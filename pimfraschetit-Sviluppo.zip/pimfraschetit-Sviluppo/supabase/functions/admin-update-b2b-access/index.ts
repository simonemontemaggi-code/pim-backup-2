import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const jsonResponse = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return jsonResponse({ error: "Non autorizzato" }, 401);

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const adminClient = createClient(supabaseUrl, serviceKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: authError } = await userClient.auth.getClaims(token);
    const callerId = claimsData?.claims?.sub;
    if (authError || !callerId) return jsonResponse({ error: "Non autorizzato" }, 401);

    const { data: roleRow } = await adminClient
      .from("user_roles")
      .select("role")
      .eq("user_id", callerId)
      .maybeSingle();
    if (roleRow?.role !== "admin")
      return jsonResponse({ error: "Solo admin può modificare i dati di accesso B2B" }, 403);

    const body = await req.json().catch(() => null);
    const customerId = String(body?.customer_id ?? "").trim();
    const rawEmail = body?.email == null ? null : String(body.email).trim().toLowerCase();
    const rawPhone = body?.phone_number == null ? null : String(body.phone_number).trim();

    if (!customerId) return jsonResponse({ error: "customer_id obbligatorio" }, 400);
    if (!rawEmail && !rawPhone) return jsonResponse({ error: "Nessun campo da aggiornare" }, 400);
    if (rawEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(rawEmail))
      return jsonResponse({ error: "Email non valida" }, 400);
    if (rawEmail && rawEmail.length > 255) return jsonResponse({ error: "Email troppo lunga" }, 400);
    if (rawPhone && !/^\+?[0-9 ]{6,20}$/.test(rawPhone))
      return jsonResponse({ error: "Numero di telefono non valido (es. +393331234567)" }, 400);

    const { data: customer, error: custErr } = await adminClient
      .from("customers")
      .select("id, auth_user_id")
      .eq("id", customerId)
      .maybeSingle();
    if (custErr) throw custErr;
    if (!customer) return jsonResponse({ error: "Cliente non trovato" }, 404);
    if (!customer.auth_user_id)
      return jsonResponse({ error: "Cliente non ancora attivato sul portale B2B" }, 400);

    const uid = customer.auth_user_id as string;

    if (rawEmail) {
      const { error: updateAuthError } = await adminClient.auth.admin.updateUserById(uid, {
        email: rawEmail,
        email_confirm: true,
      });
      if (updateAuthError) {
        const msg = updateAuthError.message || "";
        const isDuplicate = /duplicate key|already (been )?registered|users_email/i.test(msg);
        return jsonResponse(
          {
            error: isDuplicate
              ? `L'email "${rawEmail}" è già usata da un altro utente. Scegli un'email diversa.`
              : msg || "Errore aggiornamento email",
          },
          400,
        );
      }

      const { error: profErr } = await adminClient
        .from("profiles")
        .update({ email: rawEmail })
        .eq("user_id", uid);
      if (profErr) throw profErr;

      const { error: custUpdErr } = await adminClient
        .from("customers")
        .update({ mail_accesso_cliente: rawEmail })
        .eq("id", customerId);
      if (custUpdErr) throw custUpdErr;
    }

    if (rawPhone) {
      const normalizedPhone = rawPhone.replace(/\s/g, "");
      const { error: phoneErr } = await adminClient
        .from("profiles")
        .update({ phone_number: normalizedPhone, phone_set_at: new Date().toISOString() })
        .eq("user_id", uid);
      if (phoneErr) throw phoneErr;
    }

    return jsonResponse({ ok: true, email: rawEmail, phone_number: rawPhone });
  } catch (error) {
    return jsonResponse({ error: error instanceof Error ? error.message : String(error) }, 500);
  }
});

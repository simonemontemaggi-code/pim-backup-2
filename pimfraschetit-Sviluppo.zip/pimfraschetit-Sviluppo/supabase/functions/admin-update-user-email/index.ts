import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const jsonResponse = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return jsonResponse({ error: "Non autorizzato" }, 401);

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const adminClient = createClient(supabaseUrl, serviceKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: authData, error: authError } = await userClient.auth.getUser(token);
    if (authError || !authData.user) return jsonResponse({ error: "Non autorizzato" }, 401);

    const { data: roleRow, error: roleError } = await adminClient
      .from("user_roles")
      .select("role")
      .eq("user_id", authData.user.id)
      .maybeSingle();

    if (roleError) throw roleError;
    if (roleRow?.role !== "admin") return jsonResponse({ error: "Solo admin può modificare l'email login" }, 403);

    const body = await req.json().catch(() => null);
    const userId = String(body?.user_id ?? body?.userId ?? "").trim();
    const email = String(body?.email ?? body?.new_email ?? body?.newEmail ?? "").trim().toLowerCase();

    if (!userId || !email) return jsonResponse({ error: "user_id e nuova email sono obbligatori" }, 400);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return jsonResponse({ error: "Email non valida" }, 400);

    const { error: updateAuthError } = await adminClient.auth.admin.updateUserById(userId, {
      email,
      email_confirm: true,
    });
    if (updateAuthError) {
      const msg = updateAuthError.message || "";
      const isDuplicate = /duplicate key|already (been )?registered|users_email/i.test(msg);
      return jsonResponse({
        error: isDuplicate
          ? `L'email "${email}" è già usata da un altro utente. Scegli un'email diversa.`
          : msg || "Errore aggiornamento email",
      }, 400);
    }

    const { error: profileError } = await adminClient
      .from("profiles")
      .update({ email })
      .eq("user_id", userId);
    if (profileError) throw profileError;

    return jsonResponse({ ok: true, email });
  } catch (error) {
    return jsonResponse({ error: error instanceof Error ? error.message : String(error) }, 500);
  }
});

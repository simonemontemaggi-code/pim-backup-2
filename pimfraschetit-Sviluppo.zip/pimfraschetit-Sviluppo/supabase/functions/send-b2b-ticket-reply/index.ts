// deno-lint-ignore-file no-explicit-any
import { createClient } from "npm:@supabase/supabase-js@2";
import { SMTPClient } from "https://deno.land/x/denomailer@1.6.0/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SMTP_HOST = "pro.turbo-smtp.com";
const SMTP_PORT = 465;
const SMTP_USER = "6c018dcf57";
const FROM_EMAIL = "ordini@fraschetti.com";
const FROM_NAME = "Fraschetti Support";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const SMTP_PASSWORD = Deno.env.get("SMTP_PASSWORD") ?? "";

const B2B_PORTAL_BASE = "https://b2b.fraschetti.com";

const CATEGORY_LABELS: Record<string, string> = {
  ordini: "Ordini",
  contabile: "Amministrazione",
  tecnico: "Supporto tecnico",
  commerciale: "Commerciale",
  annullamento_ordine: "Annullamento ordine",
  altro: "Altro",
};

function esc(s: any) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!),
  );
}
function encodeSubject(s: string): string {
  return s
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[^\x20-\x7E]/g, "?");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const authHeader = req.headers.get("Authorization") ?? "";
  if (!authHeader.startsWith("Bearer ")) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const authed = createClient(SUPABASE_URL, ANON_KEY, {
    global: { headers: { Authorization: authHeader } },
  });
  const admin = createClient(SUPABASE_URL, SERVICE_ROLE);

  try {
    const { ticket_id, message_id, final_status } = await req.json().catch(() => ({}));
    const VALID_STATUS = ["open", "in_progress", "closed"];
    if (final_status && !VALID_STATUS.includes(final_status)) {
      return new Response(JSON.stringify({ error: "final_status non valido" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!ticket_id || !message_id) {
      return new Response(JSON.stringify({ error: "ticket_id and message_id required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verifica auth
    const { data: userData, error: userErr } = await authed.auth.getUser();
    if (userErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Legge ticket con service role
    const { data: ticket, error: tErr } = await admin
      .from("customer_support_tickets")
      .select("id,subject,category,contact_email,message,created_at,customer_id,status")
      .eq("id", ticket_id)
      .single();
    if (tErr || !ticket) {
      return new Response(JSON.stringify({ error: "Ticket non trovato" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: message, error: mErr } = await admin
      .from("customer_support_ticket_messages")
      .select("id,body,author_name,author_type,created_at")
      .eq("id", message_id)
      .eq("ticket_id", ticket_id)
      .single();
    if (mErr || !message) {
      return new Response(JSON.stringify({ error: "Messaggio non trovato" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // --- Aggiornamento stato lato server (service role) ---
    // L'utente deve essere admin oppure avere permesso 'write' sulla sezione della categoria.
    const userId = userData.user.id;
    const { data: sectionKey } = await admin.rpc("ticket_category_section", {
      _cat: ticket.category,
    });
    const { data: allowed, error: permErr } = await admin.rpc("has_section_permission", {
      _user_id: userId,
      _section: sectionKey,
      _min_permission: "write",
    });
    if (permErr) console.error("has_section_permission error:", permErr);

    let currentStatus = ticket.status as string;
    const targetStatus = final_status ?? (currentStatus === "open" ? "in_progress" : null);

    if (targetStatus && targetStatus !== currentStatus) {
      if (!allowed) {
        return new Response(
          JSON.stringify({
            error: "Permessi insufficienti per cambiare lo stato di questo ticket",
            status: currentStatus,
          }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      const { data: updated, error: updErr } = await admin
        .from("customer_support_tickets")
        .update({ status: targetStatus })
        .eq("id", ticket_id)
        .select("status")
        .maybeSingle();
      if (updErr || !updated) {
        console.error("status update failed:", updErr);
        return new Response(
          JSON.stringify({
            error: `Aggiornamento stato fallito: ${updErr?.message ?? "nessuna riga aggiornata"}`,
            status: currentStatus,
          }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      currentStatus = updated.status as string;
    }


    if (!ticket.contact_email) {
      await admin.from("email_send_log").insert({
        template_key: "b2b_ticket_reply",
        recipient: "",
        subject: `RE: ${ticket.subject}`,
        status: "skipped",
        error: "contact_email mancante",
      });
      return new Response(JSON.stringify({ ok: true, skipped: "no_contact_email", status: currentStatus }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const categoria = CATEGORY_LABELS[ticket.category] ?? ticket.category;
    const subject = `RE: ${ticket.subject}`;
    const bodyHtml = String(message.body ?? "").replace(/\n/g, "<br/>");
    const originalHtml = String(ticket.message ?? "").replace(/\n/g, "<br/>");
    const portalLink = `${B2B_PORTAL_BASE}/support/${ticket.id}`;

    const html = `<!doctype html><html><body style="font-family:Arial,sans-serif;color:#1c5832;background:#f6faf4;padding:24px">
<div style="max-width:640px;margin:0 auto;background:#fff;border-radius:6px;padding:24px;border:1px solid #e5e5e5">
  <h2 style="color:#1c5832;margin:0 0 8px">Nuova risposta al tuo ticket</h2>
  <p style="color:#666;margin:0 0 16px">Categoria: <strong>${esc(categoria)}</strong> · Oggetto: <strong>${esc(ticket.subject)}</strong></p>
  <div style="background:#f6faf4;border-left:4px solid #1c5832;padding:12px 14px;border-radius:4px;margin:16px 0">
    ${bodyHtml}
  </div>
  <p style="margin:20px 0"><a href="${esc(portalLink)}" style="display:inline-block;background:#1c5832;color:#fff;text-decoration:none;padding:10px 18px;border-radius:4px;font-weight:600">Rispondi nel Portale B2B</a></p>
  <hr style="border:none;border-top:1px solid #e5e5e5;margin:24px 0"/>
  <p style="color:#888;font-size:12px;margin:0 0 6px">Messaggio originale:</p>
  <div style="color:#666;font-size:13px;background:#fafafa;padding:10px;border-radius:4px">${originalHtml}</div>
  <p style="color:#888;font-size:12px;margin-top:24px">Risposta automatica — Fraschetti Support</p>
</div>
</body></html>`;

    const smtp = new SMTPClient({
      connection: {
        hostname: SMTP_HOST,
        port: SMTP_PORT,
        tls: true,
        auth: { username: SMTP_USER, password: SMTP_PASSWORD },
      },
    });

    try {
      await smtp.send({
        from: `${FROM_NAME} <${FROM_EMAIL}>`,
        to: ticket.contact_email,
        subject: encodeSubject(subject),
        html,
      });
    } finally {
      await smtp.close();
    }

    await admin.from("email_send_log").insert({
      template_key: "b2b_ticket_reply",
      recipient: ticket.contact_email,
      subject: encodeSubject(subject),
      status: "sent",
    });

    return new Response(JSON.stringify({ ok: true, status: currentStatus }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e: any) {
    console.error("send-b2b-ticket-reply error:", e);
    await admin.from("email_send_log").insert({
      template_key: "b2b_ticket_reply",
      recipient: "",
      subject: "",
      status: "failed",
      error: String(e?.message ?? e),
    }).catch(() => {});
    return new Response(JSON.stringify({ error: String(e?.message ?? e) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

// deno-lint-ignore-file no-explicit-any
// Weekly B2B adoption report: generates a branded PDF and emails it every Monday 08:00.
import { createClient } from "npm:@supabase/supabase-js@2";
import { SMTPClient } from "https://deno.land/x/denomailer@1.6.0/mod.ts";
import { jsPDF } from "npm:jspdf@2.5.2";
import autoTableMod from "npm:jspdf-autotable@3.8.4";
// jspdf-autotable exports a function under different shapes when loaded via npm:
const autoTable: (doc: any, opts: any) => void =
  (typeof autoTableMod === "function"
    ? autoTableMod
    : (autoTableMod as any)?.default ?? (autoTableMod as any)?.applyPlugin) as any;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SMTP_HOST = "pro.turbo-smtp.com";
const SMTP_PORT = 465;
const SMTP_USER = "6c018dcf57";
const FROM_EMAIL = "ordini@fraschetti.com";
const FROM_NAME = "Report Fraschetti B2B";

const RECIPIENTS = [
  "federico.fraschetti@fraschetti.com",
  "alessio.frasca@fraschetti.com",
  "simone.montemaggi@fraschetti.com",
];

const LOGO_URL =
  "https://pimfraschetit.lovable.app/__l5e/assets-v1/6463911a-3aac-4d40-ab31-b370f496e458/fraschetti-mark.png";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const SMTP_PASSWORD = Deno.env.get("SMTP_PASSWORD") ?? "";

// ---------------- helpers ----------------
const nfInt = new Intl.NumberFormat("it-IT");
const fmt = (n: number | null | undefined) => nfInt.format(Number(n ?? 0));
const pct = (num: number, den: number) => (den > 0 ? `${((num / den) * 100).toFixed(1)}%` : "—");

function encodeSubject(s: string): string {
  return s
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/[^\x20-\x7E]/g, "?");
}

function romeDate(d = new Date()) {
  const fmt = new Intl.DateTimeFormat("it-IT", { timeZone: "Europe/Rome", day: "2-digit", month: "2-digit", year: "numeric" });
  return fmt.format(d);
}

// Range della settimana corrente (lunedì → domenica) in formato dd/mm/yyyy - dd/mm/yyyy
function weekRange(d = new Date()): { from: string; to: string; label: string } {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Rome", year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
  const [y, m, day] = parts.split("-").map(Number);
  const base = new Date(Date.UTC(y, m - 1, day));
  const dow = (base.getUTCDay() + 6) % 7; // 0 = lunedì
  const monday = new Date(base.getTime() - dow * 86400000);
  const sunday = new Date(monday.getTime() + 6 * 86400000);
  const f = (dt: Date) =>
    `${String(dt.getUTCDate()).padStart(2, "0")}/${String(dt.getUTCMonth() + 1).padStart(2, "0")}/${dt.getUTCFullYear()}`;
  return { from: f(monday), to: f(sunday), label: `${f(monday)} - ${f(sunday)}` };
}

function normalizeCode(v: any): string | null {
  const digits = String(v ?? "").replace(/\D/g, "");
  return digits ? String(parseInt(digits, 10)) : null;
}

function weekStartMonday(iso: string | null | undefined): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  const day = d.getUTCDay();
  const diff = (day + 6) % 7;
  const monday = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - diff));
  return monday.toISOString().slice(0, 10);
}

// ---------------- data fetch ----------------
async function fetchAdoption(supabase: any) {
  const since30 = new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString();

  const [
    totCust,
    attivatiRows,
    conAccount,
    firstLoginPending,
    termsAccepted,
    newsletterCount,
    videoAttivi,
    videoOrdini,
    ordersList,
    loginsList,
    articleEvents30,
    totPerZoneRaw,
    vcFlags,
  ] = await Promise.all([
    supabase.from("customers").select("id", { count: "exact", head: true }),
    supabase.from("customers").select("activated_at, zone_code, original_agent_code, customer_code, auth_user_id").not("activated_at", "is", null),
    supabase.from("customers").select("auth_user_id").not("auth_user_id", "is", null).limit(20000),
    supabase.from("profiles").select("user_id").is("terms_accepted_at", null).limit(20000),
    supabase.from("profiles").select("user_id, terms_accepted_at").not("terms_accepted_at", "is", null).limit(20000),
    supabase.from("profiles").select("user_id", { count: "exact", head: true }).eq("newsletter_subscribed", true),
    supabase.from("customer_videocatalogo_flags").select("customer_code_norm", { count: "exact", head: true }).eq("videocatalogo_attivo", true),
    supabase.from("customer_videocatalogo_flags").select("customer_code_norm", { count: "exact", head: true }).eq("con_ordini", true),
    supabase.from("customer_orders").select("created_at, codice_cliente, auth_user_id").limit(20000),
    supabase.from("user_login_events").select("created_at, auth_user_id").limit(10000),
    supabase.from("article_events").select("customer_code, occurred_at").eq("source", "b2b").gte("occurred_at", since30).limit(50000),
    supabase.from("customers").select("zone_code, original_agent_code").limit(20000),
    supabase.from("customer_videocatalogo_flags").select("customer_code_norm, con_ordini").eq("videocatalogo_attivo", true).limit(20000),
  ]);

  const activatedCustomers = attivatiRows.data ?? [];
  const customerAuthIds = new Set((conAccount.data ?? []).map((r: any) => r.auth_user_id).filter(Boolean));
  const activatedCustomerAuthIds = new Set(activatedCustomers.map((r: any) => r.auth_user_id).filter(Boolean));

  const customerOrders = (ordersList.data ?? []).filter((o: any) => o.auth_user_id && customerAuthIds.has(o.auth_user_id));
  const customerLogins = (loginsList.data ?? []).filter((l: any) => l.auth_user_id && customerAuthIds.has(l.auth_user_id));

  const vcArr = (vcFlags.data ?? []) as Array<{ customer_code_norm: string; con_ordini: boolean }>;
  const vcCodesSet = new Set(vcArr.map((f) => f.customer_code_norm));
  const codesNorm = new Set(
    activatedCustomers.map((c: any) => normalizeCode(c.customer_code)).filter((v: any) => !!v),
  );
  const migrati = vcArr.filter((f) => codesNorm.has(f.customer_code_norm)).length;

  const ordini30 = customerOrders.filter((o: any) => o.created_at >= since30).length;
  const login30 = new Set(customerLogins.filter((l: any) => l.created_at >= since30).map((l: any) => l.auth_user_id)).size;
  const attivi30 = new Set((articleEvents30.data ?? []).map((r: any) => r.customer_code).filter(Boolean)).size;

  const orderedCodesNormArr = new Set(customerOrders.map((o: any) => o.codice_cliente).filter(Boolean));
  const clientiConOrdine = orderedCodesNormArr.size;

  const currentMonday = weekStartMonday(new Date().toISOString()) + "T00:00:00Z";
  const isWeek = (iso: string) => !!iso && iso >= currentMonday;
  const attivati_week = activatedCustomers.filter((c: any) => isWeek(c.activated_at)).length;
  const terms_accepted_week = (termsAccepted.data ?? []).filter(
    (r: any) => activatedCustomerAuthIds.has(r.user_id) && isWeek(r.terms_accepted_at),
  ).length;
  const login_week = new Set(customerLogins.filter((l: any) => isWeek(l.created_at)).map((l: any) => l.auth_user_id)).size;
  const attivi_week = new Set(
    (articleEvents30.data ?? []).filter((r: any) => isWeek(r.occurred_at)).map((r: any) => r.customer_code).filter(Boolean),
  ).size;
  const ordiniWeekArr = customerOrders.filter((o: any) => isWeek(o.created_at));
  const ordini_week = ordiniWeekArr.length;
  const clienti_con_ordine_week = new Set(ordiniWeekArr.map((o: any) => o.codice_cliente).filter(Boolean)).size;

  const pendingTermsUids = new Set((firstLoginPending.data ?? []).map((r: any) => r.user_id).filter((uid: string) => uid && activatedCustomerAuthIds.has(uid)));
  const termsUids = new Set((termsAccepted.data ?? []).map((r: any) => r.user_id).filter((uid: string) => uid && activatedCustomerAuthIds.has(uid)));

  // per zona / agente
  const totByZone = new Map<string, number>();
  const totByAgent = new Map<string, number>();
  (totPerZoneRaw.data ?? []).forEach((c: any) => {
    const z = c.zone_code ?? "—"; const a = c.original_agent_code ?? "—";
    totByZone.set(z, (totByZone.get(z) ?? 0) + 1);
    totByAgent.set(a, (totByAgent.get(a) ?? 0) + 1);
  });
  const actByZone = new Map<string, number>();
  const actByAgent = new Map<string, number>();
  activatedCustomers.forEach((c: any) => {
    const z = c.zone_code ?? "—"; const a = c.original_agent_code ?? "—";
    actByZone.set(z, (actByZone.get(z) ?? 0) + 1);
    actByAgent.set(a, (actByAgent.get(a) ?? 0) + 1);
  });
  const agentCodes = Array.from(actByAgent.keys()).filter((a) => a && a !== "—");
  const { data: agentProfiles } = await supabase
    .from("profiles").select("agent_code, full_name, email")
    .in("agent_code", agentCodes.length ? agentCodes : ["__none__"]);
  const agentNameMap = new Map<string, string>();
  (agentProfiles ?? []).forEach((p: any) => {
    const name = p.full_name || p.email || null;
    if (p.agent_code && name) agentNameMap.set(p.agent_code, name);
  });

  const perZone = Array.from(actByZone.entries())
    .map(([zone, attivati]) => ({ zone, attivati, totali: totByZone.get(zone) ?? 0 }))
    .sort((a, b) => b.attivati - a.attivati);
  const perAgent = Array.from(actByAgent.entries())
    .map(([agent, attivati]) => ({
      agent, agentName: agentNameMap.get(agent) ?? null,
      attivati, totali: totByAgent.get(agent) ?? 0,
    }))
    .sort((a, b) => b.attivati - a.attivati);

  return {
    tot: totCust.count ?? 0,
    attivati: activatedCustomers.length,
    conAccount: customerAuthIds.size,
    firstLoginPending: pendingTermsUids.size,
    termsAccepted: termsUids.size,
    newsletter: newsletterCount.count ?? 0,
    videocatAttivi: videoAttivi.count ?? 0,
    videocatOrdini: videoOrdini.count ?? 0,
    migrati,
    attivi30, login30, ordini30,
    ordiniTot: customerOrders.length,
    clientiConOrdine,
    attivati_week, terms_accepted_week, login_week, attivi_week,
    ordini_week, clienti_con_ordine_week,
    perZone, perAgent,
  };
}

// ---------------- PDF ----------------
async function fetchLogoBytes(): Promise<Uint8Array | null> {
  try {
    const r = await fetch(LOGO_URL);
    if (!r.ok) return null;
    return new Uint8Array(await r.arrayBuffer());
  } catch { return null; }
}

function toDataUrlPng(bytes: Uint8Array): string {
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.slice(i, i + 0x8000));
  return "data:image/png;base64," + btoa(s);
}

const BRAND = { r: 37, g: 99, b: 235 }; // #2563eb
const DARK = { r: 15, g: 23, b: 42 };

async function buildPdf(data: Awaited<ReturnType<typeof fetchAdoption>>): Promise<Uint8Array> {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const M = 40;
  const range = weekRange();

  const drawHeader = (compact = false) => {
    const h = compact ? 46 : 90;
    doc.setFillColor(DARK.r, DARK.g, DARK.b);
    doc.rect(0, 0, W, h, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(compact ? 14 : 22);
    doc.text("B2B", W - M, compact ? 29 : 44, { align: "right" });
    doc.setFont("helvetica", "normal");
    doc.setFontSize(compact ? 9 : 11);
    doc.text(`Report settimanale ${range.label}`, W - M, compact ? 40 : 64, { align: "right" });
  };

  // ---- header ----
  drawHeader(false);
  const logo = await fetchLogoBytes();
  if (logo) {
    try { doc.addImage(toDataUrlPng(logo), "PNG", M, 21, 39, 48); } catch { /* ignore */ }
  }

  // ---- KPI cards (stessa panoramica della dashboard) ----
  const kpis: Array<{ label: string; value: number; sub?: string; hint?: string }> = [
    { label: "Anagrafica clienti", value: data.tot, hint: `${fmt(data.videocatAttivi)} gia attivi su Videocatalogo (VdC)` },
    { label: "Attivati su B2B", value: data.attivati, sub: `+${fmt(data.attivati_week)} nuovi in settimana`, hint: `${pct(data.attivati, data.tot)} adozione` },
    { label: "Primo accesso in attesa", value: data.firstLoginPending },
    { label: "Contratti accettati", value: data.termsAccepted, sub: `+${fmt(data.terms_accepted_week)} nuovi in settimana` },
    { label: "Iscritti newsletter", value: data.newsletter },
    { label: "Attivi ultimi 30gg", value: data.attivi30, sub: `di cui ${fmt(data.attivi_week)} attivi in settimana` },
    { label: "Login ultimi 30gg", value: data.login30, sub: `di cui ${fmt(data.login_week)} in settimana` },
    { label: "Clienti con ordine online", value: data.clientiConOrdine, sub: `di cui ${fmt(data.clienti_con_ordine_week)} in settimana`, hint: `${fmt(data.ordiniTot)} ordini totali · ${fmt(data.ordini_week)} in settimana` },
  ];
  const cardW = (W - M * 2 - 3 * 10) / 4;
  const cardH = 82;
  let y = 112;
  kpis.forEach((k, i) => {
    const col = i % 4;
    const row = Math.floor(i / 4);
    const x = M + col * (cardW + 10);
    const yy = y + row * (cardH + 10);
    doc.setDrawColor(226, 232, 240);
    doc.setFillColor(248, 250, 252);
    doc.roundedRect(x, yy, cardW, cardH, 6, 6, "FD");
    doc.setTextColor(100, 116, 139);
    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    doc.text(doc.splitTextToSize(k.label, cardW - 20)[0], x + 10, yy + 16);
    doc.setTextColor(DARK.r, DARK.g, DARK.b);
    doc.setFontSize(20);
    doc.setFont("helvetica", "bold");
    doc.text(fmt(k.value), x + 10, yy + 42);
    if (k.sub) {
      doc.setTextColor(22, 163, 74);
      doc.setFontSize(7.5);
      doc.setFont("helvetica", "bold");
      doc.text(doc.splitTextToSize(k.sub, cardW - 20).slice(0, 1), x + 10, yy + 56);
    }
    if (k.hint) {
      doc.setTextColor(148, 163, 184);
      doc.setFontSize(7);
      doc.setFont("helvetica", "normal");
      doc.text(doc.splitTextToSize(k.hint, cardW - 20).slice(0, 2), x + 10, yy + 68);
    }
  });

  y += 2 * (cardH + 10) + 14;

  // ---- Migrazione Videocatalogo (VdC) verso B2B ----
  doc.setTextColor(DARK.r, DARK.g, DARK.b);
  doc.setFontSize(13);
  doc.setFont("helvetica", "bold");
  doc.text("Migrazione Videocatalogo (VdC) verso B2B", M, y);
  y += 8;
  autoTable(doc, {
    startY: y,
    head: [["Metrica", "Valore"]],
    body: [
      ["Clienti attivi su Videocatalogo", fmt(data.videocatAttivi)],
      ["Clienti Videocatalogo con ordini", fmt(data.videocatOrdini)],
      ["...di cui migrati al B2B", `${fmt(data.migrati)} (${pct(data.migrati, data.videocatAttivi)})`],
      ["Clienti senza Videocatalogo attivo", fmt(Math.max(0, data.tot - data.videocatAttivi))],
      ["Adozione B2B su anagrafica", `${fmt(data.attivati)} / ${fmt(data.tot)} (${pct(data.attivati, data.tot)})`],
    ],
    theme: "grid",
    headStyles: { fillColor: [BRAND.r, BRAND.g, BRAND.b], textColor: 255, fontStyle: "bold" },
    styles: { fontSize: 10, cellPadding: 6 },
    columnStyles: { 1: { halign: "right", cellWidth: 200 } },
    margin: { left: M, right: M },
  });

  // ---- per agente (nuova pagina) ----
  doc.addPage();
  drawHeader(true);

  doc.setTextColor(DARK.r, DARK.g, DARK.b);
  doc.setFontSize(13); doc.setFont("helvetica", "bold");
  doc.text("Adozione per agente", M, 76);
  autoTable(doc, {
    startY: 84,
    head: [["Codice", "Nome agente", "Attivati", "Totali", "Adozione %"]],
    body: [
      ...data.perAgent.map((a) => [
        a.agent, a.agentName ?? "—", fmt(a.attivati), fmt(a.totali), pct(a.attivati, a.totali),
      ]),
      [
        { content: "Totale", colSpan: 2, styles: { fontStyle: "bold" } },
        { content: fmt(data.perAgent.reduce((s, r) => s + r.attivati, 0)), styles: { fontStyle: "bold", halign: "right" } },
        { content: fmt(data.perAgent.reduce((s, r) => s + r.totali, 0)), styles: { fontStyle: "bold", halign: "right" } },
        { content: pct(data.perAgent.reduce((s, r) => s + r.attivati, 0), data.perAgent.reduce((s, r) => s + r.totali, 0)), styles: { fontStyle: "bold", halign: "right" } },
      ],
    ],
    theme: "striped",
    headStyles: { fillColor: [BRAND.r, BRAND.g, BRAND.b], textColor: 255 },
    styles: { fontSize: 9, cellPadding: 4 },
    columnStyles: { 2: { halign: "right" }, 3: { halign: "right" }, 4: { halign: "right" } },
    margin: { left: M, right: M },
  });

  // footer su tutte le pagine
  const pages = doc.getNumberOfPages();
  for (let p = 1; p <= pages; p++) {
    doc.setPage(p);
    doc.setDrawColor(226, 232, 240);
    doc.line(M, H - 30, W - M, H - 30);
    doc.setTextColor(100, 116, 139);
    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    doc.text("Fraschetti · Report B2B generato automaticamente", M, H - 16);
    doc.text(`Pag. ${p}/${pages}`, W - M, H - 16, { align: "right" });
  }

  return new Uint8Array(doc.output("arraybuffer"));
}

// ---------------- email ----------------
function buildEmailHtml(dataStr: string, rangeLabel: string) {
  return `<!doctype html><html><body style="margin:0;background:#f1f5f9;padding:24px;font-family:Arial,sans-serif">
    <table cellspacing="0" cellpadding="0" style="max-width:640px;margin:0 auto;background:#fff;border-radius:8px;overflow:hidden;border:1px solid #e2e8f0">
      <tr><td style="background:#0f172a;padding:20px 24px;color:#fff">
        <div style="font-size:20px;font-weight:bold">B2B</div>
        <div style="font-size:13px;opacity:.8">Report settimanale ${rangeLabel}</div>
      </td></tr>
      <tr><td style="padding:24px">
        <p style="margin:0;font-size:14px;color:#334155">In allegato il PDF con i dati completi di adozione del portale B2B. Riepilogo principale aggiornati al ${dataStr}</p>
      </td></tr>
    </table></body></html>`;
}

// ---------------- handler ----------------
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);
    const data = await fetchAdoption(supabase);
    const pdfBytes = await buildPdf(data);
    const dataStr = romeDate();
    const range = weekRange();
    const subject = `B2B - Report settimanale ${range.label}`;
    const html = buildEmailHtml(dataStr, range.label);

    // Anteprima PDF senza invio: ?preview=1
    if (new URL(req.url).searchParams.get("preview") === "1") {
      return new Response(pdfBytes, {
        headers: { ...corsHeaders, "Content-Type": "application/pdf" },
      });
    }

    if (!SMTP_PASSWORD) {
      return new Response(JSON.stringify({ error: "SMTP_PASSWORD non configurato" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const body = await req.json().catch(() => ({}));
    const testRecipient: string | undefined = body?.test_to;
    const scheduled: boolean = !!body?.scheduled;

    // Se invocato dal cron (che gira a 21:59 e 22:59 UTC di domenica per coprire DST),
    // invia solo quando in Europe/Rome sono le 23:xx di domenica.
    if (scheduled && !testRecipient) {
      const romeH = new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/Rome", hour: "2-digit", hour12: false }).format(new Date());
      const romeDow = new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/Rome", weekday: "short" }).format(new Date());
      if (romeH !== "23" || romeDow !== "Sun") {
        return new Response(JSON.stringify({ skipped: true, rome_hour: romeH, rome_dow: romeDow }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }


    const recipients = testRecipient ? [testRecipient] : RECIPIENTS;

    const client = new SMTPClient({
      connection: { hostname: SMTP_HOST, port: SMTP_PORT, tls: true, auth: { username: SMTP_USER, password: SMTP_PASSWORD } },
    });

    for (const to of recipients) {
      await client.send({
        from: `${FROM_NAME} <${FROM_EMAIL}>`,
        to,
        subject: encodeSubject(subject),
        html,
        attachments: [
          {
            filename: `Report_B2B_${range.from.replace(/\//g, "-")}_${range.to.replace(/\//g, "-")}.pdf`,
            content: pdfBytes,
            encoding: "binary",
            contentType: "application/pdf",
          },
        ],
      });
    }

    await client.close();

    return new Response(JSON.stringify({ ok: true, recipients, subject, pdf_size: pdfBytes.byteLength }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("send-weekly-b2b-report error:", e);
    return new Response(JSON.stringify({ error: String((e as any)?.message ?? e) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

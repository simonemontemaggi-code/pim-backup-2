import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Fetch pending items with attempts < 3
    const { data: pendingItems, error: fetchError } = await supabase
      .from("as400_sync_queue")
      .select("*")
      .eq("status", "pending")
      .lt("attempts", 3)
      .order("created_at", { ascending: true })
      .limit(100);

    if (fetchError) throw fetchError;

    let sent = 0;
    let errors = 0;

    for (const item of pendingItems ?? []) {
      const newAttempts = (item.attempts ?? 0) + 1;

      try {
        // Simulate send — log payload (real endpoint added later)
        console.log(
          `[sync-as400-retry] Processing ${item.cdpar} (attempt ${newAttempts}/3)`,
          JSON.stringify(item.payload).slice(0, 200)
        );

        // Mark as synced
        await supabase
          .from("as400_sync_queue")
          .update({
            status: "synced",
            attempts: newAttempts,
            last_attempt_at: new Date().toISOString(),
            sent_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          })
          .eq("id", item.id);

        // Update article sync status
        await supabase
          .from("archivio_articoli_fraschetti")
          .update({
            as400_sync_status: "synced",
            updated_at: new Date().toISOString(),
          })
          .eq("cdpar", item.cdpar);

        sent++;
      } catch (err) {
        // If this was the 3rd attempt, mark as error
        if (newAttempts >= 3) {
          await supabase
            .from("as400_sync_queue")
            .update({
              status: "error",
              attempts: newAttempts,
              last_attempt_at: new Date().toISOString(),
              error_message: `Max retry attempts reached: ${err instanceof Error ? err.message : String(err)}`,
              updated_at: new Date().toISOString(),
            })
            .eq("id", item.id);
          errors++;
        } else {
          await supabase
            .from("as400_sync_queue")
            .update({
              attempts: newAttempts,
              last_attempt_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            })
            .eq("id", item.id);
        }
      }
    }

    const summary = {
      processed: (pendingItems ?? []).length,
      sent,
      errors,
      timestamp: new Date().toISOString(),
    };

    console.log("[sync-as400-retry] Summary:", summary);

    return new Response(JSON.stringify(summary), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (err) {
    console.error("[sync-as400-retry] Error:", err);
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : String(err) }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});

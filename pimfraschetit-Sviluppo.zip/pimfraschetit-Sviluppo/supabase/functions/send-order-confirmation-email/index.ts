// deno-lint-ignore-file no-explicit-any
import { createClient } from "npm:@supabase/supabase-js@2";
import { SMTPClient } from "https://deno.land/x/denomailer@1.6.0/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SMTP_HOST = "pro.turbo-smtp.com";
const SMTP_PORT = 465;
const SMTP_USER = "6c018dcf57";
const FROM_EMAIL = "ordini@fraschetti.com";
const FROM_NAME = "Ordini Fraschetti";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const SMTP_PASSWORD = Deno.env.get("SMTP_PASSWORD") ?? "";

function fmtMoney(n: number | null | undefined) {
  const v = Number(n ?? 0);
  return v.toLocaleString("it-IT", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " €";
}
function fmtDate(s: string | null | undefined) {
  if (!s) return "-";
  try {
    return new Date(s).toLocaleString("it-IT", { dateStyle: "short", timeStyle: "short", timeZone: "Europe/Rome" });
  } catch { return s; }
}
function esc(s: any) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}
function encodeSubject(s: string): string {
  return s
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[^\x20-\x7E]/g, "?");
}

function base64Utf8(s: string): string {
  const bytes = new TextEncoder().encode(s);
  const chunks: string[] = [];
  for (let i = 0; i < bytes.length; i += 0x8000) {
    chunks.push(String.fromCharCode(...bytes.slice(i, i + 0x8000)));
  }
  return btoa(chunks.join(""))
    .replace(/.{1,76}/g, "$&\r\n")
    .trimEnd();
}

function buildItemsRows(items: any[]) {
  return items.map((it) => {
    const sku = esc(it.sku ?? it.product_id ?? "");
    const name = esc(it.name ?? "");
    const qty = Number(it.quantity ?? 0);
    const unit = Number(it.unit_price ?? 0);
    const finalP = it.final_price != null ? Number(it.final_price) : unit;
    const netto = it.net_price != null && Number(it.net_price) > 0
      ? Number(it.net_price)
      : (it.list_price != null && Number(it.list_price) > 0 ? Number(it.list_price) : null);
    const scontoNum = Number(it.discount_pct ?? 0);
    const nettoCell = netto != null ? fmtMoney(netto) : "—";
    const prezzoFinale = fmtMoney(finalP);
    const sconto = scontoNum > 0
      ? `-${Number.isInteger(scontoNum) ? scontoNum : scontoNum.toFixed(2).replace(/\.?0+$/, "")}%`
      : "—";
    const totRiga = fmtMoney(it.line_total ?? (qty * finalP));
    return [
      `<tr>`,
      `<td style="padding:5px 6px;border-bottom:1px solid #d8e9d4;line-height:16px;vertical-align:top;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#1f2a22">`,
      `<strong style="color:#145a24;font-family:Arial,Helvetica,sans-serif;font-size:12px">${sku}</strong>`,
      ` ${name}`,
      `</td>`,
      `<td align="right" style="padding:5px 6px;border-bottom:1px solid #d8e9d4;line-height:16px;vertical-align:top;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#8a8a8a;white-space:nowrap">${nettoCell}</td>`,
      `<td align="right" style="padding:5px 6px;border-bottom:1px solid #d8e9d4;line-height:16px;vertical-align:top;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:${scontoNum > 0 ? "#1e9239" : "#8a8a8a"};white-space:nowrap">${sconto}</td>`,
      `<td align="right" style="padding:5px 6px;border-bottom:1px solid #d8e9d4;line-height:16px;vertical-align:top;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#1f2a22;white-space:nowrap">${prezzoFinale}</td>`,
      `<td align="right" style="padding:5px 6px;border-bottom:1px solid #d8e9d4;line-height:16px;vertical-align:top;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#1f2a22;white-space:nowrap">${qty}</td>`,
      `<td align="right" style="padding:5px 6px;border-bottom:1px solid #d8e9d4;line-height:16px;vertical-align:top;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#145a24;font-weight:bold;white-space:nowrap">${totRiga}</td>`,
      `</tr>`,
    ].join("\n");
  }).join("\n");
}


function buildOrderEmailHtml(data: Record<string, string>, items: any[]) {
  const rows = buildItemsRows(items);
  const noteRow = data.note
    ? [
      `<tr>`,
      `<td style="padding:10px 12px;border-top:1px solid #d8e9d4;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:17px;color:#1f2a22">`,
      `<strong style="color:#145a24">Note:</strong> ${data.note}`,
      `</td>`,
      `</tr>`,
    ].join("\n")
    : "";

  return [
    `<!doctype html>`,
    `<html>`,
    `<body style="margin:0;padding:0;background:#ffffff">`,
    `<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:collapse;background:#ffffff">`,
    `<tr>`,
    `<td align="center" style="padding:0">`,
    `<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="680" style="width:680px;max-width:100%;border-collapse:collapse;background:#ffffff;font-family:Arial,Helvetica,sans-serif;color:#1f2a22">`,
    `<tr>`,
    `<td align="center" style="padding:14px 12px 8px;border-bottom:4px solid #1e9239">`,
    `<img src="https://pim.fraschetti.com/__l5e/assets-v1/64b03c23-f1e0-4dee-8e27-5198fa313162/fraschetti-logo-email.png" alt="Fraschetti Distribuzione" width="160" style="display:block;width:160px;max-width:160px;height:auto;border:0;outline:none">`,
    `</td>`,
    `</tr>`,
    `<tr>`,
    `<td style="padding:10px 12px;font-family:Arial,Helvetica,sans-serif;font-size:18px;line-height:22px;font-weight:bold;color:#145a24;border-bottom:1px solid #d8e9d4">Conferma ordine</td>`,
    `</tr>`,
    `<tr>`,
    `<td style="padding:0">`,
    `<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:collapse;background:#fbfdf9">`,
    `<tr>`,
    `<td style="padding:5px 12px;width:34%;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:16px;color:#1f2a22"><strong style="color:#145a24">Ordine:</strong> ${data.numero_ordine}</td>`,
    `<td style="padding:5px 12px;width:33%;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:16px;color:#1f2a22"><strong style="color:#145a24">Trasmissione:</strong> ${data.numero_trasmissione}</td>`,
    `<td style="padding:5px 12px;width:33%;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:16px;color:#1f2a22"><strong style="color:#145a24">Data:</strong> ${data.data_ordine}</td>`,
    `</tr>`,
    `</table>`,
    `</td>`,
    `</tr>`,
    `<tr>`,
    `<td style="padding:12px">`,
    `<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:collapse">`,
    `<tr>`,
    `<td style="padding:4px 0;font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:18px;color:#1f2a22"><strong style="color:#145a24">Agente:</strong> ${data.agente_nome} (${data.agente_codice})</td>`,
    `</tr>`,
    `<tr>`,
    `<td style="padding:4px 0;font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:18px;color:#1f2a22"><strong style="color:#145a24">Cliente:</strong> ${data.cliente_codice} ${data.cliente_ragione_sociale}</td>`,
    `</tr>`,
    `<tr>`,
    `<td style="padding:4px 0;font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:18px;color:#1f2a22"><strong style="color:#145a24">Indirizzo:</strong> ${data.cliente_indirizzo} ${data.cliente_citta}</td>`,
    `</tr>`,
    `</table>`,
    `</td>`,
    `</tr>`,
    `<tr>`,
    `<td style="padding:0 12px 12px">`,
    `<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:collapse;border:1px solid #d8e9d4">`,
    `<tr>`,
    `<td style="padding:6px;background:#eaf5e7;border-bottom:1px solid #d8e9d4;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:14px;font-weight:bold;color:#145a24">Articolo</td>`,
    `<td align="right" style="padding:6px;background:#eaf5e7;border-bottom:1px solid #d8e9d4;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:14px;font-weight:bold;color:#145a24;white-space:nowrap">Netto</td>`,
    `<td align="right" style="padding:6px;background:#eaf5e7;border-bottom:1px solid #d8e9d4;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:14px;font-weight:bold;color:#145a24;white-space:nowrap">Sconto</td>`,
    `<td align="right" style="padding:6px;background:#eaf5e7;border-bottom:1px solid #d8e9d4;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:14px;font-weight:bold;color:#145a24;white-space:nowrap">Prezzo finale</td>`,
    `<td align="right" style="padding:6px;background:#eaf5e7;border-bottom:1px solid #d8e9d4;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:14px;font-weight:bold;color:#145a24;white-space:nowrap">Q.tà</td>`,
    `<td align="right" style="padding:6px;background:#eaf5e7;border-bottom:1px solid #d8e9d4;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:14px;font-weight:bold;color:#145a24;white-space:nowrap">Totale riga</td>`,

    `</tr>`,
    rows,
    `</table>`,
    `</td>`,
    `</tr>`,
    `<tr>`,
    `<td style="padding:0 12px 12px">`,
    `<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:collapse;background:#1e9239">`,
    `<tr>`,
    `<td style="padding:9px 12px;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:16px;font-weight:bold;color:#ffffff">Totale ordine</td>`,
    `<td align="right" style="padding:9px 12px;font-family:Arial,Helvetica,sans-serif;font-size:16px;line-height:20px;font-weight:bold;color:#ffffff;white-space:nowrap">${data.totale_ordine}</td>`,
    `</tr>`,
    `</table>`,
    `</td>`,
    `</tr>`,
    noteRow,
    `<tr>`,
    `<td style="padding:10px 12px;background:#145a24;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:15px;color:#ffffff">Email automatica generata dal sistema PIM. Non rispondere a questo messaggio.</td>`,
    `</tr>`,
    `</table>`,
    `</td>`,
    `</tr>`,
    `</table>`,
    `</body>`,
    `</html>`,
  ].filter(Boolean).join("\n");
}

function render(template: string, data: Record<string, string>) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, k) => data[k] ?? "");
}

// Normalizza l'HTML per l'invio email:
// - collassa run di whitespace tra tag ma inserisce SEMPRE un \n dopo `>`
//   così nessuna riga risulta lunghissima;
// - se malgrado questo qualche riga superasse 900 char (raro, testo lungo
//   in un tag), la spezza a forza dopo l'ultimo `>` disponibile.
// L'obiettivo è avere righe brevi in modo che il quoted-printable encoder
// di denomailer non inserisca soft-break (=\r\n) spuri, che alcuni client
// (Gmail mobile in particolare) rendono come enormi spazi bianchi.
function normalizeForEmail(html: string): string {
  const compact = html
    .replace(/\r?\n+/g, "\n")
    .replace(/>\s+</g, ">\n<")
    .replace(/[ \t]{2,}/g, " ")
    .trim();
  // Spezza eventuali righe residue troppo lunghe.
  return compact
    .split("\n")
    .flatMap((line) => {
      if (line.length <= 900) return [line];
      const out: string[] = [];
      let rest = line;
      while (rest.length > 900) {
        const cut = rest.lastIndexOf(">", 900);
        const idx = cut > 200 ? cut + 1 : 900;
        out.push(rest.slice(0, idx));
        rest = rest.slice(idx);
      }
      if (rest) out.push(rest);
      return out;
    })
    .join("\n");
}



Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const body = await req.json().catch(() => ({}));
    const { order_id, test, override_email, template_override, internal, dry_run } = body ?? {};

    if (!order_id) {
      return new Response(JSON.stringify({ error: "order_id required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);

    // Load order
    const { data: order, error: orderErr } = await supabase
      .from("customer_orders")
      .select("*")
      .eq("id", order_id)
      .maybeSingle();
    if (orderErr || !order) throw new Error(`Ordine non trovato: ${orderErr?.message ?? order_id}`);

    // Skip if already sent — ma solo per chiamate manuali.
    // Il trigger DB imposta confirmation_email_sent_at PRIMA di invocare la
    // function (claim ottimistico anti-doppio-invio), quindi quando arriva con
    // internal=true dobbiamo procedere comunque.
    if (!test && !internal && order.confirmation_email_sent_at) {
      return new Response(JSON.stringify({ skipped: "already_sent" }), {
        status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }


    // Items — ordinate per codice prodotto
    const { data: items = [] } = await supabase
      .from("customer_order_items")
      .select("*")
      .eq("order_id", order_id)
      .order("product_id", { ascending: true });

    // Sostituisci `name` con descrizione (depar) + estensione descrizione (wdeag)
    // letti dall'anagrafica articoli. `cdpar` è char(15) paddato con spazi: matchiamo
    // sia il valore raw che quello paddato. Fallback al name salvato se non trovato.
    {
      const rawCodes = [...new Set(((items as any[]) ?? [])
        .map((i: any) => String(i.product_id ?? i.sku ?? "").trim())
        .filter(Boolean))];
      if (rawCodes.length) {
        const padded = rawCodes.map((c) => c.padEnd(15, " "));
        const { data: arts } = await supabase
          .from("archivio_articoli_fraschetti")
          .select("cdpar, depar, wdeag")
          .in("cdpar", [...rawCodes, ...padded]);
        const byCdpar = new Map((arts ?? []).map((a: any) => [String(a.cdpar).trim(), a]));
        for (const it of (items as any[])) {
          const a: any = byCdpar.get(String(it.product_id ?? it.sku ?? "").trim());
          if (!a) continue;
          const nome = [a.depar, a.wdeag]
            .map((s: any) => (s ?? "").toString().trim())
            .filter(Boolean)
            .join(" ");
          if (nome) it.name = nome;
        }
      }
    }

    // Customer
    let customer: any = null;
    if (order.customer_id) {
      const { data } = await supabase.from("customers").select("*").eq("id", order.customer_id).maybeSingle();
      customer = data;
    }
    if (!customer && order.codice_cliente) {
      const { data } = await supabase.from("customers").select("*").eq("customer_code", order.codice_cliente).maybeSingle();
      customer = data;
    }

    // Agent profile from agent_code
    let agent: any = null;
    if (order.codice_agente) {
      const { data } = await supabase
        .from("profiles")
        .select("full_name,email,order_email,agent_code")
        .eq("agent_code", order.codice_agente)
        .maybeSingle();
      agent = data;
    }

    const agentEmail = agent?.order_email || agent?.email || null;
    const customerEmail = customer?.mail_accesso_cliente || customer?.email || null;

    // Origine: CA = Agent Hub (agente in To, cliente in CC)
    //          NE = B2B Mockup (cliente in To, agente in CC)
    // Origine sconosciuta/nulla -> comportamento Agent Hub.
    const isB2b = String(order.origine ?? "").trim().toUpperCase() === "NE";
    const primary = isB2b ? customerEmail : agentEmail;
    const secondary = isB2b ? agentEmail : customerEmail;

    let recipient: string | null;
    let ccList: string[] = [];
    if (override_email) {
      recipient = override_email;
    } else {
      recipient = primary || secondary || null;
      const cc = primary ? secondary : null;
      if (cc && cc.toLowerCase() !== (recipient ?? "").toLowerCase()) ccList = [cc];
    }

    if (!recipient) {
      const errMsg = `Nessun destinatario: agente ${order.codice_agente ?? "?"} e cliente ${order.codice_cliente ?? "?"} senza email`;
      await supabase.from("email_send_log").insert({
        template_key: "order_confirmation_agent",
        recipient: "(none)",
        status: "failed",
        error: errMsg,
        order_id,
        is_test: !!test,
      });
      return new Response(JSON.stringify({ error: errMsg }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const recipientLog = ccList.length ? `${recipient} (cc: ${ccList.join(", ")})` : recipient;


    // Template
    let subject: string;
    if (template_override?.subject) {
      subject = template_override.subject;
    } else {
      const { data: tpl } = await supabase
        .from("email_templates")
        .select("subject,enabled")
        .eq("key", "order_confirmation_agent")
        .maybeSingle();
      if (!tpl) throw new Error("Template order_confirmation_agent non trovato");
      if (!tpl.enabled && !test) {
        return new Response(JSON.stringify({ skipped: "template_disabled" }), {
          status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      subject = tpl.subject;
    }

    const totale = Number(order.total ?? items.reduce((s: number, it: any) => s + Number(it.line_total ?? 0), 0));

    const subjectData: Record<string, string> = {
      numero_ordine: order.transmission_id || order.id.slice(0, 8),
      numero_trasmissione: order.transmission_id || "(non ancora trasmesso)",
      data_ordine: fmtDate(order.created_at),
      cliente_codice: order.codice_cliente ?? customer?.customer_code ?? "",
      cliente_ragione_sociale: customer?.company_name ?? "",
      cliente_indirizzo: customer?.delivery_address ?? customer?.address ?? "",
      cliente_citta: [customer?.delivery_city ?? customer?.city, customer?.delivery_province ?? customer?.province].filter(Boolean).join(" "),
      agente_codice: order.codice_agente ?? "",
      agente_nome: agent?.full_name ?? "Agente",
      righe_ordine: "",
      numero_righe: String(items.length),
      totale_ordine: fmtMoney(totale),
      note: order.note ?? "",
      note_blocco: "",
    };

    const data: Record<string, string> = {
      numero_ordine: esc(subjectData.numero_ordine),
      numero_trasmissione: esc(subjectData.numero_trasmissione),
      data_ordine: esc(subjectData.data_ordine),
      cliente_codice: esc(subjectData.cliente_codice),
      cliente_ragione_sociale: esc(subjectData.cliente_ragione_sociale),
      cliente_indirizzo: esc(subjectData.cliente_indirizzo),
      cliente_citta: esc(subjectData.cliente_citta),
      agente_codice: esc(subjectData.agente_codice),
      agente_nome: esc(subjectData.agente_nome),
      righe_ordine: "",
      numero_righe: String(items.length),
      totale_ordine: fmtMoney(totale),
      note: esc(subjectData.note),
      note_blocco: "",
    };

    const finalSubject = render(subject, subjectData);
    const finalHtml = buildOrderEmailHtml(data, items as any[]);

    if (dry_run) {
      return new Response(JSON.stringify({ html: normalizeForEmail(finalHtml), subject: finalSubject, recipient, cc: ccList }), {
        status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }


    // Plain-text fallback "pulito" — necessario perché denomailer con
    // content:"auto" produce un text/plain con artefatti quoted-printable (=20).
    const finalText = (() => {
      const righe = (items as any[]).map((it) => {
        const sku = it.sku ?? it.product_id ?? "";
        const name = it.name ?? "";
        const qty = Number(it.quantity ?? 0);
        const tot = fmtMoney(it.line_total ?? it.final_price);
        return `- ${sku}  ${name}  x${qty}  ${tot}`;
      }).join("\n");
      return [
        `Nuovo ordine ricevuto`,
        ``,
        `Ordine: ${data.numero_ordine}`,
        `Data: ${data.data_ordine}`,
        `Cliente: ${data.cliente_codice} ${data.cliente_ragione_sociale}`,
        `Agente: ${data.agente_codice} ${data.agente_nome}`,
        ``,
        `Righe (${data.numero_righe}):`,
        righe,
        ``,
        `Totale: ${data.totale_ordine}`,
        order.note ? `\nNote: ${order.note}` : ``,
      ].filter(Boolean).join("\n");
    })();

    // Send via SMTP
    const client = new SMTPClient({
      connection: {
        hostname: SMTP_HOST,
        port: SMTP_PORT,
        tls: true,
        auth: { username: SMTP_USER, password: SMTP_PASSWORD },
      },
    });

    await client.send({
      from: `${FROM_NAME} <${FROM_EMAIL}>`,
      to: recipient,
      ...(ccList.length ? { cc: ccList } : {}),
      subject: encodeSubject(finalSubject),

      mimeContent: [
        {
          mimeType: 'text/plain; charset="utf-8"',
          content: base64Utf8(finalText),
          transferEncoding: "base64",
        },
        {
          mimeType: 'text/html; charset="utf-8"',
          content: base64Utf8(normalizeForEmail(finalHtml)),
          transferEncoding: "base64",
        },
      ],
    });

    await client.close();

    // Log + mark sent. Unique partial index su (order_id) WHERE
    // template_key='order_confirmation_agent' AND status='sent' AND is_test=false
    // garantisce 1 sola mail di conferma "sent" per ordine.
    const { error: logErr } = await supabase.from("email_send_log").insert({
      template_key: "order_confirmation_agent",
      recipient: recipientLog,
      subject: finalSubject,
      status: "sent",
      order_id,
      is_test: !!test,
    });
    if (logErr && (logErr as any).code === "23505") {
      return new Response(JSON.stringify({ ok: true, recipient, cc: ccList, already_sent: true }), {
        status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!test) {
      await supabase.from("customer_orders")
        .update({ confirmation_email_sent_at: new Date().toISOString() })
        .eq("id", order_id);
    }

    return new Response(JSON.stringify({ ok: true, recipient, cc: ccList }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },

    });
  } catch (e: any) {
    const errMsg = e?.message ?? String(e);
    try {
      const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);
      await supabase.from("email_send_log").insert({
        template_key: "order_confirmation_agent",
        recipient: "(error)",
        status: "failed",
        error: errMsg,
      });
    } catch (_) { /* ignore */ }
    return new Response(JSON.stringify({ error: errMsg }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

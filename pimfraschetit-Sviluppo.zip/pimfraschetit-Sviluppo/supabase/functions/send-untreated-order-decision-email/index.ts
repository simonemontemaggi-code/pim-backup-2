// deno-lint-ignore-file no-explicit-any
import { createClient } from "npm:@supabase/supabase-js@2";
import { SMTPClient } from "https://deno.land/x/denomailer@1.6.0/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SMTP_HOST = "pro.turbo-smtp.com";
const SMTP_PORT = 465;
const SMTP_USER = "6c018dcf57";
const FROM_EMAIL = "ordini@fraschetti.com";
const FROM_NAME = "Ordini non trattati Fraschetti";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const SMTP_PASSWORD = Deno.env.get("SMTP_PASSWORD") ?? "";

const PIM_BASE = "https://pim.fraschetti.com";
const DEFAULT_RECIPIENTS = ["commercial@fraschetti.com", "dispo@fraschetti.com"];
const RECIPIENTS_SETTING = "email_recipients_untreated_decision";
const CC_SETTING = "email_cc_untreated_decision";

function esc(s: any) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!),
  );
}
function fmtDate(s: string | null | undefined) {
  if (!s) return "—";
  try {
    return new Date(s).toLocaleString("it-IT", { dateStyle: "short", timeStyle: "short", timeZone: "Europe/Rome" });
  } catch { return String(s); }
}
function render(template: string, data: Record<string, string>) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, k) => data[k] ?? "");
}
function encodeSubject(s: string): string {
  return s
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[^\x20-\x7E]/g, "?");
}
function parseList(raw: any): string[] {
  const str = typeof raw === "string" ? raw : (raw ? JSON.stringify(raw) : "");
  return str
    .replace(/^"|"$/g, "")
    .split(/[,;\s]+/)
    .map((s: string) => s.trim())
    .filter((s: string) => s.includes("@"));
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);

  try {
    const body = await req.json().catch(() => ({}));
    const { request_id, decision, test, override_email, template_override } = body ?? {};

    if (!request_id) throw new Error("request_id required");
    if (decision !== "accettato" && decision !== "rifiutato") {
      throw new Error(`decision must be 'accettato' or 'rifiutato' (got: ${decision})`);
    }

    const templateKey = `untreated_order_decision_${decision}`;

    const { data: row, error: rowErr } = await supabase
      .from("richieste_ordini_non_trattati")
      .select("*")
      .eq("id", request_id)
      .maybeSingle();
    if (rowErr || !row) throw new Error(`Richiesta non trovata: ${rowErr?.message ?? request_id}`);

    // Destinatari
    let recipients: string[] = [];
    let cc: string[] = [];
    if (override_email) {
      recipients = [override_email];
    } else {
      const { data: setting } = await supabase
        .from("app_settings").select("setting_value").eq("setting_key", RECIPIENTS_SETTING).maybeSingle();
      recipients = parseList(setting?.setting_value);
      if (recipients.length === 0) recipients = DEFAULT_RECIPIENTS;

      const { data: ccSetting } = await supabase
        .from("app_settings").select("setting_value").eq("setting_key", CC_SETTING).maybeSingle();
      cc = parseList(ccSetting?.setting_value);
    }

    // Template
    let subject: string;
    let body_html: string;
    if (template_override?.subject && template_override?.body_html) {
      subject = template_override.subject;
      body_html = template_override.body_html;
    } else {
      const { data: tpl } = await supabase
        .from("email_templates")
        .select("subject,body_html,enabled")
        .eq("key", templateKey)
        .maybeSingle();
      if (!tpl) throw new Error(`Template ${templateKey} non trovato`);
      if (!tpl.enabled && !test) {
        return new Response(JSON.stringify({ skipped: "template_disabled" }), {
          status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      subject = tpl.subject;
      body_html = tpl.body_html;
    }

    const agenteNomeCompleto = [row.agente_cognome, row.agente_nome].filter(Boolean).join(" ") || "—";
    const data: Record<string, string> = {
      fornitore: row.fornitore ?? "—",
      codice_articolo_fornitore: row.codice_articolo_fornitore ?? "—",
      descrizione: row.descrizione ?? "—",
      quantita: String(row.quantita ?? ""),
      nota: row.nota ?? "—",
      preventivo_note: row.preventivo_note ?? "—",
      cliente_codice: row.cliente_codice ?? "—",
      cliente_nominativo: row.cliente_nominativo ?? "—",
      agente_codice: row.agente_codice ?? "—",
      agente_nome_completo: agenteNomeCompleto,
      data_richiesta: fmtDate(row.created_at),
      link_pim: `${PIM_BASE}/pim/sales/untreated`,
    };
    for (const k of Object.keys(data)) data[k] = esc(data[k]);

    const finalSubject = render(subject, data);
    const finalHtml = render(body_html, data);

    const client = new SMTPClient({
      connection: {
        hostname: SMTP_HOST,
        port: SMTP_PORT,
        tls: true,
        auth: { username: SMTP_USER, password: SMTP_PASSWORD },
      },
    });

    await client.send({
      from: `${FROM_NAME} <${FROM_EMAIL}>`,
      to: recipients,
      ...(cc.length && !override_email ? { cc } : {}),
      subject: encodeSubject(finalSubject),
      content: "auto",
      html: finalHtml,
    });
    await client.close();

    await supabase.from("email_send_log").insert({
      template_key: templateKey,
      recipient: recipients.join(", ") + (cc.length ? ` (cc: ${cc.join(", ")})` : ""),
      subject: finalSubject,
      status: "sent",
      is_test: !!test,
    });

    return new Response(JSON.stringify({ ok: true, recipients, cc, subject: finalSubject }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e: any) {
    const errMsg = e?.message ?? String(e);
    try {
      await supabase.from("email_send_log").insert({
        template_key: "untreated_order_decision", recipient: "(error)", status: "failed", error: errMsg,
      });
    } catch (_) { /* ignore */ }
    return new Response(JSON.stringify({ error: errMsg }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

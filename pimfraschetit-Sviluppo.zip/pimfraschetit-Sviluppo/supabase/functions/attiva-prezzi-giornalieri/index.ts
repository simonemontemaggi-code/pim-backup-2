// Daily cron: imposta wvaef='S' sui prezzi_in_attesa con wdtin = oggi (AAAAMMGG).
// Triggera ogni mattina alle 05:00 (Europe/Rome) tramite pg_cron.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

function todayAs400(): string {
  // Use Europe/Rome local date so the rollover at 05:00 matches user expectation
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Rome",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
  const parts = fmt.formatToParts(new Date());
  const y = parts.find((p) => p.type === "year")!.value;
  const m = parts.find((p) => p.type === "month")!.value;
  const d = parts.find((p) => p.type === "day")!.value;
  return `${y}${m}${d}`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const oggi = todayAs400();
    console.log(`[attiva-prezzi] Esecuzione per data ${oggi}`);

    // 1. Aggiorna wvaef='S' per tutti i record che entrano in vigore oggi
    const { data: updated, error: upErr } = await supabase
      .from("prezzi_in_attesa")
      .update({ wvaef: "S" })
      .eq("wdtin", oggi)
      .neq("wvaef", "S")
      .select("id, wcdpa, wcdls, wprun, wdtin");

    if (upErr) throw upErr;

    const count = updated?.length ?? 0;
    console.log(`[attiva-prezzi] Aggiornati ${count} record a wvaef='S'`);

    // 2. Flag articoli per resync AS400
    if (count > 0) {
      const cdparList = Array.from(new Set(updated!.map((r: any) => r.wcdpa)));
      await supabase
        .from("archivio_articoli_fraschetti")
        .update({
          as400_sync_status: "modified",
          updated_at: new Date().toISOString(),
        })
        .in("cdpar", cdparList);
    }

    return new Response(
      JSON.stringify({
        success: true,
        date: oggi,
        activated: count,
        records: updated ?? [],
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (e) {
    console.error("[attiva-prezzi] Errore:", e);
    return new Response(
      JSON.stringify({ success: false, error: (e as Error).message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});

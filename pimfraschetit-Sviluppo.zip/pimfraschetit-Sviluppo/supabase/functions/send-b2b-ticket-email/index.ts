// deno-lint-ignore-file no-explicit-any
import { createClient } from "npm:@supabase/supabase-js@2";
import { SMTPClient } from "https://deno.land/x/denomailer@1.6.0/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SMTP_HOST = "pro.turbo-smtp.com";
const SMTP_PORT = 465;
const SMTP_USER = "6c018dcf57";
const FROM_EMAIL = "ordini@fraschetti.com";
const FROM_NAME = "Ticket B2B Fraschetti";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const SMTP_PASSWORD = Deno.env.get("SMTP_PASSWORD") ?? "";

const PIM_BASE = "https://pim.fraschetti.com";

const CATEGORY_LABELS: Record<string, string> = {
  ordini: "Ordini",
  contabile: "Amministrazione",
  tecnico: "Supporto tecnico",
  commerciale: "Commerciale",
  annullamento_ordine: "Annullamento ordine",
  post_vendita: "Assistenza Post Vendita",
  portale: "Assistenza Portale",
  altro: "Altro",
};

function esc(s: any) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!),
  );
}
function fmtDate(s: string | null | undefined) {
  if (!s) return "-";
  try {
    return new Date(s).toLocaleString("it-IT", { dateStyle: "short", timeStyle: "short", timeZone: "Europe/Rome" });
  } catch { return s; }
}
function render(template: string, data: Record<string, string>) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, k) => data[k] ?? "");
}
function encodeSubject(s: string): string {
  return s
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[^\x20-\x7E]/g, "?");
}
function parseList(raw: any): string[] {
  const str = typeof raw === "string" ? raw : (raw ? JSON.stringify(raw) : "");
  return str
    .replace(/^"|"$/g, "")
    .split(/[,;\s]+/)
    .map((s: string) => s.trim())
    .filter((s: string) => s.includes("@"));
}

function formatCancellationMessage(raw: string): string {
  if (!raw || !raw.includes("Righe da annullare:")) return "";
  const [head, rest] = raw.split(/Righe da annullare:\s*/);
  let body = rest ?? "";

  // Estrai code di totali finali
  const trailers: string[] = [];
  const trailerRegex = /(Totale righe selezionate:[^A-Z]*?)(?=\s+(?:Numero righe:|Motivo:)|$)|(Numero righe:\s*\d+)|(Motivo:\s*.*)$/g;
  // Approccio più semplice: taglia manualmente
  const cutMarkers = ["Totale righe selezionate:", "Numero righe:", "Motivo:"];
  let firstIdx = -1;
  for (const m of cutMarkers) {
    const i = body.indexOf(m);
    if (i >= 0 && (firstIdx < 0 || i < firstIdx)) firstIdx = i;
  }
  let tail = "";
  if (firstIdx >= 0) {
    tail = body.slice(firstIdx).trim();
    body = body.slice(0, firstIdx).trim();
  }

  // Split righe articolo: separatore " - " prima di un codice numerico
  const parts = body.split(/\s+-\s+(?=\d{4,6}\s+—)/);
  const items: string[] = [];
  for (let p of parts) {
    p = p.trim().replace(/^-\s+/, "");
    if (!p) continue;
    const m = p.match(/^(\d{4,6})\s+—\s+(.+?)\s+—\s+Qtà:\s*(\d+)\s+—\s+Prezzo:\s*(.+?)\s*€?\s*$/);
    if (m) {
      items.push(
        `<li style="margin:4px 0;line-height:1.4"><strong>${esc(m[1])}</strong> — ${esc(m[2])} — <em>Qtà:</em> ${esc(m[3])} — <em>Prezzo:</em> ${esc(m[4])} €</li>`,
      );
    } else {
      items.push(`<li style="margin:4px 0;line-height:1.4">${esc(p)}</li>`);
    }
  }

  const trailerLines: string[] = [];
  if (tail) {
    // Splitta tail sui marker
    const re = /(Totale righe selezionate:|Numero righe:|Motivo:)/g;
    const idxs: { key: string; pos: number }[] = [];
    let mm: RegExpExecArray | null;
    while ((mm = re.exec(tail)) !== null) idxs.push({ key: mm[1], pos: mm.index });
    for (let i = 0; i < idxs.length; i++) {
      const start = idxs[i].pos;
      const end = i + 1 < idxs.length ? idxs[i + 1].pos : tail.length;
      const seg = tail.slice(start, end).trim();
      const [k, ...v] = seg.split(":");
      trailerLines.push(
        `<div style="margin:2px 0"><strong>${esc(k)}:</strong> ${esc(v.join(":").trim())}</div>`,
      );
    }
  }

  return [
    `<div style="margin-bottom:12px">${esc(head.trim())}</div>`,
    items.length
      ? `<div style="margin:8px 0 4px 0"><strong>Righe da annullare:</strong></div><ul style="margin:0 0 12px 20px;padding:0">${items.join("")}</ul>`
      : "",
    trailerLines.length
      ? `<div style="margin-top:8px;padding-top:8px;border-top:1px solid #ddd">${trailerLines.join("")}</div>`
      : "",
  ].join("");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);
  let templateKey = "b2b_ticket_unknown";

  try {
    const body = await req.json().catch(() => ({}));
    const { ticket_id, test, override_email, template_override } = body ?? {};

    if (!ticket_id) {
      return new Response(JSON.stringify({ error: "ticket_id required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: ticket, error: tErr } = await supabase
      .from("customer_support_tickets")
      .select("*")
      .eq("id", ticket_id)
      .maybeSingle();
    if (tErr || !ticket) throw new Error(`Ticket non trovato: ${tErr?.message ?? ticket_id}`);

    const category = String(ticket.category ?? "altro");
    templateKey = `b2b_ticket_${category}`;
    const settingKey = `email_recipients_b2b_ticket_${category}`;

    // Resolve customer info (code + company + agent) — the ticket only stores customer_id
    let customerCode = "—";
    let companyName = "—";
    let assignedAgentId: string | null = null;
    let originalAgentCode: string | null = null;
    if (ticket.customer_id) {
      const { data: cust } = await supabase
        .from("customers")
        .select("customer_code, company_name, assigned_agent_id, original_agent_code")
        .eq("id", ticket.customer_id)
        .maybeSingle();
      if (cust) {
        customerCode = cust.customer_code ?? "—";
        companyName = cust.company_name ?? "—";
        assignedAgentId = (cust as any).assigned_agent_id ?? null;
        originalAgentCode = (cust as any).original_agent_code ?? null;
      }
    }

    // CC agente per categoria annullamento_ordine
    const ccList: string[] = [];
    if (category === "annullamento_ordine" && !override_email) {
      let agentEmail: string | null = null;
      if (assignedAgentId) {
        const { data: prof } = await supabase
          .from("profiles")
          .select("email")
          .eq("id", assignedAgentId)
          .maybeSingle();
        if (prof?.email && String(prof.email).includes("@")) agentEmail = prof.email;
      }
      if (!agentEmail && originalAgentCode) {
        const { data: prof } = await supabase
          .from("profiles")
          .select("email")
          .eq("agent_code", originalAgentCode)
          .not("email", "is", null)
          .limit(1)
          .maybeSingle();
        if (prof?.email && String(prof.email).includes("@")) agentEmail = prof.email;
      }
      if (agentEmail) ccList.push(agentEmail);
    }

    // Recipients
    let recipients: string[] = [];
    if (override_email) {
      recipients = [override_email];
    } else {
      const { data: setting } = await supabase
        .from("app_settings")
        .select("setting_value")
        .eq("setting_key", settingKey)
        .maybeSingle();
      recipients = parseList(setting?.setting_value);
    }

    if (recipients.length === 0) {
      await supabase.from("email_send_log").insert({
        template_key: templateKey, recipient: "(none)", status: "skipped",
        error: `Nessun destinatario per ${settingKey}`, is_test: !!test,
      });
      return new Response(JSON.stringify({ skipped: "no_recipients" }), {
        status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Template (con override opzionale per test)
    let subject: string;
    let body_html: string;
    if (template_override?.subject && template_override?.body_html) {
      subject = template_override.subject;
      body_html = template_override.body_html;
    } else {
      const { data: tpl } = await supabase
        .from("email_templates")
        .select("subject,body_html,enabled")
        .eq("key", templateKey)
        .maybeSingle();
      if (!tpl) throw new Error(`Template ${templateKey} non trovato`);
      if (!tpl.enabled && !test) {
        return new Response(JSON.stringify({ skipped: "template_disabled" }), {
          status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      subject = tpl.subject;
      body_html = tpl.body_html;
    }

    const data: Record<string, string> = {
      categoria: CATEGORY_LABELS[category] ?? category,
      oggetto: ticket.subject ?? "—",
      messaggio: ticket.message ?? "—",
      codice_cliente: customerCode,
      ragione_sociale: companyName,
      email_contatto: ticket.contact_email ?? "—",
      data_invio: fmtDate(ticket.created_at),
      link_pim: `${PIM_BASE}/pim/b2b/tickets`,
    };
    const dataHtml: Record<string, string> = {};
    for (const k of Object.keys(data)) dataHtml[k] = esc(data[k]);

    // Categoria annullamento_ordine: il messaggio arriva come blob piatto,
    // riformattalo in HTML con una riga per articolo (bypass esc su questo campo).
    if (category === "annullamento_ordine" && ticket.message && String(ticket.message).includes("Righe da annullare:")) {
      const formatted = formatCancellationMessage(String(ticket.message));
      if (formatted) dataHtml.messaggio = formatted;
    }

    const finalSubject = render(subject, data);
    const finalHtml = render(body_html, dataHtml);

    const client = new SMTPClient({
      connection: {
        hostname: SMTP_HOST, port: SMTP_PORT, tls: true,
        auth: { username: SMTP_USER, password: SMTP_PASSWORD },
      },
    });
    const finalCc = ccList.filter((e) => !recipients.includes(e));
    await client.send({
      from: `${FROM_NAME} <${FROM_EMAIL}>`,
      to: recipients,
      cc: finalCc.length ? finalCc : undefined,
      subject: encodeSubject(finalSubject),
      content: "auto",
      html: finalHtml,
    });
    await client.close();

    await supabase.from("email_send_log").insert({
      template_key: templateKey,
      recipient: finalCc.length
        ? `${recipients.join(", ")} | cc: ${finalCc.join(", ")}`
        : recipients.join(", "),
      subject: finalSubject,
      status: "sent",
      is_test: !!test,
    });

    return new Response(JSON.stringify({ ok: true, recipients }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e: any) {
    const errMsg = e?.message ?? String(e);
    try {
      await supabase.from("email_send_log").insert({
        template_key: templateKey, recipient: "(error)", status: "failed", error: errMsg,
      });
    } catch (_) { /* ignore */ }
    return new Response(JSON.stringify({ error: errMsg }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

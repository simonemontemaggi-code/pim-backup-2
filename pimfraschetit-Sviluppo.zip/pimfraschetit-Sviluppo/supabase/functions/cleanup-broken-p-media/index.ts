import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const body = req.method === "POST" ? await req.json().catch(() => ({})) : {};
    const batchSize = Math.min(Number(body.batchSize) || 500, 1000);

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceKey);

    // 1) Fetch storage paths to delete via direct REST to PostgREST on storage schema
    // Use raw fetch to query storage.objects through PostgREST? Not exposed.
    // Solution: use the admin API SQL endpoint via pg-meta? Not available.
    // Workaround: call a SECURITY DEFINER RPC we create, OR use direct SQL via
    // the management Database endpoint. Simplest: use a SQL query through
    // the postgrest "rpc" by creating a function. Here we use the new
    // supabase.rpc('list_broken_p_paths').
    const { data: rows, error: rpcError } = await supabase.rpc("list_broken_p_paths", {
      p_limit: batchSize,
    });
    if (rpcError) throw rpcError;

    const paths: string[] = (rows ?? []).map((r: any) => r.name).filter(Boolean);

    let deletedStorage = 0;
    for (let i = 0; i < paths.length; i += 100) {
      const batch = paths.slice(i, i + 100);
      const { error } = await supabase.storage.from("pim-media").remove(batch);
      if (error) throw error;
      deletedStorage += batch.length;
    }

    // 2) Delete matching article_media rows (by storage_path or P% filename)
    const { data: amRows, error: amErr } = await supabase
      .from("article_media")
      .select("id")
      .like("original_filename", "P%")
      .limit(batchSize);
    if (amErr) throw amErr;

    const ids = (amRows ?? []).map((r: any) => r.id);
    let deletedArticleMedia = 0;
    if (ids.length > 0) {
      const { error: delErr } = await supabase.from("article_media").delete().in("id", ids);
      if (delErr) throw delErr;
      deletedArticleMedia = ids.length;
    }

    return new Response(
      JSON.stringify({
        success: true,
        deletedStorage,
        deletedArticleMedia,
        hasMore: paths.length === batchSize || ids.length === batchSize,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 },
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : JSON.stringify(err);
    console.error("cleanup-broken-p-media", msg);
    return new Response(JSON.stringify({ error: msg }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});

// Sync supplier differenziale cambio to AS400 via SFTP relay
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface Payload {
  wcdfo: string;        // codice fornitore (padded)
  wan02: string;        // "A" se cancellazione, "" altrimenti
  wcacq: string;        // "Â§DC" se attivo, "" se cancellato
  wscfa: number;        // sconto/maggiorazione (intero, può essere negativo)
  wdacq: string;        // descrizione
  // wcdva NON viene trasmesso (è gestito sul fornitore)
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: authErr } = await supabase.auth.getClaims(token);
    if (authErr || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = (await req.json()) as Payload;
    if (!body.wcdfo) {
      return new Response(JSON.stringify({ error: "wcdfo required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const sftpUrl = Deno.env.get("SFTP_RELAY_URL");
    const sftpKey = Deno.env.get("SFTP_RELAY_API_KEY");

    const payload = {
      table: "differenziale_cambio",
      operation: body.wan02 === "A" ? "delete" : "upsert",
      record: {
        wcdfo: body.wcdfo,
        wan02: body.wan02 || "",
        wcacq: body.wcacq || "",
        wscfa: body.wscfa ?? 0,
        wdacq: body.wdacq || "",
      },
      user_email: claimsData.claims.email,
      timestamp: new Date().toISOString(),
    };

    if (!sftpUrl || !sftpKey) {
      // Log only — relay not configured
      console.log("[sync-supplier-differential] relay not configured, payload:", JSON.stringify(payload));
      return new Response(JSON.stringify({ ok: true, transmitted: false, payload }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const r = await fetch(sftpUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": sftpKey },
      body: JSON.stringify(payload),
    });
    const text = await r.text();

    return new Response(JSON.stringify({ ok: r.ok, status: r.status, response: text }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: r.ok ? 200 : 502,
    });
  } catch (e) {
    console.error("[sync-supplier-differential] error", e);
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

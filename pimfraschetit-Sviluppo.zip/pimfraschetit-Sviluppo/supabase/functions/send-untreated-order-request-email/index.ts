// deno-lint-ignore-file no-explicit-any
import { createClient } from "npm:@supabase/supabase-js@2";
import { SMTPClient } from "https://deno.land/x/denomailer@1.6.0/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SMTP_HOST = "pro.turbo-smtp.com";
const SMTP_PORT = 465;
const SMTP_USER = "6c018dcf57";
const FROM_EMAIL = "ordini@fraschetti.com";
const FROM_NAME = "Ordini non trattati Fraschetti";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const SMTP_PASSWORD = Deno.env.get("SMTP_PASSWORD") ?? "";

const PIM_BASE = "https://pim.fraschetti.com";
const TEMPLATE_KEY = "untreated_order_request_office";

function esc(s: any) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!),
  );
}
function fmtDate(s: string | null | undefined) {
  if (!s) return "-";
  try {
    return new Date(s).toLocaleString("it-IT", { dateStyle: "short", timeStyle: "short", timeZone: "Europe/Rome" });
  } catch { return s; }
}
function render(template: string, data: Record<string, string>) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, k) => data[k] ?? "");
}
function encodeSubject(s: string): string {
  return s
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[^\x20-\x7E]/g, "?");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const body = await req.json().catch(() => ({}));
    const { request_id, test, override_email, template_override, internal } = body ?? {};

    if (!request_id) {
      return new Response(JSON.stringify({ error: "request_id required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);

    // Load request
    const { data: row, error: rowErr } = await supabase
      .from("richieste_ordini_non_trattati")
      .select("*")
      .eq("id", request_id)
      .maybeSingle();
    if (rowErr || !row) throw new Error(`Richiesta non trovata: ${rowErr?.message ?? request_id}`);

    // Destinatari da app_settings (con override per test)
    let recipients: string[] = [];
    let cc: string[] = [];
    const parseList = (raw: any): string[] => {
      const str = typeof raw === "string" ? raw : (raw ? JSON.stringify(raw) : "");
      return str
        .replace(/^"|"$/g, "")
        .split(/[,;\s]+/)
        .map((s: string) => s.trim())
        .filter((s: string) => s.includes("@"));
    };
    if (override_email) {
      recipients = [override_email];
    } else {
      const { data: setting } = await supabase
        .from("app_settings")
        .select("setting_value")
        .eq("setting_key", "email_recipients_untreated_orders")
        .maybeSingle();
      recipients = parseList(setting?.setting_value);

      const { data: ccSetting } = await supabase
        .from("app_settings")
        .select("setting_value")
        .eq("setting_key", "email_cc_untreated_orders")
        .maybeSingle();
      cc = parseList(ccSetting?.setting_value);
    }

    if (recipients.length === 0) {
      const errMsg = "Nessun destinatario configurato in Admin → Impostazioni (email_recipients_untreated_orders)";
      await supabase.from("email_send_log").insert({
        template_key: TEMPLATE_KEY, recipient: "(none)", status: "failed", error: errMsg, is_test: !!test,
      });
      return new Response(JSON.stringify({ error: errMsg }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Template
    let subject: string;
    let body_html: string;
    if (template_override?.subject && template_override?.body_html) {
      subject = template_override.subject;
      body_html = template_override.body_html;
    } else {
      const { data: tpl } = await supabase
        .from("email_templates")
        .select("subject,body_html,enabled")
        .eq("key", TEMPLATE_KEY)
        .maybeSingle();
      if (!tpl) throw new Error(`Template ${TEMPLATE_KEY} non trovato`);
      if (!tpl.enabled && !test) {
        return new Response(JSON.stringify({ skipped: "template_disabled" }), {
          status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      subject = tpl.subject;
      body_html = tpl.body_html;
    }

    const agenteNomeCompleto = [row.agente_cognome, row.agente_nome].filter(Boolean).join(" ") || "—";

    const data: Record<string, string> = {
      fornitore: row.fornitore ?? "—",
      codice_articolo_fornitore: row.codice_articolo_fornitore ?? "—",
      descrizione: row.descrizione ?? "—",
      quantita: String(row.quantita ?? ""),
      nota: row.nota ?? "—",
      cliente_codice: row.cliente_codice ?? "—",
      cliente_nominativo: row.cliente_nominativo ?? "—",
      agente_codice: row.agente_codice ?? "—",
      agente_nome_completo: agenteNomeCompleto,
      data_richiesta: fmtDate(row.created_at),
      link_pim: `${PIM_BASE}/pim/sales/untreated`,
    };
    // Escape tutti i valori (HTML)
    for (const k of Object.keys(data)) data[k] = esc(data[k]);

    const finalSubject = render(subject, {
      ...data,
      // Subject senza HTML escaping doppio nel display
      fornitore: row.fornitore ?? "—",
      cliente_nominativo: row.cliente_nominativo ?? "—",
    });
    const finalHtml = render(body_html, data);

    const client = new SMTPClient({
      connection: {
        hostname: SMTP_HOST,
        port: SMTP_PORT,
        tls: true,
        auth: { username: SMTP_USER, password: SMTP_PASSWORD },
      },
    });

    await client.send({
      from: `${FROM_NAME} <${FROM_EMAIL}>`,
      to: recipients,
      ...(cc.length && !override_email ? { cc } : {}),
      subject: encodeSubject(finalSubject),
      content: "auto",
      html: finalHtml,
    });
    await client.close();

    await supabase.from("email_send_log").insert({
      template_key: TEMPLATE_KEY,
      recipient: recipients.join(", ") + (cc.length ? ` (cc: ${cc.join(", ")})` : ""),
      subject: finalSubject,
      status: "sent",
      is_test: !!test,
    });

    return new Response(JSON.stringify({ ok: true, recipients, cc, internal: !!internal }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e: any) {
    const errMsg = e?.message ?? String(e);
    try {
      const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);
      await supabase.from("email_send_log").insert({
        template_key: TEMPLATE_KEY, recipient: "(error)", status: "failed", error: errMsg,
      });
    } catch (_) { /* ignore */ }
    return new Response(JSON.stringify({ error: errMsg }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

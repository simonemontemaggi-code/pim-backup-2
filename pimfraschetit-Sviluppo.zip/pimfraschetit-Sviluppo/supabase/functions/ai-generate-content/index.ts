// Edge function: AI content generation via OpenRouter
// Genera contenuti marketing B2B per articoli del catalogo Fraschetti
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";

type FieldKey =
  | "all"
  | "title"
  | "description"
  | "short_description"
  | "seo_title"
  | "seo_description"
  | "tags";

const FIELD_TO_PROMPT_KEY: Record<FieldKey, string> = {
  all: "generate_all",
  title: "title",
  description: "description",
  short_description: "short_description",
  seo_title: "seo_title",
  seo_description: "seo_description",
  tags: "tags",
};

function renderTemplate(tpl: string, vars: Record<string, unknown>): string {
  return tpl.replace(/\{\{\s*(\w+)\s*\}\}/g, (_, k) => {
    const v = vars[k];
    if (v === null || v === undefined) return "";
    if (typeof v === "object") return JSON.stringify(v);
    return String(v);
  });
}

function jsonResp(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function stripNoise(text: string): string {
  return text
    .replace(/<think>[\s\S]*?<\/think>/gi, "")
    .trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();
}

function extractBalancedJson(text: string, open: string, close: string): unknown[] {
  const out: unknown[] = [];
  for (let i = 0; i < text.length; i++) {
    if (text[i] !== open) continue;
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let j = i; j < text.length; j++) {
      const ch = text[j];
      if (escaped) {
        escaped = false;
        continue;
      }
      if (ch === "\\") {
        escaped = true;
        continue;
      }
      if (ch === '"') inString = !inString;
      if (inString) continue;
      if (ch === open) depth++;
      if (ch === close) depth--;
      if (depth === 0) {
        try {
          out.push(JSON.parse(text.slice(i, j + 1)));
        } catch { /* ignore invalid fragments */ }
        i = j;
        break;
      }
    }
  }
  return out;
}

function normalizeTag(value: unknown): string | null {
  if (typeof value !== "string" && typeof value !== "number") return null;
  const tag = String(value)
    .toLowerCase()
    .normalize("NFKC")
    .replace(/[\[\]{}"'`]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  if (tag.length < 3 || tag.length > 40) return null;
  if (/^tag\s*\d*$/i.test(tag) || tag === "esempio") return null;
  return tag;
}

function sanitizeTags(value: unknown): string[] {
  const source = Array.isArray(value)
    ? value
    : value && typeof value === "object" && Array.isArray((value as { tags?: unknown }).tags)
      ? (value as { tags: unknown[] }).tags
      : [];
  return Array.from(new Set(source.map(normalizeTag).filter((tag): tag is string => Boolean(tag)))).slice(0, 8);
}

function parseTagsFromText(...texts: string[]): string[] {
  for (const raw of texts) {
    const cleaned = stripNoise(raw ?? "");
    if (!cleaned) continue;
    try {
      const direct = sanitizeTags(JSON.parse(cleaned));
      if (direct.length) return direct;
    } catch { /* try fragments */ }
    const fragments = [
      ...extractBalancedJson(cleaned, "[", "]"),
      ...extractBalancedJson(cleaned, "{", "}"),
    ].reverse();
    for (const fragment of fragments) {
      const tags = sanitizeTags(fragment);
      if (tags.length) return tags;
    }
  }
  return [];
}

function extractMessageText(choice: Record<string, unknown> | null | undefined): string {
  const content = typeof choice?.content === "string" ? choice.content : "";
  if (content.trim()) return stripNoise(content);
  const reasoning = typeof choice?.reasoning === "string" ? choice.reasoning : "";
  return stripNoise(reasoning);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const startedAt = Date.now();

  try {
    const OPENROUTER_API_KEY = Deno.env.get("OPENROUTER_API_KEY");
    if (!OPENROUTER_API_KEY) {
      return jsonResp({ error: "OPENROUTER_API_KEY non configurata" }, 500);
    }

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Auth
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return jsonResp({ error: "Unauthorized" }, 401);
    }
    const userClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });
    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userErr } = await userClient.auth.getUser(token);
    if (userErr || !userData?.user) return jsonResp({ error: "Unauthorized" }, 401);
    const userId = userData.user.id;
    const userEmail = userData.user.email ?? null;

    // Parse body
    const body = await req.json().catch(() => null);
    if (!body || typeof body !== "object") return jsonResp({ error: "Invalid body" }, 400);
    const cdpar = String(body.cdpar ?? "").trim();
    const field = String(body.field ?? "all") as FieldKey;
    if (!cdpar) return jsonResp({ error: "cdpar mancante" }, 400);
    if (!(field in FIELD_TO_PROMPT_KEY)) return jsonResp({ error: "field non valido" }, 400);

    const promptKey = FIELD_TO_PROMPT_KEY[field];

    // Service-role client per leggere prompt e articolo bypassando RLS dove serve
    const adminClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Carica prompt
    const { data: prompt, error: promptErr } = await adminClient
      .from("ai_prompts")
      .select("*")
      .eq("key", promptKey)
      .eq("is_active", true)
      .maybeSingle();
    if (promptErr || !prompt) {
      return jsonResp({ error: `Prompt '${promptKey}' non trovato o disattivato` }, 404);
    }

    // Carica articolo (campi rilevanti per il prompt)
    const { data: article, error: articleErr } = await adminClient
      .from("archivio_articoli_fraschetti")
      .select("cdpar,depar,clmer,clas2,lipro,nmcat,wfuas,attributes")
      .eq("cdpar", cdpar.padEnd(15, " "))
      .maybeSingle();
    if (articleErr || !article) {
      return jsonResp({ error: `Articolo ${cdpar} non trovato` }, 404);
    }

    const vars = {
      cdpar: (article.cdpar as string).trim(),
      depar: article.depar ?? "",
      clmer: article.clmer ?? "",
      clas2: article.clas2 ?? "",
      lipro: article.lipro ?? "",
      nmcat: article.nmcat ?? "",
      wfuas: article.wfuas ?? "",
      attributes: article.attributes ?? {},
    };

    const userMsg = renderTemplate(prompt.user_prompt_template, vars);

    let apiUrl = OPENROUTER_URL;
    let apiKey = OPENROUTER_API_KEY;
    let providerLabel = "OpenRouter";
    let modelUsed = prompt.model as string;

    const orPayload: Record<string, unknown> = {
      model: prompt.model,
      messages: [
        { role: "system", content: prompt.system_prompt },
        { role: "user", content: userMsg },
      ],
      temperature: Number(prompt.temperature ?? 0.7),
      max_tokens: Number(prompt.max_tokens ?? 1500),
    };

    if (promptKey === "generate_all" || promptKey === "tags") {
      orPayload.response_format = { type: "json_object" };
    }

    const orResp = await fetch(apiUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://pimfraschetit.lovable.app",
        "X-Title": "Fraschetti PIM",
      },
      body: JSON.stringify(orPayload),
    });

    const durationMs = Date.now() - startedAt;
    const orJson = await orResp.json().catch(() => null);

    if (!orResp.ok) {
      const errMsg =
        orJson?.error?.message ?? orJson?.error ?? `${providerLabel} error ${orResp.status}`;
      await adminClient.from("ai_generations").insert({
        cdpar: vars.cdpar,
        prompt_key: promptKey,
        field,
        model: modelUsed,
        input_payload: { vars, user_message: userMsg, provider: providerLabel },
        status: orResp.status === 429 ? "rate_limited" : "error",
        error_message: typeof errMsg === "string" ? errMsg : JSON.stringify(errMsg),
        duration_ms: durationMs,
        user_id: userId,
        user_email: userEmail,
      });
      const userFacing =
        orResp.status === 429
          ? `Limite richieste raggiunto su '${modelUsed}'. Riprova tra 30s.`
          : orResp.status === 402
          ? `Crediti esauriti su ${providerLabel} (modello '${modelUsed}'). Aggiungi crediti o cambia modello.`
          : orResp.status === 401
          ? `Chiave ${providerLabel} non valida.`
          : `Errore AI su '${modelUsed}': ${typeof errMsg === "string" ? errMsg : "imprevisto"}`;
      return jsonResp({ error: userFacing }, orResp.status);
    }

    const choice = orJson?.choices?.[0]?.message as Record<string, unknown> | undefined;
    let outputText = extractMessageText(choice);
    const usage = orJson?.usage ?? {};

    let outputParsed: unknown = null;
    if (promptKey === "generate_all") {
      try {
        const cleaned = outputText.trim().replace(/^```(?:json)?\s*|\s*```$/g, "");
        outputParsed = JSON.parse(cleaned);
        if (outputParsed && typeof outputParsed === "object" && !Array.isArray(outputParsed)) {
          const parsedObj = outputParsed as Record<string, unknown>;
          parsedObj.tags = sanitizeTags(parsedObj.tags);
          outputText = JSON.stringify(parsedObj);
        }
      } catch (e) {
        console.error("Failed to parse generate_all JSON:", e, outputText);
        outputParsed = null;
      }
    } else if (promptKey === "tags") {
      let tags: string[] = [];
      const toolCalls = (choice?.tool_calls as Array<Record<string, unknown>> | undefined) ?? [];
      for (const tc of toolCalls) {
        const fn = tc?.function as { arguments?: string } | undefined;
        if (!fn?.arguments) continue;
        try {
          const parsed = JSON.parse(fn.arguments);
          tags = sanitizeTags(parsed);
          if (tags.length) break;
        } catch { /* ignore */ }
      }
      if (!tags.length) {
        const content = typeof choice?.content === "string" ? choice.content : "";
        const reasoning = typeof choice?.reasoning === "string" ? choice.reasoning : "";
        tags = parseTagsFromText(content, outputText, reasoning);
      }
      outputParsed = tags;
      outputText = JSON.stringify(tags);
    }

    // Log success
    const { data: logRow } = await adminClient
      .from("ai_generations")
      .insert({
        cdpar: vars.cdpar,
        prompt_key: promptKey,
        field,
        model: modelUsed,
        input_payload: { vars, user_message: userMsg, provider: providerLabel },
        output_text: outputText,
        output_parsed: outputParsed as never,
        status: "success",
        tokens_prompt: usage.prompt_tokens ?? null,
        tokens_completion: usage.completion_tokens ?? null,
        duration_ms: durationMs,
        user_id: userId,
        user_email: userEmail,
      })
      .select("id")
      .single();

    return jsonResp({
      generation_id: logRow?.id ?? null,
      field,
      prompt_key: promptKey,
      model: modelUsed,
      output_text: outputText,
      output_parsed: outputParsed,
      tokens: {
        prompt: usage.prompt_tokens ?? null,
        completion: usage.completion_tokens ?? null,
        total: usage.total_tokens ?? null,
      },
      duration_ms: durationMs,
    });
  } catch (e) {
    console.error("ai-generate-content error:", e);
    return jsonResp(
      { error: e instanceof Error ? e.message : "Errore imprevisto" },
      500,
    );
  }
});

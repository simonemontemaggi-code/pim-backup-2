import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json({ error: "Non autorizzato" }, 401);

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const admin = createClient(supabaseUrl, serviceKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: authErr } = await userClient.auth.getClaims(token);
    const callerId = claimsData?.claims?.sub;
    if (authErr || !callerId) return json({ error: "Non autorizzato" }, 401);

    const { data: roleRow } = await admin
      .from("user_roles")
      .select("role")
      .eq("user_id", callerId)
      .maybeSingle();
    if (roleRow?.role !== "admin") return json({ error: "Solo admin può creare utenti" }, 403);

    const body = await req.json().catch(() => null);
    const email = String(body?.email ?? "").trim().toLowerCase();
    const password = String(body?.password ?? "");
    const full_name = String(body?.full_name ?? "").trim();
    const department_id = body?.department_id ? String(body.department_id) : null;
    const role = String(body?.role ?? "viewer");

    if (!email || !password) return json({ error: "email e password obbligatori" }, 400);
    if (password.length < 6) return json({ error: "Password troppo corta (min 6)" }, 400);
    if (!["admin", "manager", "collaborator", "viewer"].includes(role))
      return json({ error: "Ruolo non valido" }, 400);

    const { data: created, error: createErr } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name },
    });
    if (createErr || !created?.user) return json({ error: createErr?.message ?? "Errore creazione" }, 400);

    const newUserId = created.user.id;

    // profile
    await admin.from("profiles").upsert({
      user_id: newUserId,
      email,
      full_name: full_name || null,
      department_id,
    } as any, { onConflict: "user_id" });

    // role
    await admin.from("user_roles").upsert({ user_id: newUserId, role } as any, { onConflict: "user_id,role" });

    // department
    if (department_id) {
      await admin.from("user_departments").insert({
        user_id: newUserId,
        department_id,
        is_primary: true,
      } as any);
    }

    return json({ ok: true, user_id: newUserId });
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : String(e) }, 500);
  }
});

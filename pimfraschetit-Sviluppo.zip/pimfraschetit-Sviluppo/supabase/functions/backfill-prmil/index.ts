// Backfill prmil per i listini governati da criterio.
// Chiama in loop la RPC backfill_prmil_chunk(listino, limit) finché restituisce 0.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const LISTINI = ["01","02","03","04","05","06","07","10","11","12","20","51","71","A1","A2","A3","A4","A5","A6","A7","B0","B1","B2","C0","F1","H1"];
const CHUNK = 1500;
const MAX_MS = 50_000; // chiudi prima del timeout edge (60s)

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  const url = new URL(req.url);
  const targetListino = url.searchParams.get("listino");
  const list = targetListino ? [targetListino] : LISTINI;

  const started = Date.now();
  const stats: Record<string, { calls: number; updated: number; done: boolean }> = {};

  for (const lst of list) {
    stats[lst] = { calls: 0, updated: 0, done: false };
    while (Date.now() - started < MAX_MS) {
      const { data, error } = await supabase.rpc("backfill_prmil_chunk", {
        _listino: lst,
        _limit: CHUNK,
      });
      if (error) {
        return new Response(
          JSON.stringify({ error: error.message, listino: lst, stats }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      const updated = Number(data ?? 0);
      stats[lst].calls += 1;
      stats[lst].updated += updated;
      // Se updated < CHUNK e nessuna riga pendente, finito
      if (updated === 0) {
        stats[lst].done = true;
        break;
      }
    }
    if (Date.now() - started >= MAX_MS) break;
  }

  const allDone = Object.values(stats).every((s) => s.done);
  const elapsed = Date.now() - started;

  // Self-reinvoke fire-and-forget se ci sono ancora listini non completati.
  // Pattern chunking: ogni run lavora MAX_MS e richiama se stessa finché finisce.
  if (!allDone) {
    const auth = req.headers.get("Authorization") ?? "";
    // Non aspettiamo la risposta: lasciamo che Deno gestisca la chiamata in background.
    queueMicrotask(() => {
      fetch(req.url, {
        method: "POST",
        headers: auth ? { Authorization: auth } : {},
      }).catch((e) => console.error("[backfill-prmil] self-reinvoke failed", e));
    });
  }

  return new Response(
    JSON.stringify({ ok: true, all_done: allDone, elapsed_ms: elapsed, stats }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } },
  );
});


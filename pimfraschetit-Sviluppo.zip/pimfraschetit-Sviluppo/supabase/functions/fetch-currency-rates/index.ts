import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

// Map internal AS400 currency codes → ISO 4217 (when applicable)
const CODE_TO_ISO: Record<string, string> = {
  USD: "USD", "DOL": "USD", "DOL$": "USD", "DOLL": "USD", "DOLA": "USD",
  GBP: "GBP", STE: "GBP", LIRL: "GBP",
  CHF: "CHF", FSVI: "CHF",
  JPY: "JPY", YEN: "JPY",
  CNY: "CNY", YUAN: "CNY",
  CAD: "CAD", DOC: "CAD",
  AUD: "AUD",
  HKD: "HKD", DHK: "HKD",
  INR: "INR", RS: "INR",
  SEK: "SEK", SCE: "SEK",
  NOK: "NOK",
  DKK: "DKK",
  PLN: "PLN",
  CZK: "CZK",
  HUF: "HUF",
  TRY: "TRY",
  MXN: "MXN", PES: "MXN",
  BRL: "BRL",
  ZAR: "ZAR",
  KRW: "KRW", COS: "KRW",
  SGD: "SGD",
  THB: "THB",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // 1) Distinct cdval present in tassi_di_cambio (excluding EURO and CDAN reference)
    const { data: tassi, error: tErr } = await supabase
      .from("tassi_di_cambio")
      .select("cdval,cdva2,cambi,dtval")
      .order("dtval", { ascending: false });
    if (tErr) throw tErr;

    // Latest as400 rate per cdval (toward EURO)
    const as400Map: Record<string, number> = {};
    (tassi ?? []).forEach((t: any) => {
      const from = String(t.cdval ?? "").trim().toUpperCase();
      const to = String(t.cdva2 ?? "").trim().toUpperCase();
      if (!from || from === "EURO" || from === "EUR") return;
      if (to && to !== "EURO" && to !== "EUR") return;
      if (!(from in as400Map)) as400Map[from] = Number(t.cambi) || 0;
    });

    // 2) Build ISO list to query Frankfurter
    const isoSet = new Set<string>();
    const internalToIso: Record<string, string> = {};
    Object.keys(as400Map).forEach((code) => {
      const iso = CODE_TO_ISO[code];
      if (iso) {
        isoSet.add(iso);
        internalToIso[code] = iso;
      }
    });

    if (isoSet.size === 0) {
      return new Response(
        JSON.stringify({ ok: true, message: "No mappable currencies", inserted: 0 }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // 3) Fetch market rates from Frankfurter (base = EUR)
    const url = `https://api.frankfurter.app/latest?from=EUR&to=${Array.from(isoSet).join(",")}`;
    const fxRes = await fetch(url);
    if (!fxRes.ok) throw new Error(`Frankfurter API error: ${fxRes.status}`);
    const fx = await fxRes.json();
    const marketRates: Record<string, number> = fx.rates ?? {};
    const rateDate = fx.date ?? new Date().toISOString().slice(0, 10);

    // 4) Build upsert rows: market_rate is units of FOREIGN per 1 EUR (same direction as AS400 cambi for EUR→FOR)
    const rows: any[] = [];
    for (const [internal, iso] of Object.entries(internalToIso)) {
      const market = marketRates[iso];
      if (market == null) continue;
      const as400 = as400Map[internal] || null;
      let delta: number | null = null;
      if (as400 && as400 !== 0) delta = ((market - as400) / as400) * 100;
      rows.push({
        rate_date: rateDate,
        cdval: internal,
        cdval_ref: "EURO",
        market_rate: market,
        as400_rate: as400,
        delta_pct: delta,
        source: "frankfurter.app",
      });
    }

    // 5) Upsert
    const { error: upErr, count } = await supabase
      .from("currency_rates_daily")
      .upsert(rows, { onConflict: "rate_date,cdval", count: "exact" });
    if (upErr) throw upErr;

    return new Response(
      JSON.stringify({ ok: true, rate_date: rateDate, processed: rows.length, count }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (e) {
    console.error(e);
    return new Response(
      JSON.stringify({ ok: false, error: (e as Error).message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});

// deno-lint-ignore-file no-explicit-any
import { createClient } from "npm:@supabase/supabase-js@2";
import { SMTPClient } from "https://deno.land/x/denomailer@1.6.0/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SMTP_HOST = "pro.turbo-smtp.com";
const SMTP_PORT = 465;
const SMTP_USER = "6c018dcf57";
const FROM_EMAIL = "ordini@fraschetti.com";
const FROM_NAME = "Codifica Clienti Fraschetti";

const CC_FIXED = [
  "giovanni.valeri@fraschetti.com",
  "luciano.rea@fraschetti.com",
  "federico.fraschetti@fraschetti.com",
];

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const SMTP_PASSWORD = Deno.env.get("SMTP_PASSWORD") ?? "";

function esc(s: any) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!),
  );
}

function row(label: string, value: any) {
  if (value === null || value === undefined || value === "") return "";
  return `<tr>
    <td style="padding:6px 10px;border-bottom:1px solid #e5e7eb;color:#6b7280;width:42%">${esc(label)}</td>
    <td style="padding:6px 10px;border-bottom:1px solid #e5e7eb;color:#111827"><strong>${esc(value)}</strong></td>
  </tr>`;
}

function encodeSubject(s: string): string {
  return s
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[^\x20-\x7E]/g, "?");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const { request_id, decision } = await req.json().catch(() => ({}));
    if (!request_id || !["approved", "rejected"].includes(decision)) {
      return new Response(JSON.stringify({ error: "request_id and decision (approved|rejected) required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);

    const { data: reqRow, error } = await supabase
      .from("nuovi_clienti_richieste")
      .select("*")
      .eq("id", request_id)
      .maybeSingle();
    if (error || !reqRow) throw new Error(`Richiesta non trovata: ${error?.message ?? request_id}`);

    // Recipient: agente
    let recipient: string | null = reqRow.agent_email ?? null;
    if (!recipient && reqRow.agent_profile_id) {
      const { data: p } = await supabase
        .from("profiles")
        .select("email, order_email")
        .eq("id", reqRow.agent_profile_id)
        .maybeSingle();
      recipient = p?.order_email || p?.email || null;
    }
    if (!recipient) {
      return new Response(JSON.stringify({ error: "Nessuna email agente trovata" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const approved = decision === "approved";
    const subject = approved
      ? `Richiesta nuovo cliente CONFERMATA — ${reqRow.ragione_sociale ?? ""}`
      : `Richiesta nuovo cliente RESPINTA — ${reqRow.ragione_sociale ?? ""}`;

    const headerColor = approved ? "#16a34a" : "#dc2626";
    const headerLabel = approved ? "CONFERMATA" : "RESPINTA";
    const reasonBlock = approved
      ? (reqRow.assigned_customer_code
          ? `<p style="margin:0 0 8px 0">Codice cliente assegnato: <strong>${esc(reqRow.assigned_customer_code)}</strong>${reqRow.assigned_zona ? ` — Zona <strong>${esc(reqRow.assigned_zona)}</strong>` : ""}</p>`
          : "")
        + (reqRow.review_notes ? `<p style="margin:8px 0 0 0;color:#374151">${esc(reqRow.review_notes)}</p>` : "")
      : `<p style="margin:0;color:#374151"><strong>Motivo:</strong> ${esc(reqRow.rejection_reason ?? "—")}</p>`;

    const html = `<!doctype html>
<html><body style="margin:0;padding:24px;background:#f3f4f6;font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:#111827">
  <div style="max-width:640px;margin:0 auto;background:#fff;border-radius:8px;overflow:hidden;border:1px solid #e5e7eb">
    <div style="background:${headerColor};color:#fff;padding:16px 20px">
      <div style="font-size:12px;opacity:.85;letter-spacing:1px;text-transform:uppercase">Richiesta codifica cliente</div>
      <div style="font-size:20px;font-weight:700;margin-top:4px">${headerLabel}</div>
    </div>
    <div style="padding:20px">
      <p style="margin:0 0 16px 0">Ciao ${esc(reqRow.agent_name ?? "")},</p>
      <p style="margin:0 0 16px 0">la richiesta di codifica per <strong>${esc(reqRow.ragione_sociale ?? "—")}</strong> è stata <strong style="color:${headerColor}">${approved ? "confermata" : "respinta"}</strong>.</p>
      <div style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:12px 14px;margin:0 0 20px 0">
        ${reasonBlock}
      </div>

      <h3 style="font-size:14px;color:#374151;margin:0 0 8px 0">Dati richiesta</h3>
      <table style="width:100%;border-collapse:collapse;font-size:13px;border:1px solid #e5e7eb;border-radius:6px;overflow:hidden">
        <tbody>
          ${row("Ragione sociale", reqRow.ragione_sociale)}
          ${row("P.IVA", reqRow.partita_iva)}
          ${row("Cod. fiscale", reqRow.codice_fiscale)}
          ${row("Indirizzo", [reqRow.indirizzo, reqRow.cap, reqRow.citta, reqRow.provincia].filter(Boolean).join(" "))}
          ${row("Zona", reqRow.zona)}
          ${row("Telefono", reqRow.telefono_negozio)}
          ${row("Email", reqRow.email)}
          ${row("PEC", reqRow.pec)}
          ${row("Cod. SDI", reqRow.codice_sdi)}
          ${row("Referente", reqRow.nome_referente)}
          ${row("Cell. referente", reqRow.cellulare_referente)}
        </tbody>
      </table>

      <p style="margin:24px 0 0 0;font-size:12px;color:#6b7280">Email automatica — PIM Fraschetti</p>
    </div>
  </div>
</body></html>`;

    const client = new SMTPClient({
      connection: {
        hostname: SMTP_HOST,
        port: SMTP_PORT,
        tls: true,
        auth: { username: SMTP_USER, password: SMTP_PASSWORD },
      },
    });

    await client.send({
      from: `${FROM_NAME} <${FROM_EMAIL}>`,
      to: recipient,
      cc: CC_FIXED,
      subject: encodeSubject(subject),
      content: "auto",
      html,
    });
    await client.close();

    await supabase.from("email_send_log").insert({
      template_key: approved ? "customer_request_approved" : "customer_request_rejected",
      recipient,
      subject,
      status: "sent",
    });

    return new Response(JSON.stringify({ ok: true, recipient, cc: CC_FIXED }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e: any) {
    const errMsg = e?.message ?? String(e);
    try {
      const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);
      await supabase.from("email_send_log").insert({
        template_key: "customer_request_decision",
        recipient: "(error)",
        status: "failed",
        error: errMsg,
      });
    } catch (_) { /* ignore */ }
    return new Response(JSON.stringify({ error: errMsg }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});


CREATE TABLE public.gamma_attributes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  gamma_code text NOT NULL,
  attribute_name text NOT NULL,
  sort_order int NOT NULL DEFAULT 0,
  is_required boolean NOT NULL DEFAULT false,
  has_unit_select boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (gamma_code, attribute_name)
);

ALTER TABLE public.gamma_attributes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read gamma_attributes"
  ON public.gamma_attributes FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can insert gamma_attributes"
  ON public.gamma_attributes FOR INSERT TO authenticated
  WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "Admins can update gamma_attributes"
  ON public.gamma_attributes FOR UPDATE TO authenticated
  USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can delete gamma_attributes"
  ON public.gamma_attributes FOR DELETE TO authenticated
  USING (public.is_admin(auth.uid()));

CREATE TABLE public.gamma_attribute_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  gamma_attribute_id uuid NOT NULL REFERENCES public.gamma_attributes(id) ON DELETE CASCADE,
  option_value text NOT NULL,
  option_label text,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.gamma_attribute_options ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can read gamma_attribute_options"
  ON public.gamma_attribute_options FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can insert gamma_attribute_options"
  ON public.gamma_attribute_options FOR INSERT TO authenticated
  WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "Admins can update gamma_attribute_options"
  ON public.gamma_attribute_options FOR UPDATE TO authenticated
  USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can delete gamma_attribute_options"
  ON public.gamma_attribute_options FOR DELETE TO authenticated
  USING (public.is_admin(auth.uid()));

CREATE INDEX idx_gamma_attributes_code ON public.gamma_attributes(gamma_code);
CREATE INDEX idx_gamma_attribute_options_attr ON public.gamma_attribute_options(gamma_attribute_id);

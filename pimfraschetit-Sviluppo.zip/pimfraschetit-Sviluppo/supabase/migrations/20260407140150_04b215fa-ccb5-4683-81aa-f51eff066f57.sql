
CREATE TABLE public.lookup_values (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL,
  code text NOT NULL,
  label text,
  sort_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  synced_as400 boolean DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(category, code)
);

CREATE INDEX idx_lookup_values_category ON public.lookup_values(category);

ALTER TABLE public.lookup_values ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view lookup_values"
  ON public.lookup_values FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage lookup_values"
  ON public.lookup_values FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()))
  WITH CHECK (is_admin(auth.uid()));

-- Seed existing values from archivio_articoli_fraschetti
INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'clmer', clmer, clmer, true FROM archivio_articoli_fraschetti WHERE clmer IS NOT NULL AND clmer != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'cdst1', cdst1, cdst1, true FROM archivio_articoli_fraschetti WHERE cdst1 IS NOT NULL AND cdst1 != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'clas1', clas1, clas1, true FROM archivio_articoli_fraschetti WHERE clas1 IS NOT NULL AND clas1 != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'cdiva', cdiva, cdiva, true FROM archivio_articoli_fraschetti WHERE cdiva IS NOT NULL AND cdiva != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'unmis', unmis, unmis, true FROM archivio_articoli_fraschetti WHERE unmis IS NOT NULL AND unmis != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'untec', untec, untec, true FROM archivio_articoli_fraschetti WHERE untec IS NOT NULL AND untec != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'umalt', umalt, umalt, true FROM archivio_articoli_fraschetti WHERE umalt IS NOT NULL AND umalt != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'wstag', wstag, wstag, true FROM archivio_articoli_fraschetti WHERE wstag IS NOT NULL AND wstag != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'wfitt', wfitt, wfitt, true FROM archivio_articoli_fraschetti WHERE wfitt IS NOT NULL AND wfitt != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'wcdst', wcdst, wcdst, true FROM archivio_articoli_fraschetti WHERE wcdst IS NOT NULL AND wcdst != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'wimba', wimba, wimba, true FROM archivio_articoli_fraschetti WHERE wimba IS NOT NULL AND wimba != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'tpimb', tpimb, tpimb, true FROM archivio_articoli_fraschetti WHERE tpimb IS NOT NULL AND tpimb != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'wclve', wclve, wclve, true FROM archivio_articoli_fraschetti WHERE wclve IS NOT NULL AND wclve != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'wfuas', wfuas, wfuas, true FROM archivio_articoli_fraschetti WHERE wfuas IS NOT NULL AND wfuas != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'wpzne', wpzne, wpzne, true FROM archivio_articoli_fraschetti WHERE wpzne IS NOT NULL AND wpzne != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'wsezi', wsezi, wsezi, true FROM archivio_articoli_fraschetti WHERE wsezi IS NOT NULL AND wsezi != ''
ON CONFLICT DO NOTHING;

INSERT INTO public.lookup_values (category, code, label, synced_as400)
SELECT DISTINCT 'unpes', unpes, unpes, true FROM archivio_articoli_fraschetti WHERE unpes IS NOT NULL AND unpes != ''
ON CONFLICT DO NOTHING;

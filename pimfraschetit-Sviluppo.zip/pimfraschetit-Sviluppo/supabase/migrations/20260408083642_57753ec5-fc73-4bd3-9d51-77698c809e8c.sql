-- Drop the broken trigger
DROP TRIGGER IF EXISTS trg_audit_fornitori ON archivio_fornitori_fraschetti;

-- Create a fornitori-specific audit function using cdfor instead of cdpar
CREATE OR REPLACE FUNCTION public.fn_audit_log_fornitori()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  old_j jsonb;
  new_j jsonb;
  changed text[];
  k text;
BEGIN
  IF TG_OP = 'DELETE' THEN
    INSERT INTO audit_log (table_name, operation, record_id, old_values, user_id, user_email)
    VALUES (TG_TABLE_NAME, TG_OP, OLD.cdfor, to_jsonb(OLD), auth.uid(),
            (SELECT email FROM auth.users WHERE id = auth.uid()));
    RETURN OLD;
  END IF;

  IF TG_OP = 'INSERT' THEN
    INSERT INTO audit_log (table_name, operation, record_id, new_values, user_id, user_email)
    VALUES (TG_TABLE_NAME, TG_OP, NEW.cdfor, to_jsonb(NEW), auth.uid(),
            (SELECT email FROM auth.users WHERE id = auth.uid()));
    RETURN NEW;
  END IF;

  old_j := to_jsonb(OLD);
  new_j := to_jsonb(NEW);
  changed := ARRAY[]::text[];
  FOR k IN SELECT jsonb_object_keys(new_j)
  LOOP
    IF k NOT IN ('updated_at') AND (old_j->k IS DISTINCT FROM new_j->k) THEN
      changed := array_append(changed, k);
    END IF;
  END LOOP;

  IF array_length(changed, 1) > 0 THEN
    INSERT INTO audit_log (table_name, operation, record_id, old_values, new_values, changed_fields, user_id, user_email)
    VALUES (TG_TABLE_NAME, TG_OP, NEW.cdfor,
            jsonb_object_agg_strict(old_j, changed),
            jsonb_object_agg_strict(new_j, changed),
            changed, auth.uid(),
            (SELECT email FROM auth.users WHERE id = auth.uid()));
  END IF;

  RETURN NEW;
END;
$function$;

-- Re-create trigger with the correct function
CREATE TRIGGER trg_audit_fornitori
AFTER INSERT OR UPDATE OR DELETE ON archivio_fornitori_fraschetti
FOR EACH ROW EXECUTE FUNCTION fn_audit_log_fornitori();
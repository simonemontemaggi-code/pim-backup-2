INSERT INTO anag_art_fornitore_field_flags (field_code, read_flag, write_flag, missing_flag, clarify_flag)
VALUES
  ('cdfor', true, true, false, false),
  ('cdpfo', true, true, false, false),
  ('qtmio', true, true, false, false),
  ('wimbf', true, true, false, false),
  ('wviqm', true, true, false, false),
  ('wviim', true, true, false, false),
  ('wqtde', true, true, false, false),
  ('wumqm', true, true, false, false),
  ('wumim', true, true, false, false),
  ('wtaim', true, true, false, false),
  ('cdval', true, true, false, false)
ON CONFLICT DO NOTHING;
CREATE OR REPLACE FUNCTION public.search_articles(
  query text,
  filter_clmer text DEFAULT NULL,
  filter_lipro text DEFAULT NULL,
  lim int DEFAULT 100,
  off int DEFAULT 0
)
RETURNS TABLE(
  id uuid,
  cdpar text,
  depar text,
  clmer text,
  lipro text,
  pcfor text,
  unmis text,
  cdiva text,
  barcd text,
  updated_at timestamptz,
  total_count bigint
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  normalized text;
  tsq tsquery;
BEGIN
  normalized := trim(lower(query));
  
  -- Lower similarity threshold for better typo tolerance
  PERFORM set_limit(0.15);
  
  -- Build tsquery safely, fallback to NULL if parsing fails
  BEGIN
    tsq := plainto_tsquery('italian', normalized);
  EXCEPTION WHEN OTHERS THEN
    tsq := NULL;
  END;

  RETURN QUERY
  WITH matches AS (
    SELECT 
      a.id,
      a.cdpar,
      a.depar,
      a.clmer,
      a.lipro,
      a.pcfor,
      a.unmis,
      a.cdiva,
      a.barcd,
      a.updated_at,
      (
        COALESCE(similarity(a.cdpar, normalized), 0) * 2.0 +
        COALESCE(similarity(a.depar, normalized), 0) +
        CASE WHEN tsq IS NOT NULL AND a.fts @@ tsq 
             THEN ts_rank(a.fts, tsq) * 3.0 
             ELSE 0 END
      ) AS rank
    FROM archivio_articoli_fraschetti a
    WHERE (
      a.cdpar % normalized 
      OR a.depar % normalized
      OR a.cdpar ILIKE '%' || normalized || '%'
      OR a.depar ILIKE '%' || normalized || '%'
      OR (tsq IS NOT NULL AND a.fts @@ tsq)
    )
    AND (filter_clmer IS NULL OR a.clmer = filter_clmer)
    AND (filter_lipro IS NULL OR a.lipro = filter_lipro)
  )
  SELECT 
    m.id, m.cdpar, m.depar, m.clmer, m.lipro, 
    m.pcfor, m.unmis, m.cdiva, m.barcd, m.updated_at,
    (count(*) OVER ())::bigint AS total_count
  FROM matches m
  ORDER BY m.rank DESC, m.cdpar ASC
  LIMIT lim OFFSET off;
END;
$$;
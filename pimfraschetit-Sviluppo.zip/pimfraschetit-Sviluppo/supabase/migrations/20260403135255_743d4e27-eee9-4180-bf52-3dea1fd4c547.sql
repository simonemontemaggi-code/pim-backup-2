-- Enable pg_trgm extension for fuzzy search
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Create trigram indexes for fast fuzzy matching
CREATE INDEX IF NOT EXISTS idx_articoli_cdpar_trgm 
  ON archivio_articoli_fraschetti USING gin (cdpar gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_articoli_depar_trgm 
  ON archivio_articoli_fraschetti USING gin (depar gin_trgm_ops);

-- Trigger to keep fts column updated on insert/update
CREATE OR REPLACE FUNCTION public.update_article_fts() 
RETURNS trigger 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.fts := to_tsvector('italian', 
    coalesce(NEW.cdpar,'') || ' ' || 
    coalesce(NEW.depar,'') || ' ' || 
    coalesce(NEW.clmer,'') || ' ' || 
    coalesce(NEW.lipro,''));
  RETURN NEW;
END;
$$;

-- Drop existing trigger if any, then create
DROP TRIGGER IF EXISTS trg_article_fts ON archivio_articoli_fraschetti;
CREATE TRIGGER trg_article_fts 
  BEFORE INSERT OR UPDATE ON archivio_articoli_fraschetti
  FOR EACH ROW EXECUTE FUNCTION update_article_fts();

-- Hybrid search function combining trigram similarity + FTS
CREATE OR REPLACE FUNCTION public.search_articles(
  query text,
  filter_clmer text DEFAULT NULL,
  filter_lipro text DEFAULT NULL,
  lim int DEFAULT 100,
  off int DEFAULT 0
)
RETURNS TABLE(
  id uuid,
  cdpar text,
  depar text,
  clmer text,
  lipro text,
  pcfor text,
  unmis text,
  cdiva text,
  barcd text,
  updated_at timestamptz,
  total_count bigint
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  normalized text;
  tsq tsquery;
BEGIN
  normalized := trim(lower(query));
  
  -- Build tsquery safely, fallback to NULL if parsing fails
  BEGIN
    tsq := plainto_tsquery('italian', normalized);
  EXCEPTION WHEN OTHERS THEN
    tsq := NULL;
  END;

  RETURN QUERY
  WITH matches AS (
    SELECT 
      a.id,
      a.cdpar,
      a.depar,
      a.clmer,
      a.lipro,
      a.pcfor,
      a.unmis,
      a.cdiva,
      a.barcd,
      a.updated_at,
      (
        COALESCE(similarity(a.cdpar, normalized), 0) * 2.0 +
        COALESCE(similarity(a.depar, normalized), 0) +
        CASE WHEN tsq IS NOT NULL AND a.fts @@ tsq 
             THEN ts_rank(a.fts, tsq) * 3.0 
             ELSE 0 END
      ) AS rank
    FROM archivio_articoli_fraschetti a
    WHERE (
      a.cdpar % normalized 
      OR a.depar % normalized
      OR a.cdpar ILIKE '%' || normalized || '%'
      OR a.depar ILIKE '%' || normalized || '%'
      OR (tsq IS NOT NULL AND a.fts @@ tsq)
    )
    AND (filter_clmer IS NULL OR a.clmer = filter_clmer)
    AND (filter_lipro IS NULL OR a.lipro = filter_lipro)
  )
  SELECT 
    m.id, m.cdpar, m.depar, m.clmer, m.lipro, 
    m.pcfor, m.unmis, m.cdiva, m.barcd, m.updated_at,
    (count(*) OVER ())::bigint AS total_count
  FROM matches m
  ORDER BY m.rank DESC, m.cdpar ASC
  LIMIT lim OFFSET off;
END;
$$;
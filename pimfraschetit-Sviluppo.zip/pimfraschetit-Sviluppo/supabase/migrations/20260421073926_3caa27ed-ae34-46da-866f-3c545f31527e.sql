
CREATE OR REPLACE FUNCTION public.sync_brand_to_lookup()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.lookup_values (category, code, label, synced_as400, is_active)
  VALUES ('clas2', NEW.clas2, NEW.descrizione, NEW.synced_as400, true)
  ON CONFLICT (category, code)
  DO UPDATE SET label = EXCLUDED.label, synced_as400 = EXCLUDED.synced_as400;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_brand_to_lookup
AFTER INSERT OR UPDATE ON public.archivio_brand_fraschetti
FOR EACH ROW EXECUTE FUNCTION public.sync_brand_to_lookup();

CREATE OR REPLACE FUNCTION public.sync_lookup_to_brand()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.category = 'clas2' THEN
    INSERT INTO public.archivio_brand_fraschetti (clas2, descrizione, synced_as400)
    VALUES (NEW.code, COALESCE(NULLIF(NEW.label, NEW.code), 'VERIFICARE'), false)
    ON CONFLICT (clas2) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_lookup_to_brand
AFTER INSERT ON public.lookup_values
FOR EACH ROW EXECUTE FUNCTION public.sync_lookup_to_brand();


SELECT cron.schedule(
  'fetch-currency-rates-daily',
  '0 6 * * *',
  $$
  SELECT net.http_post(
    url := 'https://ytkofsktbkuzgzhzhiys.supabase.co/functions/v1/fetch-currency-rates',
    headers := '{"Content-Type":"application/json","Authorization":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl0a29mc2t0Ymt1emd6aHpoaXlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjkwODg5NTQsImV4cCI6MjA4NDY2NDk1NH0.U9qC8eC_zm8tBWVk1VpmOUp-KZVM2q_KNEQa_40HeGU"}'::jsonb,
    body := '{}'::jsonb
  ) AS request_id;
  $$
);

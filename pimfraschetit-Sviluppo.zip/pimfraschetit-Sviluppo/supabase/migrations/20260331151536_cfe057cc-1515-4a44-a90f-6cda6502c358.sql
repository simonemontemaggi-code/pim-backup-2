ALTER TABLE public.archivio_articoli_fraschetti 
ADD COLUMN IF NOT EXISTS fts tsvector 
GENERATED ALWAYS AS (
  to_tsvector('italian', coalesce(cdpar,'') || ' ' || coalesce(depar,'') || ' ' || coalesce(nmcat,'') || ' ' || coalesce(wdset,''))
) STORED;

CREATE INDEX IF NOT EXISTS idx_archivio_articoli_fts ON public.archivio_articoli_fraschetti USING GIN(fts);
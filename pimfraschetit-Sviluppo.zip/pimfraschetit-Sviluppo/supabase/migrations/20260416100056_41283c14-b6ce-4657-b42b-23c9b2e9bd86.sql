
CREATE TABLE public.field_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  department_id uuid NOT NULL REFERENCES public.departments(id) ON DELETE CASCADE,
  section_key text NOT NULL,
  field_key text NOT NULL,
  permission text NOT NULL DEFAULT 'inherit',
  created_at timestamptz DEFAULT now(),
  UNIQUE (department_id, section_key, field_key)
);

ALTER TABLE public.field_permissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage field_permissions"
ON public.field_permissions
FOR ALL
TO authenticated
USING (public.is_admin(auth.uid()))
WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "Authenticated users can read field_permissions"
ON public.field_permissions
FOR SELECT
TO authenticated
USING (true);

CREATE INDEX idx_field_permissions_dept ON public.field_permissions (department_id);
CREATE INDEX idx_field_permissions_section ON public.field_permissions (department_id, section_key);

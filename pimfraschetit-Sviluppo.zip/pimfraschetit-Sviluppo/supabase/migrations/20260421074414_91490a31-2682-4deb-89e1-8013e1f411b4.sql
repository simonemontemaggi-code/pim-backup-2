
ALTER TABLE public.archivio_brand_fraschetti
  RENAME COLUMN descrizione TO nome_as400_brand;

CREATE OR REPLACE FUNCTION public.sync_brand_to_lookup()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.lookup_values (category, code, label, synced_as400, is_active)
  VALUES ('clas2', NEW.clas2, NEW.nome_as400_brand, NEW.synced_as400, true)
  ON CONFLICT (category, code)
  DO UPDATE SET label = EXCLUDED.label, synced_as400 = EXCLUDED.synced_as400;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.sync_lookup_to_brand()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.category = 'clas2' THEN
    INSERT INTO public.archivio_brand_fraschetti (clas2, nome_as400_brand, synced_as400)
    VALUES (NEW.code, COALESCE(NULLIF(NEW.label, NEW.code), 'VERIFICARE'), false)
    ON CONFLICT (clas2) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

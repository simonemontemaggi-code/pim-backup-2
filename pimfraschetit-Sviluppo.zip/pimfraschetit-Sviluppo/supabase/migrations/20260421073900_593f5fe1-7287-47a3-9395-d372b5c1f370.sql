
CREATE TABLE IF NOT EXISTS public.archivio_brand_fraschetti (
  clas2 text PRIMARY KEY,
  descrizione text NOT NULL DEFAULT 'VERIFICARE',
  synced_as400 boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.archivio_brand_fraschetti ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view brand"
  ON public.archivio_brand_fraschetti FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "Admins can manage brand"
  ON public.archivio_brand_fraschetti FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()))
  WITH CHECK (is_admin(auth.uid()));

CREATE TRIGGER trg_brand_updated_at
BEFORE UPDATE ON public.archivio_brand_fraschetti
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.archivio_brand_fraschetti (clas2, descrizione, synced_as400) VALUES
  ('FA01','3M',true),('FA02','ABRA BETA',true),('FA03','ABT',true),('FA05','ACOLOR',true),
  ('FA07','ACQUASAN',true),('FA09','ADRETA',true),('FA10','ADTAB',true),('FA11','ADVANTAGE',true),
  ('FA13','ADVANTIX',true),('FA15','AETERNUM',true),('FA17','AGRIBIOS',true),('FA19','ALA',true),
  ('FA21','ALMA',true),('FA23','ALPINA',true),('FA25','ALUBOX',true),('FA27','AMBIPUR',true),
  ('FA29','ANCORA',true),('FA31','ANI',true),('FA33','ANNOVI REVERBERI',true),('FA35','ARCANSAS',true),
  ('FA37','ARDES',true),('FA39','AREXONS',true),('FA41','ARGENTIL',true),('FA43','ARIASANA',true),
  ('FA45','ARRIGONI',true),('FA47','ART PLAST',true),('FA49','ARTIGLIO',true),('FA51','ASSA ABLOY',true),
  ('FA53','AUSONIA',true),('FB01','B+D',true),('FB03','BACCHETTA',true),('FB05','BAHCO',true),
  ('FB07','BARTOLINI',true),('FB09','BELLOTA',true),('FB11','BESTWAY',true),('FB13','BETA',true),
  ('FB15','BETAFENCE',true),('FB17','BETTER PROTECTIVE',true),('FB18','Blumen SCJ',true),('FB19','BONAITI',true),
  ('FB21','BORMIOLI',true),('FB23','BOSCH',true),('FB25','BOSTIK',true),('FB27','BOSTON',true),
  ('FB29','BRAVO',true),('FB31','BUTTERFLY',true),('FC00','CAMON',true),('FC01','CAMPING GAZ',true),
  ('FC03','CARLTON',true),('FC05','CASTROL',true),('FC07','CENTURY',true),('FC08','PULIPER',true),
  ('FC09','CHAMPION',true),('FC10','CFG',true),('FC11','CHANTECLAIR',true),('FC13','CISA',true),
  ('FC15','CLABER',true),('FC17','CLIMAX',true),('FC19','COBRA',true),('FC21','COLLOMIX',true),
  ('FC23','COMPO',true),('FC25','COMUNELLO',true),('FC27','CORBIN',true),('FC29','CORMIK',true),
  ('FC31','CORNI',true),('FC33','CORNICI BERARDI',true),('FC35','CR',true),('FC37','CTF',true),
  ('FD01','DECA',true),('FD03','DEROMA',true),('FD04','DETOMASO',true),('FD05','DEWALT',true),
  ('FD07','DIAVOLINA',true),('FD08','DOMO LIVING',true),('FD09','DREMEL',true),('FD11','DUE BUOI',true),
  ('FD13','DURACELL',true),('FD14','Dherma&Salute',true),('FE01','ECOLIGHT',true),('FE03','EINHELL',true),
  ('FE04','EL-CHARRO',true),('FE05','ERCOLE',true),('FE06','ERG',true),('FE07','EUROCEL',true),
  ('FE08','ELF',true),('FE09','EUROPEA',true),('FE11','EXTRAFLAME',true),('FF01','FALCI',true),
  ('FF03','FAREN',true),('FF05','FELCO',true),('FF07','FEROX',true),('FF09','FINI',true),
  ('FF11','FISCHER',true),('FF13','FISKARS',true),('FF15','FITT',true),('FF17','FRANCHI',true),
  ('FF19','FULCRON',true),('FG01','GAMA',true),('FG03','GARSPORT',true),('FG05','GDM',true),
  ('FG07','GENTILI',true),('FG09','GESAL',true),('FG11','GIMI',true),('FG13','GIOSTYLE',true),
  ('FG15','GRE',true),('FG17','GREEN OIL',true),('FG18','GREENWORKS',true),('FG19','GRINDING',true),
  ('FG21','GMR',true),('FH01','HIKOKI',true),('FH03','HIT',true),('FH05','HOPPE',true),
  ('FH07','HUMIFLORA',true),('FH09','HUNTER',true),('FI01','IBFM',true),('FI03','ICOBIT',true),
  ('FI05','ICS',true),('FI07','IMPERIAL',true),('FI09','INE',true),('FI11','INTEX',true),
  ('FI13','IOI',true),('FI15','IRRITEC',true),('FI17','ISEO',true),('FI19','ITALCHIMICA',true),
  ('FI20','ITALTECNICA',true),('FI21','ITAP',true),('FK01','K2',true),('FK03','KARCHER',true),
  ('FK05','KEMPER',true),('FK06','KERBL',true),('FK07','KETER',true),('FK08','KIMONO',true),
  ('FK09','KILTIX',true),('FK11','KNIPEX',true),('FK13','KOBEL',true),('FK15','KOLLANT',true),
  ('FL01','LA NORDICA',true),('FL03','LAVOR',true),('FL04','LISA',true),('FL05','LOCTITE',true),
  ('FL07','LOWARA',true),('FL09','LUBEX',true),('FM01','MAB',true),('FM03','MAESTRI',true),
  ('FM05','MAJESTIC',true),('FM07','MANARESI',true),('FM09','MARTIN',true),('FM11','MAYER',true),
  ('FM13','MELICONI',true),('FM14','METRONIC',true),('FM15','METYLAN',true),('FM17','MILLE',true),
  ('FM19','MINUTEX',true),('FM20','MOBIL PLASTIC',true),('FM21','MONTOLIT',true),('FM23','MOTTURA',true),
  ('FM25','MRCAS',true),('FM27','MUSTAD',true),('FN01','NAAN',true),('FN02','NERI',true),
  ('FN03','NETTUNO',true),('FN05','NICHOLSON',true),('FN06','NPA',true),('FO01','ONDULINE',true),
  ('FO03','OPINEL',true),('FP01','PATTEX',true),('FP03','PEARSON',true),('FP05','PHIFER',true),
  ('FP07','PLEIN AIR',true),('FP09','PREFER',true),('FP11','PRINCESS',true),('FP13','PRITT',true),
  ('FP15','PROGARDEN',true),('FP16','PURRFIT',true),('FQ01','QUEEN',true),('FR01','REBER',true),
  ('FR03','RESPIRA',true),('FR05','RHUTTEN',true),('FR07','RINGO',true),('FR09','ROBUR',true),
  ('FR11','ROCARR',true),('FR13','ROVER',true),('FR15','RUBSON',true),('FS01','SAMURAI',true),
  ('FS03','SANSONE',true),('FS05','SAYERLACK',true),('FS07','SCAME',true),('FS09','SECUREMME',true),
  ('FS11','SERESTO',true),('FS13','SILBERSCHNITT',true),('FS15','SILCA',true),('FS17','SIME',true),
  ('FS19','SINGER',true),('FS21','SINTOLIT',true),('FS23','SMAC',true),('FS25','SMUFFER',true),
  ('FS27','SOLA',true),('FS29','SOUDAL',true),('FS31','SPID',true),('FS33','SPIRA',true),
  ('FS35','STANLEY',true),('FS37','STANLEY FATMAX',true),('FS39','STORMWATT',true),('FS41','SUPEREGO',true),
  ('FS43','SVITOL',true),('FT01','TAMOIL',true),('FT03','TANGIT',true),('FT05','TECFI',true),
  ('FT07','TELCOM',true),('FT09','TERMOZETA',true),('FT11','TERRY',true),('FT13','TESA',true),
  ('FT15','THERMACELL',true),('FT17','TOOMAX',true),('FT18','TRIO LIGHTING',true),('FT19','TRISTAR',true),
  ('FU01','UHU',true),('FU03','U-POWER',true),('FU05','URSUS',true),('FU07','USAG',true),
  ('FV01','VARTA',true),('FV03','VETRIL',true),('FV05','VILEDA',true),('FV07','VINAVIL',true),
  ('FV09','VIRO',true),('FV11','VIROSAC',true),('FW01','WC NET',true),('FW02','weber',true),
  ('FW03','WD-40',true),('FW05','WELKA',true),('FW07','WIZZY',true),('FW09','WOLFCRAFT',true),
  ('FX01','GOULDS BY XYLEM',true),('FY01','YALE',true),('FZ01','ZEPHIR',true),('FZ03','ZIBRO',true),
  ('NA01','ACQUA CLEAN',true),('NA03','ALBERIAMO',true),('NA06','ANTICA CORDERIA',true),('NB01','BELLA NAPOLI',true)
ON CONFLICT (clas2) DO UPDATE SET descrizione = EXCLUDED.descrizione, synced_as400 = true;

INSERT INTO public.archivio_brand_fraschetti (clas2, descrizione, synced_as400)
SELECT lv.code, 'VERIFICARE', false
FROM public.lookup_values lv
WHERE lv.category = 'clas2'
  AND NOT EXISTS (SELECT 1 FROM public.archivio_brand_fraschetti b WHERE b.clas2 = lv.code)
ON CONFLICT DO NOTHING;

UPDATE public.lookup_values lv
SET label = b.descrizione
FROM public.archivio_brand_fraschetti b
WHERE lv.category = 'clas2' AND lv.code = b.clas2;

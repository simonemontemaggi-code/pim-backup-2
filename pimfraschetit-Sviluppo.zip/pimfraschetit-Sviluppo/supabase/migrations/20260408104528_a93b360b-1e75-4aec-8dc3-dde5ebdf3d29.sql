ALTER TABLE public.archivio_articoli_fraschetti
  ADD COLUMN IF NOT EXISTS b2b_product_title text,
  ADD COLUMN IF NOT EXISTS b2b_product_description text;
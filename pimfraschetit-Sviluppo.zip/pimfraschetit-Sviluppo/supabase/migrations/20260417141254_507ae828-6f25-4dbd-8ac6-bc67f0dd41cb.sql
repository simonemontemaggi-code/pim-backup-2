
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

CREATE TABLE IF NOT EXISTS public.currency_rates_daily (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rate_date date NOT NULL,
  cdval text NOT NULL,
  cdval_ref text NOT NULL DEFAULT 'EURO',
  market_rate numeric NOT NULL,
  as400_rate numeric,
  delta_pct numeric,
  source text DEFAULT 'frankfurter.app',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (rate_date, cdval)
);

CREATE INDEX IF NOT EXISTS idx_currency_rates_daily_date ON public.currency_rates_daily (rate_date DESC);
CREATE INDEX IF NOT EXISTS idx_currency_rates_daily_cdval ON public.currency_rates_daily (cdval);

ALTER TABLE public.currency_rates_daily ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view currency rates"
ON public.currency_rates_daily
FOR SELECT
TO authenticated
USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can insert currency rates"
ON public.currency_rates_daily
FOR INSERT
TO authenticated
WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "Admins can update currency rates"
ON public.currency_rates_daily
FOR UPDATE
TO authenticated
USING (public.is_admin(auth.uid()));

CREATE TRIGGER trg_currency_rates_daily_updated_at
BEFORE UPDATE ON public.currency_rates_daily
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

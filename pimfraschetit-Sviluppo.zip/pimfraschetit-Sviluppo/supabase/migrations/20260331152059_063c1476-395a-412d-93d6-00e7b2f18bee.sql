
-- 1. article_purchases table (1:1 with articles via cdpar)
CREATE TABLE IF NOT EXISTS public.article_purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cdpar text NOT NULL UNIQUE,
  cdfor text,
  cdpfo text,
  qtmio numeric,
  wimbf numeric,
  wviqm text CHECK (wviqm IN ('S','N',NULL)),
  wviim text CHECK (wviim IN ('S','N',NULL)),
  wqtde text CHECK (wqtde IN ('S','N',NULL)),
  wumqm text,
  wumim text,
  wtaim text,
  voce_doganale text,
  cdval text,
  wsm01 numeric,
  wsm02 numeric DEFAULT 100,
  wprun numeric,
  wcdls text,
  wdtin date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.article_purchases ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated can view article_purchases" ON public.article_purchases FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage article_purchases" ON public.article_purchases FOR ALL TO authenticated USING (is_admin(auth.uid())) WITH CHECK (is_admin(auth.uid()));

-- 2. Marketing + sync columns on articles
ALTER TABLE public.archivio_articoli_fraschetti
  ADD COLUMN IF NOT EXISTS description_marketing text,
  ADD COLUMN IF NOT EXISTS description_ecommerce text,
  ADD COLUMN IF NOT EXISTS seo_title text,
  ADD COLUMN IF NOT EXISTS seo_description text,
  ADD COLUMN IF NOT EXISTS tags text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS attributes jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS as400_sync_status text DEFAULT 'new',
  ADD COLUMN IF NOT EXISTS updated_by uuid;

-- 3. is_active on suppliers
ALTER TABLE public.archivio_fornitori_fraschetti
  ADD COLUMN IF NOT EXISTS is_active boolean DEFAULT true;

-- 4. audit_log
CREATE TABLE IF NOT EXISTS public.audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  table_name text NOT NULL,
  record_id text NOT NULL,
  operation text NOT NULL,
  old_values jsonb,
  new_values jsonb,
  changed_fields text[],
  user_id uuid,
  user_email text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage audit_log" ON public.audit_log FOR ALL TO authenticated USING (is_admin(auth.uid())) WITH CHECK (is_admin(auth.uid()));
CREATE POLICY "Authenticated can insert audit_log" ON public.audit_log FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated can view audit_log" ON public.audit_log FOR SELECT TO authenticated USING (true);

-- 5. as400_sync_queue
CREATE TABLE IF NOT EXISTS public.as400_sync_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cdpar text NOT NULL,
  operation text NOT NULL DEFAULT 'upsert',
  payload jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'pending',
  attempts integer DEFAULT 0,
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.as400_sync_queue ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage as400_sync_queue" ON public.as400_sync_queue FOR ALL TO authenticated USING (is_admin(auth.uid())) WITH CHECK (is_admin(auth.uid()));
CREATE POLICY "Authenticated can view as400_sync_queue" ON public.as400_sync_queue FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can insert as400_sync_queue" ON public.as400_sync_queue FOR INSERT TO authenticated WITH CHECK (true);

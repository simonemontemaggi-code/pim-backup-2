-- Abilita estensioni per cron e http
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Rimuovi schedulazioni precedenti se presenti (idempotente)
DO $$
BEGIN
  PERFORM cron.unschedule('attiva-prezzi-giornalieri-summer');
EXCEPTION WHEN OTHERS THEN NULL;
END $$;
DO $$
BEGIN
  PERFORM cron.unschedule('attiva-prezzi-giornalieri-winter');
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- Schedula 03:00 UTC (= 05:00 ora legale italiana, marzo-ottobre)
SELECT cron.schedule(
  'attiva-prezzi-giornalieri-summer',
  '0 3 * * *',
  $$
  SELECT net.http_post(
    url := 'https://ytkofsktbkuzgzhzhiys.supabase.co/functions/v1/attiva-prezzi-giornalieri',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl0a29mc2t0Ymt1emd6aHpoaXlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjkwODg5NTQsImV4cCI6MjA4NDY2NDk1NH0.U9qC8eC_zm8tBWVk1VpmOUp-KZVM2q_KNEQa_40HeGU"}'::jsonb,
    body := jsonb_build_object('time', now())
  );
  $$
);

-- Schedula 04:00 UTC (= 05:00 ora solare italiana, novembre-febbraio)
SELECT cron.schedule(
  'attiva-prezzi-giornalieri-winter',
  '0 4 * * *',
  $$
  SELECT net.http_post(
    url := 'https://ytkofsktbkuzgzhzhiys.supabase.co/functions/v1/attiva-prezzi-giornalieri',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl0a29mc2t0Ymt1emd6aHpoaXlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjkwODg5NTQsImV4cCI6MjA4NDY2NDk1NH0.U9qC8eC_zm8tBWVk1VpmOUp-KZVM2q_KNEQa_40HeGU"}'::jsonb,
    body := jsonb_build_object('time', now())
  );
  $$
);
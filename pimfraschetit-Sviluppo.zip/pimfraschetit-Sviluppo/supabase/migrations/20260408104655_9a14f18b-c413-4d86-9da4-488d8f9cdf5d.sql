CREATE OR REPLACE FUNCTION public.count_articles_with_media()
RETURNS integer
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(DISTINCT cdpar)::integer FROM article_media;
$$;

CREATE OR REPLACE FUNCTION public.count_articles_with_barcodes()
RETURNS integer
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(DISTINCT wcdpa)::integer FROM archivio_codici_barre_fraschetti;
$$;
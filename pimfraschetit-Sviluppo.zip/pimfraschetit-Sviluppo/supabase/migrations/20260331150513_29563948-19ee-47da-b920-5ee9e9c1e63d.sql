CREATE TABLE IF NOT EXISTS section_permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  department_id UUID NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  section_key TEXT NOT NULL,
  permission TEXT NOT NULL DEFAULT 'hidden' CHECK (permission IN ('hidden', 'read', 'write')),
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(department_id, section_key)
);

ALTER TABLE section_permissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage section_permissions" ON section_permissions
  FOR ALL TO authenticated USING (is_admin(auth.uid())) WITH CHECK (is_admin(auth.uid()));

CREATE POLICY "Users can read own department permissions" ON section_permissions
  FOR SELECT TO authenticated
  USING (department_id IN (SELECT department_id FROM user_departments WHERE user_id = auth.uid()));

INSERT INTO section_permissions (department_id, section_key, permission)
SELECT 'da9d253b-2f0f-4ee1-acd2-7be39a15d21c'::uuid, s.key, s.perm
FROM (VALUES
  ('articles_registry','write'),('articles_pricing','write'),('articles_logistics','write'),
  ('articles_marketing','read'),('suppliers','write'),('price_lists','write'),
  ('barcodes','write'),('media_library','read'),('as400_sync','read'),
  ('import_export','write'),('users_admin','hidden')
) AS s(key, perm)
ON CONFLICT DO NOTHING;

INSERT INTO section_permissions (department_id, section_key, permission)
SELECT '21a30a8f-be8e-4a99-92d1-1c350b0eeeb6'::uuid, s.key, s.perm
FROM (VALUES
  ('articles_registry','read'),('articles_pricing','hidden'),('articles_logistics','hidden'),
  ('articles_marketing','write'),('suppliers','read'),('price_lists','hidden'),
  ('barcodes','read'),('media_library','write'),('as400_sync','hidden'),
  ('import_export','read'),('users_admin','hidden')
) AS s(key, perm)
ON CONFLICT DO NOTHING;

INSERT INTO section_permissions (department_id, section_key, permission)
SELECT '5ce8d2d5-da8e-4405-ae3b-cae1807c860f'::uuid, s.key, s.perm
FROM (VALUES
  ('articles_registry','read'),('articles_pricing','read'),('articles_logistics','read'),
  ('articles_marketing','read'),('suppliers','read'),('price_lists','read'),
  ('barcodes','read'),('media_library','read'),('as400_sync','hidden'),
  ('import_export','read'),('users_admin','hidden')
) AS s(key, perm)
ON CONFLICT DO NOTHING;

INSERT INTO section_permissions (department_id, section_key, permission)
SELECT 'c3c3356f-bb38-472f-835f-a8e6b5b5da23'::uuid, s.key, s.perm
FROM (VALUES
  ('articles_registry','read'),('articles_pricing','read'),('articles_logistics','hidden'),
  ('articles_marketing','hidden'),('suppliers','read'),('price_lists','read'),
  ('barcodes','read'),('media_library','hidden'),('as400_sync','hidden'),
  ('import_export','read'),('users_admin','hidden')
) AS s(key, perm)
ON CONFLICT DO NOTHING;

INSERT INTO section_permissions (department_id, section_key, permission)
SELECT '2f8da3a9-9a5c-4610-9adb-824b011ca93b'::uuid, s.key, 'write'
FROM (VALUES
  ('articles_registry'),('articles_pricing'),('articles_logistics'),
  ('articles_marketing'),('suppliers'),('price_lists'),
  ('barcodes'),('media_library'),('as400_sync'),
  ('import_export'),('users_admin')
) AS s(key)
ON CONFLICT DO NOTHING;
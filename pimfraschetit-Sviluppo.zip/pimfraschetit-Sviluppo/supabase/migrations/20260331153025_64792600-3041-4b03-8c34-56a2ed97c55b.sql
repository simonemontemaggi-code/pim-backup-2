
-- article_media table
CREATE TABLE public.article_media (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cdpar TEXT NOT NULL,
  media_type TEXT NOT NULL,
  storage_path TEXT NOT NULL,
  public_url TEXT,
  original_filename TEXT,
  file_size INTEGER,
  is_primary BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.article_media ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view article_media" ON public.article_media FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can insert article_media" ON public.article_media FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Admins can manage article_media" ON public.article_media FOR ALL TO authenticated USING (is_admin(auth.uid())) WITH CHECK (is_admin(auth.uid()));

-- import_sessions table
CREATE TABLE public.import_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  import_type TEXT NOT NULL,
  filename TEXT,
  total_rows INTEGER DEFAULT 0,
  created_rows INTEGER DEFAULT 0,
  updated_rows INTEGER DEFAULT 0,
  skipped_rows INTEGER DEFAULT 0,
  error_rows INTEGER DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'running',
  user_id UUID,
  user_email TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ
);

ALTER TABLE public.import_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view import_sessions" ON public.import_sessions FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can insert import_sessions" ON public.import_sessions FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Admins can manage import_sessions" ON public.import_sessions FOR ALL TO authenticated USING (is_admin(auth.uid())) WITH CHECK (is_admin(auth.uid()));

-- pim-media storage bucket
INSERT INTO storage.buckets (id, name, public) VALUES ('pim-media', 'pim-media', true);

CREATE POLICY "Authenticated can upload to pim-media" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'pim-media');
CREATE POLICY "Anyone can view pim-media" ON storage.objects FOR SELECT USING (bucket_id = 'pim-media');
CREATE POLICY "Authenticated can delete from pim-media" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'pim-media');

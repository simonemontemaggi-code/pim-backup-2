SELECT cron.schedule(
  'sync-as400-retry-every-15min',
  '*/15 * * * *',
  $$
  SELECT net.http_post(
    url:='https://ytkofsktbkuzgzhzhiys.supabase.co/functions/v1/sync-as400-retry',
    headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl0a29mc2t0Ymt1emd6aHpoaXlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjkwODg5NTQsImV4cCI6MjA4NDY2NDk1NH0.U9qC8eC_zm8tBWVk1VpmOUp-KZVM2q_KNEQa_40HeGU"}'::jsonb,
    body:='{"scheduled": true}'::jsonb
  ) AS request_id;
  $$
);
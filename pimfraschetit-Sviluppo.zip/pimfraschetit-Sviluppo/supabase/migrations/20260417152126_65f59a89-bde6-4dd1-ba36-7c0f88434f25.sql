CREATE OR REPLACE FUNCTION public.search_articles(query text, filter_clmer text DEFAULT NULL::text, filter_lipro text DEFAULT NULL::text, filter_wfuas text DEFAULT NULL::text, lim integer DEFAULT 100, off integer DEFAULT 0)
 RETURNS TABLE(id uuid, cdpar text, depar text, clmer text, lipro text, pcfor text, unmis text, as400_sync_status text, wfuas text, barcd text, updated_at timestamp with time zone, total_count bigint)
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'public'
AS $function$
DECLARE
  normalized text;
  tsq tsquery;
  like_pattern text;
BEGIN
  normalized := trim(lower(query));
  like_pattern := '%' || normalized || '%';
  PERFORM set_limit(0.15);
  BEGIN
    tsq := plainto_tsquery('italian', normalized);
  EXCEPTION WHEN OTHERS THEN
    tsq := NULL;
  END;

  RETURN QUERY
  WITH matches AS (
    SELECT 
      a.id, a.cdpar, a.depar, a.clmer, a.lipro, a.pcfor, a.unmis,
      a.as400_sync_status, a.wfuas, a.barcd, a.updated_at,
      (
        CASE WHEN lower(a.cdpar) = normalized THEN 2000.0
             WHEN lower(trim(a.cdpar)) = normalized THEN 2000.0
             WHEN a.cdpar ILIKE normalized || '%' THEN 800.0
             WHEN trim(a.cdpar) ILIKE normalized || '%' THEN 800.0
             ELSE 0 END +
        CASE WHEN lower(a.barcd) = normalized THEN 1500.0
             WHEN a.barcd ILIKE like_pattern THEN 300.0
             ELSE 0 END +
        CASE WHEN lower(a.depar) LIKE normalized || '%' THEN 200.0
             WHEN a.depar ILIKE like_pattern THEN 100.0
             ELSE 0 END +
        COALESCE(similarity(a.depar, normalized), 0) * 50.0 +
        COALESCE(similarity(coalesce(a.nmcat,''), normalized), 0) * 20.0 +
        CASE WHEN tsq IS NOT NULL AND a.fts @@ tsq 
             THEN ts_rank(a.fts, tsq) * 10.0 ELSE 0 END
      ) AS rank
    FROM archivio_articoli_fraschetti a
    WHERE (
      lower(a.cdpar) = normalized
      OR lower(trim(a.cdpar)) = normalized
      OR a.cdpar ILIKE normalized || '%'
      OR trim(a.cdpar) ILIKE normalized || '%'
      OR a.barcd ILIKE like_pattern
      OR a.depar ILIKE like_pattern
      OR a.nmcat ILIKE like_pattern
      OR a.depar % normalized
      OR (tsq IS NOT NULL AND a.fts @@ tsq)
    )
    AND (filter_clmer IS NULL OR a.clmer = filter_clmer)
    AND (filter_lipro IS NULL OR a.lipro = filter_lipro)
    AND (filter_wfuas IS NULL OR a.wfuas = filter_wfuas)
  )
  SELECT 
    m.id, m.cdpar, m.depar, m.clmer, m.lipro, 
    m.pcfor, m.unmis, m.as400_sync_status, m.wfuas, m.barcd, m.updated_at,
    (count(*) OVER ())::bigint AS total_count
  FROM matches m
  ORDER BY m.rank DESC, m.cdpar ASC
  LIMIT lim OFFSET off;
END;
$function$;
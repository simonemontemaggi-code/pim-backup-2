-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can view pim-media" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated can upload to pim-media" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated can delete from pim-media" ON storage.objects;

-- Read: all authenticated users can read all files
CREATE POLICY "Authenticated can read pim-media"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'pim-media');

-- Upload: authenticated users can upload to article paths only
CREATE POLICY "Authenticated can upload to pim-media"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'pim-media'
  AND (storage.foldername(name))[1] = 'articles'
);

-- Delete: only admins can delete files
CREATE POLICY "Admins can delete from pim-media"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'pim-media'
  AND public.is_admin(auth.uid())
);
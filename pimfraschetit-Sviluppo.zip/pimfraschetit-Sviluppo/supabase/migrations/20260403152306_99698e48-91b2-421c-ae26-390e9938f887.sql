
CREATE OR REPLACE FUNCTION public.sync_media_from_storage()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_inserted int := 0;
  v_updated int := 0;
  v_total int := 0;
  v_result jsonb;
BEGIN
  -- Single query: read storage.objects, parse paths, join with articles, upsert into article_media
  WITH storage_files AS (
    SELECT
      name AS storage_path,
      -- Extract cdpar from structured path: articles/{cdpar}/{sub}/{filename}
      CASE
        WHEN name ~ '^articles/([^/]+)/[^/]+/[^/]+$'
          THEN (regexp_match(name, '^articles/([^/]+)/'))[1]
        ELSE NULL
      END AS cdpar,
      -- Extract subfolder to determine media_type
      CASE
        WHEN name ~ '^articles/[^/]+/images/' THEN 'image'
        WHEN name ~ '^articles/[^/]+/datasheets/' THEN 'pdf_datasheet'
        WHEN name ~ '^articles/[^/]+/safety/' THEN 'pdf_safety'
        WHEN name ~ '^articles/[^/]+/docs/' THEN 'document'
        ELSE NULL
      END AS media_type,
      -- Extract progressive number from filename
      CASE
        WHEN name ~ '_(\d+)\.[^.]+$'
          THEN (regexp_match(name, '_(\d+)\.[^.]+$'))[1]::int
        ELSE 1
      END AS progressive,
      -- Original filename
      regexp_replace(name, '^.*/', '') AS original_filename,
      -- File size from metadata
      (metadata->>'size')::int AS file_size
    FROM storage.objects
    WHERE bucket_id = 'pim-media'
      AND name ~ '^articles/[^/]+/[^/]+/[^/]+$'
      AND name !~ '/\.emptyFolderPlaceholder$'
  ),
  valid_files AS (
    SELECT
      sf.storage_path,
      sf.cdpar,
      sf.media_type,
      sf.progressive,
      sf.original_filename,
      sf.file_size
    FROM storage_files sf
    INNER JOIN archivio_articoli_fraschetti a ON a.cdpar = sf.cdpar
    WHERE sf.cdpar IS NOT NULL
      AND sf.media_type IS NOT NULL
  ),
  upserted AS (
    INSERT INTO article_media (cdpar, media_type, storage_path, public_url, original_filename, file_size, is_primary, progressive, sort_order)
    SELECT
      vf.cdpar,
      vf.media_type,
      vf.storage_path,
      'https://ytkofsktbkuzgzhzhiys.supabase.co/storage/v1/object/public/pim-media/' || vf.storage_path,
      vf.original_filename,
      vf.file_size,
      (vf.media_type = 'image' AND vf.progressive = 1),
      vf.progressive,
      vf.progressive
    FROM valid_files vf
    ON CONFLICT (storage_path) DO UPDATE SET
      cdpar = EXCLUDED.cdpar,
      media_type = EXCLUDED.media_type,
      public_url = EXCLUDED.public_url,
      original_filename = EXCLUDED.original_filename,
      file_size = EXCLUDED.file_size,
      is_primary = EXCLUDED.is_primary,
      progressive = EXCLUDED.progressive,
      sort_order = EXCLUDED.sort_order,
      updated_at = now()
    RETURNING (xmax = 0) AS was_inserted
  )
  SELECT
    count(*) FILTER (WHERE was_inserted) AS ins,
    count(*) FILTER (WHERE NOT was_inserted) AS upd,
    count(*) AS tot
  INTO v_inserted, v_updated, v_total
  FROM upserted;

  RETURN jsonb_build_object(
    'success', true,
    'inserted', v_inserted,
    'updated', v_updated,
    'total', v_total
  );
END;
$$;

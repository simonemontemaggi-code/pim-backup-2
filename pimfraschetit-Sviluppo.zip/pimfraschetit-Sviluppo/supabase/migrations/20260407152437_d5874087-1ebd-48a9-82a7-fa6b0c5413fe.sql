
ALTER TABLE public.lookup_values
  ADD COLUMN parent_category text,
  ADD COLUMN parent_code text;

CREATE INDEX idx_lookup_values_parent ON public.lookup_values (parent_category, parent_code);

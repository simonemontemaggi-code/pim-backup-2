INSERT INTO lookup_values (category, code, label, synced_as400) VALUES 
  ('attributi', 'materiale', 'Materiale', false),
  ('attributi', 'colore', 'Colore', false),
  ('attributi', 'dimensioni', 'Dimensioni', false),
  ('attributi', 'peso', 'Peso', false),
  ('attributi', 'origine', 'Paese di Origine', false)
ON CONFLICT DO NOTHING;
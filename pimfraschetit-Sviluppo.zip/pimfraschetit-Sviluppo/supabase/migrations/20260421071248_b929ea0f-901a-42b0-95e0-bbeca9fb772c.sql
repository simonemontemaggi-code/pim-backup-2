ALTER TABLE public.archivio_articoli_fraschetti ADD COLUMN IF NOT EXISTS cod_padre TEXT;
COMMENT ON COLUMN public.archivio_articoli_fraschetti.cod_padre IS 'Codice Padre (6 cifre, zeri leading preservati)';
CREATE INDEX IF NOT EXISTS idx_articoli_cod_padre ON public.archivio_articoli_fraschetti(cod_padre);
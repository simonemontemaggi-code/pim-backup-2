
-- Indexes for faster filtering and lookups
CREATE INDEX IF NOT EXISTS idx_aaf_cdpar ON public.archivio_articoli_fraschetti (cdpar);
CREATE INDEX IF NOT EXISTS idx_aaf_wfuas ON public.archivio_articoli_fraschetti (wfuas);
CREATE INDEX IF NOT EXISTS idx_aaf_clmer ON public.archivio_articoli_fraschetti (clmer);
CREATE INDEX IF NOT EXISTS idx_aaf_lipro ON public.archivio_articoli_fraschetti (lipro);
CREATE INDEX IF NOT EXISTS idx_aaf_fts ON public.archivio_articoli_fraschetti USING gin (fts);
CREATE INDEX IF NOT EXISTS idx_aaf_depar_trgm ON public.archivio_articoli_fraschetti USING gin (depar gin_trgm_ops);

-- Composite index for common filter combo
CREATE INDEX IF NOT EXISTS idx_aaf_wfuas_cdpar ON public.archivio_articoli_fraschetti (wfuas, cdpar);

-- Fast distinct values function
CREATE OR REPLACE FUNCTION public.distinct_column_values(col_name text)
RETURNS text[]
LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result text[];
BEGIN
  CASE col_name
    WHEN 'clmer' THEN
      SELECT array_agg(DISTINCT clmer ORDER BY clmer)
      INTO result
      FROM archivio_articoli_fraschetti
      WHERE clmer IS NOT NULL;
    WHEN 'lipro' THEN
      SELECT array_agg(DISTINCT lipro ORDER BY lipro)
      INTO result
      FROM archivio_articoli_fraschetti
      WHERE lipro IS NOT NULL;
    WHEN 'wfuas' THEN
      SELECT array_agg(DISTINCT wfuas ORDER BY wfuas)
      INTO result
      FROM archivio_articoli_fraschetti
      WHERE wfuas IS NOT NULL;
    ELSE
      result := ARRAY[]::text[];
  END CASE;
  RETURN result;
END;
$$;

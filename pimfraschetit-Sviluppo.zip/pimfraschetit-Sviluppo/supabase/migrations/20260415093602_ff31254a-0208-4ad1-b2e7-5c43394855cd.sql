
CREATE OR REPLACE FUNCTION public.count_articles_with_media_filtered(assortments text[] DEFAULT NULL)
RETURNS integer
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(DISTINCT am.cdpar)::integer
  FROM article_media am
  WHERE (assortments IS NULL OR EXISTS (
    SELECT 1 FROM archivio_articoli_fraschetti a
    WHERE a.cdpar = am.cdpar AND a.wfuas = ANY(assortments)
  ));
$$;

ALTER TABLE public.archivio_articoli_fraschetti
  ADD COLUMN IF NOT EXISTS titolo_b2b text,
  ADD COLUMN IF NOT EXISTS descrizione_b2b text;
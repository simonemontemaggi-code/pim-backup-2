INSERT INTO public.lookup_values (category, code, label, sort_order, is_active, synced_as400)
SELECT 'clas2', TRIM(clas2), TRIM(clas2), 0, true, true
FROM public.archivio_articoli_fraschetti
WHERE clas2 IS NOT NULL AND TRIM(clas2) <> ''
GROUP BY TRIM(clas2)
ON CONFLICT DO NOTHING;
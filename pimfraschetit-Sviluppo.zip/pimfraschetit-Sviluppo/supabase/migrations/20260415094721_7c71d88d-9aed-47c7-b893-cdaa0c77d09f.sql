
ALTER TABLE public.archivio_fornitori_fraschetti
  ADD COLUMN buyer text,
  ADD COLUMN demand_planner text;


DROP FUNCTION IF EXISTS public.search_articles(text, text, text, integer, integer);

CREATE OR REPLACE FUNCTION public.search_articles(query text, filter_clmer text DEFAULT NULL::text, filter_lipro text DEFAULT NULL::text, lim integer DEFAULT 100, off integer DEFAULT 0)
 RETURNS TABLE(id uuid, cdpar text, depar text, clmer text, lipro text, pcfor text, unmis text, as400_sync_status text, barcd text, updated_at timestamp with time zone, total_count bigint)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  normalized text;
  tsq tsquery;
BEGIN
  normalized := trim(lower(query));
  PERFORM set_limit(0.15);
  BEGIN
    tsq := plainto_tsquery('italian', normalized);
  EXCEPTION WHEN OTHERS THEN
    tsq := NULL;
  END;

  RETURN QUERY
  WITH matches AS (
    SELECT 
      a.id,
      a.cdpar,
      a.depar,
      a.clmer,
      a.lipro,
      a.pcfor,
      a.unmis,
      a.as400_sync_status,
      a.barcd,
      a.updated_at,
      (
        COALESCE(similarity(a.cdpar, normalized), 0) * 2.0 +
        COALESCE(similarity(a.depar, normalized), 0) +
        CASE WHEN tsq IS NOT NULL AND a.fts @@ tsq 
             THEN ts_rank(a.fts, tsq) * 3.0 
             ELSE 0 END
      ) AS rank
    FROM archivio_articoli_fraschetti a
    WHERE (
      a.cdpar % normalized 
      OR a.depar % normalized
      OR a.cdpar ILIKE '%' || normalized || '%'
      OR a.depar ILIKE '%' || normalized || '%'
      OR (tsq IS NOT NULL AND a.fts @@ tsq)
    )
    AND (filter_clmer IS NULL OR a.clmer = filter_clmer)
    AND (filter_lipro IS NULL OR a.lipro = filter_lipro)
  )
  SELECT 
    m.id, m.cdpar, m.depar, m.clmer, m.lipro, 
    m.pcfor, m.unmis, m.as400_sync_status, m.barcd, m.updated_at,
    (count(*) OVER ())::bigint AS total_count
  FROM matches m
  ORDER BY m.rank DESC, m.cdpar ASC
  LIMIT lim OFFSET off;
END;
$function$;

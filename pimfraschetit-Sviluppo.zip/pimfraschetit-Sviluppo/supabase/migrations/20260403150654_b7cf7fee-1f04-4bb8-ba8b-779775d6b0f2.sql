
-- Add unique constraint on storage_path for upsert support
ALTER TABLE public.article_media
  ADD CONSTRAINT article_media_storage_path_unique UNIQUE (storage_path);

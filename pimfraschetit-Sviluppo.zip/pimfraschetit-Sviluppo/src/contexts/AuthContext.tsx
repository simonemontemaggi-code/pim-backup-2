import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { ssoTokenManager } from "@/lib/sso-supabase-client";
import { processSSOFromUrlIfAny } from "@/hooks/useSSO";

export type SectionKey =
  | "pim_dashboard"
  | "articles_registry" | "articles_pricing" | "articles_logistics"
  | "articles_units" | "articles_purchase"
  | "articles_marketing" | "suppliers" | "price_lists" | "barcodes"
  | "media_library" | "as400_sync" | "import_export" | "users_admin" | "admin_reports"
  | "import_una_tantum" | "import_documentazione" | "import_giornaliera" | "import_clienti" | "import_assortimenti" | "import_temp"
  | "b2b_content"
  | "b2b_brands" | "b2b_catalogs" | "b2b_hero_slider" | "b2b_promo_settori"
  | "b2b_assortments" | "b2b_novita" | "b2b_taxonomy" | "b2b_promo_order" | "b2b_communications"
  | "b2b_tickets_ordini"
  | "b2b_tickets_contabile"
  | "b2b_tickets_tecnico"
  | "b2b_tickets_commerciale"
  | "b2b_tickets_annullamento"
  | "b2b_tickets_post_vendita"
  | "b2b_tickets_portale"
  | "b2b_tickets_altro"
  | "agent_news"
  | "promo_strutturate" | "customers" | "customer_requests" | "agents"
  | "sales_dashboard" | "sales_orders" | "sales_untreated" | "sales_promo_control" | "purchases_untreated" | "scadenziario"
  | "navigation_analysis" | "portal_adoption"
  | "operations_controls" | "controls_articoli_content" | "controls_articoli_classificazione"
  | "controls_fornitori_brand" | "controls_prezzi";

type Permission = "hidden" | "read" | "write";
type FieldPermission = "hidden" | "read" | "write" | "inherit";
export type ActionKey = "create" | "delete" | "publish" | "confirm_payment" | "download_orders";
type ActionPermMap = Record<string, Partial<Record<ActionKey, boolean>>>;

interface UserProfile {
  id: string;
  user_id: string;
  email: string;
  full_name: string;
  avatar_url: string | null;
  department_id: string | null;
}

interface AuthState {
  session: Session | null;
  user: User | null;
  profile: UserProfile | null;
  role: string | null;
  departmentName: string | null;
  permissions: Record<string, Permission>;
  fieldPermissions: Record<string, Record<string, FieldPermission>>;
  actionPermissions: ActionPermMap;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthState>({} as AuthState);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [role, setRole] = useState<string | null>(null);
  const [departmentName, setDepartmentName] = useState<string | null>(null);
  const [permissions, setPermissions] = useState<Record<string, Permission>>({});
  const [fieldPermissions, setFieldPermissions] = useState<Record<string, Record<string, FieldPermission>>>({});
  const [actionPermissions, setActionPermissions] = useState<ActionPermMap>({});
  const [loading, setLoading] = useState(true);

  const loadUserData = useCallback(async (userId: string) => {
    try {
      // Fetch profile
      const { data: prof } = await supabase
        .from("profiles")
        .select("id, user_id, email, full_name, avatar_url, department_id")
        .eq("user_id", userId)
        .single();

      if (!prof) {
        setProfile(null);
        setLoading(false);
        return;
      }
      setProfile(prof as UserProfile);

      // Fetch role
      const { data: roleData } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId)
        .single();
      setRole(roleData?.role ?? "viewer");

      // Fetch ALL departments of the user (permissions = union of all)
      const { data: deptLinks } = await supabase
        .from("user_departments")
        .select("department_id, is_primary")
        .eq("user_id", userId);

      const deptIds = Array.from(
        new Set(
          (deptLinks ?? [])
            .map((d: any) => d.department_id as string)
            .concat(prof.department_id ? [prof.department_id as string] : [])
            .filter(Boolean)
        )
      );

      const primaryDeptId =
        (deptLinks ?? []).find((d: any) => d.is_primary)?.department_id ??
        prof.department_id ??
        deptIds[0];

      if (deptIds.length > 0) {
        if (primaryDeptId) {
          const { data: dept } = await supabase
            .from("departments")
            .select("name")
            .eq("id", primaryDeptId)
            .single();
          setDepartmentName(dept?.name ?? null);
        }

        // Fetch section permissions for all departments + role
        const effectiveRole = (roleData?.role ?? "viewer") as string;
        const roleFilter = ["manager", "assistant_manager", "collaborator", "viewer"].includes(effectiveRole)
          ? effectiveRole
          : "manager";
        const { data: perms } = await supabase
          .from("section_permissions")
          .select("section_key, permission")
          .in("department_id", deptIds)
          .eq("role", roleFilter as any);

        // Merge: most permissive wins (write > read > hidden)
        const rank: Record<string, number> = { hidden: 0, read: 1, write: 2 };
        const permMap: Record<string, Permission> = {};
        perms?.forEach((p: any) => {
          const current = permMap[p.section_key];
          if (!current || (rank[p.permission] ?? 0) > (rank[current] ?? 0)) {
            permMap[p.section_key] = p.permission as Permission;
          }
        });


        // Admin role gets write everywhere
        if (roleData?.role === "admin") {
          const allSections: SectionKey[] = [
            "pim_dashboard",
            "articles_registry", "articles_pricing", "articles_logistics",
            "articles_units", "articles_purchase",
            "articles_marketing", "suppliers", "price_lists", "barcodes",
            "media_library", "as400_sync", "import_export", "users_admin", "admin_reports",
            "import_una_tantum", "import_documentazione", "import_giornaliera", "import_clienti", "import_assortimenti", "import_temp",
            "b2b_content",
            "b2b_brands", "b2b_catalogs", "b2b_hero_slider", "b2b_promo_settori",
            "b2b_assortments", "b2b_novita", "b2b_taxonomy", "b2b_promo_order", "b2b_communications",
            "b2b_tickets_ordini", "b2b_tickets_contabile", "b2b_tickets_tecnico", "b2b_tickets_commerciale", "b2b_tickets_annullamento", "b2b_tickets_post_vendita", "b2b_tickets_portale", "b2b_tickets_altro",
            "agent_news",
            "promo_strutturate", "customers", "customer_requests", "agents",
            "sales_dashboard", "sales_orders", "sales_untreated", "purchases_untreated", "scadenziario",
            "navigation_analysis", "portal_adoption",
          ];
          allSections.forEach((s) => { permMap[s] = "write"; });
        }

        setPermissions(permMap);

        // Fetch field-level permissions
        const { data: fieldPerms } = await supabase
          .from("field_permissions")
          .select("section_key, field_key, permission")
          .in("department_id", deptIds)
          .eq("role", roleFilter as any);


        const fieldMap: Record<string, Record<string, FieldPermission>> = {};
        (fieldPerms ?? []).forEach((fp: any) => {
          if (!fieldMap[fp.section_key]) fieldMap[fp.section_key] = {};
          const current = fieldMap[fp.section_key][fp.field_key];
          if (!current || (rank[fp.permission] ?? 0) > (rank[current] ?? 0)) {
            fieldMap[fp.section_key][fp.field_key] = fp.permission as FieldPermission;
          }
        });
        setFieldPermissions(fieldMap);

        // Fetch action-level permissions (create/delete/publish)
        const { data: actionPerms } = await (supabase as any)
          .from("section_action_permissions")
          .select("section, action, allowed")
          .in("department_id", deptIds)
          .eq("role", roleFilter);


        const actionMap: ActionPermMap = {};
        (actionPerms ?? []).forEach((ap: any) => {
          if (!actionMap[ap.section]) actionMap[ap.section] = {};
          actionMap[ap.section][ap.action as ActionKey] =
            !!actionMap[ap.section][ap.action as ActionKey] || !!ap.allowed;
        });

        setActionPermissions(actionMap);
      }
    } catch (e) {
      console.error("Failed to load user data", e);
    } finally {
      setLoading(false);
    }
  }, []);

  // Synthesize a session-like object for SSO users (no real Supabase session,
  // but a JWT in localStorage attached by the supabase client's accessToken callback).
  const applySsoSession = useCallback(() => {
    const token = ssoTokenManager.getToken();
    const ssoUser = ssoTokenManager.getUser();
    if (!token || !ssoUser) return false;
    const synthSession = { access_token: token, user: { id: ssoUser.id, email: ssoUser.email } } as unknown as Session;
    setSession(synthSession);
    setUser({ id: ssoUser.id, email: ssoUser.email } as User);
    loadUserData(ssoUser.id);
    return true;
  }, [loadUserData]);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      // If we have a real Supabase session, it wins.
      if (session) {
        setSession(session);
        setUser(session.user ?? null);
        setTimeout(() => loadUserData(session.user.id), 0);
        return;
      }
      // No native session: fall back to SSO if present.
      if (applySsoSession()) return;
      setSession(null);
      setUser(null);
      setProfile(null);
      setRole(null);
      setDepartmentName(null);
      setPermissions({});
      setFieldPermissions({});
      setActionPermissions({});
      setLoading(false);
    });

    (async () => {
      // Ingest SSO token from URL (if hub just redirected here) BEFORE checking sessions.
      await processSSOFromUrlIfAny();
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        setSession(session);
        setUser(session.user ?? null);
        loadUserData(session.user.id);
        return;
      }
      if (applySsoSession()) return;
      setLoading(false);
    })();

    // Cross-tab SSO sync
    const onStorage = (e: StorageEvent) => {
      if (!e.key || !e.key.startsWith("sso_")) return;
      if (ssoTokenManager.hasSession()) applySsoSession();
      else if (!session) {
        setSession(null);
        setUser(null);
        setProfile(null);
      }
    };
    window.addEventListener("storage", onStorage);

    return () => {
      subscription.unsubscribe();
      window.removeEventListener("storage", onStorage);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loadUserData, applySsoSession]);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error as Error | null };
  };

  const signOut = async () => {
    ssoTokenManager.clear();
    await supabase.auth.signOut();
    setSession(null);
    setUser(null);
    setProfile(null);
  };

  return (
    <AuthContext.Provider value={{ session, user, profile, role, departmentName, permissions, fieldPermissions, actionPermissions, loading, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      adepromo: {
        Row: {
          codice: string
          created_at: string
          promo_code: string
          tipo: string
        }
        Insert: {
          codice: string
          created_at?: string
          promo_code: string
          tipo: string
        }
        Update: {
          codice?: string
          created_at?: string
          promo_code?: string
          tipo?: string
        }
        Relationships: []
      }
      agent_carts: {
        Row: {
          active_cart_index: number
          carts: Json
          created_at: string
          last_writer_client_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          active_cart_index?: number
          carts?: Json
          created_at?: string
          last_writer_client_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          active_cart_index?: number
          carts?: Json
          created_at?: string
          last_writer_client_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      agent_client_notes: {
        Row: {
          agent_user_id: string
          created_at: string
          customer_id: string
          id: string
          note: string
          updated_at: string
        }
        Insert: {
          agent_user_id: string
          created_at?: string
          customer_id: string
          id?: string
          note?: string
          updated_at?: string
        }
        Update: {
          agent_user_id?: string
          created_at?: string
          customer_id?: string
          id?: string
          note?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "agent_client_notes_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      agent_customer_lists: {
        Row: {
          agent_user_id: string
          created_at: string
          customer_codes: string[]
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          agent_user_id: string
          created_at?: string
          customer_codes?: string[]
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          agent_user_id?: string
          created_at?: string
          customer_codes?: string[]
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      agent_otp_attempts: {
        Row: {
          created_at: string
          id: string
          ip: unknown
          kind: string
          reason: string | null
          success: boolean
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          ip?: unknown
          kind: string
          reason?: string | null
          success?: boolean
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          ip?: unknown
          kind?: string
          reason?: string | null
          success?: boolean
          user_id?: string | null
        }
        Relationships: []
      }
      agent_otp_login_locations: {
        Row: {
          city: string | null
          country: string | null
          created_at: string
          device_id: string | null
          id: string
          ip: unknown
          lat: number | null
          lon: number | null
          region: string | null
          user_id: string
        }
        Insert: {
          city?: string | null
          country?: string | null
          created_at?: string
          device_id?: string | null
          id?: string
          ip?: unknown
          lat?: number | null
          lon?: number | null
          region?: string | null
          user_id: string
        }
        Update: {
          city?: string | null
          country?: string | null
          created_at?: string
          device_id?: string | null
          id?: string
          ip?: unknown
          lat?: number | null
          lon?: number | null
          region?: string | null
          user_id?: string
        }
        Relationships: []
      }
      agent_otp_trusted_devices: {
        Row: {
          created_at: string
          device_id: string
          last_ip: unknown
          last_verified_at: string
          updated_at: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          device_id: string
          last_ip?: unknown
          last_verified_at?: string
          updated_at?: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          device_id?: string
          last_ip?: unknown
          last_verified_at?: string
          updated_at?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      agent_quote_items: {
        Row: {
          applied_promo: string | null
          created_at: string
          discount_pct: number | null
          id: string
          is_omaggio: boolean
          manual_discount_pct: number | null
          manual_net_price: number | null
          net_price: number | null
          position: number
          product_id: string
          product_name: string | null
          product_sku: string | null
          product_snapshot: Json | null
          promo_snapshot: Json | null
          quantity: number
          quote_id: string
          unit_price: number
          variant_code: string | null
          variant_description: string | null
          variant_id: string | null
          variant_price: number | null
        }
        Insert: {
          applied_promo?: string | null
          created_at?: string
          discount_pct?: number | null
          id?: string
          is_omaggio?: boolean
          manual_discount_pct?: number | null
          manual_net_price?: number | null
          net_price?: number | null
          position?: number
          product_id: string
          product_name?: string | null
          product_sku?: string | null
          product_snapshot?: Json | null
          promo_snapshot?: Json | null
          quantity?: number
          quote_id: string
          unit_price?: number
          variant_code?: string | null
          variant_description?: string | null
          variant_id?: string | null
          variant_price?: number | null
        }
        Update: {
          applied_promo?: string | null
          created_at?: string
          discount_pct?: number | null
          id?: string
          is_omaggio?: boolean
          manual_discount_pct?: number | null
          manual_net_price?: number | null
          net_price?: number | null
          position?: number
          product_id?: string
          product_name?: string | null
          product_sku?: string | null
          product_snapshot?: Json | null
          promo_snapshot?: Json | null
          quantity?: number
          quote_id?: string
          unit_price?: number
          variant_code?: string | null
          variant_description?: string | null
          variant_id?: string | null
          variant_price?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "agent_quote_items_quote_id_fkey"
            columns: ["quote_id"]
            isOneToOne: false
            referencedRelation: "agent_quotes"
            referencedColumns: ["id"]
          },
        ]
      }
      agent_quotes: {
        Row: {
          agent_user_id: string
          created_at: string
          customer_id: string
          grand_total: number
          id: string
          include_description: boolean
          note: string | null
          number: string
          status: string
          updated_at: string
          valid_until: string | null
        }
        Insert: {
          agent_user_id: string
          created_at?: string
          customer_id: string
          grand_total?: number
          id?: string
          include_description?: boolean
          note?: string | null
          number: string
          status?: string
          updated_at?: string
          valid_until?: string | null
        }
        Update: {
          agent_user_id?: string
          created_at?: string
          customer_id?: string
          grand_total?: number
          id?: string
          include_description?: boolean
          note?: string | null
          number?: string
          status?: string
          updated_at?: string
          valid_until?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "agent_quotes_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_generations: {
        Row: {
          applied_fields: string[] | null
          cdpar: string | null
          created_at: string
          duration_ms: number | null
          error_message: string | null
          field: string
          id: string
          input_payload: Json | null
          model: string
          output_parsed: Json | null
          output_text: string | null
          prompt_key: string
          status: string
          tokens_completion: number | null
          tokens_prompt: number | null
          user_email: string | null
          user_id: string | null
        }
        Insert: {
          applied_fields?: string[] | null
          cdpar?: string | null
          created_at?: string
          duration_ms?: number | null
          error_message?: string | null
          field: string
          id?: string
          input_payload?: Json | null
          model: string
          output_parsed?: Json | null
          output_text?: string | null
          prompt_key: string
          status?: string
          tokens_completion?: number | null
          tokens_prompt?: number | null
          user_email?: string | null
          user_id?: string | null
        }
        Update: {
          applied_fields?: string[] | null
          cdpar?: string | null
          created_at?: string
          duration_ms?: number | null
          error_message?: string | null
          field?: string
          id?: string
          input_payload?: Json | null
          model?: string
          output_parsed?: Json | null
          output_text?: string | null
          prompt_key?: string
          status?: string
          tokens_completion?: number | null
          tokens_prompt?: number | null
          user_email?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      ai_prompt_versions: {
        Row: {
          changed_at: string
          changed_by: string | null
          id: string
          max_tokens: number
          model: string
          prompt_id: string
          system_prompt: string
          temperature: number
          user_prompt_template: string
        }
        Insert: {
          changed_at?: string
          changed_by?: string | null
          id?: string
          max_tokens: number
          model: string
          prompt_id: string
          system_prompt: string
          temperature: number
          user_prompt_template: string
        }
        Update: {
          changed_at?: string
          changed_by?: string | null
          id?: string
          max_tokens?: number
          model?: string
          prompt_id?: string
          system_prompt?: string
          temperature?: number
          user_prompt_template?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_prompt_versions_prompt_id_fkey"
            columns: ["prompt_id"]
            isOneToOne: false
            referencedRelation: "ai_prompts"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_prompts: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          key: string
          label: string
          max_tokens: number
          model: string
          system_prompt: string
          temperature: number
          updated_at: string
          updated_by: string | null
          user_prompt_template: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          key: string
          label: string
          max_tokens?: number
          model?: string
          system_prompt: string
          temperature?: number
          updated_at?: string
          updated_by?: string | null
          user_prompt_template: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          key?: string
          label?: string
          max_tokens?: number
          model?: string
          system_prompt?: string
          temperature?: number
          updated_at?: string
          updated_by?: string | null
          user_prompt_template?: string
        }
        Relationships: []
      }
      anag_art_fornitore_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      app_permissions: {
        Row: {
          access_level: Database["public"]["Enums"]["access_level"]
          app_id: string
          created_at: string
          entity_id: string
          entity_type: Database["public"]["Enums"]["entity_type"]
          id: string
          ui_permission_config: Json | null
          updated_at: string
        }
        Insert: {
          access_level?: Database["public"]["Enums"]["access_level"]
          app_id: string
          created_at?: string
          entity_id: string
          entity_type: Database["public"]["Enums"]["entity_type"]
          id?: string
          ui_permission_config?: Json | null
          updated_at?: string
        }
        Update: {
          access_level?: Database["public"]["Enums"]["access_level"]
          app_id?: string
          created_at?: string
          entity_id?: string
          entity_type?: Database["public"]["Enums"]["entity_type"]
          id?: string
          ui_permission_config?: Json | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "app_permissions_app_id_fkey"
            columns: ["app_id"]
            isOneToOne: false
            referencedRelation: "apps"
            referencedColumns: ["id"]
          },
        ]
      }
      app_settings: {
        Row: {
          created_at: string
          id: string
          setting_key: string
          setting_value: Json
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          setting_key: string
          setting_value?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          setting_key?: string
          setting_value?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      apps: {
        Row: {
          app_type: Database["public"]["Enums"]["app_type"]
          category: string | null
          created_at: string
          description: string | null
          external_url: string | null
          icon: string | null
          icon_type: Database["public"]["Enums"]["icon_type"]
          id: string
          internal_route: string | null
          is_active: boolean
          name: string
          sort_order: number | null
          updated_at: string
        }
        Insert: {
          app_type?: Database["public"]["Enums"]["app_type"]
          category?: string | null
          created_at?: string
          description?: string | null
          external_url?: string | null
          icon?: string | null
          icon_type?: Database["public"]["Enums"]["icon_type"]
          id?: string
          internal_route?: string | null
          is_active?: boolean
          name: string
          sort_order?: number | null
          updated_at?: string
        }
        Update: {
          app_type?: Database["public"]["Enums"]["app_type"]
          category?: string | null
          created_at?: string
          description?: string | null
          external_url?: string | null
          icon?: string | null
          icon_type?: Database["public"]["Enums"]["icon_type"]
          id?: string
          internal_route?: string | null
          is_active?: boolean
          name?: string
          sort_order?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      archivio_anag_art_fornitore: {
        Row: {
          avpaf: string | null
          cdfor: string | null
          cdiva: string | null
          cdpar: string
          cdpfo: string | null
          cdrif: string | null
          cdval: string | null
          cicqu: string | null
          created_at: string
          dainf: string | null
          dainp: string | null
          dauar: string | null
          daulp: string | null
          davpf: string | null
          daz01: string | null
          dtz01: string | null
          famco: string | null
          fmarc: string | null
          freep: string | null
          ftimb: number | null
          gifor: string | null
          gimri: string | null
          id: string
          lotto: string | null
          ltprv: string | null
          notef: string | null
          nrifo: number | null
          nrz01: string | null
          prull: number | null
          qsc2f: number | null
          qsc2p: number | null
          qscaf: number | null
          qscap: number | null
          qta2g: number | null
          qtagg: number | null
          qtmio: number | null
          qtr2f: number | null
          qtr2p: number | null
          qtrif: number | null
          qtrip: number | null
          quotf: number | null
          scon1: number | null
          scon2: number | null
          scon3: number | null
          setlg: string | null
          targ1: number | null
          targ2: number | null
          targ3: number | null
          temco: string | null
          tpimb: string | null
          umfaf: number | null
          umord: string | null
          unimb: string | null
          updated_at: string
          usorc: string | null
          valfo: string | null
          vapfo: string | null
          vaq2o: number | null
          vaqfo: number | null
          varic: number | null
          varip: number | null
          vricc: number | null
          vricn: number | null
          vripc: number | null
          vripn: number | null
          vrsnmb: string | null
          wcute: string | null
          wfacq: string | null
          wflfo: string | null
          wimbf: number | null
          wperspf: string | null
          wqtde: string | null
          wtaim: string | null
          wumim: string | null
          wumqm: string | null
          wumso: string | null
          wviim: string | null
          wviqm: string | null
        }
        Insert: {
          avpaf?: string | null
          cdfor?: string | null
          cdiva?: string | null
          cdpar: string
          cdpfo?: string | null
          cdrif?: string | null
          cdval?: string | null
          cicqu?: string | null
          created_at?: string
          dainf?: string | null
          dainp?: string | null
          dauar?: string | null
          daulp?: string | null
          davpf?: string | null
          daz01?: string | null
          dtz01?: string | null
          famco?: string | null
          fmarc?: string | null
          freep?: string | null
          ftimb?: number | null
          gifor?: string | null
          gimri?: string | null
          id?: string
          lotto?: string | null
          ltprv?: string | null
          notef?: string | null
          nrifo?: number | null
          nrz01?: string | null
          prull?: number | null
          qsc2f?: number | null
          qsc2p?: number | null
          qscaf?: number | null
          qscap?: number | null
          qta2g?: number | null
          qtagg?: number | null
          qtmio?: number | null
          qtr2f?: number | null
          qtr2p?: number | null
          qtrif?: number | null
          qtrip?: number | null
          quotf?: number | null
          scon1?: number | null
          scon2?: number | null
          scon3?: number | null
          setlg?: string | null
          targ1?: number | null
          targ2?: number | null
          targ3?: number | null
          temco?: string | null
          tpimb?: string | null
          umfaf?: number | null
          umord?: string | null
          unimb?: string | null
          updated_at?: string
          usorc?: string | null
          valfo?: string | null
          vapfo?: string | null
          vaq2o?: number | null
          vaqfo?: number | null
          varic?: number | null
          varip?: number | null
          vricc?: number | null
          vricn?: number | null
          vripc?: number | null
          vripn?: number | null
          vrsnmb?: string | null
          wcute?: string | null
          wfacq?: string | null
          wflfo?: string | null
          wimbf?: number | null
          wperspf?: string | null
          wqtde?: string | null
          wtaim?: string | null
          wumim?: string | null
          wumqm?: string | null
          wumso?: string | null
          wviim?: string | null
          wviqm?: string | null
        }
        Update: {
          avpaf?: string | null
          cdfor?: string | null
          cdiva?: string | null
          cdpar?: string
          cdpfo?: string | null
          cdrif?: string | null
          cdval?: string | null
          cicqu?: string | null
          created_at?: string
          dainf?: string | null
          dainp?: string | null
          dauar?: string | null
          daulp?: string | null
          davpf?: string | null
          daz01?: string | null
          dtz01?: string | null
          famco?: string | null
          fmarc?: string | null
          freep?: string | null
          ftimb?: number | null
          gifor?: string | null
          gimri?: string | null
          id?: string
          lotto?: string | null
          ltprv?: string | null
          notef?: string | null
          nrifo?: number | null
          nrz01?: string | null
          prull?: number | null
          qsc2f?: number | null
          qsc2p?: number | null
          qscaf?: number | null
          qscap?: number | null
          qta2g?: number | null
          qtagg?: number | null
          qtmio?: number | null
          qtr2f?: number | null
          qtr2p?: number | null
          qtrif?: number | null
          qtrip?: number | null
          quotf?: number | null
          scon1?: number | null
          scon2?: number | null
          scon3?: number | null
          setlg?: string | null
          targ1?: number | null
          targ2?: number | null
          targ3?: number | null
          temco?: string | null
          tpimb?: string | null
          umfaf?: number | null
          umord?: string | null
          unimb?: string | null
          updated_at?: string
          usorc?: string | null
          valfo?: string | null
          vapfo?: string | null
          vaq2o?: number | null
          vaqfo?: number | null
          varic?: number | null
          varip?: number | null
          vricc?: number | null
          vricn?: number | null
          vripc?: number | null
          vripn?: number | null
          vrsnmb?: string | null
          wcute?: string | null
          wfacq?: string | null
          wflfo?: string | null
          wimbf?: number | null
          wperspf?: string | null
          wqtde?: string | null
          wtaim?: string | null
          wumim?: string | null
          wumqm?: string | null
          wumso?: string | null
          wviim?: string | null
          wviqm?: string | null
        }
        Relationships: []
      }
      archivio_articoli_fraschetti: {
        Row: {
          agcic: string | null
          as400_sync_status: string | null
          attributes: Json | null
          b2b_content_updated_at: string | null
          b2b_first_published_at: string | null
          b2b_online_active: boolean | null
          b2b_online_effective: boolean
          b2b_product_description: string | null
          b2b_product_title: string | null
          barcd: string | null
          cat_id: string | null
          cat_id_2: string | null
          catalogo_carta_dettaglio: string | null
          catalogo_carta_scheda: string | null
          catalogo_carta_titolo: string | null
          ccndi: string | null
          cdiva: string | null
          cdpaf: string | null
          cdpar: string
          cdrga: string | null
          cdst1: string | null
          cdst2: string | null
          cdst3: string | null
          cecoa: string | null
          cenco: string | null
          ceric: string | null
          cfcal: number | null
          clapp: string | null
          clas1: string | null
          clas2: string | null
          clmer: string | null
          cmltc: number | null
          cod_padre: string | null
          conac: string | null
          conem: string | null
          cprop: string | null
          created_at: string
          crevd: string | null
          crimp: string | null
          crimt: string | null
          crrio: string | null
          crtpr: string | null
          daa26: string | null
          depar: string | null
          description_ecommerce: string | null
          description_marketing: string | null
          descrizione: string | null
          descrizione_b2b: string | null
          descrizione_variante: string | null
          dtac5: string | null
          dtcic: string | null
          dtltc: string | null
          dtstr: string | null
          dvrif: string | null
          escam: string | null
          evadi: string | null
          flglo: string | null
          flscr: string | null
          fts: unknown
          fts_simple: unknown
          gprop: number | null
          hlvmn: number | null
          id: string
          indgc: string | null
          lipro: string | null
          livmn: number | null
          master_pack: number | null
          mespc: string | null
          mgimp: string | null
          nmcat: string | null
          nmdis: string | null
          nocod: string | null
          nprop: number | null
          nrass: number | null
          nrcom: number | null
          nrope: number | null
          pcfor: string | null
          pcter: string | null
          pesun: number | null
          prefa: string | null
          preup: number | null
          preupe: number | null
          prlot: number | null
          prvoc: string | null
          prvor: string | null
          ptefo: number | null
          ptpap: string | null
          qarpl: number | null
          qmnpl: number | null
          qmxpl: number | null
          qprop: number | null
          recfl: string | null
          seo_description: string | null
          seo_title: string | null
          tags: string[] | null
          tecop: number | null
          titolo_b2b: string | null
          tpimb: string | null
          tppra: string | null
          tpprb: string | null
          tpprc: string | null
          tprod: number | null
          tproe: number | null
          tprov: number | null
          trevo: number | null
          umalt: string | null
          umfa2: number | null
          umfaa: number | null
          umfat: number | null
          unmi2: string | null
          unmis: string | null
          unpes: string | null
          untec: string | null
          updated_at: string
          updated_by: string | null
          vocor: string | null
          vocos: string | null
          vospa: string | null
          wabldrw: string | null
          wablorw: string | null
          wacau: string | null
          wartoma: string | null
          waslbrw: string | null
          waslorw: string | null
          wcdst: string | null
          wclas1rw: string | null
          wclas2rw: string | null
          wclas3rw: string | null
          wclve: string | null
          wcpad: string | null
          wcpgm: string | null
          wdalodrw: string | null
          wdaloorw: string | null
          wdeag: string | null
          wdis1drw: string | null
          wdis1orw: string | null
          wdis2drw: string | null
          wdis2orw: string | null
          wdset: string | null
          wdtscdrw: string | null
          wdtscorw: string | null
          wesrc: string | null
          wfc1s: number | null
          wfc2x: number | null
          wfcs1: number | null
          wfcvr: string | null
          wfitt: string | null
          wfuas: string | null
          wfuaspr: number | null
          wgia1drw: string | null
          wgia1orw: string | null
          wgia2drw: string | null
          wgia2orw: string | null
          wgkit: string | null
          wgslorw: string | null
          wgsltrw: string | null
          wimba: string | null
          wniva: string | null
          wnprv: string | null
          wnsts: string | null
          wolodrw: string | null
          woloorw: string | null
          wperspa: string | null
          wpocc: string | null
          wprasdrw: string | null
          wpraserw: string | null
          wprasorw: string | null
          wpzne: string | null
          wqtmndrw: string | null
          wqtmnorw: string | null
          wsezi: string | null
          wsovr: string | null
          wsqvs: string | null
          wstag: string | null
          wtrac: string | null
          wumrf: string | null
          wumsp: string | null
          wvqtm: number | null
          wvtai: string | null
          wvvii: string | null
          wvviq: string | null
        }
        Insert: {
          agcic?: string | null
          as400_sync_status?: string | null
          attributes?: Json | null
          b2b_content_updated_at?: string | null
          b2b_first_published_at?: string | null
          b2b_online_active?: boolean | null
          b2b_online_effective?: boolean
          b2b_product_description?: string | null
          b2b_product_title?: string | null
          barcd?: string | null
          cat_id?: string | null
          cat_id_2?: string | null
          catalogo_carta_dettaglio?: string | null
          catalogo_carta_scheda?: string | null
          catalogo_carta_titolo?: string | null
          ccndi?: string | null
          cdiva?: string | null
          cdpaf?: string | null
          cdpar: string
          cdrga?: string | null
          cdst1?: string | null
          cdst2?: string | null
          cdst3?: string | null
          cecoa?: string | null
          cenco?: string | null
          ceric?: string | null
          cfcal?: number | null
          clapp?: string | null
          clas1?: string | null
          clas2?: string | null
          clmer?: string | null
          cmltc?: number | null
          cod_padre?: string | null
          conac?: string | null
          conem?: string | null
          cprop?: string | null
          created_at?: string
          crevd?: string | null
          crimp?: string | null
          crimt?: string | null
          crrio?: string | null
          crtpr?: string | null
          daa26?: string | null
          depar?: string | null
          description_ecommerce?: string | null
          description_marketing?: string | null
          descrizione?: string | null
          descrizione_b2b?: string | null
          descrizione_variante?: string | null
          dtac5?: string | null
          dtcic?: string | null
          dtltc?: string | null
          dtstr?: string | null
          dvrif?: string | null
          escam?: string | null
          evadi?: string | null
          flglo?: string | null
          flscr?: string | null
          fts?: unknown
          fts_simple?: unknown
          gprop?: number | null
          hlvmn?: number | null
          id?: string
          indgc?: string | null
          lipro?: string | null
          livmn?: number | null
          master_pack?: number | null
          mespc?: string | null
          mgimp?: string | null
          nmcat?: string | null
          nmdis?: string | null
          nocod?: string | null
          nprop?: number | null
          nrass?: number | null
          nrcom?: number | null
          nrope?: number | null
          pcfor?: string | null
          pcter?: string | null
          pesun?: number | null
          prefa?: string | null
          preup?: number | null
          preupe?: number | null
          prlot?: number | null
          prvoc?: string | null
          prvor?: string | null
          ptefo?: number | null
          ptpap?: string | null
          qarpl?: number | null
          qmnpl?: number | null
          qmxpl?: number | null
          qprop?: number | null
          recfl?: string | null
          seo_description?: string | null
          seo_title?: string | null
          tags?: string[] | null
          tecop?: number | null
          titolo_b2b?: string | null
          tpimb?: string | null
          tppra?: string | null
          tpprb?: string | null
          tpprc?: string | null
          tprod?: number | null
          tproe?: number | null
          tprov?: number | null
          trevo?: number | null
          umalt?: string | null
          umfa2?: number | null
          umfaa?: number | null
          umfat?: number | null
          unmi2?: string | null
          unmis?: string | null
          unpes?: string | null
          untec?: string | null
          updated_at?: string
          updated_by?: string | null
          vocor?: string | null
          vocos?: string | null
          vospa?: string | null
          wabldrw?: string | null
          wablorw?: string | null
          wacau?: string | null
          wartoma?: string | null
          waslbrw?: string | null
          waslorw?: string | null
          wcdst?: string | null
          wclas1rw?: string | null
          wclas2rw?: string | null
          wclas3rw?: string | null
          wclve?: string | null
          wcpad?: string | null
          wcpgm?: string | null
          wdalodrw?: string | null
          wdaloorw?: string | null
          wdeag?: string | null
          wdis1drw?: string | null
          wdis1orw?: string | null
          wdis2drw?: string | null
          wdis2orw?: string | null
          wdset?: string | null
          wdtscdrw?: string | null
          wdtscorw?: string | null
          wesrc?: string | null
          wfc1s?: number | null
          wfc2x?: number | null
          wfcs1?: number | null
          wfcvr?: string | null
          wfitt?: string | null
          wfuas?: string | null
          wfuaspr?: number | null
          wgia1drw?: string | null
          wgia1orw?: string | null
          wgia2drw?: string | null
          wgia2orw?: string | null
          wgkit?: string | null
          wgslorw?: string | null
          wgsltrw?: string | null
          wimba?: string | null
          wniva?: string | null
          wnprv?: string | null
          wnsts?: string | null
          wolodrw?: string | null
          woloorw?: string | null
          wperspa?: string | null
          wpocc?: string | null
          wprasdrw?: string | null
          wpraserw?: string | null
          wprasorw?: string | null
          wpzne?: string | null
          wqtmndrw?: string | null
          wqtmnorw?: string | null
          wsezi?: string | null
          wsovr?: string | null
          wsqvs?: string | null
          wstag?: string | null
          wtrac?: string | null
          wumrf?: string | null
          wumsp?: string | null
          wvqtm?: number | null
          wvtai?: string | null
          wvvii?: string | null
          wvviq?: string | null
        }
        Update: {
          agcic?: string | null
          as400_sync_status?: string | null
          attributes?: Json | null
          b2b_content_updated_at?: string | null
          b2b_first_published_at?: string | null
          b2b_online_active?: boolean | null
          b2b_online_effective?: boolean
          b2b_product_description?: string | null
          b2b_product_title?: string | null
          barcd?: string | null
          cat_id?: string | null
          cat_id_2?: string | null
          catalogo_carta_dettaglio?: string | null
          catalogo_carta_scheda?: string | null
          catalogo_carta_titolo?: string | null
          ccndi?: string | null
          cdiva?: string | null
          cdpaf?: string | null
          cdpar?: string
          cdrga?: string | null
          cdst1?: string | null
          cdst2?: string | null
          cdst3?: string | null
          cecoa?: string | null
          cenco?: string | null
          ceric?: string | null
          cfcal?: number | null
          clapp?: string | null
          clas1?: string | null
          clas2?: string | null
          clmer?: string | null
          cmltc?: number | null
          cod_padre?: string | null
          conac?: string | null
          conem?: string | null
          cprop?: string | null
          created_at?: string
          crevd?: string | null
          crimp?: string | null
          crimt?: string | null
          crrio?: string | null
          crtpr?: string | null
          daa26?: string | null
          depar?: string | null
          description_ecommerce?: string | null
          description_marketing?: string | null
          descrizione?: string | null
          descrizione_b2b?: string | null
          descrizione_variante?: string | null
          dtac5?: string | null
          dtcic?: string | null
          dtltc?: string | null
          dtstr?: string | null
          dvrif?: string | null
          escam?: string | null
          evadi?: string | null
          flglo?: string | null
          flscr?: string | null
          fts?: unknown
          fts_simple?: unknown
          gprop?: number | null
          hlvmn?: number | null
          id?: string
          indgc?: string | null
          lipro?: string | null
          livmn?: number | null
          master_pack?: number | null
          mespc?: string | null
          mgimp?: string | null
          nmcat?: string | null
          nmdis?: string | null
          nocod?: string | null
          nprop?: number | null
          nrass?: number | null
          nrcom?: number | null
          nrope?: number | null
          pcfor?: string | null
          pcter?: string | null
          pesun?: number | null
          prefa?: string | null
          preup?: number | null
          preupe?: number | null
          prlot?: number | null
          prvoc?: string | null
          prvor?: string | null
          ptefo?: number | null
          ptpap?: string | null
          qarpl?: number | null
          qmnpl?: number | null
          qmxpl?: number | null
          qprop?: number | null
          recfl?: string | null
          seo_description?: string | null
          seo_title?: string | null
          tags?: string[] | null
          tecop?: number | null
          titolo_b2b?: string | null
          tpimb?: string | null
          tppra?: string | null
          tpprb?: string | null
          tpprc?: string | null
          tprod?: number | null
          tproe?: number | null
          tprov?: number | null
          trevo?: number | null
          umalt?: string | null
          umfa2?: number | null
          umfaa?: number | null
          umfat?: number | null
          unmi2?: string | null
          unmis?: string | null
          unpes?: string | null
          untec?: string | null
          updated_at?: string
          updated_by?: string | null
          vocor?: string | null
          vocos?: string | null
          vospa?: string | null
          wabldrw?: string | null
          wablorw?: string | null
          wacau?: string | null
          wartoma?: string | null
          waslbrw?: string | null
          waslorw?: string | null
          wcdst?: string | null
          wclas1rw?: string | null
          wclas2rw?: string | null
          wclas3rw?: string | null
          wclve?: string | null
          wcpad?: string | null
          wcpgm?: string | null
          wdalodrw?: string | null
          wdaloorw?: string | null
          wdeag?: string | null
          wdis1drw?: string | null
          wdis1orw?: string | null
          wdis2drw?: string | null
          wdis2orw?: string | null
          wdset?: string | null
          wdtscdrw?: string | null
          wdtscorw?: string | null
          wesrc?: string | null
          wfc1s?: number | null
          wfc2x?: number | null
          wfcs1?: number | null
          wfcvr?: string | null
          wfitt?: string | null
          wfuas?: string | null
          wfuaspr?: number | null
          wgia1drw?: string | null
          wgia1orw?: string | null
          wgia2drw?: string | null
          wgia2orw?: string | null
          wgkit?: string | null
          wgslorw?: string | null
          wgsltrw?: string | null
          wimba?: string | null
          wniva?: string | null
          wnprv?: string | null
          wnsts?: string | null
          wolodrw?: string | null
          woloorw?: string | null
          wperspa?: string | null
          wpocc?: string | null
          wprasdrw?: string | null
          wpraserw?: string | null
          wprasorw?: string | null
          wpzne?: string | null
          wqtmndrw?: string | null
          wqtmnorw?: string | null
          wsezi?: string | null
          wsovr?: string | null
          wsqvs?: string | null
          wstag?: string | null
          wtrac?: string | null
          wumrf?: string | null
          wumsp?: string | null
          wvqtm?: number | null
          wvtai?: string | null
          wvvii?: string | null
          wvviq?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "archivio_articoli_fraschetti_cat_id_2_fkey"
            columns: ["cat_id_2"]
            isOneToOne: false
            referencedRelation: "cat"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "archivio_articoli_fraschetti_cat_id_fkey"
            columns: ["cat_id"]
            isOneToOne: false
            referencedRelation: "cat"
            referencedColumns: ["id"]
          },
        ]
      }
      archivio_brand_fraschetti: {
        Row: {
          clas2: string
          created_at: string
          description: string | null
          display_name: string | null
          gradient_from: string | null
          gradient_to: string | null
          hero_image_url: string | null
          is_published_b2b: boolean
          logo_url: string | null
          nome_as400_brand: string
          synced_as400: boolean
          tagline: string | null
          updated_at: string
          updated_by: string | null
          website_url: string | null
        }
        Insert: {
          clas2: string
          created_at?: string
          description?: string | null
          display_name?: string | null
          gradient_from?: string | null
          gradient_to?: string | null
          hero_image_url?: string | null
          is_published_b2b?: boolean
          logo_url?: string | null
          nome_as400_brand?: string
          synced_as400?: boolean
          tagline?: string | null
          updated_at?: string
          updated_by?: string | null
          website_url?: string | null
        }
        Update: {
          clas2?: string
          created_at?: string
          description?: string | null
          display_name?: string | null
          gradient_from?: string | null
          gradient_to?: string | null
          hero_image_url?: string | null
          is_published_b2b?: boolean
          logo_url?: string | null
          nome_as400_brand?: string
          synced_as400?: boolean
          tagline?: string | null
          updated_at?: string
          updated_by?: string | null
          website_url?: string | null
        }
        Relationships: []
      }
      archivio_codici_barre_fraschetti: {
        Row: {
          created_at: string
          id: string
          updated_at: string
          wcbda: string | null
          wcbds: string | null
          wcdpa: string
          wcmab: string | null
          wcofl: string | null
          wcpba: string | null
          wderd: string | null
          wgebi: string | null
          wimbc: number | null
          wlotto: string | null
          wplub: string | null
          wprim: number | null
          wprime: number | null
          wtpco: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          updated_at?: string
          wcbda?: string | null
          wcbds?: string | null
          wcdpa: string
          wcmab?: string | null
          wcofl?: string | null
          wcpba?: string | null
          wderd?: string | null
          wgebi?: string | null
          wimbc?: number | null
          wlotto?: string | null
          wplub?: string | null
          wprim?: number | null
          wprime?: number | null
          wtpco?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          updated_at?: string
          wcbda?: string | null
          wcbds?: string | null
          wcdpa?: string
          wcmab?: string | null
          wcofl?: string | null
          wcpba?: string | null
          wderd?: string | null
          wgebi?: string | null
          wimbc?: number | null
          wlotto?: string | null
          wplub?: string | null
          wprim?: number | null
          wprime?: number | null
          wtpco?: string | null
        }
        Relationships: []
      }
      archivio_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      archivio_fornitori_fraschetti: {
        Row: {
          buyer: string | null
          cap: string | null
          cdfor: string
          cliente_corrispondente: string | null
          codice_divisione: string | null
          codice_fiscale: string | null
          codice_modalita_pagamento: string | null
          codice_nazionale: string | null
          created_at: string
          demand_planner: string | null
          id: string
          indirizzo: string | null
          is_active: boolean | null
          localita: string | null
          numero_telefono: string | null
          partita_iva: string | null
          provincia: string | null
          rasf2: string | null
          rasfo: string | null
          updated_at: string
          wmnoro: string | null
        }
        Insert: {
          buyer?: string | null
          cap?: string | null
          cdfor: string
          cliente_corrispondente?: string | null
          codice_divisione?: string | null
          codice_fiscale?: string | null
          codice_modalita_pagamento?: string | null
          codice_nazionale?: string | null
          created_at?: string
          demand_planner?: string | null
          id?: string
          indirizzo?: string | null
          is_active?: boolean | null
          localita?: string | null
          numero_telefono?: string | null
          partita_iva?: string | null
          provincia?: string | null
          rasf2?: string | null
          rasfo?: string | null
          updated_at?: string
          wmnoro?: string | null
        }
        Update: {
          buyer?: string | null
          cap?: string | null
          cdfor?: string
          cliente_corrispondente?: string | null
          codice_divisione?: string | null
          codice_fiscale?: string | null
          codice_modalita_pagamento?: string | null
          codice_nazionale?: string | null
          created_at?: string
          demand_planner?: string | null
          id?: string
          indirizzo?: string | null
          is_active?: boolean | null
          localita?: string | null
          numero_telefono?: string | null
          partita_iva?: string | null
          provincia?: string | null
          rasf2?: string | null
          rasfo?: string | null
          updated_at?: string
          wmnoro?: string | null
        }
        Relationships: []
      }
      archivio_listini_fraschetti: {
        Row: {
          avcat: string | null
          catri: string | null
          cdcat: number | null
          cdfor: string | null
          cdpar: string
          cdrcf: string | null
          cdval: string | null
          codct: string | null
          created_at: string
          daoff: number | null
          daz02: number | null
          dtvaf: number | null
          dtvai: number | null
          dtz02: string | null
          gioff: string | null
          id: string
          masc1: number | null
          masc2: number | null
          masc3: number | null
          masc4: number | null
          masc5: number | null
          notec: string | null
          nrz02: number | null
          prsc1: number | null
          prsc2: number | null
          prsc3: number | null
          prsc4: number | null
          prsc5: number | null
          qtsc1: number | null
          qtsc2: number | null
          qtsc3: number | null
          qtsc4: number | null
          qtsc5: number | null
          rifli: string | null
          scfa1: number | null
          scfa2: number | null
          scfa3: number | null
          scfa4: number | null
          scfa5: number | null
          scfb1: number | null
          scfb2: number | null
          scfb3: number | null
          scfb4: number | null
          scfb5: number | null
          sisc1: number | null
          sisc2: number | null
          sisc3: number | null
          sisc4: number | null
          sisc5: number | null
          updated_at: string
          usorc: string | null
          wbac0: string | null
          wbac1: string | null
          wbac11: string | null
          wbac12: string | null
          wbac13: string | null
          wbac14: string | null
          wbac15: string | null
          wbac16: string | null
          wbac17: string | null
          wbac18: string | null
          wbac19: string | null
          wbac2: string | null
          wbac20: string | null
          wbac3: string | null
          wbac4: string | null
          wbac5: string | null
          wbac6: string | null
          wbac7: string | null
          wbac8: string | null
          wbac9: string | null
          wbcf0: string | null
          wbcf1: string | null
          wbcf2: string | null
          wbcf3: string | null
          wbcf4: string | null
          wbcf5: string | null
          wbcf6: string | null
          wbcf7: string | null
          wbcf8: string | null
          wbcf9: string | null
          wcaa0: string | null
          wcaa1: string | null
          wcaa11: string | null
          wcaa12: string | null
          wcaa13: string | null
          wcaa14: string | null
          wcaa15: string | null
          wcaa16: string | null
          wcaa17: string | null
          wcaa18: string | null
          wcaa19: string | null
          wcaa2: string | null
          wcaa20: string | null
          wcaa3: string | null
          wcaa4: string | null
          wcaa5: string | null
          wcaa6: string | null
          wcaa7: string | null
          wcaa8: string | null
          wcaa9: string | null
          wcaaa: number | null
          wcaaa0: number | null
          wcaaa1: number | null
          wcaaa2: number | null
          wcaaa3: number | null
          wcaaa4: number | null
          wcaaa5: number | null
          wcaaa6: number | null
          wcaaa7: number | null
          wcaaa8: number | null
          wcaaa9: number | null
          wcac0: number | null
          wcac1: number | null
          wcac11: number | null
          wcac12: number | null
          wcac13: number | null
          wcac14: number | null
          wcac15: number | null
          wcac16: number | null
          wcac17: number | null
          wcac18: number | null
          wcac19: number | null
          wcac2: number | null
          wcac20: number | null
          wcac3: number | null
          wcac4: number | null
          wcac5: number | null
          wcac6: number | null
          wcac7: number | null
          wcac8: number | null
          wcac9: number | null
          wcaf0: string | null
          wcaf1: string | null
          wcaf2: string | null
          wcaf3: string | null
          wcaf4: string | null
          wcaf5: string | null
          wcaf6: string | null
          wcaf7: string | null
          wcaf8: string | null
          wcaf9: string | null
          wcaff: number | null
          wcafl: number | null
          wcate: number | null
          wcdca: number | null
          wcifa: number | null
          wcifb: number | null
          wcifc: number | null
          wcpfa: number | null
          wcpfb: number | null
          wcpfc: number | null
          wcsaa: number | null
          wcsaa0: number | null
          wcsaa1: number | null
          wcsaa2: number | null
          wcsaa3: number | null
          wcsaa4: number | null
          wcsaa5: number | null
          wcsaa6: number | null
          wcsaa7: number | null
          wcsaa8: number | null
          wcsaa9: number | null
          wcsff: number | null
          wcsfl: number | null
          wcste: number | null
          wctri: number | null
          wctrp: number | null
          wdimv: number | null
          wfcas: number | null
          wfoca: string | null
          wiac0: string | null
          wiac1: string | null
          wiac11: string | null
          wiac12: string | null
          wiac13: string | null
          wiac14: string | null
          wiac15: string | null
          wiac16: string | null
          wiac17: string | null
          wiac18: string | null
          wiac19: string | null
          wiac2: string | null
          wiac20: string | null
          wiac3: string | null
          wiac4: string | null
          wiac5: string | null
          wiac6: string | null
          wiac7: string | null
          wiac8: string | null
          wiac9: string | null
          wicf0: string | null
          wicf1: string | null
          wicf2: string | null
          wicf3: string | null
          wicf4: string | null
          wicf5: string | null
          wicf6: string | null
          wicf7: string | null
          wicf8: string | null
          wicf9: string | null
          wmasc: number | null
          wnsca: string | null
          wpersct: string | null
          wprco: number | null
          wprsc: number | null
          wscf0: number | null
          wscf1: number | null
          wscf2: number | null
          wscf3: number | null
          wscf4: number | null
          wscf5: number | null
          wscf6: number | null
          wscf7: number | null
          wscf8: number | null
          wscf9: number | null
          wscfa: number | null
          wscfb: number | null
          wscfc: number | null
          wscfd: number | null
          wscfe: number | null
          wsisc: number | null
          wsocp: string | null
          wuord: string | null
          wusto: string | null
        }
        Insert: {
          avcat?: string | null
          catri?: string | null
          cdcat?: number | null
          cdfor?: string | null
          cdpar: string
          cdrcf?: string | null
          cdval?: string | null
          codct?: string | null
          created_at?: string
          daoff?: number | null
          daz02?: number | null
          dtvaf?: number | null
          dtvai?: number | null
          dtz02?: string | null
          gioff?: string | null
          id?: string
          masc1?: number | null
          masc2?: number | null
          masc3?: number | null
          masc4?: number | null
          masc5?: number | null
          notec?: string | null
          nrz02?: number | null
          prsc1?: number | null
          prsc2?: number | null
          prsc3?: number | null
          prsc4?: number | null
          prsc5?: number | null
          qtsc1?: number | null
          qtsc2?: number | null
          qtsc3?: number | null
          qtsc4?: number | null
          qtsc5?: number | null
          rifli?: string | null
          scfa1?: number | null
          scfa2?: number | null
          scfa3?: number | null
          scfa4?: number | null
          scfa5?: number | null
          scfb1?: number | null
          scfb2?: number | null
          scfb3?: number | null
          scfb4?: number | null
          scfb5?: number | null
          sisc1?: number | null
          sisc2?: number | null
          sisc3?: number | null
          sisc4?: number | null
          sisc5?: number | null
          updated_at?: string
          usorc?: string | null
          wbac0?: string | null
          wbac1?: string | null
          wbac11?: string | null
          wbac12?: string | null
          wbac13?: string | null
          wbac14?: string | null
          wbac15?: string | null
          wbac16?: string | null
          wbac17?: string | null
          wbac18?: string | null
          wbac19?: string | null
          wbac2?: string | null
          wbac20?: string | null
          wbac3?: string | null
          wbac4?: string | null
          wbac5?: string | null
          wbac6?: string | null
          wbac7?: string | null
          wbac8?: string | null
          wbac9?: string | null
          wbcf0?: string | null
          wbcf1?: string | null
          wbcf2?: string | null
          wbcf3?: string | null
          wbcf4?: string | null
          wbcf5?: string | null
          wbcf6?: string | null
          wbcf7?: string | null
          wbcf8?: string | null
          wbcf9?: string | null
          wcaa0?: string | null
          wcaa1?: string | null
          wcaa11?: string | null
          wcaa12?: string | null
          wcaa13?: string | null
          wcaa14?: string | null
          wcaa15?: string | null
          wcaa16?: string | null
          wcaa17?: string | null
          wcaa18?: string | null
          wcaa19?: string | null
          wcaa2?: string | null
          wcaa20?: string | null
          wcaa3?: string | null
          wcaa4?: string | null
          wcaa5?: string | null
          wcaa6?: string | null
          wcaa7?: string | null
          wcaa8?: string | null
          wcaa9?: string | null
          wcaaa?: number | null
          wcaaa0?: number | null
          wcaaa1?: number | null
          wcaaa2?: number | null
          wcaaa3?: number | null
          wcaaa4?: number | null
          wcaaa5?: number | null
          wcaaa6?: number | null
          wcaaa7?: number | null
          wcaaa8?: number | null
          wcaaa9?: number | null
          wcac0?: number | null
          wcac1?: number | null
          wcac11?: number | null
          wcac12?: number | null
          wcac13?: number | null
          wcac14?: number | null
          wcac15?: number | null
          wcac16?: number | null
          wcac17?: number | null
          wcac18?: number | null
          wcac19?: number | null
          wcac2?: number | null
          wcac20?: number | null
          wcac3?: number | null
          wcac4?: number | null
          wcac5?: number | null
          wcac6?: number | null
          wcac7?: number | null
          wcac8?: number | null
          wcac9?: number | null
          wcaf0?: string | null
          wcaf1?: string | null
          wcaf2?: string | null
          wcaf3?: string | null
          wcaf4?: string | null
          wcaf5?: string | null
          wcaf6?: string | null
          wcaf7?: string | null
          wcaf8?: string | null
          wcaf9?: string | null
          wcaff?: number | null
          wcafl?: number | null
          wcate?: number | null
          wcdca?: number | null
          wcifa?: number | null
          wcifb?: number | null
          wcifc?: number | null
          wcpfa?: number | null
          wcpfb?: number | null
          wcpfc?: number | null
          wcsaa?: number | null
          wcsaa0?: number | null
          wcsaa1?: number | null
          wcsaa2?: number | null
          wcsaa3?: number | null
          wcsaa4?: number | null
          wcsaa5?: number | null
          wcsaa6?: number | null
          wcsaa7?: number | null
          wcsaa8?: number | null
          wcsaa9?: number | null
          wcsff?: number | null
          wcsfl?: number | null
          wcste?: number | null
          wctri?: number | null
          wctrp?: number | null
          wdimv?: number | null
          wfcas?: number | null
          wfoca?: string | null
          wiac0?: string | null
          wiac1?: string | null
          wiac11?: string | null
          wiac12?: string | null
          wiac13?: string | null
          wiac14?: string | null
          wiac15?: string | null
          wiac16?: string | null
          wiac17?: string | null
          wiac18?: string | null
          wiac19?: string | null
          wiac2?: string | null
          wiac20?: string | null
          wiac3?: string | null
          wiac4?: string | null
          wiac5?: string | null
          wiac6?: string | null
          wiac7?: string | null
          wiac8?: string | null
          wiac9?: string | null
          wicf0?: string | null
          wicf1?: string | null
          wicf2?: string | null
          wicf3?: string | null
          wicf4?: string | null
          wicf5?: string | null
          wicf6?: string | null
          wicf7?: string | null
          wicf8?: string | null
          wicf9?: string | null
          wmasc?: number | null
          wnsca?: string | null
          wpersct?: string | null
          wprco?: number | null
          wprsc?: number | null
          wscf0?: number | null
          wscf1?: number | null
          wscf2?: number | null
          wscf3?: number | null
          wscf4?: number | null
          wscf5?: number | null
          wscf6?: number | null
          wscf7?: number | null
          wscf8?: number | null
          wscf9?: number | null
          wscfa?: number | null
          wscfb?: number | null
          wscfc?: number | null
          wscfd?: number | null
          wscfe?: number | null
          wsisc?: number | null
          wsocp?: string | null
          wuord?: string | null
          wusto?: string | null
        }
        Update: {
          avcat?: string | null
          catri?: string | null
          cdcat?: number | null
          cdfor?: string | null
          cdpar?: string
          cdrcf?: string | null
          cdval?: string | null
          codct?: string | null
          created_at?: string
          daoff?: number | null
          daz02?: number | null
          dtvaf?: number | null
          dtvai?: number | null
          dtz02?: string | null
          gioff?: string | null
          id?: string
          masc1?: number | null
          masc2?: number | null
          masc3?: number | null
          masc4?: number | null
          masc5?: number | null
          notec?: string | null
          nrz02?: number | null
          prsc1?: number | null
          prsc2?: number | null
          prsc3?: number | null
          prsc4?: number | null
          prsc5?: number | null
          qtsc1?: number | null
          qtsc2?: number | null
          qtsc3?: number | null
          qtsc4?: number | null
          qtsc5?: number | null
          rifli?: string | null
          scfa1?: number | null
          scfa2?: number | null
          scfa3?: number | null
          scfa4?: number | null
          scfa5?: number | null
          scfb1?: number | null
          scfb2?: number | null
          scfb3?: number | null
          scfb4?: number | null
          scfb5?: number | null
          sisc1?: number | null
          sisc2?: number | null
          sisc3?: number | null
          sisc4?: number | null
          sisc5?: number | null
          updated_at?: string
          usorc?: string | null
          wbac0?: string | null
          wbac1?: string | null
          wbac11?: string | null
          wbac12?: string | null
          wbac13?: string | null
          wbac14?: string | null
          wbac15?: string | null
          wbac16?: string | null
          wbac17?: string | null
          wbac18?: string | null
          wbac19?: string | null
          wbac2?: string | null
          wbac20?: string | null
          wbac3?: string | null
          wbac4?: string | null
          wbac5?: string | null
          wbac6?: string | null
          wbac7?: string | null
          wbac8?: string | null
          wbac9?: string | null
          wbcf0?: string | null
          wbcf1?: string | null
          wbcf2?: string | null
          wbcf3?: string | null
          wbcf4?: string | null
          wbcf5?: string | null
          wbcf6?: string | null
          wbcf7?: string | null
          wbcf8?: string | null
          wbcf9?: string | null
          wcaa0?: string | null
          wcaa1?: string | null
          wcaa11?: string | null
          wcaa12?: string | null
          wcaa13?: string | null
          wcaa14?: string | null
          wcaa15?: string | null
          wcaa16?: string | null
          wcaa17?: string | null
          wcaa18?: string | null
          wcaa19?: string | null
          wcaa2?: string | null
          wcaa20?: string | null
          wcaa3?: string | null
          wcaa4?: string | null
          wcaa5?: string | null
          wcaa6?: string | null
          wcaa7?: string | null
          wcaa8?: string | null
          wcaa9?: string | null
          wcaaa?: number | null
          wcaaa0?: number | null
          wcaaa1?: number | null
          wcaaa2?: number | null
          wcaaa3?: number | null
          wcaaa4?: number | null
          wcaaa5?: number | null
          wcaaa6?: number | null
          wcaaa7?: number | null
          wcaaa8?: number | null
          wcaaa9?: number | null
          wcac0?: number | null
          wcac1?: number | null
          wcac11?: number | null
          wcac12?: number | null
          wcac13?: number | null
          wcac14?: number | null
          wcac15?: number | null
          wcac16?: number | null
          wcac17?: number | null
          wcac18?: number | null
          wcac19?: number | null
          wcac2?: number | null
          wcac20?: number | null
          wcac3?: number | null
          wcac4?: number | null
          wcac5?: number | null
          wcac6?: number | null
          wcac7?: number | null
          wcac8?: number | null
          wcac9?: number | null
          wcaf0?: string | null
          wcaf1?: string | null
          wcaf2?: string | null
          wcaf3?: string | null
          wcaf4?: string | null
          wcaf5?: string | null
          wcaf6?: string | null
          wcaf7?: string | null
          wcaf8?: string | null
          wcaf9?: string | null
          wcaff?: number | null
          wcafl?: number | null
          wcate?: number | null
          wcdca?: number | null
          wcifa?: number | null
          wcifb?: number | null
          wcifc?: number | null
          wcpfa?: number | null
          wcpfb?: number | null
          wcpfc?: number | null
          wcsaa?: number | null
          wcsaa0?: number | null
          wcsaa1?: number | null
          wcsaa2?: number | null
          wcsaa3?: number | null
          wcsaa4?: number | null
          wcsaa5?: number | null
          wcsaa6?: number | null
          wcsaa7?: number | null
          wcsaa8?: number | null
          wcsaa9?: number | null
          wcsff?: number | null
          wcsfl?: number | null
          wcste?: number | null
          wctri?: number | null
          wctrp?: number | null
          wdimv?: number | null
          wfcas?: number | null
          wfoca?: string | null
          wiac0?: string | null
          wiac1?: string | null
          wiac11?: string | null
          wiac12?: string | null
          wiac13?: string | null
          wiac14?: string | null
          wiac15?: string | null
          wiac16?: string | null
          wiac17?: string | null
          wiac18?: string | null
          wiac19?: string | null
          wiac2?: string | null
          wiac20?: string | null
          wiac3?: string | null
          wiac4?: string | null
          wiac5?: string | null
          wiac6?: string | null
          wiac7?: string | null
          wiac8?: string | null
          wiac9?: string | null
          wicf0?: string | null
          wicf1?: string | null
          wicf2?: string | null
          wicf3?: string | null
          wicf4?: string | null
          wicf5?: string | null
          wicf6?: string | null
          wicf7?: string | null
          wicf8?: string | null
          wicf9?: string | null
          wmasc?: number | null
          wnsca?: string | null
          wpersct?: string | null
          wprco?: number | null
          wprsc?: number | null
          wscf0?: number | null
          wscf1?: number | null
          wscf2?: number | null
          wscf3?: number | null
          wscf4?: number | null
          wscf5?: number | null
          wscf6?: number | null
          wscf7?: number | null
          wscf8?: number | null
          wscf9?: number | null
          wscfa?: number | null
          wscfb?: number | null
          wscfc?: number | null
          wscfd?: number | null
          wscfe?: number | null
          wsisc?: number | null
          wsocp?: string | null
          wuord?: string | null
          wusto?: string | null
        }
        Relationships: []
      }
      article_events: {
        Row: {
          cdpar: string
          customer_code: string | null
          event_type: string
          id: number
          occurred_at: string
          source: string
          user_id: string | null
        }
        Insert: {
          cdpar: string
          customer_code?: string | null
          event_type: string
          id?: number
          occurred_at?: string
          source: string
          user_id?: string | null
        }
        Update: {
          cdpar?: string
          customer_code?: string | null
          event_type?: string
          id?: number
          occurred_at?: string
          source?: string
          user_id?: string | null
        }
        Relationships: []
      }
      article_expo_items: {
        Row: {
          child_cdpar: string
          created_at: string
          created_by: string | null
          id: string
          note: string | null
          parent_cdpar: string
          quantity: number
          sort_order: number
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          child_cdpar: string
          created_at?: string
          created_by?: string | null
          id?: string
          note?: string | null
          parent_cdpar: string
          quantity?: number
          sort_order?: number
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          child_cdpar?: string
          created_at?: string
          created_by?: string | null
          id?: string
          note?: string | null
          parent_cdpar?: string
          quantity?: number
          sort_order?: number
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      article_inventory: {
        Row: {
          cdpar: string
          created_at: string
          last_import_id: string | null
          quantity: number
          updated_at: string
        }
        Insert: {
          cdpar: string
          created_at?: string
          last_import_id?: string | null
          quantity?: number
          updated_at?: string
        }
        Update: {
          cdpar?: string
          created_at?: string
          last_import_id?: string | null
          quantity?: number
          updated_at?: string
        }
        Relationships: []
      }
      article_inventory_history: {
        Row: {
          cdpar: string
          created_at: string
          delta: number | null
          id: string
          import_id: string | null
          quantity_new: number
          quantity_old: number | null
          source: string
          user_email: string | null
          user_id: string | null
        }
        Insert: {
          cdpar: string
          created_at?: string
          delta?: number | null
          id?: string
          import_id?: string | null
          quantity_new: number
          quantity_old?: number | null
          source?: string
          user_email?: string | null
          user_id?: string | null
        }
        Update: {
          cdpar?: string
          created_at?: string
          delta?: number | null
          id?: string
          import_id?: string | null
          quantity_new?: number
          quantity_old?: number | null
          source?: string
          user_email?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      article_media: {
        Row: {
          cdpar: string
          created_at: string
          file_size: number | null
          id: string
          is_primary: boolean | null
          media_type: string
          original_filename: string | null
          progressive: number | null
          public_url: string | null
          sort_order: number | null
          storage_path: string
          updated_at: string
        }
        Insert: {
          cdpar: string
          created_at?: string
          file_size?: number | null
          id?: string
          is_primary?: boolean | null
          media_type: string
          original_filename?: string | null
          progressive?: number | null
          public_url?: string | null
          sort_order?: number | null
          storage_path: string
          updated_at?: string
        }
        Update: {
          cdpar?: string
          created_at?: string
          file_size?: number | null
          id?: string
          is_primary?: boolean | null
          media_type?: string
          original_filename?: string | null
          progressive?: number | null
          public_url?: string | null
          sort_order?: number | null
          storage_path?: string
          updated_at?: string
        }
        Relationships: []
      }
      article_purchases: {
        Row: {
          cdfor: string | null
          cdpar: string
          cdpfo: string | null
          cdval: string | null
          created_at: string
          id: string
          qtmio: number | null
          updated_at: string
          voce_doganale: string | null
          wcdls: string | null
          wdtin: string | null
          wimbf: number | null
          wprun: number | null
          wqtde: string | null
          wsm01: number | null
          wsm02: number | null
          wtaim: string | null
          wumim: string | null
          wumqm: string | null
          wviim: string | null
          wviqm: string | null
        }
        Insert: {
          cdfor?: string | null
          cdpar: string
          cdpfo?: string | null
          cdval?: string | null
          created_at?: string
          id?: string
          qtmio?: number | null
          updated_at?: string
          voce_doganale?: string | null
          wcdls?: string | null
          wdtin?: string | null
          wimbf?: number | null
          wprun?: number | null
          wqtde?: string | null
          wsm01?: number | null
          wsm02?: number | null
          wtaim?: string | null
          wumim?: string | null
          wumqm?: string | null
          wviim?: string | null
          wviqm?: string | null
        }
        Update: {
          cdfor?: string | null
          cdpar?: string
          cdpfo?: string | null
          cdval?: string | null
          created_at?: string
          id?: string
          qtmio?: number | null
          updated_at?: string
          voce_doganale?: string | null
          wcdls?: string | null
          wdtin?: string | null
          wimbf?: number | null
          wprun?: number | null
          wqtde?: string | null
          wsm01?: number | null
          wsm02?: number | null
          wtaim?: string | null
          wumim?: string | null
          wumqm?: string | null
          wviim?: string | null
          wviqm?: string | null
        }
        Relationships: []
      }
      article_stats: {
        Row: {
          cart_count: number
          cdpar: string
          last_ordered_at: string | null
          last_viewed_at: string | null
          order_count: number
          updated_at: string
          views_count: number
        }
        Insert: {
          cart_count?: number
          cdpar: string
          last_ordered_at?: string | null
          last_viewed_at?: string | null
          order_count?: number
          updated_at?: string
          views_count?: number
        }
        Update: {
          cart_count?: number
          cdpar?: string
          last_ordered_at?: string | null
          last_viewed_at?: string | null
          order_count?: number
          updated_at?: string
          views_count?: number
        }
        Relationships: []
      }
      articoli: {
        Row: {
          assortimento: string | null
          brand: string | null
          cambio: number | null
          cdnaz: string | null
          classe: string | null
          codice: string
          codice_articolo_fornitore: string | null
          codice_fornitore: string | null
          costo_acquisizione: number | null
          costo_acquisto_casa: number | null
          costo_finale: number | null
          costo_listino: number | null
          costo_listino_dollaro: number | null
          created_at: string
          dazio: number | null
          demand_planner: string | null
          descrizione: string
          diff_costo_acq: number | null
          diff_ricarico: number | null
          ean: string | null
          ee: string | null
          famiglia: number | null
          fattore_conversione: number | null
          id: string
          imballo: number | null
          import_version: number
          linea: string | null
          magg_valuta: number | null
          maggiorazione: number | null
          prezzo_1: number | null
          prezzo_2: number | null
          prezzo_3: number | null
          prezzo_4: number | null
          prezzo_5: number | null
          prezzo_con_sconto: number | null
          prezzo_listino_vendita: number | null
          ragione_sociale: string | null
          reparto: string | null
          ricarico_calcolato: number | null
          ricarico_percentuale: number | null
          sconto_1: number | null
          sconto_2: number | null
          sconto_3: number | null
          sconto_4: number | null
          sconto_5: number | null
          settore: string | null
          sottobrand: string | null
          source_file: string | null
          stagionalita: number | null
          trasporto: number | null
          unita_misura: string | null
          updated_at: string
          valuta: string | null
          vincolo: boolean | null
        }
        Insert: {
          assortimento?: string | null
          brand?: string | null
          cambio?: number | null
          cdnaz?: string | null
          classe?: string | null
          codice: string
          codice_articolo_fornitore?: string | null
          codice_fornitore?: string | null
          costo_acquisizione?: number | null
          costo_acquisto_casa?: number | null
          costo_finale?: number | null
          costo_listino?: number | null
          costo_listino_dollaro?: number | null
          created_at?: string
          dazio?: number | null
          demand_planner?: string | null
          descrizione: string
          diff_costo_acq?: number | null
          diff_ricarico?: number | null
          ean?: string | null
          ee?: string | null
          famiglia?: number | null
          fattore_conversione?: number | null
          id?: string
          imballo?: number | null
          import_version?: number
          linea?: string | null
          magg_valuta?: number | null
          maggiorazione?: number | null
          prezzo_1?: number | null
          prezzo_2?: number | null
          prezzo_3?: number | null
          prezzo_4?: number | null
          prezzo_5?: number | null
          prezzo_con_sconto?: number | null
          prezzo_listino_vendita?: number | null
          ragione_sociale?: string | null
          reparto?: string | null
          ricarico_calcolato?: number | null
          ricarico_percentuale?: number | null
          sconto_1?: number | null
          sconto_2?: number | null
          sconto_3?: number | null
          sconto_4?: number | null
          sconto_5?: number | null
          settore?: string | null
          sottobrand?: string | null
          source_file?: string | null
          stagionalita?: number | null
          trasporto?: number | null
          unita_misura?: string | null
          updated_at?: string
          valuta?: string | null
          vincolo?: boolean | null
        }
        Update: {
          assortimento?: string | null
          brand?: string | null
          cambio?: number | null
          cdnaz?: string | null
          classe?: string | null
          codice?: string
          codice_articolo_fornitore?: string | null
          codice_fornitore?: string | null
          costo_acquisizione?: number | null
          costo_acquisto_casa?: number | null
          costo_finale?: number | null
          costo_listino?: number | null
          costo_listino_dollaro?: number | null
          created_at?: string
          dazio?: number | null
          demand_planner?: string | null
          descrizione?: string
          diff_costo_acq?: number | null
          diff_ricarico?: number | null
          ean?: string | null
          ee?: string | null
          famiglia?: number | null
          fattore_conversione?: number | null
          id?: string
          imballo?: number | null
          import_version?: number
          linea?: string | null
          magg_valuta?: number | null
          maggiorazione?: number | null
          prezzo_1?: number | null
          prezzo_2?: number | null
          prezzo_3?: number | null
          prezzo_4?: number | null
          prezzo_5?: number | null
          prezzo_con_sconto?: number | null
          prezzo_listino_vendita?: number | null
          ragione_sociale?: string | null
          reparto?: string | null
          ricarico_calcolato?: number | null
          ricarico_percentuale?: number | null
          sconto_1?: number | null
          sconto_2?: number | null
          sconto_3?: number | null
          sconto_4?: number | null
          sconto_5?: number | null
          settore?: string | null
          sottobrand?: string | null
          source_file?: string | null
          stagionalita?: number | null
          trasporto?: number | null
          unita_misura?: string | null
          updated_at?: string
          valuta?: string | null
          vincolo?: boolean | null
        }
        Relationships: []
      }
      as400_sync_queue: {
        Row: {
          attempts: number | null
          cdpar: string
          created_at: string
          error_message: string | null
          id: string
          last_attempt_at: string | null
          operation: string
          payload: Json
          sent_at: string | null
          status: string
          updated_at: string
        }
        Insert: {
          attempts?: number | null
          cdpar: string
          created_at?: string
          error_message?: string | null
          id?: string
          last_attempt_at?: string | null
          operation?: string
          payload?: Json
          sent_at?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          attempts?: number | null
          cdpar?: string
          created_at?: string
          error_message?: string | null
          id?: string
          last_attempt_at?: string | null
          operation?: string
          payload?: Json
          sent_at?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      ateco: {
        Row: {
          codice: string
          created_at: string
          descrizione: string
          updated_at: string
        }
        Insert: {
          codice: string
          created_at?: string
          descrizione: string
          updated_at?: string
        }
        Update: {
          codice?: string
          created_at?: string
          descrizione?: string
          updated_at?: string
        }
        Relationships: []
      }
      audit_log: {
        Row: {
          changed_fields: string[] | null
          created_at: string
          id: string
          new_values: Json | null
          old_values: Json | null
          operation: string
          record_id: string
          table_name: string
          user_email: string | null
          user_id: string | null
        }
        Insert: {
          changed_fields?: string[] | null
          created_at?: string
          id?: string
          new_values?: Json | null
          old_values?: Json | null
          operation: string
          record_id: string
          table_name: string
          user_email?: string | null
          user_id?: string | null
        }
        Update: {
          changed_fields?: string[] | null
          created_at?: string
          id?: string
          new_values?: Json | null
          old_values?: Json | null
          operation?: string
          record_id?: string
          table_name?: string
          user_email?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      b2b_assortments: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          image_url: string | null
          is_active: boolean
          match_mode: string
          name: string
          slug: string
          sort_order: number
          tags: string[]
          updated_at: string
          valid_from: string | null
          valid_to: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean
          match_mode?: string
          name: string
          slug: string
          sort_order?: number
          tags?: string[]
          updated_at?: string
          valid_from?: string | null
          valid_to?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean
          match_mode?: string
          name?: string
          slug?: string
          sort_order?: number
          tags?: string[]
          updated_at?: string
          valid_from?: string | null
          valid_to?: string | null
        }
        Relationships: []
      }
      b2b_catalogs: {
        Row: {
          assortment_id: string | null
          catalog_url: string | null
          clas2: string | null
          cover_url: string | null
          created_at: string
          created_by: string | null
          hotspots: Json
          id: string
          is_public: boolean
          is_published_b2b: boolean
          name: string
          og_image_url: string | null
          pdf_storage_path: string | null
          pdf_url: string | null
          public_slug: string | null
          public_views_count: number
          sort_order: number
          total_pages: number | null
          updated_at: string
          updated_by: string | null
          viewer_settings: Json
        }
        Insert: {
          assortment_id?: string | null
          catalog_url?: string | null
          clas2?: string | null
          cover_url?: string | null
          created_at?: string
          created_by?: string | null
          hotspots?: Json
          id?: string
          is_public?: boolean
          is_published_b2b?: boolean
          name: string
          og_image_url?: string | null
          pdf_storage_path?: string | null
          pdf_url?: string | null
          public_slug?: string | null
          public_views_count?: number
          sort_order?: number
          total_pages?: number | null
          updated_at?: string
          updated_by?: string | null
          viewer_settings?: Json
        }
        Update: {
          assortment_id?: string | null
          catalog_url?: string | null
          clas2?: string | null
          cover_url?: string | null
          created_at?: string
          created_by?: string | null
          hotspots?: Json
          id?: string
          is_public?: boolean
          is_published_b2b?: boolean
          name?: string
          og_image_url?: string | null
          pdf_storage_path?: string | null
          pdf_url?: string | null
          public_slug?: string | null
          public_views_count?: number
          sort_order?: number
          total_pages?: number | null
          updated_at?: string
          updated_by?: string | null
          viewer_settings?: Json
        }
        Relationships: [
          {
            foreignKeyName: "b2b_catalogs_assortment_id_fkey"
            columns: ["assortment_id"]
            isOneToOne: false
            referencedRelation: "b2b_assortments"
            referencedColumns: ["id"]
          },
        ]
      }
      b2b_communication_reads: {
        Row: {
          app: string
          communication_id: string
          id: string
          read_at: string
          user_identifier: string
        }
        Insert: {
          app: string
          communication_id: string
          id?: string
          read_at?: string
          user_identifier: string
        }
        Update: {
          app?: string
          communication_id?: string
          id?: string
          read_at?: string
          user_identifier?: string
        }
        Relationships: [
          {
            foreignKeyName: "b2b_communication_reads_communication_id_fkey"
            columns: ["communication_id"]
            isOneToOne: false
            referencedRelation: "b2b_communications"
            referencedColumns: ["id"]
          },
        ]
      }
      b2b_communications: {
        Row: {
          active: boolean
          audience_filters: Json
          body_html: string
          created_at: string
          created_by: string | null
          display_mode: string
          id: string
          pdf_filename: string | null
          pdf_url: string | null
          published_at: string | null
          sender_kind: string
          target_apps: string[]
          title: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          audience_filters?: Json
          body_html?: string
          created_at?: string
          created_by?: string | null
          display_mode?: string
          id?: string
          pdf_filename?: string | null
          pdf_url?: string | null
          published_at?: string | null
          sender_kind?: string
          target_apps?: string[]
          title: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          audience_filters?: Json
          body_html?: string
          created_at?: string
          created_by?: string | null
          display_mode?: string
          id?: string
          pdf_filename?: string | null
          pdf_url?: string | null
          published_at?: string | null
          sender_kind?: string
          target_apps?: string[]
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      b2b_hero_slides: {
        Row: {
          created_at: string
          cta_label: string | null
          ends_at: string | null
          id: string
          image_url: string | null
          is_active: boolean
          link_url: string | null
          sort_order: number
          starts_at: string | null
          subtitle: string | null
          title: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          created_at?: string
          cta_label?: string | null
          ends_at?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean
          link_url?: string | null
          sort_order?: number
          starts_at?: string | null
          subtitle?: string | null
          title: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          created_at?: string
          cta_label?: string | null
          ends_at?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean
          link_url?: string | null
          sort_order?: number
          starts_at?: string | null
          subtitle?: string | null
          title?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      b2b_legal_documents: {
        Row: {
          created_at: string
          file_name: string | null
          file_size: number | null
          file_url: string | null
          id: string
          slug: string
          title: string
          updated_at: string
          updated_by: string | null
          version: number
        }
        Insert: {
          created_at?: string
          file_name?: string | null
          file_size?: number | null
          file_url?: string | null
          id?: string
          slug: string
          title: string
          updated_at?: string
          updated_by?: string | null
          version?: number
        }
        Update: {
          created_at?: string
          file_name?: string | null
          file_size?: number | null
          file_url?: string | null
          id?: string
          slug?: string
          title?: string
          updated_at?: string
          updated_by?: string | null
          version?: number
        }
        Relationships: []
      }
      b2b_maintenance_bypass_users: {
        Row: {
          added_by: string | null
          created_at: string
          email: string | null
          id: string
          note: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          added_by?: string | null
          created_at?: string
          email?: string | null
          id?: string
          note?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          added_by?: string | null
          created_at?: string
          email?: string | null
          id?: string
          note?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      b2b_news_reads: {
        Row: {
          app: string
          id: string
          news_id: string
          read_at: string
          user_identifier: string
        }
        Insert: {
          app?: string
          id?: string
          news_id: string
          read_at?: string
          user_identifier: string
        }
        Update: {
          app?: string
          id?: string
          news_id?: string
          read_at?: string
          user_identifier?: string
        }
        Relationships: [
          {
            foreignKeyName: "b2b_news_reads_news_id_fkey"
            columns: ["news_id"]
            isOneToOne: false
            referencedRelation: "news"
            referencedColumns: ["id"]
          },
        ]
      }
      b2b_novita_overrides: {
        Row: {
          cdpar: string
          created_at: string
          created_by: string | null
          id: string
          note: string | null
          updated_at: string
          valid_from: string
          valid_to: string | null
        }
        Insert: {
          cdpar: string
          created_at?: string
          created_by?: string | null
          id?: string
          note?: string | null
          updated_at?: string
          valid_from?: string
          valid_to?: string | null
        }
        Update: {
          cdpar?: string
          created_at?: string
          created_by?: string | null
          id?: string
          note?: string | null
          updated_at?: string
          valid_from?: string
          valid_to?: string | null
        }
        Relationships: []
      }
      b2b_self_onboarding_requests: {
        Row: {
          cap: string
          citta: string
          codice_ateco: string | null
          cognome: string
          consenso_clausole: boolean
          consenso_privacy: boolean
          consenso_termini: boolean
          created_at: string
          descrizione_ateco: string | null
          descrizione_attivita: string | null
          email_aziendale: string
          id: string
          indirizzo: string
          marketing_newsletter: boolean
          marketing_sms: boolean
          nome: string
          notes_admin: string | null
          partita_iva: string
          payload_json: Json | null
          pec: string
          prefisso_internazionale: string
          processed_at: string | null
          processed_by: string | null
          provincia: string
          ragione_sociale: string
          sdi: string
          settore_rivenditore: string | null
          source: string
          status: string
          telefono: string
          tipo_altro: string | null
          tipologia: string
          updated_at: string
          user_agent: string | null
        }
        Insert: {
          cap: string
          citta: string
          codice_ateco?: string | null
          cognome: string
          consenso_clausole?: boolean
          consenso_privacy?: boolean
          consenso_termini?: boolean
          created_at?: string
          descrizione_ateco?: string | null
          descrizione_attivita?: string | null
          email_aziendale: string
          id?: string
          indirizzo: string
          marketing_newsletter?: boolean
          marketing_sms?: boolean
          nome: string
          notes_admin?: string | null
          partita_iva: string
          payload_json?: Json | null
          pec: string
          prefisso_internazionale: string
          processed_at?: string | null
          processed_by?: string | null
          provincia: string
          ragione_sociale: string
          sdi: string
          settore_rivenditore?: string | null
          source?: string
          status?: string
          telefono: string
          tipo_altro?: string | null
          tipologia: string
          updated_at?: string
          user_agent?: string | null
        }
        Update: {
          cap?: string
          citta?: string
          codice_ateco?: string | null
          cognome?: string
          consenso_clausole?: boolean
          consenso_privacy?: boolean
          consenso_termini?: boolean
          created_at?: string
          descrizione_ateco?: string | null
          descrizione_attivita?: string | null
          email_aziendale?: string
          id?: string
          indirizzo?: string
          marketing_newsletter?: boolean
          marketing_sms?: boolean
          nome?: string
          notes_admin?: string | null
          partita_iva?: string
          payload_json?: Json | null
          pec?: string
          prefisso_internazionale?: string
          processed_at?: string | null
          processed_by?: string | null
          provincia?: string
          ragione_sociale?: string
          sdi?: string
          settore_rivenditore?: string | null
          source?: string
          status?: string
          telefono?: string
          tipo_altro?: string | null
          tipologia?: string
          updated_at?: string
          user_agent?: string | null
        }
        Relationships: []
      }
      b2b_ticket_visits_global: {
        Row: {
          last_visit_at: string
          last_visit_by: string | null
          ticket_id: string
        }
        Insert: {
          last_visit_at?: string
          last_visit_by?: string | null
          ticket_id: string
        }
        Update: {
          last_visit_at?: string
          last_visit_by?: string | null
          ticket_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "b2b_ticket_visits_global_ticket_id_fkey"
            columns: ["ticket_id"]
            isOneToOne: true
            referencedRelation: "customer_support_tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      brand_documents: {
        Row: {
          category: Database["public"]["Enums"]["brand_document_category"]
          clas2: string
          created_at: string
          created_by: string | null
          file_name: string | null
          file_size: number | null
          file_url: string
          id: string
          sort_order: number
          title: string
          updated_at: string
        }
        Insert: {
          category: Database["public"]["Enums"]["brand_document_category"]
          clas2: string
          created_at?: string
          created_by?: string | null
          file_name?: string | null
          file_size?: number | null
          file_url: string
          id?: string
          sort_order?: number
          title: string
          updated_at?: string
        }
        Update: {
          category?: Database["public"]["Enums"]["brand_document_category"]
          clas2?: string
          created_at?: string
          created_by?: string | null
          file_name?: string | null
          file_size?: number | null
          file_url?: string
          id?: string
          sort_order?: number
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "brand_documents_clas2_fkey"
            columns: ["clas2"]
            isOneToOne: false
            referencedRelation: "archivio_brand_fraschetti"
            referencedColumns: ["clas2"]
          },
          {
            foreignKeyName: "brand_documents_clas2_fkey"
            columns: ["clas2"]
            isOneToOne: false
            referencedRelation: "b2b_brands"
            referencedColumns: ["clas2"]
          },
          {
            foreignKeyName: "brand_documents_clas2_fkey"
            columns: ["clas2"]
            isOneToOne: false
            referencedRelation: "b2b_brands"
            referencedColumns: ["slug"]
          },
        ]
      }
      carico_merci: {
        Row: {
          codice_fornitore: string
          created_at: string
          created_by: string | null
          data_ddt_fornitore: string | null
          data_ordine: string | null
          excel_file_path: string | null
          extra: Json
          id: string
          nota: string | null
          numero_colli: number | null
          numero_ddt_fornitore: string | null
          numero_ordine: string | null
          peso_kg: number | null
          ragione_sociale_fornitore: string | null
          righe_importate: number
          righe_in_errore: number
          status: Database["public"]["Enums"]["carico_merci_status"]
          status_history: Json
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          codice_fornitore: string
          created_at?: string
          created_by?: string | null
          data_ddt_fornitore?: string | null
          data_ordine?: string | null
          excel_file_path?: string | null
          extra?: Json
          id?: string
          nota?: string | null
          numero_colli?: number | null
          numero_ddt_fornitore?: string | null
          numero_ordine?: string | null
          peso_kg?: number | null
          ragione_sociale_fornitore?: string | null
          righe_importate?: number
          righe_in_errore?: number
          status?: Database["public"]["Enums"]["carico_merci_status"]
          status_history?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          codice_fornitore?: string
          created_at?: string
          created_by?: string | null
          data_ddt_fornitore?: string | null
          data_ordine?: string | null
          excel_file_path?: string | null
          extra?: Json
          id?: string
          nota?: string | null
          numero_colli?: number | null
          numero_ddt_fornitore?: string | null
          numero_ordine?: string | null
          peso_kg?: number | null
          ragione_sociale_fornitore?: string | null
          righe_importate?: number
          righe_in_errore?: number
          status?: Database["public"]["Enums"]["carico_merci_status"]
          status_history?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      cat: {
        Row: {
          attivo: boolean
          cap: string | null
          codice_categoria: string
          codice_fiscale: string | null
          codice_fornitore: string | null
          created_at: string
          created_by: string | null
          email_ddt: string | null
          email_servizio_clienti: string | null
          id: string
          indirizzo: string | null
          localita: string | null
          note: string | null
          partita_iva: string | null
          provincia: string | null
          ragione_sociale: string
          telefono: string | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          attivo?: boolean
          cap?: string | null
          codice_categoria: string
          codice_fiscale?: string | null
          codice_fornitore?: string | null
          created_at?: string
          created_by?: string | null
          email_ddt?: string | null
          email_servizio_clienti?: string | null
          id?: string
          indirizzo?: string | null
          localita?: string | null
          note?: string | null
          partita_iva?: string | null
          provincia?: string | null
          ragione_sociale: string
          telefono?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          attivo?: boolean
          cap?: string | null
          codice_categoria?: string
          codice_fiscale?: string | null
          codice_fornitore?: string | null
          created_at?: string
          created_by?: string | null
          email_ddt?: string | null
          email_servizio_clienti?: string | null
          id?: string
          indirizzo?: string | null
          localita?: string | null
          note?: string | null
          partita_iva?: string | null
          provincia?: string | null
          ragione_sociale?: string
          telefono?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      catalog_search_config: {
        Row: {
          created_at: string
          debounce_ms: number
          description_search_enabled: boolean
          fuzzy_enabled: boolean
          fuzzy_fallback_count: number
          fuzzy_min_chars: number
          fuzzy_threshold: number
          id: boolean
          min_chars: number
          updated_at: string
          updated_by: string | null
          version: number
          weights: Json
        }
        Insert: {
          created_at?: string
          debounce_ms?: number
          description_search_enabled?: boolean
          fuzzy_enabled?: boolean
          fuzzy_fallback_count?: number
          fuzzy_min_chars?: number
          fuzzy_threshold?: number
          id?: boolean
          min_chars?: number
          updated_at?: string
          updated_by?: string | null
          version?: number
          weights?: Json
        }
        Update: {
          created_at?: string
          debounce_ms?: number
          description_search_enabled?: boolean
          fuzzy_enabled?: boolean
          fuzzy_fallback_count?: number
          fuzzy_min_chars?: number
          fuzzy_threshold?: number
          id?: boolean
          min_chars?: number
          updated_at?: string
          updated_by?: string | null
          version?: number
          weights?: Json
        }
        Relationships: []
      }
      catalog_search_exclusions: {
        Row: {
          active: boolean
          created_at: string
          created_by: string | null
          exclusion_type: string
          id: string
          notes: string | null
          term: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          active?: boolean
          created_at?: string
          created_by?: string | null
          exclusion_type?: string
          id?: string
          notes?: string | null
          term: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          active?: boolean
          created_at?: string
          created_by?: string | null
          exclusion_type?: string
          id?: string
          notes?: string | null
          term?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      catalog_search_index: {
        Row: {
          agent_visible: boolean
          attrs_text: string | null
          b2b_product_title: string | null
          b2b_visible: boolean
          brand_code: string | null
          brand_name: string | null
          categoria: string | null
          cdpar: string
          clas1: string | null
          clas2: string | null
          clmer: string | null
          cod_padre: string | null
          compact_norm: string | null
          depar: string | null
          desc_norm: string
          descrizione_variante: string | null
          ean: string | null
          ean_extra: string[]
          fts_all: unknown
          fts_desc: unknown
          fts_short: unknown
          fts_taxo: unknown
          fts_title: unknown
          gamma: string | null
          indexed_at: string
          raw_cdpar: string
          reparto: string | null
          search_config_version: number
          short_norm: string
          source_updated_at: string | null
          tags: string[]
          taxo_norm: string
          title_norm: string | null
          titolo_b2b: string | null
          visible_cdpar: string
        }
        Insert: {
          agent_visible?: boolean
          attrs_text?: string | null
          b2b_product_title?: string | null
          b2b_visible?: boolean
          brand_code?: string | null
          brand_name?: string | null
          categoria?: string | null
          cdpar: string
          clas1?: string | null
          clas2?: string | null
          clmer?: string | null
          cod_padre?: string | null
          compact_norm?: string | null
          depar?: string | null
          desc_norm?: string
          descrizione_variante?: string | null
          ean?: string | null
          ean_extra?: string[]
          fts_all?: unknown
          fts_desc?: unknown
          fts_short?: unknown
          fts_taxo?: unknown
          fts_title?: unknown
          gamma?: string | null
          indexed_at?: string
          raw_cdpar: string
          reparto?: string | null
          search_config_version?: number
          short_norm?: string
          source_updated_at?: string | null
          tags?: string[]
          taxo_norm?: string
          title_norm?: string | null
          titolo_b2b?: string | null
          visible_cdpar: string
        }
        Update: {
          agent_visible?: boolean
          attrs_text?: string | null
          b2b_product_title?: string | null
          b2b_visible?: boolean
          brand_code?: string | null
          brand_name?: string | null
          categoria?: string | null
          cdpar?: string
          clas1?: string | null
          clas2?: string | null
          clmer?: string | null
          cod_padre?: string | null
          compact_norm?: string | null
          depar?: string | null
          desc_norm?: string
          descrizione_variante?: string | null
          ean?: string | null
          ean_extra?: string[]
          fts_all?: unknown
          fts_desc?: unknown
          fts_short?: unknown
          fts_taxo?: unknown
          fts_title?: unknown
          gamma?: string | null
          indexed_at?: string
          raw_cdpar?: string
          reparto?: string | null
          search_config_version?: number
          short_norm?: string
          source_updated_at?: string | null
          tags?: string[]
          taxo_norm?: string
          title_norm?: string | null
          titolo_b2b?: string | null
          visible_cdpar?: string
        }
        Relationships: []
      }
      catalog_search_product_overrides: {
        Row: {
          boost: number
          cdpar: string
          created_at: string
          excluded_from_search: boolean
          notes: string | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          boost?: number
          cdpar: string
          created_at?: string
          excluded_from_search?: boolean
          notes?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          boost?: number
          cdpar?: string
          created_at?: string
          excluded_from_search?: boolean
          notes?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      catalog_search_rebuild_log: {
        Row: {
          duration_ms: number | null
          error_message: string | null
          finished_at: string | null
          id: string
          items_processed: number
          started_at: string
          status: string
          triggered_by: string | null
        }
        Insert: {
          duration_ms?: number | null
          error_message?: string | null
          finished_at?: string | null
          id?: string
          items_processed?: number
          started_at?: string
          status?: string
          triggered_by?: string | null
        }
        Update: {
          duration_ms?: number | null
          error_message?: string | null
          finished_at?: string | null
          id?: string
          items_processed?: number
          started_at?: string
          status?: string
          triggered_by?: string | null
        }
        Relationships: []
      }
      catalog_search_synonyms: {
        Row: {
          active: boolean
          bidirectional: boolean
          created_at: string
          created_by: string | null
          id: string
          notes: string | null
          synonym: string
          term: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          active?: boolean
          bidirectional?: boolean
          created_at?: string
          created_by?: string | null
          id?: string
          notes?: string | null
          synonym: string
          term: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          active?: boolean
          bidirectional?: boolean
          created_at?: string
          created_by?: string | null
          id?: string
          notes?: string | null
          synonym?: string
          term?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      client_error_logs: {
        Row: {
          app_version: string | null
          component_stack: string | null
          created_at: string
          customer_code: string | null
          id: string
          kind: string | null
          message: string | null
          stack: string | null
          url: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          app_version?: string | null
          component_stack?: string | null
          created_at?: string
          customer_code?: string | null
          id?: string
          kind?: string | null
          message?: string | null
          stack?: string | null
          url?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          app_version?: string | null
          component_stack?: string | null
          created_at?: string
          customer_code?: string | null
          id?: string
          kind?: string | null
          message?: string | null
          stack?: string | null
          url?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      codici_barre_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      competitor_selectors: {
        Row: {
          competitor_id: string | null
          id: string
          learned_at: string | null
          selectors: Json
          verified_at: string | null
        }
        Insert: {
          competitor_id?: string | null
          id?: string
          learned_at?: string | null
          selectors: Json
          verified_at?: string | null
        }
        Update: {
          competitor_id?: string | null
          id?: string
          learned_at?: string | null
          selectors?: Json
          verified_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "competitor_selectors_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: true
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
        ]
      }
      competitors: {
        Row: {
          catalog_url: string | null
          created_at: string | null
          id: string
          name: string
          notes: string | null
          url: string
        }
        Insert: {
          catalog_url?: string | null
          created_at?: string | null
          id?: string
          name: string
          notes?: string | null
          url: string
        }
        Update: {
          catalog_url?: string | null
          created_at?: string | null
          id?: string
          name?: string
          notes?: string | null
          url?: string
        }
        Relationships: []
      }
      contestazioni_fornitori: {
        Row: {
          carico_merci_id: string | null
          causale: string | null
          codice_fornitore: string
          created_at: string
          created_by: string | null
          extra: Json
          id: string
          nota: string | null
          ragione_sociale_fornitore: string | null
          riferimento_carico: string | null
          status: Database["public"]["Enums"]["contestazione_status"]
          status_history: Json
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          carico_merci_id?: string | null
          causale?: string | null
          codice_fornitore: string
          created_at?: string
          created_by?: string | null
          extra?: Json
          id?: string
          nota?: string | null
          ragione_sociale_fornitore?: string | null
          riferimento_carico?: string | null
          status?: Database["public"]["Enums"]["contestazione_status"]
          status_history?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          carico_merci_id?: string | null
          causale?: string | null
          codice_fornitore?: string
          created_at?: string
          created_by?: string | null
          extra?: Json
          id?: string
          nota?: string | null
          ragione_sociale_fornitore?: string | null
          riferimento_carico?: string | null
          status?: Database["public"]["Enums"]["contestazione_status"]
          status_history?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "contestazioni_fornitori_carico_merci_id_fkey"
            columns: ["carico_merci_id"]
            isOneToOne: false
            referencedRelation: "carico_merci"
            referencedColumns: ["id"]
          },
        ]
      }
      contestazioni_fornitori_articoli: {
        Row: {
          causale: string
          codice_articolo: string
          contestazione_id: string
          created_at: string
          descrizione: string | null
          id: string
          qta_confermata: number | null
          qta_diff: number
          qta_prevista: number | null
        }
        Insert: {
          causale: string
          codice_articolo: string
          contestazione_id: string
          created_at?: string
          descrizione?: string | null
          id?: string
          qta_confermata?: number | null
          qta_diff?: number
          qta_prevista?: number | null
        }
        Update: {
          causale?: string
          codice_articolo?: string
          contestazione_id?: string
          created_at?: string
          descrizione?: string | null
          id?: string
          qta_confermata?: number | null
          qta_diff?: number
          qta_prevista?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "contestazioni_fornitori_articoli_contestazione_id_fkey"
            columns: ["contestazione_id"]
            isOneToOne: false
            referencedRelation: "contestazioni_fornitori"
            referencedColumns: ["id"]
          },
        ]
      }
      credentials: {
        Row: {
          competitor_id: string | null
          email: string
          id: string
          password: string
          updated_at: string | null
        }
        Insert: {
          competitor_id?: string | null
          email: string
          id?: string
          password: string
          updated_at?: string | null
        }
        Update: {
          competitor_id?: string | null
          email?: string
          id?: string
          password?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "credentials_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
        ]
      }
      currency_rates_daily: {
        Row: {
          as400_rate: number | null
          cdval: string
          cdval_ref: string
          created_at: string
          delta_pct: number | null
          id: string
          market_rate: number
          rate_date: string
          source: string | null
          updated_at: string
        }
        Insert: {
          as400_rate?: number | null
          cdval: string
          cdval_ref?: string
          created_at?: string
          delta_pct?: number | null
          id?: string
          market_rate: number
          rate_date: string
          source?: string | null
          updated_at?: string
        }
        Update: {
          as400_rate?: number | null
          cdval?: string
          cdval_ref?: string
          created_at?: string
          delta_pct?: number | null
          id?: string
          market_rate?: number
          rate_date?: string
          source?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      customer_carts: {
        Row: {
          active_order_index: number
          id: string
          last_writer_client_id: string | null
          orders: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          active_order_index?: number
          id?: string
          last_writer_client_id?: string | null
          orders?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          active_order_index?: number
          id?: string
          last_writer_client_id?: string | null
          orders?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      customer_compare: {
        Row: {
          added_at: string
          auth_user_id: string
          id: string
          product_id: string
        }
        Insert: {
          added_at?: string
          auth_user_id: string
          id?: string
          product_id: string
        }
        Update: {
          added_at?: string
          auth_user_id?: string
          id?: string
          product_id?: string
        }
        Relationships: []
      }
      customer_documents: {
        Row: {
          auth_user_id: string | null
          created_at: string
          currency: string | null
          customer_id: string | null
          doc_date: string
          doc_number: string
          doc_type: string
          file_url: string | null
          id: string
          meta: Json | null
          total: number | null
        }
        Insert: {
          auth_user_id?: string | null
          created_at?: string
          currency?: string | null
          customer_id?: string | null
          doc_date: string
          doc_number: string
          doc_type: string
          file_url?: string | null
          id?: string
          meta?: Json | null
          total?: number | null
        }
        Update: {
          auth_user_id?: string | null
          created_at?: string
          currency?: string | null
          customer_id?: string | null
          doc_date?: string
          doc_number?: string
          doc_type?: string
          file_url?: string | null
          id?: string
          meta?: Json | null
          total?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "customer_documents_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_favorites: {
        Row: {
          added_at: string
          id: string
          product_id: string
          user_id: string
        }
        Insert: {
          added_at?: string
          id?: string
          product_id: string
          user_id: string
        }
        Update: {
          added_at?: string
          id?: string
          product_id?: string
          user_id?: string
        }
        Relationships: []
      }
      customer_lists: {
        Row: {
          created_at: string
          customer_id: string | null
          id: string
          list_key: string
          name: string
          product_ids: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          customer_id?: string | null
          id?: string
          list_key: string
          name: string
          product_ids?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          customer_id?: string | null
          id?: string
          list_key?: string
          name?: string
          product_ids?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      customer_order_items: {
        Row: {
          applied_promo: string | null
          brand: string | null
          created_at: string
          discount_pct: number
          final_price: number
          id: string
          image: string | null
          is_omaggio: boolean
          line_total: number
          list_price: number
          name: string | null
          net_price: number
          order_id: string
          product_id: string | null
          quantity: number
          sku: string | null
          unit_price: number
        }
        Insert: {
          applied_promo?: string | null
          brand?: string | null
          created_at?: string
          discount_pct?: number
          final_price?: number
          id?: string
          image?: string | null
          is_omaggio?: boolean
          line_total?: number
          list_price?: number
          name?: string | null
          net_price?: number
          order_id: string
          product_id?: string | null
          quantity?: number
          sku?: string | null
          unit_price?: number
        }
        Update: {
          applied_promo?: string | null
          brand?: string | null
          created_at?: string
          discount_pct?: number
          final_price?: number
          id?: string
          image?: string | null
          is_omaggio?: boolean
          line_total?: number
          list_price?: number
          name?: string | null
          net_price?: number
          order_id?: string
          product_id?: string | null
          quantity?: number
          sku?: string | null
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "customer_order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "customer_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_order_items_price_fix_log: {
        Row: {
          fixed_at: string
          id: string
          listino: string | null
          new_line_total: number | null
          new_unit_price: number | null
          old_line_total: number | null
          old_unit_price: number | null
          order_id: string
          order_item_id: string
          quantity: number | null
          sku: string | null
        }
        Insert: {
          fixed_at?: string
          id?: string
          listino?: string | null
          new_line_total?: number | null
          new_unit_price?: number | null
          old_line_total?: number | null
          old_unit_price?: number | null
          order_id: string
          order_item_id: string
          quantity?: number | null
          sku?: string | null
        }
        Update: {
          fixed_at?: string
          id?: string
          listino?: string | null
          new_line_total?: number | null
          new_unit_price?: number | null
          old_line_total?: number | null
          old_unit_price?: number | null
          order_id?: string
          order_item_id?: string
          quantity?: number | null
          sku?: string | null
        }
        Relationships: []
      }
      customer_orders: {
        Row: {
          auth_user_id: string | null
          client_request_id: string | null
          codice_agente: string | null
          codice_cliente: string | null
          confirmation_email_sent_at: string | null
          created_at: string
          customer_id: string | null
          id: string
          items_fingerprint: string | null
          listino: string | null
          note: string | null
          origine: string | null
          status: string
          total: number
          transmission_id: string
          updated_at: string
          visibile_al_cliente: boolean
        }
        Insert: {
          auth_user_id?: string | null
          client_request_id?: string | null
          codice_agente?: string | null
          codice_cliente?: string | null
          confirmation_email_sent_at?: string | null
          created_at?: string
          customer_id?: string | null
          id?: string
          items_fingerprint?: string | null
          listino?: string | null
          note?: string | null
          origine?: string | null
          status?: string
          total?: number
          transmission_id: string
          updated_at?: string
          visibile_al_cliente?: boolean
        }
        Update: {
          auth_user_id?: string | null
          client_request_id?: string | null
          codice_agente?: string | null
          codice_cliente?: string | null
          confirmation_email_sent_at?: string | null
          created_at?: string
          customer_id?: string | null
          id?: string
          items_fingerprint?: string | null
          listino?: string | null
          note?: string | null
          origine?: string | null
          status?: string
          total?: number
          transmission_id?: string
          updated_at?: string
          visibile_al_cliente?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "customer_orders_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_pdf_prefs: {
        Row: {
          brand_color: string
          brand_color_2: string | null
          customer_id: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          brand_color?: string
          brand_color_2?: string | null
          customer_id: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          brand_color?: string
          brand_color_2?: string | null
          customer_id?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      customer_quote_extra_costs: {
        Row: {
          amount: number
          cost_type: string
          enabled: boolean
          id: string
          label: string | null
          quote_id: string
          sort_order: number
          vat_included: boolean
          vat_rate: number | null
        }
        Insert: {
          amount?: number
          cost_type: string
          enabled?: boolean
          id?: string
          label?: string | null
          quote_id: string
          sort_order?: number
          vat_included?: boolean
          vat_rate?: number | null
        }
        Update: {
          amount?: number
          cost_type?: string
          enabled?: boolean
          id?: string
          label?: string | null
          quote_id?: string
          sort_order?: number
          vat_included?: boolean
          vat_rate?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "customer_quote_extra_costs_quote_id_fkey"
            columns: ["quote_id"]
            isOneToOne: false
            referencedRelation: "customer_quotes"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_quote_lines: {
        Row: {
          base_cost: number
          created_at: string
          id: string
          image: string | null
          name: string | null
          product_id: string | null
          quantity: number
          quote_id: string
          sku: string | null
          sort_order: number
          unit: string | null
          unit_price: number
          vat_rate: number | null
        }
        Insert: {
          base_cost?: number
          created_at?: string
          id?: string
          image?: string | null
          name?: string | null
          product_id?: string | null
          quantity?: number
          quote_id: string
          sku?: string | null
          sort_order?: number
          unit?: string | null
          unit_price?: number
          vat_rate?: number | null
        }
        Update: {
          base_cost?: number
          created_at?: string
          id?: string
          image?: string | null
          name?: string | null
          product_id?: string | null
          quantity?: number
          quote_id?: string
          sku?: string | null
          sort_order?: number
          unit?: string | null
          unit_price?: number
          vat_rate?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "customer_quote_lines_quote_id_fkey"
            columns: ["quote_id"]
            isOneToOne: false
            referencedRelation: "customer_quotes"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_quotes: {
        Row: {
          auth_user_id: string | null
          created_at: string
          customer_id: string | null
          customer_name: string | null
          date: string
          global_markup: number | null
          grand_total: number
          header: Json
          id: string
          number: string
          pricing_mode: string
          show_prices: boolean
          show_total: boolean
          status: string
          subtotal: number
          updated_at: string
          vat_amount: number
          vat_rate: number
        }
        Insert: {
          auth_user_id?: string | null
          created_at?: string
          customer_id?: string | null
          customer_name?: string | null
          date?: string
          global_markup?: number | null
          grand_total?: number
          header?: Json
          id?: string
          number: string
          pricing_mode?: string
          show_prices?: boolean
          show_total?: boolean
          status?: string
          subtotal?: number
          updated_at?: string
          vat_amount?: number
          vat_rate?: number
        }
        Update: {
          auth_user_id?: string | null
          created_at?: string
          customer_id?: string | null
          customer_name?: string | null
          date?: string
          global_markup?: number | null
          grand_total?: number
          header?: Json
          id?: string
          number?: string
          pricing_mode?: string
          show_prices?: boolean
          show_total?: boolean
          status?: string
          subtotal?: number
          updated_at?: string
          vat_amount?: number
          vat_rate?: number
        }
        Relationships: [
          {
            foreignKeyName: "customer_quotes_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_sub_profiles: {
        Row: {
          active: boolean
          auth_user_id: string | null
          can_order: boolean
          can_view_docs: boolean
          can_view_prices: boolean
          created_at: string
          customer_id: string | null
          email: string | null
          id: string
          name: string
          phone: string | null
          role: string | null
          updated_at: string
        }
        Insert: {
          active?: boolean
          auth_user_id?: string | null
          can_order?: boolean
          can_view_docs?: boolean
          can_view_prices?: boolean
          created_at?: string
          customer_id?: string | null
          email?: string | null
          id?: string
          name: string
          phone?: string | null
          role?: string | null
          updated_at?: string
        }
        Update: {
          active?: boolean
          auth_user_id?: string | null
          can_order?: boolean
          can_view_docs?: boolean
          can_view_prices?: boolean
          created_at?: string
          customer_id?: string | null
          email?: string | null
          id?: string
          name?: string
          phone?: string | null
          role?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "customer_sub_profiles_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_support_ticket_messages: {
        Row: {
          author_name: string | null
          author_type: string
          author_user_id: string | null
          body: string
          created_at: string
          id: string
          ticket_id: string
        }
        Insert: {
          author_name?: string | null
          author_type: string
          author_user_id?: string | null
          body: string
          created_at?: string
          id?: string
          ticket_id: string
        }
        Update: {
          author_name?: string | null
          author_type?: string
          author_user_id?: string | null
          body?: string
          created_at?: string
          id?: string
          ticket_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "customer_support_ticket_messages_ticket_id_fkey"
            columns: ["ticket_id"]
            isOneToOne: false
            referencedRelation: "customer_support_tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_support_tickets: {
        Row: {
          category: string
          contact_email: string | null
          created_at: string
          customer_id: string
          id: string
          message: string
          notification_email_sent_at: string | null
          related_line_ids: Json | null
          related_order_number: string | null
          status: string
          subject: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          category: string
          contact_email?: string | null
          created_at?: string
          customer_id: string
          id?: string
          message: string
          notification_email_sent_at?: string | null
          related_line_ids?: Json | null
          related_order_number?: string | null
          status?: string
          subject: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          category?: string
          contact_email?: string | null
          created_at?: string
          customer_id?: string
          id?: string
          message?: string
          notification_email_sent_at?: string | null
          related_line_ids?: Json | null
          related_order_number?: string | null
          status?: string
          subject?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      customer_videocatalogo_flags: {
        Row: {
          con_ordini: boolean
          customer_code_norm: string
          updated_at: string
          videocatalogo_attivo: boolean
        }
        Insert: {
          con_ordini?: boolean
          customer_code_norm: string
          updated_at?: string
          videocatalogo_attivo?: boolean
        }
        Update: {
          con_ordini?: boolean
          customer_code_norm?: string
          updated_at?: string
          videocatalogo_attivo?: boolean
        }
        Relationships: []
      }
      customers: {
        Row: {
          activated_at: string | null
          address: string | null
          assigned_agent_id: string | null
          auth_user_id: string | null
          bank_branch: string | null
          bank_name: string | null
          billing_customer_code: string | null
          branch_office: string | null
          category_merch: string | null
          category_sales: string | null
          city: string | null
          closing_day: string | null
          codice_ateco: string | null
          company_full_name: string | null
          company_logo_url: string | null
          company_name: string
          company_name_aux: string | null
          competitors: string | null
          contact_mobile: string | null
          contact_name: string | null
          created_at: string | null
          customer_code: string
          customer_service_email: string | null
          customer_service_phone: string | null
          delivery_address: string | null
          delivery_city: string | null
          delivery_notes: string | null
          delivery_postal_code: string | null
          delivery_province: string | null
          descrizione_ateco: string | null
          email: string | null
          email_2: string | null
          email_3: string | null
          email_4: string | null
          email_5: string | null
          has_pc: boolean | null
          iban: string | null
          id: string
          importance: string | null
          is_agent_forced: boolean | null
          last_import_at: string | null
          mail_accesso_cliente: string | null
          must_change_password: boolean
          notes: string | null
          original_agent_code: string | null
          payment_method: string | null
          pec: string | null
          phone: string | null
          pim_notes: string | null
          pim_updated_at: string | null
          pim_updated_by: string | null
          postal_code: string | null
          price_list_code: string | null
          profile_image_url: string | null
          province: string | null
          sdi_code: string | null
          sells_online: boolean | null
          suppliers_present: string | null
          tax_code: string | null
          updated_at: string | null
          vat_number: string | null
          visit_day: string | null
          visit_frequency: string | null
          zone_code: string | null
        }
        Insert: {
          activated_at?: string | null
          address?: string | null
          assigned_agent_id?: string | null
          auth_user_id?: string | null
          bank_branch?: string | null
          bank_name?: string | null
          billing_customer_code?: string | null
          branch_office?: string | null
          category_merch?: string | null
          category_sales?: string | null
          city?: string | null
          closing_day?: string | null
          codice_ateco?: string | null
          company_full_name?: string | null
          company_logo_url?: string | null
          company_name: string
          company_name_aux?: string | null
          competitors?: string | null
          contact_mobile?: string | null
          contact_name?: string | null
          created_at?: string | null
          customer_code: string
          customer_service_email?: string | null
          customer_service_phone?: string | null
          delivery_address?: string | null
          delivery_city?: string | null
          delivery_notes?: string | null
          delivery_postal_code?: string | null
          delivery_province?: string | null
          descrizione_ateco?: string | null
          email?: string | null
          email_2?: string | null
          email_3?: string | null
          email_4?: string | null
          email_5?: string | null
          has_pc?: boolean | null
          iban?: string | null
          id?: string
          importance?: string | null
          is_agent_forced?: boolean | null
          last_import_at?: string | null
          mail_accesso_cliente?: string | null
          must_change_password?: boolean
          notes?: string | null
          original_agent_code?: string | null
          payment_method?: string | null
          pec?: string | null
          phone?: string | null
          pim_notes?: string | null
          pim_updated_at?: string | null
          pim_updated_by?: string | null
          postal_code?: string | null
          price_list_code?: string | null
          profile_image_url?: string | null
          province?: string | null
          sdi_code?: string | null
          sells_online?: boolean | null
          suppliers_present?: string | null
          tax_code?: string | null
          updated_at?: string | null
          vat_number?: string | null
          visit_day?: string | null
          visit_frequency?: string | null
          zone_code?: string | null
        }
        Update: {
          activated_at?: string | null
          address?: string | null
          assigned_agent_id?: string | null
          auth_user_id?: string | null
          bank_branch?: string | null
          bank_name?: string | null
          billing_customer_code?: string | null
          branch_office?: string | null
          category_merch?: string | null
          category_sales?: string | null
          city?: string | null
          closing_day?: string | null
          codice_ateco?: string | null
          company_full_name?: string | null
          company_logo_url?: string | null
          company_name?: string
          company_name_aux?: string | null
          competitors?: string | null
          contact_mobile?: string | null
          contact_name?: string | null
          created_at?: string | null
          customer_code?: string
          customer_service_email?: string | null
          customer_service_phone?: string | null
          delivery_address?: string | null
          delivery_city?: string | null
          delivery_notes?: string | null
          delivery_postal_code?: string | null
          delivery_province?: string | null
          descrizione_ateco?: string | null
          email?: string | null
          email_2?: string | null
          email_3?: string | null
          email_4?: string | null
          email_5?: string | null
          has_pc?: boolean | null
          iban?: string | null
          id?: string
          importance?: string | null
          is_agent_forced?: boolean | null
          last_import_at?: string | null
          mail_accesso_cliente?: string | null
          must_change_password?: boolean
          notes?: string | null
          original_agent_code?: string | null
          payment_method?: string | null
          pec?: string | null
          phone?: string | null
          pim_notes?: string | null
          pim_updated_at?: string | null
          pim_updated_by?: string | null
          postal_code?: string | null
          price_list_code?: string | null
          profile_image_url?: string | null
          province?: string | null
          sdi_code?: string | null
          sells_online?: boolean | null
          suppliers_present?: string | null
          tax_code?: string | null
          updated_at?: string | null
          vat_number?: string | null
          visit_day?: string | null
          visit_frequency?: string | null
          zone_code?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "customers_assigned_agent_id_fkey"
            columns: ["assigned_agent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      ddt: {
        Row: {
          articoli_json: Json
          aspetto_beni: string | null
          causale_trasporto: string | null
          cliente_codice: string | null
          created_at: string
          created_by: string | null
          data_emissione: string
          data_trasporto: string | null
          destinatario_cap: string | null
          destinatario_citta: string | null
          destinatario_indirizzo: string | null
          destinatario_partita_iva: string | null
          destinatario_ragione_sociale: string | null
          destinatario_telefono: string | null
          extra: Json
          fornitore_codice: string | null
          id: string
          mittente_cap: string | null
          mittente_citta: string | null
          mittente_indirizzo: string | null
          mittente_partita_iva: string | null
          mittente_ragione_sociale: string | null
          mittente_telefono: string | null
          note: string | null
          numero_colli: number | null
          numero_ddt: string
          numero_ddt_cliente: string | null
          pdf_url: string | null
          peso_kg: number | null
          porto: string | null
          shipping_cat_id: string | null
          source_record_id: string | null
          source_table: string | null
          status: Database["public"]["Enums"]["ddt_status"]
          status_history: Json
          template_id: string | null
          updated_at: string
          updated_by: string | null
          vettore: string | null
          workflow_instance_id: string | null
        }
        Insert: {
          articoli_json?: Json
          aspetto_beni?: string | null
          causale_trasporto?: string | null
          cliente_codice?: string | null
          created_at?: string
          created_by?: string | null
          data_emissione?: string
          data_trasporto?: string | null
          destinatario_cap?: string | null
          destinatario_citta?: string | null
          destinatario_indirizzo?: string | null
          destinatario_partita_iva?: string | null
          destinatario_ragione_sociale?: string | null
          destinatario_telefono?: string | null
          extra?: Json
          fornitore_codice?: string | null
          id?: string
          mittente_cap?: string | null
          mittente_citta?: string | null
          mittente_indirizzo?: string | null
          mittente_partita_iva?: string | null
          mittente_ragione_sociale?: string | null
          mittente_telefono?: string | null
          note?: string | null
          numero_colli?: number | null
          numero_ddt: string
          numero_ddt_cliente?: string | null
          pdf_url?: string | null
          peso_kg?: number | null
          porto?: string | null
          shipping_cat_id?: string | null
          source_record_id?: string | null
          source_table?: string | null
          status?: Database["public"]["Enums"]["ddt_status"]
          status_history?: Json
          template_id?: string | null
          updated_at?: string
          updated_by?: string | null
          vettore?: string | null
          workflow_instance_id?: string | null
        }
        Update: {
          articoli_json?: Json
          aspetto_beni?: string | null
          causale_trasporto?: string | null
          cliente_codice?: string | null
          created_at?: string
          created_by?: string | null
          data_emissione?: string
          data_trasporto?: string | null
          destinatario_cap?: string | null
          destinatario_citta?: string | null
          destinatario_indirizzo?: string | null
          destinatario_partita_iva?: string | null
          destinatario_ragione_sociale?: string | null
          destinatario_telefono?: string | null
          extra?: Json
          fornitore_codice?: string | null
          id?: string
          mittente_cap?: string | null
          mittente_citta?: string | null
          mittente_indirizzo?: string | null
          mittente_partita_iva?: string | null
          mittente_ragione_sociale?: string | null
          mittente_telefono?: string | null
          note?: string | null
          numero_colli?: number | null
          numero_ddt?: string
          numero_ddt_cliente?: string | null
          pdf_url?: string | null
          peso_kg?: number | null
          porto?: string | null
          shipping_cat_id?: string | null
          source_record_id?: string | null
          source_table?: string | null
          status?: Database["public"]["Enums"]["ddt_status"]
          status_history?: Json
          template_id?: string | null
          updated_at?: string
          updated_by?: string | null
          vettore?: string | null
          workflow_instance_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ddt_shipping_cat_id_fkey"
            columns: ["shipping_cat_id"]
            isOneToOne: false
            referencedRelation: "cat"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ddt_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "ddt_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      ddt_sequences: {
        Row: {
          created_at: string
          current_value: number
          id: string
          prefix: string | null
          sequence_name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          current_value?: number
          id?: string
          prefix?: string | null
          sequence_name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          current_value?: number
          id?: string
          prefix?: string | null
          sequence_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      ddt_templates: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          is_default: boolean
          name: string
          template_data: Json
          thumbnail_url: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_default?: boolean
          name: string
          template_data?: Json
          thumbnail_url?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_default?: boolean
          name?: string
          template_data?: Json
          thumbnail_url?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      department_pins: {
        Row: {
          created_at: string | null
          department_email: string
          full_name: string
          id: string
          is_active: boolean | null
          pin_hash: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          department_email: string
          full_name: string
          id?: string
          is_active?: boolean | null
          pin_hash: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          department_email?: string
          full_name?: string
          id?: string
          is_active?: boolean | null
          pin_hash?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      department_preferences: {
        Row: {
          created_at: string | null
          default_theme: string | null
          department_id: string
          id: string
          notification_settings: Json | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          default_theme?: string | null
          department_id: string
          id?: string
          notification_settings?: Json | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          default_theme?: string | null
          department_id?: string
          id?: string
          notification_settings?: Json | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "department_preferences_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: true
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      department_sub_users: {
        Row: {
          created_at: string
          created_by: string | null
          display_name: string
          id: string
          is_active: boolean
          must_change_password: boolean
          parent_email: string
          parent_user_id: string
          password_hash: string | null
          sub_user_id: string
          tech_email: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          display_name: string
          id?: string
          is_active?: boolean
          must_change_password?: boolean
          parent_email: string
          parent_user_id: string
          password_hash?: string | null
          sub_user_id: string
          tech_email: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          display_name?: string
          id?: string
          is_active?: boolean
          must_change_password?: boolean
          parent_email?: string
          parent_user_id?: string
          password_hash?: string | null
          sub_user_id?: string
          tech_email?: string
          updated_at?: string
        }
        Relationships: []
      }
      departments: {
        Row: {
          color: string | null
          created_at: string
          description: string | null
          icon: string | null
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          color?: string | null
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          color?: string | null
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      differenziale_cambio: {
        Row: {
          created_at: string
          id: string
          updated_at: string
          wan02: string | null
          wbcf0: string | null
          wbcf1: string | null
          wbcf2: string | null
          wbcf3: string | null
          wbcf4: string | null
          wbcf5: string | null
          wbcf6: string | null
          wbcf7: string | null
          wbcf8: string | null
          wbcf9: string | null
          wcacq: string | null
          wcaf0: string | null
          wcaf1: string | null
          wcaf2: string | null
          wcaf3: string | null
          wcaf4: string | null
          wcaf5: string | null
          wcaf6: string | null
          wcaf7: string | null
          wcaf8: string | null
          wcaf9: string | null
          wcdfo: string | null
          wcdva: string | null
          wctri: number | null
          wctrie: number | null
          wctrp: number | null
          wdacq: string | null
          wdtvaf: string | null
          wdtvai: string | null
          wfoca: string | null
          wicf0: string | null
          wicf1: string | null
          wicf2: string | null
          wicf3: string | null
          wicf4: string | null
          wicf5: string | null
          wicf6: string | null
          wicf7: string | null
          wicf8: string | null
          wicf9: string | null
          wltpr: string | null
          wmasc: number | null
          wqtde: string | null
          wscf0: number | null
          wscf1: number | null
          wscf2: number | null
          wscf3: number | null
          wscf4: number | null
          wscf5: number | null
          wscf6: number | null
          wscf7: number | null
          wscf8: number | null
          wscf9: number | null
          wscfa: number | null
          wscfb: number | null
          wscfc: number | null
          wscfd: number | null
          wscfe: number | null
          wsisc: number | null
          wsisce: number | null
          wsocp: string | null
          wtaim: string | null
          wumso: string | null
          wviim: string | null
          wviqm: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          updated_at?: string
          wan02?: string | null
          wbcf0?: string | null
          wbcf1?: string | null
          wbcf2?: string | null
          wbcf3?: string | null
          wbcf4?: string | null
          wbcf5?: string | null
          wbcf6?: string | null
          wbcf7?: string | null
          wbcf8?: string | null
          wbcf9?: string | null
          wcacq?: string | null
          wcaf0?: string | null
          wcaf1?: string | null
          wcaf2?: string | null
          wcaf3?: string | null
          wcaf4?: string | null
          wcaf5?: string | null
          wcaf6?: string | null
          wcaf7?: string | null
          wcaf8?: string | null
          wcaf9?: string | null
          wcdfo?: string | null
          wcdva?: string | null
          wctri?: number | null
          wctrie?: number | null
          wctrp?: number | null
          wdacq?: string | null
          wdtvaf?: string | null
          wdtvai?: string | null
          wfoca?: string | null
          wicf0?: string | null
          wicf1?: string | null
          wicf2?: string | null
          wicf3?: string | null
          wicf4?: string | null
          wicf5?: string | null
          wicf6?: string | null
          wicf7?: string | null
          wicf8?: string | null
          wicf9?: string | null
          wltpr?: string | null
          wmasc?: number | null
          wqtde?: string | null
          wscf0?: number | null
          wscf1?: number | null
          wscf2?: number | null
          wscf3?: number | null
          wscf4?: number | null
          wscf5?: number | null
          wscf6?: number | null
          wscf7?: number | null
          wscf8?: number | null
          wscf9?: number | null
          wscfa?: number | null
          wscfb?: number | null
          wscfc?: number | null
          wscfd?: number | null
          wscfe?: number | null
          wsisc?: number | null
          wsisce?: number | null
          wsocp?: string | null
          wtaim?: string | null
          wumso?: string | null
          wviim?: string | null
          wviqm?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          updated_at?: string
          wan02?: string | null
          wbcf0?: string | null
          wbcf1?: string | null
          wbcf2?: string | null
          wbcf3?: string | null
          wbcf4?: string | null
          wbcf5?: string | null
          wbcf6?: string | null
          wbcf7?: string | null
          wbcf8?: string | null
          wbcf9?: string | null
          wcacq?: string | null
          wcaf0?: string | null
          wcaf1?: string | null
          wcaf2?: string | null
          wcaf3?: string | null
          wcaf4?: string | null
          wcaf5?: string | null
          wcaf6?: string | null
          wcaf7?: string | null
          wcaf8?: string | null
          wcaf9?: string | null
          wcdfo?: string | null
          wcdva?: string | null
          wctri?: number | null
          wctrie?: number | null
          wctrp?: number | null
          wdacq?: string | null
          wdtvaf?: string | null
          wdtvai?: string | null
          wfoca?: string | null
          wicf0?: string | null
          wicf1?: string | null
          wicf2?: string | null
          wicf3?: string | null
          wicf4?: string | null
          wicf5?: string | null
          wicf6?: string | null
          wicf7?: string | null
          wicf8?: string | null
          wicf9?: string | null
          wltpr?: string | null
          wmasc?: number | null
          wqtde?: string | null
          wscf0?: number | null
          wscf1?: number | null
          wscf2?: number | null
          wscf3?: number | null
          wscf4?: number | null
          wscf5?: number | null
          wscf6?: number | null
          wscf7?: number | null
          wscf8?: number | null
          wscf9?: number | null
          wscfa?: number | null
          wscfb?: number | null
          wscfc?: number | null
          wscfd?: number | null
          wscfe?: number | null
          wsisc?: number | null
          wsisce?: number | null
          wsocp?: string | null
          wtaim?: string | null
          wumso?: string | null
          wviim?: string | null
          wviqm?: string | null
        }
        Relationships: []
      }
      differenziale_cambio_field_flags: {
        Row: {
          clarify_flag: boolean | null
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean | null
          read_flag: boolean | null
          updated_at: string
          write_flag: boolean | null
        }
        Insert: {
          clarify_flag?: boolean | null
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean | null
          read_flag?: boolean | null
          updated_at?: string
          write_flag?: boolean | null
        }
        Update: {
          clarify_flag?: boolean | null
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean | null
          read_flag?: boolean | null
          updated_at?: string
          write_flag?: boolean | null
        }
        Relationships: []
      }
      dlr_cat: {
        Row: {
          cap: string | null
          codice_categoria: string
          codice_fornitore: string | null
          codice_nazionale: string | null
          created_at: string
          email_servizio_clienti: string | null
          id: string
          import_version: number
          indirizzo: string | null
          localita: string | null
          numero_telefonico: string | null
          partita_iva: string | null
          provincia: string | null
          ragione_sociale: string | null
          source_file: string | null
          updated_at: string
        }
        Insert: {
          cap?: string | null
          codice_categoria: string
          codice_fornitore?: string | null
          codice_nazionale?: string | null
          created_at?: string
          email_servizio_clienti?: string | null
          id?: string
          import_version?: number
          indirizzo?: string | null
          localita?: string | null
          numero_telefonico?: string | null
          partita_iva?: string | null
          provincia?: string | null
          ragione_sociale?: string | null
          source_file?: string | null
          updated_at?: string
        }
        Update: {
          cap?: string | null
          codice_categoria?: string
          codice_fornitore?: string | null
          codice_nazionale?: string | null
          created_at?: string
          email_servizio_clienti?: string | null
          id?: string
          import_version?: number
          indirizzo?: string | null
          localita?: string | null
          numero_telefonico?: string | null
          partita_iva?: string | null
          provincia?: string | null
          ragione_sociale?: string | null
          source_file?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      dlr_ddt: {
        Row: {
          articoli_json: Json | null
          aspetto_beni: string | null
          causale_trasporto: string | null
          created_at: string
          created_by: string | null
          data_emissione: string
          data_trasporto: string | null
          destinatario_cap: string | null
          destinatario_citta: string | null
          destinatario_indirizzo: string | null
          destinatario_partita_iva: string | null
          destinatario_ragione_sociale: string | null
          destinatario_telefono: string | null
          fornitore_codice: string | null
          id: string
          mittente_cap: string | null
          mittente_citta: string | null
          mittente_indirizzo: string | null
          mittente_partita_iva: string | null
          mittente_ragione_sociale: string | null
          mittente_telefono: string | null
          note: string | null
          numero_colli: number | null
          numero_ddt: string
          numero_ddt_cliente: string | null
          pdf_url: string | null
          peso_kg: number | null
          porto: string | null
          shipping_cat_id: string | null
          source_record_id: string | null
          source_table: string | null
          status: string | null
          template_id: string | null
          updated_at: string
          vettore: string | null
          workflow_instance_id: string | null
        }
        Insert: {
          articoli_json?: Json | null
          aspetto_beni?: string | null
          causale_trasporto?: string | null
          created_at?: string
          created_by?: string | null
          data_emissione?: string
          data_trasporto?: string | null
          destinatario_cap?: string | null
          destinatario_citta?: string | null
          destinatario_indirizzo?: string | null
          destinatario_partita_iva?: string | null
          destinatario_ragione_sociale?: string | null
          destinatario_telefono?: string | null
          fornitore_codice?: string | null
          id?: string
          mittente_cap?: string | null
          mittente_citta?: string | null
          mittente_indirizzo?: string | null
          mittente_partita_iva?: string | null
          mittente_ragione_sociale?: string | null
          mittente_telefono?: string | null
          note?: string | null
          numero_colli?: number | null
          numero_ddt: string
          numero_ddt_cliente?: string | null
          pdf_url?: string | null
          peso_kg?: number | null
          porto?: string | null
          shipping_cat_id?: string | null
          source_record_id?: string | null
          source_table?: string | null
          status?: string | null
          template_id?: string | null
          updated_at?: string
          vettore?: string | null
          workflow_instance_id?: string | null
        }
        Update: {
          articoli_json?: Json | null
          aspetto_beni?: string | null
          causale_trasporto?: string | null
          created_at?: string
          created_by?: string | null
          data_emissione?: string
          data_trasporto?: string | null
          destinatario_cap?: string | null
          destinatario_citta?: string | null
          destinatario_indirizzo?: string | null
          destinatario_partita_iva?: string | null
          destinatario_ragione_sociale?: string | null
          destinatario_telefono?: string | null
          fornitore_codice?: string | null
          id?: string
          mittente_cap?: string | null
          mittente_citta?: string | null
          mittente_indirizzo?: string | null
          mittente_partita_iva?: string | null
          mittente_ragione_sociale?: string | null
          mittente_telefono?: string | null
          note?: string | null
          numero_colli?: number | null
          numero_ddt?: string
          numero_ddt_cliente?: string | null
          pdf_url?: string | null
          peso_kg?: number | null
          porto?: string | null
          shipping_cat_id?: string | null
          source_record_id?: string | null
          source_table?: string | null
          status?: string | null
          template_id?: string | null
          updated_at?: string
          vettore?: string | null
          workflow_instance_id?: string | null
        }
        Relationships: []
      }
      dlr_ddt_sequences: {
        Row: {
          created_at: string
          current_value: number
          id: string
          prefix: string | null
          sequence_name: string
          updated_at: string
          workflow_id: string | null
        }
        Insert: {
          created_at?: string
          current_value?: number
          id?: string
          prefix?: string | null
          sequence_name: string
          updated_at?: string
          workflow_id?: string | null
        }
        Update: {
          created_at?: string
          current_value?: number
          id?: string
          prefix?: string | null
          sequence_name?: string
          updated_at?: string
          workflow_id?: string | null
        }
        Relationships: []
      }
      dlr_ddt_templates: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          is_default: boolean | null
          name: string
          template_data: Json
          thumbnail_url: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_default?: boolean | null
          name: string
          template_data?: Json
          thumbnail_url?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_default?: boolean | null
          name?: string
          template_data?: Json
          thumbnail_url?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      dlr_ftp_import_logs: {
        Row: {
          created_at: string
          duration_ms: number | null
          errors: Json
          filename: string | null
          finished_at: string | null
          id: string
          rows_enriched: number
          rows_error: number
          rows_inserted: number
          rows_total: number
          rows_unchanged: number
          started_at: string
          status: string
          triggered_by: string
        }
        Insert: {
          created_at?: string
          duration_ms?: number | null
          errors?: Json
          filename?: string | null
          finished_at?: string | null
          id?: string
          rows_enriched?: number
          rows_error?: number
          rows_inserted?: number
          rows_total?: number
          rows_unchanged?: number
          started_at?: string
          status?: string
          triggered_by?: string
        }
        Update: {
          created_at?: string
          duration_ms?: number | null
          errors?: Json
          filename?: string | null
          finished_at?: string | null
          id?: string
          rows_enriched?: number
          rows_error?: number
          rows_inserted?: number
          rows_total?: number
          rows_unchanged?: number
          started_at?: string
          status?: string
          triggered_by?: string
        }
        Relationships: []
      }
      dlr_maintenance_status: {
        Row: {
          enabled: boolean
          id: boolean
          message: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          enabled?: boolean
          id?: boolean
          message?: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          enabled?: boolean
          id?: boolean
          message?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      email_send_log: {
        Row: {
          created_at: string
          error: string | null
          id: string
          is_test: boolean
          order_id: string | null
          recipient: string
          status: string
          subject: string | null
          template_key: string | null
        }
        Insert: {
          created_at?: string
          error?: string | null
          id?: string
          is_test?: boolean
          order_id?: string | null
          recipient: string
          status: string
          subject?: string | null
          template_key?: string | null
        }
        Update: {
          created_at?: string
          error?: string | null
          id?: string
          is_test?: boolean
          order_id?: string | null
          recipient?: string
          status?: string
          subject?: string | null
          template_key?: string | null
        }
        Relationships: []
      }
      email_templates: {
        Row: {
          body_html: string
          created_at: string
          description: string | null
          enabled: boolean
          id: string
          key: string
          name: string
          subject: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          body_html: string
          created_at?: string
          description?: string | null
          enabled?: boolean
          id?: string
          key: string
          name: string
          subject: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          body_html?: string
          created_at?: string
          description?: string | null
          enabled?: boolean
          id?: string
          key?: string
          name?: string
          subject?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      fatture_clienti_righe: {
        Row: {
          cifra: number | null
          cod_cliente2: string | null
          codice_articolo: string | null
          codice_cliente: string | null
          codice_finale: string | null
          created_at: string
          data_fattura: string | null
          dedup_key: string | null
          descrizione: string | null
          id: string
          import_run_id: string
          imported_at: string
          intestazione: string | null
          iva: string | null
          lettera: string | null
          line_number: number | null
          numero_fattura: string | null
          prezzo: number | null
          quantita1: number | null
          quantita2: number | null
          raw_line: string | null
          source_file: string | null
          unita: string | null
        }
        Insert: {
          cifra?: number | null
          cod_cliente2?: string | null
          codice_articolo?: string | null
          codice_cliente?: string | null
          codice_finale?: string | null
          created_at?: string
          data_fattura?: string | null
          dedup_key?: string | null
          descrizione?: string | null
          id?: string
          import_run_id: string
          imported_at?: string
          intestazione?: string | null
          iva?: string | null
          lettera?: string | null
          line_number?: number | null
          numero_fattura?: string | null
          prezzo?: number | null
          quantita1?: number | null
          quantita2?: number | null
          raw_line?: string | null
          source_file?: string | null
          unita?: string | null
        }
        Update: {
          cifra?: number | null
          cod_cliente2?: string | null
          codice_articolo?: string | null
          codice_cliente?: string | null
          codice_finale?: string | null
          created_at?: string
          data_fattura?: string | null
          dedup_key?: string | null
          descrizione?: string | null
          id?: string
          import_run_id?: string
          imported_at?: string
          intestazione?: string | null
          iva?: string | null
          lettera?: string | null
          line_number?: number | null
          numero_fattura?: string | null
          prezzo?: number | null
          quantita1?: number | null
          quantita2?: number | null
          raw_line?: string | null
          source_file?: string | null
          unita?: string | null
        }
        Relationships: []
      }
      fatture_pdf: {
        Row: {
          created_at: string
          customer_code: string | null
          data_fattura: string | null
          filename: string
          id: string
          numero_fattura: string | null
          parse_error: string | null
          parsed_ok: boolean
          totale_eur: number | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          customer_code?: string | null
          data_fattura?: string | null
          filename: string
          id?: string
          numero_fattura?: string | null
          parse_error?: string | null
          parsed_ok?: boolean
          totale_eur?: number | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          customer_code?: string | null
          data_fattura?: string | null
          filename?: string
          id?: string
          numero_fattura?: string | null
          parse_error?: string | null
          parsed_ok?: boolean
          totale_eur?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      field_permissions: {
        Row: {
          created_at: string | null
          department_id: string
          field_key: string
          id: string
          permission: string
          role: Database["public"]["Enums"]["app_role"]
          section_key: string
        }
        Insert: {
          created_at?: string | null
          department_id: string
          field_key: string
          id?: string
          permission?: string
          role?: Database["public"]["Enums"]["app_role"]
          section_key: string
        }
        Update: {
          created_at?: string | null
          department_id?: string
          field_key?: string
          id?: string
          permission?: string
          role?: Database["public"]["Enums"]["app_role"]
          section_key?: string
        }
        Relationships: [
          {
            foreignKeyName: "field_permissions_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      fornitori_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      gamma_attribute_options: {
        Row: {
          created_at: string
          gamma_attribute_id: string
          id: string
          option_label: string | null
          option_value: string
          sort_order: number
        }
        Insert: {
          created_at?: string
          gamma_attribute_id: string
          id?: string
          option_label?: string | null
          option_value: string
          sort_order?: number
        }
        Update: {
          created_at?: string
          gamma_attribute_id?: string
          id?: string
          option_label?: string | null
          option_value?: string
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "gamma_attribute_options_gamma_attribute_id_fkey"
            columns: ["gamma_attribute_id"]
            isOneToOne: false
            referencedRelation: "gamma_attributes"
            referencedColumns: ["id"]
          },
        ]
      }
      gamma_attributes: {
        Row: {
          attribute_name: string
          created_at: string
          display_name: string | null
          gamma_code: string
          has_unit_select: boolean
          id: string
          is_required: boolean
          lookup_category: string | null
          sort_order: number
        }
        Insert: {
          attribute_name: string
          created_at?: string
          display_name?: string | null
          gamma_code: string
          has_unit_select?: boolean
          id?: string
          is_required?: boolean
          lookup_category?: string | null
          sort_order?: number
        }
        Update: {
          attribute_name?: string
          created_at?: string
          display_name?: string | null
          gamma_code?: string
          has_unit_select?: boolean
          id?: string
          is_required?: boolean
          lookup_category?: string | null
          sort_order?: number
        }
        Relationships: []
      }
      import_configs: {
        Row: {
          created_at: string
          day_of_month: number | null
          day_of_week: number | null
          description: string | null
          edge_function: string | null
          frequency: Database["public"]["Enums"]["import_frequency"]
          id: string
          is_active: boolean
          last_run_at: string | null
          name: string
          parser_config: Json | null
          render_url: string
          sftp_file_path: string | null
          sftp_host: string | null
          sftp_password_secret_name: string | null
          sftp_username: string | null
          source_type: string
          target_table: string | null
          time_of_day: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          day_of_month?: number | null
          day_of_week?: number | null
          description?: string | null
          edge_function?: string | null
          frequency?: Database["public"]["Enums"]["import_frequency"]
          id?: string
          is_active?: boolean
          last_run_at?: string | null
          name: string
          parser_config?: Json | null
          render_url?: string
          sftp_file_path?: string | null
          sftp_host?: string | null
          sftp_password_secret_name?: string | null
          sftp_username?: string | null
          source_type?: string
          target_table?: string | null
          time_of_day?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          day_of_month?: number | null
          day_of_week?: number | null
          description?: string | null
          edge_function?: string | null
          frequency?: Database["public"]["Enums"]["import_frequency"]
          id?: string
          is_active?: boolean
          last_run_at?: string | null
          name?: string
          parser_config?: Json | null
          render_url?: string
          sftp_file_path?: string | null
          sftp_host?: string | null
          sftp_password_secret_name?: string | null
          sftp_username?: string | null
          source_type?: string
          target_table?: string | null
          time_of_day?: string
          updated_at?: string
        }
        Relationships: []
      }
      import_logs: {
        Row: {
          completed_at: string | null
          config_id: string
          error_message: string | null
          id: string
          records_created: number | null
          records_failed: number | null
          records_processed: number | null
          records_updated: number | null
          started_at: string
          status: Database["public"]["Enums"]["import_status"]
        }
        Insert: {
          completed_at?: string | null
          config_id: string
          error_message?: string | null
          id?: string
          records_created?: number | null
          records_failed?: number | null
          records_processed?: number | null
          records_updated?: number | null
          started_at?: string
          status?: Database["public"]["Enums"]["import_status"]
        }
        Update: {
          completed_at?: string | null
          config_id?: string
          error_message?: string | null
          id?: string
          records_created?: number | null
          records_failed?: number | null
          records_processed?: number | null
          records_updated?: number | null
          started_at?: string
          status?: Database["public"]["Enums"]["import_status"]
        }
        Relationships: [
          {
            foreignKeyName: "import_logs_config_id_fkey"
            columns: ["config_id"]
            isOneToOne: false
            referencedRelation: "import_configs"
            referencedColumns: ["id"]
          },
        ]
      }
      import_sessions: {
        Row: {
          completed_at: string | null
          created_at: string
          created_rows: number | null
          error_rows: number | null
          filename: string | null
          id: string
          import_type: string
          skipped_rows: number | null
          status: string
          total_rows: number | null
          updated_rows: number | null
          user_email: string | null
          user_id: string | null
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          created_rows?: number | null
          error_rows?: number | null
          filename?: string | null
          id?: string
          import_type: string
          skipped_rows?: number | null
          status?: string
          total_rows?: number | null
          updated_rows?: number | null
          user_email?: string | null
          user_id?: string | null
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          created_rows?: number | null
          error_rows?: number | null
          filename?: string | null
          id?: string
          import_type?: string
          skipped_rows?: number | null
          status?: string
          total_rows?: number | null
          updated_rows?: number | null
          user_email?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      inventory_imports: {
        Row: {
          created_at: string
          filename: string | null
          id: string
          matched: number
          total_rows: number
          user_email: string | null
          user_id: string | null
          zeroed: number
        }
        Insert: {
          created_at?: string
          filename?: string | null
          id?: string
          matched?: number
          total_rows?: number
          user_email?: string | null
          user_id?: string | null
          zeroed?: number
        }
        Update: {
          created_at?: string
          filename?: string | null
          id?: string
          matched?: number
          total_rows?: number
          user_email?: string | null
          user_id?: string | null
          zeroed?: number
        }
        Relationships: []
      }
      listini_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      listini_vendita_campagne: {
        Row: {
          created_at: string
          id: string
          updated_at: string
          wcdcl: string | null
          wcdcv: string | null
          wcdls: string | null
          wcdpa: string | null
          wcpam: string | null
          wdtvf: string | null
          wdtvi: string | null
          wnpun: string | null
          wnrsc: string | null
          wprui: number | null
          wprun: number | null
          wqtms: number | null
          wqtxm: number | null
          wqtxn: number | null
          wriatc: string | null
          writac: string | null
          wscon: number | null
          wsimp: string | null
          wtpbl: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          updated_at?: string
          wcdcl?: string | null
          wcdcv?: string | null
          wcdls?: string | null
          wcdpa?: string | null
          wcpam?: string | null
          wdtvf?: string | null
          wdtvi?: string | null
          wnpun?: string | null
          wnrsc?: string | null
          wprui?: number | null
          wprun?: number | null
          wqtms?: number | null
          wqtxm?: number | null
          wqtxn?: number | null
          wriatc?: string | null
          writac?: string | null
          wscon?: number | null
          wsimp?: string | null
          wtpbl?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          updated_at?: string
          wcdcl?: string | null
          wcdcv?: string | null
          wcdls?: string | null
          wcdpa?: string | null
          wcpam?: string | null
          wdtvf?: string | null
          wdtvi?: string | null
          wnpun?: string | null
          wnrsc?: string | null
          wprui?: number | null
          wprun?: number | null
          wqtms?: number | null
          wqtxm?: number | null
          wqtxn?: number | null
          wriatc?: string | null
          writac?: string | null
          wscon?: number | null
          wsimp?: string | null
          wtpbl?: string | null
        }
        Relationships: []
      }
      listini_vendita_campagne_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      listini_vendita_condizioni: {
        Row: {
          created_at: string
          id: string
          updated_at: string
          wcacq: string | null
          wcbve: string | null
          wcdcl: string | null
          wcdcv: string | null
          wcdfo: string | null
          wcdls: string | null
          wcdst: string | null
          wclme: string | null
          wclve: string | null
          wcmri: string | null
          wddlw: string | null
          wgenl: string | null
          wline: string | null
          wmova: string | null
          wrccl: string | null
          wrccv: string | null
          wrcls: string | null
          wsm01: number | null
          wsm02: number | null
          wsm03: number | null
          wsmim: string | null
          wvdim: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          updated_at?: string
          wcacq?: string | null
          wcbve?: string | null
          wcdcl?: string | null
          wcdcv?: string | null
          wcdfo?: string | null
          wcdls?: string | null
          wcdst?: string | null
          wclme?: string | null
          wclve?: string | null
          wcmri?: string | null
          wddlw?: string | null
          wgenl?: string | null
          wline?: string | null
          wmova?: string | null
          wrccl?: string | null
          wrccv?: string | null
          wrcls?: string | null
          wsm01?: number | null
          wsm02?: number | null
          wsm03?: number | null
          wsmim?: string | null
          wvdim?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          updated_at?: string
          wcacq?: string | null
          wcbve?: string | null
          wcdcl?: string | null
          wcdcv?: string | null
          wcdfo?: string | null
          wcdls?: string | null
          wcdst?: string | null
          wclme?: string | null
          wclve?: string | null
          wcmri?: string | null
          wddlw?: string | null
          wgenl?: string | null
          wline?: string | null
          wmova?: string | null
          wrccl?: string | null
          wrccv?: string | null
          wrcls?: string | null
          wsm01?: number | null
          wsm02?: number | null
          wsm03?: number | null
          wsmim?: string | null
          wvdim?: string | null
        }
        Relationships: []
      }
      listini_vendita_condizioni_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      listini_vendita_criteri_prezzo: {
        Row: {
          created_at: string
          id: string
          updated_at: string
          war01: string | null
          wcbve: string | null
          wcdcl: string | null
          wcdcv: string | null
          wcdls: string | null
          wcdpa: string | null
          wcmri: string | null
          wco01: string | null
          wfcsv: number | null
          wic01: string | null
          wmova: string | null
          wnrsc: string | null
          wrccl: string | null
          wrccv: string | null
          wrcls: string | null
          wsm01: number | null
          wsm02: number | null
          wsm03: number | null
          wsmim: string | null
          wta01: string | null
          wvdim: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          updated_at?: string
          war01?: string | null
          wcbve?: string | null
          wcdcl?: string | null
          wcdcv?: string | null
          wcdls?: string | null
          wcdpa?: string | null
          wcmri?: string | null
          wco01?: string | null
          wfcsv?: number | null
          wic01?: string | null
          wmova?: string | null
          wnrsc?: string | null
          wrccl?: string | null
          wrccv?: string | null
          wrcls?: string | null
          wsm01?: number | null
          wsm02?: number | null
          wsm03?: number | null
          wsmim?: string | null
          wta01?: string | null
          wvdim?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          updated_at?: string
          war01?: string | null
          wcbve?: string | null
          wcdcl?: string | null
          wcdcv?: string | null
          wcdls?: string | null
          wcdpa?: string | null
          wcmri?: string | null
          wco01?: string | null
          wfcsv?: number | null
          wic01?: string | null
          wmova?: string | null
          wnrsc?: string | null
          wrccl?: string | null
          wrccv?: string | null
          wrcls?: string | null
          wsm01?: number | null
          wsm02?: number | null
          wsm03?: number | null
          wsmim?: string | null
          wta01?: string | null
          wvdim?: string | null
        }
        Relationships: []
      }
      listini_vendita_criteri_prezzo_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      listini_vendita_def_base: {
        Row: {
          created_at: string
          id: string
          updated_at: string
          wcdli: string | null
          wcdls: string | null
          wfliv: string | null
          wlcos: string | null
          wlipv: string | null
          wlmgc: string | null
          wlorr: string | null
          wlpzn: string | null
          wlsif: string | null
          wltpc: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          updated_at?: string
          wcdli?: string | null
          wcdls?: string | null
          wfliv?: string | null
          wlcos?: string | null
          wlipv?: string | null
          wlmgc?: string | null
          wlorr?: string | null
          wlpzn?: string | null
          wlsif?: string | null
          wltpc?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          updated_at?: string
          wcdli?: string | null
          wcdls?: string | null
          wfliv?: string | null
          wlcos?: string | null
          wlipv?: string | null
          wlmgc?: string | null
          wlorr?: string | null
          wlpzn?: string | null
          wlsif?: string | null
          wltpc?: string | null
        }
        Relationships: []
      }
      listini_vendita_def_base_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      listini_vendita_dettagli: {
        Row: {
          arcll: string | null
          cdafl: string | null
          cdarl: string | null
          cdcll: string | null
          cdcvl: string | null
          cdlsl: string | null
          created_at: string
          daa21: string | null
          dt04l: string | null
          dt05l: string | null
          dt06l: string | null
          dt07l: string | null
          dt08l: string | null
          dt09l: string | null
          dt10l: string | null
          dt11l: string | null
          dt12l: string | null
          dta21: string | null
          dtmal: string | null
          dtmel: string | null
          dtmil: string | null
          dtvfl: string | null
          id: string
          mg04l: number | null
          mg05l: number | null
          mg06l: number | null
          mg07l: number | null
          mg08l: number | null
          mg09l: number | null
          mg10l: number | null
          mg11l: number | null
          mg12l: number | null
          mgmal: number | null
          mgmel: number | null
          mgmil: number | null
          nra21: string | null
          nrscl: string | null
          pc04l: number | null
          pc05l: number | null
          pc06l: number | null
          pc07l: number | null
          pc08l: number | null
          pc09l: number | null
          pc10l: number | null
          pc11l: number | null
          pc12l: number | null
          pcmal: number | null
          pcmel: number | null
          pcmil: number | null
          pg04l: number | null
          pg05l: number | null
          pg06l: number | null
          pg07l: number | null
          pg08l: number | null
          pg09l: number | null
          pg10l: number | null
          pg11l: number | null
          pg12l: number | null
          pgmal: number | null
          pgmel: number | null
          pgmil: number | null
          pr04l: number | null
          pr05l: number | null
          pr06l: number | null
          pr07l: number | null
          pr08l: number | null
          pr09l: number | null
          pr10l: number | null
          pr11l: number | null
          pr12l: number | null
          prmal: number | null
          prmel: number | null
          prmil: number | null
          prmil_backfilled_at: string | null
          qtscl: number | null
          raafl: string | null
          raarl: string | null
          raivl: string | null
          rapsl: number | null
          raqbl: number | null
          raqtl: number | null
          ratpl: string | null
          s041l: number | null
          s042l: number | null
          s051l: number | null
          s052l: number | null
          s061l: number | null
          s062l: number | null
          s071l: number | null
          s072l: number | null
          s081l: number | null
          s082l: number | null
          s091l: number | null
          s092l: number | null
          s101l: number | null
          s102l: number | null
          s111l: number | null
          s112l: number | null
          s121l: number | null
          s122l: number | null
          sma1l: number | null
          sma2l: number | null
          sme1l: number | null
          sme2l: number | null
          smi1l: number | null
          smi2l: number | null
          unmsl: string | null
          updated_at: string
          wpersld: string | null
        }
        Insert: {
          arcll?: string | null
          cdafl?: string | null
          cdarl?: string | null
          cdcll?: string | null
          cdcvl?: string | null
          cdlsl?: string | null
          created_at?: string
          daa21?: string | null
          dt04l?: string | null
          dt05l?: string | null
          dt06l?: string | null
          dt07l?: string | null
          dt08l?: string | null
          dt09l?: string | null
          dt10l?: string | null
          dt11l?: string | null
          dt12l?: string | null
          dta21?: string | null
          dtmal?: string | null
          dtmel?: string | null
          dtmil?: string | null
          dtvfl?: string | null
          id?: string
          mg04l?: number | null
          mg05l?: number | null
          mg06l?: number | null
          mg07l?: number | null
          mg08l?: number | null
          mg09l?: number | null
          mg10l?: number | null
          mg11l?: number | null
          mg12l?: number | null
          mgmal?: number | null
          mgmel?: number | null
          mgmil?: number | null
          nra21?: string | null
          nrscl?: string | null
          pc04l?: number | null
          pc05l?: number | null
          pc06l?: number | null
          pc07l?: number | null
          pc08l?: number | null
          pc09l?: number | null
          pc10l?: number | null
          pc11l?: number | null
          pc12l?: number | null
          pcmal?: number | null
          pcmel?: number | null
          pcmil?: number | null
          pg04l?: number | null
          pg05l?: number | null
          pg06l?: number | null
          pg07l?: number | null
          pg08l?: number | null
          pg09l?: number | null
          pg10l?: number | null
          pg11l?: number | null
          pg12l?: number | null
          pgmal?: number | null
          pgmel?: number | null
          pgmil?: number | null
          pr04l?: number | null
          pr05l?: number | null
          pr06l?: number | null
          pr07l?: number | null
          pr08l?: number | null
          pr09l?: number | null
          pr10l?: number | null
          pr11l?: number | null
          pr12l?: number | null
          prmal?: number | null
          prmel?: number | null
          prmil?: number | null
          prmil_backfilled_at?: string | null
          qtscl?: number | null
          raafl?: string | null
          raarl?: string | null
          raivl?: string | null
          rapsl?: number | null
          raqbl?: number | null
          raqtl?: number | null
          ratpl?: string | null
          s041l?: number | null
          s042l?: number | null
          s051l?: number | null
          s052l?: number | null
          s061l?: number | null
          s062l?: number | null
          s071l?: number | null
          s072l?: number | null
          s081l?: number | null
          s082l?: number | null
          s091l?: number | null
          s092l?: number | null
          s101l?: number | null
          s102l?: number | null
          s111l?: number | null
          s112l?: number | null
          s121l?: number | null
          s122l?: number | null
          sma1l?: number | null
          sma2l?: number | null
          sme1l?: number | null
          sme2l?: number | null
          smi1l?: number | null
          smi2l?: number | null
          unmsl?: string | null
          updated_at?: string
          wpersld?: string | null
        }
        Update: {
          arcll?: string | null
          cdafl?: string | null
          cdarl?: string | null
          cdcll?: string | null
          cdcvl?: string | null
          cdlsl?: string | null
          created_at?: string
          daa21?: string | null
          dt04l?: string | null
          dt05l?: string | null
          dt06l?: string | null
          dt07l?: string | null
          dt08l?: string | null
          dt09l?: string | null
          dt10l?: string | null
          dt11l?: string | null
          dt12l?: string | null
          dta21?: string | null
          dtmal?: string | null
          dtmel?: string | null
          dtmil?: string | null
          dtvfl?: string | null
          id?: string
          mg04l?: number | null
          mg05l?: number | null
          mg06l?: number | null
          mg07l?: number | null
          mg08l?: number | null
          mg09l?: number | null
          mg10l?: number | null
          mg11l?: number | null
          mg12l?: number | null
          mgmal?: number | null
          mgmel?: number | null
          mgmil?: number | null
          nra21?: string | null
          nrscl?: string | null
          pc04l?: number | null
          pc05l?: number | null
          pc06l?: number | null
          pc07l?: number | null
          pc08l?: number | null
          pc09l?: number | null
          pc10l?: number | null
          pc11l?: number | null
          pc12l?: number | null
          pcmal?: number | null
          pcmel?: number | null
          pcmil?: number | null
          pg04l?: number | null
          pg05l?: number | null
          pg06l?: number | null
          pg07l?: number | null
          pg08l?: number | null
          pg09l?: number | null
          pg10l?: number | null
          pg11l?: number | null
          pg12l?: number | null
          pgmal?: number | null
          pgmel?: number | null
          pgmil?: number | null
          pr04l?: number | null
          pr05l?: number | null
          pr06l?: number | null
          pr07l?: number | null
          pr08l?: number | null
          pr09l?: number | null
          pr10l?: number | null
          pr11l?: number | null
          pr12l?: number | null
          prmal?: number | null
          prmel?: number | null
          prmil?: number | null
          prmil_backfilled_at?: string | null
          qtscl?: number | null
          raafl?: string | null
          raarl?: string | null
          raivl?: string | null
          rapsl?: number | null
          raqbl?: number | null
          raqtl?: number | null
          ratpl?: string | null
          s041l?: number | null
          s042l?: number | null
          s051l?: number | null
          s052l?: number | null
          s061l?: number | null
          s062l?: number | null
          s071l?: number | null
          s072l?: number | null
          s081l?: number | null
          s082l?: number | null
          s091l?: number | null
          s092l?: number | null
          s101l?: number | null
          s102l?: number | null
          s111l?: number | null
          s112l?: number | null
          s121l?: number | null
          s122l?: number | null
          sma1l?: number | null
          sma2l?: number | null
          sme1l?: number | null
          sme2l?: number | null
          smi1l?: number | null
          smi2l?: number | null
          unmsl?: string | null
          updated_at?: string
          wpersld?: string | null
        }
        Relationships: []
      }
      listini_vendita_dettagli_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      listini_vendita_testate: {
        Row: {
          cambt: string | null
          cdclt: string | null
          cdcvt: string | null
          cdlst: string | null
          cdvat: string | null
          created_at: string
          daa22: string | null
          dsls2: string | null
          dslst: string | null
          dta22: string | null
          dtac6: string | null
          dtvft: string | null
          id: string
          nra22: string | null
          tcamt: string | null
          updated_at: string
          varct: string | null
          vrsnmb: string | null
          wdmvt: string | null
          wperslt: string | null
        }
        Insert: {
          cambt?: string | null
          cdclt?: string | null
          cdcvt?: string | null
          cdlst?: string | null
          cdvat?: string | null
          created_at?: string
          daa22?: string | null
          dsls2?: string | null
          dslst?: string | null
          dta22?: string | null
          dtac6?: string | null
          dtvft?: string | null
          id?: string
          nra22?: string | null
          tcamt?: string | null
          updated_at?: string
          varct?: string | null
          vrsnmb?: string | null
          wdmvt?: string | null
          wperslt?: string | null
        }
        Update: {
          cambt?: string | null
          cdclt?: string | null
          cdcvt?: string | null
          cdlst?: string | null
          cdvat?: string | null
          created_at?: string
          daa22?: string | null
          dsls2?: string | null
          dslst?: string | null
          dta22?: string | null
          dtac6?: string | null
          dtvft?: string | null
          id?: string
          nra22?: string | null
          tcamt?: string | null
          updated_at?: string
          varct?: string | null
          vrsnmb?: string | null
          wdmvt?: string | null
          wperslt?: string | null
        }
        Relationships: []
      }
      listini_vendita_testate_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      lookup_values: {
        Row: {
          category: string
          code: string
          created_at: string
          description: string | null
          id: string
          image_url: string | null
          is_active: boolean | null
          label: string | null
          parent_category: string | null
          parent_code: string | null
          sort_order: number | null
          synced_as400: boolean | null
          updated_at: string
        }
        Insert: {
          category: string
          code: string
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          label?: string | null
          parent_category?: string | null
          parent_code?: string | null
          sort_order?: number | null
          synced_as400?: boolean | null
          updated_at?: string
        }
        Update: {
          category?: string
          code?: string
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          label?: string | null
          parent_category?: string | null
          parent_code?: string | null
          sort_order?: number | null
          synced_as400?: boolean | null
          updated_at?: string
        }
        Relationships: []
      }
      match_exclusions: {
        Row: {
          articolo_id: string
          created_at: string
          excluded_by: string | null
          id: string
          product_id: string
          reason: string | null
        }
        Insert: {
          articolo_id: string
          created_at?: string
          excluded_by?: string | null
          id?: string
          product_id: string
          reason?: string | null
        }
        Update: {
          articolo_id?: string
          created_at?: string
          excluded_by?: string | null
          id?: string
          product_id?: string
          reason?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "match_exclusions_articolo_id_fkey"
            columns: ["articolo_id"]
            isOneToOne: false
            referencedRelation: "articoli"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "match_exclusions_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      matches: {
        Row: {
          articolo_id: string
          competitor_id: string
          confidence: number
          confirmed: boolean | null
          created_at: string
          id: string
          method: string
          mult_competitor: number
          mult_own: number
          notes: string | null
          product_id: string
          updated_at: string
        }
        Insert: {
          articolo_id: string
          competitor_id: string
          confidence?: number
          confirmed?: boolean | null
          created_at?: string
          id?: string
          method: string
          mult_competitor?: number
          mult_own?: number
          notes?: string | null
          product_id: string
          updated_at?: string
        }
        Update: {
          articolo_id?: string
          competitor_id?: string
          confidence?: number
          confirmed?: boolean | null
          created_at?: string
          id?: string
          method?: string
          mult_competitor?: number
          mult_own?: number
          notes?: string | null
          product_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "matches_articolo_id_fkey"
            columns: ["articolo_id"]
            isOneToOne: false
            referencedRelation: "articoli"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "matches_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "matches_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      news: {
        Row: {
          body_html: string | null
          brand_id: string | null
          brand_logo_url: string | null
          brand_name: string | null
          cover_image_url: string | null
          created_at: string
          created_by: string | null
          display_mode: string
          id: string
          pdf_filename: string | null
          pdf_url: string | null
          photos: string[]
          published_at: string | null
          status: string
          title: string
          updated_at: string
          video_url: string | null
        }
        Insert: {
          body_html?: string | null
          brand_id?: string | null
          brand_logo_url?: string | null
          brand_name?: string | null
          cover_image_url?: string | null
          created_at?: string
          created_by?: string | null
          display_mode?: string
          id?: string
          pdf_filename?: string | null
          pdf_url?: string | null
          photos?: string[]
          published_at?: string | null
          status?: string
          title: string
          updated_at?: string
          video_url?: string | null
        }
        Update: {
          body_html?: string | null
          brand_id?: string | null
          brand_logo_url?: string | null
          brand_name?: string | null
          cover_image_url?: string | null
          created_at?: string
          created_by?: string | null
          display_mode?: string
          id?: string
          pdf_filename?: string | null
          pdf_url?: string | null
          photos?: string[]
          published_at?: string | null
          status?: string
          title?: string
          updated_at?: string
          video_url?: string | null
        }
        Relationships: []
      }
      news_links: {
        Row: {
          created_at: string
          id: string
          label: string | null
          link_type: string
          news_id: string
          target_ref: string
        }
        Insert: {
          created_at?: string
          id?: string
          label?: string | null
          link_type: string
          news_id: string
          target_ref: string
        }
        Update: {
          created_at?: string
          id?: string
          label?: string | null
          link_type?: string
          news_id?: string
          target_ref?: string
        }
        Relationships: [
          {
            foreignKeyName: "news_links_news_id_fkey"
            columns: ["news_id"]
            isOneToOne: false
            referencedRelation: "news"
            referencedColumns: ["id"]
          },
        ]
      }
      news_reads: {
        Row: {
          agent_user_id: string
          id: string
          news_id: string
          read_at: string
        }
        Insert: {
          agent_user_id: string
          id?: string
          news_id: string
          read_at?: string
        }
        Update: {
          agent_user_id?: string
          id?: string
          news_id?: string
          read_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "news_reads_news_id_fkey"
            columns: ["news_id"]
            isOneToOne: false
            referencedRelation: "news"
            referencedColumns: ["id"]
          },
        ]
      }
      nomenclatura_combinata: {
        Row: {
          annpx: string | null
          azipx: string | null
          cdncm: string | null
          cdpar: string
          cdsvz: string | null
          created_at: string
          datpx: string | null
          dimsnt: number | null
          distor: string | null
          distpr: string | null
          dtanx: string | null
          id: string
          updated_at: string
          utepx: string | null
          vrsnmb: string | null
        }
        Insert: {
          annpx?: string | null
          azipx?: string | null
          cdncm?: string | null
          cdpar: string
          cdsvz?: string | null
          created_at?: string
          datpx?: string | null
          dimsnt?: number | null
          distor?: string | null
          distpr?: string | null
          dtanx?: string | null
          id?: string
          updated_at?: string
          utepx?: string | null
          vrsnmb?: string | null
        }
        Update: {
          annpx?: string | null
          azipx?: string | null
          cdncm?: string | null
          cdpar?: string
          cdsvz?: string | null
          created_at?: string
          datpx?: string | null
          dimsnt?: number | null
          distor?: string | null
          distpr?: string | null
          dtanx?: string | null
          id?: string
          updated_at?: string
          utepx?: string | null
          vrsnmb?: string | null
        }
        Relationships: []
      }
      nomenclatura_combinata_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string | null
          id: string
          is_read: boolean | null
          link: string | null
          message: string | null
          title: string
          type: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          is_read?: boolean | null
          link?: string | null
          message?: string | null
          title: string
          type?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          is_read?: boolean | null
          link?: string | null
          message?: string | null
          title?: string
          type?: string | null
          user_id?: string
        }
        Relationships: []
      }
      nuovi_clienti_richieste: {
        Row: {
          agent_code: string | null
          agent_email: string | null
          agent_name: string | null
          agent_profile_id: string | null
          agent_user_id: string
          assigned_customer_code: string | null
          assigned_price_list: string | null
          assigned_zona: string | null
          banca: string | null
          cap: string | null
          categoria: string | null
          cellulare_referente: string | null
          citta: string | null
          codice_fiscale: string | null
          codice_sdi: string | null
          created_at: string
          descrizione_pagamento: string | null
          diversa_destinazione: string | null
          email: string | null
          filiale: string | null
          fornitori_presenti: string | null
          frequenza_visite: string | null
          giorno_chiusura: string | null
          giorno_visita: string | null
          grossisti_concorrenti: string | null
          iban: string | null
          id: string
          importanza: string | null
          indirizzo: string | null
          modalita_altro: string | null
          modalita_pagamento: string | null
          nome_referente: string | null
          note_scarico: string | null
          note_varie: string | null
          notified_agent_outcome: boolean
          notified_office: boolean
          partita_iva: string | null
          pec: string | null
          presenza_pc: string | null
          provincia: string | null
          ragione_sociale: string
          rejection_reason: string | null
          review_notes: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          telefono_negozio: string | null
          updated_at: string
          vendite_online: string | null
          zona: string | null
        }
        Insert: {
          agent_code?: string | null
          agent_email?: string | null
          agent_name?: string | null
          agent_profile_id?: string | null
          agent_user_id: string
          assigned_customer_code?: string | null
          assigned_price_list?: string | null
          assigned_zona?: string | null
          banca?: string | null
          cap?: string | null
          categoria?: string | null
          cellulare_referente?: string | null
          citta?: string | null
          codice_fiscale?: string | null
          codice_sdi?: string | null
          created_at?: string
          descrizione_pagamento?: string | null
          diversa_destinazione?: string | null
          email?: string | null
          filiale?: string | null
          fornitori_presenti?: string | null
          frequenza_visite?: string | null
          giorno_chiusura?: string | null
          giorno_visita?: string | null
          grossisti_concorrenti?: string | null
          iban?: string | null
          id?: string
          importanza?: string | null
          indirizzo?: string | null
          modalita_altro?: string | null
          modalita_pagamento?: string | null
          nome_referente?: string | null
          note_scarico?: string | null
          note_varie?: string | null
          notified_agent_outcome?: boolean
          notified_office?: boolean
          partita_iva?: string | null
          pec?: string | null
          presenza_pc?: string | null
          provincia?: string | null
          ragione_sociale: string
          rejection_reason?: string | null
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          telefono_negozio?: string | null
          updated_at?: string
          vendite_online?: string | null
          zona?: string | null
        }
        Update: {
          agent_code?: string | null
          agent_email?: string | null
          agent_name?: string | null
          agent_profile_id?: string | null
          agent_user_id?: string
          assigned_customer_code?: string | null
          assigned_price_list?: string | null
          assigned_zona?: string | null
          banca?: string | null
          cap?: string | null
          categoria?: string | null
          cellulare_referente?: string | null
          citta?: string | null
          codice_fiscale?: string | null
          codice_sdi?: string | null
          created_at?: string
          descrizione_pagamento?: string | null
          diversa_destinazione?: string | null
          email?: string | null
          filiale?: string | null
          fornitori_presenti?: string | null
          frequenza_visite?: string | null
          giorno_chiusura?: string | null
          giorno_visita?: string | null
          grossisti_concorrenti?: string | null
          iban?: string | null
          id?: string
          importanza?: string | null
          indirizzo?: string | null
          modalita_altro?: string | null
          modalita_pagamento?: string | null
          nome_referente?: string | null
          note_scarico?: string | null
          note_varie?: string | null
          notified_agent_outcome?: boolean
          notified_office?: boolean
          partita_iva?: string | null
          pec?: string | null
          presenza_pc?: string | null
          provincia?: string | null
          ragione_sociale?: string
          rejection_reason?: string | null
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          telefono_negozio?: string | null
          updated_at?: string
          vendite_online?: string | null
          zona?: string | null
        }
        Relationships: []
      }
      ordcli: {
        Row: {
          cdpar: string
          codice_cliente: string
          data_ordine: string
          descrizione: string | null
          finale: string | null
          id: number
          imported_at: string
          numero_ordine: string
          prezzo: number | null
          quantita: number | null
          tipo: string
        }
        Insert: {
          cdpar: string
          codice_cliente: string
          data_ordine: string
          descrizione?: string | null
          finale?: string | null
          id?: number
          imported_at?: string
          numero_ordine: string
          prezzo?: number | null
          quantita?: number | null
          tipo: string
        }
        Update: {
          cdpar?: string
          codice_cliente?: string
          data_ordine?: string
          descrizione?: string | null
          finale?: string | null
          id?: number
          imported_at?: string
          numero_ordine?: string
          prezzo?: number | null
          quantita?: number | null
          tipo?: string
        }
        Relationships: []
      }
      order_download_batch_items: {
        Row: {
          batch_id: string
          order_id: string
          progressivo: number
        }
        Insert: {
          batch_id: string
          order_id: string
          progressivo: number
        }
        Update: {
          batch_id?: string
          order_id?: string
          progressivo?: number
        }
        Relationships: [
          {
            foreignKeyName: "order_download_batch_items_batch_id_fkey"
            columns: ["batch_id"]
            isOneToOne: false
            referencedRelation: "order_download_batches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_download_batch_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: true
            referencedRelation: "customer_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      order_download_batches: {
        Row: {
          created_at: string
          created_by: string | null
          file_name: string | null
          id: string
          orders_count: number
          seq_end: number | null
          seq_start: number | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          file_name?: string | null
          id?: string
          orders_count?: number
          seq_end?: number | null
          seq_start?: number | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          file_name?: string | null
          id?: string
          orders_count?: number
          seq_end?: number | null
          seq_start?: number | null
        }
        Relationships: []
      }
      prezzi_in_attesa: {
        Row: {
          created_at: string
          id: string
          updated_at: string
          watca: string | null
          wcbve: string | null
          wcdca: string | null
          wcdcl: string | null
          wcdcv: string | null
          wcdls: string | null
          wcdpa: string | null
          wdtia: string | null
          wdtin: string | null
          wfcsv: number | null
          wfriv: string | null
          wmova: string | null
          wnmua: string | null
          wnrsc: string | null
          wnsca: string | null
          wprui: number | null
          wprun: number | null
          wsm01: number | null
          wsm02: number | null
          wsm03: number | null
          wsmim: number | null
          wtima: string | null
          wumal: string | null
          wvaef: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          updated_at?: string
          watca?: string | null
          wcbve?: string | null
          wcdca?: string | null
          wcdcl?: string | null
          wcdcv?: string | null
          wcdls?: string | null
          wcdpa?: string | null
          wdtia?: string | null
          wdtin?: string | null
          wfcsv?: number | null
          wfriv?: string | null
          wmova?: string | null
          wnmua?: string | null
          wnrsc?: string | null
          wnsca?: string | null
          wprui?: number | null
          wprun?: number | null
          wsm01?: number | null
          wsm02?: number | null
          wsm03?: number | null
          wsmim?: number | null
          wtima?: string | null
          wumal?: string | null
          wvaef?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          updated_at?: string
          watca?: string | null
          wcbve?: string | null
          wcdca?: string | null
          wcdcl?: string | null
          wcdcv?: string | null
          wcdls?: string | null
          wcdpa?: string | null
          wdtia?: string | null
          wdtin?: string | null
          wfcsv?: number | null
          wfriv?: string | null
          wmova?: string | null
          wnmua?: string | null
          wnrsc?: string | null
          wnsca?: string | null
          wprui?: number | null
          wprun?: number | null
          wsm01?: number | null
          wsm02?: number | null
          wsm03?: number | null
          wsmim?: number | null
          wtima?: string | null
          wumal?: string | null
          wvaef?: string | null
        }
        Relationships: []
      }
      prezzi_in_attesa_field_flags: {
        Row: {
          clarify_flag: boolean | null
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean | null
          read_flag: boolean | null
          updated_at: string
          write_flag: boolean | null
        }
        Insert: {
          clarify_flag?: boolean | null
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean | null
          read_flag?: boolean | null
          updated_at?: string
          write_flag?: boolean | null
        }
        Update: {
          clarify_flag?: boolean | null
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean | null
          read_flag?: boolean | null
          updated_at?: string
          write_flag?: boolean | null
        }
        Relationships: []
      }
      products: {
        Row: {
          competitor_code: string | null
          competitor_id: string | null
          conf: number | null
          description: string | null
          ean: string | null
          id: string
          images: Json | null
          name: string | null
          other_tabs: Json | null
          price: number | null
          promo_price: number | null
          scraped_at: string | null
          stock: string | null
          supplier: string | null
          supplier_code: string | null
          technical_specs: Json | null
        }
        Insert: {
          competitor_code?: string | null
          competitor_id?: string | null
          conf?: number | null
          description?: string | null
          ean?: string | null
          id?: string
          images?: Json | null
          name?: string | null
          other_tabs?: Json | null
          price?: number | null
          promo_price?: number | null
          scraped_at?: string | null
          stock?: string | null
          supplier?: string | null
          supplier_code?: string | null
          technical_specs?: Json | null
        }
        Update: {
          competitor_code?: string | null
          competitor_id?: string | null
          conf?: number | null
          description?: string | null
          ean?: string | null
          id?: string
          images?: Json | null
          name?: string | null
          other_tabs?: Json | null
          price?: number | null
          promo_price?: number | null
          scraped_at?: string | null
          stock?: string | null
          supplier?: string | null
          supplier_code?: string | null
          technical_specs?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "products_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          agent_code: string | null
          agent_notes: string | null
          auth_method: Database["public"]["Enums"]["auth_method"] | null
          avatar_url: string | null
          created_at: string
          department_id: string | null
          email: string
          full_name: string | null
          gdpr_consent: boolean
          has_completed_onboarding: boolean
          id: string
          is_active_agent: boolean
          manager_id: string | null
          marketing_consent_at: string | null
          marketing_consent_source: string | null
          newsletter_subscribed: boolean
          order_email: string | null
          personal_email: string | null
          phone_number: string | null
          phone_set_at: string | null
          price_list_code: string | null
          product_updates: boolean
          sub_department_id: string | null
          terms_accepted_at: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          agent_code?: string | null
          agent_notes?: string | null
          auth_method?: Database["public"]["Enums"]["auth_method"] | null
          avatar_url?: string | null
          created_at?: string
          department_id?: string | null
          email: string
          full_name?: string | null
          gdpr_consent?: boolean
          has_completed_onboarding?: boolean
          id?: string
          is_active_agent?: boolean
          manager_id?: string | null
          marketing_consent_at?: string | null
          marketing_consent_source?: string | null
          newsletter_subscribed?: boolean
          order_email?: string | null
          personal_email?: string | null
          phone_number?: string | null
          phone_set_at?: string | null
          price_list_code?: string | null
          product_updates?: boolean
          sub_department_id?: string | null
          terms_accepted_at?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          agent_code?: string | null
          agent_notes?: string | null
          auth_method?: Database["public"]["Enums"]["auth_method"] | null
          avatar_url?: string | null
          created_at?: string
          department_id?: string | null
          email?: string
          full_name?: string | null
          gdpr_consent?: boolean
          has_completed_onboarding?: boolean
          id?: string
          is_active_agent?: boolean
          manager_id?: string | null
          marketing_consent_at?: string | null
          marketing_consent_source?: string | null
          newsletter_subscribed?: boolean
          order_email?: string | null
          personal_email?: string | null
          phone_number?: string | null
          phone_set_at?: string | null
          price_list_code?: string | null
          product_updates?: boolean
          sub_department_id?: string | null
          terms_accepted_at?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_sub_department_id_fkey"
            columns: ["sub_department_id"]
            isOneToOne: false
            referencedRelation: "sub_departments"
            referencedColumns: ["id"]
          },
        ]
      }
      promo_strutturate_articoli: {
        Row: {
          cdpar: string
          created_at: string
          id: string
          note: string | null
          source: string | null
          source_ref: string | null
          updated_at: string
          wdtvf: string | null
          wdtvi: string | null
          wpprge: number | null
          wpprgf: number
          wprezzo: number | null
          wqtmax: number | null
          wqtmin: number | null
          wsconto1: number | null
          wsconto2: number | null
          wsconto3: number | null
          wstate: string | null
          wumord: string | null
        }
        Insert: {
          cdpar: string
          created_at?: string
          id?: string
          note?: string | null
          source?: string | null
          source_ref?: string | null
          updated_at?: string
          wdtvf?: string | null
          wdtvi?: string | null
          wpprge?: number | null
          wpprgf: number
          wprezzo?: number | null
          wqtmax?: number | null
          wqtmin?: number | null
          wsconto1?: number | null
          wsconto2?: number | null
          wsconto3?: number | null
          wstate?: string | null
          wumord?: string | null
        }
        Update: {
          cdpar?: string
          created_at?: string
          id?: string
          note?: string | null
          source?: string | null
          source_ref?: string | null
          updated_at?: string
          wdtvf?: string | null
          wdtvi?: string | null
          wpprge?: number | null
          wpprgf?: number
          wprezzo?: number | null
          wqtmax?: number | null
          wqtmin?: number | null
          wsconto1?: number | null
          wsconto2?: number | null
          wsconto3?: number | null
          wstate?: string | null
          wumord?: string | null
        }
        Relationships: []
      }
      promo_strutturate_campagne: {
        Row: {
          created_at: string
          id: string
          updated_at: string
          wpcdcla: string | null
          wpcdcva: string | null
          wpcdlsa: string | null
          wpcdpaa: string | null
          wpdatval1: number | null
          wpdatval2: number | null
          wpdtvfa: number | null
          wpdtvia: number | null
          wpfldval1: string | null
          wpfldval2: string | null
          wpimpcpam: string | null
          wpnrsca: number | null
          wpprga: number | null
          wpprgea: number | null
          wpprgta: number | null
          wpqtmsa: number | null
          wpriatca: number | null
          wpricoa: string | null
          wpritaca: string | null
          wptpbla: string | null
          wpumqta: string | null
          wpwdtagg: number | null
          wpwdtimm: number | null
          wpwhhagg: number | null
          wpwhhimm: number | null
          wpwutagg: string | null
          wpwutimm: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          updated_at?: string
          wpcdcla?: string | null
          wpcdcva?: string | null
          wpcdlsa?: string | null
          wpcdpaa?: string | null
          wpdatval1?: number | null
          wpdatval2?: number | null
          wpdtvfa?: number | null
          wpdtvia?: number | null
          wpfldval1?: string | null
          wpfldval2?: string | null
          wpimpcpam?: string | null
          wpnrsca?: number | null
          wpprga?: number | null
          wpprgea?: number | null
          wpprgta?: number | null
          wpqtmsa?: number | null
          wpriatca?: number | null
          wpricoa?: string | null
          wpritaca?: string | null
          wptpbla?: string | null
          wpumqta?: string | null
          wpwdtagg?: number | null
          wpwdtimm?: number | null
          wpwhhagg?: number | null
          wpwhhimm?: number | null
          wpwutagg?: string | null
          wpwutimm?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          updated_at?: string
          wpcdcla?: string | null
          wpcdcva?: string | null
          wpcdlsa?: string | null
          wpcdpaa?: string | null
          wpdatval1?: number | null
          wpdatval2?: number | null
          wpdtvfa?: number | null
          wpdtvia?: number | null
          wpfldval1?: string | null
          wpfldval2?: string | null
          wpimpcpam?: string | null
          wpnrsca?: number | null
          wpprga?: number | null
          wpprgea?: number | null
          wpprgta?: number | null
          wpqtmsa?: number | null
          wpriatca?: number | null
          wpricoa?: string | null
          wpritaca?: string | null
          wptpbla?: string | null
          wpumqta?: string | null
          wpwdtagg?: number | null
          wpwdtimm?: number | null
          wpwhhagg?: number | null
          wpwhhimm?: number | null
          wpwutagg?: string | null
          wpwutimm?: string | null
        }
        Relationships: []
      }
      promo_strutturate_campagne_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      promo_strutturate_condizioni: {
        Row: {
          created_at: string
          id: string
          updated_at: string
          wpaltc: string | null
          wpdapc: number | null
          wpdmac: number | null
          wpdocic: string | null
          wpincc: string | null
          wpindc: string | null
          wpmixdes: string | null
          wporvc: number | null
          wppapc: string | null
          wpprgc: number | null
          wpprgec: number | null
          wprartc: string | null
          wpricon: string | null
          wprifc: string | null
          wprogrc: number | null
          wpsegvc: string | null
          wpseqc: number | null
          wpsm1c: string | null
          wpsm2c: string | null
          wpsm5ac: number | null
          wpsm5c: string | null
          wpsm5dac: number | null
          wpsm5mpc: string | null
          wpstatc: string | null
          wptpvc: string | null
          wpumcc: string | null
          wpunmc: string | null
          wputac: string | null
          wputmc: string | null
          wpval1c: number | null
          wpval2c: number | null
        }
        Insert: {
          created_at?: string
          id?: string
          updated_at?: string
          wpaltc?: string | null
          wpdapc?: number | null
          wpdmac?: number | null
          wpdocic?: string | null
          wpincc?: string | null
          wpindc?: string | null
          wpmixdes?: string | null
          wporvc?: number | null
          wppapc?: string | null
          wpprgc?: number | null
          wpprgec?: number | null
          wprartc?: string | null
          wpricon?: string | null
          wprifc?: string | null
          wprogrc?: number | null
          wpsegvc?: string | null
          wpseqc?: number | null
          wpsm1c?: string | null
          wpsm2c?: string | null
          wpsm5ac?: number | null
          wpsm5c?: string | null
          wpsm5dac?: number | null
          wpsm5mpc?: string | null
          wpstatc?: string | null
          wptpvc?: string | null
          wpumcc?: string | null
          wpunmc?: string | null
          wputac?: string | null
          wputmc?: string | null
          wpval1c?: number | null
          wpval2c?: number | null
        }
        Update: {
          created_at?: string
          id?: string
          updated_at?: string
          wpaltc?: string | null
          wpdapc?: number | null
          wpdmac?: number | null
          wpdocic?: string | null
          wpincc?: string | null
          wpindc?: string | null
          wpmixdes?: string | null
          wporvc?: number | null
          wppapc?: string | null
          wpprgc?: number | null
          wpprgec?: number | null
          wprartc?: string | null
          wpricon?: string | null
          wprifc?: string | null
          wprogrc?: number | null
          wpsegvc?: string | null
          wpseqc?: number | null
          wpsm1c?: string | null
          wpsm2c?: string | null
          wpsm5ac?: number | null
          wpsm5c?: string | null
          wpsm5dac?: number | null
          wpsm5mpc?: string | null
          wpstatc?: string | null
          wptpvc?: string | null
          wpumcc?: string | null
          wpunmc?: string | null
          wputac?: string | null
          wputmc?: string | null
          wpval1c?: number | null
          wpval2c?: number | null
        }
        Relationships: []
      }
      promo_strutturate_condizioni_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      promo_strutturate_destinatari_articoli: {
        Row: {
          article_mode: Database["public"]["Enums"]["promo_destinatari_article_mode"]
          created_at: string
          id: string
          manual_excludes: string[]
          manual_includes: string[]
          rules: Json
          testata_id: string
          updated_at: string
        }
        Insert: {
          article_mode?: Database["public"]["Enums"]["promo_destinatari_article_mode"]
          created_at?: string
          id?: string
          manual_excludes?: string[]
          manual_includes?: string[]
          rules?: Json
          testata_id: string
          updated_at?: string
        }
        Update: {
          article_mode?: Database["public"]["Enums"]["promo_destinatari_article_mode"]
          created_at?: string
          id?: string
          manual_excludes?: string[]
          manual_includes?: string[]
          rules?: Json
          testata_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "promo_strutturate_destinatari_articoli_testata_id_fkey"
            columns: ["testata_id"]
            isOneToOne: true
            referencedRelation: "promo_strutturate_testate"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "promo_strutturate_destinatari_articoli_testata_id_fkey"
            columns: ["testata_id"]
            isOneToOne: true
            referencedRelation: "v_promo_strutturate_testate_stato"
            referencedColumns: ["id"]
          },
        ]
      }
      promo_strutturate_destinatari_clienti: {
        Row: {
          created_at: string
          customer_mode: Database["public"]["Enums"]["promo_destinatari_customer_mode"]
          id: string
          manual_excludes: string[]
          manual_includes: string[]
          rules: Json
          testata_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          customer_mode?: Database["public"]["Enums"]["promo_destinatari_customer_mode"]
          id?: string
          manual_excludes?: string[]
          manual_includes?: string[]
          rules?: Json
          testata_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          customer_mode?: Database["public"]["Enums"]["promo_destinatari_customer_mode"]
          id?: string
          manual_excludes?: string[]
          manual_includes?: string[]
          rules?: Json
          testata_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "promo_strutturate_destinatari_clienti_testata_id_fkey"
            columns: ["testata_id"]
            isOneToOne: true
            referencedRelation: "promo_strutturate_testate"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "promo_strutturate_destinatari_clienti_testata_id_fkey"
            columns: ["testata_id"]
            isOneToOne: true
            referencedRelation: "v_promo_strutturate_testate_stato"
            referencedColumns: ["id"]
          },
        ]
      }
      promo_strutturate_elementi: {
        Row: {
          created_at: string
          id: string
          updated_at: string
          wclapre: string | null
          wnpune: number | null
          wpandor: string | null
          wpcadte: string | null
          wpcaine: string | null
          wpccae: string | null
          wpdape: number | null
          wpdesce: string | null
          wpdmae: number | null
          wpnmcone: number | null
          wporve: number | null
          wppreoe: string | null
          wpprge: number | null
          wpprgte: number | null
          wprarte: string | null
          wprasse: string | null
          wprcl1e: string | null
          wprcl2e: string | null
          wprcl3e: string | null
          wprcl4e: string | null
          wprcl5e: string | null
          wprclie: string | null
          wprclme: string | null
          wprclve: string | null
          wprctse: string | null
          wprfore: string | null
          wpriatce: number | null
          wpritace: string | null
          wprline: string | null
          wprogre: number | null
          wprstge: string | null
          wpseqe: number | null
          wpstate: string | null
          wputae: string | null
          wputme: string | null
          wqpreoe: number | null
          wumorde: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          updated_at?: string
          wclapre?: string | null
          wnpune?: number | null
          wpandor?: string | null
          wpcadte?: string | null
          wpcaine?: string | null
          wpccae?: string | null
          wpdape?: number | null
          wpdesce?: string | null
          wpdmae?: number | null
          wpnmcone?: number | null
          wporve?: number | null
          wppreoe?: string | null
          wpprge?: number | null
          wpprgte?: number | null
          wprarte?: string | null
          wprasse?: string | null
          wprcl1e?: string | null
          wprcl2e?: string | null
          wprcl3e?: string | null
          wprcl4e?: string | null
          wprcl5e?: string | null
          wprclie?: string | null
          wprclme?: string | null
          wprclve?: string | null
          wprctse?: string | null
          wprfore?: string | null
          wpriatce?: number | null
          wpritace?: string | null
          wprline?: string | null
          wprogre?: number | null
          wprstge?: string | null
          wpseqe?: number | null
          wpstate?: string | null
          wputae?: string | null
          wputme?: string | null
          wqpreoe?: number | null
          wumorde?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          updated_at?: string
          wclapre?: string | null
          wnpune?: number | null
          wpandor?: string | null
          wpcadte?: string | null
          wpcaine?: string | null
          wpccae?: string | null
          wpdape?: number | null
          wpdesce?: string | null
          wpdmae?: number | null
          wpnmcone?: number | null
          wporve?: number | null
          wppreoe?: string | null
          wpprge?: number | null
          wpprgte?: number | null
          wprarte?: string | null
          wprasse?: string | null
          wprcl1e?: string | null
          wprcl2e?: string | null
          wprcl3e?: string | null
          wprcl4e?: string | null
          wprcl5e?: string | null
          wprclie?: string | null
          wprclme?: string | null
          wprclve?: string | null
          wprctse?: string | null
          wprfore?: string | null
          wpriatce?: number | null
          wpritace?: string | null
          wprline?: string | null
          wprogre?: number | null
          wprstge?: string | null
          wpseqe?: number | null
          wpstate?: string | null
          wputae?: string | null
          wputme?: string | null
          wqpreoe?: number | null
          wumorde?: string | null
        }
        Relationships: []
      }
      promo_strutturate_elementi_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      promo_strutturate_sblocchi: {
        Row: {
          cdcli: string
          created_at: string
          data_sblocco: string
          id: string
          importo_sblocco: number | null
          modalita: string | null
          note: string | null
          ordine_ref: string | null
          user_email: string | null
          user_id: string | null
          var_cli: string | null
          wpprgf: number
        }
        Insert: {
          cdcli: string
          created_at?: string
          data_sblocco?: string
          id?: string
          importo_sblocco?: number | null
          modalita?: string | null
          note?: string | null
          ordine_ref?: string | null
          user_email?: string | null
          user_id?: string | null
          var_cli?: string | null
          wpprgf: number
        }
        Update: {
          cdcli?: string
          created_at?: string
          data_sblocco?: string
          id?: string
          importo_sblocco?: number | null
          modalita?: string | null
          note?: string | null
          ordine_ref?: string | null
          user_email?: string | null
          user_id?: string | null
          var_cli?: string | null
          wpprgf?: number
        }
        Relationships: []
      }
      promo_strutturate_tema_articoli: {
        Row: {
          cdpar: string
          created_at: string
          pezzi_min_confezione: number | null
          sort_order: number
          tema_id: string
        }
        Insert: {
          cdpar: string
          created_at?: string
          pezzi_min_confezione?: number | null
          sort_order?: number
          tema_id: string
        }
        Update: {
          cdpar?: string
          created_at?: string
          pezzi_min_confezione?: number | null
          sort_order?: number
          tema_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "promo_strutturate_tema_articoli_tema_id_fkey"
            columns: ["tema_id"]
            isOneToOne: false
            referencedRelation: "promo_strutturate_temi"
            referencedColumns: ["id"]
          },
        ]
      }
      promo_strutturate_tema_catalogo_esclusioni: {
        Row: {
          cdpar: string
          created_at: string
          id: string
          tema_id: string
          updated_at: string
        }
        Insert: {
          cdpar: string
          created_at?: string
          id?: string
          tema_id: string
          updated_at?: string
        }
        Update: {
          cdpar?: string
          created_at?: string
          id?: string
          tema_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      promo_strutturate_tema_omaggio_articoli: {
        Row: {
          cdpar: string
          created_at: string
          id: string
          qty: number
          scaglione_id: string | null
          sort_order: number
          tema_id: string
        }
        Insert: {
          cdpar: string
          created_at?: string
          id?: string
          qty?: number
          scaglione_id?: string | null
          sort_order?: number
          tema_id: string
        }
        Update: {
          cdpar?: string
          created_at?: string
          id?: string
          qty?: number
          scaglione_id?: string | null
          sort_order?: number
          tema_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "promo_strutturate_tema_omaggio_articoli_scaglione_id_fkey"
            columns: ["scaglione_id"]
            isOneToOne: false
            referencedRelation: "promo_strutturate_tema_scaglioni"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "promo_strutturate_tema_omaggio_articoli_tema_id_fkey"
            columns: ["tema_id"]
            isOneToOne: false
            referencedRelation: "promo_strutturate_temi"
            referencedColumns: ["id"]
          },
        ]
      }
      promo_strutturate_tema_scaglioni: {
        Row: {
          created_at: string
          id: string
          omaggio_modalita: string
          sconto_pct: number
          soglia_eur: number | null
          soglia_qty: number | null
          soglia_righe: number | null
          sort_order: number
          tema_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          omaggio_modalita?: string
          sconto_pct: number
          soglia_eur?: number | null
          soglia_qty?: number | null
          soglia_righe?: number | null
          sort_order?: number
          tema_id: string
        }
        Update: {
          created_at?: string
          id?: string
          omaggio_modalita?: string
          sconto_pct?: number
          soglia_eur?: number | null
          soglia_qty?: number | null
          soglia_righe?: number | null
          sort_order?: number
          tema_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "promo_strutturate_tema_scaglioni_tema_id_fkey"
            columns: ["tema_id"]
            isOneToOne: false
            referencedRelation: "promo_strutturate_temi"
            referencedColumns: ["id"]
          },
        ]
      }
      promo_strutturate_temi: {
        Row: {
          al: string | null
          bundle_confezioni: number | null
          catalogo_sconto_pct: number | null
          catalogo_stacking: string | null
          created_at: string
          dal: string | null
          descrizione: string | null
          id: string
          image_url: string | null
          nome: string
          note: string | null
          omaggio_collegato_a: string | null
          omaggio_modalita:
            | Database["public"]["Enums"]["tema_omaggio_modalita"]
            | null
          omaggio_soglia_tipo:
            | Database["public"]["Enums"]["tema_omaggio_soglia"]
            | null
          omaggio_soglia_valore: number | null
          pe_qty_omaggio: number | null
          pe_qty_paganti: number | null
          pezzi_min_referenza: number | null
          qty_min: number | null
          referenze_min: number | null
          requires_tema_id: string | null
          righe_valore_min: number | null
          scaglioni_qty_unit: string
          sconto_pct: number | null
          sort_order: number
          tipo: Database["public"]["Enums"]["tema_offerta_tipo"]
          updated_at: string
          wpprgf: number
        }
        Insert: {
          al?: string | null
          bundle_confezioni?: number | null
          catalogo_sconto_pct?: number | null
          catalogo_stacking?: string | null
          created_at?: string
          dal?: string | null
          descrizione?: string | null
          id?: string
          image_url?: string | null
          nome: string
          note?: string | null
          omaggio_collegato_a?: string | null
          omaggio_modalita?:
            | Database["public"]["Enums"]["tema_omaggio_modalita"]
            | null
          omaggio_soglia_tipo?:
            | Database["public"]["Enums"]["tema_omaggio_soglia"]
            | null
          omaggio_soglia_valore?: number | null
          pe_qty_omaggio?: number | null
          pe_qty_paganti?: number | null
          pezzi_min_referenza?: number | null
          qty_min?: number | null
          referenze_min?: number | null
          requires_tema_id?: string | null
          righe_valore_min?: number | null
          scaglioni_qty_unit?: string
          sconto_pct?: number | null
          sort_order?: number
          tipo?: Database["public"]["Enums"]["tema_offerta_tipo"]
          updated_at?: string
          wpprgf: number
        }
        Update: {
          al?: string | null
          bundle_confezioni?: number | null
          catalogo_sconto_pct?: number | null
          catalogo_stacking?: string | null
          created_at?: string
          dal?: string | null
          descrizione?: string | null
          id?: string
          image_url?: string | null
          nome?: string
          note?: string | null
          omaggio_collegato_a?: string | null
          omaggio_modalita?:
            | Database["public"]["Enums"]["tema_omaggio_modalita"]
            | null
          omaggio_soglia_tipo?:
            | Database["public"]["Enums"]["tema_omaggio_soglia"]
            | null
          omaggio_soglia_valore?: number | null
          pe_qty_omaggio?: number | null
          pe_qty_paganti?: number | null
          pezzi_min_referenza?: number | null
          qty_min?: number | null
          referenze_min?: number | null
          requires_tema_id?: string | null
          righe_valore_min?: number | null
          scaglioni_qty_unit?: string
          sconto_pct?: number | null
          sort_order?: number
          tipo?: Database["public"]["Enums"]["tema_offerta_tipo"]
          updated_at?: string
          wpprgf?: number
        }
        Relationships: [
          {
            foreignKeyName: "promo_strutturate_temi_omaggio_collegato_a_fkey"
            columns: ["omaggio_collegato_a"]
            isOneToOne: false
            referencedRelation: "promo_strutturate_temi"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "promo_strutturate_temi_requires_tema_id_fkey"
            columns: ["requires_tema_id"]
            isOneToOne: false
            referencedRelation: "promo_strutturate_temi"
            referencedColumns: ["id"]
          },
        ]
      }
      promo_strutturate_testate: {
        Row: {
          b2b_banner_visibility: string
          b2b_sort_order: number
          cover_image_url: string | null
          created_at: string
          excluded_listini: string[]
          id: string
          offerta_sconto_fattura: boolean
          show_expiry_b2b: boolean
          show_on_customer_view: boolean
          unlock_enabled: boolean
          unlock_mode: string | null
          unlock_threshold: number | null
          updated_at: string
          visible_b2b: boolean
          wdtap: number | null
          wdtdp: number | null
          wdtip: number | null
          worap: number | null
          wordp: number | null
          wpcadt: string | null
          wpcain: string | null
          wpcca: string | null
          wpdap: number | null
          wpdma: number | null
          wpdtdof: number | null
          wpdtdoi: number | null
          wpdtls: string | null
          wpdvalf: number | null
          wpdvali: number | null
          wpindif: number | null
          wpindii: number | null
          wpindof: number | null
          wpindoi: number | null
          wpinls: string | null
          wpliadd: string | null
          wpliadi: string | null
          wporv: number | null
          wpprgf: number | null
          wpriatc: number | null
          wpritac: string | null
          wprogr: number | null
          wpstato: string | null
          wptpbc: string | null
          wptpbd: string | null
          wptpbs: string | null
          wptpca: string | null
          wputa: string | null
          wputm: string | null
        }
        Insert: {
          b2b_banner_visibility?: string
          b2b_sort_order?: number
          cover_image_url?: string | null
          created_at?: string
          excluded_listini?: string[]
          id?: string
          offerta_sconto_fattura?: boolean
          show_expiry_b2b?: boolean
          show_on_customer_view?: boolean
          unlock_enabled?: boolean
          unlock_mode?: string | null
          unlock_threshold?: number | null
          updated_at?: string
          visible_b2b?: boolean
          wdtap?: number | null
          wdtdp?: number | null
          wdtip?: number | null
          worap?: number | null
          wordp?: number | null
          wpcadt?: string | null
          wpcain?: string | null
          wpcca?: string | null
          wpdap?: number | null
          wpdma?: number | null
          wpdtdof?: number | null
          wpdtdoi?: number | null
          wpdtls?: string | null
          wpdvalf?: number | null
          wpdvali?: number | null
          wpindif?: number | null
          wpindii?: number | null
          wpindof?: number | null
          wpindoi?: number | null
          wpinls?: string | null
          wpliadd?: string | null
          wpliadi?: string | null
          wporv?: number | null
          wpprgf?: number | null
          wpriatc?: number | null
          wpritac?: string | null
          wprogr?: number | null
          wpstato?: string | null
          wptpbc?: string | null
          wptpbd?: string | null
          wptpbs?: string | null
          wptpca?: string | null
          wputa?: string | null
          wputm?: string | null
        }
        Update: {
          b2b_banner_visibility?: string
          b2b_sort_order?: number
          cover_image_url?: string | null
          created_at?: string
          excluded_listini?: string[]
          id?: string
          offerta_sconto_fattura?: boolean
          show_expiry_b2b?: boolean
          show_on_customer_view?: boolean
          unlock_enabled?: boolean
          unlock_mode?: string | null
          unlock_threshold?: number | null
          updated_at?: string
          visible_b2b?: boolean
          wdtap?: number | null
          wdtdp?: number | null
          wdtip?: number | null
          worap?: number | null
          wordp?: number | null
          wpcadt?: string | null
          wpcain?: string | null
          wpcca?: string | null
          wpdap?: number | null
          wpdma?: number | null
          wpdtdof?: number | null
          wpdtdoi?: number | null
          wpdtls?: string | null
          wpdvalf?: number | null
          wpdvali?: number | null
          wpindif?: number | null
          wpindii?: number | null
          wpindof?: number | null
          wpindoi?: number | null
          wpinls?: string | null
          wpliadd?: string | null
          wpliadi?: string | null
          wporv?: number | null
          wpprgf?: number | null
          wpriatc?: number | null
          wpritac?: string | null
          wprogr?: number | null
          wpstato?: string | null
          wptpbc?: string | null
          wptpbd?: string | null
          wptpbs?: string | null
          wptpca?: string | null
          wputa?: string | null
          wputm?: string | null
        }
        Relationships: []
      }
      promo_strutturate_testate_field_flags: {
        Row: {
          clarify_flag: boolean
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean
          read_flag: boolean
          updated_at: string
          write_flag: boolean
        }
        Insert: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Update: {
          clarify_flag?: boolean
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean
          read_flag?: boolean
          updated_at?: string
          write_flag?: boolean
        }
        Relationships: []
      }
      report_columns: {
        Row: {
          align: string
          col_key: string
          created_at: string
          group_label: string | null
          id: string
          label: string
          report_id: string
          sort_order: number
          suffix: string | null
          updated_at: string
          visible: boolean
        }
        Insert: {
          align?: string
          col_key: string
          created_at?: string
          group_label?: string | null
          id?: string
          label: string
          report_id: string
          sort_order?: number
          suffix?: string | null
          updated_at?: string
          visible?: boolean
        }
        Update: {
          align?: string
          col_key?: string
          created_at?: string
          group_label?: string | null
          id?: string
          label?: string
          report_id?: string
          sort_order?: number
          suffix?: string | null
          updated_at?: string
          visible?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "report_columns_report_id_fkey"
            columns: ["report_id"]
            isOneToOne: false
            referencedRelation: "reports"
            referencedColumns: ["id"]
          },
        ]
      }
      report_rows: {
        Row: {
          created_at: string
          id: string
          recipient_code: string
          recipient_name: string | null
          report_id: string
          sort_order: number
          updated_at: string
          values: Json
        }
        Insert: {
          created_at?: string
          id?: string
          recipient_code: string
          recipient_name?: string | null
          report_id: string
          sort_order?: number
          updated_at?: string
          values?: Json
        }
        Update: {
          created_at?: string
          id?: string
          recipient_code?: string
          recipient_name?: string | null
          report_id?: string
          sort_order?: number
          updated_at?: string
          values?: Json
        }
        Relationships: [
          {
            foreignKeyName: "report_rows_report_id_fkey"
            columns: ["report_id"]
            isOneToOne: false
            referencedRelation: "reports"
            referencedColumns: ["id"]
          },
        ]
      }
      reports: {
        Row: {
          audience: string
          created_at: string
          created_by: string | null
          date_end: string | null
          date_start: string | null
          description: string | null
          hidden: boolean
          hide_recipient_name: boolean
          id: string
          ref_id: number
          show_only_if_present: boolean
          show_only_own: boolean
          sort_order: number
          title: string
          updated_at: string
        }
        Insert: {
          audience?: string
          created_at?: string
          created_by?: string | null
          date_end?: string | null
          date_start?: string | null
          description?: string | null
          hidden?: boolean
          hide_recipient_name?: boolean
          id?: string
          ref_id?: number
          show_only_if_present?: boolean
          show_only_own?: boolean
          sort_order?: number
          title: string
          updated_at?: string
        }
        Update: {
          audience?: string
          created_at?: string
          created_by?: string | null
          date_end?: string | null
          date_start?: string | null
          description?: string | null
          hidden?: boolean
          hide_recipient_name?: boolean
          id?: string
          ref_id?: number
          show_only_if_present?: boolean
          show_only_own?: boolean
          sort_order?: number
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      reports_giornalieri: {
        Row: {
          agente_id: string
          created_at: string
          data: string
          id: string
          tipo_giorno: Database["public"]["Enums"]["tipo_giorno"]
          trasmesso: boolean
          updated_at: string
        }
        Insert: {
          agente_id: string
          created_at?: string
          data: string
          id?: string
          tipo_giorno?: Database["public"]["Enums"]["tipo_giorno"]
          trasmesso?: boolean
          updated_at?: string
        }
        Update: {
          agente_id?: string
          created_at?: string
          data?: string
          id?: string
          tipo_giorno?: Database["public"]["Enums"]["tipo_giorno"]
          trasmesso?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      resi: {
        Row: {
          approvato: string | null
          blocked: boolean
          blocked_details: Json | null
          blocked_reason: string | null
          cat: string | null
          cat_applicazione: string | null
          cat_con_applicazione: string | null
          causale_reso_codice: string | null
          causale_reso_descrizione: string | null
          cliente_numero_ddt: string | null
          codice_agente: string | null
          codice_articolo: string
          codice_cliente: string | null
          cognome_agente: string | null
          created_at: string
          created_by: string | null
          current_step_key: string | null
          data_ddt_cliente: string | null
          data_export: string | null
          data_fattura: string | null
          data_nc_accredito: string | null
          data_rientro: string | null
          data_trasmissione: string | null
          ddt_completo_rma: string | null
          descrizione: string | null
          destinazione_finale: string | null
          difetto: string | null
          eliminato: boolean
          eliminato_at: string | null
          eliminato_da: string | null
          email_agente: string | null
          email_approvazione_inviata_at: string | null
          email_cliente_inviata_at: string | null
          email_fornitore_inviata_at: string | null
          email_servizio_clienti: string | null
          esito: string | null
          esito_cat: string | null
          extra: Json
          garanzia: string | null
          id: string
          id_reso: string
          id_trasmissione: string | null
          import_version: number
          importo_manodopera: number | null
          importo_pezzi_ricambio: number | null
          importo_spese_preventivo: number | null
          mail_a_fornitore: string | null
          manda_mail_a_fornitore: string | null
          motivazione_rifiuto: string | null
          motivo_negazione: string | null
          nome_agente: string | null
          nominativo_cliente: string | null
          nota: string | null
          note_preventivo: string | null
          numero_di_registrazione: number | null
          numero_fattura: string | null
          numero_nc_accredito: number | null
          numero_nc_accredito_manodopera: number | null
          ora_export: string | null
          paused_at: string | null
          pdf_ddt_rma: string | null
          pdf_negazione: string | null
          pdf_rispedizione: string | null
          pdf_smaltimento: string | null
          previous_step_key: string | null
          prezzo: number | null
          priority: number
          quantita: number | null
          ricaricato: boolean | null
          ricaricato_at: string | null
          riconoscimento_garanzia: string | null
          riparabile: boolean | null
          rispedire_o_smaltire: string | null
          risposta_al_preventivo: string | null
          risposta_preventivo: string | null
          rma: number | null
          row_hash: string | null
          source_file: string | null
          specifiche_ricambi: string | null
          spese_accessorie: number | null
          status: Database["public"]["Enums"]["resi_status"]
          status_history: Json
          strada: string | null
          totale_preventivo: number | null
          unita_misura: string | null
          updated_at: string
          updated_by: string | null
          vuoi_inviare_mail_per_rifiuto: string | null
        }
        Insert: {
          approvato?: string | null
          blocked?: boolean
          blocked_details?: Json | null
          blocked_reason?: string | null
          cat?: string | null
          cat_applicazione?: string | null
          cat_con_applicazione?: string | null
          causale_reso_codice?: string | null
          causale_reso_descrizione?: string | null
          cliente_numero_ddt?: string | null
          codice_agente?: string | null
          codice_articolo: string
          codice_cliente?: string | null
          cognome_agente?: string | null
          created_at?: string
          created_by?: string | null
          current_step_key?: string | null
          data_ddt_cliente?: string | null
          data_export?: string | null
          data_fattura?: string | null
          data_nc_accredito?: string | null
          data_rientro?: string | null
          data_trasmissione?: string | null
          ddt_completo_rma?: string | null
          descrizione?: string | null
          destinazione_finale?: string | null
          difetto?: string | null
          eliminato?: boolean
          eliminato_at?: string | null
          eliminato_da?: string | null
          email_agente?: string | null
          email_approvazione_inviata_at?: string | null
          email_cliente_inviata_at?: string | null
          email_fornitore_inviata_at?: string | null
          email_servizio_clienti?: string | null
          esito?: string | null
          esito_cat?: string | null
          extra?: Json
          garanzia?: string | null
          id?: string
          id_reso: string
          id_trasmissione?: string | null
          import_version?: number
          importo_manodopera?: number | null
          importo_pezzi_ricambio?: number | null
          importo_spese_preventivo?: number | null
          mail_a_fornitore?: string | null
          manda_mail_a_fornitore?: string | null
          motivazione_rifiuto?: string | null
          motivo_negazione?: string | null
          nome_agente?: string | null
          nominativo_cliente?: string | null
          nota?: string | null
          note_preventivo?: string | null
          numero_di_registrazione?: number | null
          numero_fattura?: string | null
          numero_nc_accredito?: number | null
          numero_nc_accredito_manodopera?: number | null
          ora_export?: string | null
          paused_at?: string | null
          pdf_ddt_rma?: string | null
          pdf_negazione?: string | null
          pdf_rispedizione?: string | null
          pdf_smaltimento?: string | null
          previous_step_key?: string | null
          prezzo?: number | null
          priority?: number
          quantita?: number | null
          ricaricato?: boolean | null
          ricaricato_at?: string | null
          riconoscimento_garanzia?: string | null
          riparabile?: boolean | null
          rispedire_o_smaltire?: string | null
          risposta_al_preventivo?: string | null
          risposta_preventivo?: string | null
          rma?: number | null
          row_hash?: string | null
          source_file?: string | null
          specifiche_ricambi?: string | null
          spese_accessorie?: number | null
          status?: Database["public"]["Enums"]["resi_status"]
          status_history?: Json
          strada?: string | null
          totale_preventivo?: number | null
          unita_misura?: string | null
          updated_at?: string
          updated_by?: string | null
          vuoi_inviare_mail_per_rifiuto?: string | null
        }
        Update: {
          approvato?: string | null
          blocked?: boolean
          blocked_details?: Json | null
          blocked_reason?: string | null
          cat?: string | null
          cat_applicazione?: string | null
          cat_con_applicazione?: string | null
          causale_reso_codice?: string | null
          causale_reso_descrizione?: string | null
          cliente_numero_ddt?: string | null
          codice_agente?: string | null
          codice_articolo?: string
          codice_cliente?: string | null
          cognome_agente?: string | null
          created_at?: string
          created_by?: string | null
          current_step_key?: string | null
          data_ddt_cliente?: string | null
          data_export?: string | null
          data_fattura?: string | null
          data_nc_accredito?: string | null
          data_rientro?: string | null
          data_trasmissione?: string | null
          ddt_completo_rma?: string | null
          descrizione?: string | null
          destinazione_finale?: string | null
          difetto?: string | null
          eliminato?: boolean
          eliminato_at?: string | null
          eliminato_da?: string | null
          email_agente?: string | null
          email_approvazione_inviata_at?: string | null
          email_cliente_inviata_at?: string | null
          email_fornitore_inviata_at?: string | null
          email_servizio_clienti?: string | null
          esito?: string | null
          esito_cat?: string | null
          extra?: Json
          garanzia?: string | null
          id?: string
          id_reso?: string
          id_trasmissione?: string | null
          import_version?: number
          importo_manodopera?: number | null
          importo_pezzi_ricambio?: number | null
          importo_spese_preventivo?: number | null
          mail_a_fornitore?: string | null
          manda_mail_a_fornitore?: string | null
          motivazione_rifiuto?: string | null
          motivo_negazione?: string | null
          nome_agente?: string | null
          nominativo_cliente?: string | null
          nota?: string | null
          note_preventivo?: string | null
          numero_di_registrazione?: number | null
          numero_fattura?: string | null
          numero_nc_accredito?: number | null
          numero_nc_accredito_manodopera?: number | null
          ora_export?: string | null
          paused_at?: string | null
          pdf_ddt_rma?: string | null
          pdf_negazione?: string | null
          pdf_rispedizione?: string | null
          pdf_smaltimento?: string | null
          previous_step_key?: string | null
          prezzo?: number | null
          priority?: number
          quantita?: number | null
          ricaricato?: boolean | null
          ricaricato_at?: string | null
          riconoscimento_garanzia?: string | null
          riparabile?: boolean | null
          rispedire_o_smaltire?: string | null
          risposta_al_preventivo?: string | null
          risposta_preventivo?: string | null
          rma?: number | null
          row_hash?: string | null
          source_file?: string | null
          specifiche_ricambi?: string | null
          spese_accessorie?: number | null
          status?: Database["public"]["Enums"]["resi_status"]
          status_history?: Json
          strada?: string | null
          totale_preventivo?: number | null
          unita_misura?: string | null
          updated_at?: string
          updated_by?: string | null
          vuoi_inviare_mail_per_rifiuto?: string | null
        }
        Relationships: []
      }
      resi_ufficio_acquisti: {
        Row: {
          blocked: boolean
          blocked_details: Json | null
          blocked_reason: string | null
          causale_reso_codice: string | null
          causale_reso_descrizione: string | null
          codice_articolo: string
          codice_cliente: string | null
          codice_fornitore: string | null
          created_at: string
          created_by: string | null
          current_step_key: string | null
          data_export: string | null
          data_fattura: string | null
          data_nc_accredito: string | null
          data_rientro: string | null
          data_trasmissione: string | null
          ddt_completo: string | null
          ddt_id: string | null
          decisione_finale: string | null
          descrizione: string | null
          difetto: string | null
          eliminato: boolean
          eliminato_at: string | null
          eliminato_da: string | null
          email_fornitore: string | null
          email_fornitore_inviata_at: string | null
          esito: string | null
          esito_cat: string | null
          extra: Json
          garanzia: string | null
          id: string
          id_reso: string
          id_trasmissione: string | null
          import_version: number
          importo_manodopera: number | null
          importo_pezzi_ricambio: number | null
          importo_spese_preventivo: number | null
          motivazione_rifiuto: string | null
          motivo_negazione: string | null
          nominativo_cliente: string | null
          nota: string | null
          note_preventivo: string | null
          numero_fattura: string | null
          numero_nc_accredito: number | null
          ora_export: string | null
          paused_at: string | null
          previous_step_key: string | null
          prezzo: number | null
          priority: number
          quantita: number | null
          ragione_sociale_fornitore: string | null
          riconoscimento_garanzia: string | null
          risposto: boolean | null
          risposto_al_sollecito: boolean | null
          rma: number | null
          row_hash: string | null
          sollecito_inviato_at: string | null
          source_file: string | null
          spese_accessorie: number | null
          status: Database["public"]["Enums"]["resi_acquisti_status"]
          status_history: Json
          totale_preventivo: number | null
          unita_misura: string | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          blocked?: boolean
          blocked_details?: Json | null
          blocked_reason?: string | null
          causale_reso_codice?: string | null
          causale_reso_descrizione?: string | null
          codice_articolo: string
          codice_cliente?: string | null
          codice_fornitore?: string | null
          created_at?: string
          created_by?: string | null
          current_step_key?: string | null
          data_export?: string | null
          data_fattura?: string | null
          data_nc_accredito?: string | null
          data_rientro?: string | null
          data_trasmissione?: string | null
          ddt_completo?: string | null
          ddt_id?: string | null
          decisione_finale?: string | null
          descrizione?: string | null
          difetto?: string | null
          eliminato?: boolean
          eliminato_at?: string | null
          eliminato_da?: string | null
          email_fornitore?: string | null
          email_fornitore_inviata_at?: string | null
          esito?: string | null
          esito_cat?: string | null
          extra?: Json
          garanzia?: string | null
          id?: string
          id_reso: string
          id_trasmissione?: string | null
          import_version?: number
          importo_manodopera?: number | null
          importo_pezzi_ricambio?: number | null
          importo_spese_preventivo?: number | null
          motivazione_rifiuto?: string | null
          motivo_negazione?: string | null
          nominativo_cliente?: string | null
          nota?: string | null
          note_preventivo?: string | null
          numero_fattura?: string | null
          numero_nc_accredito?: number | null
          ora_export?: string | null
          paused_at?: string | null
          previous_step_key?: string | null
          prezzo?: number | null
          priority?: number
          quantita?: number | null
          ragione_sociale_fornitore?: string | null
          riconoscimento_garanzia?: string | null
          risposto?: boolean | null
          risposto_al_sollecito?: boolean | null
          rma?: number | null
          row_hash?: string | null
          sollecito_inviato_at?: string | null
          source_file?: string | null
          spese_accessorie?: number | null
          status?: Database["public"]["Enums"]["resi_acquisti_status"]
          status_history?: Json
          totale_preventivo?: number | null
          unita_misura?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          blocked?: boolean
          blocked_details?: Json | null
          blocked_reason?: string | null
          causale_reso_codice?: string | null
          causale_reso_descrizione?: string | null
          codice_articolo?: string
          codice_cliente?: string | null
          codice_fornitore?: string | null
          created_at?: string
          created_by?: string | null
          current_step_key?: string | null
          data_export?: string | null
          data_fattura?: string | null
          data_nc_accredito?: string | null
          data_rientro?: string | null
          data_trasmissione?: string | null
          ddt_completo?: string | null
          ddt_id?: string | null
          decisione_finale?: string | null
          descrizione?: string | null
          difetto?: string | null
          eliminato?: boolean
          eliminato_at?: string | null
          eliminato_da?: string | null
          email_fornitore?: string | null
          email_fornitore_inviata_at?: string | null
          esito?: string | null
          esito_cat?: string | null
          extra?: Json
          garanzia?: string | null
          id?: string
          id_reso?: string
          id_trasmissione?: string | null
          import_version?: number
          importo_manodopera?: number | null
          importo_pezzi_ricambio?: number | null
          importo_spese_preventivo?: number | null
          motivazione_rifiuto?: string | null
          motivo_negazione?: string | null
          nominativo_cliente?: string | null
          nota?: string | null
          note_preventivo?: string | null
          numero_fattura?: string | null
          numero_nc_accredito?: number | null
          ora_export?: string | null
          paused_at?: string | null
          previous_step_key?: string | null
          prezzo?: number | null
          priority?: number
          quantita?: number | null
          ragione_sociale_fornitore?: string | null
          riconoscimento_garanzia?: string | null
          risposto?: boolean | null
          risposto_al_sollecito?: boolean | null
          rma?: number | null
          row_hash?: string | null
          sollecito_inviato_at?: string | null
          source_file?: string | null
          spese_accessorie?: number | null
          status?: Database["public"]["Enums"]["resi_acquisti_status"]
          status_history?: Json
          totale_preventivo?: number | null
          unita_misura?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "resi_acq_ddt_fk"
            columns: ["ddt_id"]
            isOneToOne: false
            referencedRelation: "ddt"
            referencedColumns: ["id"]
          },
        ]
      }
      richieste_ordini_non_trattati: {
        Row: {
          agente_codice: string | null
          agente_cognome: string | null
          agente_nome: string | null
          arrivato_at: string | null
          arrivato_by: string | null
          cdpar_codificato: string | null
          chiuso_at: string | null
          chiuso_by: string | null
          chiuso_da: string | null
          chiusura_motivo: string | null
          cliente_codice: string
          cliente_nominativo: string
          codice_articolo_fornitore: string
          codificato_at: string | null
          codificato_by: string | null
          confermato: boolean | null
          confermato_at: string | null
          created_at: string
          created_by: string
          decision_email_sent_at: string | null
          descrizione: string
          edited_at: string | null
          edited_by: string | null
          fornitore: string
          id: string
          in_arrivo_at: string | null
          in_arrivo_by: string | null
          nota: string | null
          notified_at: string | null
          ordine_cliente_at: string | null
          ordine_cliente_by: string | null
          ordine_cliente_ref: string | null
          ordine_fornitore_at: string | null
          ordine_fornitore_by: string | null
          ordine_fornitore_ref: string | null
          preventivo_note: string | null
          preventivo_note_at: string | null
          preventivo_note_by: string | null
          quantita: number
          stato: Database["public"]["Enums"]["untreated_order_status"]
          status:
            | Database["public"]["Enums"]["ordine_non_trattato_status"]
            | null
          status_updated_at: string | null
          status_updated_by: string | null
        }
        Insert: {
          agente_codice?: string | null
          agente_cognome?: string | null
          agente_nome?: string | null
          arrivato_at?: string | null
          arrivato_by?: string | null
          cdpar_codificato?: string | null
          chiuso_at?: string | null
          chiuso_by?: string | null
          chiuso_da?: string | null
          chiusura_motivo?: string | null
          cliente_codice: string
          cliente_nominativo: string
          codice_articolo_fornitore: string
          codificato_at?: string | null
          codificato_by?: string | null
          confermato?: boolean | null
          confermato_at?: string | null
          created_at?: string
          created_by: string
          decision_email_sent_at?: string | null
          descrizione: string
          edited_at?: string | null
          edited_by?: string | null
          fornitore: string
          id?: string
          in_arrivo_at?: string | null
          in_arrivo_by?: string | null
          nota?: string | null
          notified_at?: string | null
          ordine_cliente_at?: string | null
          ordine_cliente_by?: string | null
          ordine_cliente_ref?: string | null
          ordine_fornitore_at?: string | null
          ordine_fornitore_by?: string | null
          ordine_fornitore_ref?: string | null
          preventivo_note?: string | null
          preventivo_note_at?: string | null
          preventivo_note_by?: string | null
          quantita: number
          stato?: Database["public"]["Enums"]["untreated_order_status"]
          status?:
            | Database["public"]["Enums"]["ordine_non_trattato_status"]
            | null
          status_updated_at?: string | null
          status_updated_by?: string | null
        }
        Update: {
          agente_codice?: string | null
          agente_cognome?: string | null
          agente_nome?: string | null
          arrivato_at?: string | null
          arrivato_by?: string | null
          cdpar_codificato?: string | null
          chiuso_at?: string | null
          chiuso_by?: string | null
          chiuso_da?: string | null
          chiusura_motivo?: string | null
          cliente_codice?: string
          cliente_nominativo?: string
          codice_articolo_fornitore?: string
          codificato_at?: string | null
          codificato_by?: string | null
          confermato?: boolean | null
          confermato_at?: string | null
          created_at?: string
          created_by?: string
          decision_email_sent_at?: string | null
          descrizione?: string
          edited_at?: string | null
          edited_by?: string | null
          fornitore?: string
          id?: string
          in_arrivo_at?: string | null
          in_arrivo_by?: string | null
          nota?: string | null
          notified_at?: string | null
          ordine_cliente_at?: string | null
          ordine_cliente_by?: string | null
          ordine_cliente_ref?: string | null
          ordine_fornitore_at?: string | null
          ordine_fornitore_by?: string | null
          ordine_fornitore_ref?: string | null
          preventivo_note?: string | null
          preventivo_note_at?: string | null
          preventivo_note_by?: string | null
          quantita?: number
          stato?: Database["public"]["Enums"]["untreated_order_status"]
          status?:
            | Database["public"]["Enums"]["ordine_non_trattato_status"]
            | null
          status_updated_at?: string | null
          status_updated_by?: string | null
        }
        Relationships: []
      }
      richieste_resi_legacy: {
        Row: {
          agente_codice: string
          agente_cognome: string
          agente_nome: string
          causale_codice: string
          causale_descrizione: string
          cliente_codice: string
          cliente_nominativo: string
          codice_articolo: string
          created_at: string
          created_by: string
          data_export: string | null
          data_fattura: string
          data_trasmissione: string | null
          descrizione_articolo: string
          id: string
          id_reso: string
          id_trasmissione: string | null
          nota: string | null
          numero_fattura: string
          ora_export: string | null
          quantita: number
          unita_misura: string
        }
        Insert: {
          agente_codice: string
          agente_cognome: string
          agente_nome: string
          causale_codice: string
          causale_descrizione: string
          cliente_codice: string
          cliente_nominativo: string
          codice_articolo: string
          created_at?: string
          created_by: string
          data_export?: string | null
          data_fattura: string
          data_trasmissione?: string | null
          descrizione_articolo: string
          id?: string
          id_reso?: string
          id_trasmissione?: string | null
          nota?: string | null
          numero_fattura: string
          ora_export?: string | null
          quantita: number
          unita_misura: string
        }
        Update: {
          agente_codice?: string
          agente_cognome?: string
          agente_nome?: string
          causale_codice?: string
          causale_descrizione?: string
          cliente_codice?: string
          cliente_nominativo?: string
          codice_articolo?: string
          created_at?: string
          created_by?: string
          data_export?: string | null
          data_fattura?: string
          data_trasmissione?: string | null
          descrizione_articolo?: string
          id?: string
          id_reso?: string
          id_trasmissione?: string | null
          nota?: string | null
          numero_fattura?: string
          ora_export?: string | null
          quantita?: number
          unita_misura?: string
        }
        Relationships: []
      }
      richieste_ricambi: {
        Row: {
          blocked: boolean
          blocked_details: Json | null
          blocked_reason: string | null
          codice_agente: string | null
          codice_articolo: string
          codice_cliente: string | null
          created_at: string
          created_by: string | null
          current_step_key: string | null
          data_richiesta: string
          descrizione_articolo: string | null
          eliminato: boolean
          eliminato_at: string | null
          eliminato_da: string | null
          esito_globale: string | null
          extra: Json
          id: string
          nome_agente: string | null
          note_generali: string | null
          numero_pezzi_richiesti: number | null
          paused_at: string | null
          pdf_url: string | null
          previous_step_key: string | null
          priority: number
          ragione_sociale: string | null
          status: Database["public"]["Enums"]["ricambi_status"]
          status_history: Json
          totale_preventivo: number | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          blocked?: boolean
          blocked_details?: Json | null
          blocked_reason?: string | null
          codice_agente?: string | null
          codice_articolo: string
          codice_cliente?: string | null
          created_at?: string
          created_by?: string | null
          current_step_key?: string | null
          data_richiesta?: string
          descrizione_articolo?: string | null
          eliminato?: boolean
          eliminato_at?: string | null
          eliminato_da?: string | null
          esito_globale?: string | null
          extra?: Json
          id?: string
          nome_agente?: string | null
          note_generali?: string | null
          numero_pezzi_richiesti?: number | null
          paused_at?: string | null
          pdf_url?: string | null
          previous_step_key?: string | null
          priority?: number
          ragione_sociale?: string | null
          status?: Database["public"]["Enums"]["ricambi_status"]
          status_history?: Json
          totale_preventivo?: number | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          blocked?: boolean
          blocked_details?: Json | null
          blocked_reason?: string | null
          codice_agente?: string | null
          codice_articolo?: string
          codice_cliente?: string | null
          created_at?: string
          created_by?: string | null
          current_step_key?: string | null
          data_richiesta?: string
          descrizione_articolo?: string | null
          eliminato?: boolean
          eliminato_at?: string | null
          eliminato_da?: string | null
          esito_globale?: string | null
          extra?: Json
          id?: string
          nome_agente?: string | null
          note_generali?: string | null
          numero_pezzi_richiesti?: number | null
          paused_at?: string | null
          pdf_url?: string | null
          previous_step_key?: string | null
          priority?: number
          ragione_sociale?: string | null
          status?: Database["public"]["Enums"]["ricambi_status"]
          status_history?: Json
          totale_preventivo?: number | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      richieste_ricambi_items: {
        Row: {
          codice_ricambio: string
          created_at: string
          da_preparare: boolean | null
          descrizione_ricambio: string | null
          disponibile: boolean | null
          esito: string | null
          garanzia: boolean | null
          id: string
          immagine_url: string | null
          note: string | null
          preparato: boolean | null
          prezzo_totale: number | null
          prezzo_unitario: number | null
          quantita: number | null
          richiesta_id: string
        }
        Insert: {
          codice_ricambio: string
          created_at?: string
          da_preparare?: boolean | null
          descrizione_ricambio?: string | null
          disponibile?: boolean | null
          esito?: string | null
          garanzia?: boolean | null
          id?: string
          immagine_url?: string | null
          note?: string | null
          preparato?: boolean | null
          prezzo_totale?: number | null
          prezzo_unitario?: number | null
          quantita?: number | null
          richiesta_id: string
        }
        Update: {
          codice_ricambio?: string
          created_at?: string
          da_preparare?: boolean | null
          descrizione_ricambio?: string | null
          disponibile?: boolean | null
          esito?: string | null
          garanzia?: boolean | null
          id?: string
          immagine_url?: string | null
          note?: string | null
          preparato?: boolean | null
          prezzo_totale?: number | null
          prezzo_unitario?: number | null
          quantita?: number | null
          richiesta_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "richieste_ricambi_items_richiesta_id_fkey"
            columns: ["richiesta_id"]
            isOneToOne: false
            referencedRelation: "richieste_ricambi"
            referencedColumns: ["id"]
          },
        ]
      }
      scadenziario_imports: {
        Row: {
          agent_code: string | null
          filename: string
          id: string
          imported_at: string
          imported_by: string | null
          notes: string | null
          total_amount: number
          total_rows: number
        }
        Insert: {
          agent_code?: string | null
          filename: string
          id?: string
          imported_at?: string
          imported_by?: string | null
          notes?: string | null
          total_amount?: number
          total_rows?: number
        }
        Update: {
          agent_code?: string | null
          filename?: string
          id?: string
          imported_at?: string
          imported_by?: string | null
          notes?: string | null
          total_amount?: number
          total_rows?: number
        }
        Relationships: []
      }
      scadenziario_payment_ack: {
        Row: {
          acked_at: string
          acked_by: string | null
          row_id: string
        }
        Insert: {
          acked_at?: string
          acked_by?: string | null
          row_id: string
        }
        Update: {
          acked_at?: string
          acked_by?: string | null
          row_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "scadenziario_payment_ack_row_id_fkey"
            columns: ["row_id"]
            isOneToOne: true
            referencedRelation: "scadenziario_rows"
            referencedColumns: ["id"]
          },
        ]
      }
      scadenziario_rows: {
        Row: {
          causal: string | null
          contanti: number | null
          created_at: string
          currency: string | null
          customer_code: string
          customer_name: string | null
          doc_date: string | null
          doc_number: string | null
          due_date: string | null
          effetti: number | null
          id: string
          last_import_id: string | null
          nat_key: string | null
          payment_confirmed: boolean
          payment_confirmed_amount: number | null
          payment_confirmed_at: string | null
          payment_confirmed_by_agent: string | null
          payment_desc: string | null
          payment_note: string | null
          reg_data: string | null
          reg_prot: string | null
          totale: number | null
        }
        Insert: {
          causal?: string | null
          contanti?: number | null
          created_at?: string
          currency?: string | null
          customer_code: string
          customer_name?: string | null
          doc_date?: string | null
          doc_number?: string | null
          due_date?: string | null
          effetti?: number | null
          id?: string
          last_import_id?: string | null
          nat_key?: string | null
          payment_confirmed?: boolean
          payment_confirmed_amount?: number | null
          payment_confirmed_at?: string | null
          payment_confirmed_by_agent?: string | null
          payment_desc?: string | null
          payment_note?: string | null
          reg_data?: string | null
          reg_prot?: string | null
          totale?: number | null
        }
        Update: {
          causal?: string | null
          contanti?: number | null
          created_at?: string
          currency?: string | null
          customer_code?: string
          customer_name?: string | null
          doc_date?: string | null
          doc_number?: string | null
          due_date?: string | null
          effetti?: number | null
          id?: string
          last_import_id?: string | null
          nat_key?: string | null
          payment_confirmed?: boolean
          payment_confirmed_amount?: number | null
          payment_confirmed_at?: string | null
          payment_confirmed_by_agent?: string | null
          payment_desc?: string | null
          payment_note?: string | null
          reg_data?: string | null
          reg_prot?: string | null
          totale?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "scadenziario_rows_last_import_fkey"
            columns: ["last_import_id"]
            isOneToOne: false
            referencedRelation: "scadenziario_imports"
            referencedColumns: ["id"]
          },
        ]
      }
      scrape_logs: {
        Row: {
          competitor_id: string | null
          created_at: string | null
          id: string
          message: string | null
          products_found: number | null
          status: string | null
        }
        Insert: {
          competitor_id?: string | null
          created_at?: string | null
          id?: string
          message?: string | null
          products_found?: number | null
          status?: string | null
        }
        Update: {
          competitor_id?: string | null
          created_at?: string | null
          id?: string
          message?: string | null
          products_found?: number | null
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "scrape_logs_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
        ]
      }
      search_miss_resolutions: {
        Row: {
          note: string | null
          query: string
          resolved_at: string
          resolved_by: string
        }
        Insert: {
          note?: string | null
          query: string
          resolved_at?: string
          resolved_by: string
        }
        Update: {
          note?: string | null
          query?: string
          resolved_at?: string
          resolved_by?: string
        }
        Relationships: []
      }
      search_misses: {
        Row: {
          created_at: string
          customer_code: string | null
          id: string
          query: string
          query_raw: string | null
          source: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          customer_code?: string | null
          id?: string
          query: string
          query_raw?: string | null
          source?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          customer_code?: string | null
          id?: string
          query?: string
          query_raw?: string | null
          source?: string
          user_id?: string | null
        }
        Relationships: []
      }
      section_action_permissions: {
        Row: {
          action: string
          allowed: boolean
          created_at: string
          department_id: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          section: string
          updated_at: string
        }
        Insert: {
          action: string
          allowed?: boolean
          created_at?: string
          department_id: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          section: string
          updated_at?: string
        }
        Update: {
          action?: string
          allowed?: boolean
          created_at?: string
          department_id?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          section?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "section_action_permissions_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      section_permissions: {
        Row: {
          created_at: string | null
          department_id: string
          id: string
          permission: string
          role: Database["public"]["Enums"]["app_role"]
          section_key: string
        }
        Insert: {
          created_at?: string | null
          department_id: string
          id?: string
          permission?: string
          role?: Database["public"]["Enums"]["app_role"]
          section_key: string
        }
        Update: {
          created_at?: string | null
          department_id?: string
          id?: string
          permission?: string
          role?: Database["public"]["Enums"]["app_role"]
          section_key?: string
        }
        Relationships: [
          {
            foreignKeyName: "section_permissions_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      shop_settings: {
        Row: {
          address: string | null
          company_name: string
          created_at: string
          email: string | null
          fiscal_code: string | null
          id: string
          logo_url: string | null
          phone: string | null
          singleton: boolean
          tagline: string | null
          updated_at: string
          vat_number: string | null
          website: string | null
        }
        Insert: {
          address?: string | null
          company_name?: string
          created_at?: string
          email?: string | null
          fiscal_code?: string | null
          id?: string
          logo_url?: string | null
          phone?: string | null
          singleton?: boolean
          tagline?: string | null
          updated_at?: string
          vat_number?: string | null
          website?: string | null
        }
        Update: {
          address?: string | null
          company_name?: string
          created_at?: string
          email?: string | null
          fiscal_code?: string | null
          id?: string
          logo_url?: string | null
          phone?: string | null
          singleton?: boolean
          tagline?: string | null
          updated_at?: string
          vat_number?: string | null
          website?: string | null
        }
        Relationships: []
      }
      storico_assortimenti: {
        Row: {
          created_at: string
          id: string
          updated_at: string
          wchfil: string | null
          wdtcre: string | null
          wdtdec: string | null
          wdtvar: string | null
          wnofil: string | null
          wnotei: string | null
          worcre: string | null
          worvar: string | null
          wpospr: string | null
          wposst: string | null
          wprogr: string | null
          wstato: string | null
          wutcre: string | null
          wutvar: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          updated_at?: string
          wchfil?: string | null
          wdtcre?: string | null
          wdtdec?: string | null
          wdtvar?: string | null
          wnofil?: string | null
          wnotei?: string | null
          worcre?: string | null
          worvar?: string | null
          wpospr?: string | null
          wposst?: string | null
          wprogr?: string | null
          wstato?: string | null
          wutcre?: string | null
          wutvar?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          updated_at?: string
          wchfil?: string | null
          wdtcre?: string | null
          wdtdec?: string | null
          wdtvar?: string | null
          wnofil?: string | null
          wnotei?: string | null
          worcre?: string | null
          worvar?: string | null
          wpospr?: string | null
          wposst?: string | null
          wprogr?: string | null
          wstato?: string | null
          wutcre?: string | null
          wutvar?: string | null
        }
        Relationships: []
      }
      storico_assortimenti_field_flags: {
        Row: {
          clarify_flag: boolean | null
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean | null
          read_flag: boolean | null
          updated_at: string
          write_flag: boolean | null
        }
        Insert: {
          clarify_flag?: boolean | null
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean | null
          read_flag?: boolean | null
          updated_at?: string
          write_flag?: boolean | null
        }
        Update: {
          clarify_flag?: boolean | null
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean | null
          read_flag?: boolean | null
          updated_at?: string
          write_flag?: boolean | null
        }
        Relationships: []
      }
      sub_departments: {
        Row: {
          created_at: string
          department_id: string
          description: string | null
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          department_id: string
          description?: string | null
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          department_id?: string
          description?: string | null
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sub_departments_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      sub_user_password_history: {
        Row: {
          created_at: string
          id: string
          password_hash: string
          sub_user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          password_hash: string
          sub_user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          password_hash?: string
          sub_user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "sub_user_password_history_sub_user_id_fkey"
            columns: ["sub_user_id"]
            isOneToOne: false
            referencedRelation: "department_sub_users"
            referencedColumns: ["id"]
          },
        ]
      }
      tassi_di_cambio: {
        Row: {
          cambi: number | null
          cdva2: string | null
          cdval: string | null
          created_at: string
          daa33: string | null
          divst: number | null
          dta33: string | null
          dtval: string | null
          id: string
          nra33: string | null
          updated_at: string
          vrsnmb: string | null
        }
        Insert: {
          cambi?: number | null
          cdva2?: string | null
          cdval?: string | null
          created_at?: string
          daa33?: string | null
          divst?: number | null
          dta33?: string | null
          dtval?: string | null
          id?: string
          nra33?: string | null
          updated_at?: string
          vrsnmb?: string | null
        }
        Update: {
          cambi?: number | null
          cdva2?: string | null
          cdval?: string | null
          created_at?: string
          daa33?: string | null
          divst?: number | null
          dta33?: string | null
          dtval?: string | null
          id?: string
          nra33?: string | null
          updated_at?: string
          vrsnmb?: string | null
        }
        Relationships: []
      }
      tassi_di_cambio_field_flags: {
        Row: {
          clarify_flag: boolean | null
          custom_label: string | null
          field_code: string
          id: string
          missing_flag: boolean | null
          read_flag: boolean | null
          updated_at: string
          write_flag: boolean | null
        }
        Insert: {
          clarify_flag?: boolean | null
          custom_label?: string | null
          field_code: string
          id?: string
          missing_flag?: boolean | null
          read_flag?: boolean | null
          updated_at?: string
          write_flag?: boolean | null
        }
        Update: {
          clarify_flag?: boolean | null
          custom_label?: string | null
          field_code?: string
          id?: string
          missing_flag?: boolean | null
          read_flag?: boolean | null
          updated_at?: string
          write_flag?: boolean | null
        }
        Relationships: []
      }
      taxonomy_content: {
        Row: {
          button_image_url: string | null
          created_at: string
          description: string | null
          display_name: string | null
          gradient_from: string | null
          gradient_to: string | null
          hero_image_url: string | null
          id: string
          is_published_b2b: boolean
          node_code: string
          node_type: string
          sort_order: number
          tagline: string | null
          thumb_image_url: string | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          button_image_url?: string | null
          created_at?: string
          description?: string | null
          display_name?: string | null
          gradient_from?: string | null
          gradient_to?: string | null
          hero_image_url?: string | null
          id?: string
          is_published_b2b?: boolean
          node_code: string
          node_type: string
          sort_order?: number
          tagline?: string | null
          thumb_image_url?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          button_image_url?: string | null
          created_at?: string
          description?: string | null
          display_name?: string | null
          gradient_from?: string | null
          gradient_to?: string | null
          hero_image_url?: string | null
          id?: string
          is_published_b2b?: boolean
          node_code?: string
          node_type?: string
          sort_order?: number
          tagline?: string | null
          thumb_image_url?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      taxonomy_promos: {
        Row: {
          created_at: string
          cta_label: string | null
          ends_at: string | null
          id: string
          image_url: string | null
          is_active: boolean
          link_url: string | null
          node_code: string
          node_type: string
          sort_order: number
          starts_at: string | null
          subtitle: string | null
          title: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          created_at?: string
          cta_label?: string | null
          ends_at?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean
          link_url?: string | null
          node_code: string
          node_type: string
          sort_order?: number
          starts_at?: string | null
          subtitle?: string | null
          title: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          created_at?: string
          cta_label?: string | null
          ends_at?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean
          link_url?: string | null
          node_code?: string
          node_type?: string
          sort_order?: number
          starts_at?: string | null
          subtitle?: string | null
          title?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      untreated_orders_row_visits_global: {
        Row: {
          last_visit_at: string
          last_visit_by: string | null
          richiesta_id: string
        }
        Insert: {
          last_visit_at?: string
          last_visit_by?: string | null
          richiesta_id: string
        }
        Update: {
          last_visit_at?: string
          last_visit_by?: string | null
          richiesta_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "untreated_orders_row_visits_global_richiesta_id_fkey"
            columns: ["richiesta_id"]
            isOneToOne: true
            referencedRelation: "richieste_ordini_non_trattati"
            referencedColumns: ["id"]
          },
        ]
      }
      untreated_orders_tab_visits: {
        Row: {
          last_visit_at: string
          stato: string
          user_id: string
        }
        Insert: {
          last_visit_at?: string
          stato: string
          user_id: string
        }
        Update: {
          last_visit_at?: string
          stato?: string
          user_id?: string
        }
        Relationships: []
      }
      untreated_orders_tab_visits_global: {
        Row: {
          last_visit_at: string
          last_visit_by: string | null
          stato: string
        }
        Insert: {
          last_visit_at?: string
          last_visit_by?: string | null
          stato: string
        }
        Update: {
          last_visit_at?: string
          last_visit_by?: string | null
          stato?: string
        }
        Relationships: []
      }
      user_app_preferences: {
        Row: {
          app_order: Json | null
          created_at: string
          dashboard_config: Json | null
          id: string
          module_prefs: Json
          pinned_apps: Json | null
          theme_preference: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          app_order?: Json | null
          created_at?: string
          dashboard_config?: Json | null
          id?: string
          module_prefs?: Json
          pinned_apps?: Json | null
          theme_preference?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          app_order?: Json | null
          created_at?: string
          dashboard_config?: Json | null
          id?: string
          module_prefs?: Json
          pinned_apps?: Json | null
          theme_preference?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_column_layouts: {
        Row: {
          columns: Json
          created_at: string
          id: string
          scope: string
          updated_at: string
          user_id: string
        }
        Insert: {
          columns?: Json
          created_at?: string
          id?: string
          scope: string
          updated_at?: string
          user_id: string
        }
        Update: {
          columns?: Json
          created_at?: string
          id?: string
          scope?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_departments: {
        Row: {
          created_at: string | null
          department_id: string
          id: string
          is_primary: boolean | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          department_id: string
          id?: string
          is_primary?: boolean | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          department_id?: string
          id?: string
          is_primary?: boolean | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_departments_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      user_login_events: {
        Row: {
          auth_user_id: string
          created_at: string
          device: string | null
          id: string
          ip: string | null
          user_agent: string | null
        }
        Insert: {
          auth_user_id: string
          created_at?: string
          device?: string | null
          id?: string
          ip?: string | null
          user_agent?: string | null
        }
        Update: {
          auth_user_id?: string
          created_at?: string
          device?: string | null
          id?: string
          ip?: string | null
          user_agent?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_sub_departments: {
        Row: {
          created_at: string | null
          id: string
          sub_department_id: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          sub_department_id: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          sub_department_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_sub_departments_sub_department_id_fkey"
            columns: ["sub_department_id"]
            isOneToOne: false
            referencedRelation: "sub_departments"
            referencedColumns: ["id"]
          },
        ]
      }
      user_view_preferences: {
        Row: {
          created_at: string
          id: string
          is_pinned: boolean
          is_shared: boolean
          key: string
          label: string | null
          payload: Json
          scope: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_pinned?: boolean
          is_shared?: boolean
          key: string
          label?: string | null
          payload?: Json
          scope: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_pinned?: boolean
          is_shared?: boolean
          key?: string
          label?: string | null
          payload?: Json
          scope?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      visite_dettaglio: {
        Row: {
          attivita: Database["public"]["Enums"]["attivita_visita"] | null
          citta: string | null
          cliente_codice: string | null
          created_at: string
          id: string
          indirizzo: string | null
          note: string | null
          orario_visita: string | null
          ordine_manuale: number
          ragione_sociale: string
          report_id: string
        }
        Insert: {
          attivita?: Database["public"]["Enums"]["attivita_visita"] | null
          citta?: string | null
          cliente_codice?: string | null
          created_at?: string
          id?: string
          indirizzo?: string | null
          note?: string | null
          orario_visita?: string | null
          ordine_manuale?: number
          ragione_sociale: string
          report_id: string
        }
        Update: {
          attivita?: Database["public"]["Enums"]["attivita_visita"] | null
          citta?: string | null
          cliente_codice?: string | null
          created_at?: string
          id?: string
          indirizzo?: string | null
          note?: string | null
          orario_visita?: string | null
          ordine_manuale?: number
          ragione_sociale?: string
          report_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "visite_dettaglio_report_id_fkey"
            columns: ["report_id"]
            isOneToOne: false
            referencedRelation: "reports_giornalieri"
            referencedColumns: ["id"]
          },
        ]
      }
      workflow_attachments: {
        Row: {
          created_at: string
          entity_id: string
          entity_type: Database["public"]["Enums"]["workflow_entity_type"]
          filename: string
          id: string
          mime_type: string
          size_bytes: number
          storage_path: string
          uploaded_by: string | null
        }
        Insert: {
          created_at?: string
          entity_id: string
          entity_type: Database["public"]["Enums"]["workflow_entity_type"]
          filename: string
          id?: string
          mime_type: string
          size_bytes: number
          storage_path: string
          uploaded_by?: string | null
        }
        Update: {
          created_at?: string
          entity_id?: string
          entity_type?: Database["public"]["Enums"]["workflow_entity_type"]
          filename?: string
          id?: string
          mime_type?: string
          size_bytes?: number
          storage_path?: string
          uploaded_by?: string | null
        }
        Relationships: []
      }
      workflow_step_action_log: {
        Row: {
          action_type: string
          created_at: string
          entity_id: string
          entity_type: Database["public"]["Enums"]["workflow_entity_type"]
          error: string | null
          id: string
          output_ref: string | null
          payload: Json | null
          status: string
          step_key: string
          template_key: string | null
          user_email_snapshot: string | null
          user_id: string | null
        }
        Insert: {
          action_type: string
          created_at?: string
          entity_id: string
          entity_type: Database["public"]["Enums"]["workflow_entity_type"]
          error?: string | null
          id?: string
          output_ref?: string | null
          payload?: Json | null
          status?: string
          step_key: string
          template_key?: string | null
          user_email_snapshot?: string | null
          user_id?: string | null
        }
        Update: {
          action_type?: string
          created_at?: string
          entity_id?: string
          entity_type?: Database["public"]["Enums"]["workflow_entity_type"]
          error?: string | null
          id?: string
          output_ref?: string | null
          payload?: Json | null
          status?: string
          step_key?: string
          template_key?: string | null
          user_email_snapshot?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      workflow_step_events: {
        Row: {
          action: Database["public"]["Enums"]["workflow_action"]
          actor_role: string | null
          created_at: string
          duration_ms: number | null
          entity_id: string
          entity_type: Database["public"]["Enums"]["workflow_entity_type"]
          esito: string | null
          from_step_key: string | null
          id: string
          note: string | null
          note_reason: string | null
          to_step_key: string | null
          transition_key: string | null
          user_email_snapshot: string | null
          user_id: string | null
        }
        Insert: {
          action: Database["public"]["Enums"]["workflow_action"]
          actor_role?: string | null
          created_at?: string
          duration_ms?: number | null
          entity_id: string
          entity_type: Database["public"]["Enums"]["workflow_entity_type"]
          esito?: string | null
          from_step_key?: string | null
          id?: string
          note?: string | null
          note_reason?: string | null
          to_step_key?: string | null
          transition_key?: string | null
          user_email_snapshot?: string | null
          user_id?: string | null
        }
        Update: {
          action?: Database["public"]["Enums"]["workflow_action"]
          actor_role?: string | null
          created_at?: string
          duration_ms?: number | null
          entity_id?: string
          entity_type?: Database["public"]["Enums"]["workflow_entity_type"]
          esito?: string | null
          from_step_key?: string | null
          id?: string
          note?: string | null
          note_reason?: string | null
          to_step_key?: string | null
          transition_key?: string | null
          user_email_snapshot?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      b2b_brands: {
        Row: {
          clas2: string | null
          description: string | null
          gradient_from: string | null
          gradient_to: string | null
          hero_image_url: string | null
          is_published_b2b: boolean | null
          logo_url: string | null
          name: string | null
          slug: string | null
          tagline: string | null
          website_url: string | null
        }
        Insert: {
          clas2?: string | null
          description?: string | null
          gradient_from?: string | null
          gradient_to?: string | null
          hero_image_url?: string | null
          is_published_b2b?: boolean | null
          logo_url?: string | null
          name?: never
          slug?: string | null
          tagline?: string | null
          website_url?: string | null
        }
        Update: {
          clas2?: string | null
          description?: string | null
          gradient_from?: string | null
          gradient_to?: string | null
          hero_image_url?: string | null
          is_published_b2b?: boolean | null
          logo_url?: string | null
          name?: never
          slug?: string | null
          tagline?: string | null
          website_url?: string | null
        }
        Relationships: []
      }
      v_promo_strutturate_testate_stato: {
        Row: {
          b2b_banner_visibility: string | null
          b2b_sort_order: number | null
          cover_image_url: string | null
          created_at: string | null
          excluded_listini: string[] | null
          id: string | null
          show_expiry_b2b: boolean | null
          show_on_customer_view: boolean | null
          unlock_enabled: boolean | null
          unlock_mode: string | null
          unlock_threshold: number | null
          updated_at: string | null
          visible_b2b: boolean | null
          wdtap: number | null
          wdtdp: number | null
          wdtip: number | null
          worap: number | null
          wordp: number | null
          wpcadt: string | null
          wpcain: string | null
          wpcca: string | null
          wpdap: number | null
          wpdma: number | null
          wpdtdof: number | null
          wpdtdoi: number | null
          wpdtls: string | null
          wpdvalf: number | null
          wpdvali: number | null
          wpindif: number | null
          wpindii: number | null
          wpindof: number | null
          wpindoi: number | null
          wpinls: string | null
          wpliadd: string | null
          wpliadi: string | null
          wporv: number | null
          wpprgf: number | null
          wpriatc: number | null
          wpritac: string | null
          wprogr: number | null
          wpstato: string | null
          wpstato_effettivo: string | null
          wptpbc: string | null
          wptpbd: string | null
          wptpbs: string | null
          wptpca: string | null
          wputa: string | null
          wputm: string | null
        }
        Insert: {
          b2b_banner_visibility?: string | null
          b2b_sort_order?: number | null
          cover_image_url?: string | null
          created_at?: string | null
          excluded_listini?: string[] | null
          id?: string | null
          show_expiry_b2b?: boolean | null
          show_on_customer_view?: boolean | null
          unlock_enabled?: boolean | null
          unlock_mode?: string | null
          unlock_threshold?: number | null
          updated_at?: string | null
          visible_b2b?: boolean | null
          wdtap?: number | null
          wdtdp?: number | null
          wdtip?: number | null
          worap?: number | null
          wordp?: number | null
          wpcadt?: string | null
          wpcain?: string | null
          wpcca?: string | null
          wpdap?: number | null
          wpdma?: number | null
          wpdtdof?: number | null
          wpdtdoi?: number | null
          wpdtls?: string | null
          wpdvalf?: number | null
          wpdvali?: number | null
          wpindif?: number | null
          wpindii?: number | null
          wpindof?: number | null
          wpindoi?: number | null
          wpinls?: string | null
          wpliadd?: string | null
          wpliadi?: string | null
          wporv?: number | null
          wpprgf?: number | null
          wpriatc?: number | null
          wpritac?: string | null
          wprogr?: number | null
          wpstato?: string | null
          wpstato_effettivo?: never
          wptpbc?: string | null
          wptpbd?: string | null
          wptpbs?: string | null
          wptpca?: string | null
          wputa?: string | null
          wputm?: string | null
        }
        Update: {
          b2b_banner_visibility?: string | null
          b2b_sort_order?: number | null
          cover_image_url?: string | null
          created_at?: string | null
          excluded_listini?: string[] | null
          id?: string | null
          show_expiry_b2b?: boolean | null
          show_on_customer_view?: boolean | null
          unlock_enabled?: boolean | null
          unlock_mode?: string | null
          unlock_threshold?: number | null
          updated_at?: string | null
          visible_b2b?: boolean | null
          wdtap?: number | null
          wdtdp?: number | null
          wdtip?: number | null
          worap?: number | null
          wordp?: number | null
          wpcadt?: string | null
          wpcain?: string | null
          wpcca?: string | null
          wpdap?: number | null
          wpdma?: number | null
          wpdtdof?: number | null
          wpdtdoi?: number | null
          wpdtls?: string | null
          wpdvalf?: number | null
          wpdvali?: number | null
          wpindif?: number | null
          wpindii?: number | null
          wpindof?: number | null
          wpindoi?: number | null
          wpinls?: string | null
          wpliadd?: string | null
          wpliadi?: string | null
          wporv?: number | null
          wpprgf?: number | null
          wpriatc?: number | null
          wpritac?: string | null
          wprogr?: number | null
          wpstato?: string | null
          wpstato_effettivo?: never
          wptpbc?: string | null
          wptpbd?: string | null
          wptpbs?: string | null
          wptpca?: string | null
          wputa?: string | null
          wputm?: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      _agent_eligible_promo_heads: {
        Args: { _customer_code: string }
        Returns: {
          testata_id: string
          wpprgf: number
        }[]
      }
      _promo_rule_block_matches: {
        Args: {
          block: Json
          cust_category_merch: string
          cust_category_sales: string
          cust_price_list_code: string
          cust_province: string
          cust_zone_code: string
        }
        Returns: boolean
      }
      agent_active_promo_campaigns: {
        Args: { _customer_code: string }
        Returns: {
          articles_count: number
          cover_image: string
          name: string
          promo_type: string
          show_expiry: boolean
          sort_order: number
          subtitle: string
          themes_count: number
          valid_from: string
          valid_until: string
          wpprgf: number
        }[]
      }
      agent_active_promos: {
        Args: { _customer_code: string }
        Returns: {
          campaign_name: string
          cdpar: string
          condition_note: string
          cover_image: string
          discount: number
          offer_name: string
          promo_name: string
          promo_type: string
          qty_max: number
          qty_min: number
          show_expiry: boolean
          theme_id: string
          theme_image: string
          valid_from: string
          valid_until: string
          wpprgf: number
        }[]
      }
      agent_active_promos_bulk: {
        Args: { _customer_codes: string[] }
        Returns: {
          campaign_name: string
          cdpar: string
          condition_note: string
          cover_image: string
          customer_code: string
          discount: number
          offer_name: string
          promo_name: string
          promo_type: string
          qty_max: number
          qty_min: number
          show_expiry: boolean
          theme_id: string
          theme_image: string
          valid_from: string
          valid_until: string
          wpprgf: number
        }[]
      }
      agent_all_active_promo_campaigns: {
        Args: never
        Returns: {
          articles_count: number
          cover_image: string
          name: string
          promo_type: string
          show_expiry: boolean
          sort_order: number
          subtitle: string
          themes_count: number
          valid_from: string
          valid_until: string
          wpprgf: number
        }[]
      }
      agent_all_active_promos: {
        Args: never
        Returns: {
          campaign_name: string
          cdpar: string
          condition_note: string
          cover_image: string
          discount: number
          offer_name: string
          promo_name: string
          promo_type: string
          qty_max: number
          qty_min: number
          show_expiry: boolean
          theme_id: string
          theme_image: string
          valid_from: string
          valid_until: string
          wpprgf: number
        }[]
      }
      agent_catalog_index_delta: {
        Args: { p_since?: string }
        Returns: {
          barcd: string
          cdpar: string
          clas2: string
          clmer: string
          cod_padre: string
          depar: string
          descrizione: string
          is_active: boolean
          tags: string[]
          titolo: string
          updated_at: string
        }[]
      }
      agent_customer_view_promos: {
        Args: { _customer_code: string }
        Returns: {
          cover_image: string
          name: string
          testata_id: string
          valid_from: string
          valid_until: string
          wpprgf: number
        }[]
      }
      agent_customer_view_promos_bulk: {
        Args: { _customer_codes: string[] }
        Returns: {
          cover_image: string
          customer_code: string
          name: string
          testata_id: string
          valid_from: string
          valid_until: string
          wpprgf: number
        }[]
      }
      agent_order_download_batches: {
        Args: { _order_ids: string[] }
        Returns: {
          batch_id: string
          created_at: string
          file_name: string
          order_id: string
          progressivo: number
        }[]
      }
      agent_otp_needs_challenge: {
        Args: { _device_id: string }
        Returns: boolean
      }
      agent_otp_phone_status: { Args: never; Returns: Json }
      agent_promo_themes_available: {
        Args: { _wpprgf: number }
        Returns: {
          articles_count: number
          description: string
          id: string
          image_url: string
          name: string
          sort_order: number
          wpprgf: number
        }[]
      }
      analytics_resi_by_agente: {
        Args: { _from: string; _limit?: number; _to: string }
        Returns: {
          agente: string
          count: number
        }[]
      }
      analytics_resi_by_causale: {
        Args: { _from: string; _limit?: number; _to: string }
        Returns: {
          causale: string
          count: number
        }[]
      }
      analytics_resi_by_step: {
        Args: { _from: string; _to: string }
        Returns: {
          count: number
          step_key: string
        }[]
      }
      analytics_resi_kpi: {
        Args: { _from: string; _to: string }
        Returns: {
          aperti: number
          cancellati: number
          chiusi: number
          chiusi_periodo: number
          nuovi_periodo: number
          tempo_medio_chiusura_ms: number
          totale: number
        }[]
      }
      analytics_resi_step_duration: {
        Args: { _from: string; _to: string }
        Returns: {
          avg_duration_ms: number
          median_duration_ms: number
          samples: number
          step_key: string
        }[]
      }
      analytics_resi_trend: {
        Args: { _bucket?: string; _from: string; _to: string }
        Returns: {
          bucket: string
          chiusure: number
          ingressi: number
        }[]
      }
      b2b_active_promo_campaigns: {
        Args: { _customer_code?: string }
        Returns: {
          articles_count: number
          cover_image: string
          is_adherent: boolean
          name: string
          promo_type: string
          show_expiry: boolean
          sort_order: number
          subtitle: string
          themes_count: number
          valid_from: string
          valid_until: string
          wpprgf: number
        }[]
      }
      b2b_assortment_article_count: { Args: { _id: string }; Returns: number }
      b2b_assortments_deactivate_expired: { Args: never; Returns: number }
      b2b_catalogo_theme_count: { Args: { _tema_id: string }; Returns: number }
      b2b_catalogo_theme_products: {
        Args: { _limit?: number; _offset?: number; _tema_id: string }
        Returns: {
          cdpar: string
        }[]
      }
      b2b_catalogo_theme_skus: {
        Args: { _tema_id: string }
        Returns: {
          cdpar: string
        }[]
      }
      backfill_prmil_chunk: {
        Args: { _limit?: number; _listino: string }
        Returns: number
      }
      brands_with_visible_products: {
        Args: never
        Returns: {
          clas2: string
        }[]
      }
      can_access_customer_order: {
        Args: { _order_id: string }
        Returns: boolean
      }
      can_bypass_b2b_maintenance: {
        Args: { _user_id: string }
        Returns: boolean
      }
      can_manage_workflow: { Args: { _uid: string }; Returns: boolean }
      catalog_search_code_norm: { Args: { p_text: string }; Returns: string }
      catalog_search_gtin_valid: { Args: { p_code: string }; Returns: boolean }
      catalog_search_norm: { Args: { p_text: string }; Returns: string }
      catalog_search_stem: { Args: { p_text: string }; Returns: string }
      catalog_search_upsert: { Args: { p_cdpars: string[] }; Returns: number }
      catalog_search_v2: {
        Args: {
          p_allowed_cdpars?: string[]
          p_brand_codes?: string[]
          p_categoria?: string[]
          p_channel?: string
          p_debug?: boolean
          p_depar?: string[]
          p_gamma?: string[]
          p_limit?: number
          p_offset?: number
          p_query: string
          p_tags?: string[]
        }
        Returns: {
          brand_name: string
          cdpar: string
          cod_padre: string
          config_version: number
          has_more: boolean
          match_fields: string[]
          match_reasons: Json
          matched_cdpar: string
          score: number
          title: string
          total_count: number
          visible_cdpar: string
        }[]
      }
      check_sub_user_password_available: {
        Args: { p_password: string; p_sub_user_id: string }
        Returns: string
      }
      compute_b2b_online_effective: {
        Args: { _active: boolean; _wfuas: string }
        Returns: boolean
      }
      compute_recalculated_prmil: {
        Args: { _cdlsl: string; _cdpar: string }
        Returns: number
      }
      compute_recalculated_prmil_batch: {
        Args: { _cdlsl?: string; _cdpars: string[] }
        Returns: {
          cdpar: string
          prmil: number
        }[]
      }
      controls_articoli_legacy_clmer: {
        Args: { lim?: number; off?: number; visible_assortments?: string[] }
        Returns: {
          cdpar: string
          clmer: string
          depar: string
          lipro: string
          pcfor: string
          total_count: number
          wfuas: string
        }[]
      }
      controls_articoli_per_clmer: {
        Args: {
          lim?: number
          off?: number
          p_clmer: string
          visible_assortments?: string[]
        }
        Returns: {
          cdpar: string
          clmer: string
          depar: string
          lipro: string
          pcfor: string
          total_count: number
          wfuas: string
        }[]
      }
      controls_articoli_senza_attributi: {
        Args: { lim?: number; off?: number; visible_assortments?: string[] }
        Returns: {
          cdpar: string
          clmer: string
          depar: string
          missing_attrs: string[]
          pcfor: string
          total_count: number
          wfuas: string
        }[]
      }
      controls_articoli_senza_attributi_any: {
        Args: {
          lim?: number
          off?: number
          search_text?: string
          visible_assortments?: string[]
        }
        Returns: {
          cdpar: string
          clmer: string
          depar: string
          pcfor: string
          total_count: number
          wfuas: string
        }[]
      }
      controls_articoli_senza_descrizione: {
        Args: { lim?: number; off?: number; visible_assortments?: string[] }
        Returns: {
          cdpar: string
          clmer: string
          depar: string
          has_title_legacy: boolean
          pcfor: string
          total_count: number
          wfuas: string
        }[]
      }
      controls_articoli_senza_gamma: {
        Args: { lim?: number; off?: number; visible_assortments?: string[] }
        Returns: {
          cdpar: string
          clmer: string
          depar: string
          lipro: string
          pcfor: string
          total_count: number
          wclas1rw: string
          wdset: string
          wfuas: string
        }[]
      }
      controls_articoli_senza_immagine: {
        Args: { lim?: number; off?: number; visible_assortments?: string[] }
        Returns: {
          cdpar: string
          clmer: string
          depar: string
          lipro: string
          pcfor: string
          total_count: number
          wfuas: string
        }[]
      }
      controls_articoli_senza_listino: {
        Args: { lim?: number; off?: number; visible_assortments?: string[] }
        Returns: {
          cdpar: string
          clmer: string
          depar: string
          pcfor: string
          total_count: number
          wfuas: string
        }[]
      }
      controls_articoli_senza_reparto: {
        Args: { lim?: number; off?: number; visible_assortments?: string[] }
        Returns: {
          cdpar: string
          clmer: string
          depar: string
          lipro: string
          pcfor: string
          total_count: number
          wclas1rw: string
          wdset: string
          wfuas: string
        }[]
      }
      controls_articoli_senza_scheda_tecnica: {
        Args: { lim?: number; off?: number; visible_assortments?: string[] }
        Returns: {
          cdpar: string
          clmer: string
          depar: string
          pcfor: string
          total_count: number
          wfuas: string
        }[]
      }
      controls_counts:
        | { Args: { visible_assortments?: string[] }; Returns: Json }
        | {
            Args: { only_b2b_online?: boolean; visible_assortments?: string[] }
            Returns: Json
          }
      count_articles_with_barcodes: {
        Args: { assortments?: string[] }
        Returns: number
      }
      count_articles_with_media: { Args: never; Returns: number }
      count_articles_with_media_filtered: {
        Args: { assortments?: string[] }
        Returns: number
      }
      current_customer_id: { Args: never; Returns: string }
      current_user_can_bypass_b2b: { Args: never; Returns: boolean }
      current_user_is_admin: { Args: never; Returns: boolean }
      deactivate_query18_missing: { Args: { p_codes: string[] }; Returns: Json }
      delorean_advance_status: {
        Args: {
          _id: string
          _new_status: string
          _note?: string
          _table: string
        }
        Returns: Json
      }
      distinct_column_values: { Args: { col_name: string }; Returns: string[] }
      dlr_fill_customer_service: { Args: { _rows: Json }; Returns: number }
      fn_b2b_is_effectively_online: {
        Args: { _b2b_online_active: boolean; _wfuas: string }
        Returns: boolean
      }
      fn_refresh_recalculated_prmil_for_article: {
        Args: { _cdlsl?: string; _cdpar: string }
        Returns: undefined
      }
      generate_order_download_batch: {
        Args: { p_order_ids?: string[] }
        Returns: Json
      }
      get_catalog_search_config: { Args: never; Returns: Json }
      get_category_brand_counts: {
        Args: { p_clmer: string }
        Returns: {
          clas2: string
          cnt: number
        }[]
      }
      get_category_products_count: {
        Args: { p_clmer_label: string; p_department?: string; p_range?: string }
        Returns: number
      }
      get_category_products_ordered:
        | {
            Args: {
              p_clmer_label: string
              p_department?: string
              p_limit?: number
              p_offset?: number
              p_range?: string
            }
            Returns: {
              cdpar: string
            }[]
          }
        | {
            Args: {
              p_clmer_label: string
              p_department?: string
              p_limit?: number
              p_offset?: number
              p_range?: string
              p_rotation_offset?: number
            }
            Returns: {
              cdpar: string
            }[]
          }
      get_category_taxonomy_pairs: {
        Args: { p_clmer: string }
        Returns: {
          gamma: string
          reparto: string
        }[]
      }
      get_current_customer_code: { Args: never; Returns: string }
      get_distinct_article_tags: {
        Args: never
        Returns: {
          tag: string
        }[]
      }
      get_online_assortments: { Args: never; Returns: string[] }
      get_random_catalog_cdpars:
        | {
            Args: { page_offset: number; page_size: number; seed: number }
            Returns: {
              cdpar: string
            }[]
          }
        | {
            Args: {
              page_offset: number
              page_size: number
              price_listino?: string
              seed: number
            }
            Returns: {
              cdpar: string
            }[]
          }
      get_standard_fields: { Args: never; Returns: Json }
      get_standard_fields_anag_art_fornitore: { Args: never; Returns: Json }
      get_standard_fields_codici_barre: { Args: never; Returns: Json }
      get_standard_fields_differenziale_cambio: { Args: never; Returns: Json }
      get_standard_fields_fornitori: { Args: never; Returns: Json }
      get_standard_fields_listini: { Args: never; Returns: Json }
      get_standard_fields_lv_campagne: { Args: never; Returns: Json }
      get_standard_fields_lv_condizioni: { Args: never; Returns: Json }
      get_standard_fields_lv_criteri_prezzo: { Args: never; Returns: Json }
      get_standard_fields_lv_def_base: { Args: never; Returns: Json }
      get_standard_fields_lv_dettagli: { Args: never; Returns: Json }
      get_standard_fields_lv_testate: { Args: never; Returns: Json }
      get_standard_fields_nomenclatura_combinata: { Args: never; Returns: Json }
      get_standard_fields_prezzi_in_attesa: { Args: never; Returns: Json }
      get_standard_fields_storico_assortimenti: { Args: never; Returns: Json }
      get_standard_fields_tassi_di_cambio: { Args: never; Returns: Json }
      get_supplier_brand_comparison: {
        Args: { p_group_by: string; p_search?: string }
        Returns: Json
      }
      get_user_department: { Args: { _user_id: string }; Returns: string }
      get_user_departments: { Args: { _user_id: string }; Returns: string[] }
      get_user_display_names: {
        Args: { _ids: string[] }
        Returns: {
          display: string
          email: string
          id: string
        }[]
      }
      get_user_role: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      get_user_sub_department: { Args: { _user_id: string }; Returns: string }
      get_user_sub_departments: {
        Args: { _user_id: string }
        Returns: string[]
      }
      get_workflow_dashboard_counts: {
        Args: { p_entity_type: string }
        Returns: {
          record_count: number
          step_key: string
        }[]
      }
      get_workflow_step_avg_days: {
        Args: { p_entity_type: string }
        Returns: {
          avg_days: number
          step_key: string
        }[]
      }
      get_workflow_timeline_counts: {
        Args: {
          p_end_date: string
          p_entity_type: string
          p_start_date: string
        }
        Returns: {
          completed_records: number
          total_records: number
        }[]
      }
      get_wsm01_per_lettera:
        | {
            Args: { p_category: string }
            Returns: {
              lettera: string
              max_val: number
              min_val: number
              n_articoli: number
              n_distinti: number
              wcdls: string
              wsm01_value: number
            }[]
          }
        | {
            Args: { p_category: string; p_visible_assortments?: string[] }
            Returns: {
              lettera: string
              max_val: number
              min_val: number
              n_articoli: number
              n_distinti: number
              wcdls: string
              wsm01_value: number
            }[]
          }
      has_future_pending_price: {
        Args: { _cdlsl: string; _cdpar: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      has_section_permission: {
        Args: { _min_permission: string; _section: string; _user_id: string }
        Returns: boolean
      }
      import_catalogo_carta: { Args: { p_rows: Json }; Returns: Json }
      import_customers_snapshot: {
        Args: { p_filename?: string; rows: Json }
        Returns: Json
      }
      import_inventory_snapshot: {
        Args: { p_filename?: string; p_zero_fill?: boolean; rows: Json }
        Returns: Json
      }
      import_query01_articoli: { Args: { p_rows: Json }; Returns: Json }
      import_query02_anag_art_fornitori: {
        Args: { p_rows: Json }
        Returns: Json
      }
      import_query03_codici_barre: { Args: { p_rows: Json }; Returns: Json }
      import_query04_listini: { Args: { p_rows: Json }; Returns: Json }
      import_query05_differenziale_cambio: {
        Args: { p_rows: Json }
        Returns: Json
      }
      import_query06_tassi_cambio: { Args: { p_rows: Json }; Returns: Json }
      import_query07_listini_campagne: { Args: { p_rows: Json }; Returns: Json }
      import_query08_criteri_prezzo: { Args: { p_rows: Json }; Returns: Json }
      import_query09_def_base: { Args: { p_rows: Json }; Returns: Json }
      import_query10_dettagli: { Args: { p_rows: Json }; Returns: Json }
      import_query11_listini_testate: { Args: { p_rows: Json }; Returns: Json }
      import_query12_prezzi_attesa: { Args: { p_rows: Json }; Returns: Json }
      import_query13_campagne_associate: {
        Args: { p_rows: Json }
        Returns: Json
      }
      import_query14_condizioni: {
        Args: { p_reset?: boolean; p_rows: Json }
        Returns: Json
      }
      import_query15_elementi: { Args: { p_rows: Json }; Returns: Json }
      import_query16_testate: { Args: { p_rows: Json }; Returns: Json }
      import_query17_nomenclatura_combinata: {
        Args: { p_rows: Json }
        Returns: Json
      }
      import_query18_fornitori: { Args: { p_rows: Json }; Returns: Json }
      import_query19_condizioni: {
        Args: { p_reset?: boolean; p_rows: Json }
        Returns: Json
      }
      import_query20_storico_assortimenti: {
        Args: { p_reset?: boolean; p_rows: Json }
        Returns: Json
      }
      import_query99_ricarico: {
        Args: { p_rows: Json; p_wcdls: string }
        Returns: Json
      }
      import_scadenziario_for_agent: {
        Args: {
          p_agent_code: string
          p_filename: string
          p_total_amount?: number
          rows: Json
        }
        Returns: Json
      }
      import_scadenziario_snapshot: {
        Args: { p_filename: string; p_total_amount?: number; rows: Json }
        Returns: Json
      }
      increment_catalog_views: { Args: { p_slug: string }; Returns: undefined }
      is_admin: { Args: { _user_id: string }; Returns: boolean }
      is_agent_for_customer: {
        Args: { _customer_id: string }
        Returns: boolean
      }
      is_agent_of_customer: { Args: { _customer_id: string }; Returns: boolean }
      is_customer_of_current_agent: {
        Args: { _cart_user_id: string }
        Returns: boolean
      }
      jsonb_object_agg_strict: {
        Args: { keys: string[]; obj: Json }
        Returns: Json
      }
      list_broken_p_paths: {
        Args: { p_limit?: number }
        Returns: {
          name: string
        }[]
      }
      mark_password_changed: { Args: never; Returns: undefined }
      pim_article_perf_top: {
        Args: {
          _from: string
          _limit?: number
          _order_by?: string
          _source?: string
          _to: string
        }
        Returns: {
          cart_adds: number
          cdpar: string
          conversion_rate: number
          orders: number
          views: number
        }[]
      }
      pim_article_search_referrers: {
        Args: { _cdpar: string; _from: string; _to: string }
        Returns: {
          last_seen: string
          n: number
          query: string
        }[]
      }
      pim_article_timeseries: {
        Args: { _cdpar: string; _from: string; _to: string }
        Returns: {
          bucket: string
          cart_adds: number
          cart_removes: number
          orders: number
          views: number
        }[]
      }
      pim_best_promo_for_cart: {
        Args: {
          _cdls: string
          _customer_code: string
          _date: string
          _lines: Json
        }
        Returns: {
          applied_promo: string
          cdpar: string
          line_idx: number
          qty: number
          sconto_pct: number
          tema_id: string
          tema_nome: string
          tema_tipo: string
          wpprgf: number
        }[]
      }
      pim_best_promo_for_line: {
        Args: {
          _cdls: string
          _cdpar: string
          _customer_code: string
          _date: string
          _netto_unitario?: number
          _qty: number
        }
        Returns: {
          applied_promo: string
          sconto_pct: number
          tema_id: string
          tema_nome: string
          tema_tipo: string
          wpdes: string
          wpprgf: number
        }[]
      }
      pim_best_promo_omaggi_for_cart: {
        Args: {
          _cdls: string
          _customer_code: string
          _date: string
          _lines: Json
        }
        Returns: {
          applied_promo: string
          is_choice: boolean
          omaggio_cdpar: string
          omaggio_modalita: string
          omaggio_qty: number
          scaglione_id: string
          tema_id: string
          tema_nome: string
          wpdes: string
          wpprgf: number
        }[]
      }
      pim_compute_promo_stato: {
        Args: {
          _current?: string
          _wpindif: number
          _wpindii: number
          _wpindof: number
          _wpindoi: number
        }
        Returns: string
      }
      pim_count_articoli_attributi_corrotti: { Args: never; Returns: number }
      pim_import_assortimenti: {
        Args: { p_dry_run?: boolean; p_rows: Json }
        Returns: Json
      }
      pim_list_articoli_attributi_corrotti: {
        Args: never
        Returns: {
          attributes: Json
          cdpar: string
          depar: string
        }[]
      }
      pim_prezzo_listino: {
        Args: { _cdls: string; _cdpar: string }
        Returns: number
      }
      pim_prezzo_listino_batch: {
        Args: { _cdls: string; _cdpars: string[] }
        Returns: {
          cdpar: string
          prezzo: number
        }[]
      }
      pim_promo_article_eligible:
        | { Args: { _cdpar: string; _testata_id: string }; Returns: boolean }
        | { Args: { _cdpar: string; _wpprgf: number }; Returns: boolean }
      pim_promo_customer_eligible:
        | {
            Args: {
              _customer_code: string
              _testata_id: string
              _today: string
            }
            Returns: boolean
          }
        | {
            Args: { _customer_code: string; _wpprgf: number }
            Returns: boolean
          }
      pim_promo_next_step_for_cart: {
        Args: {
          _cdls: string
          _customer_code: string
          _date: string
          _lines: Json
        }
        Returns: {
          out_current_value: number
          out_line_idx: number
          out_missing_value: number
          out_next_sconto_pct: number
          out_pe_o: number
          out_pe_p: number
          out_target_value: number
          out_tema_id: string
          out_tema_nome: string
          out_tema_tipo: string
          out_unit: string
          out_wpprgf: number
        }[]
      }
      pim_report_recipient_name: {
        Args: { _audience: string; _code: string }
        Returns: string
      }
      pim_report_rows_for: {
        Args: { _code: string; _report_id: string }
        Returns: {
          id: string
          recipient_code: string
          recipient_name: string
          sort_order: number
          values: Json
        }[]
      }
      pim_scadenziario_agents_summary: {
        Args: never
        Returns: {
          agent_code: string
          agent_name: string
          confirmed_count: number
          customers_count: number
          overdue_count: number
          rows_count: number
          total: number
          total_confirmed: number
          total_open: number
        }[]
      }
      pim_scadenziario_customers_for_agent: {
        Args: { p_agent_code: string }
        Returns: {
          confirmed_count: number
          customer_code: string
          customer_name: string
          overdue_count: number
          rows_count: number
          total: number
        }[]
      }
      pim_scadenziario_export: {
        Args: { p_agent_code?: string; p_only_paid?: boolean; p_query?: string }
        Returns: {
          agent_code: string
          agent_name: string
          causal: string
          contanti: number
          currency: string
          customer_code: string
          customer_name: string
          doc_date: string
          doc_number: string
          due_date: string
          effetti: number
          is_overdue: boolean
          payment_confirmed: boolean
          payment_confirmed_amount: number
          payment_confirmed_at: string
          payment_confirmed_by_agent: string
          payment_desc: string
          reg_data: string
          reg_prot: string
          totale: number
        }[]
      }
      pim_scadenziario_search_customers: {
        Args: { p_query: string }
        Returns: {
          agent_code: string
          confirmed_count: number
          customer_code: string
          customer_name: string
          overdue_count: number
          rows_count: number
          total: number
        }[]
      }
      pim_search_misses_agg: {
        Args: {
          _from: string
          _min_count?: number
          _source?: string
          _to: string
        }
        Returns: {
          last_seen: string
          n: number
          n_agent: number
          n_b2b: number
          n_customers: number
          n_users: number
          query: string
          resolved_at: string
        }[]
      }
      pim_search_misses_timeseries: {
        Args: { _from: string; _to: string }
        Returns: {
          bucket: string
          n: number
        }[]
      }
      rebuild_catalog_search_index: { Args: never; Returns: Json }
      record_sub_user_password: {
        Args: { p_password: string; p_sub_user_id: string }
        Returns: undefined
      }
      refresh_catalog_search_item: {
        Args: { p_cdpar: string }
        Returns: number
      }
      regenerate_order_download_batch: {
        Args: { p_batch_id: string }
        Returns: Json
      }
      report_is_published: { Args: { _report_id: string }; Returns: boolean }
      resolve_assigned_agent_id: { Args: { _code: string }; Returns: string }
      search_agent_catalog_products: {
        Args: {
          p_allowed_cdpars?: string[]
          p_brand_codes?: string[]
          p_limit?: number
          p_offset?: number
          p_query: string
          p_tag_matches?: string[]
          p_token_groups?: Json
        }
        Returns: {
          attributes: Json
          b2b_online_effective: boolean
          b2b_product_description: string
          b2b_product_title: string
          barcd: string
          cdiva: string
          cdpar: string
          clas1: string
          clas2: string
          clmer: string
          cod_padre: string
          depar: string
          description_marketing: string
          descrizione: string
          descrizione_b2b: string
          descrizione_variante: string
          lipro: string
          master_pack: number
          nmdis: string
          search_rank: number
          tags: string[]
          titolo_b2b: string
          umalt: string
          unmis: string
          wfc2x: number
          wvvii: string
        }[]
      }
      search_article_tags: {
        Args: { lim?: number; q?: string }
        Returns: {
          tag: string
          usage_count: number
        }[]
      }
      search_articles: {
        Args: {
          filter_clmer?: string
          filter_lipro?: string
          filter_wfuas?: string
          lim?: number
          off?: number
          query: string
        }
        Returns: {
          as400_sync_status: string
          attributes: Json
          b2b_online_active: boolean
          barcd: string
          cdpar: string
          clmer: string
          depar: string
          id: string
          lipro: string
          pcfor: string
          total_count: number
          unmis: string
          updated_at: string
          wfuas: string
        }[]
      }
      search_articoli_fast:
        | {
            Args: { lim?: number; off?: number; tokens: string[] }
            Returns: {
              agcic: string | null
              as400_sync_status: string | null
              attributes: Json | null
              b2b_content_updated_at: string | null
              b2b_first_published_at: string | null
              b2b_online_active: boolean | null
              b2b_online_effective: boolean
              b2b_product_description: string | null
              b2b_product_title: string | null
              barcd: string | null
              cat_id: string | null
              cat_id_2: string | null
              catalogo_carta_dettaglio: string | null
              catalogo_carta_scheda: string | null
              catalogo_carta_titolo: string | null
              ccndi: string | null
              cdiva: string | null
              cdpaf: string | null
              cdpar: string
              cdrga: string | null
              cdst1: string | null
              cdst2: string | null
              cdst3: string | null
              cecoa: string | null
              cenco: string | null
              ceric: string | null
              cfcal: number | null
              clapp: string | null
              clas1: string | null
              clas2: string | null
              clmer: string | null
              cmltc: number | null
              cod_padre: string | null
              conac: string | null
              conem: string | null
              cprop: string | null
              created_at: string
              crevd: string | null
              crimp: string | null
              crimt: string | null
              crrio: string | null
              crtpr: string | null
              daa26: string | null
              depar: string | null
              description_ecommerce: string | null
              description_marketing: string | null
              descrizione: string | null
              descrizione_b2b: string | null
              descrizione_variante: string | null
              dtac5: string | null
              dtcic: string | null
              dtltc: string | null
              dtstr: string | null
              dvrif: string | null
              escam: string | null
              evadi: string | null
              flglo: string | null
              flscr: string | null
              fts: unknown
              fts_simple: unknown
              gprop: number | null
              hlvmn: number | null
              id: string
              indgc: string | null
              lipro: string | null
              livmn: number | null
              master_pack: number | null
              mespc: string | null
              mgimp: string | null
              nmcat: string | null
              nmdis: string | null
              nocod: string | null
              nprop: number | null
              nrass: number | null
              nrcom: number | null
              nrope: number | null
              pcfor: string | null
              pcter: string | null
              pesun: number | null
              prefa: string | null
              preup: number | null
              preupe: number | null
              prlot: number | null
              prvoc: string | null
              prvor: string | null
              ptefo: number | null
              ptpap: string | null
              qarpl: number | null
              qmnpl: number | null
              qmxpl: number | null
              qprop: number | null
              recfl: string | null
              seo_description: string | null
              seo_title: string | null
              tags: string[] | null
              tecop: number | null
              titolo_b2b: string | null
              tpimb: string | null
              tppra: string | null
              tpprb: string | null
              tpprc: string | null
              tprod: number | null
              tproe: number | null
              tprov: number | null
              trevo: number | null
              umalt: string | null
              umfa2: number | null
              umfaa: number | null
              umfat: number | null
              unmi2: string | null
              unmis: string | null
              unpes: string | null
              untec: string | null
              updated_at: string
              updated_by: string | null
              vocor: string | null
              vocos: string | null
              vospa: string | null
              wabldrw: string | null
              wablorw: string | null
              wacau: string | null
              wartoma: string | null
              waslbrw: string | null
              waslorw: string | null
              wcdst: string | null
              wclas1rw: string | null
              wclas2rw: string | null
              wclas3rw: string | null
              wclve: string | null
              wcpad: string | null
              wcpgm: string | null
              wdalodrw: string | null
              wdaloorw: string | null
              wdeag: string | null
              wdis1drw: string | null
              wdis1orw: string | null
              wdis2drw: string | null
              wdis2orw: string | null
              wdset: string | null
              wdtscdrw: string | null
              wdtscorw: string | null
              wesrc: string | null
              wfc1s: number | null
              wfc2x: number | null
              wfcs1: number | null
              wfcvr: string | null
              wfitt: string | null
              wfuas: string | null
              wfuaspr: number | null
              wgia1drw: string | null
              wgia1orw: string | null
              wgia2drw: string | null
              wgia2orw: string | null
              wgkit: string | null
              wgslorw: string | null
              wgsltrw: string | null
              wimba: string | null
              wniva: string | null
              wnprv: string | null
              wnsts: string | null
              wolodrw: string | null
              woloorw: string | null
              wperspa: string | null
              wpocc: string | null
              wprasdrw: string | null
              wpraserw: string | null
              wprasorw: string | null
              wpzne: string | null
              wqtmndrw: string | null
              wqtmnorw: string | null
              wsezi: string | null
              wsovr: string | null
              wsqvs: string | null
              wstag: string | null
              wtrac: string | null
              wumrf: string | null
              wumsp: string | null
              wvqtm: number | null
              wvtai: string | null
              wvvii: string | null
              wvviq: string | null
            }[]
            SetofOptions: {
              from: "*"
              to: "archivio_articoli_fraschetti"
              isOneToOne: false
              isSetofReturn: true
            }
          }
        | {
            Args: {
              lim?: number
              off?: number
              p_token_groups?: Json
              tokens: string[]
            }
            Returns: {
              agcic: string | null
              as400_sync_status: string | null
              attributes: Json | null
              b2b_content_updated_at: string | null
              b2b_first_published_at: string | null
              b2b_online_active: boolean | null
              b2b_online_effective: boolean
              b2b_product_description: string | null
              b2b_product_title: string | null
              barcd: string | null
              cat_id: string | null
              cat_id_2: string | null
              catalogo_carta_dettaglio: string | null
              catalogo_carta_scheda: string | null
              catalogo_carta_titolo: string | null
              ccndi: string | null
              cdiva: string | null
              cdpaf: string | null
              cdpar: string
              cdrga: string | null
              cdst1: string | null
              cdst2: string | null
              cdst3: string | null
              cecoa: string | null
              cenco: string | null
              ceric: string | null
              cfcal: number | null
              clapp: string | null
              clas1: string | null
              clas2: string | null
              clmer: string | null
              cmltc: number | null
              cod_padre: string | null
              conac: string | null
              conem: string | null
              cprop: string | null
              created_at: string
              crevd: string | null
              crimp: string | null
              crimt: string | null
              crrio: string | null
              crtpr: string | null
              daa26: string | null
              depar: string | null
              description_ecommerce: string | null
              description_marketing: string | null
              descrizione: string | null
              descrizione_b2b: string | null
              descrizione_variante: string | null
              dtac5: string | null
              dtcic: string | null
              dtltc: string | null
              dtstr: string | null
              dvrif: string | null
              escam: string | null
              evadi: string | null
              flglo: string | null
              flscr: string | null
              fts: unknown
              fts_simple: unknown
              gprop: number | null
              hlvmn: number | null
              id: string
              indgc: string | null
              lipro: string | null
              livmn: number | null
              master_pack: number | null
              mespc: string | null
              mgimp: string | null
              nmcat: string | null
              nmdis: string | null
              nocod: string | null
              nprop: number | null
              nrass: number | null
              nrcom: number | null
              nrope: number | null
              pcfor: string | null
              pcter: string | null
              pesun: number | null
              prefa: string | null
              preup: number | null
              preupe: number | null
              prlot: number | null
              prvoc: string | null
              prvor: string | null
              ptefo: number | null
              ptpap: string | null
              qarpl: number | null
              qmnpl: number | null
              qmxpl: number | null
              qprop: number | null
              recfl: string | null
              seo_description: string | null
              seo_title: string | null
              tags: string[] | null
              tecop: number | null
              titolo_b2b: string | null
              tpimb: string | null
              tppra: string | null
              tpprb: string | null
              tpprc: string | null
              tprod: number | null
              tproe: number | null
              tprov: number | null
              trevo: number | null
              umalt: string | null
              umfa2: number | null
              umfaa: number | null
              umfat: number | null
              unmi2: string | null
              unmis: string | null
              unpes: string | null
              untec: string | null
              updated_at: string
              updated_by: string | null
              vocor: string | null
              vocos: string | null
              vospa: string | null
              wabldrw: string | null
              wablorw: string | null
              wacau: string | null
              wartoma: string | null
              waslbrw: string | null
              waslorw: string | null
              wcdst: string | null
              wclas1rw: string | null
              wclas2rw: string | null
              wclas3rw: string | null
              wclve: string | null
              wcpad: string | null
              wcpgm: string | null
              wdalodrw: string | null
              wdaloorw: string | null
              wdeag: string | null
              wdis1drw: string | null
              wdis1orw: string | null
              wdis2drw: string | null
              wdis2orw: string | null
              wdset: string | null
              wdtscdrw: string | null
              wdtscorw: string | null
              wesrc: string | null
              wfc1s: number | null
              wfc2x: number | null
              wfcs1: number | null
              wfcvr: string | null
              wfitt: string | null
              wfuas: string | null
              wfuaspr: number | null
              wgia1drw: string | null
              wgia1orw: string | null
              wgia2drw: string | null
              wgia2orw: string | null
              wgkit: string | null
              wgslorw: string | null
              wgsltrw: string | null
              wimba: string | null
              wniva: string | null
              wnprv: string | null
              wnsts: string | null
              wolodrw: string | null
              woloorw: string | null
              wperspa: string | null
              wpocc: string | null
              wprasdrw: string | null
              wpraserw: string | null
              wprasorw: string | null
              wpzne: string | null
              wqtmndrw: string | null
              wqtmnorw: string | null
              wsezi: string | null
              wsovr: string | null
              wsqvs: string | null
              wstag: string | null
              wtrac: string | null
              wumrf: string | null
              wumsp: string | null
              wvqtm: number | null
              wvtai: string | null
              wvvii: string | null
              wvviq: string | null
            }[]
            SetofOptions: {
              from: "*"
              to: "archivio_articoli_fraschetti"
              isOneToOne: false
              isSetofReturn: true
            }
          }
      show_limit: { Args: never; Returns: number }
      show_trgm: { Args: { "": string }; Returns: string[] }
      submit_agent_order: {
        Args: {
          _client_request_id: string
          _customer_id: string
          _items: Json
          _note: string
          _total: number
          _visible: boolean
        }
        Returns: {
          auth_user_id: string | null
          client_request_id: string | null
          codice_agente: string | null
          codice_cliente: string | null
          confirmation_email_sent_at: string | null
          created_at: string
          customer_id: string | null
          id: string
          items_fingerprint: string | null
          listino: string | null
          note: string | null
          origine: string | null
          status: string
          total: number
          transmission_id: string
          updated_at: string
          visibile_al_cliente: boolean
        }
        SetofOptions: {
          from: "*"
          to: "customer_orders"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      submit_customer_order: {
        Args: { _items: Json; _note?: string; _total: number }
        Returns: {
          auth_user_id: string | null
          client_request_id: string | null
          codice_agente: string | null
          codice_cliente: string | null
          confirmation_email_sent_at: string | null
          created_at: string
          customer_id: string | null
          id: string
          items_fingerprint: string | null
          listino: string | null
          note: string | null
          origine: string | null
          status: string
          total: number
          transmission_id: string
          updated_at: string
          visibile_al_cliente: boolean
        }
        SetofOptions: {
          from: "*"
          to: "customer_orders"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      sync_adepromo: {
        Args: {
          _error_message?: string
          _log_id: string
          _records_failed?: number
          _rows: Json
        }
        Returns: {
          deleted_count: number
          inserted_count: number
        }[]
      }
      sync_article_inventory: {
        Args: {
          _error_message?: string
          _log_id: string
          _records_failed?: number
          _rows: Json
        }
        Returns: {
          deleted_count: number
          upserted_count: number
        }[]
      }
      sync_media_from_storage: { Args: never; Returns: Json }
      sync_ordcli: {
        Args: {
          _error_message?: string
          _log_id: string
          _records_failed?: number
          _rows: Json
        }
        Returns: {
          deleted_count: number
          inserted_count: number
        }[]
      }
      sync_promo_articoli_from_listini: {
        Args: { p_tipo_blocchi?: string[] }
        Returns: Json
      }
      ticket_category_section: { Args: { _cat: string }; Returns: string }
      track_article_cart: {
        Args: { _cdpar: string; _delta: number; _source?: string }
        Returns: undefined
      }
      track_article_order: {
        Args: { _cdpar: string; _source?: string }
        Returns: undefined
      }
      track_article_view: {
        Args: { _cdpar: string; _source?: string }
        Returns: undefined
      }
      trigger_customer_sync: { Args: never; Returns: undefined }
      truncate_import_table: {
        Args: { target_table: string }
        Returns: undefined
      }
      truncate_listini_vendita_criteri_prezzo: { Args: never; Returns: Json }
      unaccent: { Args: { "": string }; Returns: string }
      update_order_status: {
        Args: { _new_status: string; _order_id: string }
        Returns: {
          auth_user_id: string | null
          client_request_id: string | null
          codice_agente: string | null
          codice_cliente: string | null
          confirmation_email_sent_at: string | null
          created_at: string
          customer_id: string | null
          id: string
          items_fingerprint: string | null
          listino: string | null
          note: string | null
          origine: string | null
          status: string
          total: number
          transmission_id: string
          updated_at: string
          visibile_al_cliente: boolean
        }
        SetofOptions: {
          from: "*"
          to: "customer_orders"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      upsert_fatture_storico: {
        Args: { p_import_run_id: string; p_rows: Json; p_source_file: string }
        Returns: Json
      }
      verify_department_pin: {
        Args: { _department_email: string; _pin_hash: string }
        Returns: {
          full_name: string
          is_valid: boolean
          user_id: string
        }[]
      }
    }
    Enums: {
      access_level: "read" | "write" | "admin"
      app_role:
        | "admin"
        | "manager"
        | "assistant_manager"
        | "collaborator"
        | "viewer"
        | "agent"
        | "customer"
      app_type: "external_url" | "internal_module" | "system"
      attivita_visita: "ORDINE" | "INCASSO" | "RESI" | "ALTRO"
      auth_method: "personal" | "department_pin"
      brand_document_category: "centri_assistenza" | "piu_info"
      carico_merci_status: "in_attesa" | "caricato" | "contestazione" | "chiuso"
      contestazione_status: "aperta" | "in_lavorazione" | "risolta" | "chiusa"
      ddt_status: "bozza" | "emesso" | "spedito" | "annullato"
      entity_type: "department" | "sub_department" | "user"
      icon_type: "lucide" | "custom" | "emoji"
      import_frequency: "daily" | "weekly" | "monthly"
      import_status: "running" | "success" | "error"
      ordine_non_trattato_status:
        | "in_lavorazione"
        | "inviato_acquisti"
        | "preventivo"
      promo_destinatari_article_mode: "all_listino" | "rules" | "manual"
      promo_destinatari_customer_mode: "all" | "rules" | "manual" | "from_as400"
      resi_acquisti_status:
        | "nuovo"
        | "attesa_fornitore"
        | "ddt_emesso"
        | "rispedito"
        | "completato"
        | "annullato"
      resi_status:
        | "nuovo"
        | "in_lavorazione_sc"
        | "attesa_acquisti"
        | "attesa_amministrazione"
        | "rientrato"
        | "rispedito"
        | "completato"
        | "annullato"
      ricambi_status:
        | "nuova"
        | "verifica_disponibilita"
        | "preventivo"
        | "approvata"
        | "evasa"
        | "rifiutata"
      tema_offerta_tipo:
        | "sconto_base"
        | "bundle"
        | "referenza"
        | "scaglioni_qty"
        | "scaglioni_valore"
        | "righe_ordine"
        | "omaggio"
        | "piu_economico"
        | "bancale"
        | "sconto_catalogo"
      tema_omaggio_modalita: "fisso" | "scelta" | "scaglioni"
      tema_omaggio_soglia: "valore" | "pezzi"
      tipo_giorno: "lavorativo" | "riposo"
      untreated_order_status:
        | "in_lavorazione"
        | "inviato_acquisti"
        | "preventivo"
        | "accettato"
        | "rifiutato"
        | "codificato"
        | "ordine_cliente"
        | "ordine_fornitore"
        | "in_arrivo"
        | "arrivato"
        | "chiuso"
        | "nulla"
      workflow_action:
        | "avanza"
        | "annulla"
        | "riapri"
        | "pausa"
        | "riprendi"
        | "nota"
        | "email_inviata"
        | "ddt_generato"
        | "rollback"
        | "blocked"
      workflow_entity_type: "reso_cliente" | "reso_ua" | "richiesta_ricambio"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      access_level: ["read", "write", "admin"],
      app_role: [
        "admin",
        "manager",
        "assistant_manager",
        "collaborator",
        "viewer",
        "agent",
        "customer",
      ],
      app_type: ["external_url", "internal_module", "system"],
      attivita_visita: ["ORDINE", "INCASSO", "RESI", "ALTRO"],
      auth_method: ["personal", "department_pin"],
      brand_document_category: ["centri_assistenza", "piu_info"],
      carico_merci_status: ["in_attesa", "caricato", "contestazione", "chiuso"],
      contestazione_status: ["aperta", "in_lavorazione", "risolta", "chiusa"],
      ddt_status: ["bozza", "emesso", "spedito", "annullato"],
      entity_type: ["department", "sub_department", "user"],
      icon_type: ["lucide", "custom", "emoji"],
      import_frequency: ["daily", "weekly", "monthly"],
      import_status: ["running", "success", "error"],
      ordine_non_trattato_status: [
        "in_lavorazione",
        "inviato_acquisti",
        "preventivo",
      ],
      promo_destinatari_article_mode: ["all_listino", "rules", "manual"],
      promo_destinatari_customer_mode: ["all", "rules", "manual", "from_as400"],
      resi_acquisti_status: [
        "nuovo",
        "attesa_fornitore",
        "ddt_emesso",
        "rispedito",
        "completato",
        "annullato",
      ],
      resi_status: [
        "nuovo",
        "in_lavorazione_sc",
        "attesa_acquisti",
        "attesa_amministrazione",
        "rientrato",
        "rispedito",
        "completato",
        "annullato",
      ],
      ricambi_status: [
        "nuova",
        "verifica_disponibilita",
        "preventivo",
        "approvata",
        "evasa",
        "rifiutata",
      ],
      tema_offerta_tipo: [
        "sconto_base",
        "bundle",
        "referenza",
        "scaglioni_qty",
        "scaglioni_valore",
        "righe_ordine",
        "omaggio",
        "piu_economico",
        "bancale",
        "sconto_catalogo",
      ],
      tema_omaggio_modalita: ["fisso", "scelta", "scaglioni"],
      tema_omaggio_soglia: ["valore", "pezzi"],
      tipo_giorno: ["lavorativo", "riposo"],
      untreated_order_status: [
        "in_lavorazione",
        "inviato_acquisti",
        "preventivo",
        "accettato",
        "rifiutato",
        "codificato",
        "ordine_cliente",
        "ordine_fornitore",
        "in_arrivo",
        "arrivato",
        "chiuso",
        "nulla",
      ],
      workflow_action: [
        "avanza",
        "annulla",
        "riapri",
        "pausa",
        "riprendi",
        "nota",
        "email_inviata",
        "ddt_generato",
        "rollback",
        "blocked",
      ],
      workflow_entity_type: ["reso_cliente", "reso_ua", "richiesta_ricambio"],
    },
  },
} as const

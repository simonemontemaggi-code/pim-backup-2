export type ImportType = "fornitori_buyer_dp" | "articoli_settore_reparto_gamma" | "articoli_brand_pim" | "articoli_cod_padre" | "articoli_scheda_prodotto" | "articoli_master_pack" | "attributi_gamma" | "articoli_attributi_dettaglio";

/** Numero massimo di blocchi attributo (attributo_N/valore_N/obbligatorio_N) supportati nel CSV wide-format. */
export const ATTR_DETTAGLIO_MAX_BLOCKS = 40;

/**
 * Normalizza un cdpar al formato canonico DB:
 *  - trim
 *  - se numerico (max 6 cifre): zero-pad a 6 cifre, poi space-pad a 15 char
 *  - altrimenti: solo space-pad a 15 char
 * Esempio: "1030" -> "001030         " (15 char)
 */
export const normalizeCdpar = (value?: string): string => {
  const raw = (value ?? "").trim();
  if (!raw) return "";
  const padded = /^\d{1,6}$/.test(raw) ? raw.padStart(6, "0") : raw;
  return padded.padEnd(15, " ");
};

/** Versione "compact" di un cdpar (trimmed, zero-padded a 6 se numerico). Utile come chiave logica. */
export const cdparKey = (value?: string): string => normalizeCdpar(value).trim();

/**
 * Normalizza un cdpar al formato "logico" a 6 cifre.
 * - trim
 * - se numerico con ≤6 cifre → zero-pad a sinistra a 6
 * - altrimenti restituisce il valore trimmato (per cdpar non numerici, es. "ART001")
 * Esempio: "1010" → "001010", "  1010 " → "001010", "ART001" → "ART001"
 */
export const pad6Cdpar = (value?: string | null): string => {
  const raw = String(value ?? "").trim();
  if (!raw) return "";
  return /^\d{1,6}$/.test(raw) ? raw.padStart(6, "0") : raw;
};

interface TemplateConfig {
  label: string;
  headers: string[];
  required: string[];
  examples: Record<string, string>[];
  conflictKey: string;
  table: string;
  pimOnly: boolean;
  syncAs400: boolean;
}

export const TEMPLATES: Record<ImportType, TemplateConfig> = {
  fornitori_buyer_dp: {
    label: "Fornitori — Buyer / Demand Planner",
    table: "archivio_fornitori_fraschetti",
    conflictKey: "cdfor",
    required: ["cdfor"],
    headers: ["cdfor", "buyer", "demand_planner"],
    pimOnly: true,
    syncAs400: false,
    examples: [
      { cdfor: "FOR001", buyer: "Mario Rossi", demand_planner: "Luca Bianchi" },
      { cdfor: "FOR002", buyer: "Anna Verdi", demand_planner: "Sara Neri" },
    ],
  },
  articoli_settore_reparto_gamma: {
    label: "Articoli — Settore / Reparto / Gamma",
    table: "archivio_articoli_fraschetti",
    conflictKey: "cdpar",
    required: ["cdpar"],
    headers: ["cdpar", "clmer", "reparto", "gamma"],
    pimOnly: false,
    syncAs400: true,
    examples: [
      { cdpar: "ART001", clmer: "2", reparto: "REP01", gamma: "GAM01" },
      { cdpar: "ART002", clmer: "3", reparto: "", gamma: "" },
      { cdpar: "ART003", clmer: "", reparto: "REP02", gamma: "GAM02" },
    ],
  },
  articoli_brand_pim: {
    label: "Articoli — Brand + Linea Brand (clas2, nmdis, solo PIM)",
    table: "archivio_articoli_fraschetti",
    conflictKey: "cdpar",
    required: ["cdpar"],
    headers: ["cdpar", "clas2", "nmdis"],
    pimOnly: true,
    syncAs400: false,
    examples: [
      { cdpar: "001010", clas2: "FA01", nmdis: "LINEA1" },
      { cdpar: "001020", clas2: "FA02", nmdis: "" },
    ],
  },
  articoli_cod_padre: {
    label: "Articoli — Codici Padri (solo PIM)",
    table: "archivio_articoli_fraschetti",
    conflictKey: "cdpar",
    required: ["cdpar", "cod_padre"],
    headers: ["cdpar", "cod_padre"],
    pimOnly: true,
    syncAs400: false,
    examples: [
      { cdpar: "001010", cod_padre: "000123" },
      { cdpar: "001020", cod_padre: "000123" },
    ],
  },
  articoli_master_pack: {
    label: "Articoli — Confezionamento master (solo PIM)",
    table: "archivio_articoli_fraschetti",
    conflictKey: "cdpar",
    required: ["cdpar", "master_pack"],
    headers: ["cdpar", "master_pack"],
    pimOnly: true,
    syncAs400: false,
    examples: [
      { cdpar: "275100", master_pack: "24" },
      { cdpar: "050410", master_pack: "12" },
    ],
  },
  articoli_scheda_prodotto: {
    label: "Articoli — Scheda Prodotto (Titolo + Descrizione Variante + Descrizione Prodotto)",
    table: "archivio_articoli_fraschetti",
    conflictKey: "cdpar",
    required: ["cdpar"],
    headers: ["cdpar", "titolo_b2b", "descrizione_variante", "descrizione_b2b", "tags"],
    pimOnly: true,
    syncAs400: false,
    examples: [
      { cdpar: "499315", titolo_b2b: "Giratubi modello americano Standard", descrizione_variante: "Lunghezza 250 mm. - 10\"", descrizione_b2b: "Corpo monoblocco in acciaio fuso con testa lucida e impugnatura verniciata", tags: "giratubi|americano|acciaio" },
      { cdpar: "499316", titolo_b2b: "Giratubi modello americano Standard", descrizione_variante: "Lunghezza 300 mm. - 12\"", descrizione_b2b: "Corpo monoblocco in acciaio fuso con testa lucida e impugnatura verniciata", tags: "giratubi|americano|acciaio" },
    ],
  },
  attributi_gamma: {
    label: "Attributi Gamma — Configurazione attributi per gamma (PIM)",
    table: "gamma_attributes",
    conflictKey: "id",
    required: ["gamma", "attributo"],
    headers: ["gamma", "attributo", "display_name", "varianti", "obbligo"],
    pimOnly: true,
    syncAs400: false,
    examples: [
      { gamma: "Arredo Bagno E Idraulica\\Accessori Bagno\\Accessori Bagno Muro e Appoggio", attributo: "tipologia_prodotto", display_name: "Tipologia Prodotto", varianti: "Portaspazzolino|Portasapone|Portasciugamani|Mensola|Scopino", obbligo: "Si" },
      { gamma: "Arredo Bagno E Idraulica\\Accessori Bagno\\Accessori Bagno Muro e Appoggio", attributo: "linea_collezione", display_name: "Linea Collezione", varianti: "IDEA|GIOIA|FACILE|GOLDEN RUST", obbligo: "Si" },
    ],
  },
  articoli_attributi_dettaglio: {
    label: "Articoli — Attributi Dettaglio (valori per SKU) (PIM)",
    table: "archivio_articoli_fraschetti",
    conflictKey: "cdpar",
    required: ["sku"],
    headers: [
      "sku",
      ...Array.from({ length: ATTR_DETTAGLIO_MAX_BLOCKS }, (_, i) => [
        `attributo_${i + 1}`,
        `valore_${i + 1}`,
        `obbligatorio_${i + 1}`,
      ]).flat(),
    ],
    pimOnly: true,
    syncAs400: false,
    examples: [
      {
        sku: "034201",
        attributo_1: "tipologia_prodotto", valore_1: "Portaspazzolino", obbligatorio_1: "Si",
        attributo_2: "linea_collezione", valore_2: "IDEA", obbligatorio_2: "Si",
        attributo_3: "materiale_principale", valore_3: "Acciaio cromato-ABS", obbligatorio_3: "Si",
        attributo_4: "finitura", valore_4: "Cromato", obbligatorio_4: "Si",
        attributo_5: "sistema_fissaggio", valore_5: "Misto (Adesivo+Viti)", obbligatorio_5: "Si",
      },
    ],
  },
};

import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 18 - ARCHIVIO FORNITORI FRASCHETTI".
 *
 * Mapping STRICT per posizione (3 colonne, ordine SELECT AS400):
 *   1 cdfor | 2 rasf2 | 3 rasfo
 *
 * Target: `archivio_fornitori_fraschetti`. La query filtra `ata19 <> 'A'`
 * (esclude annullati): i fornitori NON presenti nel file possono essere
 * marcati come `is_active=false` tramite azione separata.
 * I campi PIM-only `buyer` e `demand_planner` non vengono mai toccati.
 */

export interface Q18Row {
  cdfor: string;
  rasf2: string | null;
  rasfo: string | null;
}

const cleanStr = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

export interface Q18ParseResult {
  headers: string[];
  rows: Q18Row[];
  warnings: string[];
}

export async function parseQuery18Xlsx(file: File): Promise<Q18ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < 3) warnings.push(`Attese 3 colonne, trovate ${headers.length}`);

  const rows: Q18Row[] = [];
  const seen = new Set<string>();
  let skipped = 0;
  let dupes = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const cdfor = cleanStr(r[0]);
    if (cdfor === null) { skipped++; continue; }
    if (seen.has(cdfor)) { dupes++; continue; }
    seen.add(cdfor);
    rows.push({
      cdfor,
      rasf2: cleanStr(r[1]),
      rasfo: cleanStr(r[2]),
    });
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (cdfor mancante)`);
  if (dupes > 0) warnings.push(`${dupes} duplicati su cdfor (tenuta la prima occorrenza)`);
  return { headers, rows, warnings };
}

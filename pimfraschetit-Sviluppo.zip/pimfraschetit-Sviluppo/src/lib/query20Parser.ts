import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 20 - STORICO ASSORTIMENTI (cambi futuri)".
 *
 * SAD_FRAC/WANPAW1L0S — WHERE wdtdec > today.
 * Mapping STRICT per posizione (14 colonne):
 *   1 wchfil | 2 wdtcre | 3 wdtdec | 4 wdtvar | 5 wnofil | 6 wnotei
 *   7 worcre | 8 worvar | 9 wposst | 10 wpospr | 11 wprogr | 12 wstato
 *  13 wutcre | 14 wutvar
 *
 * Target: `storico_assortimenti`. Replace solo righe future (wdtdec > today).
 */

export interface Q20Row {
  wchfil: string | null;
  wdtcre: string | null;
  wdtdec: string | null;
  wdtvar: string | null;
  wnofil: string | null;
  wnotei: string | null;
  worcre: string | null;
  worvar: string | null;
  wposst: string | null;
  wpospr: string | null;
  wprogr: string | null;
  wstato: string | null;
  wutcre: string | null;
  wutvar: string | null;
}

const cleanStr = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  // wchfil is space-padded in AS400 (often 256 chars). Preserve it as-is.
  const s = String(raw);
  return s === "" ? null : s;
};

const cleanTrim = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

export interface Q20ParseResult {
  headers: string[];
  rows: Q20Row[];
  warnings: string[];
}

const EXPECTED = 14;

export async function parseQuery20Xlsx(file: File): Promise<Q20ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < EXPECTED) warnings.push(`Attese ${EXPECTED} colonne, trovate ${headers.length}`);

  const rows: Q20Row[] = [];
  let empty = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    if (r.every((v: any) => v === null || v === undefined || v === "")) { empty++; continue; }
    rows.push({
      wchfil: cleanStr(r[0]),
      wdtcre: cleanTrim(r[1]),
      wdtdec: cleanTrim(r[2]),
      wdtvar: cleanTrim(r[3]),
      wnofil: cleanTrim(r[4]),
      wnotei: cleanStr(r[5]),
      worcre: cleanTrim(r[6]),
      worvar: cleanTrim(r[7]),
      wposst: cleanTrim(r[8]),
      wpospr: cleanTrim(r[9]),
      wprogr: cleanTrim(r[10]),
      wstato: cleanTrim(r[11]),
      wutcre: cleanTrim(r[12]),
      wutvar: cleanTrim(r[13]),
    });
  }
  if (empty > 0) warnings.push(`${empty} righe vuote ignorate`);
  return { headers, rows, warnings };
}

// Parser TXT ordini AS400.
// Controparte di `orderTxtFormat.ts` — stesso layout esatto (47 char per riga).
//
// Layout riga articolo ('A'):
//   [0]      tipo 'A'
//   [1..7)   codice cliente (6 char: cifre zero-pad a 4 + spazi a destra)
//   [7..13)  progressivo (6)
//   [13..19) codice articolo cdpar (6)
//   [19..27) quantità "00000,00" (8)
//   [27..35) prezzo   "00000,00" (8)
//   [35..37) origine "  " | "NE"
//   [37..47) transmission_id / numero ordine (10)
//
// Layout riga nota ('N'):
//   [0]      'N'
//   [1..7)   codice cliente (6)
//   [7..13)  progressivo (6)
//   [13..37) testo nota (24 char, rtrim)
//   [37..47) transmission_id (10)

export interface ParsedOrderLine {
  cdpar: string; // 6 cifre
  qty: number;
  price: number;
  value: number;
}

export interface ParsedOrderNote {
  text: string;
}

export interface ParsedOrder {
  orderNumber: string; // transmission_id, 10 char trimmed
  custCode: string; // cifre, senza spazi
  progressivo: string; // 6 char
  totalValue: number;
  lines: ParsedOrderLine[];
  notes: ParsedOrderNote[];
}

export interface ParseStats {
  totalLines: number;
  articleLines: number;
  noteLines: number;
  orders: number;
  skipped: number;
}

export interface ParseResult {
  orders: ParsedOrder[];
  custCodes: string[];
  stats: ParseStats;
  warnings: string[];
}

const LINE_LEN = 47;

function parseAmount(s: string): number {
  const cleaned = s.replace(/\s/g, "").replace(",", ".");
  if (!cleaned) return 0;
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : 0;
}

export function parseOrderTxt(content: string): ParseResult {
  const stats: ParseStats = {
    totalLines: 0,
    articleLines: 0,
    noteLines: 0,
    orders: 0,
    skipped: 0,
  };
  const warnings: string[] = [];
  const orderMap = new Map<string, ParsedOrder>();
  const custSet = new Set<string>();

  const rawLines = content.split(/\r\n|\n|\r/);

  for (let idx = 0; idx < rawLines.length; idx++) {
    const raw = rawLines[idx];
    if (!raw || raw.trim() === "") continue;
    stats.totalLines++;

    // Il builder produce righe fisse a 47 char. Accettiamo lunghezza >=47
    // (eventuale padding a destra) e scartiamo il resto.
    if (raw.length < LINE_LEN) {
      stats.skipped++;
      warnings.push(`Riga ${idx + 1}: lunghezza ${raw.length} < ${LINE_LEN}, scartata`);
      continue;
    }
    const line = raw.length === LINE_LEN ? raw : raw.slice(0, LINE_LEN);

    const type = line[0];
    if (type !== "A" && type !== "N") {
      stats.skipped++;
      warnings.push(`Riga ${idx + 1}: tipo "${type}" non riconosciuto, scartata`);
      continue;
    }

    const custCode = line.substring(1, 7).trim();
    const progressivo = line.substring(7, 13);
    const orderNumber = line.substring(37, 47).trim();

    if (!orderNumber) {
      stats.skipped++;
      warnings.push(`Riga ${idx + 1}: numero ordine mancante, scartata`);
      continue;
    }

    custSet.add(custCode);

    let order = orderMap.get(orderNumber);
    if (!order) {
      order = {
        orderNumber,
        custCode,
        progressivo,
        totalValue: 0,
        lines: [],
        notes: [],
      };
      orderMap.set(orderNumber, order);
    }

    if (type === "N") {
      stats.noteLines++;
      // Il builder scrive 22 char di testo + 2 di padding (totale 24 in [13..37)).
      // Concatenando i 22 raw ricostruiamo il testo originale.
      const chunk = line.substring(13, 35);
      if (order.notes.length === 0) order.notes.push({ text: chunk });
      else order.notes[0].text += chunk;
      continue;
    }

    // type === 'A'
    stats.articleLines++;
    const cdpar = line.substring(13, 19);
    const qty = parseAmount(line.substring(19, 27));
    const price = parseAmount(line.substring(27, 35));
    const value = qty * price;

    // Dedup: se la stessa cdpar è già presente sommo qty (mantengo il prezzo max).
    const existing = order.lines.find((l) => l.cdpar === cdpar);
    if (existing) {
      existing.qty += qty;
      existing.price = Math.max(existing.price, price);
      existing.value = existing.qty * existing.price;
    } else {
      order.lines.push({ cdpar, qty, price, value });
    }

    order.totalValue = order.lines.reduce((s, l) => s + l.value, 0);
  }

  stats.orders = orderMap.size;

  // Rtrim finale del testo nota (padding di spazi in coda al chunk finale).
  for (const o of orderMap.values()) {
    for (const n of o.notes) n.text = n.text.replace(/\s+$/, "");
  }

  const orders = Array.from(orderMap.values()).sort((a, b) =>
    a.orderNumber.localeCompare(b.orderNumber),
  );

  return {
    orders,
    custCodes: Array.from(custSet),
    stats,
    warnings,
  };
}

import * as XLSX from "xlsx";
import { pad6Cdpar } from "@/lib/csvTemplates";

export interface CatalogoCartaRow {
  cdpar: string;
  catalogo_carta_titolo: string;
  catalogo_carta_dettaglio: string;
  catalogo_carta_scheda: string;
}

export interface CatalogoCartaParseResult {
  headers: string[];
  rows: CatalogoCartaRow[];
  warnings: string[];
}

const MAX_TITOLO = 37;
const MAX_DETTAGLIO = 29;
const MAX_SCHEDA = 340;

export async function parseCatalogoCartaXlsx(file: File): Promise<CatalogoCartaParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rowsRaw = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: "" });
  if (!rowsRaw.length) return { headers: [], rows: [], warnings: ["File vuoto"] };

  const headers = rowsRaw[0].map(String);
  const warnings: string[] = [];
  const seen = new Set<string>();
  const rows: CatalogoCartaRow[] = [];
  let truncCount = 0;
  let dupCount = 0;

  for (let i = 1; i < rowsRaw.length; i++) {
    const r = rowsRaw[i];
    if (!r || r.every((v) => v === "" || v == null)) continue;
    const cdpar = pad6Cdpar(String(r[0] ?? ""));
    if (!cdpar) continue;
    if (seen.has(cdpar)) { dupCount++; continue; }
    seen.add(cdpar);

    let titolo = String(r[1] ?? "").trim();
    let dettaglio = String(r[2] ?? "").trim();
    let scheda = String(r[3] ?? "").trim();

    if (titolo.length > MAX_TITOLO) { titolo = titolo.slice(0, MAX_TITOLO); truncCount++; }
    if (dettaglio.length > MAX_DETTAGLIO) { dettaglio = dettaglio.slice(0, MAX_DETTAGLIO); truncCount++; }
    if (scheda.length > MAX_SCHEDA) { scheda = scheda.slice(0, MAX_SCHEDA); truncCount++; }

    rows.push({
      cdpar,
      catalogo_carta_titolo: titolo,
      catalogo_carta_dettaglio: dettaglio,
      catalogo_carta_scheda: scheda,
    });
  }

  if (truncCount > 0) warnings.push(`${truncCount} valori troncati oltre i limiti (37/29/340)`);
  if (dupCount > 0) warnings.push(`${dupCount} cdpar duplicati ignorati`);

  return { headers, rows, warnings };
}

import { PDFDocument, PDFName } from "pdf-lib";

export interface OptimizeResult {
  blob: Blob;
  sizeOriginal: number;
  sizeStep1: number;
  sizeStep2: number;
  status: "ok" | "warning" | "rejected";
}

const TARGET_BYTES = 1 * 1024 * 1024; // 1 MB
const HARD_LIMIT_BYTES = 5 * 1024 * 1024; // 5 MB

// Step 2 (JPEG re-encode via internal pdf-lib APIs) è disattivato di default:
// le API interne usate non sono stabili e in alcuni PDF corrompono il rendering.
const ENABLE_STEP2 = false;

/**
 * Verifica che `bytes` sia un PDF leggibile con lo stesso numero di pagine dell'originale.
 */
async function isStructurallyValid(bytes: Uint8Array, expectedPages: number): Promise<boolean> {
  try {
    const doc = await PDFDocument.load(bytes, { ignoreEncryption: true, updateMetadata: false });
    return doc.getPageCount() === expectedPages;
  } catch {
    return false;
  }
}

/**
 * Step 1 — lossless: riscrive il PDF con pdf-lib.
 * Conservativo: NON azzera i metadata e usa useObjectStreams=false per minimizzare le modifiche.
 * Salta PDF con AcroForm (form fields / firme) che pdf-lib non preserva in modo affidabile.
 */
async function step1Lossless(bytes: Uint8Array): Promise<Uint8Array> {
  const doc = await PDFDocument.load(bytes, { ignoreEncryption: true, updateMetadata: false });

  // Skip PDF con AcroForm o XFA: pdf-lib può romperli al re-save.
  try {
    const acroForm = doc.catalog.lookup(PDFName.of("AcroForm"));
    if (acroForm) return bytes;
  } catch {
    // ignore
  }

  return doc.save({ useObjectStreams: false, addDefaultPage: false });
}

export async function optimizePdf(file: File): Promise<OptimizeResult> {
  const sizeOriginal = file.size;
  const originalBytes = new Uint8Array(await file.arrayBuffer());

  // Pagina di riferimento per la verifica
  let expectedPages = 0;
  try {
    const refDoc = await PDFDocument.load(originalBytes, { ignoreEncryption: true, updateMetadata: false });
    expectedPages = refDoc.getPageCount();
  } catch {
    // Originale non parsabile: restituiamolo intatto.
    const ab = new ArrayBuffer(originalBytes.byteLength);
    new Uint8Array(ab).set(originalBytes);
    return {
      blob: new Blob([ab], { type: "application/pdf" }),
      sizeOriginal,
      sizeStep1: sizeOriginal,
      sizeStep2: sizeOriginal,
      status: sizeOriginal <= TARGET_BYTES ? "ok" : sizeOriginal <= HARD_LIMIT_BYTES ? "warning" : "rejected",
    };
  }

  // STEP 1
  let step1Bytes: Uint8Array = originalBytes;
  try {
    const candidate = await step1Lossless(originalBytes);
    // Accetta solo se più piccolo E strutturalmente valido
    if (candidate.byteLength < originalBytes.byteLength && await isStructurallyValid(candidate, expectedPages)) {
      step1Bytes = candidate;
    }
  } catch {
    step1Bytes = originalBytes;
  }
  const sizeStep1 = step1Bytes.byteLength;

  // STEP 2 disabilitato
  const finalBytes = step1Bytes;
  const sizeStep2 = sizeStep1;

  const finalSize = finalBytes.byteLength;
  let status: OptimizeResult["status"];
  if (finalSize <= TARGET_BYTES) status = "ok";
  else if (finalSize <= HARD_LIMIT_BYTES) status = "warning";
  else status = "rejected";

  const out = new ArrayBuffer(finalBytes.byteLength);
  new Uint8Array(out).set(finalBytes);
  const blob = new Blob([out], { type: "application/pdf" });

  return { blob, sizeOriginal, sizeStep1, sizeStep2, status };
}

// Esposto per evitare warning su simbolo non usato; in futuro potrà essere reintegrato.
export const __STEP2_ENABLED = ENABLE_STEP2;

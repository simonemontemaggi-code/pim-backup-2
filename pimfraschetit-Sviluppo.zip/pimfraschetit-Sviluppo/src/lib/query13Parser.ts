import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 13 - PROMO STRUTTURATA CAMPAGNE ASSOCIATE".
 *
 * Mapping STRICT per posizione (10 colonne):
 *   1 wpprga | 2 wpprgta | 3 wpprgea | 4 wpcdpaa | 5 wpcdlsa
 *   6 wpcdcva | 7 wpcdcla | 8 wptpbla | 9 wpdtvia | 10 wpdtvfa
 *
 * Target: `promo_strutturate_campagne`.
 * Chiave naturale: (wpprga, wpprgta, wpprgea, wpcdpaa, wpcdlsa, wpcdcva, wpcdcla).
 */

export interface Q13Row {
  wpprga: number;
  wpprgta: number;
  wpprgea: number;
  wpcdpaa: string;
  wpcdlsa: string;
  wpcdcva: string | null;
  wpcdcla: string | null;
  wptpbla: string | null;
  wpdtvia: number | null;
  wpdtvfa: number | null;
}

const cleanKey = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

const padArticle = (raw: any): string | null => {
  const s = cleanKey(raw);
  if (!s) return null;
  return s.padStart(6, "0");
};

const toNum = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const n = typeof raw === "number" ? raw : Number(String(raw).replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

export interface Q13ParseResult {
  headers: string[];
  rows: Q13Row[];
  warnings: string[];
}

export async function parseQuery13Xlsx(file: File): Promise<Q13ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < 10) warnings.push(`Attese 10 colonne, trovate ${headers.length}`);

  const rows: Q13Row[] = [];
  const seen = new Set<string>();
  let skipped = 0;
  let dupes = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const wpprga = toNum(r[0]);
    const wpprgta = toNum(r[1]);
    const wpprgea = toNum(r[2]);
    const wpcdpaa = padArticle(r[3]);
    const wpcdlsa = cleanKey(r[4]);
    if (wpprga === null || wpprgta === null || wpprgea === null || !wpcdpaa || !wpcdlsa) {
      skipped++;
      continue;
    }
    const wpcdcva = cleanKey(r[5]);
    const wpcdcla = cleanKey(r[6]);
    const key = `${wpprga}|${wpprgta}|${wpprgea}|${wpcdpaa}|${wpcdlsa}|${wpcdcva ?? ""}|${wpcdcla ?? ""}`;
    if (seen.has(key)) { dupes++; continue; }
    seen.add(key);
    rows.push({
      wpprga,
      wpprgta,
      wpprgea,
      wpcdpaa,
      wpcdlsa,
      wpcdcva,
      wpcdcla,
      wptpbla: cleanKey(r[7]),
      wpdtvia: toNum(r[8]),
      wpdtvfa: toNum(r[9]),
    });
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (chiave incompleta)`);
  if (dupes > 0) warnings.push(`${dupes} duplicati sulla chiave naturale (tenuta la prima)`);
  return { headers, rows, warnings };
}

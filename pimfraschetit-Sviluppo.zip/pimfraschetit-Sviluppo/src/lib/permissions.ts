import { useAuth } from "@/contexts/AuthContext";
import { SectionKey, ActionKey } from "@/contexts/AuthContext";

type Permission = "hidden" | "read" | "write";
type FieldPermission = "hidden" | "read" | "write" | "inherit";

export function usePermissions() {
  const { permissions, fieldPermissions, actionPermissions, role } = useAuth();

  const getPermission = (section: SectionKey): Permission => {
    if (role === "admin") return "write";
    return (permissions[section] ?? "hidden") as Permission;
  };

  const can = (action: "read" | "write", section: SectionKey): boolean => {
    if (role === "admin") return true;
    const perm = (permissions[section] ?? "hidden") as Permission;
    if (action === "read") return perm === "read" || perm === "write";
    return perm === "write";
  };

  const sectionVisible = (section: SectionKey): boolean => {
    if (role === "admin") return true;
    return (permissions[section] ?? "hidden") !== "hidden";
  };

  const canField = (action: "read" | "write", section: SectionKey, fieldKey: string): boolean => {
    if (role === "admin") return true;
    const fieldPerm = fieldPermissions?.[section]?.[fieldKey] as FieldPermission | undefined;
    if (fieldPerm && fieldPerm !== "inherit") {
      if (action === "read") return fieldPerm === "read" || fieldPerm === "write";
      return fieldPerm === "write";
    }
    return can(action, section);
  };

  const fieldVisible = (section: SectionKey, fieldKey: string): boolean => {
    if (role === "admin") return true;
    const fieldPerm = fieldPermissions?.[section]?.[fieldKey] as FieldPermission | undefined;
    if (fieldPerm && fieldPerm !== "inherit") return fieldPerm !== "hidden";
    return sectionVisible(section);
  };

  /**
   * Action-level permission (create / delete / publish).
   * Default: admin → true; if explicit override exists → use it; else fall back to write.
   */
  const canAction = (section: SectionKey, action: ActionKey): boolean => {
    if (role === "admin") return true;
    const override = actionPermissions?.[section]?.[action];
    if (typeof override === "boolean") return override;
    return can("write", section);
  };

  return { can, sectionVisible, getPermission, canField, fieldVisible, canAction };
}

import { supabase } from "@/integrations/supabase/client";

export interface ResolvedPath {
  rawPath: string;
  parts: string[];
  settoreCode: string | null;
  repartoCode: string | null;
  gammaCode: string | null;
  status: "matched" | "partial" | "unmatched";
}

function norm(s: string): string {
  return s.trim().toLowerCase().replace(/\s+/g, " ");
}

/** Split "Settore\Reparto\Gamma" or "Settore/Reparto/Gamma". */
export function splitGammaPath(raw: string): string[] {
  return (raw ?? "")
    .split(/[\\/]/)
    .map((p) => p.trim())
    .filter(Boolean);
}

export async function resolveGammaPaths(rawPaths: string[]): Promise<Map<string, ResolvedPath>> {
  const unique = Array.from(new Set(rawPaths.filter(Boolean)));

  const { data: lookups, error } = await supabase
    .from("lookup_values")
    .select("category, code, label, parent_category, parent_code")
    .in("category", ["clmer", "reparto", "gamma"])
    .eq("is_active", true);
  if (error) throw error;

  const byCategory: Record<string, { code: string; label: string; parent_code: string | null }[]> = {
    clmer: [], reparto: [], gamma: [],
  };
  (lookups ?? []).forEach((r: any) => {
    if (byCategory[r.category]) {
      byCategory[r.category].push({ code: r.code, label: r.label ?? r.code, parent_code: r.parent_code });
    }
  });

  const findByLabel = (cat: "clmer" | "reparto" | "gamma", label: string, parentCode?: string | null) => {
    const target = norm(label);
    return byCategory[cat].find((v) => {
      if (norm(v.label) !== target && norm(v.code) !== target) return false;
      if (parentCode != null && v.parent_code && v.parent_code !== parentCode) return false;
      return true;
    }) ?? null;
  };

  const result = new Map<string, ResolvedPath>();
  for (const raw of unique) {
    const parts = splitGammaPath(raw);
    // L'ultimo segmento è SEMPRE la gamma, i precedenti sono settore/reparto
    const g = parts[parts.length - 1];
    const r = parts.length >= 2 ? parts[parts.length - 2] : undefined;
    const s = parts.length >= 3 ? parts[parts.length - 3] : undefined;

    // Match gamma direttamente per label/code, indipendente dal parent
    const gamma = g ? findByLabel("gamma", g) : null;
    // Settore/reparto best-effort, senza vincolo parent
    const reparto = r ? findByLabel("reparto", r) : null;
    const settore = s ? findByLabel("clmer", s) : null;

    const matched = !!gamma;
    const partial = !matched && !!(settore || reparto);

    result.set(raw, {
      rawPath: raw,
      parts,
      settoreCode: settore?.code ?? null,
      repartoCode: reparto?.code ?? null,
      gammaCode: gamma?.code ?? null,
      status: matched ? "matched" : partial ? "partial" : "unmatched",
    });
  }
  return result;
}

export function buildAttrLookupCategory(gammaCode: string, attributeName: string): string {
  const safeGamma = gammaCode.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
  const safeAttr = attributeName.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
  return `attr_${safeGamma}_${safeAttr}`;
}

export function parseObbligo(raw: string): boolean {
  const v = (raw ?? "").trim().toLowerCase();
  return v === "si" || v === "sì" || v === "x" || v === "yes" || v === "y" || v === "true" || v === "1";
}

export function parseVarianti(raw: string): string[] {
  return (raw ?? "")
    .split("|")
    .map((v) => v.trim())
    .filter(Boolean);
}

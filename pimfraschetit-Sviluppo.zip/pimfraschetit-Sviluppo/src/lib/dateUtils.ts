/**
 * AS400 stores dates as strings in AAAAMMGG format (e.g. "20260417").
 * These helpers convert between that format and JS Date / display strings.
 */

export function as400DateToJsDate(s: string | null | undefined): Date | null {
  if (!s) return null;
  const trimmed = String(s).trim();
  if (!/^\d{8}$/.test(trimmed)) return null;
  const y = Number(trimmed.slice(0, 4));
  const m = Number(trimmed.slice(4, 6));
  const d = Number(trimmed.slice(6, 8));
  if (!y || !m || !d) return null;
  const dt = new Date(y, m - 1, d);
  return isNaN(dt.getTime()) ? null : dt;
}

export function jsDateToAs400(d: Date): string {
  const y = d.getFullYear().toString().padStart(4, "0");
  const m = (d.getMonth() + 1).toString().padStart(2, "0");
  const day = d.getDate().toString().padStart(2, "0");
  return `${y}${m}${day}`;
}

export function as400DateToDisplay(s: string | null | undefined): string {
  const d = as400DateToJsDate(s);
  if (!d) return "—";
  return d.toLocaleDateString("it-IT");
}

export function todayAs400(): string {
  return jsDateToAs400(new Date());
}

export function todayAs400Date(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

/** AS400 time HHMMSS */
export function nowAs400Time(): string {
  const d = new Date();
  return (
    d.getHours().toString().padStart(2, "0") +
    d.getMinutes().toString().padStart(2, "0") +
    d.getSeconds().toString().padStart(2, "0")
  );
}

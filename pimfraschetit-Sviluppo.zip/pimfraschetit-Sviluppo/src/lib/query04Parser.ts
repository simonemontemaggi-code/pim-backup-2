import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 04 - ARCHIVIO LISTINI FRASCHETTI - CATALOGHI FORNITORI" (v4, 58 colonne).
 *
 * Mapping STRICT per posizione (1-indexed):
 *   1 nrz02 | 2 daz02 | 3 cdcat | 4 cdpar | 5 cdfor | 6 daoff | 7 rifli
 *   8 dtvai | 9 dtvaf | 10 cdval | 11 gioff | 12 catri | 13 notec | 14 avcat
 *   15 cdrcf | 16 usorc
 *   17-22 scaglione 1 | 23-28 sc.2 | 29-34 sc.3 | 35-40 sc.4 | 41-46 sc.5
 *   47 wmasc | 48 wprsc | 49 wscfa | 50 wscfb | 51 wscfc | 52 wscfd | 53 wscfe
 *   54 wctri | 55 wcpfa | 56 wcpfb | 57 wcpfc | 58 wfcas (NEW)
 *
 * Target: `archivio_listini_fraschetti`.
 * Chiave naturale: (cdpar, cdfor, cdcat, dtvai). wcdca viene popolato = cdcat per compat.
 */

export interface Q04Row {
  // chiave
  cdpar: string;
  cdfor: string;
  cdcat: number;
  dtvai: number;
  // anagrafici
  nrz02: number | null;
  daz02: number | null;
  daoff: number | null;
  rifli: string | null;
  dtvaf: number | null;
  cdval: string | null;
  gioff: string | null;
  catri: string | null;
  notec: string | null;
  avcat: string | null;
  cdrcf: string | null;
  usorc: string | null;
  // scaglioni 1..5
  qtsc1: number | null; prsc1: number | null; scfa1: number | null; scfb1: number | null; masc1: number | null; sisc1: number | null;
  qtsc2: number | null; prsc2: number | null; scfa2: number | null; scfb2: number | null; masc2: number | null; sisc2: number | null;
  qtsc3: number | null; prsc3: number | null; scfa3: number | null; scfb3: number | null; masc3: number | null; sisc3: number | null;
  qtsc4: number | null; prsc4: number | null; scfa4: number | null; scfb4: number | null; masc4: number | null; sisc4: number | null;
  qtsc5: number | null; prsc5: number | null; scfa5: number | null; scfb5: number | null; masc5: number | null; sisc5: number | null;
  // calcolati WANCTW0F
  wmasc: number | null;
  wprsc: number | null;
  wscfa: number | null;
  wscfb: number | null;
  wscfc: number | null;
  wscfd: number | null;
  wscfe: number | null;
  wctri: number | null;
  wcpfa: number | null;
  wcpfb: number | null;
  wcpfc: number | null;
  wfcas: number | null;
}

const cleanText = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};
const cleanKey = cleanText;
const cleanNumber = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const n = typeof raw === "number" ? raw : parseFloat(String(raw).replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

export interface Q04ParseResult {
  headers: string[];
  rows: Q04Row[];
  warnings: string[];
}

export async function parseQuery04Xlsx(file: File): Promise<Q04ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < 58) warnings.push(`Attese 58 colonne, trovate ${headers.length}`);

  const rows: Q04Row[] = [];
  let skipped = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const cdpar = cleanKey(r[3]);
    const cdfor = cleanKey(r[4]);
    const cdcat = cleanNumber(r[2]);
    const dtvai = cleanNumber(r[7]);
    if (!cdpar || !cdfor || cdcat === null || dtvai === null) { skipped++; continue; }
    rows.push({
      cdpar, cdfor, cdcat, dtvai,
      nrz02: cleanNumber(r[0]),
      daz02: cleanNumber(r[1]),
      daoff: cleanNumber(r[5]),
      rifli: cleanText(r[6]),
      dtvaf: cleanNumber(r[8]),
      cdval: cleanText(r[9]),
      gioff: cleanText(r[10]),
      catri: cleanText(r[11]),
      notec: cleanText(r[12]),
      avcat: cleanText(r[13]),
      cdrcf: cleanText(r[14]),
      usorc: cleanText(r[15]),
      qtsc1: cleanNumber(r[16]), prsc1: cleanNumber(r[17]), scfa1: cleanNumber(r[18]), scfb1: cleanNumber(r[19]), masc1: cleanNumber(r[20]), sisc1: cleanNumber(r[21]),
      qtsc2: cleanNumber(r[22]), prsc2: cleanNumber(r[23]), scfa2: cleanNumber(r[24]), scfb2: cleanNumber(r[25]), masc2: cleanNumber(r[26]), sisc2: cleanNumber(r[27]),
      qtsc3: cleanNumber(r[28]), prsc3: cleanNumber(r[29]), scfa3: cleanNumber(r[30]), scfb3: cleanNumber(r[31]), masc3: cleanNumber(r[32]), sisc3: cleanNumber(r[33]),
      qtsc4: cleanNumber(r[34]), prsc4: cleanNumber(r[35]), scfa4: cleanNumber(r[36]), scfb4: cleanNumber(r[37]), masc4: cleanNumber(r[38]), sisc4: cleanNumber(r[39]),
      qtsc5: cleanNumber(r[40]), prsc5: cleanNumber(r[41]), scfa5: cleanNumber(r[42]), scfb5: cleanNumber(r[43]), masc5: cleanNumber(r[44]), sisc5: cleanNumber(r[45]),
      wmasc: cleanNumber(r[46]),
      wprsc: cleanNumber(r[47]),
      wscfa: cleanNumber(r[48]),
      wscfb: cleanNumber(r[49]),
      wscfc: cleanNumber(r[50]),
      wscfd: cleanNumber(r[51]),
      wscfe: cleanNumber(r[52]),
      wctri: cleanNumber(r[53]),
      wcpfa: cleanNumber(r[54]),
      wcpfb: cleanNumber(r[55]),
      wcpfc: cleanNumber(r[56]),
      wfcas: cleanNumber(r[57]),
    });
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (chiave incompleta: cdpar/cdfor/cdcat/dtvai)`);
  return { headers, rows, warnings };
}

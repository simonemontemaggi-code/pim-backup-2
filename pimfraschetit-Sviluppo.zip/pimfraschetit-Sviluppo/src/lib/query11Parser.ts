import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 11 - LISTINI DI VENDITA TESTATE".
 *
 * Mapping STRICT per posizione (6 colonne):
 *   1 cdlst | 2 cdcvt | 3 cdclt | 4 cambt | 5 cdvat | 6 tcamt
 *
 * Target: `listini_vendita_testate`.
 * Chiave naturale: (cdlst, cdcvt, cdclt). Update di cambt/cdvat/tcamt.
 */

export interface Q11Row {
  cdlst: string;
  cdcvt: string | null;
  cdclt: string | null;
  cambt: string | null;
  cdvat: string | null;
  tcamt: string | null;
}

const cleanKey = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

export interface Q11ParseResult {
  headers: string[];
  rows: Q11Row[];
  warnings: string[];
}

export async function parseQuery11Xlsx(file: File): Promise<Q11ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < 6) warnings.push(`Attese 6 colonne, trovate ${headers.length}`);

  const rows: Q11Row[] = [];
  const seen = new Set<string>();
  let skipped = 0;
  let dupes = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const cdlst = cleanKey(r[0]);
    const cdcvt = cleanKey(r[1]);
    const cdclt = cleanKey(r[2]);
    const cambt = cleanKey(r[3]);
    const cdvat = cleanKey(r[4]);
    const tcamt = cleanKey(r[5]);
    if (!cdlst) { skipped++; continue; }
    const key = `${cdlst}|${cdcvt ?? ""}|${cdclt ?? ""}`;
    if (seen.has(key)) { dupes++; continue; }
    seen.add(key);
    rows.push({ cdlst, cdcvt, cdclt, cambt, cdvat, tcamt });
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (cdlst mancante)`);
  if (dupes > 0) warnings.push(`${dupes} duplicati nella chiave (cdlst,cdcvt,cdclt)`);
  return { headers, rows, warnings };
}

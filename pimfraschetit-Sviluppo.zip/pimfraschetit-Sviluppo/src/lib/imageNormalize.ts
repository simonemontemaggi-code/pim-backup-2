// Normalizza un'immagine cropandola (center-crop) e ridimensionandola alle
// dimensioni target. Default 800×450 (ratio 16:9) — è ciò che il Portale Agenti
// si aspetta per cover e photo slider delle News.
export async function normalizeImageToBlob(
  file: File,
  targetW = 800,
  targetH = 450,
  quality = 0.9,
): Promise<Blob> {
  if (!file.type.startsWith("image/")) {
    throw new Error("Il file non è un'immagine");
  }
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = () => rej(new Error("Impossibile leggere l'immagine"));
      i.src = url;
    });
    const srcRatio = img.width / img.height;
    const dstRatio = targetW / targetH;
    let sx = 0, sy = 0, sw = img.width, sh = img.height;
    if (srcRatio > dstRatio) {
      // troppo larga → crop laterale
      sw = img.height * dstRatio;
      sx = (img.width - sw) / 2;
    } else if (srcRatio < dstRatio) {
      // troppo alta → crop verticale
      sh = img.width / dstRatio;
      sy = (img.height - sh) / 2;
    }
    const canvas = document.createElement("canvas");
    canvas.width = targetW;
    canvas.height = targetH;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas non disponibile");
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(img, sx, sy, sw, sh, 0, 0, targetW, targetH);
    return await new Promise<Blob>((res, rej) => {
      canvas.toBlob(
        (b) => (b ? res(b) : rej(new Error("Errore conversione immagine"))),
        "image/jpeg",
        quality,
      );
    });
  } finally {
    URL.revokeObjectURL(url);
  }
}

const YT = /^(https?:\/\/)?(www\.)?(youtube\.com\/watch\?v=[\w-]+|youtu\.be\/[\w-]+)/i;
const VIMEO = /^(https?:\/\/)?(www\.)?vimeo\.com\/\d+/i;
const MP4 = /^https?:\/\/.+\.mp4(\?.*)?$/i;

export type VideoKind = "youtube" | "vimeo" | "mp4" | null;

export function detectVideoKind(url: string): VideoKind {
  if (!url) return null;
  if (YT.test(url)) return "youtube";
  if (VIMEO.test(url)) return "vimeo";
  if (MP4.test(url)) return "mp4";
  return null;
}

export function toEmbedUrl(url: string): string | null {
  const kind = detectVideoKind(url);
  if (!kind) return null;
  if (kind === "youtube") {
    let id = "";
    const m1 = url.match(/youtube\.com\/watch\?v=([\w-]+)/i);
    const m2 = url.match(/youtu\.be\/([\w-]+)/i);
    id = m1?.[1] || m2?.[1] || "";
    return id ? `https://www.youtube.com/embed/${id}` : null;
  }
  if (kind === "vimeo") {
    const m = url.match(/vimeo\.com\/(\d+)/i);
    return m ? `https://player.vimeo.com/video/${m[1]}` : null;
  }
  return url; // mp4 diretto
}

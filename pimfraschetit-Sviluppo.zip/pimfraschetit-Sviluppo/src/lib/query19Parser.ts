import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 19 - LISTINI DI VENDITA CONDIZIONI".
 *
 * Mapping STRICT per posizione (22 colonne, SAD_FRAC/WANLTW0F):
 *   1 wsm01 | 2 wsm02 | 3 wcdls | 4 wsm03 | 5 wcdcv
 *   6 wcdcl | 7 wcdfo | 8 wcdst | 9 wclme | 10 wclve
 *  11 wcacq | 12 wcbve | 13 wcmri | 14 wddlw | 15 wgenl
 *  16 wline | 17 wmova | 18 wrccv | 19 wrccl | 20 wrcls
 *  21 wsmim | 22 wvdim
 *
 * Target: `listini_vendita_condizioni`. Snapshot full-replace (no natural key
 * unico nel modello AS400 → reset totale + reinsert).
 */

export interface Q19Row {
  wsm01: number | null;
  wsm02: number | null;
  wcdls: string | null;
  wsm03: number | null;
  wcdcv: string | null;
  wcdcl: string | null;
  wcdfo: string | null;
  wcdst: string | null;
  wclme: string | null;
  wclve: string | null;
  wcacq: string | null;
  wcbve: string | null;
  wcmri: string | null;
  wddlw: string | null;
  wgenl: string | null;
  wline: string | null;
  wmova: string | null;
  wrccv: string | null;
  wrccl: string | null;
  wrcls: string | null;
  wsmim: string | null;
  wvdim: string | null;
}

const cleanStr = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

const toNum = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const n = typeof raw === "number" ? raw : Number(String(raw).replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

export interface Q19ParseResult {
  headers: string[];
  rows: Q19Row[];
  warnings: string[];
}

const EXPECTED = 22;

export async function parseQuery19Xlsx(file: File): Promise<Q19ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < EXPECTED) warnings.push(`Attese ${EXPECTED} colonne, trovate ${headers.length}`);

  const rows: Q19Row[] = [];
  let empty = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    if (r.every((v: any) => v === null || v === undefined || v === "")) { empty++; continue; }
    rows.push({
      wsm01: toNum(r[0]),
      wsm02: toNum(r[1]),
      wcdls: cleanStr(r[2]),
      wsm03: toNum(r[3]),
      wcdcv: cleanStr(r[4]),
      wcdcl: cleanStr(r[5]),
      wcdfo: cleanStr(r[6]),
      wcdst: cleanStr(r[7]),
      wclme: cleanStr(r[8]),
      wclve: cleanStr(r[9]),
      wcacq: cleanStr(r[10]),
      wcbve: cleanStr(r[11]),
      wcmri: cleanStr(r[12]),
      wddlw: cleanStr(r[13]),
      wgenl: cleanStr(r[14]),
      wline: cleanStr(r[15]),
      wmova: cleanStr(r[16]),
      wrccv: cleanStr(r[17]),
      wrccl: cleanStr(r[18]),
      wrcls: cleanStr(r[19]),
      wsmim: cleanStr(r[20]),
      wvdim: cleanStr(r[21]),
    });
  }
  if (empty > 0) warnings.push(`${empty} righe vuote ignorate`);
  return { headers, rows, warnings };
}

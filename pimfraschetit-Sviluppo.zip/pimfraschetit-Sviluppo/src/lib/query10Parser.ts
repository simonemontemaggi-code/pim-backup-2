import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 10 - LISTINI VENDITA DETTAGLI".
 *
 * L'export AS400 può avere 2 forme:
 *   - 8  colonne (vecchia): D.ult.manut., Cd Ls, Codice articolo, N s c, QTSCL_P, UM, Data val min, PRMIL
 *   - 11 colonne (nuova):   Azione, D.ult.manut., Cd Ls, Cd ca ve, Client, Codice articolo, N s c, QTSCL_P, UM, Data val min, PRMIL
 *
 * Per essere robusti il mapping è fatto PER NOME HEADER (case/spazi insensitive),
 * non per posizione fissa.
 *
 * Chiave naturale: (cdlsl, cdcvl, cdcll, cdarl, nrscl) — le colonne mancanti diventano null.
 */

export interface Q10Row {
  nra21: string | null;
  daa21: string | null;
  cdlsl: string;
  cdcvl: string | null;
  cdcll: string | null;
  cdarl: string;
  nrscl: string | null;
  qtscl: number | null;
  unmsl: string | null;
  dtmil: string | null;
  prmil: number | null;
}

export interface Q10ParseResult {
  headers: string[];
  rows: Q10Row[];
  warnings: string[];
}

const cleanKey = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

const padArticle = (raw: any): string | null => {
  const s = cleanKey(raw);
  if (!s) return null;
  return s.padStart(6, "0");
};

const toNum = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const n = typeof raw === "number" ? raw : Number(String(raw).replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

/** Data AS400: accetta numero (20170131 / 20170131.0) o stringa, ritorna "20170131". */
const toAs400Date = (raw: any): string | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  if (typeof raw === "number") {
    if (!Number.isFinite(raw)) return null;
    return String(Math.trunc(raw));
  }
  const s = String(raw).trim();
  if (!s) return null;
  const digits = s.replace(/[^0-9]/g, "");
  return digits.length >= 8 ? digits.slice(0, 8) : digits || null;
};

/** Normalizza un header: minuscolo, no spazi/punti/trattini. */
const normHeader = (h: any): string =>
  String(h ?? "").toLowerCase().replace(/[\s._\-]+/g, "");

/** Sinonimi noti per ogni campo target (tutti già normalizzati con normHeader). */
const HEADER_ALIASES: Record<keyof Q10Row, string[]> = {
  nra21:  ["nra21", "azione"],                          // colonna "Azione" → la teniamo come hint
  daa21:  ["daa21", "dultmanut", "dataultmanut"],
  cdlsl:  ["cdlsl", "cdls"],
  cdcvl:  ["cdcvl", "cdcave"],
  cdcll:  ["cdcll", "client", "cliente"],
  cdarl:  ["cdarl", "codicearticolo", "codarticolo"],
  nrscl:  ["nrscl", "nsc"],
  qtscl:  ["qtscl", "qtsclp"],
  unmsl:  ["unmsl", "um"],
  dtmil:  ["dtmil", "datavalmin", "prezzodatamin"],
  prmil:  ["prmil", "prezzo"],
};

function buildColumnMap(headers: any[]): Partial<Record<keyof Q10Row, number>> {
  const map: Partial<Record<keyof Q10Row, number>> = {};
  const normHeaders = headers.map(normHeader);
  (Object.keys(HEADER_ALIASES) as (keyof Q10Row)[]).forEach((field) => {
    const aliases = HEADER_ALIASES[field];
    for (let i = 0; i < normHeaders.length; i++) {
      if (aliases.includes(normHeaders[i])) {
        map[field] = i;
        return;
      }
    }
  });
  return map;
}

export async function parseQuery10Xlsx(file: File): Promise<Q10ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) =>
    h === null || h === undefined ? "" : String(h),
  );
  const colMap = buildColumnMap(headers);
  const warnings: string[] = [];

  // Verifica colonne essenziali
  const required: (keyof Q10Row)[] = ["cdlsl", "cdarl", "prmil"];
  const missing = required.filter((k) => colMap[k] === undefined);
  if (missing.length) {
    warnings.push(`Colonne essenziali mancanti: ${missing.join(", ")} (header: ${headers.join(" | ")})`);
  }

  const get = (row: any[], field: keyof Q10Row): any => {
    const idx = colMap[field];
    return idx === undefined ? null : row[idx];
  };

  const rows: Q10Row[] = [];
  const seen = new Set<string>();
  let skipped = 0;
  let dupes = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const cdlsl = cleanKey(get(r, "cdlsl"));
    const cdarl = padArticle(get(r, "cdarl"));
    if (!cdlsl || !cdarl) {
      skipped++;
      continue;
    }
    const cdcvl = cleanKey(get(r, "cdcvl"));
    const cdcll = cleanKey(get(r, "cdcll"));
    const nrscl = cleanKey(get(r, "nrscl"));
    const key = `${cdlsl}|${cdcvl ?? ""}|${cdcll ?? ""}|${cdarl}|${nrscl ?? ""}`;
    if (seen.has(key)) {
      dupes++;
      continue;
    }
    seen.add(key);
    rows.push({
      nra21: cleanKey(get(r, "nra21")),
      daa21: toAs400Date(get(r, "daa21")),
      cdlsl,
      cdcvl,
      cdcll,
      cdarl,
      nrscl,
      qtscl: toNum(get(r, "qtscl")),
      unmsl: cleanKey(get(r, "unmsl")),
      dtmil: toAs400Date(get(r, "dtmil")),
      prmil: toNum(get(r, "prmil")),
    });
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (cdlsl/cdarl mancanti)`);
  if (dupes > 0) warnings.push(`${dupes} duplicati nella chiave naturale (tenuta la prima occorrenza)`);
  return { headers, rows, warnings };
}

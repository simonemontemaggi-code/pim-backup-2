import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 07 - LISTINI DI VENDITA CAMPAGNE" (versione 19 colonne).
 *
 * Mapping STRICT per posizione, identico all'ordine della SELECT AS400:
 *   1  wcdls      Cod. List.
 *   2  wcdcv      COD. CAT.VEN.
 *   3  wcdcl      COD. CLIENTE
 *   4  wcdpa      Cod.articolo
 *   5  wnrsc      N.sca LIST.
 *   6  wdtvi      DATA INIZ.BLOCCO
 *   7  wdtvf      DATA FINE BLOCCO
 *   8  wprun      PRZ.IMP.
 *   9  wprui      PRZ.IVATO
 *   10 wtpbl      Codice Campagna
 *   11 wqtxm      Qta M
 *   12 wqtxn      Qta N
 *   13 wcpam      Cod.Art. Omagg.
 *   14 wscon      PERC. SCONTO
 *   15 wqtms      Qta Min.sc.
 *   16 wsimp      Sc. Imp.
 *   17 wnpun      N° Punti
 *   18 writac     WRITAC
 *   19 wriatc     WRIATC
 *
 * Target: `listini_vendita_campagne`.
 * Chiave naturale: (wcdpa, wcdls, wcdcv, wcdcl, wnrsc, wdtvi, wdtvf).
 */

export interface Q07Row {
  wcdls: string;
  wcdcv: string | null;
  wcdcl: string | null;
  wcdpa: string;
  wnrsc: string | null;
  wdtvi: string;
  wdtvf: string;
  wprun: number | null;
  wprui: number | null;
  wtpbl: string | null;
  wqtxm: number | null;
  wqtxn: number | null;
  wcpam: string | null;
  wscon: number | null;
  wqtms: number | null;
  wsimp: string | null;
  wnpun: string | null;
  writac: string | null;
  wriatc: string | null;
}

const cleanText = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

const padArticle = (raw: any): string | null => {
  const s = cleanText(raw);
  if (!s) return null;
  // Pad numerico a 6 cifre, lascia inalterati i cdpar non numerici
  return /^\d{1,6}$/.test(s) ? s.padStart(6, "0") : s;
};

const toNum = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  if (typeof raw === "number") return Number.isFinite(raw) ? raw : null;
  const s = String(raw).trim().replace(/\s/g, "").replace(",", ".");
  if (!s) return null;
  const n = parseFloat(s);
  return Number.isFinite(n) ? n : null;
};

export interface Q07ParseResult {
  headers: string[];
  rows: Q07Row[];
  warnings: string[];
}

const EXPECTED_COLS = 19;

export async function parseQuery07Xlsx(file: File): Promise<Q07ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) =>
    h === null || h === undefined ? "" : String(h),
  );
  const warnings: string[] = [];
  if (headers.length < EXPECTED_COLS) {
    warnings.push(`Attese ${EXPECTED_COLS} colonne, trovate ${headers.length}`);
  }

  const rows: Q07Row[] = [];
  let skipped = 0;
  let dupes = 0;
  const seen = new Set<string>();

  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const wcdls = cleanText(r[0]);
    const wcdcv = cleanText(r[1]);
    const wcdcl = cleanText(r[2]);
    const wcdpa = padArticle(r[3]);
    const wnrsc = cleanText(r[4]);
    const wdtvi = cleanText(r[5]);
    const wdtvf = cleanText(r[6]);

    if (!wcdpa || !wcdls || !wdtvi || !wdtvf) {
      skipped++;
      continue;
    }

    const key = `${wcdpa}|${wcdls}|${wcdcv ?? ""}|${wcdcl ?? ""}|${wnrsc ?? ""}|${wdtvi}|${wdtvf}`;
    if (seen.has(key)) {
      dupes++;
      continue;
    }
    seen.add(key);

    rows.push({
      wcdls,
      wcdcv,
      wcdcl,
      wcdpa,
      wnrsc,
      wdtvi,
      wdtvf,
      wprun: toNum(r[7]),
      wprui: toNum(r[8]),
      wtpbl: cleanText(r[9]),
      wqtxm: toNum(r[10]),
      wqtxn: toNum(r[11]),
      wcpam: cleanText(r[12]),
      wscon: toNum(r[13]),
      wqtms: toNum(r[14]),
      wsimp: cleanText(r[15]),
      wnpun: cleanText(r[16]),
      writac: cleanText(r[17]),
      wriatc: cleanText(r[18]),
    });
  }

  if (skipped > 0) warnings.push(`${skipped} righe scartate (chiavi mancanti)`);
  if (dupes > 0) warnings.push(`${dupes} duplicati nella chiave naturale (tenuta la prima occorrenza)`);
  return { headers, rows, warnings };
}

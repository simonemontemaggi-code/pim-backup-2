/**
 * AS400 export helper.
 * Builds a structured JSON payload for AS400 sync and triggers a download.
 *
 * Format:
 * {
 *   "user": "user@example.com",
 *   "tables": {
 *     "<table_name>": [
 *       {
 *         "operation": "update" | "insert" | "delete",
 *         "key": { ... primary/lookup key columns ... },
 *         "fields": { ... only changed/inserted columns ... }
 *       }
 *     ]
 *   }
 * }
 *
 * Use `buildAs400Payload` to compose, then `downloadAs400Json` to save.
 * For convenience, `exportAs400Change` does both in one call when there is a single change.
 */

export type As400Operation = "insert" | "update" | "delete";

export interface As400TableChange {
  operation: As400Operation;
  key: Record<string, any>;
  fields?: Record<string, any>;
}

export interface As400Payload {
  user?: string | null;
  tables: Record<string, As400TableChange[]>;
}

/**
 * PIM-only fields that must NEVER be sent to AS400.
 * These are columns added by the PIM layer (metadata, SEO, B2B, sync flags, audit).
 */
const PIM_ONLY_FIELDS = new Set<string>([
  // Generic / system
  "id",
  "created_at",
  "updated_at",
  "updated_by",
  "fts",
  // Sync metadata
  "as400_sync_status",
  // PIM enrichment (articles)
  "attributes",
  "tags",
  "b2b_product_title",
  "b2b_product_description",
  "seo_title",
  "seo_description",
  "description_marketing",
  "description_ecommerce",
  // Linea Brand: gestita solo dal PIM, non sincronizzata su AS400
  "nmdis",
  // Promo Strutturate: gestione lato PIM, non esiste su AS400
  "excluded_listini",
  // Logistica B2B PIM-only
  "master_pack",
  // Cataloghi Cartacei PIM-only
  "catalogo_carta_titolo",
  "catalogo_carta_dettaglio",
  "catalogo_carta_scheda",
]);

/**
 * Strip PIM-only fields from a key/fields object before sending to AS400.
 */
function stripPimFields(obj: Record<string, any> | undefined): Record<string, any> | undefined {
  if (!obj) return obj;
  const out: Record<string, any> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (!PIM_ONLY_FIELDS.has(k)) out[k] = v;
  }
  return out;
}

/** Trim leading zeros from AS400-style padded codes (e.g. "0000000273050" → "273050"). */
function trimAs400Code(val: any): any {
  if (typeof val !== "string") return val;
  const trimmed = val.replace(/^0+/, "");
  return trimmed === "" ? "0" : trimmed;
}

/** Columns containing AS400 article/supplier codes that should be displayed unpadded in the export. */
const CODE_FIELDS = new Set<string>(["cdpar", "wcdpa", "cdarl", "cdfor", "wcdca"]);

/** Apply trim to AS400 code fields inside a key/fields object. */
function normalizeCodes(obj: Record<string, any> | undefined): Record<string, any> | undefined {
  if (!obj) return obj;
  const out: Record<string, any> = {};
  for (const [k, v] of Object.entries(obj)) {
    out[k] = CODE_FIELDS.has(k) ? trimAs400Code(v) : v;
  }
  return out;
}

function sanitizeChange(change: As400TableChange): As400TableChange | null {
  const fields = normalizeCodes(stripPimFields(change.fields));
  const key = normalizeCodes(stripPimFields(change.key)) ?? {};
  // For update/insert: if no real AS400 fields remain, skip the change
  if ((change.operation === "update" || change.operation === "insert") && (!fields || Object.keys(fields).length === 0)) {
    return null;
  }
  return { ...change, key, fields };
}

export function buildAs400Payload(opts: {
  user?: string | null;
  record?: string | null;
  changes: { table: string; change: As400TableChange }[];
}): As400Payload {
  const tables: Record<string, As400TableChange[]> = {};
  for (const { table, change } of opts.changes) {
    const sanitized = sanitizeChange(change);
    if (!sanitized) continue;
    if (!tables[table]) tables[table] = [];
    tables[table].push(sanitized);
  }
  return {
    user: opts.user ?? null,
    tables,
  };
}

/** `record` is used only to name the downloaded file, it is not part of the JSON. */
export function downloadAs400Json(payload: As400Payload, filenamePrefix = "as400", record?: string | null) {
  if (typeof window === "undefined") return;
  if (!payload.tables || Object.keys(payload.tables).length === 0) return;
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const recordPart = record ? `_${trimAs400Code(record)}` : "";
  a.href = url;
  a.download = `${filenamePrefix}${recordPart}_${stamp}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Convenience: build + download in one call for a single-table change.
 */
export function exportAs400Change(opts: {
  user?: string | null;
  record?: string | null;
  table: string;
  change: As400TableChange;
  filenamePrefix?: string;
}) {
  const payload = buildAs400Payload({
    user: opts.user,
    changes: [{ table: opts.table, change: opts.change }],
  });
  downloadAs400Json(payload, opts.filenamePrefix ?? "as400", opts.record);
  return payload;
}

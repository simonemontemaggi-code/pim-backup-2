import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 01 - ARCHIVIO ARTICOLI FRASCHETTI" (versione estesa, 124 colonne).
 *
 * Mapping STRICT per posizione (header AS400 ingannevoli).
 * Colonna #3 (depar||wdeag) viene SKIPPATA: dato ridondante.
 */

export interface Q01Row {
  cdpar: string;
  // 1-19 (originali, col #3 saltata)
  clmer: string | null; wvvii: string | null; clas2: string | null; barcd: string | null;
  pcfor: string | null; clas1: string | null; depar: string | null; wfc2x: number | null;
  lipro: string | null; nmdis: string | null; umalt: string | null; unmis: string | null;
  cdiva: string | null; wcdst: string | null; cdst1: string | null;
  daa26: string | null; dtstr: string | null; wdeag: string | null;
  // 20+ nuovi
  wfuas: string | null; cdrga: string | null; wdset: string | null; wstag: string | null;
  clapp: string | null; wclve: string | null; cdpaf: string | null; nmcat: string | null;
  escam: string | null; recfl: string | null; agcic: string | null; flglo: string | null;
  nocod: string | null; flscr: string | null; evadi: string | null; crevd: string | null;
  wsezi: string | null; wsovr: string | null; wacau: string | null; wsqvs: string | null;
  wcpgm: string | null; wgkit: string | null; wesrc: string | null; wpocc: string | null;
  wfitt: string | null; wnsts: string | null; wartoma: string | null; wtrac: string | null;
  untec: string | null; unmi2: string | null;
  umfat: number | null; umfaa: number | null; umfa2: number | null;
  unpes: string | null; pesun: number | null;
  wimba: string | null; wumsp: string | null; tpimb: string | null; mespc: string | null;
  wcpad: string | null; wniva: string | null; wnprv: string | null;
  cdst2: string | null; cdst3: string | null;
  tppra: string | null; tpprb: string | null; tpprc: string | null;
  pcter: string | null; ptpap: string | null;
  preup: number | null; preupe: number | null; prlot: number | null;
  qmnpl: number | null; qmxpl: number | null; qarpl: number | null;
  cfcal: number | null; qprop: number | null;
  wperspa: string | null;
  crrio: string | null; crimp: string | null; crtpr: string | null; mgimp: string | null;
  indgc: string | null; cprop: string | null; crimt: string | null;
  prvoc: string | null; vocos: string | null; cenco: string | null;
  prvor: string | null; vocor: string | null; ceric: string | null;
  prefa: string | null; vospa: string | null; cecoa: string | null; ccndi: string | null;
  conem: string | null; conac: string | null;
  wfcvr: string | null;
  wfcs1: number | null; wfc1s: number | null; wvqtm: number | null;
  wvviq: string | null; wvtai: string | null; wpzne: string | null;
  dvrif: string | null; wumrf: string | null;
  tprod: number | null; trevo: number | null; tecop: number | null;
  nprop: number | null; gprop: number | null; ptefo: number | null;
  cmltc: number | null; tprov: number | null; tproe: number | null;
  livmn: number | null; nrcom: number | null; nrass: number | null;
  nrope: number | null; hlvmn: number | null;
  dtcic: string | null; dtltc: string | null; dtac5: string | null;
  wfuaspr: number | null;
}

const padCdpar = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  if (!s) return null;
  return s.padEnd(15, " ");
};

const cleanText = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

const cleanNumber = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const n = typeof raw === "number" ? raw : Number(String(raw).replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

const cleanInt = (raw: any): number | null => {
  const n = cleanNumber(raw);
  return n === null ? null : Math.trunc(n);
};

/** AS400 YYYYMMDD numeric → "YYYY-MM-DD" (0 / vuoto → null). */
const cleanAs400Date = (raw: any): string | null => {
  if (raw === null || raw === undefined || raw === "" || raw === 0 || raw === "0") return null;
  const s = String(typeof raw === "number" ? Math.trunc(raw) : raw).trim();
  if (!/^\d{8}$/.test(s)) return null;
  const y = s.slice(0, 4), m = s.slice(4, 6), d = s.slice(6, 8);
  if (y === "0000" || m === "00" || d === "00") return null;
  return `${y}-${m}-${d}`;
};

export interface Q01ParseResult {
  headers: string[];
  rows: Q01Row[];
  warnings: string[];
}

export const Q01_PREVIEW_COLS = [
  "cdpar","clmer","wfuas","depar","wdeag","wvvii","clas1","clas2","barcd",
  "pcfor","cdpaf","cdiva","unmis","umalt","preup","daa26","dtstr","dtcic","dtac5",
] as const;

export async function parseQuery01Xlsx(file: File): Promise<Q01ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < 124) warnings.push(`Attese 124 colonne, trovate ${headers.length}`);

  const rows: Q01Row[] = [];
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const cdpar = padCdpar(r[0]);
    if (!cdpar) continue;
    rows.push({
      cdpar,
      clmer: cleanText(r[1]),
      // r[2] skip (depar||wdeag)
      wvvii: cleanText(r[3]),
      clas2: cleanText(r[4]),
      barcd: cleanText(r[5]),
      pcfor: cleanText(r[6]),
      clas1: cleanText(r[7]),
      depar: cleanText(r[8]),
      wfc2x: cleanNumber(r[9]),
      lipro: cleanText(r[10]),
      nmdis: cleanText(r[11]),
      umalt: cleanText(r[12]),
      unmis: cleanText(r[13]),
      cdiva: cleanText(r[14]),
      wcdst: cleanText(r[15]),
      cdst1: cleanText(r[16]),
      daa26: cleanAs400Date(r[17]),
      dtstr: cleanAs400Date(r[18]),
      wdeag: cleanText(r[19]),
      wfuas: cleanText(r[20]),
      cdrga: cleanText(r[21]),
      wdset: cleanText(r[22]),
      wstag: cleanText(r[23]),
      clapp: cleanText(r[24]),
      wclve: cleanText(r[25]),
      cdpaf: cleanText(r[26]),
      nmcat: cleanText(r[27]),
      escam: cleanText(r[28]),
      recfl: cleanText(r[29]),
      agcic: cleanText(r[30]),
      flglo: cleanText(r[31]),
      nocod: cleanText(r[32]),
      flscr: cleanText(r[33]),
      evadi: cleanText(r[34]),
      crevd: cleanText(r[35]),
      wsezi: cleanText(r[36]),
      wsovr: cleanText(r[37]),
      wacau: cleanText(r[38]),
      wsqvs: cleanText(r[39]),
      wcpgm: cleanText(r[40]),
      wgkit: cleanText(r[41]),
      wesrc: cleanText(r[42]),
      wpocc: cleanText(r[43]),
      wfitt: cleanText(r[44]),
      wnsts: cleanText(r[45]),
      wartoma: cleanText(r[46]),
      wtrac: cleanText(r[47]),
      untec: cleanText(r[48]),
      unmi2: cleanText(r[49]),
      umfat: cleanNumber(r[50]),
      umfaa: cleanNumber(r[51]),
      umfa2: cleanNumber(r[52]),
      unpes: cleanText(r[53]),
      pesun: cleanNumber(r[54]),
      wimba: cleanText(r[55]),
      wumsp: cleanText(r[56]),
      tpimb: cleanText(r[57]),
      mespc: cleanText(r[58]),
      wcpad: cleanText(r[59]),
      wniva: cleanText(r[60]),
      wnprv: cleanText(r[61]),
      cdst2: cleanText(r[62]),
      cdst3: cleanText(r[63]),
      tppra: cleanText(r[64]),
      tpprb: cleanText(r[65]),
      tpprc: cleanText(r[66]),
      pcter: cleanText(r[67]),
      ptpap: cleanText(r[68]),
      preup: cleanNumber(r[69]),
      preupe: cleanNumber(r[70]),
      prlot: cleanNumber(r[71]),
      qmnpl: cleanNumber(r[72]),
      qmxpl: cleanNumber(r[73]),
      qarpl: cleanNumber(r[74]),
      cfcal: cleanNumber(r[75]),
      qprop: cleanNumber(r[76]),
      wperspa: cleanText(r[77]),
      crrio: cleanText(r[78]),
      crimp: cleanText(r[79]),
      crtpr: cleanText(r[80]),
      mgimp: cleanText(r[81]),
      indgc: cleanText(r[82]),
      cprop: cleanText(r[83]),
      crimt: cleanText(r[84]),
      prvoc: cleanText(r[85]),
      vocos: cleanText(r[86]),
      cenco: cleanText(r[87]),
      prvor: cleanText(r[88]),
      vocor: cleanText(r[89]),
      ceric: cleanText(r[90]),
      prefa: cleanText(r[91]),
      vospa: cleanText(r[92]),
      cecoa: cleanText(r[93]),
      ccndi: cleanText(r[94]),
      conem: cleanText(r[95]),
      conac: cleanText(r[96]),
      wfcvr: cleanText(r[97]),
      wfcs1: cleanNumber(r[98]),
      wfc1s: cleanNumber(r[99]),
      wvqtm: cleanNumber(r[100]),
      wvviq: cleanText(r[101]),
      wvtai: cleanText(r[102]),
      wpzne: cleanText(r[103]),
      dvrif: cleanText(r[104]),
      wumrf: cleanText(r[105]),
      tprod: cleanInt(r[106]),
      trevo: cleanInt(r[107]),
      tecop: cleanInt(r[108]),
      nprop: cleanInt(r[109]),
      gprop: cleanInt(r[110]),
      ptefo: cleanInt(r[111]),
      cmltc: cleanInt(r[112]),
      tprov: cleanInt(r[113]),
      tproe: cleanInt(r[114]),
      livmn: cleanInt(r[115]),
      nrcom: cleanInt(r[116]),
      nrass: cleanInt(r[117]),
      nrope: cleanInt(r[118]),
      hlvmn: cleanInt(r[119]),
      dtcic: cleanAs400Date(r[120]),
      dtltc: cleanAs400Date(r[121]),
      dtac5: cleanAs400Date(r[122]),
      wfuaspr: cleanNumber(r[123]),
    });
  }
  return { headers, rows, warnings };
}

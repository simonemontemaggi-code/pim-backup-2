import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 05 - DIFFERENZIALE CAMBIO" (v2, 66 colonne).
 *
 * Mapping STRICT per posizione (1-indexed):
 *   1 wan02 | 2 wcdfo | 3 wcacq
 *   4 wscfa | 5 wscfb | 6 wscfc | 7 wscfd | 8 wscfe
 *   9 wmasc | 10 wsisc | 11 wctri | 12 wctrp | 13 wsocp
 *   14 wdacq | 15 wfoca | 16 wltpr
 *   17 wviqm | 18 wviim | 19 wtaim | 20 wqtde | 21 wumso
 *   22 wsisce | 23 wctrie | 24 wcdva
 *   25-34 wscf1..wscf0 (numeric)
 *   35-44 wcaf1..wcaf0 (text)
 *   45-54 wicf1..wicf0 (text)
 *   55-64 wbcf1..wbcf0 (text)
 *   65 wdtvai | 66 wdtvaf
 *
 * Target: `differenziale_cambio` (filtro wcacq = '§DC').
 * Chiave naturale: wcdfo (una sola riga §DC per fornitore).
 */

const SCF_KEYS = ["wscf1","wscf2","wscf3","wscf4","wscf5","wscf6","wscf7","wscf8","wscf9","wscf0"] as const;
const CAF_KEYS = ["wcaf1","wcaf2","wcaf3","wcaf4","wcaf5","wcaf6","wcaf7","wcaf8","wcaf9","wcaf0"] as const;
const ICF_KEYS = ["wicf1","wicf2","wicf3","wicf4","wicf5","wicf6","wicf7","wicf8","wicf9","wicf0"] as const;
const BCF_KEYS = ["wbcf1","wbcf2","wbcf3","wbcf4","wbcf5","wbcf6","wbcf7","wbcf8","wbcf9","wbcf0"] as const;

export type Q05Row = {
  wan02: string | null;
  wcdfo: string;
  wcacq: string | null;
  wscfa: number | null; wscfb: number | null; wscfc: number | null; wscfd: number | null; wscfe: number | null;
  wmasc: number | null; wsisc: number | null; wctri: number | null; wctrp: number | null;
  wsocp: string | null;
  wdacq: string | null; wfoca: string | null; wltpr: string | null;
  wviqm: string | null; wviim: string | null; wtaim: string | null; wqtde: string | null; wumso: string | null;
  wsisce: number | null; wctrie: number | null;
  wcdva: string | null;
  wdtvai: string | null; wdtvaf: string | null;
} & { [K in typeof SCF_KEYS[number]]: number | null }
  & { [K in typeof CAF_KEYS[number]]: string | null }
  & { [K in typeof ICF_KEYS[number]]: string | null }
  & { [K in typeof BCF_KEYS[number]]: string | null };

const cleanText = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};
const cleanNumber = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const n = typeof raw === "number" ? raw : parseFloat(String(raw).replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

export interface Q05ParseResult {
  headers: string[];
  rows: Q05Row[];
  warnings: string[];
}

export async function parseQuery05Xlsx(file: File): Promise<Q05ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < 66) warnings.push(`Attese 66 colonne, trovate ${headers.length}`);

  const rows: Q05Row[] = [];
  let skipped = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const wcdfo = cleanText(r[1]);
    if (!wcdfo) { skipped++; continue; }

    const row: any = {
      wan02: cleanText(r[0]),
      wcdfo,
      wcacq: cleanText(r[2]),
      wscfa: cleanNumber(r[3]), wscfb: cleanNumber(r[4]), wscfc: cleanNumber(r[5]), wscfd: cleanNumber(r[6]), wscfe: cleanNumber(r[7]),
      wmasc: cleanNumber(r[8]), wsisc: cleanNumber(r[9]), wctri: cleanNumber(r[10]), wctrp: cleanNumber(r[11]),
      wsocp: cleanText(r[12]),
      wdacq: cleanText(r[13]), wfoca: cleanText(r[14]), wltpr: cleanText(r[15]),
      wviqm: cleanText(r[16]), wviim: cleanText(r[17]), wtaim: cleanText(r[18]), wqtde: cleanText(r[19]), wumso: cleanText(r[20]),
      wsisce: cleanNumber(r[21]), wctrie: cleanNumber(r[22]),
      wcdva: cleanText(r[23]),
      wdtvai: cleanText(r[64]),
      wdtvaf: cleanText(r[65]),
    };
    SCF_KEYS.forEach((k, idx) => { row[k] = cleanNumber(r[24 + idx]); });
    CAF_KEYS.forEach((k, idx) => { row[k] = cleanText(r[34 + idx]); });
    ICF_KEYS.forEach((k, idx) => { row[k] = cleanText(r[44 + idx]); });
    BCF_KEYS.forEach((k, idx) => { row[k] = cleanText(r[54 + idx]); });
    rows.push(row as Q05Row);
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (wcdfo mancante)`);
  return { headers, rows, warnings };
}

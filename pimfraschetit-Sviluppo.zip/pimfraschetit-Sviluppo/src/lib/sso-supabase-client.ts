// SSO token manager — stores tokens passed via URL by the Fraschetti hub
// Keys are shared with the hub spec: sso_access_token, sso_user, sso_profile, sso_role, sso_permissions

const TOKEN_KEY = "sso_access_token";
const USER_KEY = "sso_user";
const PROFILE_KEY = "sso_profile";
const ROLE_KEY = "sso_role";
const PERMS_KEY = "sso_permissions";

export interface SSOUser {
  id: string;
  email: string;
}

export interface SSOProfile {
  user_id: string;
  full_name: string | null;
  avatar_url: string | null;
  [k: string]: unknown;
}

export type SSORole = "admin" | "manager" | "collaborator" | "viewer";

export interface SSOPermissions {
  access_level: SSORole;
  ui_permission_config: Record<string, unknown>;
}

export const ssoTokenManager = {
  getToken(): string | null {
    try {
      const t = localStorage.getItem(TOKEN_KEY);
      if (!t) return null;
      if (isTokenExpired(t)) {
        ssoTokenManager.clear();
        return null;
      }
      return t;
    } catch {
      return null;
    }
  },
  setToken(token: string) {
    localStorage.setItem(TOKEN_KEY, token);
  },
  getUser(): SSOUser | null {
    const raw = localStorage.getItem(USER_KEY);
    return raw ? JSON.parse(raw) : null;
  },
  setUser(user: SSOUser) {
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  },
  getProfile(): SSOProfile | null {
    const raw = localStorage.getItem(PROFILE_KEY);
    return raw ? JSON.parse(raw) : null;
  },
  setProfile(profile: SSOProfile | null) {
    if (profile) localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
    else localStorage.removeItem(PROFILE_KEY);
  },
  getRole(): SSORole | null {
    return (localStorage.getItem(ROLE_KEY) as SSORole | null) ?? null;
  },
  setRole(role: SSORole) {
    localStorage.setItem(ROLE_KEY, role);
  },
  getPermissions(): SSOPermissions | null {
    const raw = localStorage.getItem(PERMS_KEY);
    return raw ? JSON.parse(raw) : null;
  },
  setPermissions(perms: SSOPermissions) {
    localStorage.setItem(PERMS_KEY, JSON.stringify(perms));
  },
  clear() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    localStorage.removeItem(PROFILE_KEY);
    localStorage.removeItem(ROLE_KEY);
    localStorage.removeItem(PERMS_KEY);
  },
  hasSession(): boolean {
    return !!ssoTokenManager.getToken();
  },
};

export function isTokenExpired(jwt: string): boolean {
  try {
    const payload = JSON.parse(atob(jwt.split(".")[1]));
    if (!payload.exp) return false;
    // 30s skew
    return Date.now() / 1000 >= payload.exp - 30;
  } catch {
    return true;
  }
}

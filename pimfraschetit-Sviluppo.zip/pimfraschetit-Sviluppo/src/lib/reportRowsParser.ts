import * as XLSX from "xlsx";

export interface ParsedGrid {
  headers: string[];
  rows: string[][];
  warnings: string[];
}

function cleanCell(v: unknown): string {
  if (v === null || v === undefined) return "";
  if (typeof v === "number") return String(v);
  return String(v).trim();
}

function fromMatrix(matrix: unknown[][]): ParsedGrid {
  const warnings: string[] = [];
  const nonEmpty = matrix.filter((r) => Array.isArray(r) && r.some((c) => cleanCell(c) !== ""));
  if (nonEmpty.length === 0) return { headers: [], rows: [], warnings: ["File vuoto"] };

  const headers = nonEmpty[0].map((c, i) => cleanCell(c) || `Colonna ${i + 1}`);
  const rows: string[][] = [];
  for (let i = 1; i < nonEmpty.length; i++) {
    const r = nonEmpty[i];
    const row: string[] = [];
    for (let c = 0; c < headers.length; c++) row.push(cleanCell(r[c]));
    rows.push(row);
  }
  if (rows.length === 0) warnings.push("Nessuna riga dati dopo l'intestazione");
  return { headers, rows, warnings };
}

/** Testo delimitato da tabulazione (TXT AS400 o incolla da Excel). */
export function parseDelimitedText(text: string): ParsedGrid {
  const lines = text.replace(/\r\n?/g, "\n").split("\n");
  const useTab = lines.some((l) => l.includes("\t"));
  const matrix = lines.map((l) => (useTab ? l.split("\t") : l.split(";")));
  return fromMatrix(matrix);
}

/** File .xlsx / .xls — prima riga = intestazioni. */
export async function parseXlsxGrid(file: File): Promise<ParsedGrid> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<unknown[]>(ws, { header: 1, defval: "" });
  return fromMatrix(matrix);
}

/** File .txt tabulato. */
export async function parseTxtGrid(file: File): Promise<ParsedGrid> {
  return parseDelimitedText(await file.text());
}

export async function parseReportFile(file: File): Promise<ParsedGrid> {
  const name = file.name.toLowerCase();
  if (name.endsWith(".xlsx") || name.endsWith(".xls")) return parseXlsxGrid(file);
  return parseTxtGrid(file);
}

/** Chiave tecnica stabile per una colonna, derivata dall'etichetta. */
export function toColumnKey(label: string, index: number): string {
  const slug = label
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
  return slug || `col_${index + 1}`;
}

/** Formatta un valore per la visualizzazione, con eventuale suffisso. */
export function formatReportValue(value: unknown, suffix?: string | null): string {
  const raw = value === null || value === undefined ? "" : String(value);
  if (!raw) return "";
  return suffix ? `${raw} ${suffix}` : raw;
}

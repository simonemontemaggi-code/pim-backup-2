import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 15 - PROMO STRUTTURATE ELEMENTI".
 *
 * Mapping STRICT per posizione (25 colonne, SAD_FRAC/WPSVE00F):
 *   1 wpstate | 2 wprogre | 3 wpprge | 4 wpseqe | 5 wpprgte
 *   6 wpccae  | 7 wpdesce | 8 wpcaine | 9 wpcadte | 10 wppreoe
 *  11 wprarte | 12 wprfore | 13 wprclme | 14 wprline | 15 wprclve
 *  16 wprasse | 17 wprstge | 18 wprcl1e | 19 wprcl2e | 20 wprcl3e
 *  21 wprcl4e | 22 wprcl5e | 23 wqpreoe | 24 wumorde | 25 wpandor
 *
 * Target: `promo_strutturate_elementi`. Differenziale su chiave naturale wprogre.
 */

export interface Q15Row {
  wpstate: string | null;
  wprogre: number;
  wpprge: number | null;
  wpseqe: number | null;
  wpprgte: number | null;
  wpccae: string | null;
  wpdesce: string | null;
  wpcaine: string | null;
  wpcadte: string | null;
  wppreoe: string | null;
  wprarte: string | null;
  wprfore: string | null;
  wprclme: string | null;
  wprline: string | null;
  wprclve: string | null;
  wprasse: string | null;
  wprstge: string | null;
  wprcl1e: string | null;
  wprcl2e: string | null;
  wprcl3e: string | null;
  wprcl4e: string | null;
  wprcl5e: string | null;
  wqpreoe: number | null;
  wumorde: string | null;
  wpandor: string | null;
}

const cleanText = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

const toNum = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const n = typeof raw === "number" ? raw : Number(String(raw).replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

export interface Q15ParseResult {
  headers: string[];
  rows: Q15Row[];
  warnings: string[];
}

const EXPECTED = 25;

export async function parseQuery15Xlsx(file: File): Promise<Q15ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < EXPECTED) warnings.push(`Attese ${EXPECTED} colonne, trovate ${headers.length}`);

  const rows: Q15Row[] = [];
  const seen = new Set<number>();
  let skipped = 0;
  let dupes = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const wprogre = toNum(r[1]);
    if (wprogre === null) { skipped++; continue; }
    if (seen.has(wprogre)) { dupes++; continue; }
    seen.add(wprogre);
    rows.push({
      wpstate: cleanText(r[0]),
      wprogre,
      wpprge: toNum(r[2]),
      wpseqe: toNum(r[3]),
      wpprgte: toNum(r[4]),
      wpccae: cleanText(r[5]),
      wpdesce: cleanText(r[6]),
      wpcaine: cleanText(r[7]),
      wpcadte: cleanText(r[8]),
      wppreoe: cleanText(r[9]),
      wprarte: cleanText(r[10]),
      wprfore: cleanText(r[11]),
      wprclme: cleanText(r[12]),
      wprline: cleanText(r[13]),
      wprclve: cleanText(r[14]),
      wprasse: cleanText(r[15]),
      wprstge: cleanText(r[16]),
      wprcl1e: cleanText(r[17]),
      wprcl2e: cleanText(r[18]),
      wprcl3e: cleanText(r[19]),
      wprcl4e: cleanText(r[20]),
      wprcl5e: cleanText(r[21]),
      wqpreoe: toNum(r[22]),
      wumorde: cleanText(r[23]),
      wpandor: cleanText(r[24]),
    });
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (wprogre mancante)`);
  if (dupes > 0) warnings.push(`${dupes} duplicati wprogre scartati`);
  return { headers, rows, warnings };
}

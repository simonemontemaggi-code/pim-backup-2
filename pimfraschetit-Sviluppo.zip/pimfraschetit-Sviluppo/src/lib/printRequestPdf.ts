import type { CustomerRequest } from "@/hooks/useCustomerRequests";
import type { SelfOnboardingRequest } from "@/hooks/useSelfOnboardingRequests";

const esc = (v: unknown) => {
  if (v === null || v === undefined || String(v).trim() === "") return "—";
  return String(v)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
};

const fmtDate = (iso: string | null | undefined) => {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString("it-IT", { dateStyle: "medium", timeStyle: "short" });
  } catch {
    return String(iso);
  }
};

const STATUS_LABEL_CR: Record<string, string> = {
  pending: "In attesa",
  approved: "Confermata",
  rejected: "Respinta",
};
const STATUS_LABEL_SO: Record<string, string> = {
  new: "In attesa",
  pending: "In attesa",
  reviewing: "In revisione",
  approved: "Approvata",
  rejected: "Respinta",
};

const baseStyles = `
  @page { size: A4; margin: 15mm; }
  * { box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; color: #1a1a1a; margin: 0; font-size: 11pt; line-height: 1.35; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 10px; margin-bottom: 16px; }
  .brand { font-size: 18pt; font-weight: 700; color: #0f172a; letter-spacing: -0.5px; }
  .brand small { display: block; font-size: 9pt; font-weight: 500; color: #64748b; margin-top: 2px; letter-spacing: 0; }
  .status { font-size: 10pt; font-weight: 600; padding: 4px 10px; border-radius: 999px; border: 1px solid #cbd5e1; background: #f1f5f9; color: #0f172a; }
  .status.warning { background: #fef3c7; border-color: #fcd34d; color: #92400e; }
  .status.success { background: #dcfce7; border-color: #86efac; color: #14532d; }
  .status.danger  { background: #fee2e2; border-color: #fca5a5; color: #7f1d1d; }
  .status.info    { background: #dbeafe; border-color: #93c5fd; color: #1e3a8a; }
  .meta { font-size: 9pt; color: #64748b; margin-bottom: 18px; }
  h1 { font-size: 15pt; margin: 0 0 12px 0; color: #0f172a; }
  h2 { font-size: 11pt; margin: 18px 0 6px 0; color: #0f172a; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #e2e8f0; padding-bottom: 3px; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px 20px; padding: 6px 0; }
  .field { break-inside: avoid; }
  .field .label { font-size: 8pt; text-transform: uppercase; color: #64748b; letter-spacing: 0.4px; font-weight: 600; }
  .field .value { font-size: 10.5pt; color: #0f172a; word-break: break-word; white-space: pre-wrap; }
  .full { grid-column: 1 / -1; }
  .badges { display: flex; flex-wrap: wrap; gap: 6px; padding: 6px 0; }
  .badge { font-size: 9pt; padding: 3px 10px; border-radius: 999px; border: 1px solid #cbd5e1; background: #f8fafc; color: #475569; }
  .badge.ok { background: #dcfce7; border-color: #86efac; color: #14532d; }
  .footer { position: fixed; bottom: 8mm; left: 15mm; right: 15mm; font-size: 8pt; color: #94a3b8; display: flex; justify-content: space-between; border-top: 1px solid #e2e8f0; padding-top: 4px; }
  @media print { .noprint { display: none !important; } }
`;

function statusClass(status: string): string {
  if (status === "approved") return "success";
  if (status === "rejected") return "danger";
  if (status === "reviewing") return "info";
  return "warning";
}

function field(label: string, value: unknown, full = false): string {
  return `<div class="field${full ? " full" : ""}"><div class="label">${esc(label)}</div><div class="value">${esc(value)}</div></div>`;
}

function openPrintWindow(title: string, bodyHtml: string) {
  const win = window.open("", "_blank");
  if (!win) {
    // Popup blocker
    // eslint-disable-next-line no-alert
    alert("Il browser ha bloccato la finestra di stampa. Abilita i popup per questo sito.");
    return;
  }
  const now = new Date().toLocaleString("it-IT", { dateStyle: "medium", timeStyle: "short" });
  win.document.open();
  win.document.write(`<!DOCTYPE html><html lang="it"><head><meta charset="utf-8"><title>${esc(title)}</title><style>${baseStyles}</style></head><body>${bodyHtml}<div class="footer"><span>Stampato il ${esc(now)}</span><span>Fraschetti PIM</span></div><script>window.addEventListener('load',()=>{setTimeout(()=>{window.focus();window.print();},250);});<\/script></body></html>`);
  win.document.close();
}

export function printCustomerRequest(r: CustomerRequest) {
  const statusLabel = STATUS_LABEL_CR[r.status] ?? r.status;
  const sc = statusClass(r.status);
  const inviata = fmtDate(r.created_at);
  const daAgente = r.agent_name ?? r.agent_code ?? "—";

  const sezioni: string[] = [];

  sezioni.push(`<h2>Anagrafica</h2><div class="grid">
    ${field("Ragione Sociale", r.ragione_sociale, true)}
    ${field("P.IVA", r.partita_iva)}
    ${field("Codice Fiscale", r.codice_fiscale)}
    ${field("Categoria", r.categoria)}
  </div>`);

  sezioni.push(`<h2>Indirizzo</h2><div class="grid">
    ${field("Indirizzo", r.indirizzo, true)}
    ${field("CAP", r.cap)}
    ${field("Città", r.citta)}
    ${field("Provincia", r.provincia)}
    ${field("Zona", r.zona)}
    ${field("Diversa destinazione", r.diversa_destinazione, true)}
  </div>`);

  sezioni.push(`<h2>Contatti &amp; Referente</h2><div class="grid">
    ${field("Telefono Negozio", r.telefono_negozio)}
    ${field("Email", r.email)}
    ${field("PEC", r.pec)}
    ${field("Codice SDI", r.codice_sdi)}
    ${field("Nome Referente", r.nome_referente)}
    ${field("Cellulare Referente", r.cellulare_referente)}
  </div>`);

  sezioni.push(`<h2>Informazioni Commerciali</h2><div class="grid">
    ${field("Importanza", r.importanza)}
    ${field("Giorno Visita", r.giorno_visita)}
    ${field("Frequenza Visite", r.frequenza_visite)}
    ${field("Giorno Chiusura", r.giorno_chiusura)}
    ${field("Grossisti Concorrenti", r.grossisti_concorrenti, true)}
    ${field("Fornitori Presenti", r.fornitori_presenti, true)}
    ${field("Vendite Online", r.vendite_online)}
    ${field("Presenza PC", r.presenza_pc)}
    ${field("Note Scarico", r.note_scarico, true)}
    ${field("Note Varie", r.note_varie, true)}
  </div>`);

  sezioni.push(`<h2>Pagamento &amp; Bancari</h2><div class="grid">
    ${field("Modalità Pagamento", r.modalita_pagamento)}
    ${field("Modalità (altro)", r.modalita_altro)}
    ${field("Descrizione Pagamento", r.descrizione_pagamento, true)}
    ${field("Banca", r.banca)}
    ${field("Filiale", r.filiale)}
    ${field("IBAN", r.iban, true)}
  </div>`);

  sezioni.push(`<h2>Agente</h2><div class="grid">
    ${field("Nome", r.agent_name)}
    ${field("Codice Agente", r.agent_code)}
    ${field("Email", r.agent_email, true)}
  </div>`);

  if (r.status !== "pending") {
    const esitoRows: string[] = [
      field("Gestita il", fmtDate(r.reviewed_at)),
      field("Gestita da", r.reviewed_by),
    ];
    if (r.status === "approved") {
      esitoRows.push(field("Codice Cliente assegnato", r.assigned_customer_code));
      esitoRows.push(field("Zona assegnata", r.assigned_zona));
      esitoRows.push(field("Note interne", r.review_notes, true));
    } else {
      esitoRows.push(field("Motivazione", r.rejection_reason, true));
    }
    sezioni.push(`<h2>Esito</h2><div class="grid">${esitoRows.join("")}</div>`);
  }

  const body = `
    <div class="header">
      <div class="brand">FRASCHETTI<small>Richiesta codifica cliente</small></div>
      <div class="status ${sc}">${esc(statusLabel)}</div>
    </div>
    <h1>${esc(r.ragione_sociale ?? "Senza nome")}</h1>
    <div class="meta">Inviata il ${esc(inviata)} · da ${esc(daAgente)} · ID ${esc(r.id)}</div>
    ${sezioni.join("")}
  `;
  openPrintWindow(`Richiesta ${r.ragione_sociale ?? r.id}`, body);
}

export function printSelfOnboardingRequest(r: SelfOnboardingRequest) {
  const statusLabel = STATUS_LABEL_SO[r.status as string] ?? String(r.status);
  const sc = statusClass(r.status as string);
  const inviata = fmtDate(r.created_at);
  const telefono = r.telefono ? `${r.prefisso_internazionale ?? ""} ${r.telefono}`.trim() : null;
  const referente = [r.nome, r.cognome].filter(Boolean).join(" ") || null;

  const consensi = [
    { label: "Privacy Policy", ok: !!r.consenso_privacy },
    { label: "Condizioni di Vendita", ok: !!r.consenso_termini },
    { label: "Clausole restrittive", ok: !!r.consenso_clausole },
    { label: "Newsletter", ok: !!r.marketing_newsletter },
    { label: "SMS", ok: !!r.marketing_sms },
  ]
    .map((c) => `<span class="badge ${c.ok ? "ok" : ""}">${c.ok ? "✓" : "✗"} ${esc(c.label)}</span>`)
    .join("");

  const sezioni: string[] = [];

  sezioni.push(`<h2>Azienda</h2><div class="grid">
    ${field("Ragione Sociale", r.ragione_sociale, true)}
    ${field("P.IVA", r.partita_iva)}
    ${field("Email aziendale", r.email_aziendale)}
    ${field("Telefono", telefono)}
    ${field("PEC", r.pec)}
    ${field("SDI", r.sdi)}
    ${field("Tipologia", r.tipologia)}
    ${field("Settore rivenditore", r.settore_rivenditore)}
    ${field("Tipo (altro)", r.tipo_altro)}
    ${field("Descrizione attività", r.descrizione_attivita, true)}
    ${r.codice_ateco ? field("Codice ATECO", `${r.codice_ateco}${r.descrizione_ateco ? " — " + r.descrizione_ateco : ""}`, true) : ""}
  </div>`);

  sezioni.push(`<h2>Referente</h2><div class="grid">
    ${field("Nome e Cognome", referente, true)}
  </div>`);

  sezioni.push(`<h2>Indirizzo</h2><div class="grid">
    ${field("Indirizzo", r.indirizzo, true)}
    ${field("Città", r.citta)}
    ${field("Provincia", r.provincia)}
    ${field("CAP", r.cap)}
  </div>`);

  sezioni.push(`<h2>Consensi</h2><div class="badges">${consensi}</div>`);

  if (r.notes_admin) {
    sezioni.push(`<h2>Note admin</h2><div class="grid">${field("Note", r.notes_admin, true)}</div>`);
  }

  const isPending = r.status === "pending" || (r.status as string) === "new";
  if (!isPending) {
    sezioni.push(`<h2>Esito</h2><div class="grid">
      ${field("Gestita il", fmtDate(r.processed_at))}
      ${field("Gestita da", r.processed_by)}
    </div>`);
  }

  const body = `
    <div class="header">
      <div class="brand">FRASCHETTI<small>Auto-registrazione B2B</small></div>
      <div class="status ${sc}">${esc(statusLabel)}</div>
    </div>
    <h1>${esc(r.ragione_sociale ?? "Senza nome")}</h1>
    <div class="meta">Inviata il ${esc(inviata)} · ID ${esc(r.id)}</div>
    ${sezioni.join("")}
  `;
  openPrintWindow(`Auto-richiesta ${r.ragione_sociale ?? r.id}`, body);
}

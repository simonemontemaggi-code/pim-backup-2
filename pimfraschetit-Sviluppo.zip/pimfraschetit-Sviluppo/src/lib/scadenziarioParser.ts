export interface ParsedScadRow {
  customer_code: string;
  customer_name: string;
  reg_prot: string;
  reg_data: string | null;
  causal: string;
  payment_desc: string;
  doc_number: string;
  doc_date: string | null;
  due_date: string | null;
  currency: string;
  contanti: number;
  effetti: number;
  totale: number;
}

export interface ParsedScadResult {
  agentCode: string;
  rows: ParsedScadRow[];
}

function parseAmount(s: string): number {
  if (!s) return 0;
  const neg = s.endsWith("-");
  const clean = (neg ? s.slice(0, -1) : s).replace(/\./g, "").replace(",", ".");
  const n = parseFloat(clean);
  if (isNaN(n)) return 0;
  return neg ? -n : n;
}

function parseDate(s: string | null | undefined): string | null {
  if (!s) return null;
  const m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2})$/);
  if (!m) return null;
  const dd = parseInt(m[1], 10);
  const mm = parseInt(m[2], 10);
  const yy = parseInt(m[3], 10);
  if (dd === 0 || mm === 0) return null;
  const yyyy = yy < 60 ? 2000 + yy : 1900 + yy;
  return `${yyyy}-${String(mm).padStart(2, "0")}-${String(dd).padStart(2, "0")}`;
}

// Map descrizione testuale -> codice causale breve (per filtri/leggibilità)
export const CAUSAL_MAP: Array<{ re: RegExp; code: string }> = [
  { re: /^fattura\s+vendit/i, code: "FT" },
  { re: /nota\s+di\s+credito/i, code: "NC" },
  { re: /ns\s+nota\s+debito/i, code: "ND" },
  { re: /^insoluto/i, code: "IN" },
  { re: /ns\s+bonifico/i, code: "BN" },
  { re: /^storno/i, code: "ST" },
  { re: /^girofondi/i, code: "GF" },
];

function mapCausal(desc: string): string {
  const t = desc.trim();
  for (const { re, code } of CAUSAL_MAP) if (re.test(t)) return code;
  return t.toUpperCase().slice(0, 4);
}

const AGENT_RE = /^\s*Agente\s+(\S+)\s+/i;
// SKIP solo header pagina e righe di servizio. Ancorato a inizio riga per non
// catturare i clienti con ragione sociale "FRASCHETTI SPA".
const SKIP_RE = /^(FRASCHETTI SPA\b|\s+Stampa situazione clienti|\s*-Riferimenti|\s+Anno\s+Numero|\s+Totale\s+(cliente|agente|generale))/i;
const DASH_RE = /^\s*-{10,}\s*$/;

// Riga cliente: " 1428   .BRIKO SAN MARINO SRL  CAILUNGO (EE) - Tel. ..."
// oppure " 4801   ARDES S.P.A.  BERGAMO (BG)" (senza tel)
// oppure ragsoc senza città/prov (raro)
const CUST_RE = /^\s+(\d{2,6})\s{2,}(.+?)(?:\s{2,}([^()]+?)\s*\(([A-Za-z]{2})\))?\s*(?:-\s*Tel\..*)?$/;

// Riga documento (importo a destra, doc_number opzionale, date possono essere 0/00/00).
// reg_prot e doc_number sono \S+ (accettano COFACE, VB/2, ecc.).
const DOC_RE = /^\s+(\d{4})\s+(\S+)\s+(\d{1,2}\/\d{1,2}\/\d{2})\s+(?:(\S+)\s+)?(\d{1,2}\/\d{1,2}\/\d{2})\s+(.+?)\s+(-?[\d.]+,\d{2}-?)\s*$/;

export function parseScadenziarioText(text: string): ParsedScadResult {
  const rows: ParsedScadRow[] = [];
  let agentCode = "";
  let curCust: { code: string; name: string } | null = null;

  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.replace(/\s+$/, "");
    if (!line.trim()) continue;

    if (!agentCode) {
      const am = line.match(AGENT_RE);
      if (am) {
        agentCode = am[1].toUpperCase();
        continue;
      }
    }

    if (SKIP_RE.test(line)) continue;
    if (DASH_RE.test(line)) continue;

    // Prima prova come riga documento (più specifica)
    const dm = line.match(DOC_RE);
    if (dm && curCust) {
      const totale = parseAmount(dm[7]);
      const desc = dm[6].trim();
      rows.push({
        customer_code: curCust.code,
        customer_name: curCust.name,
        reg_prot: dm[2],
        reg_data: parseDate(dm[3]),
        causal: mapCausal(desc),
        payment_desc: desc,
        doc_number: dm[4] ?? "",
        doc_date: parseDate(dm[3]),
        due_date: parseDate(dm[5]),
        currency: "EUR",
        contanti: 0,
        effetti: 0,
        totale,
      });
      continue;
    }

    const cm = line.match(CUST_RE);
    if (cm) {
      curCust = {
        code: cm[1].padStart(4, "0"),
        name: cm[2].trim(),
      };
      continue;
    }
  }

  if (!agentCode) {
    throw new Error("Codice agente non trovato nel file (header 'Agente XX' mancante).");
  }

  return { agentCode, rows };
}

import * as XLSX from "xlsx";

/**
 * Scarica un file XLSX partendo da array di oggetti (una riga per oggetto).
 * Le chiavi del primo record determinano le colonne, salvo `headers` esplicito.
 */
export function downloadXlsx(
  filename: string,
  rows: Record<string, any>[],
  opts: { sheetName?: string; headers?: string[] } = {},
) {
  const ws = opts.headers
    ? XLSX.utils.json_to_sheet(rows, { header: opts.headers })
    : XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, opts.sheetName ?? "Sheet1");
  XLSX.writeFile(wb, filename);
}

/**
 * Scarica un file XLSX partendo da un AOA (array di array) - prima riga = header.
 */
export function downloadXlsxAoa(
  filename: string,
  aoa: any[][],
  opts: { sheetName?: string } = {},
) {
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, opts.sheetName ?? "Sheet1");
  XLSX.writeFile(wb, filename);
}

import { supabase } from "@/integrations/supabase/client";
import { getMediaCdparCandidates, normalizeMediaCdpar } from "@/lib/mediaUtils";
import { buildPublicMediaUrl } from "@/lib/mediaUpload";

export type DocKind = "sds" | "st" | "col" | "expo";

export interface DocKindConfig {
  marker: string; // uppercased token expected at end of filename, e.g. "SDS" or "ST"
  mediaType: string; // value stored in article_media.media_type
  storageSubfolder: string; // subfolder under articles/_shared/
  label: string; // human label for UI
  shortLabel: string; // short label for messages
}

export const DOC_KINDS: Record<DocKind, DocKindConfig> = {
  sds: {
    marker: "SDS",
    mediaType: "pdf_safety",
    storageSubfolder: "safety",
    label: "Schede di Sicurezza (SDS)",
    shortLabel: "SDS",
  },
  st: {
    marker: "ST",
    mediaType: "pdf_datasheet",
    storageSubfolder: "datasheets",
    label: "Schede Tecniche (ST)",
    shortLabel: "ST",
  },
  col: {
    marker: "COL",
    mediaType: "pdf_collection",
    storageSubfolder: "collections",
    label: "Collezioni",
    shortLabel: "COL",
  },
  expo: {
    marker: "EXPO",
    mediaType: "pdf_expo",
    storageSubfolder: "expo",
    label: "Expo",
    shortLabel: "EXPO",
  },
};

export interface ParsedDocName {
  cdpars: string[];
  error?: string;
}

/**
 * Parse a filename like:
 *   002085_SDS.pdf / 002085_st.pdf / 002085_002087_SDS.PDF
 * Case-insensitive on the marker and extension.
 */
export function parseDocFilename(filename: string, kind: DocKind): ParsedDocName {
  const cfg = DOC_KINDS[kind];
  const m = filename.match(/^(.+)\.([^.]+)$/);
  if (!m) return { cdpars: [], error: "Nome senza estensione" };
  const base = m[1];
  const ext = m[2].toLowerCase();
  if (ext !== "pdf") return { cdpars: [], error: "Non è un PDF" };

  const parts = base.split("_").map((p) => p.trim()).filter(Boolean);
  if (parts.length < 2) return { cdpars: [], error: `Manca suffisso _${cfg.marker}` };

  const tail = parts[parts.length - 1].toUpperCase();
  if (tail !== cfg.marker) return { cdpars: [], error: `Suffisso _${cfg.marker} mancante` };

  const cdpars = parts.slice(0, -1).map((p) => normalizeMediaCdpar(p));
  if (cdpars.length === 0) return { cdpars: [], error: "Nessun codice articolo nel nome" };

  return { cdpars: Array.from(new Set(cdpars)) };
}

// Backward-compat alias for SDS-only callers
export const parseSdsFilename = (filename: string) => parseDocFilename(filename, "sds");

/**
 * Validate cdpars against archivio_articoli_fraschetti.
 */
export async function validateCdpars(cdpars: string[]): Promise<{ valid: Set<string>; invalid: string[] }> {
  if (cdpars.length === 0) return { valid: new Set(), invalid: [] };

  const candidates = Array.from(new Set(cdpars.flatMap((c) => getMediaCdparCandidates(c))));

  const found = new Set<string>();
  for (let i = 0; i < candidates.length; i += 500) {
    const chunk = candidates.slice(i, i + 500);
    const { data, error } = await supabase
      .from("archivio_articoli_fraschetti")
      .select("cdpar")
      .in("cdpar", chunk);
    if (error) throw error;
    for (const row of data ?? []) {
      found.add(normalizeMediaCdpar((row as any).cdpar));
    }
  }

  const valid = new Set<string>();
  const invalid: string[] = [];
  for (const c of cdpars) {
    if (found.has(normalizeMediaCdpar(c))) valid.add(normalizeMediaCdpar(c));
    else invalid.push(c);
  }
  return { valid, invalid };
}

export async function sha256Hex(blob: Blob): Promise<string> {
  const buf = await blob.arrayBuffer();
  const digest = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export const buildSharedDocPath = (kind: DocKind, hash: string) =>
  `articles/_shared/${DOC_KINDS[kind].storageSubfolder}/sha256-${hash}.pdf`;

// Backward-compat alias
export const buildSharedSafetyPath = (hash: string) => buildSharedDocPath("sds", hash);

/**
 * Upload optimized PDF (deduped via hash) and upsert one article_media row per cdpar.
 */
export async function uploadDocForFile(params: {
  kind: DocKind;
  optimized: Blob;
  cdpars: string[];
  originalFilename: string;
}): Promise<{ uploaded: number; reused: boolean }> {
  const { kind, optimized, cdpars, originalFilename } = params;
  const cfg = DOC_KINDS[kind];
  const hash = await sha256Hex(optimized);
  const storagePath = buildSharedDocPath(kind, hash);

  let reused = false;
  const { error: uploadErr } = await supabase.storage
    .from("pim-media")
    .upload(storagePath, optimized, {
      contentType: "application/pdf",
      upsert: false,
    });
  if (uploadErr) {
    const msg = (uploadErr as any).message?.toLowerCase?.() ?? "";
    if (msg.includes("exists") || msg.includes("duplicate") || (uploadErr as any).statusCode === "409") {
      reused = true;
    } else {
      throw uploadErr;
    }
  }

  const publicUrl = buildPublicMediaUrl(storagePath);
  const fileSize = optimized.size;

  for (const cdpar of cdpars) {
    const candidates = getMediaCdparCandidates(cdpar);
    const { error: delErr } = await supabase
      .from("article_media")
      .delete()
      .in("cdpar", candidates)
      .eq("media_type", cfg.mediaType);
    if (delErr) throw delErr;

    const { error: insErr } = await supabase.from("article_media").insert({
      cdpar: normalizeMediaCdpar(cdpar),
      media_type: cfg.mediaType,
      storage_path: storagePath,
      public_url: publicUrl,
      original_filename: originalFilename,
      file_size: fileSize,
      is_primary: false,
      progressive: 1,
      sort_order: 1,
    } as any);
    if (insErr) throw insErr;
  }

  return { uploaded: cdpars.length, reused };
}

// Backward-compat alias
export const uploadSdsForFile = (p: Omit<Parameters<typeof uploadDocForFile>[0], "kind">) =>
  uploadDocForFile({ ...p, kind: "sds" });

export const formatBytes = (n: number) => {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
};

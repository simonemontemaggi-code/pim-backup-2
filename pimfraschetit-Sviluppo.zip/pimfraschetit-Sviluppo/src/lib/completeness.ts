const IMPORTANT_FIELDS = ["cdpar", "depar", "clmer", "lipro", "unmis", "cdiva", "pcfor", "barcd"] as const;

export function computeCompleteness(article: Record<string, any>): number {
  const total = IMPORTANT_FIELDS.length;
  let filled = 0;
  for (const f of IMPORTANT_FIELDS) {
    const v = article[f];
    if (v !== null && v !== undefined && v !== "") filled++;
  }
  return Math.round((filled / total) * 100);
}

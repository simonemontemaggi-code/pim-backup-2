import { supabase } from "@/integrations/supabase/client";

// --- Path builders ---

export const normalizeMediaCdpar = (value: string | null | undefined) =>
  (value ?? "").trim();

export const getMediaCdparCandidates = (value: string | null | undefined) => {
  const normalized = normalizeMediaCdpar(value);
  if (!normalized) return [] as string[];

  return Array.from(new Set([normalized, normalized.padEnd(15, " ")]));
};

const getFilenameBase = (filename: string) => filename.replace(/\.[^/.]+$/, "").trim();

const getFilenameFromPath = (path: string | null | undefined) =>
  (path ?? "").split("/").pop() ?? "";

const escapeRegExp = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

export type ImageFilenameSlot =
  | { kind: "bare"; number: null; rank: 0; base: string }
  | { kind: "numbered"; number: number; rank: 1; base: string }
  | { kind: "prefixed_p"; number: null; rank: 2; base: string }
  | { kind: "other"; number: null; rank: 3; base: string };

export const getImageFilenameSlot = (cdpar: string, filename: string): ImageFilenameSlot => {
  const normalizedCdpar = normalizeMediaCdpar(cdpar);
  const base = getFilenameBase(filename);
  const upperBase = base.toUpperCase();
  const upperCdpar = normalizedCdpar.toUpperCase();

  if (!upperCdpar) return { kind: "other", number: null, rank: 3, base };
  if (upperBase === upperCdpar) return { kind: "bare", number: null, rank: 0, base };
  if (upperBase === `P${upperCdpar}`) return { kind: "prefixed_p", number: null, rank: 2, base };

  const match = upperBase.match(new RegExp(`^${escapeRegExp(upperCdpar)}_(\\d+)$`));
  const number = match?.[1] ? parseInt(match[1], 10) : null;
  if (number != null && Number.isFinite(number) && number > 0) {
    return { kind: "numbered", number, rank: 1, base };
  }

  return { kind: "other", number: null, rank: 3, base };
};

const getMediaComparableFilename = (media: any) =>
  media?.original_filename || getFilenameFromPath(media?.storage_path) || "";

export const compareArticleImageMedia = (cdpar: string, a: any, b: any) => {
  const nameA = getMediaComparableFilename(a);
  const nameB = getMediaComparableFilename(b);
  const slotA = getImageFilenameSlot(cdpar, nameA);
  const slotB = getImageFilenameSlot(cdpar, nameB);

  if (slotA.rank !== slotB.rank) return slotA.rank - slotB.rank;
  if (slotA.kind === "numbered" && slotB.kind === "numbered" && slotA.number !== slotB.number) {
    return slotA.number - slotB.number;
  }

  const sortA = typeof a?.sort_order === "number" ? a.sort_order : Number.MAX_SAFE_INTEGER;
  const sortB = typeof b?.sort_order === "number" ? b.sort_order : Number.MAX_SAFE_INTEGER;
  if (slotA.kind === "other" && sortA !== sortB) return sortA - sortB;

  const byName = nameA.localeCompare(nameB, "it", { numeric: true, sensitivity: "base" });
  if (byName !== 0) return byName;

  return String(a?.id ?? "").localeCompare(String(b?.id ?? ""));
};

export const sortArticleImages = <T extends any>(cdpar: string, images: T[]): T[] =>
  [...images].sort((a, b) => compareArticleImageMedia(cdpar, a, b));

export const normalizeArticleImageOrdering = async (cdpar: string) => {
  const cdparCandidates = getMediaCdparCandidates(cdpar);
  const { data, error } = await supabase
    .from("article_media")
    .select("id, cdpar, storage_path, original_filename, progressive, sort_order, is_primary")
    .in("cdpar", cdparCandidates)
    .eq("media_type", "image");

  if (error) throw error;

  const ordered = sortArticleImages(cdpar, (data ?? []) as any[]);
  for (let index = 0; index < ordered.length; index++) {
    const image = ordered[index];
    const sortOrder = index + 1;
    const isPrimary = index === 0;
    if (image.sort_order === sortOrder && image.is_primary === isPrimary) continue;

    const { error: updateError } = await supabase
      .from("article_media")
      .update({ sort_order: sortOrder, is_primary: isPrimary } as any)
      .eq("id", image.id);

    if (updateError) throw updateError;
  }

  return ordered.map((image, index) => ({
    ...image,
    sort_order: index + 1,
    is_primary: index === 0,
  }));
};

export const buildImagePath = (cdpar: string, progressive: number, ext: string, originalFilename?: string) => {
  const normalizedCdpar = normalizeMediaCdpar(cdpar);
  const originalBase = originalFilename ? getFilenameBase(originalFilename) : "";

  // Preserve the "P{cdpar}" naming convention when the source file uses it.
  if (originalBase.toUpperCase() === `P${normalizedCdpar.toUpperCase()}`) {
    return `articles/${normalizedCdpar}/images/${originalBase}.${ext.toLowerCase()}`;
  }

  // Preserve the bare "{cdpar}" naming convention: distinct slot from `{cdpar}_N`.
  if (originalBase.toUpperCase() === normalizedCdpar.toUpperCase()) {
    return `articles/${normalizedCdpar}/images/${normalizedCdpar}.${ext.toLowerCase()}`;
  }

  return `articles/${normalizedCdpar}/images/${normalizedCdpar}_${progressive}.${ext.toLowerCase()}`;
};

export const buildDatasheetPath = (cdpar: string) =>
  `articles/${normalizeMediaCdpar(cdpar)}/datasheets/${normalizeMediaCdpar(cdpar)}_scheda.pdf`;

export const buildSafetyPath = (cdpar: string) =>
  `articles/${normalizeMediaCdpar(cdpar)}/safety/${normalizeMediaCdpar(cdpar)}_sicurezza.pdf`;

export const buildDocPath = (cdpar: string, progressive: number, ext: string) =>
  `articles/${normalizeMediaCdpar(cdpar)}/docs/${normalizeMediaCdpar(cdpar)}_doc_${progressive}.${ext.toLowerCase()}`;

export const buildAssemblyPath = (cdpar: string) =>
  `articles/${normalizeMediaCdpar(cdpar)}/docs/${normalizeMediaCdpar(cdpar)}_montaggio.pdf`;

export const buildCertificationPath = (cdpar: string) =>
  `articles/${normalizeMediaCdpar(cdpar)}/docs/${normalizeMediaCdpar(cdpar)}_certificazione.pdf`;

export const buildCollectionPath = (cdpar: string) =>
  `articles/${normalizeMediaCdpar(cdpar)}/collections/${normalizeMediaCdpar(cdpar)}_collezione.pdf`;

export const buildExpoPath = (cdpar: string) =>
  `articles/${normalizeMediaCdpar(cdpar)}/expo/${normalizeMediaCdpar(cdpar)}_expo.pdf`;

export const buildVideoPath = (cdpar: string, progressive: number, ext: string) =>
  `articles/${normalizeMediaCdpar(cdpar)}/videos/${normalizeMediaCdpar(cdpar)}_video_${progressive}.${ext.toLowerCase()}`;

// --- Filename → progressive inference ---
// Riconosce nomi tipo "536001_2.webp" → progressive=2 per cdpar=536001.
// Restituisce null se il nome non segue il pattern "{cdpar}_{N}.{ext}".
export const parseImageProgressiveFromFilename = (
  cdpar: string,
  filename: string
): number | null => {
  const slot = getImageFilenameSlot(cdpar, filename);
  return slot.kind === "numbered" ? slot.number : null;
};

// True se il basename del filename è esattamente il cdpar (senza suffisso _N).
export const isBareCdparFilename = (cdpar: string, filename: string): boolean => {
  return getImageFilenameSlot(cdpar, filename).kind === "bare";
};

export const isPrefixedPCdparFilename = (cdpar: string, filename: string): boolean => {
  return getImageFilenameSlot(cdpar, filename).kind === "prefixed_p";
};

// --- Progressive numbering ---

export const getNextProgressive = async (cdpar: string, mediaType: string): Promise<number> => {
  const { data } = await supabase
    .from("article_media")
    .select("progressive")
    .in("cdpar", getMediaCdparCandidates(cdpar))
    .eq("media_type", mediaType)
    .order("progressive", { ascending: false })
    .limit(1);
  return ((data?.[0] as any)?.progressive ?? 0) + 1;
};

// --- Auto-detect cdpar from filename ---

export interface DetectResult {
  cdpar: string | null;
  confidence: "exact" | "partial" | "none";
}

interface CdparLookupCache {
  byLength: Map<number, Set<string>>;
  lengths: number[];
  originalByUpper: Map<string, string>;
}

const cdparLookupCache = new WeakMap<string[], CdparLookupCache>();

const getCdparLookupCache = (knownCdpars: string[]): CdparLookupCache => {
  const cached = cdparLookupCache.get(knownCdpars);
  if (cached) {
    return cached;
  }

  const byLength = new Map<number, Set<string>>();
  const originalByUpper = new Map<string, string>();

  for (const cdpar of knownCdpars) {
    // Normalize padding before indexing so filenames and media tables always use the same key.
    const normalized = normalizeMediaCdpar(cdpar);
    const upper = normalized.toUpperCase();
    if (!upper) continue;
    // Preserve the normalized value used by media/storage tables.
    if (!originalByUpper.has(upper)) {
      originalByUpper.set(upper, normalized);
    }

    const bucket = byLength.get(upper.length) ?? new Set<string>();
    bucket.add(upper);
    byLength.set(upper.length, bucket);
  }

  const lookup = {
    byLength,
    lengths: [...byLength.keys()].sort((a, b) => b - a),
    originalByUpper,
  };

  cdparLookupCache.set(knownCdpars, lookup);
  return lookup;
};

export const detectCdparFromFilename = (
  filename: string,
  knownCdpars: string[]
): DetectResult => {
  const baseName = filename.replace(/\.[^/.]+$/, "").toUpperCase();
  const { byLength, lengths, originalByUpper } = getCdparLookupCache(knownCdpars);

  // Build candidates for the "exact" pass: the raw basename, plus a variant
  // with a leading "P" stripped (used for padre-product images named e.g. "P12345.jpg").
  const exactCandidates: string[] = [baseName];
  if (baseName.startsWith("P") && baseName.length > 1) {
    exactCandidates.push(baseName.slice(1));
  }

  for (const candidate of exactCandidates) {
    for (const length of lengths) {
      if (candidate.length < length) {
        continue;
      }

      const prefix = candidate.slice(0, length);
      if (byLength.get(length)?.has(prefix)) {
        return {
          cdpar: originalByUpper.get(prefix) ?? prefix,
          confidence: "exact",
        };
      }
    }
  }

  for (const length of lengths) {
    if (baseName.length < length) {
      continue;
    }

    const bucket = byLength.get(length);
    if (!bucket) {
      continue;
    }

    for (let index = 1; index <= baseName.length - length; index++) {
      const candidate = baseName.slice(index, index + length);
      if (bucket.has(candidate)) {
        return {
          cdpar: originalByUpper.get(candidate) ?? candidate,
          confidence: "partial",
        };
      }
    }
  }

  return { cdpar: null, confidence: "none" };
};

// --- Renumber images after delete (metadata-only, no file renaming) ---

export const renumberImages = async (cdpar: string) => {
  const { data: images } = await supabase
    .from("article_media")
    .select("*")
    .in("cdpar", getMediaCdparCandidates(cdpar))
    .eq("media_type", "image")
    .order("sort_order", { ascending: true });

  if (!images || images.length === 0) return;

  for (let i = 0; i < images.length; i++) {
    const img = images[i] as any;
    await supabase
      .from("article_media")
      .update({
        sort_order: i + 1,
        is_primary: i === 0,
      } as any)
      .eq("id", img.id);
  }
};

// --- Get file extension ---
export const getFileExt = (filename: string) =>
  (filename.split(".").pop() ?? "bin").toLowerCase();

/**
 * Helpers per <input type="datetime-local"> ↔ Supabase timestamptz (UTC).
 * UI mostra sempre l'ora locale del browser (incl. ora legale/solare),
 * Supabase riceve sempre UTC.
 */

/** UTC ISO → "YYYY-MM-DDTHH:mm" in ora locale per il <input datetime-local>. */
export function utcToLocalDateTimeInput(value: string | Date | null | undefined): string {
  if (!value) return "";
  const date = value instanceof Date ? value : new Date(value);
  if (isNaN(date.getTime())) return "";
  const pad = (n: number) => n.toString().padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

/** "YYYY-MM-DDTHH:mm" (ora locale) → ISO UTC da salvare in Supabase. */
export function localDateTimeInputToUtcIso(value: string | null | undefined): string | null {
  if (!value) return null;
  const m = value.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
  if (!m) return null;
  const [, y, mo, d, h, mi] = m;
  const local = new Date(+y, +mo - 1, +d, +h, +mi, 0, 0);
  if (isNaN(local.getTime())) return null;
  return local.toISOString();
}

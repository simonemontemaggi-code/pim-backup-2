import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 14 - PROMO STRUTT. CONDIZIONI".
 *
 * Mapping STRICT per posizione (14 colonne, SAD_FRAC/WPSVC00F):
 *   1 wpstatc  | 2 wpprgc   | 3 wpprgec | 4 wpseqc  | 5 wpricon
 *   6 wpsm1c   | 7 wpsm2c   | 8 wppapc  | 9 wptpvc  | 10 wpsegvc
 *  11 wpval1c  | 12 wpval2c | 13 wpunmc | 14 wpsm5c
 *
 * Target: `promo_strutturate_condizioni`. Snapshot replace (truncate + insert).
 */

export interface Q14Row {
  wpstatc: string | null;
  wpprgc: number | null;
  wpprgec: number | null;
  wpseqc: number | null;
  wpricon: string | null;
  wpsm1c: string | null;
  wpsm2c: string | null;
  wppapc: string | null;
  wptpvc: string | null;
  wpsegvc: string | null;
  wpval1c: number | null;
  wpval2c: number | null;
  wpunmc: string | null;
  wpsm5c: string | null;
}

const cleanText = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

const toNum = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const n = typeof raw === "number" ? raw : Number(String(raw).replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

export interface Q14ParseResult {
  headers: string[];
  rows: Q14Row[];
  warnings: string[];
}

const EXPECTED = 14;

export async function parseQuery14Xlsx(file: File): Promise<Q14ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < EXPECTED) warnings.push(`Attese ${EXPECTED} colonne, trovate ${headers.length}`);

  const rows: Q14Row[] = [];
  let skipped = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const row: Q14Row = {
      wpstatc: cleanText(r[0]),
      wpprgc: toNum(r[1]),
      wpprgec: toNum(r[2]),
      wpseqc: toNum(r[3]),
      wpricon: cleanText(r[4]),
      wpsm1c: cleanText(r[5]),
      wpsm2c: cleanText(r[6]),
      wppapc: cleanText(r[7]),
      wptpvc: cleanText(r[8]),
      wpsegvc: cleanText(r[9]),
      wpval1c: toNum(r[10]),
      wpval2c: toNum(r[11]),
      wpunmc: cleanText(r[12]),
      wpsm5c: cleanText(r[13]),
    };
    if (row.wpprgec === null && row.wpprgc === null && !row.wpstatc) { skipped++; continue; }
    rows.push(row);
  }
  if (skipped > 0) warnings.push(`${skipped} righe vuote scartate`);
  return { headers, rows, warnings };
}

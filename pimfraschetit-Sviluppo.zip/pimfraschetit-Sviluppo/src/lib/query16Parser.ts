import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 16 - PROMO STRUTTURATE TESTATE".
 *
 * Mapping STRICT per posizione (11 colonne, ordine SELECT AS400):
 *   1 wpprgf | 2 wptpbd | 3 wpcca | 4 wpindoi | 5 wpindof
 *   6 wpdvali | 7 wpdvalf | 8 wpstato | 9 wptpca | 10 wpdma | 11 wpriatc
 *
 * Target: `promo_strutturate_testate`. Update mirato solo su righe esistenti
 * (chiave `wpprgf`). Nessun insert/delete, nessun export AS400.
 */

export interface Q16Row {
  wpprgf: number;
  wptpbd: string | null;
  wpcca: string | null;
  wpindoi: number | null;
  wpindof: number | null;
  wpdvali: number | null;
  wpdvalf: number | null;
  wpstato: string | null;
  wptpca: string | null;
  wpdma: number | null;
  wpriatc: number | null;
}

const cleanStr = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

const toNum = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const n = typeof raw === "number" ? raw : Number(String(raw).replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

export interface Q16ParseResult {
  headers: string[];
  rows: Q16Row[];
  warnings: string[];
}

export async function parseQuery16Xlsx(file: File): Promise<Q16ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < 11) warnings.push(`Attese 11 colonne, trovate ${headers.length}`);

  const rows: Q16Row[] = [];
  const seen = new Set<number>();
  let skipped = 0;
  let dupes = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const wpprgf = toNum(r[0]);
    if (wpprgf === null) { skipped++; continue; }
    if (seen.has(wpprgf)) { dupes++; continue; }
    seen.add(wpprgf);
    rows.push({
      wpprgf,
      wptpbd: cleanStr(r[1]),
      wpcca: cleanStr(r[2]),
      wpindoi: toNum(r[3]),
      wpindof: toNum(r[4]),
      wpdvali: toNum(r[5]),
      wpdvalf: toNum(r[6]),
      wpstato: cleanStr(r[7]),
      wptpca: cleanStr(r[8]),
      wpdma: toNum(r[9]),
      wpriatc: toNum(r[10]),
    });
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (wpprgf mancante)`);
  if (dupes > 0) warnings.push(`${dupes} duplicati su wpprgf (tenuta la prima occorrenza)`);
  return { headers, rows, warnings };
}

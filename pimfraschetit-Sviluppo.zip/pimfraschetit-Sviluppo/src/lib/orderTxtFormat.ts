// Builder TXT formato AS400 per scarico ordini.
// Tutte le funzioni sono pure: nessun side effect, facile da testare.

export interface OrderItemPayload {
  product_id: string | null;
  quantity: number | string | null;
  unit_price: number | string | null;
  net_price: number | string | null;
  list_price?: number | string | null;
  final_price?: number | string | null;
  discount_pct?: number | string | null;
  applied_promo?: string | null;
  is_omaggio?: boolean | null;
}

export interface OrderPayload {
  order_id: string;
  progressivo: number;
  codice_cliente: string | null;
  transmission_id: string | null;
  origine: string | null;
  note: string | null;
  items: OrderItemPayload[];
}

export interface BatchPayload {
  batch_id: string;
  file_name: string;
  seq_start: number | null;
  seq_end: number | null;
  orders_count: number;
  orders: OrderPayload[];
}

const padLeft = (v: string, n: number, ch = " ") =>
  v.length >= n ? v.slice(-n) : ch.repeat(n - v.length) + v;
const padRight = (v: string, n: number, ch = " ") =>
  v.length >= n ? v.slice(0, n) : v + ch.repeat(n - v.length);

const padCode = (v: string | null | undefined, n: number) =>
  padLeft(String(v ?? "").replace(/\D/g, ""), n, "0");

/**
 * Campo codice cliente: 6 caratteri totali.
 * 4 cifre -> "0099  ", 5 cifre -> "10099 ", 6 cifre -> "100992".
 */
export function formatCustCode(v: string | null | undefined): string {
  const digits = String(v ?? "").replace(/\D/g, "").slice(-6);
  const zeroPadded = digits.length < 4 ? "0".repeat(4 - digits.length) + digits : digits;
  return padRight(zeroPadded, 6, " ");
}

/** Numero -> "00000,00" (5 interi + virgola + 2 decimali, totale 8 char). */
export function formatNumber8(n: number | string | null | undefined): string {
  const num = Number(n ?? 0);
  if (!isFinite(num)) return "00000,00";
  const fixed = num.toFixed(2); // "19.99"
  const [intPart, decPart] = fixed.split(".");
  return `${padLeft(intPart, 5, "0")},${decPart}`;
}

function formatItemRow(o: OrderPayload, it: OrderItemPayload): string {
  const tipo = "A";
  const cliente = formatCustCode(o.codice_cliente);
  const prog = padLeft(String(o.progressivo), 6, "0");
  const articolo = padCode(it.product_id, 6);
  const qty = formatNumber8(it.quantity);
  // Regola prezzo TXT:
  // - se la riga ha promo/sconto/omaggio/prezzo modificato → scrivi il prezzo riga
  // - altrimenti (listino standard senza modifiche) → scrivi 0,00
  const unit = Number(it.unit_price ?? 0);
  const net = it.net_price == null ? null : Number(it.net_price);
  const list = it.list_price == null ? null : Number(it.list_price);
  const finalP = it.final_price == null ? null : Number(it.final_price);
  const disc = Number(it.discount_pct ?? 0);
  const hasPromo = !!(it.applied_promo && String(it.applied_promo).trim());
  const hasDiscount = disc !== 0;
  const hasFinalOverride = finalP != null && finalP !== 0 && finalP !== unit;
  const hasNetOverride = net != null && net !== 0 && net !== unit;
  const hasListOverride = list != null && list !== 0 && list !== unit;
  const isGift = !!it.is_omaggio;
  const hasPriceChange = hasPromo || hasDiscount || hasFinalOverride || hasNetOverride || hasListOverride || isGift;
  const priceToWrite = hasPriceChange ? unit : 0;
  const prezzo = formatNumber8(priceToWrite);
  const origine = o.origine === "NE" ? "NE" : "  ";
  const tx = padLeft(String(o.transmission_id ?? ""), 10, " ");
  return `${tipo}${cliente}${prog}${articolo}${qty}${prezzo}${origine}${tx}`;
}

function formatNoteRows(o: OrderPayload): string[] {
  if (!o.note || !o.note.trim()) return [];
  const cliente = formatCustCode(o.codice_cliente);
  const prog = padLeft(String(o.progressivo), 6, "0");
  const tx = padLeft(String(o.transmission_id ?? ""), 10, " ");
  const text = o.note;
  const rows: string[] = [];
  for (let i = 0; i < text.length; i += 22) {
    const chunk = padRight(text.slice(i, i + 22), 24, " ");
    rows.push(`N${cliente}${prog}${chunk}${tx}`);
  }
  return rows;
}

export function buildOrderTxt(payload: BatchPayload): string {
  const lines: string[] = [];
  for (const o of payload.orders) {
    for (const it of o.items) lines.push(formatItemRow(o, it));
    for (const r of formatNoteRows(o)) lines.push(r);
  }
  return lines.join("\r\n") + (lines.length ? "\r\n" : "");
}

export function downloadTxt(filename: string, content: string) {
  // Encoding ASCII / Latin1 compatibile AS400.
  const bytes = new Uint8Array(content.length);
  for (let i = 0; i < content.length; i++) bytes[i] = content.charCodeAt(i) & 0xff;
  const blob = new Blob([bytes], { type: "text/plain;charset=iso-8859-1" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

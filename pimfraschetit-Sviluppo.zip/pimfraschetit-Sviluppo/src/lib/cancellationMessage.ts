export interface CancellationItem {
  cdpar: string;
  descrizione: string;
  qty: string;
  prezzo: string;
}

export interface CancellationTrailer {
  key: string;
  value: string;
}

export interface ParsedCancellation {
  header: string;
  items: CancellationItem[];
  trailers: CancellationTrailer[];
  raw?: string; // fallback lines that couldn't be parsed as items
}

/**
 * Parse the flat "Richiesta annullamento ordine" message sent by the B2B portal.
 * Same logic as the edge function `send-b2b-ticket-email` — kept in sync.
 * Returns null if the message doesn't contain the "Righe da annullare:" marker.
 */
export function parseCancellationMessage(raw: string | null | undefined): ParsedCancellation | null {
  if (!raw || !raw.includes("Righe da annullare:")) return null;
  const [head, rest] = raw.split(/Righe da annullare:\s*/);
  let body = rest ?? "";

  const cutMarkers = ["Totale righe selezionate:", "Numero righe:", "Motivo:"];
  let firstIdx = -1;
  for (const m of cutMarkers) {
    const i = body.indexOf(m);
    if (i >= 0 && (firstIdx < 0 || i < firstIdx)) firstIdx = i;
  }
  let tail = "";
  if (firstIdx >= 0) {
    tail = body.slice(firstIdx).trim();
    body = body.slice(0, firstIdx).trim();
  }

  const parts = body.split(/\s+-\s+(?=\d{4,6}\s+—)/);
  const items: CancellationItem[] = [];
  const unparsed: string[] = [];
  for (let p of parts) {
    p = p.trim().replace(/^-\s+/, "");
    if (!p) continue;
    const m = p.match(/^(\d{4,6})\s+—\s+(.+?)\s+—\s+Qtà:\s*(\d+)\s+—\s+Prezzo:\s*(.+?)\s*€?\s*$/);
    if (m) {
      items.push({ cdpar: m[1], descrizione: m[2].trim(), qty: m[3], prezzo: m[4].trim() });
    } else {
      unparsed.push(p);
    }
  }

  const trailers: CancellationTrailer[] = [];
  if (tail) {
    const re = /(Totale righe selezionate:|Numero righe:|Motivo:)/g;
    const idxs: { key: string; pos: number }[] = [];
    let mm: RegExpExecArray | null;
    while ((mm = re.exec(tail)) !== null) idxs.push({ key: mm[1], pos: mm.index });
    for (let i = 0; i < idxs.length; i++) {
      const start = idxs[i].pos;
      const end = i + 1 < idxs.length ? idxs[i + 1].pos : tail.length;
      const seg = tail.slice(start, end).trim();
      const [k, ...v] = seg.split(":");
      trailers.push({ key: k.trim(), value: v.join(":").trim() });
    }
  }

  return {
    header: head.trim(),
    items,
    trailers,
    raw: unparsed.length ? unparsed.join("\n") : undefined,
  };
}

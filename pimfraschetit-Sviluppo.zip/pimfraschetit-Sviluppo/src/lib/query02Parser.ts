import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 02 - ANAGR. ART. FORNITORI" (versione completa AS400).
 *
 * Mapping STRICT per posizione (75 colonne) — vedi Q02_COLUMNS sotto.
 * Le prime 2 colonne sono chiavi (cdpar, cdfor) salvate trimmed.
 *
 * Target: `archivio_anag_art_fornitore` (tutti i campi tranne id/created_at/updated_at).
 */

// Lista delle 75 colonne nell'ordine esatto del file XLSX
export const Q02_COLUMNS = [
  "cdpar", "cdfor", "nrz01", "daz01", "cdpfo", "umord", "umfaf", "ltprv",
  "cdval", "prull", "daulp", "dauar", "temco", "famco", "qtagg", "qta2g",
  "gimri", "qtrif", "qscaf", "qtr2f", "qsc2f", "varic", "qtrip", "qscap",
  "qtr2p", "qsc2p", "varip", "targ1", "targ2", "targ3", "scon1", "scon2",
  "scon3", "dainf", "dainp", "gifor", "davpf", "vapfo", "valfo", "vaqfo",
  "vaq2o", "nrifo", "notef", "avpaf", "usorc", "vricn", "vripn", "vricc",
  "vripc", "tpimb", "cdiva", "dtz01", "fmarc", "freep", "quotf", "unimb",
  "ftimb", "lotto", "cicqu", "cdrif", "vrsnmb", "setlg", "wfacq", "qtmio",
  "wimbf", "wviqm", "wviim", "wtaim", "wqtde", "wumqm", "wumim", "wumso",
  "wcute", "wflfo", "wperspf",
] as const;

export type Q02Col = (typeof Q02_COLUMNS)[number];

// Campi numerici (decimali) — gli altri sono tutti text
export const Q02_NUMERIC_FIELDS = new Set<string>([
  "umfaf", "prull", "qtagg", "qta2g", "qtrif", "qscaf", "qtr2f", "qsc2f",
  "varic", "qtrip", "qscap", "qtr2p", "qsc2p", "varip", "targ1", "targ2",
  "targ3", "scon1", "scon2", "scon3", "vaqfo", "vaq2o", "vricn", "vripn",
  "vricc", "vripc", "quotf", "ftimb", "qtmio", "wimbf",
]);

// Campi integer
export const Q02_INTEGER_FIELDS = new Set<string>(["nrifo"]);

export type Q02Row = {
  cdpar: string;
  cdfor: string;
} & Record<string, string | number | null>;

export const Q02_EXPECTED_HEADERS = [
  "Cd Parte", "Fornit.", "Azione", "D.ult. manut.", "Cd par.forn.",
  "U.M. di acquisto", "Fatt.conv. st/acq", "LTD", "Cd div", "Pr.ult.lordo",
  "Dt ult.prezzo", "Dt ult.arrivo", "T.medio cons.", "Att.t.consegna",
  "Qta min agg.", "Qta min agg.", "Media gg.rit", "Qta ric per.",
  "Qta sca per.", "Qta ric per.", "Qta sca per.", "Val. ricevuto",
  "Qta ric pre.", "Qta sca pre.", "Qta ric pre.", "Qta sca pre.",
  "Val. ricevuto prec.", "1° Target", "2° Target", "3° Target",
  "Sc.target 1", "Sc.target 2", "Sc.target 3", "Dt in.periodo",
  "Dt in.per.pre.", "Giu for", "Agg.pre. fornit.", "Val.pres. fornit.",
  "Valut.fornitore", "Qta valutazione", "Qta valutazione", "N.rg valutazione",
  "Note", "Av.rio.pr.", "Record Uso", "Val.ric. moneta naz.",
  "Val prec moneta naz", "Val.ric. moneta com.", "Val prec moneta com",
  "Tipo di imb.", "Cd as fs", "Id. azienda", "FMARC", "FREEP", "QUOTF",
  "UM imb", "Fattore conv. UM imb", "Lotto interno", "Codice ciclo qualità",
  "Cd Parte", "VRSNMB", "SETLG", "Cd.cond. Acquisto", "Q.mov.", "IMBALLO",
  "Vinc.qtà min. S/N", "Vinc.imballo S/N", "Tp.arr. Imballo",
  "Qtà con dec. S/N", "UM stock", "UM stock", "Um S.Ord", "Codice Utente",
  "LINEA", "A disposiz. pers.azienda",
];

const cleanText = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

const cleanNumber = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const n = typeof raw === "number" ? raw : Number(String(raw).replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

const cleanKey = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

export interface Q02ParseResult {
  headers: string[];
  rows: Q02Row[];
  warnings: string[];
}

export async function parseQuery02Xlsx(file: File): Promise<Q02ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < Q02_COLUMNS.length) {
    warnings.push(`Attese ${Q02_COLUMNS.length} colonne, trovate ${headers.length}`);
  }

  const rows: Q02Row[] = [];
  let skipped = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const cdpar = cleanKey(r[0]);
    const cdfor = cleanKey(r[1]);
    if (!cdpar || !cdfor) { skipped++; continue; }

    const row: Q02Row = { cdpar, cdfor } as Q02Row;
    for (let c = 2; c < Q02_COLUMNS.length; c++) {
      const key = Q02_COLUMNS[c];
      const raw = r[c];
      if (Q02_NUMERIC_FIELDS.has(key) || Q02_INTEGER_FIELDS.has(key)) {
        (row as any)[key] = cleanNumber(raw);
      } else {
        (row as any)[key] = cleanText(raw);
      }
    }
    rows.push(row);
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (cdpar o cdfor mancanti)`);
  return { headers, rows, warnings };
}

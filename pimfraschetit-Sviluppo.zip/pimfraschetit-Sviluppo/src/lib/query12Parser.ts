import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 12 - PREZZI IN ATTESA".
 *
 * Mapping STRICT per posizione (10 colonne):
 *   1 wsm01 | 2 wsm02 | 3 wcdpa | 4 wcdls | 5 wsm03 | 6 wcdca | 7 wcdcv | 8 wcdcl | 9 wprun | 10 wdtin
 *
 * Target: `prezzi_in_attesa`. UPDATE diff su wsm01/wsm02/wsm03/wprun + INSERT nuovi.
 */

export interface Q12Row {
  wsm01: number | null;
  wsm02: number | null;
  wcdpa: string;
  wcdls: string;
  wsm03: number | null;
  wcdca: string | null;
  wcdcv: string | null;
  wcdcl: string | null;
  wprun: number | null;
  wdtin: string;
}

const cleanKey = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

const padArticle = (raw: any): string | null => {
  const s = cleanKey(raw);
  if (!s) return null;
  return s.padStart(6, "0");
};

const toNum = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const n = typeof raw === "number" ? raw : Number(String(raw).replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

const toDateStr = (raw: any): string | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const s = String(raw).trim().replace(/\D/g, "");
  if (s.length !== 8) return null;
  return s;
};

export interface Q12ParseResult {
  headers: string[];
  rows: Q12Row[];
  warnings: string[];
}

export async function parseQuery12Xlsx(file: File): Promise<Q12ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < 10) warnings.push(`Attese 10 colonne, trovate ${headers.length}`);

  const rows: Q12Row[] = [];
  const seen = new Set<string>();
  let skipped = 0;
  let dupes = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const wcdpa = padArticle(r[2]);
    const wcdls = cleanKey(r[3]);
    const wdtin = toDateStr(r[9]);
    if (!wcdpa || !wcdls || !wdtin) { skipped++; continue; }
    const wcdca = cleanKey(r[5]);
    const wcdcv = cleanKey(r[6]);
    const wcdcl = cleanKey(r[7]);
    const key = `${wcdpa}|${wcdls}|${wdtin}|${wcdca ?? ""}|${wcdcv ?? ""}|${wcdcl ?? ""}`;
    if (seen.has(key)) { dupes++; continue; }
    seen.add(key);
    rows.push({
      wsm01: toNum(r[0]),
      wsm02: toNum(r[1]),
      wcdpa,
      wcdls,
      wsm03: toNum(r[4]),
      wcdca,
      wcdcv,
      wcdcl,
      wprun: toNum(r[8]),
      wdtin,
    });
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (wcdpa/wcdls/wdtin mancanti)`);
  if (dupes > 0) warnings.push(`${dupes} duplicati sulla chiave naturale (tenuta la prima occorrenza)`);
  return { headers, rows, warnings };
}

import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 09 - LISTINI DEFINIZIONE DI BASE" (versione 10 colonne).
 *
 * Mapping STRICT per posizione, identico alla SELECT AS400:
 *   1  wcdls   Cod. List.
 *   2  wcdli   Cod.Lis. Ivato
 *   3  wfliv   WFLIV (flag IVA inclusa)
 *   4  wlipv   PR.VEND.CL.VEND.
 *   5  wlpzn   Prezzo netto S/N
 *   6  wlcos   Listino a costo S/N
 *   7  wltpc   Tipo di costo L/F/A/P
 *   8  wlorr   Ord.ricerca Costo
 *   9  wlmgc   Mag.reperim. Costo
 *   10 wlsif   WLSIF
 *
 * Target: `listini_vendita_def_base`. Chiave naturale: `wcdls`.
 */

export interface Q09Row {
  wcdls: string;
  wcdli: string | null;
  wfliv: string | null;
  wlipv: string | null;
  wlpzn: string | null;
  wlcos: string | null;
  wltpc: string | null;
  wlorr: string | null;
  wlmgc: string | null;
  wlsif: string | null;
}

const cleanText = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

export interface Q09ParseResult {
  headers: string[];
  rows: Q09Row[];
  warnings: string[];
}

const EXPECTED_COLS = 10;

export async function parseQuery09Xlsx(file: File): Promise<Q09ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) =>
    h === null || h === undefined ? "" : String(h),
  );
  const warnings: string[] = [];
  if (headers.length < EXPECTED_COLS) {
    warnings.push(`Attese ${EXPECTED_COLS} colonne, trovate ${headers.length}`);
  }

  const rows: Q09Row[] = [];
  const seen = new Set<string>();
  let skipped = 0;
  let dupes = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const wcdls = cleanText(r[0]);
    if (!wcdls) {
      skipped++;
      continue;
    }
    if (seen.has(wcdls)) {
      dupes++;
      continue;
    }
    seen.add(wcdls);
    rows.push({
      wcdls,
      wcdli: cleanText(r[1]),
      wfliv: cleanText(r[2]),
      wlipv: cleanText(r[3]),
      wlpzn: cleanText(r[4]),
      wlcos: cleanText(r[5]),
      wltpc: cleanText(r[6]),
      wlorr: cleanText(r[7]),
      wlmgc: cleanText(r[8]),
      wlsif: cleanText(r[9]),
    });
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (wcdls mancante)`);
  if (dupes > 0) warnings.push(`${dupes} duplicati su wcdls (tenuta la prima occorrenza)`);
  return { headers, rows, warnings };
}

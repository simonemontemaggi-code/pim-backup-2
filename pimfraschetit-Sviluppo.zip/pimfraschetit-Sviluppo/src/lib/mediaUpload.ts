import { supabase } from "@/integrations/supabase/client";
import { getMediaCdparCandidates, normalizeMediaCdpar } from "@/lib/mediaUtils";

export const MEDIA_UPLOAD_CONCURRENCY = 6;
export const MEDIA_BULK_UPLOAD_CONCURRENCY = 16;
const MEDIA_QUERY_PAGE_SIZE = 1000;
const MEDIA_PROGRESSIVE_CDPAR_CHUNK_SIZE = 150;

export interface MediaProgressiveKey {
  cdpar: string;
  mediaType: string;
}

export const getMediaProgressiveKey = ({ cdpar, mediaType }: MediaProgressiveKey) =>
  `${cdpar}::${mediaType}`;

const chunkArray = <T,>(items: T[], size: number): T[][] => {
  const chunks: T[][] = [];

  for (let index = 0; index < items.length; index += size) {
    chunks.push(items.slice(index, index + size));
  }

  return chunks;
};

export const getStartingProgressives = async (
  items: MediaProgressiveKey[]
): Promise<Record<string, number>> => {
  const uniqueItems = Array.from(
    new Map(items.map((item) => [getMediaProgressiveKey(item), item])).values()
  );

  const startMap = Object.fromEntries(
    uniqueItems.map((item) => [getMediaProgressiveKey(item), 1])
  ) as Record<string, number>;

  if (uniqueItems.length === 0) {
    return startMap;
  }

  const uniqueCdpars = [...new Set(uniqueItems.map((item) => normalizeMediaCdpar(item.cdpar)).filter(Boolean))];
  const uniqueMediaTypes = [...new Set(uniqueItems.map((item) => item.mediaType))];

  for (const cdparChunk of chunkArray(uniqueCdpars, MEDIA_PROGRESSIVE_CDPAR_CHUNK_SIZE)) {
    const cdparCandidates = Array.from(new Set(cdparChunk.flatMap((cdpar) => getMediaCdparCandidates(cdpar))));
    const rows = await fetchAllPages(async (from, to) => {
      const { data, error } = await supabase
        .from("article_media")
        .select("cdpar, media_type, progressive")
        .in("cdpar", cdparCandidates)
        .in("media_type", uniqueMediaTypes)
        .range(from, to);

      if (error) {
        throw error;
      }

      return (data ?? []) as {
        cdpar: string;
        media_type: string;
        progressive: number | null;
      }[];
    });

    for (const row of rows) {
      const key = getMediaProgressiveKey({
        cdpar: normalizeMediaCdpar(row.cdpar),
        mediaType: row.media_type,
      });
      startMap[key] = Math.max(startMap[key] ?? 1, (row.progressive ?? 0) + 1);
    }
  }

  return startMap;
};

export const buildPublicMediaUrl = (storagePath: string) =>
  supabase.storage.from("pim-media").getPublicUrl(storagePath).data.publicUrl;

export const runWithConcurrency = async <T, R>(
  items: T[],
  limit: number,
  worker: (item: T, index: number) => Promise<R>
): Promise<R[]> => {
  if (items.length === 0) {
    return [];
  }

  const results = new Array<R>(items.length);
  let currentIndex = 0;
  const poolSize = Math.max(1, Math.min(limit, items.length));

  const runner = async () => {
    while (true) {
      const index = currentIndex++;
      if (index >= items.length) {
        break;
      }
      results[index] = await worker(items[index], index);
    }
  };

  await Promise.all(Array.from({ length: poolSize }, () => runner()));

  return results;
};

export const fetchAllPages = async <T>(
  fetchPage: (from: number, to: number) => Promise<T[]>,
  pageSize = MEDIA_QUERY_PAGE_SIZE
): Promise<T[]> => {
  const results: T[] = [];
  let from = 0;

  while (true) {
    const page = await fetchPage(from, from + pageSize - 1);
    results.push(...page);

    if (page.length < pageSize) {
      break;
    }

    from += pageSize;
  }

  return results;
};

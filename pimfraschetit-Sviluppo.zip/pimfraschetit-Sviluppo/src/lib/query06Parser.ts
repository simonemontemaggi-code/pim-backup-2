import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 06 - TASSI DI CAMBIO" (WANVA00F).
 *
 * Mapping STRICT per posizione (9 colonne):
 *   1 daa33 | 2 nra33 | 3 cdval | 4 cdva2 | 5 dtval
 *   6 cambi | 7 divst | 8 dta33 | 9 vrsnmb
 *
 * Target: `tassi_di_cambio`. Chiave: trim(cdval).
 */

export interface Q06Row {
  daa33: string | null;
  nra33: string | null;
  cdval: string;
  cdva2: string | null;
  dtval: string | null;
  cambi: number | null;
  divst: number | null;
  dta33: string | null;
  vrsnmb: string | null;
}

const cleanKey = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

const cleanNumber = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const n = typeof raw === "number" ? raw : parseFloat(String(raw).replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

export interface Q06ParseResult {
  headers: string[];
  rows: Q06Row[];
  warnings: string[];
}

export async function parseQuery06Xlsx(file: File): Promise<Q06ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < 9) warnings.push(`Attese 9 colonne, trovate ${headers.length}`);

  const rows: Q06Row[] = [];
  let skipped = 0;
  const seen = new Set<string>();
  let dupes = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const cdval = cleanKey(r[2]);
    if (!cdval) { skipped++; continue; }
    if (seen.has(cdval)) { dupes++; continue; }
    seen.add(cdval);
    rows.push({
      daa33: cleanKey(r[0]),
      nra33: cleanKey(r[1]),
      cdval,
      cdva2: cleanKey(r[3]),
      dtval: cleanKey(r[4]),
      cambi: cleanNumber(r[5]),
      divst: cleanNumber(r[6]),
      dta33: cleanKey(r[7]),
      vrsnmb: cleanKey(r[8]),
    });
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (cdval mancante)`);
  if (dupes > 0) warnings.push(`${dupes} duplicati cdval nel file (tenuta la prima occorrenza)`);
  return { headers, rows, warnings };
}

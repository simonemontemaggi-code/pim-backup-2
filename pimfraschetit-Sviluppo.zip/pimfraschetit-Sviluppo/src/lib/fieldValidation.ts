/**
 * Field validation rules for Article Registry & UM fields.
 * - sanitizeInput: filters disallowed chars on the fly (paste-safe, length-capped)
 * - validateField: returns an error message (or null) for the final value
 */

export type FieldKind = "int" | "decimal" | "text";

export interface FieldRule {
  kind: FieldKind;
  /** maximum digits (decimal) or characters (text/int) */
  maxLen: number;
  /** minimum digits (decimal/int) or characters (text); undefined = no minimum */
  minLen?: number;
  /** if true, value must equal exactly maxLen (e.g. 6-digit codes) */
  exactLen?: boolean;
  required?: boolean;
  label: string;
}

export const FIELD_RULES: Record<string, FieldRule> = {
  cdpar: { kind: "int", maxLen: 6, exactLen: true, label: "Codice Parte" },
  depar: { kind: "text", maxLen: 30, label: "Descrizione" },
  wdeag: { kind: "text", maxLen: 20, label: "Estensione Descrizione" },
  nmdis: { kind: "text", maxLen: 50, label: "Linea Brand" },
  lipro: { kind: "int", maxLen: 3, exactLen: true, required: true, label: "Linea Prodotto" },
  pcfor: { kind: "int", maxLen: 4, exactLen: true, required: true, label: "Fornitore Principale" },
  umfaf: { kind: "decimal", maxLen: 6, label: "UM Fornitore - Fattore Conv." },
  umfat: { kind: "decimal", maxLen: 10, label: "UM Stoccaggio - Fattore Conv." },
  umfaa: { kind: "decimal", maxLen: 10, label: "Fatt. Conv. UM Imballo" },
  wfcs1: { kind: "decimal", maxLen: 10, label: "Fatt. Conv. UM Vendita" },
  wfc2x: { kind: "decimal", maxLen: 10, label: "Imballo di vendita" },
};

/** Filter input on-type. Returns sanitized string respecting kind & maxLen. */
export function sanitizeInput(rule: FieldRule, raw: string): string {
  if (raw == null) return "";
  let v = String(raw);

  if (rule.kind === "int") {
    v = v.replace(/[^0-9]/g, "");
    if (v.length > rule.maxLen) v = v.slice(0, rule.maxLen);
    return v;
  }

  if (rule.kind === "decimal") {
    // accept 0-9 and comma; convert dot to comma for italian input
    v = v.replace(/\./g, ",").replace(/[^0-9,]/g, "");
    // collapse multiple commas: keep first only
    const firstComma = v.indexOf(",");
    if (firstComma !== -1) {
      v = v.slice(0, firstComma + 1) + v.slice(firstComma + 1).replace(/,/g, "");
    }
    // count digits only against maxLen
    const digits = v.replace(",", "");
    if (digits.length > rule.maxLen) {
      // trim trailing chars until digit count fits
      while (v.replace(",", "").length > rule.maxLen) {
        v = v.slice(0, -1);
      }
    }
    return v;
  }

  // text
  if (v.length > rule.maxLen) v = v.slice(0, rule.maxLen);
  return v;
}

/** Validate the final value. Returns error string or null. */
export function validateField(rule: FieldRule, value: string | null | undefined): string | null {
  const v = (value ?? "").toString().trim();

  if (!v) {
    if (rule.required) return `${rule.label} è obbligatorio`;
    return null;
  }

  if (rule.kind === "int") {
    if (!/^\d+$/.test(v)) return `${rule.label}: solo cifre numeriche`;
    if (rule.exactLen && v.length !== rule.maxLen) return `${rule.label}: esattamente ${rule.maxLen} cifre`;
    if (rule.minLen && v.length < rule.minLen) return `${rule.label}: minimo ${rule.minLen} cifre`;
    if (v.length > rule.maxLen) return `${rule.label}: massimo ${rule.maxLen} cifre`;
    return null;
  }

  if (rule.kind === "decimal") {
    if (!/^\d+(,\d+)?$/.test(v)) return `${rule.label}: numero non valido`;
    const digits = v.replace(",", "");
    if (digits.length > rule.maxLen) return `${rule.label}: massimo ${rule.maxLen} cifre`;
    return null;
  }

  // text
  if (v.length > rule.maxLen) return `${rule.label}: massimo ${rule.maxLen} caratteri`;
  return null;
}

/** Run validation on a record of values. Returns map of fieldName → error. */
export function validateAll(values: Record<string, any>): Record<string, string> {
  const errors: Record<string, string> = {};
  for (const [name, rule] of Object.entries(FIELD_RULES)) {
    const err = validateField(rule, values[name]);
    if (err) errors[name] = err;
  }
  return errors;
}

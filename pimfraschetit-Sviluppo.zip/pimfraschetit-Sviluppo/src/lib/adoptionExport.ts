import * as XLSX from "xlsx";
import { jsPDF } from "jspdf";
import type { AdoptionCustomerRow } from "@/hooks/usePortalAdoption";

export const fmtAdoptionDate = (v: string | null | undefined) =>
  v ? new Date(v).toLocaleDateString("it-IT") : "—";

export const CUSTOMER_EXPORT_WIDTHS = [18, 68, 14, 42, 24, 12, 20, 22, 22, 26, 26];

export function customerExportRow(r: AdoptionCustomerRow) {
  return {
    Codice: r.code,
    "Ragione sociale": r.name,
    Zona: r.zone,
    Agente: r.agentName ? `${r.agent} - ${r.agentName}` : r.agent,
    "Attivo B2B dal": fmtAdoptionDate(r.activatedAt),
    VdC: r.vdcAttivo ? "Sì" : "No",
    "VdC con ordini": r.vdcOrdini ? "Sì" : "No",
    "Ordini cliente": r.ordiniCliente,
    "Ordini agente": r.ordiniAgente,
    "Ultimo ord. cliente": fmtAdoptionDate(r.ultimoOrdineCliente),
    "Ultimo ord. agente": fmtAdoptionDate(r.ultimoOrdineAgente),
  };
}

export function downloadCustomersExcel(
  filename: string,
  rows: AdoptionCustomerRow[],
  summary?: { name: string; rows: Record<string, any>[] },
) {
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(
    wb,
    XLSX.utils.json_to_sheet(rows.map(customerExportRow)),
    "Clienti",
  );
  if (summary && summary.rows.length) {
    XLSX.utils.book_append_sheet(
      wb,
      XLSX.utils.json_to_sheet(summary.rows),
      summary.name.slice(0, 31),
    );
  }
  XLSX.writeFile(wb, filename);
}

/**
 * PDF tabellare orizzontale dei clienti. Se `groupByAgent` è true inserisce
 * un'intestazione per ogni agente.
 */
export function downloadCustomersPdf(opts: {
  filename: string;
  title: string;
  subtitle?: string;
  rows: AdoptionCustomerRow[];
  groupByAgent?: boolean;
}) {
  const { filename, title, subtitle, rows, groupByAgent } = opts;
  const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
  const data = rows.map(customerExportRow);
  const headers = Object.keys(data[0] ?? customerExportRow({} as any));
  const widths = CUSTOMER_EXPORT_WIDTHS;
  const totalW = widths.reduce((a, b) => a + b, 0);
  const startX = 10;
  let y = 22;

  doc.setFontSize(14);
  doc.text(title, startX, 13);
  doc.setFontSize(9);
  doc.setTextColor(110);
  doc.text(
    `${subtitle ? subtitle + " · " : ""}${data.length} clienti · ${new Date().toLocaleDateString("it-IT")}`,
    startX,
    18,
  );
  doc.setTextColor(0);

  const drawHeader = () => {
    doc.setFillColor(15, 23, 42);
    doc.rect(startX, y - 5, totalW, 7, "F");
    doc.setTextColor(255);
    doc.setFontSize(7.5);
    let x = startX + 1.5;
    headers.forEach((h, i) => {
      doc.text(String(h), x, y);
      x += widths[i] ?? 20;
    });
    doc.setTextColor(0);
    y += 6;
  };

  const newPageIfNeeded = (needed = 5.5) => {
    if (y + needed > 200) {
      doc.addPage();
      y = 18;
      drawHeader();
      doc.setFontSize(7);
    }
  };

  drawHeader();
  doc.setFontSize(7);

  const drawRows = (list: typeof data, offset = 0) => {
    list.forEach((row, idx) => {
      newPageIfNeeded();
      if ((idx + offset) % 2 === 1) {
        doc.setFillColor(244, 246, 250);
        doc.rect(startX, y - 4, totalW, 5.5, "F");
      }
      let x = startX + 1.5;
      headers.forEach((h, i) => {
        const w = widths[i] ?? 20;
        const txt = String((row as any)[h] ?? "");
        doc.text(doc.splitTextToSize(txt, w - 3)[0] ?? "", x, y);
        x += w;
      });
      y += 5.5;
    });
  };

  if (groupByAgent) {
    const groups = new Map<string, AdoptionCustomerRow[]>();
    rows.forEach((r) => {
      const key = r.agentName ? `${r.agent} · ${r.agentName}` : r.agent || "—";
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(r);
    });
    Array.from(groups.entries())
      .sort((a, b) => a[0].localeCompare(b[0], "it"))
      .forEach(([label, list]) => {
        newPageIfNeeded(10);
        doc.setFillColor(226, 232, 240);
        doc.rect(startX, y - 4, totalW, 6, "F");
        doc.setFontSize(8);
        doc.text(`Agente ${label} — ${list.length} clienti`, startX + 1.5, y);
        y += 7;
        doc.setFontSize(7);
        drawRows(list.map(customerExportRow));
        y += 2;
      });
  } else {
    drawRows(data);
  }

  doc.save(filename);
}

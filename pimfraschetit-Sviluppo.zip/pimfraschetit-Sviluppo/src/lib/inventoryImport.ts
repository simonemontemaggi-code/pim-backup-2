// Parser per file TXT giacenze.
// Layout: prime 6 cifre = cdpar, poi 9 cifre + virgola + 2 decimali = quantità.
// Es. "001010000000289,00" → { cdpar: "001010", quantity: 289 }

export interface InventoryRow {
  cdpar: string;
  quantity: number;
}

export function parseInventoryTxt(text: string): InventoryRow[] {
  const rows: InventoryRow[] = [];
  const lines = text.split(/\r?\n/);

  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;

    const cdpar = line.slice(0, 6);
    if (!/^\d{6}$/.test(cdpar)) continue;

    // Cerca la quantità (numero con virgola decimale) nel resto della riga,
    // ignorando padding di spazi. Es. "001010                  000000289,00"
    const rest = line.slice(6);
    const match = rest.match(/(\d+),(\d{2})/);
    if (!match) continue;

    const normalized = `${match[1].replace(/^0+(?=\d)/, "")}.${match[2]}`;
    const qty = parseFloat(normalized);
    if (!Number.isFinite(qty)) continue;

    rows.push({
      cdpar,
      quantity: Math.round(qty * 100) / 100,
    });
  }

  return rows;
}

/**
 * Formatta una quantità rimuovendo zeri inutili a sinistra,
 * mantenendo sempre 2 decimali. Es. 289 → "289,00", 1234.5 → "1.234,50"
 */
export function formatQty(n: number | null | undefined): string {
  if (n === null || n === undefined || !Number.isFinite(n)) return "—";
  return n.toLocaleString("it-IT", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

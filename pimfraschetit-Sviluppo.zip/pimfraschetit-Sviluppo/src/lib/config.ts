export const COMPANY_NAME = "Fraschetti S.p.A.";

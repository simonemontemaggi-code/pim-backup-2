/**
 * AS400 stores dates as numeric YYYYMMDD (e.g. 20260401).
 * 0 / null / NaN → no date.
 */

export function yyyymmddToDate(n: number | string | null | undefined): Date | null {
  if (n === null || n === undefined || n === "" || n === 0 || n === "0") return null;
  const s = String(n).padStart(8, "0");
  if (s.length !== 8) return null;
  const y = parseInt(s.slice(0, 4), 10);
  const m = parseInt(s.slice(4, 6), 10);
  const d = parseInt(s.slice(6, 8), 10);
  if (!y || !m || !d) return null;
  const dt = new Date(y, m - 1, d);
  if (isNaN(dt.getTime())) return null;
  return dt;
}

export function dateToYyyymmdd(d: Date | null | undefined): number | null {
  if (!d) return null;
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return parseInt(`${y}${m}${day}`, 10);
}

export function yyyymmddToInputValue(n: number | string | null | undefined): string {
  const d = yyyymmddToDate(n);
  if (!d) return "";
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function inputValueToYyyymmdd(v: string): number | null {
  if (!v) return null;
  const m = v.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return null;
  return parseInt(`${m[1]}${m[2]}${m[3]}`, 10);
}

export function formatYyyymmddDisplay(n: number | string | null | undefined): string {
  const d = yyyymmddToDate(n);
  if (!d) return "—";
  return d.toLocaleDateString("it-IT");
}

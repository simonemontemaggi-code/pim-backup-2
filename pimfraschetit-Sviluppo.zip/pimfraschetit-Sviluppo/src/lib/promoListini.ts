/**
 * Gestione "listini ingrosso" per Promo Strutturate.
 *
 * Logica:
 * - Universo "listini base" = i 13 codici di vendita reali (no IVA, no costo).
 * - Su una promo testata, `wpinls`:
 *     - 'T' (Tutti)   → target = base
 *     - 'E' (Esclusi) → target = base \ excluded_listini
 * - Per ogni elemento della promo, esiste una riga in promo_strutturate_campagne
 *   per ciascun listino target (wpcdlsa).
 *
 * Relazioni DB (vedere mem://features/db-schema):
 *   campagne.wpprgta = testate.wpprgf  (NON wprogr!)
 *   campagne.wpprgea = elementi.wpprge
 *   campagne.wpcdlsa = numeric → padded "01".."99" lato UI/listini_vendita_testate
 */

import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";

/**
 * Universo "listini base" — modificabile in un solo posto.
 * Filtro applicato su listini_vendita_testate:
 *   cdlst NON inizia con A/B/C/F/H/J  AND  cdlst NOT IN ('90','91','99')
 */
export const BASE_LISTINI: readonly string[] = [
  "01", "02", "03", "04", "05", "06", "07",
  "10", "11", "12",
  "20",
  "51",
  "71",
];

/** Padding consistente: "1" → "01", "  3 " → "03". */
export function padCdlst(v: any): string {
  if (v === null || v === undefined) return "";
  const s = String(v).trim();
  if (!s) return "";
  return s.length === 1 ? `0${s}` : s;
}

export interface ListinoBase {
  cdlst: string;
  dslst: string;
}

/**
 * Recupera i listini base con descrizione da listini_vendita_testate.
 * Ordina per ordine di BASE_LISTINI.
 */
export function useListiniBase() {
  return useQuery({
    queryKey: ["promo_listini_base"],
    staleTime: 5 * 60 * 1000,
    queryFn: async (): Promise<ListinoBase[]> => {
      const { data, error } = await supabase
        .from("listini_vendita_testate")
        .select("cdlst, dslst")
        .in("cdlst", BASE_LISTINI as unknown as string[]);
      if (error) throw error;
      const map = new Map((data ?? []).map((r: any) => [r.cdlst, (r.dslst ?? "").trim()]));
      return BASE_LISTINI.map((cdlst) => ({
        cdlst,
        dslst: map.get(cdlst) ?? cdlst,
      }));
    },
  });
}

/**
 * Calcola i listini target di una testata.
 * - wpinls = 'T' → tutti i base
 * - wpinls = 'E' → base \ excluded_listini
 */
export function computeTargetListini(
  wpinls: string | null | undefined,
  excluded: string[] | null | undefined,
): string[] {
  const ex = new Set((excluded ?? []).map(padCdlst));
  if (wpinls === "E") return BASE_LISTINI.filter((c) => !ex.has(c));
  return [...BASE_LISTINI];
}

/* ───────────────────────── DB helpers ───────────────────────── */

/**
 * Restituisce, per la promo (identificata dal n° AS400 wpprgf),
 * la mappa elemento → set di listini già presenti in campagne.
 */
export async function fetchExistingCampagneByElement(
  wpprgf: number,
): Promise<Map<number, Set<string>>> {
  const { data, error } = await supabase
    .from("promo_strutturate_campagne")
    .select("wpprgea, wpcdlsa")
    .eq("wpprgta", wpprgf);
  if (error) throw error;
  const out = new Map<number, Set<string>>();
  for (const row of data ?? []) {
    const elem = Number((row as any).wpprgea);
    if (!Number.isFinite(elem)) continue;
    const code = padCdlst((row as any).wpcdlsa);
    if (!code) continue;
    if (!out.has(elem)) out.set(elem, new Set());
    out.get(elem)!.add(code);
  }
  return out;
}

/* ───────────────────────── ID generators ───────────────────────── */

async function nextWpprga(): Promise<number> {
  const { data, error } = await supabase
    .from("promo_strutturate_campagne")
    .select("wpprga")
    .order("wpprga", { ascending: false, nullsFirst: false })
    .limit(1)
    .maybeSingle();
  if (error) throw error;
  return Number((data as any)?.wpprga ?? 0) + 1;
}

/* ───────────────────────── Mutations ───────────────────────── */

/**
 * Genera le righe campagna per un nuovo elemento in base ai listini target.
 * Valori ereditati: wpdtvia/wpdtvfa = sell-out della testata.
 */
export async function generateCampagneForElemento(opts: {
  testataWpprgf: number;
  elementoWpprge: number;
  targetListini: string[];
  defaultDateInizio?: number | null;
  defaultDateFine?: number | null;
}): Promise<{ inserted: number; rows: any[] }> {
  if (opts.targetListini.length === 0) return { inserted: 0, rows: [] };
  let nextId = await nextWpprga();
  const rows = opts.targetListini.map((cdlst) => {
    const wpprga = nextId++;
    return {
      wpprga,
      wpprgta: opts.testataWpprgf,
      wpprgea: opts.elementoWpprge,
      wpcdlsa: Number(cdlst), // numeric in DB
      wpdtvia: opts.defaultDateInizio ?? 0,
      wpdtvfa: opts.defaultDateFine ?? 0,
    } as any;
  });
  const { data, error } = await supabase
    .from("promo_strutturate_campagne")
    .insert(rows)
    .select("*");
  if (error) throw error;
  return { inserted: rows.length, rows: data ?? rows };
}

export interface ReconcilePreviewItem {
  wpprge: number;
  toAdd: string[];
  toRemove: string[];
  existing: string[];
}

/**
 * Calcola il diff (per ogni elemento) tra listini attualmente presenti in campagne
 * e i nuovi listini target.
 */
export async function previewReconcile(
  testataWpprgf: number,
  newTarget: string[],
): Promise<{
  items: ReconcilePreviewItem[];
  totalAdd: number;
  totalRemove: number;
  affectedElements: number;
}> {
  const target = new Set(newTarget.map(padCdlst));
  const byElem = await fetchExistingCampagneByElement(testataWpprgf);
  const items: ReconcilePreviewItem[] = [];
  let totalAdd = 0;
  let totalRemove = 0;
  for (const [wpprge, existing] of byElem.entries()) {
    const toAdd = [...target].filter((c) => !existing.has(c));
    const toRemove = [...existing].filter((c) => !target.has(c));
    if (toAdd.length === 0 && toRemove.length === 0) continue;
    items.push({
      wpprge,
      toAdd,
      toRemove,
      existing: [...existing].sort(),
    });
    totalAdd += toAdd.length;
    totalRemove += toRemove.length;
  }
  return {
    items,
    totalAdd,
    totalRemove,
    affectedElements: items.length,
  };
}

/**
 * Applica la riconciliazione. Per ogni elemento:
 *  - DELETE righe campagne con wpcdlsa nei toRemove
 *  - INSERT righe per i toAdd
 * Ritorna conteggi reali.
 */
export async function applyReconcile(opts: {
  testataWpprgf: number;
  preview: ReconcilePreviewItem[];
  defaultDateInizio?: number | null;
  defaultDateFine?: number | null;
}): Promise<{ inserted: number; deleted: number }> {
  let inserted = 0;
  let deleted = 0;
  let nextId = await nextWpprga();

  for (const item of opts.preview) {
    if (item.toRemove.length > 0) {
      // wpcdlsa è string padded "01".."99" in DB
      const { error, count } = await supabase
        .from("promo_strutturate_campagne")
        .delete({ count: "exact" })
        .eq("wpprgta", opts.testataWpprgf)
        .eq("wpprgea", item.wpprge)
        .in("wpcdlsa", item.toRemove);
      if (error) throw error;
      deleted += count ?? item.toRemove.length;
    }
    if (item.toAdd.length > 0) {
      const rows = item.toAdd.map((cdlst) => ({
        wpprga: nextId++,
        wpprgta: opts.testataWpprgf,
        wpprgea: item.wpprge,
        wpcdlsa: cdlst,
        wpdtvia: opts.defaultDateInizio ?? 0,
        wpdtvfa: opts.defaultDateFine ?? 0,
      }));
      const { error } = await supabase
        .from("promo_strutturate_campagne")
        .insert(rows as any);
      if (error) throw error;
      inserted += rows.length;
    }
  }
  return { inserted, deleted };
}

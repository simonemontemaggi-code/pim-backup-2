import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 17 - NOMENCLATURA COMBINATA".
 *
 * Mapping STRICT per posizione (2 colonne): 1 cdpar | 2 cdncm
 * Target: `nomenclatura_combinata` (upsert per `cdpar`, 6 cifre con padding).
 */

export interface Q17Row {
  cdpar: string;
  cdncm: string | null;
}

const padCdpar = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  if (s === "") return null;
  return s.padStart(6, "0");
};

const toStr = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

export interface Q17ParseResult {
  headers: string[];
  rows: Q17Row[];
  warnings: string[];
}

export async function parseQuery17Xlsx(file: File): Promise<Q17ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < 2) warnings.push(`Attese 2 colonne, trovate ${headers.length}`);

  const rows: Q17Row[] = [];
  const seen = new Set<string>();
  let skipped = 0;
  let dupes = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const cdpar = padCdpar(r[0]);
    if (!cdpar) { skipped++; continue; }
    if (seen.has(cdpar)) { dupes++; continue; }
    seen.add(cdpar);
    rows.push({ cdpar, cdncm: toStr(r[1]) });
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (cdpar mancante)`);
  if (dupes > 0) warnings.push(`${dupes} duplicati su cdpar (tenuta la prima occorrenza)`);
  return { headers, rows, warnings };
}

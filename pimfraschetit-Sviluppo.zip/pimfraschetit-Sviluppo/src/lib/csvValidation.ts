import type { ImportType } from "./csvTemplates";
import { cdparKey, ATTR_DETTAGLIO_MAX_BLOCKS } from "./csvTemplates";

export interface CellIssue {
  field: string;
  message: string;
  level: "error" | "warning";
}

export interface RowValidation {
  rowIndex: number;
  status: "valid" | "warning" | "error";
  issues: CellIssue[];
}

export function validateRows(
  rows: Record<string, string>[],
  type: ImportType,
  existingKeys: Set<string>,
  extraContext?: { existingSettori?: Map<string, string>; pathToGamma?: Map<string, string | null> },
): RowValidation[] {
  const seenKeys = new Set<string>();
  const seenPairs = new Set<string>();

  return rows.map((row, rowIndex) => {
    const issues: CellIssue[] = [];

    if (type === "fornitori_buyer_dp") {
      const cdfor = (row.cdfor ?? "").trim();
      if (!cdfor) {
        issues.push({ field: "cdfor", message: "Campo obbligatorio", level: "error" });
      } else {
        if (seenKeys.has(cdfor)) issues.push({ field: "cdfor", message: "Duplicato nel CSV", level: "error" });
        if (!existingKeys.has(cdfor)) issues.push({ field: "cdfor", message: "Fornitore non trovato in archivio", level: "error" });
        seenKeys.add(cdfor);
      }
      if (!(row.buyer ?? "").trim() && !(row.demand_planner ?? "").trim()) {
        issues.push({ field: "buyer", message: "Né buyer né demand_planner valorizzati", level: "warning" });
      }
    }

    if (type === "articoli_settore_reparto_gamma") {
      const cdpar = cdparKey(row.cdpar);
      const clmer = (row.clmer ?? "").trim();
      const reparto = (row.reparto ?? "").trim();
      const gamma = (row.gamma ?? "").trim();
      if (!cdpar) {
        issues.push({ field: "cdpar", message: "Campo obbligatorio", level: "error" });
      } else {
        if (seenKeys.has(cdpar)) issues.push({ field: "cdpar", message: "Duplicato nel CSV", level: "error" });
        if (!existingKeys.has(cdpar)) issues.push({ field: "cdpar", message: "Articolo non trovato in archivio", level: "error" });
        seenKeys.add(cdpar);
      }
      // Se clmer valorizzato e diverso da quello in DB → warning (verrà propagato ad AS400)
      if (clmer && cdpar && existingKeys.has(cdpar) && extraContext?.existingSettori) {
        const dbSettore = extraContext.existingSettori.get(cdpar)?.trim();
        if (dbSettore && dbSettore !== clmer) {
          issues.push({ field: "clmer", message: `Settore cambia (DB: ${dbSettore} → ${clmer}, sarà inviato ad AS400)`, level: "warning" });
        }
      }
      if (!clmer && !reparto && !gamma) {
        issues.push({ field: "clmer", message: "Nessun campo valorizzato (settore/reparto/gamma)", level: "warning" });
      }
    }


    if (type === "articoli_scheda_prodotto") {
      const cdpar = cdparKey(row.cdpar);
      if (!cdpar) {
        issues.push({ field: "cdpar", message: "Campo obbligatorio", level: "error" });
      } else {
        if (seenKeys.has(cdpar)) issues.push({ field: "cdpar", message: "Duplicato nel CSV", level: "error" });
        if (!existingKeys.has(cdpar)) issues.push({ field: "cdpar", message: "Articolo non trovato in archivio", level: "error" });
        seenKeys.add(cdpar);
      }
      const hasAny =
        (row.titolo_b2b ?? "").trim() ||
        (row.descrizione_variante ?? "").trim() ||
        (row.descrizione_b2b ?? "").trim() ||
        (row.tags ?? "").trim();
      if (!hasAny) {
        issues.push({ field: "titolo_b2b", message: "Nessun campo valorizzato (titolo / variante / descrizione / tags)", level: "warning" });
      }
      if ((row.titolo_b2b ?? "").length > 255) {
        issues.push({ field: "titolo_b2b", message: "Titolo molto lungo (>255 caratteri)", level: "warning" });
      }
    }


    if (type === "attributi_gamma") {
      const path = (row.gamma ?? "").trim();
      const attributo = (row.attributo ?? "").trim();
      const varianti = (row.varianti ?? "").trim();
      if (!path) {
        issues.push({ field: "gamma", message: "Campo obbligatorio", level: "error" });
      } else if (extraContext?.pathToGamma) {
        const code = extraContext.pathToGamma.get(path);
        if (!code) issues.push({ field: "gamma", message: "Path non risolto a una gamma valida", level: "error" });
      }
      if (!attributo) {
        issues.push({ field: "attributo", message: "Campo obbligatorio", level: "error" });
      } else if (!/^[a-z][a-z0-9_]*$/i.test(attributo)) {
        issues.push({ field: "attributo", message: "Solo lettere/numeri/underscore (snake_case)", level: "warning" });
      }
      const pairKey = `${path}||${attributo}`;
      if (path && attributo) {
        if (seenPairs.has(pairKey)) {
          issues.push({ field: "attributo", message: "Coppia gamma+attributo duplicata nel CSV", level: "error" });
        }
        seenPairs.add(pairKey);
      }
      if (!varianti) {
        issues.push({ field: "varianti", message: "Nessuna variante: l'attributo sarà testo libero", level: "warning" });
      }
    }

    if (type === "articoli_attributi_dettaglio") {
      const sku = cdparKey(row.sku);
      if (!sku) {
        issues.push({ field: "sku", message: "Campo obbligatorio", level: "error" });
      } else {
        if (seenKeys.has(sku)) issues.push({ field: "sku", message: "SKU duplicato nel CSV", level: "error" });
        if (!existingKeys.has(sku)) issues.push({ field: "sku", message: "Articolo non trovato in archivio", level: "error" });
        seenKeys.add(sku);
      }

      let nonEmptyBlocks = 0;
      const seenAttrs = new Set<string>();
      for (let i = 1; i <= ATTR_DETTAGLIO_MAX_BLOCKS; i++) {
        const name = (row[`attributo_${i}`] ?? "").trim();
        const value = (row[`valore_${i}`] ?? "").trim();
        const required = (row[`obbligatorio_${i}`] ?? "").trim().toLowerCase();
        if (!name && !value) continue;
        nonEmptyBlocks++;
        if (!name) {
          issues.push({ field: `attributo_${i}`, message: "Nome attributo mancante", level: "error" });
          continue;
        }
        if (!/^[a-z][a-z0-9_]*$/i.test(name)) {
          issues.push({ field: `attributo_${i}`, message: `"${name}" non è snake_case valido`, level: "warning" });
        }
        if (seenAttrs.has(name)) {
          issues.push({ field: `attributo_${i}`, message: `Attributo "${name}" duplicato nella riga`, level: "warning" });
        }
        seenAttrs.add(name);
        if ((required === "si" || required === "sì" || required === "yes" || required === "true" || required === "1") && !value) {
          issues.push({ field: `valore_${i}`, message: `"${name}" è obbligatorio ma vuoto`, level: "warning" });
        }
      }
      if (nonEmptyBlocks === 0) {
        issues.push({ field: "attributo_1", message: "Nessun attributo valorizzato", level: "warning" });
      }
    }

    const hasError = issues.some((i) => i.level === "error");
    const hasWarning = issues.some((i) => i.level === "warning");

    return {
      rowIndex,
      status: hasError ? "error" : hasWarning ? "warning" : "valid",
      issues,
    };
  });
}

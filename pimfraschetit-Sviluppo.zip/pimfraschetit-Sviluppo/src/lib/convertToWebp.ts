/**
 * Converte un'immagine raster (PNG/JPG/...) in WebP lato client via Canvas.
 * Ritorna il file originale invariato se la conversione non è applicabile
 * (svg, gif, webp già, o browser senza supporto).
 */
export async function convertToWebp(
  file: File,
  opts: { quality?: number; maxWidth?: number } = {}
): Promise<File> {
  const quality = opts.quality ?? 0.85;
  const maxWidth = opts.maxWidth ?? 1920;

  // Skip casi non convertibili
  if (!file.type.startsWith("image/")) return file;
  if (file.type === "image/webp") return file;
  if (file.type === "image/svg+xml") return file;
  if (file.type === "image/gif") return file; // potrebbe essere animata, lascia stare

  try {
    const dataUrl = URL.createObjectURL(file);
    try {
      const img = await new Promise<HTMLImageElement>((resolve, reject) => {
        const el = new Image();
        el.onload = () => resolve(el);
        el.onerror = () => reject(new Error("image load failed"));
        el.src = dataUrl;
      });

      const scale = img.width > maxWidth ? maxWidth / img.width : 1;
      const w = Math.round(img.width * scale);
      const h = Math.round(img.height * scale);

      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d");
      if (!ctx) return file;
      ctx.drawImage(img, 0, 0, w, h);

      const blob: Blob | null = await new Promise((resolve) =>
        canvas.toBlob((b) => resolve(b), "image/webp", quality)
      );
      if (!blob || blob.type !== "image/webp") return file;

      const baseName = file.name.replace(/\.[^.]+$/, "");
      return new File([blob], `${baseName}.webp`, {
        type: "image/webp",
        lastModified: Date.now(),
      });
    } finally {
      URL.revokeObjectURL(dataUrl);
    }
  } catch {
    return file;
  }
}

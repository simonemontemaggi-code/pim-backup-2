/**
 * Netto Acq = Prezzo (wprsc)
 *   × (1 - ScA/100) × (1 - ScB/100) × (1 - ScC/100) × (1 - ScD/100) × (1 - ScE/100)
 *   × (1 + Magg/100)
 *   × (1 + Dazio/100) × (1 + Trasp/100) × (1 + Altro/100)
 * Tutti i valori sono percentuali.
 */
export function computeNetPrice(row: Record<string, any>): number {
  let p = Number(row.wprsc) || 0;
  for (const k of ["wscfa", "wscfb", "wscfc", "wscfd", "wscfe"]) {
    const sc = Number(row[k]) || 0;
    p = p * (1 - sc / 100);
  }
  const magg = Number(row.wmasc) || 0;
  p = p * (1 + magg / 100);
  // Dazio + Trasporto + Altro: SOMMATI prima di applicare (non sequenziali)
  const dazTraspAltro =
    (Number(row.wcpfa) || 0) + (Number(row.wcpfb) || 0) + (Number(row.wcpfc) || 0);
  p = p * (1 + dazTraspAltro / 100);
  return Math.round(p * 100000) / 100000;
}

export function computeSupplierCostBase(row: Record<string, any>): number {
  return computeStocPrice(row);
}


/**
 * Netto Stoc = Netto Acq / Fc.As. (fattore di conversione, NON percentuale).
 * Se Fc.As è 0 o mancante, ritorna Netto Acq invariato.
 */
export function computeStocPrice(row: Record<string, any>): number {
  const acq = computeNetPrice(row);
  const fc = Number(row.wfcas) || 0;
  if (!fc) return acq;
  return Math.round((acq / fc) * 100000) / 100000;
}

/**
 * Prezzo di Listino = Netto Stoc × (1 + Ricarico/100) × (1 + Ricarico Radd. List./100).
 */
export function computeListPriceFromStoc(stocPrice: number, ricarico: any, ricaricoRaddList: any): number {
  const factor = (1 + (Number(ricarico) || 0) / 100) * (1 + (Number(ricaricoRaddList) || 0) / 100);
  return Math.round(stocPrice * factor * 100) / 100;
}

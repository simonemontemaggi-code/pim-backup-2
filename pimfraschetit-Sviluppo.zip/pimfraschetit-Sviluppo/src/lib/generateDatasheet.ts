import { jsPDF } from "jspdf";
import { supabase } from "@/integrations/supabase/client";
import { COMPANY_NAME } from "./config";
import { toast } from "@/hooks/use-toast";

const DARK_BLUE: [number, number, number] = [30, 58, 95];
const LIGHT_BLUE: [number, number, number] = [232, 240, 254];
const ALT_ROW: [number, number, number] = [248, 250, 252];

export async function generateDatasheet(article: any, media: any[]) {
  const doc = new jsPDF("p", "mm", "a4");
  const pw = 210;
  const ph = 297;
  const margin = 15;
  const cw = pw - margin * 2;
  let y = margin;

  const today = new Date().toLocaleDateString("it-IT");
  const yyyymmdd = new Date().toISOString().slice(0, 10).replace(/-/g, "");

  // Fetch supplier name
  let supplierName = "";
  if (article.pcfor) {
    const { data } = await supabase.from("archivio_fornitori_fraschetti").select("rasfo").eq("cdfor", article.pcfor).single();
    supplierName = data?.rasfo ?? "";
  }

  // Fetch barcodes
  const { data: barcodes } = await supabase.from("archivio_codici_barre_fraschetti").select("wcpba").eq("wcdpa", article.cdpar);

  // ---- HEADER BAR ----
  doc.setFillColor(...DARK_BLUE);
  doc.rect(0, 0, pw, 22, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(10);
  doc.text(COMPANY_NAME, margin, 10);
  doc.setFontSize(16);
  doc.text("SCHEDA TECNICA", pw - margin, 10, { align: "right" });
  doc.setFontSize(8);
  doc.text(`Generata: ${today}`, margin, 18);
  doc.text(`Cod: ${article.cdpar}`, pw - margin, 18, { align: "right" });

  y = 28;

  // ---- PRODUCT INFO ----
  const primaryImg = media.find((m: any) => m.media_type === "image" && m.is_primary);
  const imgX = margin;
  const imgW = 55;
  const infoX = margin + imgW + 8;

  // Draw image placeholder or image
  doc.setDrawColor(200, 200, 200);
  doc.rect(imgX, y, imgW, imgW);
  if (primaryImg?.public_url) {
    try {
      const response = await fetch(primaryImg.public_url);
      const blob = await response.blob();
      const base64 = await blobToBase64(blob);
      doc.addImage(base64, "JPEG", imgX + 1, y + 1, imgW - 2, imgW - 2);
    } catch {
      doc.setFontSize(8);
      doc.setTextColor(150, 150, 150);
      doc.text("Immagine non disponibile", imgX + imgW / 2, y + imgW / 2, { align: "center" });
    }
  } else {
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.text("Nessuna immagine", imgX + imgW / 2, y + imgW / 2, { align: "center" });
  }

  // Info fields
  doc.setTextColor(0, 0, 0);
  const infoLines = [
    ["Codice", article.cdpar],
    ["Descrizione", article.depar ?? ""],
    ["Linea", article.lipro ?? ""],
    ["Settore", article.clmer ?? ""],
    ["Rif. Catalogo", article.nmcat ?? ""],
    ["Fornitore", supplierName],
  ];
  let iy = y + 6;
  infoLines.forEach(([label, value]) => {
    doc.setFontSize(8);
    doc.setFont("helvetica", "bold");
    doc.text(label + ":", infoX, iy);
    doc.setFont("helvetica", "normal");
    doc.text(String(value ?? ""), infoX + 30, iy);
    iy += 7;
  });

  y = Math.max(y + imgW + 5, iy + 5);

  // ---- DESCRIPTION ----
  drawSectionHeader(doc, margin, y, cw, "DESCRIZIONE PRODOTTO");
  y += 8;
  doc.setFontSize(9);
  doc.setTextColor(0, 0, 0);
  const desc = article.description_marketing || article.depar || "";
  const descLines = doc.splitTextToSize(desc, cw - 4);
  doc.text(descLines, margin + 2, y);
  y += descLines.length * 4.5 + 6;

  // ---- SPECIFICHE TECNICHE ----
  drawSectionHeader(doc, margin, y, cw, "SPECIFICHE TECNICHE");
  y += 8;

  const specs: [string, string][] = [
    ["UM Stoccaggio", article.unmis ?? ""],
    ["UM Tecnica", article.untec ?? ""],
    ["Imballo", article.wimba ?? ""],
    ["Settore", article.clmer ?? ""],
  ];

  // Add dynamic attributes
  if (article.attributes && typeof article.attributes === "object") {
    Object.entries(article.attributes).forEach(([k, v]) => {
      if (v) specs.push([k, String(v)]);
    });
  }

  specs.forEach(([label, value], i) => {
    if (i % 2 === 1) {
      doc.setFillColor(...ALT_ROW);
      doc.rect(margin, y - 3.5, cw, 5.5, "F");
    }
    doc.setFontSize(8);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(50, 50, 50);
    doc.text(label, margin + 3, y);
    doc.setFont("helvetica", "normal");
    doc.text(String(value), margin + cw / 2, y);
    y += 5.5;
  });

  y += 4;

  // ---- BARCODES ----
  if (barcodes && barcodes.length > 0) {
    drawSectionHeader(doc, margin, y, cw, "CODICI A BARRE");
    y += 8;
    doc.setFontSize(8);
    doc.setTextColor(0, 0, 0);
    doc.text(barcodes.map((b: any) => b.wcpba).filter(Boolean).join(", "), margin + 3, y);
    y += 6;
  }

  // ---- FOOTER ----
  doc.setFontSize(7);
  doc.setTextColor(120, 120, 120);
  doc.line(margin, ph - 15, pw - margin, ph - 15);
  doc.text(COMPANY_NAME, margin, ph - 10);
  doc.text(today, pw / 2, ph - 10, { align: "center" });
  doc.text("Pag. 1/1", pw - margin, ph - 10, { align: "right" });

  // Download PDF directly (window.open is blocked in iframes)
  const pdfBlob = doc.output("blob");
  const url = URL.createObjectURL(pdfBlob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `scheda_tecnica_${article.cdpar}_${yyyymmdd}.pdf`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  // Upload to storage — auxiliary tables/storage paths use the TRIMMED cdpar
  const cdparKey = (article.cdpar ?? "").trim();
  const storagePath = `articles/${cdparKey}/datasheets/scheda_tecnica_${cdparKey}_${yyyymmdd}.pdf`;
  const { error: uploadError } = await supabase.storage.from("pim-media").upload(storagePath, pdfBlob, { upsert: true, contentType: "application/pdf" });

  if (!uploadError) {
    const { data: urlData } = supabase.storage.from("pim-media").getPublicUrl(storagePath);

    // Upsert article_media
    const { data: existing } = await supabase
      .from("article_media" as any)
      .select("id")
      .eq("cdpar", cdparKey)
      .eq("media_type", "pdf_datasheet")
      .limit(1) as any;

    if (existing && existing.length > 0) {
      await supabase
        .from("article_media" as any)
        .update({ storage_path: storagePath, public_url: urlData.publicUrl, original_filename: `scheda_tecnica_${cdparKey}_${yyyymmdd}.pdf`, updated_at: new Date().toISOString() } as any)
        .eq("id", existing[0].id);
    } else {
      await supabase.from("article_media" as any).insert({
        cdpar: cdparKey,
        media_type: "pdf_datasheet",
        storage_path: storagePath,
        public_url: urlData.publicUrl,
        original_filename: `scheda_tecnica_${cdparKey}_${yyyymmdd}.pdf`,
      });
    }
  }

  toast({ title: "Scheda tecnica generata e salvata ✅" });
}

function drawSectionHeader(doc: jsPDF, x: number, y: number, w: number, text: string) {
  doc.setFillColor(...LIGHT_BLUE);
  doc.rect(x, y - 4, w, 7, "F");
  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(30, 58, 95);
  doc.text(text, x + 3, y);
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

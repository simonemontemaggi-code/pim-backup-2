import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 08 - LISTINI DI VENDITA CRITERI DI PREZZO".
 *
 * Estrazione AS400 aggiornata (21 colonne, mapping STRICT per posizione,
 * stesso ordine della SELECT):
 *   1 wcdpa | 2 wcdls | 3 wcdcv | 4 wcdcl
 *   5 wnrsc | 6 wmova
 *   7 wsm01 | 8 wsm02 | 9 wsm03 | 10 wsmim
 *   11 wcmri | 12 wcbve | 13 wvdim
 *   14 war01 | 15 wta01 | 16 wco01 | 17 wic01
 *   18 wfcsv
 *   19 wrcls | 20 wrccv | 21 wrccl
 *
 * Target: `listini_vendita_criteri_prezzo`.
 * Chiave naturale: (wcdpa, wcdls, wcdcv, wcdcl).
 */

export interface Q08Row {
  wcdpa: string;
  wcdls: string;
  wcdcv: string | null;
  wcdcl: string | null;
  wnrsc: string | null;
  wmova: string | null;
  wsm01: number | null;
  wsm02: number | null;
  wsm03: number | null;
  wsmim: string | null;
  wcmri: string | null;
  wcbve: string | null;
  wvdim: string | null;
  war01: string | null;
  wta01: string | null;
  wco01: string | null;
  wic01: string | null;
  wfcsv: number | null;
  wrcls: string | null;
  wrccv: string | null;
  wrccl: string | null;
}

const cleanKey = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

const padArticle = (raw: any): string | null => {
  const s = cleanKey(raw);
  if (!s) return null;
  return s.padStart(6, "0");
};

const toNum = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const n = typeof raw === "number" ? raw : Number(String(raw).replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

export interface Q08ParseResult {
  headers: string[];
  rows: Q08Row[];
  warnings: string[];
}

export async function parseQuery08Xlsx(file: File): Promise<Q08ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) =>
    h === null || h === undefined ? "" : String(h),
  );
  const warnings: string[] = [];
  if (headers.length < 21) warnings.push(`Attese 21 colonne, trovate ${headers.length}`);

  const rows: Q08Row[] = [];
  let skipped = 0;
  const seen = new Set<string>();
  let dupes = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const wcdpa = padArticle(r[0]);
    const wcdls = cleanKey(r[1]);
    if (!wcdpa || !wcdls) {
      skipped++;
      continue;
    }
    const wcdcv = cleanKey(r[2]);
    const wcdcl = cleanKey(r[3]);
    const key = `${wcdpa}|${wcdls}|${wcdcv ?? ""}|${wcdcl ?? ""}`;
    if (seen.has(key)) {
      dupes++;
      continue;
    }
    seen.add(key);
    rows.push({
      wcdpa,
      wcdls,
      wcdcv,
      wcdcl,
      wnrsc: cleanKey(r[4]),
      wmova: cleanKey(r[5]),
      wsm01: toNum(r[6]),
      wsm02: toNum(r[7]),
      wsm03: toNum(r[8]),
      wsmim: cleanKey(r[9]),
      wcmri: cleanKey(r[10]),
      wcbve: cleanKey(r[11]),
      wvdim: cleanKey(r[12]),
      war01: cleanKey(r[13]),
      wta01: cleanKey(r[14]),
      wco01: cleanKey(r[15]),
      wic01: cleanKey(r[16]),
      wfcsv: toNum(r[17]),
      wrcls: cleanKey(r[18]),
      wrccv: cleanKey(r[19]),
      wrccl: cleanKey(r[20]),
    });
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (chiavi mancanti)`);
  if (dupes > 0) warnings.push(`${dupes} duplicati nella chiave naturale (tenuta la prima occorrenza)`);
  return { headers, rows, warnings };
}

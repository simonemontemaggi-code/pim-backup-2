import { toast } from "sonner";
import { optimizePdf } from "./pdfOptimizer";

/**
 * If `file` is a PDF, run it through the optimizer and return a new File
 * with the compressed bytes. For non-PDFs, returns the original file.
 * Shows a toast with the size delta. Never throws — on failure, falls back
 * to the original file.
 */
export async function maybeOptimizePdf(file: File): Promise<File> {
  if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) {
    return file;
  }
  try {
    const res = await optimizePdf(file);
    const finalSize = res.blob.size;
    const saved = res.sizeOriginal - finalSize;
    const pct = res.sizeOriginal > 0 ? Math.round((saved / res.sizeOriginal) * 100) : 0;
    const fmt = (n: number) => `${(n / 1024 / 1024).toFixed(2)} MB`;
    // Se il risparmio è trascurabile (<50KB) usa l'originale: evita rischi di rendering.
    if (saved <= 50 * 1024) {
      return file;
    }
    toast.success(`PDF compresso: ${fmt(res.sizeOriginal)} → ${fmt(finalSize)} (-${pct}%)`);
    return new File([res.blob], file.name, { type: "application/pdf", lastModified: Date.now() });
  } catch {
    return file;
  }
}

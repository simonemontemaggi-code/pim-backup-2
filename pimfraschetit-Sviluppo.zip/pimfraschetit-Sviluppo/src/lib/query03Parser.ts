import * as XLSX from "xlsx";

/**
 * Parser per "QUERY 03 - ARCHIVIO CODICI A BARRE".
 *
 * Mapping STRICT per posizione (14 colonne):
 *   1 wcdpa | 2 wcpba | 3 wgebi | 4 wcmab | 5 wplub | 6 wcbda | 7 wcbds
 *   8 wderd | 9 wlotto | 10 wprim | 11 wprime | 12 wimbc | 13 wcofl | 14 wtpco
 *
 * Target table: `archivio_codici_barre_fraschetti`.
 * Natural key: (wcdpa, wcpba).
 */

export interface Q03Row {
  wcdpa: string;
  wcpba: string;
  wgebi: string | null;
  wcmab: string | null;
  wplub: string | null;
  wcbda: string | null;
  wcbds: string | null;
  wderd: string | null;
  wlotto: string | null;
  wprim: number | null;
  wprime: number | null;
  wimbc: number | null;
  wcofl: string | null;
  wtpco: string | null;
}

const cleanText = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

const cleanKey = (raw: any): string | null => {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  return s === "" ? null : s;
};

const cleanNumber = (raw: any): number | null => {
  if (raw === null || raw === undefined || raw === "") return null;
  const n = typeof raw === "number" ? raw : parseFloat(String(raw).replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

const cleanInt = (raw: any): number | null => {
  const n = cleanNumber(raw);
  return n === null ? null : Math.trunc(n);
};

export interface Q03ParseResult {
  headers: string[];
  rows: Q03Row[];
  warnings: string[];
}

export async function parseQuery03Xlsx(file: File): Promise<Q03ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const matrix = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: null, raw: true });
  if (matrix.length === 0) return { headers: [], rows: [], warnings: ["Foglio vuoto"] };

  const headers = (matrix[0] ?? []).map((h: any) => (h === null || h === undefined ? "" : String(h)));
  const warnings: string[] = [];
  if (headers.length < 14) warnings.push(`Attese 14 colonne, trovate ${headers.length}`);

  const rows: Q03Row[] = [];
  let skipped = 0;
  for (let i = 1; i < matrix.length; i++) {
    const r = matrix[i] ?? [];
    const wcdpa = cleanKey(r[0]);
    const wcpba = cleanKey(r[1]);
    if (!wcdpa || !wcpba) { skipped++; continue; }
    rows.push({
      wcdpa,
      wcpba,
      wgebi: cleanText(r[2]),
      wcmab: cleanText(r[3]),
      wplub: cleanText(r[4]),
      wcbda: cleanText(r[5]),
      wcbds: cleanText(r[6]),
      wderd: cleanText(r[7]),
      wlotto: cleanText(r[8]),
      wprim: cleanNumber(r[9]),
      wprime: cleanNumber(r[10]),
      wimbc: cleanInt(r[11]),
      wcofl: cleanText(r[12]),
      wtpco: cleanText(r[13]),
    });
  }
  if (skipped > 0) warnings.push(`${skipped} righe scartate (wcdpa o wcpba mancanti)`);
  return { headers, rows, warnings };
}

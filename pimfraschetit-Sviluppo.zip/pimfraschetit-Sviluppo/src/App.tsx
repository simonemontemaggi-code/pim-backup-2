import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { DialogsProvider } from "@/components/ui/confirm-dialog";
import { AuthGuard } from "@/components/auth/AuthGuard";
import { AppShell } from "@/components/layout/AppShell";
import { SectionGuard } from "@/components/auth/SectionGuard";
import LoginPage from "./pages/LoginPage";
import PimDashboard from "./pages/PimDashboard";
import ArticlesPage from "./pages/ArticlesPage";
import ArticleDetailPage from "./pages/ArticleDetailPage";
import SuppliersPage from "./pages/SuppliersPage";
import PriceListsPage from "./pages/PriceListsPage";
import SyncQueuePage from "./pages/SyncQueuePage";
import ImportPage from "./pages/ImportPage";
import MediaLibraryPage from "./pages/MediaLibraryPage";
import SdsImportPage from "./pages/SdsImportPage";
import AdminPage from "./pages/AdminPage";
import AdminUsersPage from "./pages/AdminUsersPage";
import AdminPermissionsPage from "./pages/AdminPermissionsPage";
import AdminAuditPage from "./pages/AdminAuditPage";
import AdminSettingsPage from "./pages/AdminSettingsPage";

import AdminEmailTemplatesPage from "./pages/AdminEmailTemplatesPage";
import AdminAiPromptsPage from "./pages/AdminAiPromptsPage";
import AdminCurrenciesPage from "./pages/AdminCurrenciesPage";
import AdminCatalogSearchPage from "./pages/AdminCatalogSearchPage";
import AdminReportsPage from "./pages/AdminReportsPage";
import AdminReportDetailPage from "./pages/AdminReportDetailPage";
import BarcodesPage from "./pages/BarcodesPage";
import ControlsPage from "./pages/ControlsPage";
import ControlsPrezziAttesaPage from "./pages/ControlsPrezziAttesaPage";
import ControlsB2bSenzaPrezzoPage from "./pages/ControlsB2bSenzaPrezzoPage";
import ControlsArticoliSenzaImmaginePage from "./pages/controls/ControlsArticoliSenzaImmaginePage";
import ControlsArticoliSenzaListinoPage from "./pages/controls/ControlsArticoliSenzaListinoPage";
import ControlsArticoliSenzaDescrizionePage from "./pages/controls/ControlsArticoliSenzaDescrizionePage";
import ControlsArticoliSenzaSchedaTecnicaPage from "./pages/controls/ControlsArticoliSenzaSchedaTecnicaPage";
import ControlsArticoliSenzaAttributiObbligatoriPage from "./pages/controls/ControlsArticoliSenzaAttributiObbligatoriPage";
import ControlsArticoliSenzaAttributiPage from "./pages/controls/ControlsArticoliSenzaAttributiPage";
import ControlsArticoliSettorePage from "./pages/controls/ControlsArticoliSettorePage";
import ControlsArticoliClmerLegacyPage from "./pages/controls/ControlsArticoliClmerLegacyPage";
import ControlsArticoliSenzaRepartoPage from "./pages/controls/ControlsArticoliSenzaRepartoPage";
import ControlsArticoliSenzaGammaPage from "./pages/controls/ControlsArticoliSenzaGammaPage";
import { ControlsFornitoriSenzaBuyerPage, ControlsFornitoriSenzaDemandPlannerPage } from "./pages/controls/ControlsFornitoriPages";
import ControlsBrandSenzaImmaginiPage from "./pages/controls/ControlsBrandSenzaImmaginiPage";
import B2bBrandsListPage from "./pages/B2bBrandsListPage";
import B2bBrandEditorPage from "./pages/B2bBrandEditorPage";
import B2bTaxonomyPage from "./pages/B2bTaxonomyPage";
import B2bHeroSliderPage from "./pages/B2bHeroSliderPage";
import B2bPromosPage from "./pages/B2bPromosPage";
import B2bAssortmentsPage from "./pages/B2bAssortmentsPage";
import B2bAssortmentArticlesPage from "./pages/B2bAssortmentArticlesPage";
import B2bNovitaPage from "./pages/B2bNovitaPage";
import B2bCatalogsPage from "./pages/B2bCatalogsPage";
import B2bCatalogHotspotsPage from "./pages/B2bCatalogHotspotsPage";
import PromoStrutturatePage from "./pages/PromoStrutturatePage";
import B2bPromoOrderPage from "./pages/B2bPromoOrderPage";
import B2bCommunicationsPage from "./pages/B2bCommunicationsPage";
import B2bCommunicationEditorPage from "./pages/B2bCommunicationEditorPage";
import AgentNewsPage from "./pages/AgentNewsPage";
import AgentNewsEditorPage from "./pages/AgentNewsEditorPage";
import B2bTicketsPage from "./pages/B2bTicketsPage";
import CustomersPage from "./pages/CustomersPage";
import CustomerDetailPage from "./pages/CustomerDetailPage";
import AgentsPage from "./pages/AgentsPage";
import SalesDashboardPage from "./pages/SalesDashboardPage";
import SalesOrdersPage from "./pages/SalesOrdersPage";
import SalesUntreatedOrdersPage from "./pages/SalesUntreatedOrdersPage";
import SalesPromoControlPage from "./pages/SalesPromoControlPage";
import ScadenziarioPage from "./pages/ScadenziarioPage";
import PublicCatalogPage from "./pages/PublicCatalogPage";
import NavigationAnalysisPage from "./pages/NavigationAnalysisPage";
import PortalAdoptionPage from "./pages/PortalAdoptionPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <DialogsProvider>
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route path="/c/:slug" element={<PublicCatalogPage />} />
            <Route path="/" element={<Navigate to="/pim" replace />} />
            <Route
              path="/pim"
              element={
                <AuthGuard>
                  <AppShell />
                </AuthGuard>
              }
            >
              <Route index element={<SectionGuard section="pim_dashboard" redirectTo="/pim/articles"><PimDashboard /></SectionGuard>} />
              <Route path="articles" element={<ArticlesPage />} />
              <Route path="articles/:cdpar" element={<ArticleDetailPage />} />
              <Route path="suppliers" element={<SuppliersPage />} />
              <Route path="price-lists" element={<PriceListsPage />} />
              <Route path="barcodes" element={<BarcodesPage />} />
              <Route path="sync" element={<SyncQueuePage />} />
              <Route path="import" element={<ImportPage />} />
              <Route path="media" element={<MediaLibraryPage />} />
              <Route path="media/import-sds" element={<SdsImportPage />} />
              <Route path="controls" element={<SectionGuard section="operations_controls" redirectTo="/pim"><ControlsPage /></SectionGuard>} />
              <Route path="controls/prezzi-attesa" element={<SectionGuard section="controls_prezzi"><ControlsPrezziAttesaPage /></SectionGuard>} />
              <Route path="controls/b2b-senza-prezzo" element={<SectionGuard section="controls_prezzi"><ControlsB2bSenzaPrezzoPage /></SectionGuard>} />
              <Route path="controls/articoli/senza-immagine" element={<SectionGuard section="controls_articoli_content"><ControlsArticoliSenzaImmaginePage /></SectionGuard>} />
              <Route path="controls/articoli/senza-descrizione" element={<SectionGuard section="controls_articoli_content"><ControlsArticoliSenzaDescrizionePage /></SectionGuard>} />
              <Route path="controls/articoli/senza-scheda-tecnica" element={<SectionGuard section="controls_articoli_content"><ControlsArticoliSenzaSchedaTecnicaPage /></SectionGuard>} />
              <Route path="controls/articoli/senza-attributi-obbligatori" element={<SectionGuard section="controls_articoli_content"><ControlsArticoliSenzaAttributiObbligatoriPage /></SectionGuard>} />
              <Route path="controls/articoli/senza-attributi" element={<SectionGuard section="controls_articoli_content"><ControlsArticoliSenzaAttributiPage /></SectionGuard>} />
              <Route path="controls/articoli/senza-listino" element={<SectionGuard section="controls_prezzi"><ControlsArticoliSenzaListinoPage /></SectionGuard>} />
              <Route path="controls/articoli/settore/:settore" element={<SectionGuard section="controls_articoli_classificazione"><ControlsArticoliSettorePage /></SectionGuard>} />
              <Route path="controls/articoli/clmer-legacy" element={<SectionGuard section="controls_articoli_classificazione"><ControlsArticoliClmerLegacyPage /></SectionGuard>} />
              <Route path="controls/articoli/senza-reparto" element={<SectionGuard section="controls_articoli_classificazione"><ControlsArticoliSenzaRepartoPage /></SectionGuard>} />
              <Route path="controls/articoli/senza-gamma" element={<SectionGuard section="controls_articoli_classificazione"><ControlsArticoliSenzaGammaPage /></SectionGuard>} />
              <Route path="controls/fornitori/senza-buyer" element={<SectionGuard section="controls_fornitori_brand"><ControlsFornitoriSenzaBuyerPage /></SectionGuard>} />
              <Route path="controls/fornitori/senza-demand-planner" element={<SectionGuard section="controls_fornitori_brand"><ControlsFornitoriSenzaDemandPlannerPage /></SectionGuard>} />
              <Route path="controls/brand/senza-immagini" element={<SectionGuard section="controls_fornitori_brand"><ControlsBrandSenzaImmaginiPage /></SectionGuard>} />

              <Route path="b2b/brands" element={<B2bBrandsListPage />} />
              <Route path="b2b/brands/:clas2" element={<B2bBrandEditorPage />} />
              <Route path="b2b/taxonomy" element={<B2bTaxonomyPage />} />
              <Route path="b2b/hero-slider" element={<B2bHeroSliderPage />} />
              <Route path="b2b/promos" element={<B2bPromosPage />} />
              <Route path="b2b/assortments" element={<B2bAssortmentsPage />} />
              <Route path="b2b/assortments/:id/articles" element={<B2bAssortmentArticlesPage />} />
              <Route path="b2b/novita" element={<B2bNovitaPage />} />
              <Route path="b2b/catalogs" element={<B2bCatalogsPage />} />
              <Route path="b2b/catalogs/:id/hotspots" element={<B2bCatalogHotspotsPage />} />
              <Route path="b2b/promo-order" element={<B2bPromoOrderPage />} />
              <Route path="b2b/communications" element={<B2bCommunicationsPage />} />
              <Route path="b2b/communications/:id" element={<B2bCommunicationEditorPage />} />
              <Route path="agent-news" element={<SectionGuard section="agent_news" redirectTo="/pim"><AgentNewsPage /></SectionGuard>} />
              <Route path="agent-news/:id" element={<SectionGuard section="agent_news" redirectTo="/pim"><AgentNewsEditorPage /></SectionGuard>} />
              <Route path="b2b/tickets" element={<B2bTicketsPage />} />
              <Route path="promo-strutturate" element={<PromoStrutturatePage />} />
              <Route path="customers" element={<CustomersPage />} />
              <Route path="customers/:id" element={<CustomerDetailPage />} />
              <Route path="agents" element={<AgentsPage />} />
              <Route path="sales" element={<SalesDashboardPage />} />
              <Route path="sales/orders" element={<SalesOrdersPage />} />
              <Route path="sales/untreated" element={<SalesUntreatedOrdersPage />} />
              <Route path="sales/promo-control" element={<SectionGuard section="sales_promo_control" redirectTo="/pim"><SalesPromoControlPage /></SectionGuard>} />

              <Route path="scadenziario" element={<ScadenziarioPage />} />
              <Route path="reports" element={<SectionGuard section="admin_reports" redirectTo="/pim"><AdminReportsPage /></SectionGuard>} />
              <Route path="reports/:id" element={<SectionGuard section="admin_reports" redirectTo="/pim"><AdminReportDetailPage /></SectionGuard>} />
              <Route path="navigation-analysis" element={<SectionGuard section="navigation_analysis" redirectTo="/pim"><NavigationAnalysisPage /></SectionGuard>} />
              <Route path="analytics/adozione-portale" element={<SectionGuard section="portal_adoption" redirectTo="/pim"><PortalAdoptionPage /></SectionGuard>} />
              <Route path="admin" element={<AdminPage />}>
                <Route index element={<Navigate to="users" replace />} />
                <Route path="users" element={<AdminUsersPage />} />
                <Route path="permissions" element={<AdminPermissionsPage />} />
                <Route path="audit" element={<AdminAuditPage />} />
                <Route path="currencies" element={<AdminCurrenciesPage />} />
                <Route path="ai-prompts" element={<AdminAiPromptsPage />} />
                <Route path="email-templates" element={<AdminEmailTemplatesPage />} />
                <Route path="settings" element={<AdminSettingsPage />} />
                <Route path="catalog-search" element={<AdminCatalogSearchPage />} />
                <Route path="reports" element={<Navigate to="/pim/reports" replace />} />
                <Route path="reports/:id" element={<Navigate to="/pim/reports" replace />} />


              </Route>
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
          </DialogsProvider>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;

import { useCallback, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { CatalogoCartaRow } from "@/lib/catalogoCartaParser";

export interface CatalogoCartaImportStats {
  total: number;
  updated: number;
  unchanged: number;
  missing: number;
}

const CHUNK_SIZE = 1000;

export function useCatalogoCartaImport() {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stats, setStats] = useState<CatalogoCartaImportStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async (rows: CatalogoCartaRow[]) => {
    setIsRunning(true);
    setProgress(0);
    setError(null);
    setStats(null);
    const agg: CatalogoCartaImportStats = { total: 0, updated: 0, unchanged: 0, missing: 0 };
    try {
      for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
        const chunk = rows.slice(i, i + CHUNK_SIZE);
        const { data, error: rpcErr } = await supabase.rpc(
          "import_catalogo_carta" as any,
          { p_rows: chunk as any },
        );
        if (rpcErr) throw rpcErr;
        const r = (data ?? {}) as CatalogoCartaImportStats;
        agg.total += r.total ?? 0;
        agg.updated += r.updated ?? 0;
        agg.unchanged += r.unchanged ?? 0;
        agg.missing += r.missing ?? 0;
        setProgress(Math.min(100, ((i + chunk.length) / rows.length) * 100));
        setStats({ ...agg });
      }
      setProgress(100);
    } catch (e: any) {
      console.error("[CatalogoCarta Import] errore:", e);
      setError(e?.message ?? "Errore import");
    } finally {
      setIsRunning(false);
    }
  }, []);

  const reset = useCallback(() => {
    setStats(null);
    setProgress(0);
    setError(null);
    setIsRunning(false);
  }, []);

  return { run, reset, isRunning, progress, stats, error };
}

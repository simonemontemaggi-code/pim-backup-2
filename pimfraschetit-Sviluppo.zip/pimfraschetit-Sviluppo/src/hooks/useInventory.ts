import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface InventoryRecord {
  cdpar: string;
  quantity: number;
  updated_at: string;
}

export interface InventoryHistoryRecord {
  id: string;
  cdpar: string;
  quantity_old: number | null;
  quantity_new: number;
  delta: number;
  source: string;
  user_email: string | null;
  user_id: string | null;
  created_at: string;
}

export function useInventory(cdpar: string | undefined) {
  return useQuery({
    queryKey: ["article_inventory", cdpar],
    queryFn: async () => {
      const key = (cdpar ?? "").trim().slice(0, 6);
      if (!key) return null;
      const { data, error } = await supabase
        .from("article_inventory" as any)
        .select("cdpar, quantity, updated_at")
        .eq("cdpar", key)
        .maybeSingle();
      if (error) throw error;
      return (data as unknown as InventoryRecord) ?? null;
    },
    enabled: !!cdpar,
    staleTime: 60_000,
  });
}

export function useInventoryHistory(cdpar: string | undefined, limit = 50) {
  return useQuery({
    queryKey: ["article_inventory_history", cdpar, limit],
    queryFn: async () => {
      const key = (cdpar ?? "").trim().slice(0, 6);
      if (!key) return [];
      const { data, error } = await supabase
        .from("article_inventory_history" as any)
        .select("id, cdpar, quantity_old, quantity_new, delta, source, user_email, user_id, created_at")
        .eq("cdpar", key)
        .order("created_at", { ascending: false })
        .limit(limit);
      if (error) throw error;
      return (data ?? []) as unknown as InventoryHistoryRecord[];
    },
    enabled: !!cdpar,
    staleTime: 60_000,
  });
}

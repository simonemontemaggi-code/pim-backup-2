import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type CustomerRequestStatus = "pending" | "approved" | "rejected";

export interface CustomerRequest {
  id: string;
  status: CustomerRequestStatus;
  agent_user_id: string | null;
  agent_profile_id: string | null;
  agent_code: string | null;
  agent_name: string | null;
  agent_email: string | null;
  ragione_sociale: string | null;
  partita_iva: string | null;
  codice_fiscale: string | null;
  indirizzo: string | null;
  cap: string | null;
  citta: string | null;
  provincia: string | null;
  zona: string | null;
  telefono_negozio: string | null;
  email: string | null;
  pec: string | null;
  codice_sdi: string | null;
  giorno_chiusura: string | null;
  note_scarico: string | null;
  diversa_destinazione: string | null;
  nome_referente: string | null;
  cellulare_referente: string | null;
  categoria: string | null;
  importanza: string | null;
  giorno_visita: string | null;
  frequenza_visite: string | null;
  grossisti_concorrenti: string | null;
  fornitori_presenti: string | null;
  vendite_online: string | null;
  presenza_pc: string | null;
  note_varie: string | null;
  modalita_pagamento: string | null;
  modalita_altro: string | null;
  descrizione_pagamento: string | null;
  banca: string | null;
  filiale: string | null;
  iban: string | null;
  assigned_customer_code: string | null;
  assigned_zona: string | null;
  assigned_price_list: string | null;
  rejection_reason: string | null;
  review_notes: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
  updated_at: string | null;
}

const TABLE = "nuovi_clienti_richieste" as const;

function hasAgentInfo(r: Pick<CustomerRequest, "agent_name" | "agent_code" | "agent_email">) {
  return Boolean(
    (r.agent_name && r.agent_name.trim()) ||
      (r.agent_code && String(r.agent_code).trim()) ||
      (r.agent_email && r.agent_email.trim()),
  );
}

async function fillMissingAgentInfo(rows: CustomerRequest[]): Promise<CustomerRequest[]> {
  // Build local map from rows that already have info
  const map = new Map<string, { agent_name: string | null; agent_code: string | null; agent_email: string | null }>();
  for (const r of rows) {
    if (r.agent_user_id && hasAgentInfo(r) && !map.has(r.agent_user_id)) {
      map.set(r.agent_user_id, {
        agent_name: r.agent_name,
        agent_code: r.agent_code,
        agent_email: r.agent_email,
      });
    }
  }

  // Missing user_ids we still need to resolve
  const missing = Array.from(
    new Set(
      rows
        .filter((r) => r.agent_user_id && !hasAgentInfo(r) && !map.has(r.agent_user_id!))
        .map((r) => r.agent_user_id!),
    ),
  );

  if (missing.length > 0) {
    const { data: siblings } = await supabase
      .from(TABLE as any)
      .select("agent_user_id, agent_name, agent_code, agent_email, created_at")
      .in("agent_user_id", missing)
      .or("agent_name.neq.,agent_code.not.is.null,agent_email.not.is.null")
      .order("created_at", { ascending: false })
      .limit(1000);
    for (const s of (siblings ?? []) as any[]) {
      if (s.agent_user_id && !map.has(s.agent_user_id) && hasAgentInfo(s)) {
        map.set(s.agent_user_id, {
          agent_name: s.agent_name,
          agent_code: s.agent_code,
          agent_email: s.agent_email,
        });
      }
    }
  }

  return rows.map((r) => {
    if (!r.agent_user_id || hasAgentInfo(r)) return r;
    const info = map.get(r.agent_user_id);
    if (!info) return r;
    return {
      ...r,
      agent_name: r.agent_name || info.agent_name,
      agent_code: r.agent_code || info.agent_code,
      agent_email: r.agent_email || info.agent_email,
    };
  });
}

export function useCustomerRequestsList(status: CustomerRequestStatus) {
  useCustomerRequestsRealtime();
  return useQuery({
    queryKey: ["customer-requests", "list", status],
    queryFn: async () => {
      const { data, error } = await supabase
        .from(TABLE as any)
        .select("*")
        .eq("status", status)
        .order("created_at", { ascending: false })
        .limit(500);
      if (error) throw error;
      const rows = (data ?? []) as unknown as CustomerRequest[];
      return await fillMissingAgentInfo(rows);
    },
  });
}

export function useCustomerRequestsPendingCount() {
  useCustomerRequestsRealtime();
  return useQuery({
    queryKey: ["customer-requests", "count", "pending"],
    queryFn: async () => {
      const { count, error } = await supabase
        .from(TABLE as any)
        .select("id", { count: "exact", head: true })
        .eq("status", "pending");
      if (error) throw error;
      return count ?? 0;
    },
  });
}

let realtimeSubscribers = 0;
let realtimeChannel: ReturnType<typeof supabase.channel> | null = null;

export function useCustomerRequestsRealtime() {
  const qc = useQueryClient();
  useEffect(() => {
    realtimeSubscribers += 1;
    if (!realtimeChannel) {
      realtimeChannel = supabase
        .channel("customer-requests")
        .on(
          "postgres_changes" as any,
          { event: "*", schema: "public", table: TABLE },
          () => {
            qc.invalidateQueries({ queryKey: ["customer-requests"] });
          },
        )
        .subscribe();
    }
    return () => {
      realtimeSubscribers -= 1;
      if (realtimeSubscribers <= 0 && realtimeChannel) {
        supabase.removeChannel(realtimeChannel);
        realtimeChannel = null;
        realtimeSubscribers = 0;
      }
    };
  }, [qc]);
}

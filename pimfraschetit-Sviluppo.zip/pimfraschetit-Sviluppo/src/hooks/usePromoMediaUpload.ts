import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { maybeOptimizePdf } from "@/lib/maybeOptimizePdf";
import { convertToWebp } from "@/lib/convertToWebp";

export function usePromoMediaUpload() {
  const [uploading, setUploading] = useState(false);

  /** Carica un file nel bucket `promo-media` e ritorna la URL pubblica. */
  const upload = async (file: File, path: string): Promise<string | null> => {
    setUploading(true);
    try {
      // Le immagini raster vengono convertite in WebP lato client (più leggere).
      const converted = file.type.startsWith("image/") ? await convertToWebp(file) : file;
      const ext = converted.name.split(".").pop()?.toLowerCase() || "jpg";
      const finalPath = path.endsWith(`.${ext}`) ? path : `${path}.${ext}`;
      const toUpload = await maybeOptimizePdf(converted);
      const { error } = await supabase.storage
        .from("promo-media")
        .upload(finalPath, toUpload, { upsert: true, cacheControl: "3600", contentType: converted.type || undefined });
      if (error) throw error;
      const { data } = supabase.storage.from("promo-media").getPublicUrl(finalPath);
      // cache-bust per forzare refresh nel browser
      return `${data.publicUrl}?v=${Date.now()}`;
    } catch (e: any) {
      toast({ title: "Errore upload", description: e.message, variant: "destructive" });
      return null;
    } finally {
      setUploading(false);
    }
  };

  /** Estrae il path interno al bucket dalla URL pubblica e lo elimina. */
  const remove = async (publicUrl: string | null) => {
    if (!publicUrl) return;
    try {
      const m = publicUrl.match(/\/promo-media\/(.+?)(\?.*)?$/);
      if (!m) return;
      await supabase.storage.from("promo-media").remove([m[1]]);
    } catch (e) {
      console.warn("promo-media remove failed", e);
    }
  };

  return { upload, remove, uploading };
}

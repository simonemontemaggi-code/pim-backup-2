import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type ScontoFatturaPromo = {
  id: string;
  wpprgf: number;
  wpcca: string | null;
  wptpbd: string | null;
  wpdvali: number | null;
  wpdvalf: number | null;
};

export type PromoTema = {
  id: string;
  wpprgf: number;
  nome: string | null;
  descrizione: string | null;
  tipo: string | null;
  sconto_pct: number | null;
  qty_min: number | null;
  righe_valore_min: number | null;
  scaglioni_qty_unit: "pezzi" | "confezioni" | null;
};

export type PromoTemaScaglione = {
  id: string;
  tema_id: string;
  soglia_qty: number | null;
  soglia_eur: number | null;
  soglia_righe: number | null;
  sconto_pct: number | null;
  sort_order: number | null;
};

export type PromoTemaArticolo = {
  tema_id: string;
  cdpar: string; // 6 digits, trimmed
  master_pack: number | null;
  imballo_vendita: number | null; // wimba: pezzi per confezione di vendita
  variabile: boolean; // wfcvr === 'S' → confezione apribile, conta 1 pz = 1 conf
};


export function useScontoFatturaPromos() {
  return useQuery({
    queryKey: ["sconto_fattura_promos"],
    queryFn: async (): Promise<ScontoFatturaPromo[]> => {
      const { data, error } = await supabase
        .from("promo_strutturate_testate")
        .select("id, wpprgf, wpcca, wptpbd, wpdvali, wpdvalf")
        .eq("offerta_sconto_fattura", true)
        .order("wpdvali", { ascending: false });
      if (error) throw error;
      return (data ?? []).map((r: any) => ({
        id: r.id,
        wpprgf: Number(r.wpprgf),
        wpcca: r.wpcca,
        wptpbd: r.wptpbd,
        wpdvali: r.wpdvali ?? null,
        wpdvalf: r.wpdvalf ?? null,
      }));
    },
  });
}

export function usePromoTemi(wpprgf: number | null) {
  return useQuery({
    queryKey: ["sconto_fattura_temi", wpprgf],
    enabled: wpprgf != null,
    queryFn: async (): Promise<PromoTema[]> => {
      const { data, error } = await supabase
        .from("promo_strutturate_temi")
        .select("id, wpprgf, nome, descrizione, tipo, sconto_pct, qty_min, righe_valore_min, scaglioni_qty_unit")
        .eq("wpprgf", wpprgf!)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return (data ?? []) as any;
    },
  });
}

export function usePromoTemaArticoli(temaIds: string[]) {
  const key = temaIds.slice().sort().join(",");
  return useQuery({
    queryKey: ["sconto_fattura_tema_articoli", key],
    enabled: temaIds.length > 0,
    queryFn: async (): Promise<PromoTemaArticolo[]> => {
      const { data, error } = await supabase
        .from("promo_strutturate_tema_articoli")
        .select("tema_id, cdpar")
        .in("tema_id", temaIds);
      if (error) throw error;
      const rows = (data ?? []) as any[];
      const codes = Array.from(new Set(rows.map((r) => String(r.cdpar).trim()).filter(Boolean)));
      const artMap = new Map<string, { master_pack: number | null; imballo_vendita: number | null; variabile: boolean }>();
      if (codes.length > 0) {
        const lookup = Array.from(new Set(codes.flatMap((c) => [c, c.padStart(6, "0")])));
        const { data: arts } = await supabase
          .from("archivio_articoli_fraschetti")
          .select("cdpar, master_pack, wimba, wfcvr")
          .in("cdpar", lookup);
        for (const a of (arts ?? []) as any[]) {
          artMap.set(String(a.cdpar).trim(), {
            master_pack: a.master_pack ?? null,
            imballo_vendita: a.wimba ?? null,
            variabile: String(a.wfcvr ?? "").trim().toUpperCase() === "S",
          });
        }
      }
      return rows.map((r) => {
        const cd = String(r.cdpar).trim();
        const a = artMap.get(cd);
        return {
          tema_id: r.tema_id,
          cdpar: cd,
          master_pack: a?.master_pack ?? null,
          imballo_vendita: a?.imballo_vendita ?? null,
          variabile: a?.variabile ?? false,
        };
      });
    },

  });
}

export function usePromoTemaScaglioni(temaIds: string[]) {
  const key = temaIds.slice().sort().join(",");
  return useQuery({
    queryKey: ["sconto_fattura_tema_scaglioni", key],
    enabled: temaIds.length > 0,
    queryFn: async (): Promise<PromoTemaScaglione[]> => {
      const { data, error } = await supabase
        .from("promo_strutturate_tema_scaglioni")
        .select("id, tema_id, soglia_qty, soglia_eur, soglia_righe, sconto_pct, sort_order")
        .in("tema_id", temaIds)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return (data ?? []) as any;
    },
  });
}

import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/** Returns both padded (15ch) and trimmed variants so .in() and search filtering both match. */
function expandCdparVariants(cdpars: (string | null | undefined)[]): string[] {
  const out = new Set<string>();
  for (const c of cdpars) {
    if (!c) continue;
    out.add(c);
    const trimmed = c.trim();
    if (trimmed) {
      out.add(trimmed);
      out.add(trimmed.padEnd(15, " "));
    }
  }
  return Array.from(out);
}


export interface PromoOption {
  wpprgf: number;
  wpcca: string;
  label: string;
}

export interface TemaOption {
  id: string;
  nome: string;
  wpprgf: number;
}

/** Lists all active promo testate (wpstato = 'V'). */
export function usePromoOptions() {
  return useQuery({
    queryKey: ["promo-filter-options"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("promo_strutturate_testate")
        .select("wpprgf, wpcca, wptpbd, wpstato")
        .order("wpprgf", { ascending: false })
        .limit(500);
      if (error) throw error;
      return (data ?? []).map((r: any) => {
        const codice = (r.wpcca ?? "").trim();
        const nome = (r.wptpbd ?? "").trim();
        const label = nome
          ? (codice ? `${codice} · ${nome}` : nome)
          : (codice || "(senza nome)");
        return {
          wpprgf: Number(r.wpprgf),
          wpcca: r.wpcca ?? "",
          label,
        };
      }) as PromoOption[];
    },
    staleTime: 60_000,
  });
}

/** Lists temi (offerte) optionally filtered to the selected promo wpprgf list. */
export function useTemaOptions(promoWpprgfs: number[]) {
  return useQuery({
    queryKey: ["tema-filter-options", promoWpprgfs],
    queryFn: async () => {
      let q = supabase
        .from("promo_strutturate_temi")
        .select("id, nome, wpprgf")
        .order("sort_order", { ascending: true });
      if (promoWpprgfs.length > 0) q = q.in("wpprgf", promoWpprgfs);
      const { data, error } = await q.limit(1000);
      if (error) throw error;
      return (data ?? []).map((r: any) => ({
        id: r.id,
        nome: r.nome ?? "(senza nome)",
        wpprgf: Number(r.wpprgf),
      })) as TemaOption[];
    },
    staleTime: 60_000,
  });
}

/**
 * Returns cdpars array when at least one promo/tema is selected, else undefined.
 * - If temaIds is set: only cdpars from those temi.
 * - Else if promoWpprgfs is set: union of cdpars from promo_strutturate_articoli
 *   AND from temi belonging to those promo.
 */
export function usePromoFilterCdpars(promoWpprgfs: number[], temaIds: string[]) {
  return useQuery({
    queryKey: ["promo-filter-cdpars", promoWpprgfs, temaIds],
    queryFn: async () => {
      if (temaIds.length > 0) {
        const { data, error } = await supabase
          .from("promo_strutturate_tema_articoli")
          .select("cdpar")
          .in("tema_id", temaIds)
          .limit(10000);
        if (error) throw error;
        return expandCdparVariants((data ?? []).map((r: any) => r.cdpar));
      }

      if (promoWpprgfs.length > 0) {
        // Get tema ids for these promo first (no FK in DB -> can't use nested select)
        const { data: temi, error: tErr } = await supabase
          .from("promo_strutturate_temi")
          .select("id")
          .in("wpprgf", promoWpprgfs)
          .limit(5000);
        if (tErr) throw tErr;
        const allTemaIds = (temi ?? []).map((t: any) => t.id);

        const [aRes, taRes] = await Promise.all([
          supabase
            .from("promo_strutturate_articoli")
            .select("cdpar")
            .in("wpprgf", promoWpprgfs)
            .limit(10000),
          allTemaIds.length > 0
            ? supabase
                .from("promo_strutturate_tema_articoli")
                .select("cdpar")
                .in("tema_id", allTemaIds)
                .limit(10000)
            : Promise.resolve({ data: [], error: null } as any),
        ]);
        if (aRes.error) throw aRes.error;
        if (taRes.error) throw taRes.error;
        const set = new Set<string>();
        const all: string[] = [];
        (aRes.data ?? []).forEach((r: any) => { if (r.cdpar) all.push(r.cdpar); });
        (taRes.data ?? []).forEach((r: any) => { if (r.cdpar) all.push(r.cdpar); });
        return expandCdparVariants(all);
      }
      return null;
    },
    enabled: promoWpprgfs.length > 0 || temaIds.length > 0,
    staleTime: 30_000,
  });
}

import { useEffect, useState } from "react";

export const CONTROLS_FILTER_OPTIONS = ["A", "B", "C", "E", "G", "N", "O"];
export const CONTROLS_FILTER_DEFAULTS = ["C", "E", "G", "N", "O"];
const STORAGE_KEY = "controls_assortment_filter";
const EVENT = "controls_assortment_filter_changed";

function read(): string[] {
  if (typeof window === "undefined") return CONTROLS_FILTER_DEFAULTS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return CONTROLS_FILTER_DEFAULTS;
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.every((x) => typeof x === "string")) return parsed;
  } catch {}
  return CONTROLS_FILTER_DEFAULTS;
}

export function useControlsFilter() {
  const [selected, setSelected] = useState<string[]>(read);

  useEffect(() => {
    const handler = () => setSelected(read());
    window.addEventListener(EVENT, handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener(EVENT, handler);
      window.removeEventListener("storage", handler);
    };
  }, []);

  const update = (next: string[]) => {
    setSelected(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      window.dispatchEvent(new Event(EVENT));
    } catch {}
  };

  const toggle = (code: string) =>
    update(selected.includes(code) ? selected.filter((c) => c !== code) : [...selected, code]);

  const reset = () => update(CONTROLS_FILTER_DEFAULTS);

  return { selected, toggle, reset, setSelected: update };
}

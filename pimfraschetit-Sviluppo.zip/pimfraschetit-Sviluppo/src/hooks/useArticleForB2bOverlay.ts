import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface B2bOverlayArticle {
  cdpar: string;
  title: string;
  description: string | null;
  brand: string | null;
  ean: string | null;
  unit: string | null;
  attributes: Record<string, any> | null;
  images: { url: string; isPrimary: boolean }[];
}

/**
 * Carica un articolo PIM con dati B2B (titolo, descrizione, immagini).
 * Usato dall'overlay del flipbook (anteprima PIM).
 */
export function useArticleForB2bOverlay(cdpar: string | null | undefined) {
  return useQuery({
    queryKey: ["b2b-overlay-article", cdpar],
    enabled: !!cdpar,
    queryFn: async (): Promise<B2bOverlayArticle | null> => {
      if (!cdpar) return null;
      const padded = cdpar.padEnd(15, " ");
      const trimmed = cdpar.trim();

      // articolo
      const { data: art, error: aErr } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar, depar, lipro, clmer, barcd, unmis, attributes, titolo_b2b, descrizione_b2b, b2b_product_title, b2b_product_description")
        .or(`cdpar.eq.${padded},cdpar.eq.${trimmed}`)
        .maybeSingle();
      if (aErr) throw aErr;
      if (!art) return null;

      // media — article_media memorizza cdpar trimmato, archivio lo ha paddato a 15
      const artCdpar = art.cdpar.trim();
      const { data: media } = await supabase
        .from("article_media")
        .select("public_url, is_primary, media_type, sort_order, cdpar")
        .in("cdpar", [artCdpar, art.cdpar])
        .eq("media_type", "image")
        .order("is_primary", { ascending: false })
        .order("sort_order", { ascending: true });

      const images = (media ?? [])
        .filter((m: any) => !!m.public_url)
        .map((m: any) => ({ url: m.public_url as string, isPrimary: !!m.is_primary }));

      return {
        cdpar: art.cdpar.trim(),
        title: (art.b2b_product_title || art.titolo_b2b || art.depar || "").trim(),
        description: art.b2b_product_description || art.descrizione_b2b || art.lipro || null,
        brand: art.clmer || null,
        ean: art.barcd || null,
        unit: art.unmis || null,
        attributes: (art.attributes as Record<string, any> | null) ?? null,
        images,
      };
    },
  });
}

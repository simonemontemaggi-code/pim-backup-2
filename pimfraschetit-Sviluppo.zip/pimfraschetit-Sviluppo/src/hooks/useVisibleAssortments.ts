import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function useVisibleAssortments() {
  return useQuery({
    queryKey: ["app_settings", "visible_assortments"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings")
        .select("setting_value")
        .eq("setting_key", "visible_assortments")
        .maybeSingle();
      if (error) throw error;
      if (!data?.setting_value) return [];
      const val = data.setting_value;
      return Array.isArray(val) ? (val as string[]) : [];
    },
    staleTime: 300_000,
  });
}

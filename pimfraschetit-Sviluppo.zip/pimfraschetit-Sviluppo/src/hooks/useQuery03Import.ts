import { useCallback, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Q03Row } from "@/lib/query03Parser";

export interface Q03ImportStats {
  total: number;
  updated: number;
  inserted: number;
  unchanged: number;
}

const CHUNK_SIZE = 3000;

export function useQuery03Import() {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stats, setStats] = useState<Q03ImportStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async (rows: Q03Row[]) => {
    setIsRunning(true);
    setProgress(0);
    setError(null);
    setStats(null);
    const agg: Q03ImportStats = { total: 0, updated: 0, inserted: 0, unchanged: 0 };
    try {
      for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
        const chunk = rows.slice(i, i + CHUNK_SIZE);
        const { data, error: rpcErr } = await supabase.rpc(
          "import_query03_codici_barre" as any,
          { p_rows: chunk as any },
        );
        if (rpcErr) throw rpcErr;
        const r = (data ?? {}) as Q03ImportStats;
        agg.total += r.total ?? 0;
        agg.updated += r.updated ?? 0;
        agg.inserted += r.inserted ?? 0;
        agg.unchanged += r.unchanged ?? 0;
        setProgress(Math.min(100, ((i + chunk.length) / rows.length) * 100));
        setStats({ ...agg });
      }
      setProgress(100);
    } catch (e: any) {
      console.error("[Q03 Import] errore:", e);
      setError(e?.message ?? "Errore import");
    } finally {
      setIsRunning(false);
    }
  }, []);

  const reset = useCallback(() => {
    setStats(null);
    setProgress(0);
    setError(null);
    setIsRunning(false);
  }, []);

  return { run, reset, isRunning, progress, stats, error };
}

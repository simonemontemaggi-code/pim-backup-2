import { useCallback, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Q16Row } from "@/lib/query16Parser";

export interface Q16ImportStats {
  total: number;
  matched: number;
  updated: number;
  unchanged: number;
  missing: number;
}

const CHUNK_SIZE = 1000;

export function useQuery16Import() {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stats, setStats] = useState<Q16ImportStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async (rows: Q16Row[]) => {
    setIsRunning(true);
    setProgress(0);
    setError(null);
    setStats(null);
    const agg: Q16ImportStats = { total: 0, matched: 0, updated: 0, unchanged: 0, missing: 0 };
    try {
      for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
        const chunk = rows.slice(i, i + CHUNK_SIZE);
        const { data, error: rpcErr } = await supabase.rpc(
          "import_query16_testate" as any,
          { p_rows: chunk as any },
        );
        if (rpcErr) throw rpcErr;
        const r = (data ?? {}) as Q16ImportStats;
        agg.total += r.total ?? 0;
        agg.matched += r.matched ?? 0;
        agg.updated += r.updated ?? 0;
        agg.unchanged += r.unchanged ?? 0;
        agg.missing += r.missing ?? 0;
        setProgress(Math.min(100, ((i + chunk.length) / rows.length) * 100));
        setStats({ ...agg });
      }
      setProgress(100);
    } catch (e: any) {
      console.error("[Q16 Import] errore:", e);
      setError(e?.message ?? "Errore import");
    } finally {
      setIsRunning(false);
    }
  }, []);

  const reset = useCallback(() => {
    setStats(null);
    setProgress(0);
    setError(null);
    setIsRunning(false);
  }, []);

  return { run, reset, isRunning, progress, stats, error };
}

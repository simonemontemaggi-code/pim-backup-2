import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface LookupValue {
  id: string;
  category: string;
  code: string;
  label: string | null;
  sort_order: number;
  is_active: boolean;
  synced_as400: boolean;
  parent_category: string | null;
  parent_code: string | null;
  image_url: string | null;
  description: string | null;
}

export function useLookupValues(category?: string) {
  return useQuery({
    queryKey: ["lookup_values", category],
    queryFn: async () => {
      let q = supabase
        .from("lookup_values")
        .select("*")
        .eq("is_active", true)
        .order("sort_order")
        .order("code");
      if (category) q = q.eq("category", category);
      const { data, error } = await q;
      if (error) throw error;
      const values = (data ?? []) as LookupValue[];
      values.sort((a, b) => {
        if (a.sort_order !== b.sort_order) return a.sort_order - b.sort_order;
        const aNum = Number(a.code);
        const bNum = Number(b.code);
        if (!isNaN(aNum) && !isNaN(bNum)) return aNum - bNum;
        return a.code.localeCompare(b.code, undefined, { numeric: true });
      });
      return values;
    },
    staleTime: 10 * 60 * 1000,
    gcTime: 30 * 60 * 1000,
  });
}

// Categories that should always appear even if empty
const REQUIRED_CATEGORIES = ["clmer", "reparto", "gamma", "attributi", "buyer", "demand_planner"];

export function useLookupCategories() {
  return useQuery({
    queryKey: ["lookup_categories"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("lookup_values")
        .select("category")
        .order("category");
      if (error) throw error;
      const dbCats = [...new Set((data ?? []).map((r: any) => r.category))];
      const allCats = [...new Set([...dbCats, ...REQUIRED_CATEGORIES])];
      allCats.sort();
      return allCats;
    },
    staleTime: 10 * 60 * 1000,
    gcTime: 30 * 60 * 1000,
  });
}

export function useAddLookupValue() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (val: { category: string; code: string; label?: string; parent_category?: string; parent_code?: string }) => {
      const { error } = await supabase.from("lookup_values").insert({
        category: val.category,
        code: val.code,
        label: val.label ?? val.code,
        synced_as400: false,
        parent_category: val.parent_category ?? null,
        parent_code: val.parent_code ?? null,
      });
      if (error) throw error;
    },
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ["lookup_values", vars.category] });
      qc.invalidateQueries({ queryKey: ["lookup_values"] });
      qc.invalidateQueries({ queryKey: ["lookup_categories"] });
    },
  });
}

export function useUpdateLookupValue() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (val: { id: string; label?: string; code?: string; sort_order?: number; is_active?: boolean; synced_as400?: boolean; image_url?: string | null; description?: string | null }) => {
      const { id, ...updates } = val;
      const { error } = await supabase.from("lookup_values").update(updates).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["lookup_values"] });
    },
  });
}

export function useDeleteLookupValue() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("lookup_values").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["lookup_values"] });
      qc.invalidateQueries({ queryKey: ["lookup_categories"] });
    },
  });
}

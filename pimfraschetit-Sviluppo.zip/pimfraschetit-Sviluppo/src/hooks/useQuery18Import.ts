import { useCallback, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Q18Row } from "@/lib/query18Parser";

export interface Q18ImportStats {
  total: number;
  inserted: number;
  updated: number;
  unchanged: number;
  reactivated: number;
}

const CHUNK_SIZE = 1000;

export function useQuery18Import() {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stats, setStats] = useState<Q18ImportStats | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [deactivated, setDeactivated] = useState<number | null>(null);

  const run = useCallback(async (rows: Q18Row[]) => {
    setIsRunning(true);
    setProgress(0);
    setError(null);
    setStats(null);
    setDeactivated(null);
    const agg: Q18ImportStats = { total: 0, inserted: 0, updated: 0, unchanged: 0, reactivated: 0 };
    try {
      for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
        const chunk = rows.slice(i, i + CHUNK_SIZE);
        const { data, error: rpcErr } = await supabase.rpc(
          "import_query18_fornitori" as any,
          { p_rows: chunk as any },
        );
        if (rpcErr) throw rpcErr;
        const r = (data ?? {}) as Q18ImportStats;
        agg.total += r.total ?? 0;
        agg.inserted += r.inserted ?? 0;
        agg.updated += r.updated ?? 0;
        agg.unchanged += r.unchanged ?? 0;
        agg.reactivated += r.reactivated ?? 0;
        setProgress(Math.min(100, ((i + chunk.length) / rows.length) * 100));
        setStats({ ...agg });
      }
      setProgress(100);
    } catch (e: any) {
      console.error("[Q18 Import] errore:", e);
      setError(e?.message ?? "Errore import");
    } finally {
      setIsRunning(false);
    }
  }, []);

  const deactivateMissing = useCallback(async (rows: Q18Row[]) => {
    setError(null);
    try {
      const codes = rows.map(r => r.cdfor);
      const { data, error: rpcErr } = await supabase.rpc(
        "deactivate_query18_missing" as any,
        { p_codes: codes as any },
      );
      if (rpcErr) throw rpcErr;
      setDeactivated((data as any)?.deactivated ?? 0);
    } catch (e: any) {
      console.error("[Q18 Deactivate] errore:", e);
      setError(e?.message ?? "Errore deactivate");
    }
  }, []);

  const reset = useCallback(() => {
    setStats(null);
    setProgress(0);
    setError(null);
    setIsRunning(false);
    setDeactivated(null);
  }, []);

  return { run, deactivateMissing, reset, isRunning, progress, stats, error, deactivated };
}

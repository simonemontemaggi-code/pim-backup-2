import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useVisibleAssortments } from "./useVisibleAssortments";

const LIST_COLUMNS = "id,cdpar,depar,wfuas,clmer,lipro,pcfor,clas2,unmis,as400_sync_status,barcd,updated_at,attributes,b2b_online_active,b2b_online_effective";

const DETAIL_COLUMNS = "id,cdpar,depar,clmer,lipro,pcfor,unmis,cdiva,nmcat,barcd,nmdis,cdst1,clas1,clas2,wcdst,untec,umfat,umalt,umfaa,wimba,wdset,wdeag,wfuas,wstag,wclve,wvvii,wfcvr,wfcs1,wfc2x,wumrf,description_marketing,description_ecommerce,seo_title,seo_description,tags,attributes,as400_sync_status,updated_at,updated_by,b2b_online_active,b2b_online_effective,b2b_product_title,b2b_product_description,descrizione_variante,cod_padre,master_pack,catalogo_carta_titolo,catalogo_carta_dettaglio,catalogo_carta_scheda";

const PAGE_SIZE = 25;

interface ArticleFilters {
  search?: string;
  clmer?: string[];
  lipro?: string[];
  reparto?: string[];
  gamma?: string[];
  wfuas?: string[];
  pcfor?: string[];
  clas2?: string[];
  cdpars?: string[]; // restrict to these cdpars (e.g. promo filter)
  page?: number;
}

export function useArticles(filters: ArticleFilters = {}) {
  const { search, clmer, lipro, reparto, gamma, wfuas, pcfor, clas2, cdpars, page = 0 } = filters;

  const { data: visibleAssortments } = useVisibleAssortments();

  return useQuery({
    queryKey: ["articles", search, clmer, lipro, reparto, gamma, wfuas, pcfor, clas2, cdpars, page, visibleAssortments],
    queryFn: async () => {
      // Empty cdpar filter explicitly requested -> no results
      if (cdpars && cdpars.length === 0) {
        return { data: [], count: 0, pageSize: PAGE_SIZE };
      }
      // Build two views of the cdpar filter:
      //  - cdparDbList: values for `.in("cdpar", ...)` against archivio_articoli_fraschetti,
      //    which stores cdpar PADDED to 15 chars. Include raw + padded variants.
      //  - cdparTrimSet: trimmed values for client-side filtering (e.g. after RPC search).
      let cdparDbList: string[] | null = null;
      let cdparTrimSet: Set<string> | null = null;
      if (cdpars && cdpars.length > 0) {
        const dbSet = new Set<string>();
        const trimSet = new Set<string>();
        for (const c of cdpars) {
          if (!c) continue;
          const trimmed = c.trim();
          if (!trimmed) continue;
          const variants = new Set<string>([trimmed]);
          // Excel spesso rimuove gli zeri iniziali dai codici numerici (es. 013002 -> 13002).
          // Se è tutto numerico e più corto di 6, ricostruisci la forma zero-padded a 6.
          if (/^\d+$/.test(trimmed) && trimmed.length < 6) {
            variants.add(trimmed.padStart(6, "0"));
          }
          for (const v of variants) {
            trimSet.add(v);
            dbSet.add(v);
            dbSet.add(v.padEnd(15, " "));
          }
          dbSet.add(c);
        }
        cdparDbList = Array.from(dbSet);
        cdparTrimSet = trimSet;
      }

      if (search && search.trim().length >= 1) {
        const { data, error } = await supabase.rpc("search_articles", {
          query: search,
          filter_clmer: clmer?.[0] || null,
          filter_lipro: lipro?.[0] || null,
          filter_wfuas: wfuas?.[0] || null,
          lim: PAGE_SIZE,
          off: page * PAGE_SIZE,
        });
        if (error) throw error;
        let rows = (data ?? []) as any[];
        if (visibleAssortments && visibleAssortments.length > 0) {
          rows = rows.filter((r: any) => visibleAssortments.includes(r.wfuas));
        }
        // Client-side multi-filter for search results
        if (clmer && clmer.length > 0) rows = rows.filter((r: any) => clmer.includes(r.clmer));
        if (reparto && reparto.length > 0) rows = rows.filter((r: any) => reparto.includes(r.attributes?.reparto));
        if (gamma && gamma.length > 0) rows = rows.filter((r: any) => gamma.includes(r.attributes?.gamma));
        if (pcfor && pcfor.length > 0) {
          const pcforTrim = new Set(pcfor.map((c) => c.trim()));
          rows = rows.filter((r: any) => pcforTrim.has((r.pcfor ?? "").trim()));
        }
        if (wfuas && wfuas.length > 0) rows = rows.filter((r: any) => wfuas.includes(r.wfuas));
        if (clas2 && clas2.length > 0) {
          const clas2Trim = new Set(clas2.map((c) => c.trim()));
          rows = rows.filter((r: any) => clas2Trim.has((r.clas2 ?? "").trim()));
        }
        if (cdparTrimSet) {
          rows = rows.filter((r: any) => cdparTrimSet!.has((r.cdpar ?? "").trim()));
        }
        const count = rows.length > 0 ? Number(rows[0].total_count) : 0;
        return { data: rows, count, pageSize: PAGE_SIZE };
      }

      let query = supabase
        .from("archivio_articoli_fraschetti")
        .select(LIST_COLUMNS, { count: "exact" });

      // Visible assortments
      if (visibleAssortments && visibleAssortments.length > 0) {
        if (wfuas && wfuas.length > 0) {
          const intersection = wfuas.filter((v) => visibleAssortments.includes(v));
          if (intersection.length > 0) {
            query = query.in("wfuas", intersection);
          } else {
            query = query.in("wfuas", ["__none__"]);
          }
        } else {
          query = query.in("wfuas", visibleAssortments);
        }
      } else if (wfuas && wfuas.length > 0) {
        query = query.in("wfuas", wfuas);
      }

      if (clmer && clmer.length > 0) query = query.in("clmer", clmer);
      if (lipro && lipro.length > 0) query = query.in("lipro", lipro);
      if (reparto && reparto.length > 0) query = query.in("attributes->>reparto", reparto);
      if (gamma && gamma.length > 0) query = query.in("attributes->>gamma", gamma);
      if (pcfor && pcfor.length > 0) {
        const expanded = Array.from(
          new Set(pcfor.flatMap((c) => {
            const t = c.trim();
            return [t, t.padEnd(6, " ")];
          }))
        );
        query = query.in("pcfor", expanded);
      }
      if (clas2 && clas2.length > 0) {
        const expanded = Array.from(
          new Set(clas2.flatMap((c) => {
            const t = c.trim();
            return [t, t.padEnd(6, " "), t.padEnd(10, " ")];
          }))
        );
        query = query.in("clas2", expanded);
      }

      if (cdparDbList) {
        // cdparDbList contains raw + trimmed + 15-char padded variants
        query = query.in("cdpar", cdparDbList);
      }

      const from = page * PAGE_SIZE;
      query = query.range(from, from + PAGE_SIZE - 1).order("cdpar");

      const { data, error, count } = await query;
      if (error) throw error;
      return { data: data ?? [], count: count ?? 0, pageSize: PAGE_SIZE };
    },
    staleTime: 30_000,
    placeholderData: (prev) => prev,
  });
}

export function useArticle(cdpar: string | undefined) {
  return useQuery({
    queryKey: ["article", cdpar],
    queryFn: async () => {
      if (!cdpar) return null;
      // Master table stores cdpar PADDED to 15 chars with trailing spaces.
      // Always lookup ONLY the padded version to avoid matching legacy short rows.
      const padded = cdpar.trim().padEnd(15, " ");
      const { data, error } = await supabase
        .from("archivio_articoli_fraschetti")
        .select(DETAIL_COLUMNS)
        .eq("cdpar", padded)
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!cdpar,
    staleTime: 5 * 60 * 1000,
    gcTime: 15 * 60 * 1000,
  });
}

export function useDistinctValues(column: "clmer" | "lipro" | "wfuas" | "pcfor" | "clas2") {
  return useQuery({
    queryKey: ["distinct", column],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("distinct_column_values", {
        col_name: column,
      });
      if (error) throw error;
      return (data ?? []) as string[];
    },
    staleTime: 300_000,
  });
}

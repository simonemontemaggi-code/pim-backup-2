import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

export interface Customer {
  id: string;
  customer_code: string;
  company_name: string;
  company_name_aux: string | null;
  company_full_name: string | null;
  original_agent_code: string | null;
  zone_code: string | null;
  city: string | null;
  province: string | null;
  billing_customer_code: string | null;
  postal_code: string | null;
  vat_number: string | null;
  category_merch: string | null;
  category_sales: string | null;
  phone: string | null;
  address: string | null;
  tax_code: string | null;
  price_list_code: string | null;
  delivery_address: string | null;
  delivery_postal_code: string | null;
  delivery_city: string | null;
  delivery_province: string | null;
  email: string | null;
  last_import_at: string | null;
  notes: string | null;

  // PIM-only editable
  pec: string | null;
  sdi_code: string | null;
  closing_day: string | null;
  delivery_notes: string | null;
  contact_name: string | null;
  contact_mobile: string | null;
  importance: string | null;
  visit_day: string | null;
  visit_frequency: string | null;
  competitors: string | null;
  suppliers_present: string | null;
  sells_online: boolean | null;
  has_pc: boolean | null;
  payment_method: string | null;
  bank_name: string | null;
  bank_branch: string | null;
  iban: string | null;
  pim_notes: string | null;
  pim_updated_at: string | null;
  pim_updated_by: string | null;

  // B2B portal access (read-only, gestita dal portale B2B)
  mail_accesso_cliente: string | null;
  auth_user_id: string | null;
  activated_at: string | null;
  must_change_password: boolean | null;

  // B2B consents (from public.profiles, joined via auth_user_id = profiles.user_id)
  b2b_consents?: {
    gdpr_consent: boolean | null;
    newsletter_subscribed: boolean | null;
    product_updates: boolean | null;
    terms_accepted_at: string | null;
    marketing_consent_at: string | null;
    marketing_consent_source: string | null;
  } | null;

  // B2B access data (from public.profiles)
  b2b_access?: {
    phone_number: string | null;
    phone_set_at: string | null;
  } | null;
}

export const CUSTOMER_PIM_FIELDS = [
  "pec",
  "sdi_code",
  "closing_day",
  "delivery_notes",
  "contact_name",
  "contact_mobile",
  "importance",
  "visit_day",
  "visit_frequency",
  "competitors",
  "suppliers_present",
  "sells_online",
  "has_pc",
  "payment_method",
  "bank_name",
  "bank_branch",
  "iban",
  "pim_notes",
] as const;

export type CustomerPimField = (typeof CUSTOMER_PIM_FIELDS)[number];
export type CustomerPimUpdate = Partial<Pick<Customer, CustomerPimField>>;

const PAGE_SIZE = 50;

export type CustomersSortColumn =
  | "customer_code"
  | "company_full_name"
  | "city"
  | "province"
  | "activated_at"
  | "mail_accesso_cliente"
  | "price_list_code"
  | "original_agent_code"
  | "zone_code";
export type SortDirection = "asc" | "desc";

export function useCustomersList(
  search: string,
  page: number,
  onlyB2bActive = false,
  onlyTermsAccepted = false,
  onlyNewsletter = false,
  onlyFirstAccessPending = false,
  onlyRecentOptOut = false,
  sortColumn: CustomersSortColumn = "customer_code",
  sortDirection: SortDirection = "asc",
) {
  return useQuery({
    queryKey: [
      "customers-list",
      search.trim(),
      page,
      onlyB2bActive,
      onlyTermsAccepted,
      onlyNewsletter,
      onlyFirstAccessPending,
      onlyRecentOptOut,
      sortColumn,
      sortDirection,
    ],
    queryFn: async () => {
      const from = page * PAGE_SIZE;
      const to = from + PAGE_SIZE - 1;
      const q = search.trim();

      // Pre-filtro consensi: recupera gli auth_user_id di profiles che soddisfano i toggle
      const needsProfilesFilter =
        onlyTermsAccepted || onlyNewsletter || onlyFirstAccessPending || onlyRecentOptOut;
      let allowedAuthUserIds: string[] | null = null;
      if (needsProfilesFilter) {
        let pq = supabase.from("profiles").select("user_id");
        if (onlyTermsAccepted) pq = pq.not("terms_accepted_at", "is", null);
        if (onlyFirstAccessPending) pq = pq.is("terms_accepted_at", null);
        if (onlyNewsletter) pq = pq.eq("newsletter_subscribed", true);
        if (onlyRecentOptOut) {
          const since = new Date(Date.now() - 90 * 24 * 3600 * 1000).toISOString();
          pq = pq.eq("newsletter_subscribed", false).gte("marketing_consent_at", since);
        }
        const { data: pdata, error: perr } = await pq.limit(20000);
        if (perr) throw perr;
        allowedAuthUserIds = (pdata ?? []).map((r: any) => r.user_id).filter(Boolean);
        if (allowedAuthUserIds.length === 0) {
          return { rows: [] as Partial<Customer>[], total: 0 };
        }
      }

      let query = supabase
        .from("customers")
        .select(
          "id, customer_code, company_name, company_name_aux, company_full_name, city, province, vat_number, phone, email, mail_accesso_cliente, price_list_code, original_agent_code, zone_code, activated_at, last_import_at, auth_user_id",
          { count: "exact" }
        );

      if (q) {
        query = query.or(
          `customer_code.ilike.%${q}%,company_full_name.ilike.%${q}%`
        );
      }

      if (onlyB2bActive) {
        query = query.not("activated_at", "is", null);
      }

      if (allowedAuthUserIds) {
        query = query.in("auth_user_id", allowedAuthUserIds);
      }

      const ascending = sortDirection === "asc";
      query = query.order(sortColumn, { ascending, nullsFirst: false });
      if (sortColumn !== "customer_code") {
        query = query.order("customer_code", { ascending: true });
      }
      const { data, error, count } = await query.range(from, to);

      if (error) throw error;

      const rows = (data ?? []) as Partial<Customer>[];

      // Merge consensi per la pagina corrente
      const authIds = rows
        .map((r) => (r as any).auth_user_id as string | null)
        .filter((v): v is string => !!v);
      if (authIds.length > 0) {
        const { data: profs } = await supabase
          .from("profiles")
          .select("user_id, newsletter_subscribed, terms_accepted_at, marketing_consent_at, marketing_consent_source")
          .in("user_id", authIds);
        const map = new Map<string, any>();
        (profs ?? []).forEach((p: any) => map.set(p.user_id, p));
        rows.forEach((r) => {
          const uid = (r as any).auth_user_id as string | null;
          if (uid && map.has(uid)) {
            const p = map.get(uid);
            (r as any).b2b_consents = {
              newsletter_subscribed: p.newsletter_subscribed,
              terms_accepted_at: p.terms_accepted_at,
              marketing_consent_at: p.marketing_consent_at,
              marketing_consent_source: p.marketing_consent_source,
            };
          }
        });
      }

      // Merge flag videocatalogo (matching su customer_code normalizzato = senza zeri iniziali)
      const codesNorm = rows
        .map((r) => {
          const cc = (r as any).customer_code as string | undefined;
          if (!cc) return null;
          // Solo codici interamente numerici possono agganciare una riga
          // videocatalogo: L002 non deve ereditare i flag di 0002.
          const s = String(cc).trim();
          if (!/^\d+$/.test(s)) return null;
          return String(parseInt(s, 10));
        })
        .filter((v): v is string => !!v);
      if (codesNorm.length > 0) {
        const { data: flags } = await supabase
          .from("customer_videocatalogo_flags" as any)
          .select("customer_code_norm, videocatalogo_attivo, con_ordini")
          .in("customer_code_norm", codesNorm);
        const fmap = new Map<string, any>();
        (flags ?? []).forEach((f: any) => fmap.set(f.customer_code_norm, f));
        rows.forEach((r) => {
          const cc = (r as any).customer_code as string | undefined;
          if (!cc) return;
          const t = String(cc).trim();
          const key = /^\d+$/.test(t) ? String(parseInt(t, 10)) : "";
          const f = fmap.get(key);
          (r as any).videocatalogo_attivo = !!f?.videocatalogo_attivo;
          (r as any).videocatalogo_con_ordini = !!f?.con_ordini;
        });
      }

      return { rows, total: count ?? 0 };
    },
    staleTime: 30_000,
  });
}



export function useCustomer(id: string | null) {
  return useQuery({
    queryKey: ["customer", id],
    queryFn: async () => {
      if (!id) return null;
      const { data, error } = await supabase
        .from("customers")
        .select("*")
        .eq("id", id)
        .single();
      if (error) throw error;
      const customer = data as unknown as Customer;

      if (customer.auth_user_id) {
        const { data: p } = await supabase
          .from("profiles")
          .select("gdpr_consent, newsletter_subscribed, product_updates, terms_accepted_at, marketing_consent_at, marketing_consent_source, phone_number, phone_set_at")
          .eq("user_id", customer.auth_user_id)
          .maybeSingle();
        const row = (p as any) ?? null;
        customer.b2b_consents = row
          ? {
              gdpr_consent: row.gdpr_consent,
              newsletter_subscribed: row.newsletter_subscribed,
              product_updates: row.product_updates,
              terms_accepted_at: row.terms_accepted_at,
              marketing_consent_at: row.marketing_consent_at,
              marketing_consent_source: row.marketing_consent_source,
            }
          : null;
        customer.b2b_access = row
          ? { phone_number: row.phone_number, phone_set_at: row.phone_set_at }
          : null;
      } else {
        customer.b2b_consents = null;
        customer.b2b_access = null;
      }

      return customer;
    },
    enabled: !!id,
  });
}

export function useUpdateCustomerPim(id: string | null) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (patch: CustomerPimUpdate) => {
      if (!id) throw new Error("ID cliente mancante");
      // Whitelist solo campi PIM-only — non si può scrivere su campi AS400
      const safe: CustomerPimUpdate = {};
      for (const k of CUSTOMER_PIM_FIELDS) {
        if (k in patch) (safe as any)[k] = (patch as any)[k];
      }
      const { error } = await supabase.from("customers").update(safe).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Cliente aggiornato", description: "Modifiche salvate." });
      qc.invalidateQueries({ queryKey: ["customer", id] });
      qc.invalidateQueries({ queryKey: ["customers-list"] });
    },
    onError: (e: any) => {
      toast({
        title: "Errore salvataggio",
        description: e?.message ?? "Impossibile salvare le modifiche.",
        variant: "destructive",
      });
    },
  });
}

export function useUpdateCustomerB2bAccess(id: string | null) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (payload: { email?: string; phone_number?: string }) => {
      if (!id) throw new Error("ID cliente mancante");
      const { data, error } = await supabase.functions.invoke("admin-update-b2b-access", {
        body: { customer_id: id, ...payload },
      });
      if (error) {
        // Prova a estrarre il messaggio di errore dalla response della function
        let msg = error.message ?? "Errore aggiornamento";
        try {
          const ctx: any = (error as any).context;
          const body = ctx && typeof ctx.json === "function" ? await ctx.json() : null;
          if (body?.error) msg = body.error;
        } catch {
          /* ignore */
        }
        throw new Error(msg);
      }
      if ((data as any)?.error) throw new Error((data as any).error);
      return data;
    },
    onSuccess: () => {
      toast({ title: "Accesso B2B aggiornato", description: "Modifiche salvate." });
      qc.invalidateQueries({ queryKey: ["customer", id] });
      qc.invalidateQueries({ queryKey: ["customers-list"] });
    },
    onError: (e: any) => {
      toast({
        title: "Errore aggiornamento",
        description: e?.message ?? "Impossibile aggiornare i dati di accesso.",
        variant: "destructive",
      });
    },
  });
}

export const CUSTOMERS_PAGE_SIZE = PAGE_SIZE;

import { useCallback, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Q13Row } from "@/lib/query13Parser";

export interface Q13ImportStats {
  total: number;
  inserted: number;
  unchanged: number;
  updated?: number;
}

const CHUNK_SIZE = 2000;

export function useQuery13Import() {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stats, setStats] = useState<Q13ImportStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async (rows: Q13Row[]) => {
    setIsRunning(true);
    setProgress(0);
    setError(null);
    setStats(null);
    const agg: Q13ImportStats = { total: 0, inserted: 0, unchanged: 0, updated: 0 };
    try {
      for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
        const chunk = rows.slice(i, i + CHUNK_SIZE);
        const { data, error: rpcErr } = await supabase.rpc(
          "import_query13_campagne_associate" as any,
          { p_rows: chunk as any },
        );
        if (rpcErr) throw rpcErr;
        const r = (data ?? {}) as Q13ImportStats;
        agg.total += r.total ?? 0;
        agg.inserted += r.inserted ?? 0;
        agg.unchanged += r.unchanged ?? 0;
        agg.updated = (agg.updated ?? 0) + (r.updated ?? 0);
        setProgress(Math.min(100, ((i + chunk.length) / rows.length) * 100));
        setStats({ ...agg });
      }
      setProgress(100);
    } catch (e: any) {
      console.error("[Q13 Import] errore:", e);
      setError(e?.message ?? "Errore import");
    } finally {
      setIsRunning(false);
    }
  }, []);

  const reset = useCallback(() => {
    setStats(null);
    setProgress(0);
    setError(null);
    setIsRunning(false);
  }, []);

  return { run, reset, isRunning, progress, stats, error };
}

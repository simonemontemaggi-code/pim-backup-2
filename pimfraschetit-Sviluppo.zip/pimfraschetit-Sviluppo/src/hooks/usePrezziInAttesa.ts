import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { todayAs400, nowAs400Time } from "@/lib/dateUtils";
import { exportAs400Change } from "@/lib/as400Export";
import { useAuth } from "@/contexts/AuthContext";

export interface PrezzoInAttesa {
  id: string;
  wcdpa: string;
  wcdls: string | null;
  wcdca: string | null;
  wprun: number | null;
  wprui: number | null;
  wsm01: number | null;
  wsm02: number | null;
  wsm03: number | null;
  wsmim: number | null;
  wdtin: string | null;
  wdtia: string | null;
  wtima: string | null;
  wmova: string | null;
  wvaef: string | null;
  wcbve: string | null;
  wfcsv: number | null;
  wnsca: string | null;
  wnrsc: string | null;
  wumal: string | null;
  wnmua: string | null;
}

export function usePrezziInAttesa(cdpar: string, wcdls: string | null | undefined, _cdfor?: string | null | undefined) {
  return useQuery({
    queryKey: ["prezzi_in_attesa", cdpar, wcdls],
    enabled: !!cdpar && !!wcdls,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("prezzi_in_attesa" as any)
        .select("*")
        .eq("wcdpa", cdpar)
        .eq("wcdls", wcdls!)
        .neq("wvaef", "S")
        .order("wdtin", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as PrezzoInAttesa[];
    },
    staleTime: 30_000,
  });
}

async function flagArticleSync(cdpar: string) {
  await supabase
    .from("archivio_articoli_fraschetti")
    .update({ as400_sync_status: "modified", updated_at: new Date().toISOString() })
    .eq("cdpar", cdpar);
}

export function useUpsertPrezzoInAttesa(cdpar: string) {
  const qc = useQueryClient();
  const { user, profile } = useAuth();
  return useMutation({
    mutationFn: async (payload: Partial<PrezzoInAttesa> & { id?: string }) => {
      if (payload.id) {
        const { id, ...rest } = payload;
        const { error } = await supabase
          .from("prezzi_in_attesa" as any)
          .update(rest as any)
          .eq("id", id);
        if (error) throw error;
        exportAs400Change({
          user: profile?.email ?? user?.email,
          record: cdpar,
          table: "prezzi_in_attesa",
          change: {
            operation: "update",
            key: { id, wcdpa: cdpar },
            fields: rest,
          },
          filenamePrefix: "as400_prezzo_attesa",
        });
      } else {
        const insertPayload = {
          wcbve: "A",
          wmova: "C",
          wvaef: "M",
          wfcsv: 1,
          wnsca: "1",
          wnrsc: "0",
          wdtia: todayAs400(),
          wtima: nowAs400Time(),
          ...payload,
        };
        const { error } = await supabase.from("prezzi_in_attesa" as any).insert(insertPayload as any);
        if (error) throw error;
        exportAs400Change({
          user: profile?.email ?? user?.email,
          record: cdpar,
          table: "prezzi_in_attesa",
          change: {
            operation: "insert",
            key: { wcdpa: insertPayload.wcdpa ?? cdpar, wcdls: insertPayload.wcdls, wdtin: insertPayload.wdtin },
            fields: insertPayload,
          },
          filenamePrefix: "as400_prezzo_attesa",
        });
      }
      await flagArticleSync(cdpar);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["prezzi_in_attesa", cdpar] });
    },
  });
}

export function useDeletePrezzoInAttesa(cdpar: string) {
  const qc = useQueryClient();
  const { user, profile } = useAuth();
  return useMutation({
    mutationFn: async (id: string) => {
      // Fetch row before delete so we can include its key in the export
      const { data: row } = await supabase
        .from("prezzi_in_attesa" as any)
        .select("wcdpa,wcdls,wdtin")
        .eq("id", id)
        .maybeSingle();
      const { error } = await supabase.from("prezzi_in_attesa" as any).delete().eq("id", id);
      if (error) throw error;
      exportAs400Change({
        user: profile?.email ?? user?.email,
        record: cdpar,
        table: "prezzi_in_attesa",
        change: {
          operation: "delete",
          key: { id, ...((row as Record<string, any>) ?? { wcdpa: cdpar }) },
        },
        filenamePrefix: "as400_prezzo_attesa",
      });
      await flagArticleSync(cdpar);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["prezzi_in_attesa", cdpar] });
    },
  });
}

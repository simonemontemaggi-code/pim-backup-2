import { useCallback, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Q20Row } from "@/lib/query20Parser";

export interface Q20ImportStats {
  inserted: number;
  deleted: number;
}

const CHUNK_SIZE = 2000;

export function useQuery20Import() {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stats, setStats] = useState<Q20ImportStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async (rows: Q20Row[]) => {
    setIsRunning(true);
    setProgress(0);
    setError(null);
    setStats(null);
    const agg: Q20ImportStats = { inserted: 0, deleted: 0 };
    try {
      // Even with zero rows, reset to clear stale future entries
      if (rows.length === 0) {
        const { data, error: rpcErr } = await supabase.rpc(
          "import_query20_storico_assortimenti" as any,
          { p_rows: [] as any, p_reset: true },
        );
        if (rpcErr) throw rpcErr;
        const r = (data ?? {}) as Q20ImportStats;
        agg.deleted += r.deleted ?? 0;
        setStats({ ...agg });
        setProgress(100);
        return;
      }
      for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
        const chunk = rows.slice(i, i + CHUNK_SIZE);
        const isFirst = i === 0;
        const { data, error: rpcErr } = await supabase.rpc(
          "import_query20_storico_assortimenti" as any,
          { p_rows: chunk as any, p_reset: isFirst },
        );
        if (rpcErr) throw rpcErr;
        const r = (data ?? {}) as Q20ImportStats;
        agg.inserted += r.inserted ?? 0;
        agg.deleted += r.deleted ?? 0;
        setProgress(Math.min(100, ((i + chunk.length) / rows.length) * 100));
        setStats({ ...agg });
      }
      setProgress(100);
    } catch (e: any) {
      console.error("[Q20 Import] errore:", e);
      setError(e?.message ?? "Errore import");
    } finally {
      setIsRunning(false);
    }
  }, []);

  const reset = useCallback(() => {
    setStats(null);
    setProgress(0);
    setError(null);
    setIsRunning(false);
  }, []);

  return { run, reset, isRunning, progress, stats, error };
}

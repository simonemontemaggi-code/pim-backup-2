import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import { exportAs400Change, type As400Operation } from "@/lib/as400Export";

interface SaveOpts {
  table: string;
  /** Where clause columns (e.g. { wprogr: 3115 } for testate). Used for update + audit/export key. */
  keyColumns: Record<string, any>;
  /** Logical record id (e.g. wpprgf for testate). Shown in toasts/audit. */
  recordId: string | number;
  /** For "update": current row values to compute diff. Ignored for insert. */
  oldValues?: Record<string, any>;
  /** Tag in audit/export filename, e.g. "promo_testata". */
  filenamePrefix?: string;
  /** Invalidate these query keys on success. */
  invalidate?: any[][];
  /** Field names to persist on Supabase but EXCLUDE from the AS400 JSON export. */
  pimOnlyFields?: string[];
}

function normalize(val: any): any {
  if (val === null || val === undefined || val === "") return null;
  return val;
}

export function usePromoSave({
  table,
  keyColumns,
  recordId,
  oldValues,
  filenamePrefix = "as400_promo",
  invalidate = [],
  pimOnlyFields = [],
}: SaveOpts) {
  const queryClient = useQueryClient();
  const { user, profile } = useAuth();

  return useMutation({
    mutationFn: async (input: { newValues: Record<string, any>; operation?: As400Operation }) => {
      const operation: As400Operation = input.operation ?? "update";
      const newValues = input.newValues;

      let changedFields: string[] = [];
      let changes: Record<string, any> = {};

      if (operation === "update") {
        for (const [k, v] of Object.entries(newValues)) {
          const ov = oldValues?.[k];
          if (
            normalize(v) !== normalize(ov) &&
            JSON.stringify(normalize(v)) !== JSON.stringify(normalize(ov))
          ) {
            changedFields.push(k);
            changes[k] = v;
          }
        }
        if (changedFields.length === 0) return { changedCount: 0, operation };

        let q = supabase.from(table as any).update(changes);
        for (const [k, v] of Object.entries(keyColumns)) q = q.eq(k, v as any);
        const { error } = await q;
        if (error) throw error;
      } else if (operation === "insert") {
        changes = { ...keyColumns, ...newValues };
        changedFields = Object.keys(changes);
        const { error } = await supabase.from(table as any).insert(changes);
        if (error) throw error;
      } else if (operation === "delete") {
        let q = supabase.from(table as any).delete();
        for (const [k, v] of Object.entries(keyColumns)) q = q.eq(k, v as any);
        const { error } = await q;
        if (error) throw error;
      }

      // Audit log
      try {
        await supabase.from("audit_log" as any).insert({
          table_name: table,
          record_id: String(recordId),
          operation,
          old_values:
            operation === "update"
              ? Object.fromEntries(changedFields.map((f) => [f, oldValues?.[f]]))
              : null,
          new_values: operation !== "delete" ? changes : null,
          changed_fields: changedFields,
          user_id: user?.id,
          user_email: profile?.email,
        });
      } catch (e) {
        console.warn("audit_log insert failed", e);
      }

      // AS400 JSON export — escludi i campi PIM-only e segnala se non resta nulla.
      const exportFields =
        operation === "delete"
          ? undefined
          : Object.fromEntries(
              Object.entries(changes).filter(([k]) => !pimOnlyFields.includes(k)),
            );
      const hasAs400Changes =
        operation === "delete" || (exportFields && Object.keys(exportFields).length > 0);
      if (hasAs400Changes) {
        exportAs400Change({
          user: profile?.email ?? user?.email,
          record: String(recordId),
          table,
          change: { operation, key: keyColumns, fields: exportFields },
          filenamePrefix,
        });
      }

      return { changedCount: changedFields.length, operation };
    },
    onSuccess: (result) => {
      if (!result) return;
      const verb =
        result.operation === "insert"
          ? "Creato"
          : result.operation === "delete"
          ? "Eliminato"
          : `${result.changedCount} camp${result.changedCount === 1 ? "o modificato" : "i modificati"}`;
      toast({ title: "Salvato", description: `${verb}. JSON AS400 scaricato.` });
      invalidate.forEach((qk) => queryClient.invalidateQueries({ queryKey: qk }));
    },
    onError: (e: Error) => {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    },
  });
}

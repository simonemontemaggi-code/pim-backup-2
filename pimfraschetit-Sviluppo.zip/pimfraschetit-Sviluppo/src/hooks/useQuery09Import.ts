import { useCallback, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Q09Row } from "@/lib/query09Parser";

export interface Q09ImportStats {
  total: number;
  updated: number;
  inserted: number;
  unchanged: number;
}

const CHUNK_SIZE = 500;

export function useQuery09Import() {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stats, setStats] = useState<Q09ImportStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async (rows: Q09Row[]) => {
    setIsRunning(true);
    setProgress(0);
    setError(null);
    setStats(null);
    const agg: Q09ImportStats = { total: 0, updated: 0, inserted: 0, unchanged: 0 };
    try {
      for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
        const chunk = rows.slice(i, i + CHUNK_SIZE);
        const { data, error: rpcErr } = await supabase.rpc(
          "import_query09_def_base" as any,
          { p_rows: chunk as any },
        );
        if (rpcErr) throw rpcErr;
        const r = (data ?? {}) as Q09ImportStats;
        agg.total += r.total ?? 0;
        agg.updated += r.updated ?? 0;
        agg.inserted += r.inserted ?? 0;
        agg.unchanged += r.unchanged ?? 0;
        setProgress(Math.min(100, ((i + chunk.length) / rows.length) * 100));
        setStats({ ...agg });
      }
      setProgress(100);
    } catch (e: any) {
      console.error("[Q09 Import] errore:", e);
      setError(e?.message ?? "Errore import");
    } finally {
      setIsRunning(false);
    }
  }, []);

  const reset = useCallback(() => {
    setStats(null);
    setProgress(0);
    setError(null);
    setIsRunning(false);
  }, []);

  return { run, reset, isRunning, progress, stats, error };
}

import { useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export type AiField =
  | "all"
  | "title"
  | "description"
  | "short_description"
  | "seo_title"
  | "seo_description"
  | "tags";

export type AiGenerateAllResult = {
  title?: string;
  description?: string;
  short_description?: string;
  seo_title?: string;
  seo_description?: string;
  tags?: string[];
};

export type AiResponse = {
  generation_id: string | null;
  field: AiField;
  prompt_key: string;
  model: string;
  output_text: string;
  output_parsed: AiGenerateAllResult | string[] | null;
  tokens: { prompt: number | null; completion: number | null; total: number | null };
  duration_ms: number;
};

export function useAiGenerate() {
  const [loading, setLoading] = useState<AiField | null>(null);
  const [result, setResult] = useState<AiResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const generate = useCallback(async (cdpar: string, field: AiField): Promise<AiResponse | null> => {
    setLoading(field);
    setError(null);
    try {
      const { data, error: fnErr } = await supabase.functions.invoke("ai-generate-content", {
        body: { cdpar, field },
      });
      if (fnErr) {
        // Edge function returns JSON {error} with non-2xx → fnErr.context contains response
        let message = fnErr.message ?? "Errore AI";
        try {
          const ctx = (fnErr as { context?: Response }).context;
          if (ctx) {
            const j = await ctx.json();
            if (j?.error) message = j.error;
          }
        } catch { /* ignore */ }
        throw new Error(message);
      }
      if ((data as { error?: string })?.error) throw new Error((data as { error: string }).error);
      const resp = data as AiResponse;
      setResult(resp);
      return resp;
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Errore AI";
      setError(msg);
      toast.error(msg);
      return null;
    } finally {
      setLoading(null);
    }
  }, []);

  const reset = useCallback(() => {
    setResult(null);
    setError(null);
  }, []);

  return { generate, loading, result, error, reset };
}

import { useCallback, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Q14Row } from "@/lib/query14Parser";

export interface Q14ImportStats {
  inserted: number;
  deleted: number;
}

const CHUNK_SIZE = 3000;

export function useQuery14Import() {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stats, setStats] = useState<Q14ImportStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async (rows: Q14Row[]) => {
    setIsRunning(true);
    setProgress(0);
    setError(null);
    setStats(null);
    const agg: Q14ImportStats = { inserted: 0, deleted: 0 };
    try {
      for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
        const chunk = rows.slice(i, i + CHUNK_SIZE);
        const isFirst = i === 0;
        const { data, error: rpcErr } = await supabase.rpc(
          "import_query14_condizioni" as any,
          { p_rows: chunk as any, p_reset: isFirst },
        );
        if (rpcErr) throw rpcErr;
        const r = (data ?? {}) as Q14ImportStats;
        agg.inserted += r.inserted ?? 0;
        agg.deleted += r.deleted ?? 0;
        setProgress(Math.min(100, ((i + chunk.length) / rows.length) * 100));
        setStats({ ...agg });
      }
      setProgress(100);
    } catch (e: any) {
      console.error("[Q14 Import] errore:", e);
      setError(e?.message ?? "Errore import");
    } finally {
      setIsRunning(false);
    }
  }, []);

  const reset = useCallback(() => {
    setStats(null);
    setProgress(0);
    setError(null);
    setIsRunning(false);
  }, []);

  return { run, reset, isRunning, progress, stats, error };
}

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface GammaAttributeOption {
  id: string;
  gamma_attribute_id: string;
  option_value: string;
  option_label: string | null;
  sort_order: number;
}

export interface GammaAttribute {
  id: string;
  gamma_code: string;
  attribute_name: string;
  display_name: string | null;
  lookup_category: string | null;
  sort_order: number;
  is_required: boolean;
  has_unit_select: boolean;
  options: GammaAttributeOption[];
}

/** Derive a human-readable label from snake_case attribute name */
export function deriveDisplayName(snake: string): string {
  return snake
    .split(/[_\s]+/)
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(" ");
}

export function useGammaAttributes(gammaCode?: string) {
  return useQuery({
    queryKey: ["gamma_attributes", gammaCode],
    queryFn: async () => {
      if (!gammaCode) return [];
      const { data: attrs, error } = await supabase
        .from("gamma_attributes")
        .select("*")
        .eq("gamma_code", gammaCode)
        .order("sort_order");
      if (error) throw error;
      if (!attrs?.length) return [];

      const attrIds = attrs.map((a: any) => a.id);
      const { data: opts, error: optErr } = await supabase
        .from("gamma_attribute_options")
        .select("*")
        .in("gamma_attribute_id", attrIds)
        .order("sort_order");
      if (optErr) throw optErr;

      return attrs.map((a: any) => ({
        ...a,
        options: (opts ?? []).filter((o: any) => o.gamma_attribute_id === a.id),
      })) as GammaAttribute[];
    },
    enabled: !!gammaCode,
    staleTime: 5 * 60 * 1000,
  });
}

export function useAddGammaAttribute() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (val: { gamma_code: string; attribute_name: string; display_name?: string | null; lookup_category?: string | null; is_required?: boolean; has_unit_select?: boolean; sort_order?: number }) => {
      const { error } = await supabase.from("gamma_attributes").insert({
        gamma_code: val.gamma_code,
        attribute_name: val.attribute_name,
        display_name: val.display_name ?? deriveDisplayName(val.attribute_name),
        lookup_category: val.lookup_category ?? null,
        is_required: val.is_required ?? false,
        has_unit_select: val.has_unit_select ?? false,
        sort_order: val.sort_order ?? 0,
      } as any);
      if (error) throw error;
    },
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ["gamma_attributes", vars.gamma_code] });
    },
  });
}

export function useUpdateGammaAttribute() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (val: { id: string; gamma_code: string; attribute_name?: string; display_name?: string | null; lookup_category?: string | null; is_required?: boolean; has_unit_select?: boolean; sort_order?: number }) => {
      const { id, gamma_code, ...updates } = val;
      const { error } = await supabase.from("gamma_attributes").update(updates as any).eq("id", id);
      if (error) throw error;
    },
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ["gamma_attributes", vars.gamma_code] });
    },
  });
}

export function useDeleteGammaAttribute() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (val: { id: string; gamma_code: string }) => {
      const { error } = await supabase.from("gamma_attributes").delete().eq("id", val.id);
      if (error) throw error;
    },
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ["gamma_attributes", vars.gamma_code] });
    },
  });
}

export function useAddGammaAttributeOption() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (val: { gamma_attribute_id: string; gamma_code: string; option_value: string; option_label?: string; sort_order?: number }) => {
      const { gamma_code, ...insert } = val;
      const { error } = await supabase.from("gamma_attribute_options").insert({
        gamma_attribute_id: insert.gamma_attribute_id,
        option_value: insert.option_value,
        option_label: insert.option_label ?? null,
        sort_order: insert.sort_order ?? 0,
      } as any);
      if (error) throw error;
    },
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ["gamma_attributes", vars.gamma_code] });
    },
  });
}

export function useDeleteGammaAttributeOption() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (val: { id: string; gamma_code: string }) => {
      const { error } = await supabase.from("gamma_attribute_options").delete().eq("id", val.id);
      if (error) throw error;
    },
    onSuccess: (_, vars) => {
      qc.invalidateQueries({ queryKey: ["gamma_attributes", vars.gamma_code] });
    },
  });
}

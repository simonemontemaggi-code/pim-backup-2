import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/**
 * Conteggi notifiche per i pallini in sidebar.
 * - customer_requests: nuovi_clienti_richieste.status = 'pending'
 * - sales_untreated:   richieste_ordini_non_trattati.stato = 'in_lavorazione'
 * - sales_orders:      customer_orders.status = 'trasmesso' AND non presenti in order_download_batch_items
 * - scadenziario_incassi: scadenziario_rows.payment_confirmed=true AND non presenti in scadenziario_payment_ack
 */
export function useSidebarNotifications() {
  const qc = useQueryClient();

  // Realtime: invalida i conteggi quando cambiano le tabelle sorgente
  useEffect(() => {
    const ch = supabase
      .channel("sidebar-notifications")
      .on(
        "postgres_changes" as any,
        { event: "*", schema: "public", table: "nuovi_clienti_richieste" },
        () => qc.invalidateQueries({ queryKey: ["sidebar-notif"] }),
      )
      .on(
        "postgres_changes" as any,
        { event: "*", schema: "public", table: "richieste_ordini_non_trattati" },
        () => qc.invalidateQueries({ queryKey: ["sidebar-notif"] }),
      )
      .on(
        "postgres_changes" as any,
        { event: "*", schema: "public", table: "customer_orders" },
        () => qc.invalidateQueries({ queryKey: ["sidebar-notif"] }),
      )
      .on(
        "postgres_changes" as any,
        { event: "*", schema: "public", table: "order_download_batch_items" },
        () => qc.invalidateQueries({ queryKey: ["sidebar-notif"] }),
      )
      .on(
        "postgres_changes" as any,
        { event: "*", schema: "public", table: "scadenziario_rows" },
        () => qc.invalidateQueries({ queryKey: ["sidebar-notif"] }),
      )
      .on(
        "postgres_changes" as any,
        { event: "*", schema: "public", table: "scadenziario_payment_ack" },
        () => qc.invalidateQueries({ queryKey: ["sidebar-notif"] }),
      )
      .on(
        "postgres_changes" as any,
        { event: "*", schema: "public", table: "untreated_orders_row_visits_global" },
        () => qc.invalidateQueries({ queryKey: ["sidebar-notif"] }),
      )
      .on(
        "postgres_changes" as any,
        { event: "*", schema: "public", table: "customer_support_tickets" },
        () => qc.invalidateQueries({ queryKey: ["sidebar-notif"] }),
      )
      .on(
        "postgres_changes" as any,
        { event: "*", schema: "public", table: "b2b_ticket_visits_global" },
        () => qc.invalidateQueries({ queryKey: ["sidebar-notif"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  return useQuery({
    queryKey: ["sidebar-notif"],
    queryFn: async () => {
      const [reqRes, untreatedRowsRes, visitsRes, downloadedRes, transmittedRes, confirmedRes, ackRes, ticketsRes, ticketVisitsRes] = await Promise.all([
        supabase
          .from("nuovi_clienti_richieste")
          .select("id", { count: "exact", head: true })
          .eq("status", "pending"),
        supabase
          .from("richieste_ordini_non_trattati")
          .select("id,stato,status_updated_at,created_at")
          .eq("stato", "in_lavorazione"),
        supabase
          .from("untreated_orders_row_visits_global")
          .select("richiesta_id,last_visit_at"),
        supabase.from("order_download_batch_items").select("order_id"),
        supabase
          .from("customer_orders")
          .select("id")
          .eq("status", "trasmesso"),
        supabase
          .from("scadenziario_rows")
          .select("id", { count: "exact", head: true })
          .eq("payment_confirmed", true),
        supabase
          .from("scadenziario_payment_ack")
          .select("row_id", { count: "exact", head: true }),
        supabase
          .from("customer_support_tickets" as never)
          .select("id,updated_at,created_at,status")
          .neq("status", "closed"),
        supabase
          .from("b2b_ticket_visits_global" as never)
          .select("ticket_id,last_visit_at"),
      ]);

      const visitsMap = new Map<string, number>();
      for (const v of ((visitsRes as any)?.data ?? []) as { richiesta_id: string; last_visit_at: string }[]) {
        visitsMap.set(v.richiesta_id, new Date(v.last_visit_at).getTime());
      }
      const untreatedNew = ((untreatedRowsRes.data ?? []) as { id: string; status_updated_at: string | null; created_at: string }[])
        .filter((r) => {
          const t = new Date(r.status_updated_at ?? r.created_at).getTime();
          const seen = visitsMap.get(r.id) ?? 0;
          return t > seen;
        }).length;

      const downloadedIds = new Set(
        (downloadedRes.data ?? []).map((d: any) => d.order_id),
      );
      const newOrders = (transmittedRes.data ?? []).filter(
        (o: any) => !downloadedIds.has(o.id),
      ).length;

      const scadenziarioIncassi = Math.max(
        0,
        (confirmedRes.count ?? 0) - (ackRes.count ?? 0),
      );

      const ticketVisitMap = new Map<string, number>();
      for (const v of (((ticketVisitsRes as any)?.data ?? []) as { ticket_id: string; last_visit_at: string }[])) {
        ticketVisitMap.set(v.ticket_id, new Date(v.last_visit_at).getTime());
      }
      const ticketsNew = (((ticketsRes as any)?.data ?? []) as { id: string; updated_at: string | null; created_at: string }[])
        .filter((r) => {
          const t = new Date(r.updated_at ?? r.created_at).getTime();
          const seen = ticketVisitMap.get(r.id) ?? 0;
          return t > seen;
        }).length;

      return {
        customer_requests: reqRes.count ?? 0,
        sales_untreated: untreatedNew,
        sales_orders: newOrders,
        scadenziario_incassi: scadenziarioIncassi,
        b2b_tickets: ticketsNew,
      };
    },
    staleTime: 30_000,
    refetchInterval: 60_000,
  });
}

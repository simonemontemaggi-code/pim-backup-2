import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface AdoptionKpis {
  tot_customers: number;
  attivati: number;
  con_account: number;
  first_login_pending: number;
  terms_accepted: number;
  newsletter: number;
  videocat_attivi: number;
  videocat_ordini: number;
  migrati_videocat_b2b: number;
  migrati_videocat_b2b_week: number;
  // Segmentazione: attivi VC SENZA ordini VC
  vc_no_ord_totali: number;
  vc_no_ord_migrati: number;
  vc_no_ord_migrati_week: number;
  vc_no_ord_hanno_ordinato: number;
  vc_no_ord_hanno_ordinato_week: number;
  // Segmentazione: attivi VC CON ordini VC
  vc_con_ord_totali: number;
  vc_con_ord_migrati: number;
  vc_con_ord_migrati_week: number;
  vc_con_ord_hanno_ordinato: number;
  vc_con_ord_hanno_ordinato_week: number;
  // Segmentazione: clienti SENZA storico Videocatalogo
  no_vc_totali: number;
  no_vc_attivati: number;
  no_vc_attivati_week: number;
  no_vc_hanno_ordinato: number;
  no_vc_hanno_ordinato_week: number;

  attivi_30d: number;
  clienti_con_ordine: number;
  ordini_totali: number;
  ordini_30d: number;
  login_30d: number;

  // Dati settimana corrente (da lunedì)
  attivati_week: number;
  terms_accepted_week: number;
  attivi_week: number;
  login_week: number;
  clienti_con_ordine_week: number;
  ordini_week: number;
}

export interface TimeseriesPoint {
  ym: string; // YYYY-MM (or ISO week start for weekly series)
  value: number;
  label?: string; // display label, e.g. dd/MM for weekly buckets
}

export interface AdoptionData {
  kpi: AdoptionKpis;
  activations: TimeseriesPoint[];
  activationsMigrati: TimeseriesPoint[];
  activationsNuovi: TimeseriesPoint[];
  activationsMigratiWeekly: TimeseriesPoint[];
  activationsNuoviWeekly: TimeseriesPoint[];
  activationsMigratiWeeklyAll: TimeseriesPoint[];
  activationsNuoviWeeklyAll: TimeseriesPoint[];
  logins: TimeseriesPoint[];
  orders: TimeseriesPoint[];
  loginsWeekly: TimeseriesPoint[];
  ordersWeekly: TimeseriesPoint[];
  perZone: { zone: string; attivati: number; totali: number }[];
  perAgent: {
    agent: string;
    agentName: string | null;
    attivati: number;
    totali: number;
    /** clienti distinti con almeno un ordine trasmesso dall'agente */
    clientiOrdAgente: number;
    /** clienti distinti che hanno trasmesso ordini in autonomia dal B2B */
    clientiOrdCliente: number;
    /** clienti ordinati dall'agente ma non ancora attivati sul B2B */
    clientiOrdAgenteNonIscritti: number;
    /** clienti dell'agente con Videocatalogo attivo */
    clientiVdc: number;
  }[];
  funnel: { label: string; value: number }[];
  /** dettaglio per cliente, usato dai drill-down */
  customerRows: AdoptionCustomerRow[];
}

export interface AdoptionCustomerRow {
  code: string;
  codeNorm: string | null;
  name: string;
  zone: string;
  agent: string;
  agentName: string | null;
  activatedAt: string | null;
  vdcAttivo: boolean;
  vdcOrdini: boolean;
  ordiniCliente: number;
  ordiniAgente: number;
  ultimoOrdineCliente: string | null;
  ultimoOrdineAgente: string | null;
}


const ymOf = (iso: string | null | undefined) => {
  if (!iso) return "";
  const d = new Date(iso);
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
};

const bucketize = (dates: (string | null | undefined)[]): TimeseriesPoint[] => {
  const m = new Map<string, number>();
  for (const d of dates) {
    const k = ymOf(d);
    if (!k) continue;
    m.set(k, (m.get(k) ?? 0) + 1);
  }
  return Array.from(m.entries())
    .sort(([a], [b]) => (a < b ? -1 : 1))
    .map(([ym, value]) => ({ ym, value }));
};

// Monday-based ISO-like week start (UTC)
const weekStart = (iso: string | null | undefined): string => {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  const day = d.getUTCDay(); // 0=Sun
  const diff = (day + 6) % 7; // days since Monday
  const monday = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - diff));
  return monday.toISOString().slice(0, 10);
};

const bucketizeWeekly8 = (dates: (string | null | undefined)[]): TimeseriesPoint[] => {
  // Build last 8 weeks (Monday-based) ending on current week
  const now = new Date();
  const currentMonday = weekStart(now.toISOString());
  const weeks: string[] = [];
  const base = new Date(currentMonday + "T00:00:00Z");
  for (let i = 7; i >= 0; i--) {
    const w = new Date(base);
    w.setUTCDate(base.getUTCDate() - i * 7);
    weeks.push(w.toISOString().slice(0, 10));
  }
  const set = new Set(weeks);
  const m = new Map<string, number>(weeks.map((w) => [w, 0]));
  for (const d of dates) {
    const k = weekStart(d);
    if (!k || !set.has(k)) continue;
    m.set(k, (m.get(k) ?? 0) + 1);
  }
  return weeks.map((w) => {
    // Label: dd/MM
    const dt = new Date(w + "T00:00:00Z");
    const label = `${String(dt.getUTCDate()).padStart(2, "0")}/${String(dt.getUTCMonth() + 1).padStart(2, "0")}`;
    return { ym: w, label, value: m.get(w) ?? 0 };
  });
};

const bucketizeWeeklyAll = (dates: (string | null | undefined)[]): TimeseriesPoint[] => {
  const m = new Map<string, number>();
  for (const d of dates) {
    const k = weekStart(d);
    if (!k) continue;
    m.set(k, (m.get(k) ?? 0) + 1);
  }
  return Array.from(m.entries())
    .sort(([a], [b]) => (a < b ? -1 : 1))
    .map(([w, value]) => {
      const dt = new Date(w + "T00:00:00Z");
      const label = `${String(dt.getUTCDate()).padStart(2, "0")}/${String(dt.getUTCMonth() + 1).padStart(2, "0")}`;
      return { ym: w, label, value };
    });
};

const bucketizeWeeklyDistinct = (
  rows: Array<{ ts: string | null | undefined; uid: string | null | undefined }>,
): TimeseriesPoint[] => {
  const m = new Map<string, Set<string>>();
  for (const r of rows) {
    const k = weekStart(r.ts);
    if (!k || !r.uid) continue;
    if (!m.has(k)) m.set(k, new Set());
    m.get(k)!.add(r.uid);
  }
  return Array.from(m.entries())
    .sort(([a], [b]) => (a < b ? -1 : 1))
    .map(([w, set]) => {
      const dt = new Date(w + "T00:00:00Z");
      const label = `${String(dt.getUTCDate()).padStart(2, "0")}/${String(dt.getUTCMonth() + 1).padStart(2, "0")}`;
      return { ym: w, label, value: set.size };
    });
};


/**
 * Codice cliente confrontato ESATTO: L002, 0002 e 00002 sono clienti diversi.
 * Nessuna rimozione di lettere o zeri iniziali.
 */
const exactCode = (v: any): string | null => {
  const s = String(v ?? "").trim().toUpperCase();
  return s ? s : null;
};

/**
 * Chiave per il match con `customer_videocatalogo_flags.customer_code_norm`
 * (numerico senza zeri iniziali). Solo codici interamente numerici possono
 * agganciare una riga videocatalogo: L002 / NUOVO2 non matchano mai.
 */
const vcKey = (v: any): string | null => {
  const s = String(v ?? "").trim();
  if (!/^\d+$/.test(s)) return null;
  return String(parseInt(s, 10));
};

export function usePortalAdoption() {
  return useQuery({
    // Versionare la chiave quando cambia la classificazione degli ordini: evita
    // che React Query mantenga in memoria il vecchio drill-down basato anche sui CA.
    queryKey: ["portal-adoption", "v4-exact-code"],

    staleTime: 5 * 60 * 1000,
    queryFn: async (): Promise<AdoptionData> => {
      const since30 = new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString();

      const [
        totCust,
        attivatiRows,
        conAccount,
        firstLoginPending,
        termsAccepted,
        newsletterCount,
        videoAttivi,
        videoOrdini,
        activationsList,
        ordersList,
        loginsList,
        articleEvents30,
      ] = await Promise.all([
        supabase.from("customers").select("id", { count: "exact", head: true }),
        supabase
          .from("customers")
          .select("activated_at, zone_code, original_agent_code, customer_code, auth_user_id")
          .not("activated_at", "is", null),
        supabase
          .from("customers")
          .select("auth_user_id")
          .not("auth_user_id", "is", null)
          .limit(20000),
        // Profili senza accettazione termini (per intersezione con clienti B2B)
        supabase
          .from("profiles")
          .select("user_id")
          .is("terms_accepted_at", null)
          .limit(20000),


        supabase
          .from("profiles")
          .select("user_id, terms_accepted_at")
          .not("terms_accepted_at", "is", null)
          .limit(20000),
        supabase
          .from("profiles")
          .select("user_id", { count: "exact", head: true })
          .eq("newsletter_subscribed", true),
        supabase
          .from("customer_videocatalogo_flags" as any)
          .select("customer_code_norm", { count: "exact", head: true })
          .eq("videocatalogo_attivo", true),
        supabase
          .from("customer_videocatalogo_flags" as any)
          .select("customer_code_norm", { count: "exact", head: true })
          .eq("con_ordini", true),
        supabase.from("customers").select("activated_at").not("activated_at", "is", null),
        supabase
          .from("customer_orders")
          .select("created_at, codice_cliente, auth_user_id, origine")
          .limit(20000),

        supabase.from("user_login_events").select("created_at, auth_user_id").limit(10000),
        supabase
          .from("article_events")
          .select("customer_code, occurred_at")
          .eq("source", "b2b")
          .gte("occurred_at", since30)
          .limit(50000),
      ]);

      // Migrati: clienti attivati B2B che avevano videocatalogo attivo
      const activatedCustomers = attivatiRows.data ?? [];
      const codesNorm = activatedCustomers
        .map((c: any) => vcKey(c.customer_code))
        .filter((v): v is string => !!v);


      // Fetch tutti i flag videocatalogo attivi (con info ordini VC)
      const { data: vcFlags } = await supabase
        .from("customer_videocatalogo_flags" as any)
        .select("customer_code_norm, con_ordini")
        .eq("videocatalogo_attivo", true)
        .limit(20000);
      const vcFlagsArr = ((vcFlags ?? []) as unknown) as Array<{ customer_code_norm: string; con_ordini: boolean }>;

      const migratedCodesSet = new Set(codesNorm);
      const migrati = vcFlagsArr.filter((f) => migratedCodesSet.has(f.customer_code_norm)).length;

      // Set degli auth_user_id che sono clienti (per distinguere ordini fatti dal cliente vs agente)
      const customerAuthIdsEarly = new Set(
        (conAccount.data ?? []).map((r: any) => r.auth_user_id).filter(Boolean),
      );

      // Attribuzione autorevole: `origine` dell'ordine
      //   NE = trasmesso dal cliente sul B2B
      //   CA = trasmesso dall'agente (Agent Hub) per conto del cliente
      // NB: non si può usare l'auth_user_id, perché alcuni agenti hanno anche
      // un record in `customers` e i loro ordini risultavano "del cliente".
      const isOrderByCustomer = (o: any) => String(o?.origine ?? "").toUpperCase() === "NE";

      // Ordini "cliente-online": solo quelli trasmessi dal cliente sul B2B
      const customerOrders = (ordersList.data ?? []).filter(isOrderByCustomer);

      // Login solo di clienti B2B reali (esclude agenti/dipendenti)
      const customerLogins = (loginsList.data ?? []).filter(
        (l: any) => l.auth_user_id && customerAuthIdsEarly.has(l.auth_user_id),
      );

      // Bucketize distinct users per month (same logic as Panoramica: unique auth_user_id)
      const bucketizeDistinct = (
        rows: Array<{ ts: string | null | undefined; uid: string | null | undefined }>,
      ): TimeseriesPoint[] => {
        const m = new Map<string, Set<string>>();
        for (const r of rows) {
          const k = ymOf(r.ts);
          if (!k || !r.uid) continue;
          if (!m.has(k)) m.set(k, new Set());
          m.get(k)!.add(r.uid);
        }
        return Array.from(m.entries())
          .sort(([a], [b]) => (a < b ? -1 : 1))
          .map(([ym, set]) => ({ ym, value: set.size }));
      };

      // Time series
      const activations = bucketize(activatedCustomers.map((c: any) => c.activated_at));
      const orders = bucketizeDistinct(
        customerOrders.map((o: any) => ({ ts: o.created_at, uid: o.auth_user_id })),
      );
      const logins = bucketizeDistinct(
        customerLogins.map((l: any) => ({ ts: l.created_at, uid: l.auth_user_id })),
      );


      // Attivazioni split: migrati da Videocatalogo vs nuovi
      const vcCodesSet = new Set(vcFlagsArr.map((f) => f.customer_code_norm));
      const activationsMigrati = bucketize(
        activatedCustomers
          .filter((c: any) => {
            const n = vcKey(c.customer_code);
            return n && vcCodesSet.has(n);
          })
          .map((c: any) => c.activated_at),
      );
      const activationsNuovi = bucketize(
        activatedCustomers
          .filter((c: any) => {
            const n = vcKey(c.customer_code);
            return !n || !vcCodesSet.has(n);
          })
          .map((c: any) => c.activated_at),
      );

      const activationsMigratiWeekly = bucketizeWeekly8(
        activatedCustomers
          .filter((c: any) => {
            const n = vcKey(c.customer_code);
            return n && vcCodesSet.has(n);
          })
          .map((c: any) => c.activated_at),
      );
      const activationsNuoviWeekly = bucketizeWeekly8(
        activatedCustomers
          .filter((c: any) => {
            const n = vcKey(c.customer_code);
            return !n || !vcCodesSet.has(n);
          })
          .map((c: any) => c.activated_at),
      );


      // Ordini 30d (solo cliente-online)
      const ordini30 = customerOrders.filter(
        (o: any) => o.created_at && o.created_at >= since30,
      ).length;
      const login30 = new Set(
        customerLogins
          .filter((l: any) => l.created_at && l.created_at >= since30)
          .map((l: any) => l.auth_user_id),
      ).size;


      // Attivi 30d (distinct customer_code da article_events)
      const attivi30 = new Set(
        (articleEvents30.data ?? [])
          .map((r: any) => r.customer_code)
          .filter((v: any) => !!v),
      ).size;

      // Clienti con almeno un ordine online (distinct codice_cliente tra ordini cliente-online)
      const orderedCustomerCodes = new Set(
        customerOrders.map((o: any) => o.codice_cliente).filter((v: any) => !!v),
      );
      const clientiConOrdine = orderedCustomerCodes.size;

      const orderedCodesNorm = new Set(
        Array.from(orderedCustomerCodes).map(vcKey).filter((v): v is string => !!v),
      );

      // Segmentazione videocatalogo
      const vcNoOrd = vcFlagsArr.filter((f) => !f.con_ordini);
      const vcConOrd = vcFlagsArr.filter((f) => f.con_ordini);
      const vc_no_ord_migrati = vcNoOrd.filter((f) => migratedCodesSet.has(f.customer_code_norm)).length;
      const vc_no_ord_hanno_ordinato = vcNoOrd.filter((f) => orderedCodesNorm.has(f.customer_code_norm)).length;
      const vc_con_ord_migrati = vcConOrd.filter((f) => migratedCodesSet.has(f.customer_code_norm)).length;
      const vc_con_ord_hanno_ordinato = vcConOrd.filter((f) => orderedCodesNorm.has(f.customer_code_norm)).length;

      // Segmentazione: clienti anagrafica SENZA storico Videocatalogo
      const vcCodesSetForNoVc = new Set(vcFlagsArr.map((f) => f.customer_code_norm));
      const no_vc_totali = Math.max((totCust.count ?? 0) - vcFlagsArr.length, 0);
      const no_vc_attivati = activatedCustomers.filter((c: any) => {
        const n = vcKey(c.customer_code);
        return !n || !vcCodesSetForNoVc.has(n);
      }).length;
      const no_vc_hanno_ordinato = Array.from(orderedCodesNorm).filter(
        (n) => !vcCodesSetForNoVc.has(n),
      ).length;

      // Dati settimana corrente (da lunedì)
      const currentMondayStr = weekStart(new Date().toISOString());
      const isThisWeek = (iso: string | null | undefined) => !!iso && iso >= (currentMondayStr + "T00:00:00Z");

      const migrati_videocat_b2b_week = activatedCustomers.filter((c: any) => {
        const n = vcKey(c.customer_code);
        return isThisWeek(c.activated_at) && n && vcCodesSet.has(n);
      }).length;

      const vc_no_ord_migrati_week = vcNoOrd.filter((f) => {
        const match = activatedCustomers.find((c: any) => vcKey(c.customer_code) === f.customer_code_norm);
        return match && isThisWeek(match.activated_at);
      }).length;
      const vc_no_ord_hanno_ordinato_week = vcNoOrd.filter((f) => {
        const hasOrderThisWeek = customerOrders.some(
          (o: any) => vcKey(o.codice_cliente) === f.customer_code_norm && isThisWeek(o.created_at),
        );
        return hasOrderThisWeek;
      }).length;

      const vc_con_ord_migrati_week = vcConOrd.filter((f) => {
        const match = activatedCustomers.find((c: any) => vcKey(c.customer_code) === f.customer_code_norm);
        return match && isThisWeek(match.activated_at);
      }).length;
      const vc_con_ord_hanno_ordinato_week = vcConOrd.filter((f) => {
        const hasOrderThisWeek = customerOrders.some(
          (o: any) => vcKey(o.codice_cliente) === f.customer_code_norm && isThisWeek(o.created_at),
        );
        return hasOrderThisWeek;
      }).length;

      const no_vc_attivati_week = activatedCustomers.filter((c: any) => {
        const n = vcKey(c.customer_code);
        return isThisWeek(c.activated_at) && (!n || !vcCodesSetForNoVc.has(n));
      }).length;
      const no_vc_hanno_ordinato_week = Array.from(orderedCodesNorm).filter((n) => {
        if (vcCodesSetForNoVc.has(n)) return false;
        return customerOrders.some(
          (o: any) => vcKey(o.codice_cliente) === n && isThisWeek(o.created_at),
        );
      }).length;




      // Ripartizione per zona (attivati) + totali per zona
      const { data: totPerZoneRaw } = await supabase
        .from("customers")
        .select("zone_code, original_agent_code, customer_code, activated_at, company_name")
        .limit(20000);
      const totByZone = new Map<string, number>();
      const totByAgent = new Map<string, number>();
      (totPerZoneRaw ?? []).forEach((c: any) => {
        const z = c.zone_code ?? "—";
        const a = c.original_agent_code ?? "—";
        totByZone.set(z, (totByZone.get(z) ?? 0) + 1);
        totByAgent.set(a, (totByAgent.get(a) ?? 0) + 1);
      });
      const actByZone = new Map<string, number>();
      const actByAgent = new Map<string, number>();
      activatedCustomers.forEach((c: any) => {
        const z = c.zone_code ?? "—";
        const a = c.original_agent_code ?? "—";
        actByZone.set(z, (actByZone.get(z) ?? 0) + 1);
        actByAgent.set(a, (actByAgent.get(a) ?? 0) + 1);
      });
      const perZone = Array.from(actByZone.entries())
        .map(([zone, attivati]) => ({ zone, attivati, totali: totByZone.get(zone) ?? 0 }))
        .sort((a, b) => b.attivati - a.attivati);

      // --- Metriche per agente basate sui clienti (non sul numero di ordini) ---
      // mappa codice cliente normalizzato -> { agente, attivato }
      const custByCode = new Map<string, { agent: string; activated: boolean }>();
      (totPerZoneRaw ?? []).forEach((c: any) => {
        const n = exactCode(c.customer_code);
        if (!n) return;
        custByCode.set(n, {
          agent: c.original_agent_code ?? "—",
          activated: !!c.activated_at,
        });
      });

      const ordAgenteByAgent = new Map<string, Set<string>>();
      const ordClienteByAgent = new Map<string, Set<string>>();
      const ordAgenteNoIscrByAgent = new Map<string, Set<string>>();
      const addTo = (m: Map<string, Set<string>>, k: string, v: string) => {
        if (!m.has(k)) m.set(k, new Set());
        m.get(k)!.add(v);
      };
      (ordersList.data ?? []).forEach((o: any) => {
        const n = exactCode(o.codice_cliente);
        if (!n) return;
        const info = custByCode.get(n);
        const agCode = info?.agent ?? "—";
        const byCustomer = isOrderByCustomer(o);
        if (byCustomer) {
          addTo(ordClienteByAgent, agCode, n);
        } else {
          addTo(ordAgenteByAgent, agCode, n);
          if (!info?.activated) addTo(ordAgenteNoIscrByAgent, agCode, n);
        }
      });

      // clienti con Videocatalogo attivo per agente
      const vdcByAgent = new Map<string, number>();
      (totPerZoneRaw ?? []).forEach((c: any) => {
        const n = vcKey(c.customer_code);
        if (!n || !vcCodesSet.has(n)) return;
        const a = c.original_agent_code ?? "—";
        vdcByAgent.set(a, (vdcByAgent.get(a) ?? 0) + 1);
      });

      const agentCodes = Array.from(actByAgent.keys()).filter((a) => a && a !== "—");
      const { data: agentProfiles } = await supabase
        .from("profiles")
        .select("agent_code, full_name, email")
        .in("agent_code", agentCodes.length ? agentCodes : ["__none__"]);
      const agentNameMap = new Map<string, string>();
      (agentProfiles ?? []).forEach((p: any) => {
        const name = p.full_name || p.email || null;
        if (p.agent_code && name) agentNameMap.set(p.agent_code, name);
      });
      const perAgent = Array.from(actByAgent.entries())
        .map(([agent, attivati]) => ({
          agent,
          agentName: agentNameMap.get(agent) ?? null,
          attivati,
          totali: totByAgent.get(agent) ?? 0,
          clientiOrdAgente: ordAgenteByAgent.get(agent)?.size ?? 0,
          clientiOrdCliente: ordClienteByAgent.get(agent)?.size ?? 0,
          clientiOrdAgenteNonIscritti: ordAgenteNoIscrByAgent.get(agent)?.size ?? 0,
          clientiVdc: vdcByAgent.get(agent) ?? 0,
        }))
        .sort((a, b) => b.attivati - a.attivati);

      // --- Dettaglio per cliente (drill-down) ---
      const vcOrdSet = new Set(vcFlagsArr.filter((f) => f.con_ordini).map((f) => f.customer_code_norm));
      const ordStatsByCode = new Map<string, { cli: number; age: number; lastCli: string | null; lastAge: string | null }>();
      (ordersList.data ?? []).forEach((o: any) => {
        const n = exactCode(o.codice_cliente);
        if (!n) return;
        const cur = ordStatsByCode.get(n) ?? { cli: 0, age: 0, lastCli: null, lastAge: null };
        const byCustomer = isOrderByCustomer(o);
        if (byCustomer) {
          cur.cli += 1;
          if (o.created_at && (!cur.lastCli || o.created_at > cur.lastCli)) cur.lastCli = o.created_at;
        } else {
          cur.age += 1;
          if (o.created_at && (!cur.lastAge || o.created_at > cur.lastAge)) cur.lastAge = o.created_at;
        }
        ordStatsByCode.set(n, cur);
      });
      const customerRows: AdoptionCustomerRow[] = (totPerZoneRaw ?? []).map((c: any) => {
        const n = exactCode(c.customer_code);
        const vk = vcKey(c.customer_code);
        const st = n ? ordStatsByCode.get(n) : undefined;
        const agent = c.original_agent_code ?? "—";
        return {
          code: String(c.customer_code ?? ""),
          codeNorm: n,
          name: c.company_name ?? "",
          zone: c.zone_code ?? "—",
          agent,
          agentName: agentNameMap.get(agent) ?? null,
          activatedAt: c.activated_at ?? null,
          vdcAttivo: !!vk && vcCodesSet.has(vk),
          vdcOrdini: !!vk && vcOrdSet.has(vk),
          ordiniCliente: st?.cli ?? 0,
          ordiniAgente: st?.age ?? 0,
          ultimoOrdineCliente: st?.lastCli ?? null,
          ultimoOrdineAgente: st?.lastAge ?? null,
        };
      });




      const tot = totCust.count ?? 0;
      const attivatiN = activatedCustomers.length;
      const customerAuthIds = new Set(
        (conAccount.data ?? []).map((r: any) => r.auth_user_id).filter(Boolean),
      );
      const activatedCustomerAuthIds = new Set(
        activatedCustomers.map((r: any) => r.auth_user_id).filter(Boolean),
      );
      const conAccountN = customerAuthIds.size;
      const pendingTermsUids = new Set((firstLoginPending.data ?? [])
        .map((r: any) => r.user_id)
        .filter((uid: string) => uid && activatedCustomerAuthIds.has(uid)));
      const firstLoginPendingN = pendingTermsUids.size;
      const termsUids = new Set((termsAccepted.data ?? [])
        .map((r: any) => r.user_id)
        .filter((uid: string) => uid && activatedCustomerAuthIds.has(uid)));
      const termsN = termsUids.size;

      // Metriche settimana corrente
      const attivati_week = activatedCustomers.filter((c: any) => isThisWeek(c.activated_at)).length;
      const terms_accepted_week = (termsAccepted.data ?? []).filter(
        (r: any) => activatedCustomerAuthIds.has(r.user_id) && isThisWeek(r.terms_accepted_at),
      ).length;
      const currentMondayIso = currentMondayStr + "T00:00:00Z";
      const attivi_week = new Set(
        (articleEvents30.data ?? [])
          .filter((r: any) => r.occurred_at && r.occurred_at >= currentMondayIso)
          .map((r: any) => r.customer_code)
          .filter((v: any) => !!v),
      ).size;
      const login_week = new Set(
        customerLogins
          .filter((l: any) => isThisWeek(l.created_at))
          .map((l: any) => l.auth_user_id),
      ).size;
      const ordiniWeekArr = customerOrders.filter((o: any) => isThisWeek(o.created_at));
      const ordini_week = ordiniWeekArr.length;
      const clienti_con_ordine_week = new Set(
        ordiniWeekArr.map((o: any) => o.codice_cliente).filter((v: any) => !!v),
      ).size;

      return {
        kpi: {
          tot_customers: tot,
          attivati: attivatiN,
          con_account: conAccountN,
          first_login_pending: firstLoginPendingN,

          terms_accepted: termsN,
          newsletter: newsletterCount.count ?? 0,
          videocat_attivi: videoAttivi.count ?? 0,
          videocat_ordini: videoOrdini.count ?? 0,
          migrati_videocat_b2b: migrati,
          migrati_videocat_b2b_week: migrati_videocat_b2b_week,
          vc_no_ord_totali: vcNoOrd.length,
          vc_no_ord_migrati,
          vc_no_ord_migrati_week,
          vc_no_ord_hanno_ordinato,
          vc_no_ord_hanno_ordinato_week,
          vc_con_ord_totali: vcConOrd.length,
          vc_con_ord_migrati,
          vc_con_ord_migrati_week,
          vc_con_ord_hanno_ordinato,
          vc_con_ord_hanno_ordinato_week,
          no_vc_totali,
          no_vc_attivati,
          no_vc_attivati_week,
          no_vc_hanno_ordinato,
          no_vc_hanno_ordinato_week,
          attivi_30d: attivi30,
          clienti_con_ordine: clientiConOrdine,
          ordini_totali: customerOrders.length,
          ordini_30d: ordini30,
          login_30d: login30,
          attivati_week,
          terms_accepted_week,
          attivi_week,
          login_week,
          clienti_con_ordine_week,
          ordini_week,
        },
        activations,
        activationsMigrati,
        activationsNuovi,
        activationsMigratiWeekly,
        activationsNuoviWeekly,
        activationsMigratiWeeklyAll: bucketizeWeeklyAll(
          activatedCustomers
            .filter((c: any) => {
              const n = vcKey(c.customer_code);
              return n && vcCodesSet.has(n);
            })
            .map((c: any) => c.activated_at),
        ),
        activationsNuoviWeeklyAll: bucketizeWeeklyAll(
          activatedCustomers
            .filter((c: any) => {
              const n = vcKey(c.customer_code);
              return !n || !vcCodesSet.has(n);
            })
            .map((c: any) => c.activated_at),
        ),
        logins,
        orders,
        loginsWeekly: bucketizeWeeklyDistinct(
          customerLogins.map((l: any) => ({ ts: l.created_at, uid: l.auth_user_id })),
        ),
        ordersWeekly: bucketizeWeeklyAll(
          customerOrders.map((o: any) => o.created_at),
        ),
        perZone,
        perAgent,
        funnel: [
          { label: "Anagrafica AS400", value: tot },
          { label: "Account creato", value: conAccountN },
          { label: "Attivato (primo login)", value: attivatiN },
          { label: "Contratti accettati", value: termsN },
          { label: "Cliente con ordine", value: clientiConOrdine },
        ],
        customerRows,
      };
    },
  });
}

import { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export type TicketCategory =
  | "ordini"
  | "contabile"
  | "tecnico"
  | "commerciale"
  | "annullamento_ordine"
  | "post_vendita"
  | "portale"
  | "altro";

export type TicketStatus = "open" | "in_progress" | "closed";

export interface B2bTicket {
  id: string;
  customer_id: string;
  user_id: string | null;
  category: string;
  subject: string;
  message: string;
  contact_email: string | null;
  status: string;
  created_at: string;
  updated_at: string | null;
  customer_code?: string | null;
  company_name?: string | null;
}

const KEY = ["b2b-tickets"] as const;

export function useB2bTickets() {
  const qc = useQueryClient();

  useEffect(() => {
    const ch = supabase
      .channel("b2b-tickets-changes")
      .on(
        "postgres_changes" as never,
        { event: "*", schema: "public", table: "customer_support_tickets" },
        () => qc.invalidateQueries({ queryKey: KEY }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  return useQuery({
    queryKey: KEY,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("customer_support_tickets" as never)
        .select("*")
        .order("created_at", { ascending: false })
        .limit(1000);
      if (error) throw error;
      const rows = (data ?? []) as unknown as B2bTicket[];
      const ids = Array.from(new Set(rows.map((r) => r.customer_id).filter(Boolean)));
      if (ids.length === 0) return rows;
      const { data: custs } = await supabase
        .from("customers")
        .select("id, customer_code, company_name")
        .in("id", ids);
      const map = new Map((custs ?? []).map((c) => [c.id, c]));
      return rows.map((r) => {
        const c = map.get(r.customer_id);
        return {
          ...r,
          customer_code: c?.customer_code ?? null,
          company_name: c?.company_name ?? null,
        };
      });
    },
  });
}

export function useUpdateTicketStatus() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, status }: { id: string; status: TicketStatus }) => {
      const { data, error } = await supabase
        .from("customer_support_tickets" as never)
        .update({ status } as never)
        .eq("id", id)
        .select("id");
      if (error) throw error;
      if (!data || (data as unknown[]).length === 0) {
        throw new Error("Permessi insufficienti per cambiare lo stato di questo ticket");
      }
    },
    onSuccess: () => {
      toast.success("Stato aggiornato");
      qc.invalidateQueries({ queryKey: KEY });
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useDeleteTicket() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("customer_support_tickets" as never)
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Ticket eliminato");
      qc.invalidateQueries({ queryKey: KEY });
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

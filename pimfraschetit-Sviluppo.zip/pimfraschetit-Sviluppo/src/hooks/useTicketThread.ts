import { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import type { TicketStatus } from "@/hooks/useB2bTickets";

export type TicketMessage = {
  id: string;
  ticket_id: string;
  author_type: "customer" | "staff";
  author_user_id: string | null;
  author_name: string | null;
  body: string;
  created_at: string;
};

export function useTicketThread(ticketId: string | null | undefined) {
  const qc = useQueryClient();

  const query = useQuery({
    queryKey: ["ticket-thread", ticketId],
    enabled: !!ticketId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("customer_support_ticket_messages" as never)
        .select("id,ticket_id,author_type,author_user_id,author_name,body,created_at")
        .eq("ticket_id", ticketId as string)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as TicketMessage[];
    },
  });

  useEffect(() => {
    if (!ticketId) return;
    const channel = supabase
      .channel(`ticket-thread-${ticketId}`)
      .on(
        "postgres_changes" as never,
        {
          event: "INSERT",
          schema: "public",
          table: "customer_support_ticket_messages",
          filter: `ticket_id=eq.${ticketId}`,
        },
        () => qc.invalidateQueries({ queryKey: ["ticket-thread", ticketId] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [ticketId, qc]);

  return query;
}

export function useSendTicketReply() {
  const qc = useQueryClient();
  const { user, profile } = useAuth() as any;

  return useMutation({
    mutationFn: async ({
      ticketId,
      body,
      finalStatus,
    }: {
      ticketId: string;
      body: string;
      finalStatus?: TicketStatus;
    }) => {
      const trimmed = body.trim();
      if (!trimmed) throw new Error("Messaggio vuoto");
      if (!user?.id) throw new Error("Non autenticato");

      const authorName =
        profile?.full_name ||
        profile?.display_name ||
        user?.email ||
        "Staff Fraschetti";

      const { data: inserted, error: insErr } = await supabase
        .from("customer_support_ticket_messages" as never)
        .insert({
          ticket_id: ticketId,
          author_type: "staff",
          author_user_id: user.id,
          author_name: authorName,
          body: trimmed,
        } as never)
        .select("id")
        .single();
      if (insErr) throw insErr;

      const messageId = (inserted as { id: string }).id;

      // Lo stato viene aggiornato lato server (service role) dentro la edge function,
      // così funziona per tutti gli utenti abilitati e non fallisce in silenzio via RLS.
      const { data: fnData, error: fnErr } = await supabase.functions.invoke(
        "send-b2b-ticket-reply",
        { body: { ticket_id: ticketId, message_id: messageId, final_status: finalStatus ?? null } },
      );
      if (fnErr) {
        let details = fnErr.message;
        try {
          const ctx = (fnErr as unknown as { context?: Response }).context;
          if (ctx && typeof ctx.text === "function") {
            const txt = await ctx.text();
            try {
              details = JSON.parse(txt)?.error ?? txt;
            } catch {
              details = txt || details;
            }
          }
        } catch {
          /* ignore */
        }
        console.error("send-b2b-ticket-reply failed:", details);
        throw new Error(details);
      }

      return { messageId, status: (fnData as { status?: TicketStatus })?.status };
    },

    onSuccess: (_res, vars) => {
      qc.invalidateQueries({ queryKey: ["ticket-thread", vars.ticketId] });
      qc.invalidateQueries({ queryKey: ["b2b-tickets"] });
    },
  });
}

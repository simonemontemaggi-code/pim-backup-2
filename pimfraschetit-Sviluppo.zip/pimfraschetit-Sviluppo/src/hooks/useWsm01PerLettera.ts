import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useVisibleAssortments } from "@/hooks/useVisibleAssortments";

export interface Wsm01AggRow {
  lettera: string;
  wcdls: string;
  wsm01_value: number | null;
  n_articoli: number;
  n_distinti: number;
  min_val: number | null;
  max_val: number | null;
}

const SUPPORTED = new Set(["clas1", "cdst1", "wcdst"]);

/**
 * Returns aggregated wsm01 per (lettera classificazione, listino numerico),
 * limited to articles whose wfuas is in the admin-selected "Assortimenti Visibili".
 * Map: lettera -> wcdls -> AggRow.
 */
export function useWsm01PerLettera(category: string) {
  const enabled = SUPPORTED.has(category);
  const { data: visibleAssortments = [], isLoading: assortLoading } = useVisibleAssortments();

  return useQuery({
    queryKey: ["wsm01_per_lettera", category, visibleAssortments],
    enabled: enabled && !assortLoading,
    staleTime: 5 * 60 * 1000,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_wsm01_per_lettera", {
        p_category: category,
        p_visible_assortments: visibleAssortments.length > 0 ? visibleAssortments : null,
      } as any);
      if (error) throw error;
      const map = new Map<string, Map<string, Wsm01AggRow>>();
      for (const row of (data ?? []) as Wsm01AggRow[]) {
        if (!map.has(row.lettera)) map.set(row.lettera, new Map());
        map.get(row.lettera)!.set(row.wcdls, row);
      }
      return map;
    },
  });
}

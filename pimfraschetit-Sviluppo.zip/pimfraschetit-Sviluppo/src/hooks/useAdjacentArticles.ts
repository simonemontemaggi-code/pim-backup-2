import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function useAdjacentArticles(cdpar: string | undefined) {
  return useQuery({
    queryKey: ["adjacent-articles", cdpar],
    queryFn: async () => {
      if (!cdpar) return { prev: null, next: null };

      // Get previous article (cdpar < current, ordered desc, limit 1)
      const { data: prevData } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar,depar")
        .lt("cdpar", cdpar)
        .order("cdpar", { ascending: false })
        .limit(1)
        .maybeSingle();

      // Get next article (cdpar > current, ordered asc, limit 1)
      const { data: nextData } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar,depar")
        .gt("cdpar", cdpar)
        .order("cdpar", { ascending: true })
        .limit(1)
        .maybeSingle();

      return {
        prev: prevData ? { cdpar: prevData.cdpar, depar: prevData.depar } : null,
        next: nextData ? { cdpar: nextData.cdpar, depar: nextData.depar } : null,
      };
    },
    enabled: !!cdpar,
    staleTime: 60_000,
  });
}

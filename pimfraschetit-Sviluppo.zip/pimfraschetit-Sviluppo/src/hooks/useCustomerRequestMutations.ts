import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const TABLE = "nuovi_clienti_richieste" as const;

export function useApproveCustomerRequest() {
  const qc = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (args: {
      id: string;
      assigned_customer_code: string;
      assigned_zona: string | null;
      assigned_price_list: string;
      review_notes: string | null;
    }) => {
      const { error } = await supabase
        .from(TABLE as any)
        .update({
          status: "approved",
          assigned_customer_code: args.assigned_customer_code,
          assigned_zona: args.assigned_zona,
          assigned_price_list: args.assigned_price_list,
          review_notes: args.review_notes,
          reviewed_by: user?.id ?? null,
          reviewed_at: new Date().toISOString(),
        })
        .eq("id", args.id)
        .eq("status", "pending");
      if (error) throw error;
      // Fire-and-forget email (non blocca la UI)
      supabase.functions
        .invoke("send-customer-request-decision-email", {
          body: { request_id: args.id, decision: "approved" },
        })
        .catch((e) => console.error("[email approve] failed", e));
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["customer-requests"] });
      toast.success("Richiesta confermata — email inviata all'agente");
    },
    onError: (e: any) => toast.error(e.message ?? "Errore nella conferma"),
  });
}

export function useRejectCustomerRequest() {
  const qc = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (args: { id: string; rejection_reason: string }) => {
      const { error } = await supabase
        .from(TABLE as any)
        .update({
          status: "rejected",
          rejection_reason: args.rejection_reason,
          reviewed_by: user?.id ?? null,
          reviewed_at: new Date().toISOString(),
        })
        .eq("id", args.id)
        .eq("status", "pending");
      if (error) throw error;
      supabase.functions
        .invoke("send-customer-request-decision-email", {
          body: { request_id: args.id, decision: "rejected" },
        })
        .catch((e) => console.error("[email reject] failed", e));
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["customer-requests"] });
      toast.success("Richiesta respinta — email inviata all'agente");
    },
    onError: (e: any) => toast.error(e.message ?? "Errore nel rifiuto"),
  });
}

export function useReopenCustomerRequest() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from(TABLE as any)
        .update({
          status: "pending",
          assigned_customer_code: null,
          assigned_zona: null,
          rejection_reason: null,
          review_notes: null,
          reviewed_by: null,
          reviewed_at: null,
        })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["customer-requests"] });
      toast.success("Richiesta riaperta");
    },
    onError: (e: any) => toast.error(e.message ?? "Errore nella riapertura"),
  });
}

import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";

export function useHotkeys() {
  const navigate = useNavigate();
  const [shortcutsHelpOpen, setShortcutsHelpOpen] = useState(false);

  const handler = useCallback(
    (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const tag = target.tagName.toLowerCase();
      const isEditing =
        tag === "input" ||
        tag === "textarea" ||
        tag === "select" ||
        target.isContentEditable;

      const ctrl = e.metaKey || e.ctrlKey;

      // Ctrl+S — save (works even in inputs)
      if (ctrl && e.key === "s" && !e.shiftKey) {
        e.preventDefault();
        document.dispatchEvent(new CustomEvent("pim:save"));
        return;
      }

      // Ctrl+Shift combos (work even in inputs)
      if (ctrl && e.shiftKey) {
        if (e.key === "S" || e.key === "s") {
          e.preventDefault();
          navigate("/pim/sync");
          return;
        }
        if (e.key === "I" || e.key === "i") {
          e.preventDefault();
          navigate("/pim/import");
          return;
        }
        if (e.key === "M" || e.key === "m") {
          e.preventDefault();
          navigate("/pim/media");
          return;
        }
      }

      // Skip remaining shortcuts if editing
      if (isEditing) return;

      if (ctrl && e.key === "n") {
        e.preventDefault();
        navigate("/pim/articles");
        return;
      }

      if (ctrl && e.key === "f") {
        e.preventDefault();
        document.dispatchEvent(new CustomEvent("pim:focus-search"));
        return;
      }

      if (e.key === "Escape") {
        document.dispatchEvent(new CustomEvent("pim:close"));
        return;
      }

      if (e.key === "?") {
        setShortcutsHelpOpen(true);
        return;
      }
    },
    [navigate]
  );

  useEffect(() => {
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [handler]);

  return { shortcutsHelpOpen, setShortcutsHelpOpen };
}

import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function useActivePriceList() {
  return useQuery({
    queryKey: ["app_settings", "primary_price_list"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings")
        .select("setting_value")
        .eq("setting_key", "primary_price_list")
        .maybeSingle();
      if (error) throw error;
      if (!data?.setting_value) return null;
      return typeof data.setting_value === "string" ? data.setting_value : null;
    },
    staleTime: 300_000,
  });
}

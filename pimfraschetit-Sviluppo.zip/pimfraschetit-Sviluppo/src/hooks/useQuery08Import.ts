import { useCallback, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Q08Row } from "@/lib/query08Parser";

export interface Q08ImportStats {
  total: number;
  updated: number;
  inserted: number;
  unchanged: number;
  deleted?: number;
}

const CHUNK_SIZE = 1000;

export function useQuery08Import() {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stats, setStats] = useState<Q08ImportStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async (rows: Q08Row[], opts?: { overwrite?: boolean }) => {
    setIsRunning(true);
    setProgress(0);
    setError(null);
    setStats(null);
    const agg: Q08ImportStats = { total: 0, updated: 0, inserted: 0, unchanged: 0, deleted: 0 };
    try {
      if (opts?.overwrite) {
        const { data, error: trErr } = await supabase.rpc(
          "truncate_listini_vendita_criteri_prezzo" as any,
        );
        if (trErr) throw trErr;
        agg.deleted = (data as any)?.deleted ?? 0;
        setStats({ ...agg });
      }
      for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
        const chunk = rows.slice(i, i + CHUNK_SIZE);
        const { data, error: rpcErr } = await supabase.rpc(
          "import_query08_criteri_prezzo" as any,
          { p_rows: chunk as any },
        );
        if (rpcErr) throw rpcErr;
        const r = (data ?? {}) as Q08ImportStats;
        agg.total += r.total ?? 0;
        agg.updated += r.updated ?? 0;
        agg.inserted += r.inserted ?? 0;
        agg.unchanged += r.unchanged ?? 0;
        setProgress(Math.min(100, ((i + chunk.length) / rows.length) * 100));
        setStats({ ...agg });
      }
      setProgress(100);
    } catch (e: any) {
      console.error("[Q08 Import] errore:", e);
      setError(e?.message ?? "Errore import");
    } finally {
      setIsRunning(false);
    }
  }, []);

  const reset = useCallback(() => {
    setStats(null);
    setProgress(0);
    setError(null);
    setIsRunning(false);
  }, []);

  return { run, reset, isRunning, progress, stats, error };
}

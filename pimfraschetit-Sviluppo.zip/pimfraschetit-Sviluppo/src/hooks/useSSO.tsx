import { useEffect, useState, useCallback } from "react";
import { ssoTokenManager, isTokenExpired, type SSORole } from "@/lib/sso-supabase-client";
import { supabase } from "@/integrations/supabase/client";

// PIM app_id (registered in hub.apps). Fallback "pim" is also accepted by the edge function (ilike on name).
const PIM_APP_ID = "5f7f4b6e-5ada-4f37-b846-26de4c13a0d1";
const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;

interface VerifyResponse {
  authorized: boolean;
  user?: { id: string; email: string };
  profile?: {
    user_id: string;
    full_name: string | null;
    avatar_url: string | null;
    [k: string]: unknown;
  } | null;
  role?: SSORole;
  permissions?: {
    access_level: SSORole;
    ui_permission_config: Record<string, unknown>;
  };
  app?: { id: string; name: string };
  error?: string;
}

function cleanUrl() {
  try {
    const url = new URL(window.location.href);
    url.searchParams.delete("token");
    url.searchParams.delete("app_id");
    window.history.replaceState({}, "", url.pathname + (url.search || "") + url.hash);
  } catch {
    /* no-op */
  }
}

async function verifyAndStore(token: string, appId: string): Promise<VerifyResponse | null> {
  try {
    const res = await fetch(`${SUPABASE_URL}/functions/v1/verify-app-access`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
        apikey: SUPABASE_ANON_KEY,
      },
      body: JSON.stringify({ app_id: appId }),
    });
    const data: VerifyResponse = await res.json();
    if (!res.ok || !data.authorized) {
      console.error("[SSO] ❌ Accesso non autorizzato:", data.error ?? res.status);
      return null;
    }
    ssoTokenManager.setToken(token);
    if (data.user) ssoTokenManager.setUser(data.user);
    if (data.profile !== undefined) ssoTokenManager.setProfile(data.profile ?? null);
    if (data.role) ssoTokenManager.setRole(data.role);
    if (data.permissions) ssoTokenManager.setPermissions(data.permissions);

    // Upsert the PIM-side profile so AuthGuard can let the user in.
    if (data.user) {
      try {
        await supabase.from("profiles").upsert(
          {
            user_id: data.user.id,
            email: data.user.email,
            full_name: data.profile?.full_name ?? data.user.email,
            avatar_url: data.profile?.avatar_url ?? null,
          } as any,
          { onConflict: "user_id" }
        );
      } catch (e) {
        console.warn("[SSO] profile upsert fallito (non bloccante):", e);
      }
    }

    console.log("[SSO] ✅ Accesso autorizzato!", data.user?.email);
    return data;
  } catch (e) {
    console.error("[SSO] verify-app-access errore:", e);
    return null;
  }
}

export async function processSSOFromUrlIfAny(): Promise<boolean> {
  try {
    const url = new URL(window.location.href);
    const token = url.searchParams.get("token");
    const appId = url.searchParams.get("app_id");
    if (!token) {
      const existing = ssoTokenManager.getToken();
      if (existing && isTokenExpired(existing)) ssoTokenManager.clear();
      return ssoTokenManager.hasSession();
    }
    if (isTokenExpired(token)) {
      console.warn("[SSO] token in URL già scaduto");
      ssoTokenManager.clear();
      cleanUrl();
      return false;
    }
    const data = await verifyAndStore(token, appId || PIM_APP_ID);
    cleanUrl();
    return !!data;
  } catch (e) {
    console.error("[SSO] processSSOFromUrlIfAny errore:", e);
    return false;
  }
}

export function useSSO() {
  const [ready, setReady] = useState(false);
  const [authorized, setAuthorized] = useState(ssoTokenManager.hasSession());

  const refresh = useCallback(() => {
    setAuthorized(ssoTokenManager.hasSession());
  }, []);

  useEffect(() => {
    (async () => {
      await processSSOFromUrlIfAny();
      refresh();
      setReady(true);
    })();

    const onStorage = (e: StorageEvent) => {
      if (e.key && e.key.startsWith("sso_")) refresh();
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, [refresh]);

  return { ready, authorized };
}


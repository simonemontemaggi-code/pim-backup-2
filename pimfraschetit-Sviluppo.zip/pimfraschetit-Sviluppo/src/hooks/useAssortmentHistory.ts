import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { todayAs400, nowAs400Time } from "@/lib/dateUtils";

export interface AssortmentRecord {
  wstato: string;
  wdtdec: string; // AAAAMMGG
  wprogr: string;
}

export interface AssortmentStatus {
  current: AssortmentRecord | null;
  future: AssortmentRecord | null;
  maxProgr: number;
}

/**
 * Fetch all storico_assortimenti rows for an article and split into
 * current (wdtdec <= today, most recent) and future (wdtdec > today, nearest).
 *
 * `wchfil` in AS400 is space-padded; we match by trim.
 */
export function useAssortmentStatus(cdpar: string | undefined) {
  return useQuery({
    queryKey: ["assortment_status", cdpar],
    queryFn: async (): Promise<AssortmentStatus> => {
      if (!cdpar) return { current: null, future: null, maxProgr: 0 };
      const trimmed = cdpar.trim();
      // Try exact (already padded) and trimmed variants
      const { data, error } = await supabase
        .from("storico_assortimenti")
        .select("wstato, wdtdec, wprogr, wchfil")
        .or(`wchfil.eq.${cdpar},wchfil.like.${trimmed}%`)
        .order("wdtdec", { ascending: false });
      if (error) throw error;

      // Filter client-side to ensure trim-match
      const rows = (data ?? []).filter(
        (r: any) => (r.wchfil ?? "").trim() === trimmed && r.wdtdec
      ) as AssortmentRecord[];

      const today = todayAs400();
      let current: AssortmentRecord | null = null;
      let future: AssortmentRecord | null = null;
      let maxProgr = 0;

      for (const r of rows) {
        const p = parseInt(r.wprogr ?? "0", 10);
        if (!isNaN(p) && p > maxProgr) maxProgr = p;
        if (r.wdtdec <= today) {
          if (!current || r.wdtdec > current.wdtdec) current = r;
        } else {
          if (!future || r.wdtdec < future.wdtdec) future = r;
        }
      }

      return { current, future, maxProgr };
    },
    enabled: !!cdpar,
    staleTime: 60_000,
  });
}

/**
 * Insert a new assortment status change row (append-only log).
 */
export function useInsertAssortmentHistory() {
  const qc = useQueryClient();
  const { user, profile } = useAuth();

  return useMutation({
    mutationFn: async (params: {
      cdpar: string;
      wstato: string;
      wdtdec: string; // AAAAMMGG
      maxProgr: number;
    }) => {
      // Pad wchfil to match AS400 format (256 chars observed in data)
      const wchfil = params.cdpar.padEnd(256, " ");
      const newProgr = (params.maxProgr + 1).toString();
      const today = todayAs400();
      const now = nowAs400Time();
      const userTag = (profile?.email || user?.email || "PIM").slice(0, 10);

      const { error } = await supabase.from("storico_assortimenti").insert({
        wchfil,
        wstato: params.wstato,
        wdtdec: params.wdtdec,
        wprogr: newProgr,
        wdtcre: today,
        worcre: now,
        wutcre: userTag,
        wdtvar: today,
        worvar: now,
        wutvar: userTag,
      } as any);
      if (error) throw error;

      // Enqueue AS400 sync (upsert planned change)
      await supabase.from("as400_sync_queue").insert({
        cdpar: params.cdpar,
        operation: "assortment_upsert",
        status: "pending",
        payload: {
          table: "storico_assortimenti",
          action: "upsert",
          wchfil,
          wstato: params.wstato,
          wdtdec: params.wdtdec,
          wprogr: newProgr,
          wdtvar: today,
          worvar: now,
          wutvar: userTag,
        } as any,
      } as any);

      // Mark article as pending sync
      await supabase
        .from("archivio_articoli_fraschetti")
        .update({ as400_sync_status: "pending" })
        .eq("cdpar", params.cdpar);
    },
    onSuccess: (_data, vars) => {
      qc.invalidateQueries({ queryKey: ["assortment_status", vars.cdpar] });
    },
  });
}

/**
 * Delete a planned (future) assortment row identified by cdpar + wprogr.
 * AS400 reads the same storico, so removing the row cancels the planned change.
 */
export function useDeleteAssortmentFuture() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (params: { cdpar: string; wprogr: string }) => {
      const trimmed = params.cdpar.trim();
      // Find rows matching cdpar (trim-tolerant) + wprogr, then delete by id
      const { data: rows, error: selErr } = await supabase
        .from("storico_assortimenti")
        .select("id, wchfil, wprogr")
        .eq("wprogr", params.wprogr)
        .or(`wchfil.eq.${params.cdpar},wchfil.like.${trimmed}%`);
      if (selErr) throw selErr;
      const ids = (rows ?? [])
        .filter((r: any) => (r.wchfil ?? "").trim() === trimmed)
        .map((r: any) => r.id);
      if (ids.length === 0) return;
      const { error } = await supabase.from("storico_assortimenti").delete().in("id", ids);
      if (error) throw error;

      // Enqueue AS400 sync (delete planned change)
      const wchfil = params.cdpar.padEnd(256, " ");
      await supabase.from("as400_sync_queue").insert({
        cdpar: params.cdpar,
        operation: "assortment_delete",
        status: "pending",
        payload: {
          table: "storico_assortimenti",
          action: "delete",
          wchfil,
          wprogr: params.wprogr,
        } as any,
      } as any);

      await supabase
        .from("archivio_articoli_fraschetti")
        .update({ as400_sync_status: "pending" })
        .eq("cdpar", params.cdpar);
    },
    onSuccess: (_d, vars) => {
      qc.invalidateQueries({ queryKey: ["assortment_status", vars.cdpar] });
    },
  });
}

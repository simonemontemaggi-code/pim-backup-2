import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type SourceFilter = "all" | "b2b" | "agent_hub";

const srcParam = (s: SourceFilter) => (s === "all" ? null : s);

export function useSearchMissesAgg(from: Date, to: Date, source: SourceFilter, minCount: number) {
  return useQuery({
    queryKey: ["nav-search-agg", from.toISOString(), to.toISOString(), source, minCount],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("pim_search_misses_agg" as any, {
        _from: from.toISOString(), _to: to.toISOString(),
        _source: srcParam(source), _min_count: minCount,
      });
      if (error) throw error;
      return (data ?? []) as Array<{
        query: string; n: number; n_users: number; n_customers: number;
        last_seen: string; n_b2b: number; n_agent: number; resolved_at: string | null;
      }>;
    },
  });
}

export function useSearchMissesTimeseries(from: Date, to: Date) {
  return useQuery({
    queryKey: ["nav-search-ts", from.toISOString(), to.toISOString()],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("pim_search_misses_timeseries" as any, {
        _from: from.toISOString(), _to: to.toISOString(),
      });
      if (error) throw error;
      return (data ?? []) as Array<{ bucket: string; n: number }>;
    },
  });
}

export function useArticlePerfTop(from: Date, to: Date, source: SourceFilter, orderBy: string, limit: number) {
  return useQuery({
    queryKey: ["nav-art-top", from.toISOString(), to.toISOString(), source, orderBy, limit],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("pim_article_perf_top" as any, {
        _from: from.toISOString(), _to: to.toISOString(),
        _source: srcParam(source), _order_by: orderBy, _limit: limit,
      });
      if (error) throw error;
      return (data ?? []) as Array<{
        cdpar: string; views: number; cart_adds: number; orders: number; conversion_rate: number;
      }>;
    },
  });
}

export function useArticleTimeseries(cdpar: string | null, from: Date, to: Date) {
  return useQuery({
    queryKey: ["nav-art-ts", cdpar, from.toISOString(), to.toISOString()],
    enabled: !!cdpar,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("pim_article_timeseries" as any, {
        _cdpar: cdpar, _from: from.toISOString(), _to: to.toISOString(),
      });
      if (error) throw error;
      return (data ?? []) as Array<{
        bucket: string; views: number; cart_adds: number; cart_removes: number; orders: number;
      }>;
    },
  });
}

export function useArticleSearchReferrers(cdpar: string | null, from: Date, to: Date) {
  return useQuery({
    queryKey: ["nav-art-ref", cdpar, from.toISOString(), to.toISOString()],
    enabled: !!cdpar,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("pim_article_search_referrers" as any, {
        _cdpar: cdpar, _from: from.toISOString(), _to: to.toISOString(),
      });
      if (error) throw error;
      return (data ?? []) as Array<{ query: string; n: number; last_seen: string }>;
    },
  });
}

export function useArticleMeta(cdpars: string[]) {
  return useQuery({
    queryKey: ["nav-art-meta", cdpars.slice().sort().join(",")],
    enabled: cdpars.length > 0,
    queryFn: async () => {
      const padded = cdpars.map((c) => c.padEnd(15, " "));
      const { data, error } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar, descrizione, titolo_b2b, descrizione_variante, clas2")
        .in("cdpar", padded);
      if (error) throw error;
      const clasCodes = Array.from(new Set((data ?? []).map((r: any) => r.clas2).filter(Boolean)));
      let brandMap = new Map<string, string>();
      if (clasCodes.length) {
        const { data: brands } = await supabase
          .from("archivio_brand_fraschetti")
          .select("clas2, display_name, nome_as400_brand")
          .in("clas2", clasCodes);
        (brands ?? []).forEach((b: any) => {
          brandMap.set(b.clas2, b.display_name || b.nome_as400_brand || b.clas2);
        });
      }
      const map = new Map<string, { descr: string | null; brand: string | null }>();
      (data ?? []).forEach((r: any) => {
        const key = String(r.cdpar).trim();
        const titolo = (r.titolo_b2b ?? "").toString().trim();
        const variante = (r.descrizione_variante ?? "").toString().trim();
        const composed = [titolo, variante].filter(Boolean).join(" · ") || r.descrizione || null;
        map.set(key, { descr: composed, brand: r.clas2 ? (brandMap.get(r.clas2) ?? r.clas2) : null });
      });
      return map;
    },
  });
}

import { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

export type SelfOnboardingStatus = "pending" | "reviewing" | "approved" | "rejected";

// Il B2B scrive status = "new" per le richieste appena inviate.
// Nel PIM le mostriamo come "pending".
const STATUS_TO_DB: Record<SelfOnboardingStatus, string[]> = {
  pending: ["pending", "new"],
  reviewing: ["reviewing"],
  approved: ["approved"],
  rejected: ["rejected"],
};

export interface SelfOnboardingRequest {
  id: string;
  status: SelfOnboardingStatus;
  ragione_sociale: string | null;
  partita_iva: string | null;
  email_aziendale: string | null;
  pec: string | null;
  sdi: string | null;
  nome: string | null;
  cognome: string | null;
  prefisso_internazionale: string | null;
  telefono: string | null;
  indirizzo: string | null;
  citta: string | null;
  provincia: string | null;
  cap: string | null;
  tipologia: string | null;
  settore_rivenditore: string | null;
  tipo_altro: string | null;
  descrizione_attivita: string | null;
  codice_ateco: string | null;
  descrizione_ateco: string | null;
  consenso_privacy: boolean | null;
  consenso_termini: boolean | null;
  consenso_clausole: boolean | null;
  marketing_newsletter: boolean | null;
  marketing_sms: boolean | null;
  notes_admin: string | null;
  payload_json: any;
  source: string | null;
  user_agent: string | null;
  processed_by: string | null;
  processed_at: string | null;
  created_at: string;
  updated_at: string | null;
}

const TABLE = "b2b_self_onboarding_requests" as const;

export function useSelfOnboardingList(status: SelfOnboardingStatus) {
  useSelfOnboardingRealtime();
  return useQuery({
    queryKey: ["self-onboarding", "list", status],
    queryFn: async () => {
      const { data, error } = await supabase
        .from(TABLE as any)
        .select("*")
        .in("status", STATUS_TO_DB[status])
        .order("created_at", { ascending: false })
        .limit(500);
      if (error) throw error;
      return (data ?? []) as unknown as SelfOnboardingRequest[];
    },
  });
}

export function useSelfOnboardingPendingCount() {
  useSelfOnboardingRealtime();
  return useQuery({
    queryKey: ["self-onboarding", "count", "pending"],
    queryFn: async () => {
      const { count, error } = await supabase
        .from(TABLE as any)
        .select("id", { count: "exact", head: true })
        .in("status", STATUS_TO_DB.pending);
      if (error) throw error;
      return count ?? 0;
    },
  });
}

export function useUpdateSelfOnboardingStatus() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({
      id,
      status,
      notes,
    }: {
      id: string;
      status: SelfOnboardingStatus;
      notes?: string | null;
    }) => {
      const { data: userRes } = await supabase.auth.getUser();
      const uid = userRes?.user?.id ?? null;
      const patch: Record<string, unknown> = {
        status,
        processed_by: uid,
        processed_at: new Date().toISOString(),
      };
      if (typeof notes === "string") patch.notes_admin = notes;
      const { error } = await supabase.from(TABLE as any).update(patch).eq("id", id);
      if (error) throw error;
    },
    onSuccess: (_d, vars) => {
      qc.invalidateQueries({ queryKey: ["self-onboarding"] });
      const label =
        vars.status === "approved"
          ? "Richiesta approvata"
          : vars.status === "rejected"
            ? "Richiesta respinta"
            : vars.status === "reviewing"
              ? "Richiesta in revisione"
              : "Richiesta aggiornata";
      toast({ title: label });
    },
    onError: (e: any) => {
      toast({
        title: "Errore",
        description: e?.message ?? "Impossibile aggiornare la richiesta.",
        variant: "destructive",
      });
    },
  });
}

export function useDeleteSelfOnboardingRequest() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from(TABLE as any).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["self-onboarding"] });
      toast({ title: "Richiesta eliminata" });
    },
    onError: (e: any) => {
      toast({
        title: "Errore",
        description: e?.message ?? "Impossibile eliminare la richiesta.",
        variant: "destructive",
      });
    },
  });
}

let realtimeSubscribers = 0;
let realtimeChannel: ReturnType<typeof supabase.channel> | null = null;

export function useSelfOnboardingRealtime() {
  const qc = useQueryClient();
  useEffect(() => {
    realtimeSubscribers += 1;
    if (!realtimeChannel) {
      realtimeChannel = supabase
        .channel("self-onboarding-requests")
        .on(
          "postgres_changes" as any,
          { event: "*", schema: "public", table: TABLE },
          () => {
            qc.invalidateQueries({ queryKey: ["self-onboarding"] });
          },
        )
        .subscribe();
    }
    return () => {
      realtimeSubscribers -= 1;
      if (realtimeSubscribers <= 0 && realtimeChannel) {
        supabase.removeChannel(realtimeChannel);
        realtimeChannel = null;
        realtimeSubscribers = 0;
      }
    };
  }, [qc]);
}

import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import { exportAs400Change } from "@/lib/as400Export";

interface SaveOpts {
  table: string;
  recordId: string; // cdpar
  oldValues: Record<string, any>;
}

function normalize(val: any): any {
  if (val === null || val === undefined || val === "") return null;
  if (typeof val === "number") return Number.isNaN(val) ? null : val;
  return val;
}

function normalizeCdpar(value: string): string {
  return value.trim().padEnd(15, " ");
}

export function useSaveArticle({ table, recordId, oldValues }: SaveOpts) {
  const queryClient = useQueryClient();
  const { user, profile } = useAuth();
  const normalizedRecordId = normalizeCdpar(recordId);

  return useMutation({
    mutationFn: async (newValues: Record<string, any>) => {
      // 1. Compute changed fields (normalize empty strings & nulls)
      const changedFields: string[] = [];
      const changes: Record<string, any> = {};
      for (const [k, v] of Object.entries(newValues)) {
        if (normalize(v) !== normalize(oldValues[k]) && 
            JSON.stringify(normalize(v)) !== JSON.stringify(normalize(oldValues[k]))) {
          changedFields.push(k);
          changes[k] = v;
        }
      }
      if (changedFields.length === 0) return { changedCount: 0 };

      // 2. Save to Supabase — usa .select() per rilevare update bloccati da RLS (0 righe)
      const { data: updatedRows, error } = await supabase
        .from(table as any)
        .update(changes)
        .eq("cdpar", normalizedRecordId)
        .select("cdpar");
      if (error) throw error;
      if (!updatedRows || updatedRows.length === 0) {
        throw new Error(
          "Nessuna riga aggiornata: permessi insufficienti per modificare questo articolo (contatta un amministratore) oppure record non trovato."
        );
      }

      // 3. Update sync status on main article if table is articles
      if (table === "archivio_articoli_fraschetti") {
        const syncUpdate: Record<string, any> = { updated_by: user?.id };
        if (oldValues.as400_sync_status === "synced") {
          syncUpdate.as400_sync_status = "modified";
        }
        await supabase
          .from("archivio_articoli_fraschetti")
          .update(syncUpdate as any)
          .eq("cdpar", normalizedRecordId);
      }

      // 4. Audit log
      await supabase.from("audit_log" as any).insert({
        table_name: table,
        record_id: recordId,
        operation: "update",
        old_values: Object.fromEntries(changedFields.map((f) => [f, oldValues[f]])),
        new_values: Object.fromEntries(changedFields.map((f) => [f, newValues[f]])),
        changed_fields: changedFields,
        user_id: user?.id,
        user_email: profile?.email,
      });

      // 5. Download structured AS400 JSON (only changed fields)
      exportAs400Change({
        user: profile?.email ?? user?.email,
        record: recordId,
        table,
        change: {
          operation: "update",
          key: { cdpar: normalizedRecordId },
          fields: changes,
        },
        filenamePrefix: "as400_articolo",
      });

      return { changedCount: changedFields.length };
    },
    onSuccess: (result) => {
      if (result && result.changedCount > 0) {
        toast({
          title: "Salvato",
          description: `${result.changedCount} camp${result.changedCount === 1 ? "o modificato" : "i modificati"}. JSON scaricato.`,
        });
      }
      const cdparKey = recordId.trim();
      queryClient.invalidateQueries({ queryKey: ["article", cdparKey] });
      queryClient.invalidateQueries({ queryKey: ["articles"] });
      queryClient.invalidateQueries({ queryKey: ["article_purchase", cdparKey] });
    },
    onError: (e: Error) => {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    },
  });
}

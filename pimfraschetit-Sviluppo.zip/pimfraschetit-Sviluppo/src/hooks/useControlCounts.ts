import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useVisibleAssortments } from "./useVisibleAssortments";

export interface SettoreEntry {
  code: string;
  label: string;
  count: number;
}

export interface ControlCounts {
  total: number;
  no_image: number;
  no_desc: number;
  no_st: number;
  no_attr: number;
  no_attr_any: number;
  no_reparto: number;
  no_gamma: number;
  clmer_legacy: number;
  no_listino: number;
  settori: SettoreEntry[];
  forn_no_buyer: number;
  forn_no_dp: number;
  brand_no_img: number;
}

export function useControlCounts(override?: string[], onlyB2bOnline?: boolean) {
  const { data: assortments } = useVisibleAssortments();
  const effective = override && override.length > 0 ? override : assortments;
  return useQuery({
    queryKey: ["controls_counts", effective, !!onlyB2bOnline],
    queryFn: async (): Promise<ControlCounts> => {
      const { data, error } = await supabase.rpc("controls_counts" as any, {
        visible_assortments: effective && effective.length > 0 ? effective : null,
        only_b2b_online: !!onlyB2bOnline,
      });
      if (error) throw error;
      return data as ControlCounts;
    },
    staleTime: 5 * 60 * 1000,
  });
}

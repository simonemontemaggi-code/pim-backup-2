import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/**
 * Risolve `user_id` → `full_name` consultando `profiles`.
 * Utile quando più sotto-utenti condividono la stessa email reparto
 * (es. dispo@fraschetti.com) e l'email da sola non identifica la persona.
 */
export function useUserDisplayNames(userIds: (string | null | undefined)[]) {
  const unique = Array.from(
    new Set(userIds.filter((x): x is string => !!x))
  ).sort();
  const key = unique.join(",");

  const { data } = useQuery({
    queryKey: ["user_display_names", key],
    enabled: unique.length > 0,
    staleTime: 5 * 60_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("user_id, full_name, email")
        .in("user_id", unique);
      if (error) throw error;
      const map: Record<string, { full_name: string | null; email: string | null }> = {};
      (data ?? []).forEach((p: any) => {
        map[p.user_id] = { full_name: p.full_name ?? null, email: p.email ?? null };
      });
      return map;
    },
  });

  /** Ritorna "Mario Rossi (mario@x.it)" oppure fallback su email/user_id. */
  const display = (user_id: string | null | undefined, fallbackEmail?: string | null): string => {
    if (!user_id) return fallbackEmail ?? "—";
    const p = data?.[user_id];
    if (p?.full_name) return p.email ? `${p.full_name} (${p.email})` : p.full_name;
    return fallbackEmail ?? p?.email ?? user_id.slice(0, 8);
  };

  return { display, map: data ?? {} };
}

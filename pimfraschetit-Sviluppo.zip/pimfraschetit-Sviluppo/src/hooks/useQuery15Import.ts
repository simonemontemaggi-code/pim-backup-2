import { useCallback, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Q15Row } from "@/lib/query15Parser";

export interface Q15ImportStats {
  total: number;
  matched: number;
  inserted: number;
  updated: number;
  unchanged: number;
  missing: number;
}

const CHUNK_SIZE = 2000;

export function useQuery15Import() {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stats, setStats] = useState<Q15ImportStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async (rows: Q15Row[]) => {
    setIsRunning(true);
    setProgress(0);
    setError(null);
    setStats(null);
    const agg: Q15ImportStats = { total: 0, matched: 0, inserted: 0, updated: 0, unchanged: 0, missing: 0 };
    try {
      for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
        const chunk = rows.slice(i, i + CHUNK_SIZE);
        const { data, error: rpcErr } = await supabase.rpc(
          "import_query15_elementi" as any,
          { p_rows: chunk as any },
        );
        if (rpcErr) throw rpcErr;
        const r = (data ?? {}) as Q15ImportStats;
        agg.total += r.total ?? 0;
        agg.matched += r.matched ?? 0;
        agg.inserted += (r as any).inserted ?? 0;
        agg.updated += r.updated ?? 0;
        agg.unchanged += r.unchanged ?? 0;
        agg.missing += r.missing ?? 0;
        setProgress(Math.min(100, ((i + chunk.length) / rows.length) * 100));
        setStats({ ...agg });
      }
      setProgress(100);
    } catch (e: any) {
      console.error("[Q15 Import] errore:", e);
      setError(e?.message ?? "Errore import");
    } finally {
      setIsRunning(false);
    }
  }, []);

  const reset = useCallback(() => {
    setStats(null);
    setProgress(0);
    setError(null);
    setIsRunning(false);
  }, []);

  return { run, reset, isRunning, progress, stats, error };
}

import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/**
 * Codici wfuas che vengono considerati "online B2B" per default.
 * Un articolo è online se:
 *   - b2b_online_active = true (override manuale "forza online"), OPPURE
 *   - b2b_online_active IS NULL E wfuas è nell'elenco online_assortments
 * Se b2b_online_active = false → override manuale "forza offline".
 */
export function useOnlineAssortments() {
  return useQuery({
    queryKey: ["app_settings", "online_assortments"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings")
        .select("setting_value")
        .eq("setting_key", "online_assortments")
        .maybeSingle();
      if (error) throw error;
      const val = data?.setting_value;
      return Array.isArray(val) ? (val as string[]) : [];
    },
    staleTime: 300_000,
  });
}

/** Computa lo stato online effettivo di un articolo. */
export function computeIsB2bOnline(
  b2bOnlineActive: boolean | null | undefined,
  wfuas: string | null | undefined,
  onlineAssortments: string[]
): boolean {
  if (b2bOnlineActive === true) return true;
  if (b2bOnlineActive === false) return false;
  // NULL → auto: dipende da wfuas
  const code = (wfuas ?? "").trim();
  if (!code) return false;
  return Array.isArray(onlineAssortments) && onlineAssortments.map((v) => v.trim()).includes(code);
}

/** Override mode for the 3-state select */
export type B2bOverrideMode = "auto" | "force_on" | "force_off";

export function b2bValueToMode(v: boolean | null | undefined): B2bOverrideMode {
  if (v === true) return "force_on";
  if (v === false) return "force_off";
  return "auto";
}

export function b2bModeToValue(m: B2bOverrideMode): boolean | null {
  if (m === "force_on") return true;
  if (m === "force_off") return false;
  return null;
}

/**
 * Costruisce la clausola `.or()` per filtrare gli articoli online B2B.
 * Online = (b2b_online_active = true) OR (b2b_online_active IS NULL AND wfuas IN onlineAssortments)
 */
export function buildOnlineB2bOrFilter(onlineAssortments: string[]): string {
  const list = onlineAssortments.map((c) => c.replace(/[,()"]/g, "")).join(",");
  if (!list) return "b2b_online_active.eq.true";
  return `b2b_online_active.eq.true,and(b2b_online_active.is.null,wfuas.in.(${list}))`;
}


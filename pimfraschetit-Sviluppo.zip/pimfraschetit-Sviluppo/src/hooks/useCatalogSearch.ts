import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface CatalogSearchWeights {
  exact_code: number;
  prefix_code: number;
  title_exact?: number;
  title_starts?: number;
  title_all_words?: number;
  title_word: number;
  title_lexeme: number;
  prefix_last_word: number;
  taxonomy: number;
  brand_tag: number;
  description: number;
  fuzzy: number;
}

export interface CatalogSearchConfig {
  version: number;
  min_chars: number;
  debounce_ms: number;
  fuzzy_enabled: boolean;
  fuzzy_min_chars: number;
  fuzzy_threshold: number;
  fuzzy_fallback_count: number;
  description_search_enabled: boolean;
  weights: CatalogSearchWeights;
  updated_at: string | null;
}

export interface CatalogSearchSynonym {
  id: string;
  term: string;
  synonym: string;
  bidirectional: boolean;
  active: boolean;
  notes: string | null;
}

export interface CatalogSearchExclusion {
  id: string;
  term: string;
  exclusion_type: string;
  active: boolean;
  notes: string | null;
}

export interface CatalogSearchOverride {
  cdpar: string;
  boost: number;
  excluded_from_search: boolean;
  notes: string | null;
}

export interface CatalogSearchHit {
  cdpar: string;
  visible_cdpar: string;
  matched_cdpar: string;
  title: string;
  brand_name: string | null;
  cod_padre: string | null;
  score: number;
  match_fields: string[] | null;
  match_reasons: Record<string, unknown> | null;
  total_count: number;
  has_more: boolean;
  config_version: number;
}

const sb = supabase as any;

/* ---------------- config ---------------- */

export function useCatalogSearchConfig() {
  return useQuery({
    queryKey: ["catalog-search-config"],
    queryFn: async (): Promise<CatalogSearchConfig> => {
      const { data, error } = await sb.from("catalog_search_config").select("*").maybeSingle();
      if (error) throw error;
      return data as CatalogSearchConfig;
    },
  });
}

export function useSaveCatalogSearchConfig() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (patch: Partial<CatalogSearchConfig>) => {
      const { error } = await sb.from("catalog_search_config").update(patch).eq("id", true);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["catalog-search-config"] });
      toast.success("Parametri salvati");
    },
    onError: (e: any) => toast.error(e.message ?? "Errore salvataggio"),
  });
}

/* ---------------- synonyms ---------------- */

export function useCatalogSearchSynonyms() {
  return useQuery({
    queryKey: ["catalog-search-synonyms"],
    queryFn: async (): Promise<CatalogSearchSynonym[]> => {
      const { data, error } = await sb
        .from("catalog_search_synonyms")
        .select("id, term, synonym, bidirectional, active, notes")
        .order("term")
        .limit(2000);
      if (error) throw error;
      return (data ?? []) as CatalogSearchSynonym[];
    },
  });
}

export function useSynonymMutations() {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: ["catalog-search-synonyms"] });

  const upsert = useMutation({
    mutationFn: async (row: Partial<CatalogSearchSynonym>) => {
      if (row.id) {
        const { error } = await sb.from("catalog_search_synonyms").update(row).eq("id", row.id);
        if (error) throw error;
      } else {
        const { error } = await sb.from("catalog_search_synonyms").insert(row);
        if (error) throw error;
      }
    },
    onSuccess: () => { invalidate(); toast.success("Sinonimo salvato"); },
    onError: (e: any) => toast.error(e.message ?? "Errore"),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await sb.from("catalog_search_synonyms").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Sinonimo eliminato"); },
    onError: (e: any) => toast.error(e.message ?? "Errore"),
  });

  return { upsert, remove };
}

/* ---------------- exclusions ---------------- */

export function useCatalogSearchExclusions() {
  return useQuery({
    queryKey: ["catalog-search-exclusions"],
    queryFn: async (): Promise<CatalogSearchExclusion[]> => {
      const { data, error } = await sb
        .from("catalog_search_exclusions")
        .select("id, term, exclusion_type, active, notes")
        .order("term")
        .limit(2000);
      if (error) throw error;
      return (data ?? []) as CatalogSearchExclusion[];
    },
  });
}

export function useExclusionMutations() {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: ["catalog-search-exclusions"] });

  const upsert = useMutation({
    mutationFn: async (row: Partial<CatalogSearchExclusion>) => {
      if (row.id) {
        const { error } = await sb.from("catalog_search_exclusions").update(row).eq("id", row.id);
        if (error) throw error;
      } else {
        const { error } = await sb.from("catalog_search_exclusions").insert(row);
        if (error) throw error;
      }
    },
    onSuccess: () => { invalidate(); toast.success("Parola salvata"); },
    onError: (e: any) => toast.error(e.message ?? "Errore"),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await sb.from("catalog_search_exclusions").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Parola eliminata"); },
    onError: (e: any) => toast.error(e.message ?? "Errore"),
  });

  return { upsert, remove };
}

/* ---------------- product overrides ---------------- */

export function useCatalogSearchOverrides() {
  return useQuery({
    queryKey: ["catalog-search-overrides"],
    queryFn: async (): Promise<CatalogSearchOverride[]> => {
      const { data, error } = await sb
        .from("catalog_search_product_overrides")
        .select("cdpar, boost, excluded_from_search, notes")
        .order("cdpar")
        .limit(2000);
      if (error) throw error;
      return (data ?? []) as CatalogSearchOverride[];
    },
  });
}

export function useOverrideMutations() {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: ["catalog-search-overrides"] });

  const upsert = useMutation({
    mutationFn: async (row: CatalogSearchOverride) => {
      const { error } = await sb
        .from("catalog_search_product_overrides")
        .upsert({ ...row, cdpar: row.cdpar.trim().padStart(6, "0") }, { onConflict: "cdpar" });
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Priorità salvata"); },
    onError: (e: any) => toast.error(e.message ?? "Errore"),
  });

  const remove = useMutation({
    mutationFn: async (cdpar: string) => {
      const { error } = await sb.from("catalog_search_product_overrides").delete().eq("cdpar", cdpar);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Priorità rimossa"); },
    onError: (e: any) => toast.error(e.message ?? "Errore"),
  });

  return { upsert, remove };
}

/* ---------------- diagnostics ---------------- */

export function useCatalogSearchStatus() {
  return useQuery({
    queryKey: ["catalog-search-status"],
    queryFn: async () => {
      const [total, b2b, agent, log] = await Promise.all([
        sb.from("catalog_search_index").select("cdpar", { count: "exact", head: true }),
        sb.from("catalog_search_index").select("cdpar", { count: "exact", head: true }).eq("b2b_visible", true),
        sb.from("catalog_search_index").select("cdpar", { count: "exact", head: true }).eq("agent_visible", true),
        sb.from("catalog_search_rebuild_log").select("*").order("started_at", { ascending: false }).limit(5),
      ]);
      return {
        total: total.count ?? 0,
        b2b: b2b.count ?? 0,
        agent: agent.count ?? 0,
        log: (log.data ?? []) as any[],
      };
    },
    refetchInterval: 30000,
  });
}

export function useRebuildIndex() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const { error } = await sb.rpc("rebuild_catalog_search_index");
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["catalog-search-status"] });
      toast.success("Indice ricostruito");
    },
    onError: (e: any) => toast.error(e.message ?? "Errore ricostruzione"),
  });
}

/* ---------------- test bench ---------------- */

export function useCatalogSearchTest(query: string, channel: string, debug = true, enabled = true) {
  return useQuery({
    queryKey: ["catalog-search-test", query, channel, debug],
    enabled: enabled && query.trim().length > 0,
    queryFn: async () => {
      const t0 = performance.now();
      const { data, error } = await sb.rpc("catalog_search_v2", {
        p_query: query,
        p_limit: 50,
        p_offset: 0,
        p_channel: channel,
        p_debug: debug,
      });
      if (error) throw error;
      return { hits: (data ?? []) as CatalogSearchHit[], ms: Math.round(performance.now() - t0) };
    },
  });
}

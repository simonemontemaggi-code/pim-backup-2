import { useState } from "react";
import { Sparkles, Check, X, Loader2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAiGenerate, type AiField, type AiGenerateAllResult } from "@/hooks/useAiGenerate";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type SetField = (
  field: "b2b_product_title" | "b2b_product_description" | "description_ecommerce" | "seo_title" | "seo_description" | "tags",
  value: string | string[],
) => void;

interface Props {
  cdpar: string;
  canWrite: boolean;
  setField: SetField;
  /** Tag correnti (per merge) */
  currentTags: string[];
  /** Centralized AI-tags applier from parent form (ensures UI re-render) */
  applyAiTags?: (incoming: string[] | unknown) => void;
}

const FIELD_TO_FORM: Record<Exclude<AiField, "all">, "b2b_product_title" | "b2b_product_description" | "description_ecommerce" | "seo_title" | "seo_description" | "tags"> = {
  title: "b2b_product_title",
  description: "b2b_product_description",
  short_description: "description_ecommerce",
  seo_title: "seo_title",
  seo_description: "seo_description",
  tags: "tags",
};

const FIELD_LABELS: Record<Exclude<AiField, "all">, string> = {
  title: "Titolo Prodotto",
  description: "Descrizione Prodotto",
  short_description: "Descrizione Breve",
  seo_title: "SEO Title",
  seo_description: "SEO Description",
  tags: "Tag",
};

function normalizeTags(value: unknown): string[] {
  if (Array.isArray(value)) {
    return Array.from(new Set(value.map((t) => String(t).toLowerCase().trim()).filter(Boolean)));
  }
  if (value && typeof value === "object" && Array.isArray((value as { tags?: unknown }).tags)) {
    return normalizeTags((value as { tags: unknown[] }).tags);
  }
  if (typeof value === "string" && value.trim()) {
    try {
      return normalizeTags(JSON.parse(value));
    } catch { /* ignore invalid JSON */ }
  }
  return [];
}

export function AiMarketingPanel({ cdpar, canWrite, setField, currentTags, applyAiTags }: Props) {
  const { generate, loading, result, reset } = useAiGenerate();
  const [appliedFields, setAppliedFields] = useState<string[]>([]);

  if (!canWrite) return null;

  const isLoadingAll = loading === "all";
  const isLoadingAny = loading !== null;

  const handleGenerateAll = async () => {
    setAppliedFields([]);
    await generate(cdpar, "all");
  };

  const applyOne = (key: Exclude<AiField, "all">, value: string | string[]) => {
    const formField = FIELD_TO_FORM[key];
    setField(formField, value);
    setAppliedFields((prev) => Array.from(new Set([...prev, key])));
    toast.success(`${FIELD_LABELS[key]} applicato`);
    void logApplied(key);
  };

  const applyAll = () => {
    if (!result?.output_parsed || Array.isArray(result.output_parsed)) return;
    const parsed = result.output_parsed as AiGenerateAllResult;
    const applied: string[] = [];
    if (parsed.title) { setField("b2b_product_title", parsed.title.slice(0, 150)); applied.push("title"); }
    if (parsed.description) { setField("b2b_product_description", parsed.description.slice(0, 2000)); applied.push("description"); }
    if (parsed.short_description) { setField("description_ecommerce", parsed.short_description.slice(0, 230)); applied.push("short_description"); }
    if (parsed.seo_title) { setField("seo_title", parsed.seo_title.slice(0, 60)); applied.push("seo_title"); }
    if (parsed.seo_description) { setField("seo_description", parsed.seo_description.slice(0, 160)); applied.push("seo_description"); }
    const parsedTags = normalizeTags(parsed.tags);
    if (parsedTags.length > 0) {
      if (applyAiTags) {
        applyAiTags(parsedTags);
      } else {
        const merged = Array.from(new Set([...currentTags, ...parsedTags]));
        setField("tags", merged);
      }
      applied.push("tags");
    }
    setAppliedFields(applied);
    toast.success(`Applicati ${applied.length} campi. Ricordati di salvare.`);
    void logApplied(...applied);
  };

  const logApplied = async (...fields: string[]) => {
    if (!result?.generation_id) return;
    try {
      await supabase
        .from("ai_generations")
        .update({ applied_fields: Array.from(new Set([...appliedFields, ...fields])) })
        .eq("id", result.generation_id);
    } catch { /* ignore */ }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 flex-wrap">
        <Button
          type="button"
          onClick={handleGenerateAll}
          disabled={isLoadingAny || !cdpar}
          size="sm"
          className="gap-2 bg-gradient-to-r from-primary to-blue-500 hover:opacity-90"
        >
          {isLoadingAll ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
          {isLoadingAll ? "Generazione in corso..." : "Genera tutto con AI"}
        </Button>
        {result && (
          <Button type="button" variant="ghost" size="sm" onClick={reset} className="gap-1.5">
            <X className="h-3.5 w-3.5" /> Chiudi anteprima
          </Button>
        )}
      </div>

      {result && result.field === "all" && result.output_parsed && !Array.isArray(result.output_parsed) && (
        <Card className="border-primary/30 bg-primary/5 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold">Anteprima generazione AI</span>
              <Badge variant="outline" className="text-[10px]">{result.model}</Badge>
              {result.tokens.total && (
                <Badge variant="outline" className="text-[10px]">{result.tokens.total} tok • {result.duration_ms}ms</Badge>
              )}
            </div>
            <Button type="button" size="sm" onClick={applyAll} className="gap-1.5">
              <Check className="h-3.5 w-3.5" /> Applica tutto
            </Button>
          </div>

          <ScrollArea className="max-h-[400px] pr-3">
            <PreviewItem
              label="Titolo Prodotto"
              value={(result.output_parsed as AiGenerateAllResult).title}
              applied={appliedFields.includes("title")}
              onApply={(v) => applyOne("title", v)}
            />
            <PreviewItem
              label="Descrizione Prodotto"
              value={(result.output_parsed as AiGenerateAllResult).description}
              applied={appliedFields.includes("description")}
              onApply={(v) => applyOne("description", v)}
              isHtml
            />
            <PreviewItem
              label="Descrizione Breve E-commerce"
              value={(result.output_parsed as AiGenerateAllResult).short_description}
              applied={appliedFields.includes("short_description")}
              onApply={(v) => applyOne("short_description", v)}
            />
            <PreviewItem
              label="SEO Title"
              value={(result.output_parsed as AiGenerateAllResult).seo_title}
              applied={appliedFields.includes("seo_title")}
              onApply={(v) => applyOne("seo_title", v)}
            />
            <PreviewItem
              label="SEO Description"
              value={(result.output_parsed as AiGenerateAllResult).seo_description}
              applied={appliedFields.includes("seo_description")}
              onApply={(v) => applyOne("seo_description", v)}
            />
            <PreviewTags
              tags={(result.output_parsed as AiGenerateAllResult).tags ?? []}
              currentTags={currentTags}
              applied={appliedFields.includes("tags")}
              onApply={(merged) => {
                if (applyAiTags) {
                  applyAiTags(merged);
                } else {
                  setField("tags", merged);
                }
                setAppliedFields((p) => Array.from(new Set([...p, "tags"])));
                toast.success("Tag applicati");
                void logApplied("tags");
              }}
            />
          </ScrollArea>
        </Card>
      )}

      {result && result.field !== "all" && (
        <Card className="border-primary/30 bg-primary/5 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold">Anteprima: {FIELD_LABELS[result.field as Exclude<AiField, "all">]}</span>
              <Badge variant="outline" className="text-[10px]">{result.model}</Badge>
            </div>
          </div>
          {result.field === "tags" ? (
            <PreviewTags
              tags={normalizeTags(result.output_parsed).length ? normalizeTags(result.output_parsed) : normalizeTags(result.output_text)}
              currentTags={currentTags}
              applied={appliedFields.includes("tags")}
              onApply={(merged) => {
                if (applyAiTags) {
                  applyAiTags(merged);
                } else {
                  setField("tags", merged);
                }
                setAppliedFields((p) => Array.from(new Set([...p, "tags"])));
                toast.success("Tag applicati");
                void logApplied("tags");
              }}
            />
          ) : (
            <PreviewItem
              label={FIELD_LABELS[result.field as Exclude<AiField, "all">]}
              value={result.output_text}
              applied={appliedFields.includes(result.field)}
              onApply={(v) => applyOne(result.field as Exclude<AiField, "all">, v)}
              isHtml={result.field === "description"}
            />
          )}
        </Card>
      )}
    </div>
  );
}

function PreviewItem({
  label, value, applied, onApply, isHtml,
}: { label: string; value?: string; applied: boolean; onApply: (v: string) => void; isHtml?: boolean }) {
  if (!value) return null;
  return (
    <div className="border-b last:border-b-0 py-2">
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs font-semibold text-muted-foreground uppercase">{label}</span>
        <Button
          type="button"
          size="sm"
          variant={applied ? "secondary" : "outline"}
          className="h-6 text-[11px] gap-1"
          onClick={() => onApply(value)}
        >
          {applied ? <><Check className="h-3 w-3" /> Applicato</> : <>Applica</>}
        </Button>
      </div>
      {isHtml ? (
        <div className="text-xs prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: value }} />
      ) : (
        <p className="text-xs whitespace-pre-wrap">{value}</p>
      )}
    </div>
  );
}

function PreviewTags({
  tags, currentTags, applied, onApply,
}: { tags: string[]; currentTags: string[]; applied: boolean; onApply: (merged: string[]) => void }) {
  if (!tags || tags.length === 0) return null;
  const merged = Array.from(new Set([...currentTags, ...tags.map((t) => String(t).toLowerCase().trim()).filter(Boolean)]));
  return (
    <div className="border-b last:border-b-0 py-2">
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs font-semibold text-muted-foreground uppercase">Tag</span>
        <Button type="button" size="sm" variant={applied ? "secondary" : "outline"} className="h-6 text-[11px] gap-1" onClick={() => onApply(merged)}>
          {applied ? <><Check className="h-3 w-3" /> Applicato</> : <>Applica (+{merged.length - currentTags.length})</>}
        </Button>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {tags.map((t) => (
          <Badge key={t} variant="secondary" className="text-[11px]">{t}</Badge>
        ))}
      </div>
    </div>
  );
}

/* ───────────── Iconcina inline per singolo campo ───────────── */
export function AiFieldButton({
  cdpar, field, canWrite, onApply, disabled,
}: {
  cdpar: string;
  field: Exclude<AiField, "all">;
  canWrite: boolean;
  onApply: (value: string | string[]) => void;
  disabled?: boolean;
}) {
  const { generate, loading } = useAiGenerate();
  if (!canWrite) return null;
  const isLoading = loading === field;

  const handleClick = async () => {
    const r = await generate(cdpar, field);
    if (!r) return;
    if (field === "tags") {
      const tags = normalizeTags(r.output_parsed).length ? normalizeTags(r.output_parsed) : normalizeTags(r.output_text);
      if (tags.length === 0) {
        toast.warning("AI non ha generato tag validi. Riprova o usa Genera tutto.");
        return;
      }
      onApply(tags);
      toast.success(`${tags.length} tag generati e applicati. Ricordati di salvare.`);
    } else {
      onApply((r.output_text || "").trim());
      toast.success(`${FIELD_LABELS[field]} generato e applicato`);
    }
  };

  return (
    <Button
      type="button"
      size="icon"
      variant="ghost"
      className="h-6 w-6 shrink-0 text-primary hover:text-primary hover:bg-primary/10"
      onClick={handleClick}
      disabled={disabled || isLoading || !cdpar}
      title={`Genera ${FIELD_LABELS[field]} con AI`}
    >
      {isLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
    </Button>
  );
}

export { RefreshCw };

import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CheckCircle2, AlertCircle, XCircle, ChevronsUpDown } from "lucide-react";
import { useLookupValues } from "@/hooks/useLookupValues";
import { resolveGammaPaths, type ResolvedPath } from "@/lib/gammaPathResolver";

export interface PathMappingResult {
  pathToGamma: Map<string, string | null>;
}

interface Props {
  csvData: Record<string, string>[];
  pathColumn: string;
  onBack: () => void;
  onNext: (result: PathMappingResult) => void;
}

export function StepGammaPathMapping({ csvData, pathColumn, onBack, onNext }: Props) {
  const [resolved, setResolved] = useState<Map<string, ResolvedPath> | null>(null);
  const [overrides, setOverrides] = useState<Map<string, string>>(new Map());
  const { data: gammaValues = [] } = useLookupValues("gamma");
  const { data: repartoValues = [] } = useLookupValues("reparto");
  const { data: clmerValues = [] } = useLookupValues("clmer");

  const uniquePaths = useMemo(() => {
    const set = new Set<string>();
    csvData.forEach((row) => {
      const p = (row[pathColumn] ?? "").trim();
      if (p) set.add(p);
    });
    return Array.from(set).sort();
  }, [csvData, pathColumn]);

  useEffect(() => {
    let cancelled = false;
    resolveGammaPaths(uniquePaths).then((res) => {
      if (!cancelled) setResolved(res);
    });
    return () => { cancelled = true; };
  }, [uniquePaths]);

  const gammaLabel = (code: string): string => {
    const g = gammaValues.find((v) => v.code === code);
    if (!g) return code;
    const r = repartoValues.find((v) => v.code === g.parent_code);
    const s = r ? clmerValues.find((v) => v.code === r.parent_code) : null;
    const parts = [s?.label || s?.code, r?.label || r?.code, g.label || g.code].filter(Boolean);
    return parts.join(" › ");
  };

  const counts = useMemo(() => {
    if (!resolved) return { matched: 0, partial: 0, unmatched: 0, total: 0 };
    let matched = 0, partial = 0, unmatched = 0;
    resolved.forEach((r) => {
      const ovr = overrides.get(r.rawPath);
      const finalCode = ovr !== undefined ? ovr : r.gammaCode;
      if (finalCode) matched++;
      else if (r.status === "partial") partial++;
      else unmatched++;
    });
    return { matched, partial, unmatched, total: resolved.size };
  }, [resolved, overrides]);

  const handleConfirm = () => {
    if (!resolved) return;
    const map = new Map<string, string | null>();
    resolved.forEach((r) => {
      const ovr = overrides.get(r.rawPath);
      map.set(r.rawPath, ovr !== undefined ? (ovr || null) : r.gammaCode);
    });
    onNext({ pathToGamma: map });
  };

  if (!resolved) {
    return <div className="p-8 text-center text-sm text-muted-foreground">Risoluzione path in corso…</div>;
  }

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-medium mb-2">Mappatura Gamme</h3>
        <p className="text-xs text-muted-foreground mb-3">
          Per ogni path "Settore\Reparto\Gamma" trovato nel CSV, verifica la corrispondenza con le gamme del PIM.
          I path non riconosciuti possono essere mappati manualmente o saltati.
        </p>
        <div className="flex gap-2 flex-wrap">
          <Badge className="bg-green-600">{counts.matched} riconosciuti</Badge>
          <Badge className="bg-amber-500 text-black">{counts.partial} parziali</Badge>
          <Badge variant="destructive">{counts.unmatched} non trovati</Badge>
          <Badge variant="outline">{counts.total} totali</Badge>
        </div>
      </div>

      <ScrollArea className="border rounded-md h-[480px]">
        <div className="divide-y">
          {Array.from(resolved.values()).map((r) => {
            const ovr = overrides.get(r.rawPath);
            const finalCode = ovr !== undefined ? ovr : r.gammaCode;
            const icon = finalCode
              ? <CheckCircle2 className="h-4 w-4 text-green-600" />
              : r.status === "partial"
                ? <AlertCircle className="h-4 w-4 text-amber-500" />
                : <XCircle className="h-4 w-4 text-destructive" />;
            return (
              <div key={r.rawPath} className="p-2.5 flex items-start gap-3">
                <div className="mt-1">{icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-mono break-all">{r.rawPath}</div>
                  {finalCode ? (
                    <div className="text-[11px] text-green-700 mt-0.5">→ {gammaLabel(finalCode)} <span className="font-mono text-muted-foreground">({finalCode})</span></div>
                  ) : (
                    <div className="text-[11px] text-muted-foreground mt-0.5">
                      {r.status === "partial"
                        ? `Match parziale: settore=${r.settoreCode ?? "—"}, reparto=${r.repartoCode ?? "—"}, gamma=—`
                        : "Nessuna corrispondenza trovata"}
                    </div>
                  )}
                </div>
                <div className="w-64 shrink-0">
                  <GammaCombobox
                    value={ovr === undefined ? "__auto__" : (ovr === "" ? "__skip__" : ovr)}
                    autoCode={r.gammaCode}
                    options={gammaValues.map((g) => ({ code: g.code, label: gammaLabel(g.code) }))}
                    onChange={(v) => {
                      const next = new Map(overrides);
                      if (v === "__auto__") next.delete(r.rawPath);
                      else if (v === "__skip__") next.set(r.rawPath, "");
                      else next.set(r.rawPath, v);
                      setOverrides(next);
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>

      <div className="flex justify-between items-center">
        <Button variant="outline" onClick={onBack}>← Indietro</Button>
        <div className="flex items-center gap-3">
          {counts.unmatched > 0 && (
            <span className="text-xs text-muted-foreground">
              {counts.unmatched} path saranno saltati
            </span>
          )}
          <Button onClick={handleConfirm}>
            Avanti → ({counts.matched} gamme)
          </Button>
        </div>
      </div>
    </div>
  );
}

interface GammaComboboxProps {
  value: string;
  autoCode: string | null;
  options: { code: string; label: string }[];
  onChange: (val: string) => void;
}

function GammaCombobox({ value, autoCode, options, onChange }: GammaComboboxProps) {
  const [open, setOpen] = useState(false);
  const selected = options.find((o) => o.code === value);
  const display =
    value === "__auto__"
      ? `— Automatico (${autoCode || "nessuno"}) —`
      : value === "__skip__"
        ? "⊘ Salta questo path"
        : selected?.label || "Seleziona gamma…";
  const isSkip = value === "__skip__";
  const isAuto = value === "__auto__";

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          className={`h-8 w-full justify-between text-xs font-normal ${isSkip ? "text-destructive" : isAuto ? "text-muted-foreground" : ""}`}
        >
          <span className="truncate">{display}</span>
          <ChevronsUpDown className="ml-2 h-3 w-3 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[420px] p-0" align="end">
        <Command>
          <CommandInput placeholder="Cerca gamma…" className="h-9" />
          <CommandList>
            <CommandEmpty>Nessun risultato.</CommandEmpty>
            <CommandGroup>
              <CommandItem value="__auto__ automatico" onSelect={() => { onChange("__auto__"); setOpen(false); }}>
                <span className="text-muted-foreground text-xs">— Automatico ({autoCode || "nessuno"}) —</span>
              </CommandItem>
              <CommandItem value="__skip__ salta" onSelect={() => { onChange("__skip__"); setOpen(false); }}>
                <span className="text-destructive text-xs">⊘ Salta questo path</span>
              </CommandItem>
            </CommandGroup>
            <CommandGroup heading="Gamme">
              {options.map((o) => (
                <CommandItem
                  key={o.code}
                  value={`${o.label} ${o.code}`}
                  onSelect={() => { onChange(o.code); setOpen(false); }}
                >
                  <span className="text-xs">{o.label}</span>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

import { useCallback, useEffect, useMemo, useState } from "react";
import { CheckCircle, AlertTriangle, XCircle, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";

interface BrandRow {
  clas2: string;
  nome_as400_brand: string | null;
  display_name: string | null;
  logo_url: string | null;
}

interface BulkLogoFile {
  file: File;
  detectedClas2: string | null;
  manualClas2: string | null;
  matchedOn: string | null; // debug: chiave normalizzata che ha matchato
}

const SUPPORTED_EXT = new Set(["jpg", "jpeg", "png", "webp", "svg"]);

// Normalizza: lowercase, rimuove tutto tranne lettere/numeri (no spazi, no -, _, ., punteggiatura, accenti basici)
function normalize(s: string | null | undefined): string {
  if (!s) return "";
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // accenti
    .replace(/[^a-z0-9]/g, "");
}

function getExt(name: string): string {
  const i = name.lastIndexOf(".");
  return i >= 0 ? name.slice(i + 1).toLowerCase() : "";
}

function stripExt(name: string): string {
  const i = name.lastIndexOf(".");
  return i >= 0 ? name.slice(0, i) : name;
}

function getKey(bf: BulkLogoFile) {
  return `${bf.file.name}::${bf.file.size}::${bf.file.lastModified}`;
}

export function BulkBrandLogos() {
  const [brands, setBrands] = useState<BrandRow[]>([]);
  const [loadingBrands, setLoadingBrands] = useState(true);
  const [files, setFiles] = useState<BulkLogoFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadedCount, setUploadedCount] = useState(0);
  const [editingIdx, setEditingIdx] = useState<number | null>(null);

  useEffect(() => {
    (async () => {
      setLoadingBrands(true);
      const { data, error } = await supabase
        .from("archivio_brand_fraschetti")
        .select("clas2, nome_as400_brand, display_name, logo_url")
        .order("nome_as400_brand", { ascending: true })
        .limit(2000);
      if (!error && data) setBrands(data as BrandRow[]);
      setLoadingBrands(false);
    })();
  }, []);

  // Lookup map: normalized key -> clas2
  const lookup = useMemo(() => {
    const m = new Map<string, string>();
    brands.forEach((b) => {
      const keys = [b.clas2, b.nome_as400_brand, b.display_name];
      keys.forEach((k) => {
        const n = normalize(k);
        if (n && !m.has(n)) m.set(n, b.clas2);
      });
    });
    return m;
  }, [brands]);

  const brandsByCode = useMemo(() => {
    const m = new Map<string, BrandRow>();
    brands.forEach((b) => m.set(b.clas2, b));
    return m;
  }, [brands]);

  const detect = useCallback(
    (filename: string): { clas2: string | null; matchedOn: string | null } => {
      const base = stripExt(filename);
      const norm = normalize(base);
      if (!norm) return { clas2: null, matchedOn: null };
      // Exact match
      if (lookup.has(norm)) return { clas2: lookup.get(norm)!, matchedOn: norm };
      // Tenta match prefisso/contenuto con la chiave più lunga che sta nel filename
      let best: { clas2: string; key: string } | null = null;
      for (const [k, code] of lookup.entries()) {
        if (k.length < 3) continue; // evita match cortissimi tipo "3m"? lo manteniamo a 3
        if (norm.includes(k)) {
          if (!best || k.length > best.key.length) best = { clas2: code, key: k };
        }
      }
      return best ? { clas2: best.clas2, matchedOn: best.key } : { clas2: null, matchedOn: null };
    },
    [lookup]
  );

  const handleFiles = useCallback(
    (fileList: File[]) => {
      const valid = fileList.filter((f) => SUPPORTED_EXT.has(getExt(f.name)));
      const skipped = fileList.length - valid.length;
      const next: BulkLogoFile[] = valid.map((file) => {
        const det = detect(file.name);
        return { file, detectedClas2: det.clas2, manualClas2: null, matchedOn: det.matchedOn };
      });
      setFiles(next);
      setUploadedCount(0);
      if (skipped > 0) {
        toast({
          title: "Alcuni file ignorati",
          description: `${skipped} file non supportati (accettati: jpg, png, webp, svg)`,
        });
      }
    },
    [detect]
  );

  const updateManual = (idx: number, clas2: string) => {
    setFiles((prev) => {
      const next = [...prev];
      next[idx] = { ...next[idx], manualClas2: clas2 || null };
      return next;
    });
  };

  const effective = (bf: BulkLogoFile) => bf.manualClas2 || bf.detectedClas2;

  const status = (bf: BulkLogoFile): "green" | "yellow" | "red" => {
    const c = effective(bf);
    if (!c || !brandsByCode.has(c)) return "red";
    const b = brandsByCode.get(c)!;
    return b.logo_url ? "yellow" : "green";
  };

  const counts = useMemo(() => {
    return files.reduce(
      (acc, f) => {
        acc[status(f)]++;
        return acc;
      },
      { green: 0, yellow: 0, red: 0 }
    );
  }, [files, brandsByCode]);

  const uploadable = useMemo(() => files.filter((f) => status(f) !== "red"), [files, brandsByCode]);

  const handleUpload = async () => {
    if (uploadable.length === 0) return;
    setUploading(true);
    setUploadedCount(0);
    const succeeded = new Set<string>();
    const updatedLogos = new Map<string, string>();
    let okCount = 0;
    let errCount = 0;
    const CONCURRENCY = 8;

    const uploadOne = async (bf: BulkLogoFile) => {
      const clas2 = effective(bf)!;
      const ext = getExt(bf.file.name) || "png";
      const path = `brands/${clas2}/logo.${ext}`;
      try {
        const { error: upErr } = await supabase.storage
          .from("pim-media")
          .upload(path, bf.file, { upsert: true, contentType: bf.file.type || undefined });
        if (upErr) throw upErr;

        const { data: pub } = supabase.storage.from("pim-media").getPublicUrl(path);
        const publicUrl = pub.publicUrl;

        const { error: dbErr } = await supabase
          .from("archivio_brand_fraschetti")
          .update({ logo_url: publicUrl })
          .eq("clas2", clas2);
        if (dbErr) throw dbErr;

        succeeded.add(getKey(bf));
        updatedLogos.set(clas2, publicUrl);
        okCount++;
      } catch (e: any) {
        console.error(`[BulkBrandLogos] errore ${bf.file.name}:`, e);
        errCount++;
      }
      setUploadedCount((c) => c + 1);
    };

    // Esegui in parallelo a batch di CONCURRENCY
    for (let i = 0; i < uploadable.length; i += CONCURRENCY) {
      const batch = uploadable.slice(i, i + CONCURRENCY);
      await Promise.all(batch.map(uploadOne));
    }

    // Aggiorna stato locale una volta sola alla fine (no re-render per upload)
    if (updatedLogos.size > 0) {
      setBrands((prev) =>
        prev.map((b) => (updatedLogos.has(b.clas2) ? { ...b, logo_url: updatedLogos.get(b.clas2)! } : b))
      );
    }
    setFiles((prev) => prev.filter((f) => !succeeded.has(getKey(f))));
    setUploading(false);
    toast({
      title: "Caricamento completato",
      description: `${okCount} loghi caricati${errCount ? `, ${errCount} errori` : ""}`,
    });
  };

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-base font-semibold">Caricamento massivo loghi Brand</h3>
        <p className="text-sm text-muted-foreground">
          Trascina i file. Il nome del file viene confrontato con codice brand (clas2),
          nome AS400 e display name in modo case-insensitive, ignorando spazi, trattini e
          punteggiatura. I file riconosciuti vengono caricati in <code>brands/&#123;clas2&#125;/logo.&#123;ext&#125;</code>
          e <code>logo_url</code> viene aggiornato in automatico.
        </p>
      </div>

      <FileDropZone
        accept="image/jpeg,image/png,image/webp,image/svg+xml"
        onFiles={handleFiles}
        label="Trascina o seleziona loghi (JPG, PNG, WebP, SVG)"
        className="p-8"
      />

      {loadingBrands && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Carico elenco brand...
        </div>
      )}

      {files.length > 0 && (
        <div className="space-y-3">
          <div className="flex flex-wrap gap-4 text-sm">
            <span className="flex items-center gap-1">
              <CheckCircle className="h-4 w-4 text-green-500" /> {counts.green} nuovi
            </span>
            <span className="flex items-center gap-1">
              <AlertTriangle className="h-4 w-4 text-yellow-500" /> {counts.yellow} sovrascriveranno
            </span>
            <span className="flex items-center gap-1">
              <XCircle className="h-4 w-4 text-red-500" /> {counts.red} non abbinati
            </span>
          </div>

          <div className="border rounded-md max-h-[480px] overflow-y-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted sticky top-0">
                <tr className="text-left">
                  <th className="p-2 w-10"></th>
                  <th className="p-2">File</th>
                  <th className="p-2">Brand abbinato</th>
                  <th className="p-2">Override</th>
                </tr>
              </thead>
              <tbody>
                {files.map((bf, idx) => {
                  const st = status(bf);
                  const eff = effective(bf);
                  const brand = eff ? brandsByCode.get(eff) : null;
                  return (
                    <tr key={getKey(bf)} className="border-t">
                      <td className="p-2 align-top">
                        {st === "green" && <CheckCircle className="h-4 w-4 text-green-500" />}
                        {st === "yellow" && <AlertTriangle className="h-4 w-4 text-yellow-500" />}
                        {st === "red" && <XCircle className="h-4 w-4 text-red-500" />}
                      </td>
                      <td className="p-2 align-top">
                        <div className="font-mono text-xs">{bf.file.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {(bf.file.size / 1024).toFixed(1)} KB
                        </div>
                      </td>
                      <td className="p-2 align-top">
                        {brand ? (
                          <div>
                            <div className="font-medium">
                              {brand.display_name || brand.nome_as400_brand || "(senza nome)"}
                            </div>
                            <div className="text-xs text-muted-foreground font-mono">
                              {brand.clas2}
                              {bf.matchedOn && !bf.manualClas2 && (
                                <> · match: <span className="italic">{bf.matchedOn}</span></>
                              )}
                            </div>
                          </div>
                        ) : (
                          <span className="text-xs text-muted-foreground">Nessun match</span>
                        )}
                      </td>
                      <td className="p-2 align-top w-64">
                        {editingIdx === idx ? (
                          <Select
                            value={bf.manualClas2 ?? ""}
                            onValueChange={(v) => { updateManual(idx, v); setEditingIdx(null); }}
                            open
                            onOpenChange={(o) => { if (!o) setEditingIdx(null); }}
                          >
                            <SelectTrigger className="h-8">
                              <SelectValue placeholder="Scegli brand..." />
                            </SelectTrigger>
                            <SelectContent>
                              {brands.map((b) => (
                                <SelectItem key={b.clas2} value={b.clas2}>
                                  {b.clas2} — {b.display_name || b.nome_as400_brand || "(senza nome)"}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        ) : (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 text-xs"
                            onClick={() => setEditingIdx(idx)}
                          >
                            {bf.manualClas2 ? "Cambia" : "Modifica"}
                          </Button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="flex items-center gap-3">
            <Button onClick={handleUpload} disabled={uploading || uploadable.length === 0}>
              {uploading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Caricamento {uploadedCount}/{uploadable.length}...
                </>
              ) : (
                <>Carica {uploadable.length} loghi</>
              )}
            </Button>
            <Button variant="ghost" onClick={() => setFiles([])} disabled={uploading}>
              Svuota
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

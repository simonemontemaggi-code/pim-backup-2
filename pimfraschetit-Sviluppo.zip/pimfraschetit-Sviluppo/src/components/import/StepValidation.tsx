import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";
import type { RowValidation } from "@/lib/csvValidation";

interface Props {
  rows: Record<string, string>[];
  validations: RowValidation[];
  headers: string[];
  onBack: () => void;
  onImport: (mode: "valid" | "valid_warning") => void;
}

export function StepValidation({ rows, validations, headers, onBack, onImport }: Props) {
  const [mode, setMode] = useState<"valid" | "valid_warning">("valid_warning");
  const [filter, setFilter] = useState<"all" | "valid" | "warning" | "error">("all");

  const counts = useMemo(() => {
    let valid = 0, warning = 0, error = 0;
    validations.forEach((v) => {
      if (v.status === "valid") valid++;
      else if (v.status === "warning") warning++;
      else error++;
    });
    return { valid, warning, error };
  }, [validations]);

  const importable = mode === "valid" ? counts.valid : counts.valid + counts.warning;

  const visibleIndexes = useMemo(
    () => rows.map((_, i) => i).filter((i) => filter === "all" || validations[i]?.status === filter),
    [rows, validations, filter]
  );

  const toggle = (s: "valid" | "warning" | "error") => setFilter((f) => (f === s ? "all" : s));

  return (
    <div className="space-y-4">
      <div className="flex gap-2 items-center text-sm">
        <button type="button" onClick={() => toggle("valid")} className={`transition ${filter !== "all" && filter !== "valid" ? "opacity-40" : ""}`}>
          <Badge variant="default" className="bg-green-600 cursor-pointer hover:opacity-90">{counts.valid} pronte ✅</Badge>
        </button>
        <button type="button" onClick={() => toggle("warning")} className={`transition ${filter !== "all" && filter !== "warning" ? "opacity-40" : ""}`}>
          <Badge variant="secondary" className="bg-yellow-500 text-black cursor-pointer hover:opacity-90">{counts.warning} warning ⚠️</Badge>
        </button>
        <button type="button" onClick={() => toggle("error")} className={`transition ${filter !== "all" && filter !== "error" ? "opacity-40" : ""}`}>
          <Badge variant="destructive" className="cursor-pointer hover:opacity-90">{counts.error} errori ❌</Badge>
        </button>
        {filter !== "all" && (
          <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => setFilter("all")}>
            Mostra tutte
          </Button>
        )}
      </div>

      <div className="border rounded-md overflow-auto" style={{ maxHeight: "400px" }}>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-16 text-xs">Stato</TableHead>
              <TableHead className="w-10 text-xs">#</TableHead>
              {headers.map((h) => (
                <TableHead key={h} className="text-xs whitespace-nowrap">{h}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {visibleIndexes.length === 0 ? (
              <TableRow>
                <TableCell colSpan={headers.length + 2} className="text-center py-6 text-muted-foreground text-xs">
                  Nessuna riga per questo filtro
                </TableCell>
              </TableRow>
            ) : visibleIndexes.map((i) => {
              const row = rows[i];
              const v = validations[i];
              const issueMap = new Map(v.issues.map((iss) => [iss.field, iss]));
              return (
                <TableRow key={i} className={v.status === "error" ? "bg-destructive/5" : v.status === "warning" ? "bg-yellow-50" : ""}>
                  <TableCell className="text-center">
                    {v.status === "valid" ? (
                      <span>🟢</span>
                    ) : (
                      <TooltipProvider delayDuration={100}>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span className="cursor-help inline-flex items-center justify-center">
                              {v.status === "warning" ? "🟡" : "🔴"}
                            </span>
                          </TooltipTrigger>
                          <TooltipContent side="right" className="max-w-sm space-y-1">
                            {[...v.issues].sort((a, b) => (a.level === "error" ? -1 : 1) - (b.level === "error" ? -1 : 1)).map((iss, idx) => (
                              <div key={idx} className="text-xs">
                                {iss.level === "error" ? "❌" : "⚠️"} <span className="font-medium">{iss.field}</span>: {iss.message}
                              </div>
                            ))}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    )}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">{i + 1}</TableCell>
                  {headers.map((h) => {
                    const issue = issueMap.get(h);
                    return (
                      <TableCell key={h} className={`text-xs whitespace-nowrap ${issue ? (issue.level === "error" ? "text-destructive font-medium" : "text-yellow-700") : ""}`}>
                        {issue ? (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span className="underline decoration-dotted cursor-help">{row[h] || "—"}</span>
                            </TooltipTrigger>
                            <TooltipContent>{issue.message}</TooltipContent>
                          </Tooltip>
                        ) : (
                          <span className="max-w-[150px] truncate block">{row[h] || ""}</span>
                        )}
                      </TableCell>
                    );
                  })}
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      <RadioGroup value={mode} onValueChange={(v) => setMode(v as any)} className="flex gap-4">
        <Label className="flex items-center gap-2 cursor-pointer">
          <RadioGroupItem value="valid_warning" />
          Importa valide + warning ✅⚠️
        </Label>
        <Label className="flex items-center gap-2 cursor-pointer">
          <RadioGroupItem value="valid" />
          Solo righe valide ✅
        </Label>
      </RadioGroup>

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack}>← Indietro</Button>
        <Button disabled={importable === 0} onClick={() => onImport(mode)}>
          Avvia Import ({importable} righe) →
        </Button>
      </div>
    </div>
  );
}

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { supabase } from "@/integrations/supabase/client";
import { parseInventoryTxt, formatQty, type InventoryRow } from "@/lib/inventoryImport";
import { toast } from "@/hooks/use-toast";
import { Package, Upload, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";

interface ImportResult {
  total: number;
  matched: number;
  zeroed: number;
}

export function InventoryImportPanel() {
  const [file, setFile] = useState<File | null>(null);
  const [rows, setRows] = useState<InventoryRow[]>([]);
  const [running, setRunning] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFiles = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    setFile(f);
    setResult(null);
    setError(null);
    const text = await f.text();
    const parsed = parseInventoryTxt(text);
    setRows(parsed);
    if (parsed.length === 0) {
      toast({
        title: "Nessuna riga valida",
        description: "Il file non contiene righe interpretabili.",
        variant: "destructive",
      });
    }
  };

  const runImport = async () => {
    if (rows.length === 0 || !file) return;
    setRunning(true);
    setElapsed(0);
    setError(null);
    setResult(null);

    // Timer per il tempo trascorso (la RPC è bulk, non c'è progress reale)
    const startedAt = Date.now();
    const timer = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startedAt) / 1000));
    }, 500);

    try {
      const { data, error: rpcErr } = await supabase.rpc(
        "import_inventory_snapshot" as any,
        {
          rows: rows as any,
          p_filename: file.name,
          p_zero_fill: true,
        }
      );
      if (rpcErr) throw rpcErr;
      setResult(data as ImportResult);
      toast({
        title: "Import giacenze completato",
        description: `${rows.length} righe processate in ${Math.floor(
          (Date.now() - startedAt) / 1000
        )}s.`,
      });
    } catch (e: any) {
      console.error("[InventoryImport] error:", e);
      setError(e.message ?? "Errore sconosciuto");
      toast({
        title: "Errore import",
        description: e.message ?? "Errore sconosciuto",
        variant: "destructive",
      });
    } finally {
      clearInterval(timer);
      setRunning(false);
    }
  };

  const reset = () => {
    setFile(null);
    setRows([]);
    setResult(null);
    setError(null);
    setElapsed(0);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Package className="h-6 w-6" />
        <div>
          <h1 className="text-2xl font-bold">Giacenze</h1>
          <p className="text-sm text-muted-foreground">
            Importa file TXT con giacenze articoli (formato: 6 cifre cdpar + quantità).
          </p>
        </div>
      </div>

      {!file && (
        <FileDropZone
          accept=".txt,text/plain"
          multiple={false}
          label="Trascina qui un file .txt o clicca per selezionarlo"
          onFiles={handleFiles}
          className="py-12"
        />
      )}

      {file && (
        <div className="rounded-lg border bg-card p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Upload className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium">{file.name}</span>
              <Badge variant="outline">{rows.length} righe valide</Badge>
            </div>
            <Button variant="ghost" size="sm" onClick={reset} disabled={running}>
              Cambia file
            </Button>
          </div>

          {rows.length > 0 && (
            <div className="rounded border bg-muted/30 p-3 text-xs font-mono max-h-48 overflow-auto">
              <div className="font-semibold mb-1 text-muted-foreground">
                Anteprima (prime 20 righe):
              </div>
              <table className="w-full">
                <thead>
                  <tr className="text-left text-muted-foreground">
                    <th className="pr-4">cdpar</th>
                    <th>quantità</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.slice(0, 20).map((r, i) => (
                    <tr key={i}>
                      <td className="pr-4">{r.cdpar}</td>
                      <td className="tabular-nums">{formatQty(r.quantity)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {running && (
            <div className="space-y-2">
              <Progress value={undefined} />
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Loader2 className="h-3 w-3 animate-spin" />
                Import in corso… {elapsed}s
              </div>
            </div>
          )}

          {error && (
            <div className="flex items-start gap-2 rounded border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
              <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
              <div>{error}</div>
            </div>
          )}

          {result && (
            <div className="rounded border border-green-500/30 bg-green-50 dark:bg-green-950/20 p-4 space-y-2">
              <div className="flex items-center gap-2 text-green-700 dark:text-green-400 font-medium">
                <CheckCircle2 className="h-4 w-4" />
                Import completato
              </div>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Righe nel file</div>
                  <div className="text-xl font-bold tabular-nums">{result.total}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Articoli aggiornati</div>
                  <div className="text-xl font-bold tabular-nums text-green-600">
                    {result.matched}
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground">Articoli azzerati</div>
                  <div className="text-xl font-bold tabular-nums text-amber-600">
                    {result.zeroed}
                  </div>
                </div>
              </div>
            </div>
          )}

          {!result && (
            <Button
              onClick={runImport}
              disabled={running || rows.length === 0}
              className="w-full"
            >
              {running ? "Importazione in corso..." : `Importa ${rows.length} giacenze`}
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

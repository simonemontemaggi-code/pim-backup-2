import { useCallback } from "react";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import Papa from "papaparse";
import { TEMPLATES, type ImportType } from "@/lib/csvTemplates";
import { FileDropZone } from "@/components/ui/FileDropZone";

interface Props {
  file: File | null;
  importType: ImportType | null;
  onFileChange: (f: File) => void;
  onTypeChange: (t: ImportType) => void;
  onNext: () => void;
}

export function StepUpload({ file, importType, onFileChange, onTypeChange, onNext }: Props) {
  const handleFiles = useCallback(
    (files: File[]) => {
      const f = files[0];
      if (f && f.name.endsWith(".csv") && f.size <= 10 * 1024 * 1024) onFileChange(f);
    },
    [onFileChange]
  );

  const downloadTemplate = () => {
    if (!importType) return;
    const tpl = TEMPLATES[importType];
    const csv = Papa.unparse({ fields: tpl.headers, data: tpl.examples.map((ex) => tpl.headers.map((h) => ex[h] ?? "")) });
    // BOM UTF-8: forza Excel (Windows) ad aprire in UTF-8 e a preservarlo al salvataggio.
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `template_${importType}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-medium mb-3">Tipo di import</h3>
        <RadioGroup value={importType ?? ""} onValueChange={(v) => onTypeChange(v as ImportType)} className="grid grid-cols-2 gap-3">
          {(Object.entries(TEMPLATES) as [ImportType, (typeof TEMPLATES)[ImportType]][]).map(([key, tpl]) => (
            <Label key={key} className="flex items-center gap-2 border rounded-md p-3 cursor-pointer has-[:checked]:border-primary has-[:checked]:bg-primary/5">
              <RadioGroupItem value={key} />
              {tpl.label}
            </Label>
          ))}
        </RadioGroup>
      </div>

      {importType && (
        <div className="space-y-2">
          <Button variant="outline" size="sm" onClick={downloadTemplate}>
            <Download className="mr-2 h-4 w-4" /> Scarica template CSV
          </Button>
          <p className="text-xs text-muted-foreground border-l-2 border-amber-500 pl-2">
            ⚠️ Se apri il template in Excel, salvalo come <strong>CSV UTF-8 (delimitato da virgole)</strong>,
            non come CSV standard: altrimenti i caratteri accentati (à, è, ì, ò, ù, °, €) verranno persi
            e l'import verrà bloccato.
          </p>
        </div>
      )}

      <FileDropZone
        accept=".csv"
        multiple={false}
        onFiles={handleFiles}
        label={file
          ? `${file.name} — ${(file.size / 1024).toFixed(1)} KB`
          : "Trascina un file CSV (max 10 MB) o clicca per selezionare"
        }
        className="p-10"
      />

      <div className="flex justify-end">
        <Button disabled={!file || !importType} onClick={onNext}>
          Avanti →
        </Button>
      </div>
    </div>
  );
}

import { useState, useMemo } from "react";
import { useQueryClient } from "@tanstack/react-query";
import * as XLSX from "xlsx";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { usePermissions } from "@/lib/permissions";
import { Package2, Upload, CheckCircle2, AlertCircle, Loader2, Lock, Download, PlayCircle, FlaskConical } from "lucide-react";

interface Row {
  cdpar: string;
  wstato: string;
}

interface Detail {
  cdpar: string;
  esito: "inserted" | "unchanged" | "not_found";
  stato_precedente: string | null;
  stato_nuovo: string;
}

interface RpcResult {
  total: number;
  inserted: number;
  unchanged: number;
  not_found: number;
  dry_run: boolean;
  details: Detail[];
}

const CHUNK_SIZE = 200;

function normalizeCdpar(v: any): string {
  const s = String(v ?? "").trim();
  if (!s) return "";
  // Numeric-only → pad-left to 6
  if (/^\d+$/.test(s)) return s.padStart(6, "0");
  return s;
}

function parseFile(file: File): Promise<{ rows: Row[]; warnings: string[] }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const raw = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: "" });
        const warnings: string[] = [];
        const rows: Row[] = [];
        const seen = new Set<string>();
        let skippedEmpty = 0;
        let skippedDup = 0;
        // Skip header row (row 0)
        for (let i = 1; i < raw.length; i++) {
          const r = raw[i];
          if (!r || r.every((v: any) => v === "" || v == null)) { skippedEmpty++; continue; }
          const cdpar = normalizeCdpar(r[0]);
          const wstato = String(r[1] ?? "").trim().toUpperCase();
          if (!cdpar || !wstato) { skippedEmpty++; continue; }
          if (seen.has(cdpar)) { skippedDup++; continue; }
          seen.add(cdpar);
          rows.push({ cdpar, wstato });
        }
        if (skippedEmpty) warnings.push(`${skippedEmpty} righe vuote o incomplete ignorate`);
        if (skippedDup) warnings.push(`${skippedDup} duplicati (stesso cdpar) ignorati — tenuta la prima occorrenza`);
        resolve({ rows, warnings });
      } catch (err: any) {
        reject(err);
      }
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsArrayBuffer(file);
  });
}

async function runImport(rows: Row[], dryRun: boolean, onProgress: (p: number) => void): Promise<RpcResult> {
  const agg: RpcResult = { total: 0, inserted: 0, unchanged: 0, not_found: 0, dry_run: dryRun, details: [] };
  for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
    const chunk = rows.slice(i, i + CHUNK_SIZE);
    const { data, error } = await supabase.rpc("pim_import_assortimenti" as any, {
      p_rows: chunk as any,
      p_dry_run: dryRun,
    });
    if (error) throw error;
    const r = data as unknown as RpcResult;
    agg.total += r.total;
    agg.inserted += r.inserted;
    agg.unchanged += r.unchanged;
    agg.not_found += r.not_found;
    agg.details.push(...(r.details ?? []));
    onProgress(Math.min(100, Math.round(((i + chunk.length) / rows.length) * 100)));
  }
  return agg;
}

function downloadCsv(details: Detail[]) {
  const header = "cdpar,esito,stato_precedente,stato_nuovo\n";
  const body = details
    .map((d) => [d.cdpar, d.esito, d.stato_precedente ?? "", d.stato_nuovo].join(","))
    .join("\n");
  const blob = new Blob(["\uFEFF" + header + body], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `import_assortimenti_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-")}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export function AssortimentiImportPanel() {
  const queryClient = useQueryClient();
  const { can } = usePermissions();
  const canWrite = can("write", "import_assortimenti");
  const [file, setFile] = useState<File | null>(null);
  const [rows, setRows] = useState<Row[]>([]);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [result, setResult] = useState<RpcResult | null>(null);
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<"idle" | "dry" | "run">("idle");

  const preview = useMemo(() => rows.slice(0, 10), [rows]);

  const handleFile = async (f: File) => {
    setFile(f);
    setResult(null);
    setProgress(0);
    try {
      const { rows: parsed, warnings: w } = await parseFile(f);
      setRows(parsed);
      setWarnings(w);
      if (parsed.length === 0) toast({ title: "File vuoto", description: "Nessuna riga valida trovata.", variant: "destructive" });
    } catch (err: any) {
      toast({ title: "Errore lettura file", description: err.message, variant: "destructive" });
      setRows([]);
      setWarnings([]);
    }
  };

  const doRun = async (dry: boolean) => {
    if (rows.length === 0) return;
    setPhase(dry ? "dry" : "run");
    setProgress(0);
    setResult(null);
    try {
      const res = await runImport(rows, dry, setProgress);
      setResult(res);
      if (!dry) {
        queryClient.invalidateQueries({ queryKey: ["article"] });
        queryClient.invalidateQueries({ queryKey: ["articles"] });
        queryClient.invalidateQueries({ queryKey: ["assortment_status"] });
      }
      toast({
        title: dry ? "Dry-run completato" : "Import completato",
        description: `${res.inserted} inserite · ${res.unchanged} già allineate · ${res.not_found} non trovate`,
      });
    } catch (err: any) {
      toast({ title: "Errore import", description: err.message, variant: "destructive" });
    } finally {
      setPhase("idle");
    }
  };

  if (!canWrite) {
    return (
      <div className="rounded-md border border-dashed p-8 text-center text-sm text-muted-foreground">
        <Lock className="mx-auto mb-2 h-5 w-5" />
        Non hai i permessi di scrittura sulla sezione <strong>Storico Assortimenti</strong>.
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex items-start gap-3 rounded-md border bg-muted/30 p-4">
        <Package2 className="h-5 w-5 text-primary mt-0.5" />
        <div className="space-y-1 text-sm">
          <div className="font-medium">Import Assortimenti (XLSX)</div>
          <div className="text-muted-foreground">
            File con <strong>2 colonne</strong>: <code>cdpar</code> (codice articolo) e <code>wstato</code> (nuovo stato).
            La data di decorrenza è impostata automaticamente a <strong>oggi</strong>.
            Le righe già allineate vengono ignorate. Gli inserimenti vengono accodati alla sync AS400.
          </div>
        </div>
      </div>

      <FileDropZone
        accept=".xlsx,.xls"
        multiple={false}
        onFiles={(files) => files[0] && handleFile(files[0])}
        label={file ? file.name : "Trascina o clicca per selezionare un file XLSX"}
      />

      {rows.length > 0 && (
        <div className="rounded-md border p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="text-sm">
              <Badge variant="secondary">{rows.length} righe</Badge>
              {warnings.map((w, i) => (
                <span key={i} className="ml-2 text-xs text-amber-600 dark:text-amber-400">⚠ {w}</span>
              ))}
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={phase !== "idle"}
                onClick={() => doRun(true)}
              >
                {phase === "dry" ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <FlaskConical className="h-4 w-4 mr-1" />}
                Dry-run
              </Button>
              <Button
                size="sm"
                disabled={phase !== "idle"}
                onClick={() => doRun(false)}
              >
                {phase === "run" ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <PlayCircle className="h-4 w-4 mr-1" />}
                Esegui import
              </Button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left p-2">#</th>
                  <th className="text-left p-2">cdpar</th>
                  <th className="text-left p-2">wstato</th>
                </tr>
              </thead>
              <tbody>
                {preview.map((r, i) => (
                  <tr key={i} className="border-t">
                    <td className="p-2 text-muted-foreground">{i + 1}</td>
                    <td className="p-2 font-mono">{r.cdpar}</td>
                    <td className="p-2 font-mono"><Badge variant="outline">{r.wstato}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
            {rows.length > preview.length && (
              <div className="text-xs text-muted-foreground p-2">
                … e altre {rows.length - preview.length} righe
              </div>
            )}
          </div>
        </div>
      )}

      {phase !== "idle" && (
        <div className="space-y-1">
          <Progress value={progress} />
          <div className="text-xs text-muted-foreground text-right">{progress}%</div>
        </div>
      )}

      {result && (
        <div className="rounded-md border p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {result.dry_run ? (
                <FlaskConical className="h-5 w-5 text-blue-600" />
              ) : (
                <CheckCircle2 className="h-5 w-5 text-green-600" />
              )}
              <span className="font-medium">
                {result.dry_run ? "Anteprima (nessuna scrittura)" : "Import completato"}
              </span>
            </div>
            <Button variant="outline" size="sm" onClick={() => downloadCsv(result.details)}>
              <Download className="h-4 w-4 mr-1" />
              Scarica report CSV
            </Button>
          </div>
          <div className="grid grid-cols-4 gap-3 text-sm">
            <div className="rounded border p-2">
              <div className="text-xs text-muted-foreground">Totale</div>
              <div className="text-lg font-semibold">{result.total}</div>
            </div>
            <div className="rounded border p-2">
              <div className="text-xs text-muted-foreground">{result.dry_run ? "Da inserire" : "Inserite"}</div>
              <div className="text-lg font-semibold text-green-600">{result.inserted}</div>
            </div>
            <div className="rounded border p-2">
              <div className="text-xs text-muted-foreground">Già allineate</div>
              <div className="text-lg font-semibold text-muted-foreground">{result.unchanged}</div>
            </div>
            <div className="rounded border p-2">
              <div className="text-xs text-muted-foreground">Non trovate</div>
              <div className="text-lg font-semibold text-amber-600">{result.not_found}</div>
            </div>
          </div>

          {result.details.length > 0 && (
            <div className="max-h-64 overflow-auto rounded border">
              <table className="w-full text-xs">
                <thead className="bg-muted/50 sticky top-0">
                  <tr>
                    <th className="text-left p-2">cdpar</th>
                    <th className="text-left p-2">Esito</th>
                    <th className="text-left p-2">Stato prec.</th>
                    <th className="text-left p-2">Stato nuovo</th>
                  </tr>
                </thead>
                <tbody>
                  {result.details.slice(0, 200).map((d, i) => (
                    <tr key={i} className="border-t">
                      <td className="p-2 font-mono">{d.cdpar}</td>
                      <td className="p-2">
                        {d.esito === "inserted" && <Badge className="bg-green-600">inserted</Badge>}
                        {d.esito === "unchanged" && <Badge variant="secondary">unchanged</Badge>}
                        {d.esito === "not_found" && <Badge variant="destructive">not_found</Badge>}
                      </td>
                      <td className="p-2 font-mono text-muted-foreground">{d.stato_precedente ?? "—"}</td>
                      <td className="p-2 font-mono">{d.stato_nuovo}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {result.details.length > 200 && (
                <div className="text-xs text-muted-foreground p-2 border-t">
                  Mostrate le prime 200 righe. Scarica il CSV per il report completo.
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

import { useState } from "react";
import * as XLSX from "xlsx";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { usePermissions } from "@/lib/permissions";
import { Users, Upload, CheckCircle2, AlertCircle, Loader2, Lock } from "lucide-react";

interface ImportResult {
  total: number;
  inserted: number;
  updated: number;
  filename?: string | null;
}

interface CustomerRow {
  customer_code: string;
  company_name: string;
  company_name_aux: string;
  original_agent_code: string;
  zone_code: string;
  city: string;
  province: string;
  billing_customer_code: string;
  postal_code: string;
  vat_number: string;
  category_merch: string;
  category_sales: string;
  phone: string;
  address: string;
  tax_code: string;
  price_list_code: string;
  delivery_address: string;
  delivery_postal_code: string;
  delivery_city: string;
  delivery_province: string;
  email: string;
}

// Mappa header XLSB → campo DB. Tollerante a varianti maiuscole/spazi/punteggiatura/accenti.
function normalizeHeader(h: string): string {
  return String(h ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // rimuove accenti (À → A)
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

const HEADER_MAP: Record<string, keyof CustomerRow> = {
  // customer_code
  cdcli: "customer_code",
  codcli: "customer_code",
  codicecliente: "customer_code",
  cliente: "customer_code",
  // company_name
  ragsoc: "company_name",
  ragionesociale: "company_name",
  ragsociale: "company_name",
  rsoc: "company_name",
  ragsoc1: "company_name",
  descrizione: "company_name",
  // company_name_aux
  ragsocagg: "company_name_aux",
  ragsoc2: "company_name_aux",
  ragionesocialeaggiuntiva: "company_name_aux",
  ragsocaggiuntiva: "company_name_aux",
  ragionesociale2: "company_name_aux",
  // agent
  ag: "original_agent_code",
  agente: "original_agent_code",
  cdag: "original_agent_code",
  codag: "original_agent_code",
  codiceagente: "original_agent_code",
  agen: "original_agent_code",
  // zone
  zn: "zone_code",
  zona: "zone_code",
  cdzn: "zone_code",
  codzn: "zone_code",
  codicezona: "zone_code",
  zon: "zone_code",
  // city
  localita: "city",
  citta: "city",
  comune: "city",
  // province
  pr: "province",
  prov: "province",
  provincia: "province",
  // billing
  clifatt: "billing_customer_code",
  clientefatturazione: "billing_customer_code",
  cdclifatt: "billing_customer_code",
  // cap
  cap: "postal_code",
  capcli: "postal_code",
  // vat
  piva: "vat_number",
  partitaiva: "vat_number",
  pi: "vat_number",
  // categories
  catmerc: "category_merch",
  categoriamerceologica: "category_merch",
  cm: "category_merch",
  catvend: "category_sales",
  categoriavendita: "category_sales",
  cv: "category_sales",
  // phone
  tel: "phone",
  telefono: "phone",
  numerotelefono: "phone",
  // address
  indirizzo: "address",
  ind: "address",
  via: "address",
  // tax code
  codfisc: "tax_code",
  codicefiscale: "tax_code",
  cf: "tax_code",
  // price list
  codlist: "price_list_code",
  list: "price_list_code",
  listino: "price_list_code",
  codicelistino: "price_list_code",
  // delivery
  indscarico: "delivery_address",
  indirizzoscarico: "delivery_address",
  capscarico: "delivery_postal_code",
  cittascarico: "delivery_city",
  localitascarico: "delivery_city",
  prscarico: "delivery_province",
  provscarico: "delivery_province",
  // email
  email: "email",
  mail: "email",
  emailcli: "email",
  posta: "email",
};

const padCustomerCode = (raw: any): string => {
  const s = String(raw ?? "").trim();
  if (!s) return "";
  // Se è solo numerico, pad a 4 zeri come nel file
  if (/^\d+$/.test(s)) return s.padStart(4, "0");
  return s;
};

const cellToString = (v: any): string => {
  if (v == null) return "";
  if (typeof v === "number") {
    // Mantieni leading-zero per codici numerici già padded; numerici puri come stringa intera
    return String(v);
  }
  return String(v).trim();
};

function parseXlsbFile(file: File): Promise<CustomerRow[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const sheetName = wb.SheetNames[0];
        const sheet = wb.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json<Record<string, any>>(sheet, {
          defval: "",
          raw: true,
        });

        // Diagnostica header: log mappati vs ignorati
        if (json.length > 0) {
          const sampleKeys = Object.keys(json[0]);
          const mapped: Record<string, string> = {};
          const ignored: string[] = [];
          for (const k of sampleKeys) {
            const norm = normalizeHeader(k);
            const f = HEADER_MAP[norm];
            if (f) mapped[k] = `${f} (norm: "${norm}")`;
            else ignored.push(`${k} (norm: "${norm}")`);
          }
          console.log("[CustomersImport] Header MAPPATI:", mapped);
          console.log("[CustomersImport] Header IGNORATI:", ignored);
        }

        const rows: CustomerRow[] = json.map((rec) => {
          const out: any = {
            customer_code: "", company_name: "", company_name_aux: "",
            original_agent_code: "", zone_code: "", city: "", province: "",
            billing_customer_code: "", postal_code: "", vat_number: "",
            category_merch: "", category_sales: "", phone: "", address: "",
            tax_code: "", price_list_code: "", delivery_address: "",
            delivery_postal_code: "", delivery_city: "", delivery_province: "",
            email: "",
          };
          for (const key of Object.keys(rec)) {
            const norm = normalizeHeader(key);
            const dbField = HEADER_MAP[norm];
            if (dbField) {
              out[dbField] = cellToString(rec[key]);
            }
          }
          out.customer_code = padCustomerCode(out.customer_code);
          // CLIFATT: stesso padding logico (4 cifre se numerico)
          if (out.billing_customer_code) {
            out.billing_customer_code = padCustomerCode(out.billing_customer_code);
          }
          // Normalizza CAP a 5 cifre se numerico
          if (out.postal_code && /^\d+$/.test(out.postal_code)) {
            out.postal_code = out.postal_code.padStart(5, "0");
          }
          if (out.delivery_postal_code && /^\d+$/.test(out.delivery_postal_code)) {
            out.delivery_postal_code = out.delivery_postal_code.padStart(5, "0");
          }
          // Listino: se numerico, mantieni intero (1, 2…)
          return out as CustomerRow;
        }).filter((r) => r.customer_code.length > 0);

        resolve(rows);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsArrayBuffer(file);
  });
}

const CHUNK_SIZE = 1000;

export function CustomersImportPanel() {
  const { can } = usePermissions();
  const canImport = can("write", "import_clienti");
  const [file, setFile] = useState<File | null>(null);
  const [rows, setRows] = useState<CustomerRow[]>([]);
  const [parsing, setParsing] = useState(false);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFiles = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    setFile(f);
    setResult(null);
    setError(null);
    setRows([]);
    setParsing(true);
    try {
      const parsed = await parseXlsbFile(f);
      setRows(parsed);
      if (parsed.length === 0) {
        toast({
          title: "Nessuna riga valida",
          description: "Controlla che il file contenga la colonna CDCLI.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "File caricato",
          description: `${parsed.length} clienti pronti per l'import.`,
        });
      }
    } catch (err: any) {
      console.error("[CustomersImport] parse error:", err);
      setError(err?.message ?? "Errore parsing file");
      toast({
        title: "Errore parsing",
        description: err?.message ?? "Impossibile leggere il file",
        variant: "destructive",
      });
    } finally {
      setParsing(false);
    }
  };

  const runImport = async () => {
    if (rows.length === 0 || !file) return;
    setRunning(true);
    setProgress(0);
    setError(null);
    setResult(null);

    let totalInserted = 0;
    let totalUpdated = 0;
    let totalProcessed = 0;

    try {
      // Dedup per customer_code: ultima occorrenza vince
      const dedupMap = new Map<string, CustomerRow>();
      for (const r of rows) dedupMap.set(r.customer_code, r);
      const uniqueRows = Array.from(dedupMap.values());
      const skipped = rows.length - uniqueRows.length;
      if (skipped > 0) {
        console.warn(`[CustomersImport] Rimossi ${skipped} duplicati su customer_code`);
      }

      for (let i = 0; i < uniqueRows.length; i += CHUNK_SIZE) {
        const chunk = uniqueRows.slice(i, i + CHUNK_SIZE);
        const { data, error: rpcErr } = await supabase.rpc(
          "import_customers_snapshot" as any,
          { rows: chunk as any, p_filename: file.name }
        );
        if (rpcErr) throw rpcErr;
        const r = data as any;
        totalInserted += Number(r?.inserted ?? 0);
        totalUpdated += Number(r?.updated ?? 0);
        totalProcessed += chunk.length;
        setProgress(Math.round((totalProcessed / uniqueRows.length) * 100));
      }

      setResult({
        total: rows.length,
        inserted: totalInserted,
        updated: totalUpdated,
        filename: file.name,
      });
      toast({
        title: "Import clienti completato",
        description: `${totalInserted} nuovi, ${totalUpdated} aggiornati.`,
      });
    } catch (e: any) {
      console.error("[CustomersImport] error:", e);
      setError(e.message ?? "Errore sconosciuto");
      toast({
        title: "Errore import",
        description: e.message ?? "Errore sconosciuto",
        variant: "destructive",
      });
    } finally {
      setRunning(false);
    }
  };

  const reset = () => {
    setFile(null);
    setRows([]);
    setResult(null);
    setError(null);
    setProgress(0);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Users className="h-6 w-6" />
        <div>
          <h1 className="text-2xl font-bold">Clienti</h1>
          <p className="text-sm text-muted-foreground">
            Importa il file XLSB dei clienti AS400. L'import aggiorna i record esistenti per <code>CDCLI</code> senza creare duplicati.
          </p>
        </div>
      </div>

      {!file && (
        <FileDropZone
          accept=".xlsb,.xlsx,.xls"
          multiple={false}
          label="Trascina qui il file .xlsb (o .xlsx) clienti, o clicca per selezionarlo"
          onFiles={handleFiles}
          className="py-12"
        />
      )}

      {parsing && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" />
          Lettura file in corso…
        </div>
      )}

      {file && !parsing && (
        <div className="rounded-lg border bg-card p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Upload className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium">{file.name}</span>
              <Badge variant="outline">{rows.length} clienti</Badge>
            </div>
            <Button variant="ghost" size="sm" onClick={reset} disabled={running}>
              Cambia file
            </Button>
          </div>

          {rows.length > 0 && (
            <div className="rounded border bg-muted/30 p-3 text-xs max-h-64 overflow-auto">
              <div className="font-semibold mb-1 text-muted-foreground">
                Anteprima (prime 10 righe):
              </div>
              <table className="w-full">
                <thead>
                  <tr className="text-left text-muted-foreground">
                    <th className="pr-2">CDCLI</th>
                    <th className="pr-2">Ragione Sociale</th>
                    <th className="pr-2">AG</th>
                    <th className="pr-2">ZN</th>
                    <th className="pr-2">Località</th>
                    <th className="pr-2">PR</th>
                    <th>P.IVA</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.slice(0, 10).map((r, i) => (
                    <tr key={i}>
                      <td className="pr-2 font-mono">{r.customer_code}</td>
                      <td className="pr-2">
                        {r.company_name || <span className="text-destructive">—</span>}
                        {r.company_name_aux && <span className="text-muted-foreground"> · {r.company_name_aux}</span>}
                      </td>
                      <td className="pr-2 font-mono">{r.original_agent_code || <span className="text-destructive">—</span>}</td>
                      <td className="pr-2 font-mono">{r.zone_code || <span className="text-destructive">—</span>}</td>
                      <td className="pr-2">{r.city}</td>
                      <td className="pr-2">{r.province}</td>
                      <td className="font-mono">{r.vat_number}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {running && (
            <div className="space-y-2">
              <Progress value={progress} />
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Loader2 className="h-3 w-3 animate-spin" />
                Import in corso… {progress}%
              </div>
            </div>
          )}

          {error && (
            <div className="flex items-start gap-2 rounded border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
              <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
              <div>{error}</div>
            </div>
          )}

          {result && (
            <div className="rounded border border-green-500/30 bg-green-50 dark:bg-green-950/20 p-4 space-y-2">
              <div className="flex items-center gap-2 text-green-700 dark:text-green-400 font-medium">
                <CheckCircle2 className="h-4 w-4" />
                Import completato
              </div>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Righe nel file</div>
                  <div className="text-xl font-bold tabular-nums">{result.total}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Nuovi clienti</div>
                  <div className="text-xl font-bold tabular-nums text-green-600">
                    {result.inserted}
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground">Aggiornati</div>
                  <div className="text-xl font-bold tabular-nums text-blue-600">
                    {result.updated}
                  </div>
                </div>
              </div>
            </div>
          )}

          {!result && !canImport && (
            <div className="flex items-start gap-2 rounded border border-amber-500/30 bg-amber-50 dark:bg-amber-950/20 p-3 text-sm text-amber-800 dark:text-amber-300">
              <Lock className="h-4 w-4 mt-0.5 shrink-0" />
              <div>Non hai il permesso di scrittura sulla sezione <b>Import · Clienti</b>. Chiedi a un amministratore di abilitarlo per eseguire l'import.</div>
            </div>
          )}

          {!result && (
            <Button
              onClick={runImport}
              disabled={running || rows.length === 0 || !canImport}
              className="w-full"
            >
              {running ? "Importazione in corso..." : `Importa ${rows.length} clienti`}
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertCircle, Download, FileSpreadsheet, Play } from "lucide-react";
import { parseCatalogoCartaXlsx, type CatalogoCartaRow } from "@/lib/catalogoCartaParser";
import { useCatalogoCartaImport } from "@/hooks/useCatalogoCartaImport";
import { toast } from "@/hooks/use-toast";
import { downloadXlsxAoa } from "@/lib/xlsxExport";

const COLS = ["cdpar", "catalogo_carta_titolo", "catalogo_carta_dettaglio", "catalogo_carta_scheda"] as const;

export function CatalogoCartaPanel() {
  const [file, setFile] = useState<File | null>(null);
  const [rows, setRows] = useState<CatalogoCartaRow[]>([]);
  const [parsing, setParsing] = useState(false);
  const [warnings, setWarnings] = useState<string[]>([]);
  const { run, reset, isRunning, progress, stats, error } = useCatalogoCartaImport();

  const handleFile = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    setFile(f);
    setRows([]);
    setWarnings([]);
    reset();
    setParsing(true);
    try {
      const res = await parseCatalogoCartaXlsx(f);
      setRows(res.rows);
      setWarnings(res.warnings);
      toast({ title: "File letto", description: `${res.rows.length.toLocaleString()} righe valide` });
    } catch (e: any) {
      toast({ title: "Errore parsing", description: e?.message ?? "Errore", variant: "destructive" });
    } finally {
      setParsing(false);
    }
  };

  const handleImport = () => {
    if (rows.length === 0) return;
    run(rows);
  };

  const downloadTemplate = () => {
    downloadXlsxAoa("template_cataloghi_carta.xlsx", [
      ["cdpar", "catalogo_carta_titolo (max 37)", "catalogo_carta_dettaglio (max 29)", "catalogo_carta_scheda (max 340)"],
      ["001010", "Giratubi modello americano", "Lunghezza 250 mm - 10\"", "Corpo monoblocco in acciaio fuso con testa lucida e impugnatura verniciata"],
      ["001020", "Giratubi modello americano", "Lunghezza 300 mm - 12\"", "Corpo monoblocco in acciaio fuso con testa lucida"],
    ]);
  };

  return (
    <div className="space-y-6">
      <div className="rounded-lg border bg-card p-4 space-y-2">
        <div className="flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Cataloghi Carta — Titolo/Dettaglio/Scheda</h2>
          <Badge variant="secondary">PIM-only</Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          Aggiorna i 3 campi PIM-only per la stampa dei cataloghi cartacei
          (<code>catalogo_carta_titolo</code> max 37 · <code>catalogo_carta_dettaglio</code> max 29 · <code>catalogo_carta_scheda</code> max 340).
          Colonne in ordine posizionale: <code>cdpar</code>, titolo, dettaglio, scheda. Valori oltre i limiti vengono troncati.
          Solo update: cdpar non presenti in archivio vengono contati come "mancanti".
        </p>
        <div>
          <Button variant="outline" size="sm" onClick={downloadTemplate}>
            <Download className="mr-2 h-4 w-4" /> Scarica template XLSX
          </Button>
        </div>
      </div>

      <FileDropZone
        accept=".xlsx,.xls"
        multiple={false}
        onFiles={handleFile}
        label={file ? `${file.name} — ${(file.size / 1024 / 1024).toFixed(2)} MB` : "Trascina il file XLSX o clicca per selezionare"}
        className="p-8"
        disabled={isRunning}
      />

      {parsing && <p className="text-sm text-muted-foreground">Lettura file in corso…</p>}

      {warnings.length > 0 && (
        <Alert variant="default">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{warnings.join(" · ")}</AlertDescription>
        </Alert>
      )}

      {rows.length > 0 && !isRunning && !stats && (
        <>
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex flex-wrap items-center gap-3">
              <Badge>{rows.length.toLocaleString()} righe da processare</Badge>
              <span className="text-sm text-muted-foreground">Update in chunk da 1.000</span>
            </div>
            <Button onClick={handleImport} disabled={isRunning}>
              <Play className="mr-2 h-4 w-4" /> Avvia import
            </Button>
          </div>

          <div className="rounded-lg border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  {COLS.map((h) => (
                    <TableHead key={h} className="text-xs whitespace-nowrap">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.slice(0, 5).map((r, i) => (
                  <TableRow key={i}>
                    {COLS.map((k) => (
                      <TableCell key={k} className="text-xs whitespace-nowrap max-w-[260px] truncate">
                        {r[k as keyof CatalogoCartaRow] || "—"}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <p className="text-xs text-muted-foreground p-2">Anteprima prime 5 righe</p>
          </div>
        </>
      )}

      {isRunning && (
        <div className="space-y-2">
          <Progress value={progress} />
          <p className="text-sm text-muted-foreground">
            Import in corso… {Math.round(progress)}%
            {stats && (
              <> · {stats.updated.toLocaleString()} aggiornati · {stats.unchanged.toLocaleString()} invariati · {stats.missing.toLocaleString()} mancanti</>
            )}
          </p>
        </div>
      )}

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {stats && !isRunning && !error && (
        <div className="rounded-lg border p-4 space-y-3">
          <h3 className="font-semibold">Import completato</h3>
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary">{stats.total.toLocaleString()} totali</Badge>
            <Badge className="bg-blue-600">{stats.updated.toLocaleString()} aggiornati</Badge>
            <Badge variant="outline">{stats.unchanged.toLocaleString()} invariati</Badge>
            {stats.missing > 0 && <Badge variant="destructive">{stats.missing.toLocaleString()} cdpar non trovati</Badge>}
          </div>
          <Button variant="outline" onClick={() => { setFile(null); setRows([]); reset(); }}>
            Nuovo import
          </Button>
        </div>
      )}
    </div>
  );
}

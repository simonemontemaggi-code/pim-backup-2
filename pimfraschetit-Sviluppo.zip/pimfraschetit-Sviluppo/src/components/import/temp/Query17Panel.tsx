import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertCircle, FileSpreadsheet, Play } from "lucide-react";
import { parseQuery17Xlsx, type Q17Row } from "@/lib/query17Parser";
import { useQuery17Import } from "@/hooks/useQuery17Import";
import { toast } from "@/hooks/use-toast";

const COLS: (keyof Q17Row)[] = ["cdpar", "cdncm"];

export function Query17Panel() {
  const [file, setFile] = useState<File | null>(null);
  const [rows, setRows] = useState<Q17Row[]>([]);
  const [parsing, setParsing] = useState(false);
  const [warnings, setWarnings] = useState<string[]>([]);
  const { run, reset, isRunning, progress, stats, error } = useQuery17Import();

  const handleFile = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    setFile(f);
    setRows([]);
    setWarnings([]);
    reset();
    setParsing(true);
    try {
      const res = await parseQuery17Xlsx(f);
      setRows(res.rows);
      setWarnings(res.warnings);
      toast({ title: "File letto", description: `${res.rows.length.toLocaleString()} righe trovate` });
    } catch (e: any) {
      toast({ title: "Errore parsing", description: e?.message ?? "Errore", variant: "destructive" });
    } finally {
      setParsing(false);
    }
  };

  const handleImport = () => {
    if (rows.length === 0) return;
    run(rows);
  };

  return (
    <div className="space-y-6">
      <div className="rounded-lg border bg-card p-4 space-y-2">
        <div className="flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Query 17 — Nomenclatura Combinata</h2>
          <Badge variant="secondary">PIM-only</Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          Carica l'estrazione XLSX della QUERY 17 (articoli con <code>wfuas</code> in C/E/G/H/N/O).
          Per ogni <code>cdpar</code> aggiorna o inserisce il codice <code>cdncm</code> nella
          tabella <code>nomenclatura_combinata</code>.
        </p>
        <p className="text-xs text-muted-foreground">
          Mapping per posizione (2 colonne): cdpar, cdncm. <code>cdpar</code> normalizzato a 6 cifre
          con padding. Nessuna cancellazione, nessun export AS400.
        </p>
      </div>

      <FileDropZone
        accept=".xlsx,.xls"
        multiple={false}
        onFiles={handleFile}
        label={file ? `${file.name} — ${(file.size / 1024 / 1024).toFixed(2)} MB` : "Trascina il file XLSX o clicca per selezionare"}
        className="p-8"
        disabled={isRunning}
      />

      {parsing && <p className="text-sm text-muted-foreground">Lettura file in corso…</p>}

      {warnings.length > 0 && (
        <Alert variant="default">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{warnings.join(" · ")}</AlertDescription>
        </Alert>
      )}

      {rows.length > 0 && !isRunning && !stats && (
        <>
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex flex-wrap items-center gap-3">
              <Badge>{rows.length.toLocaleString()} righe da processare</Badge>
              <span className="text-sm text-muted-foreground">Upsert (chunk da 2.000)</span>
            </div>
            <Button onClick={handleImport} disabled={isRunning}>
              <Play className="mr-2 h-4 w-4" /> Avvia import
            </Button>
          </div>

          <div className="rounded-lg border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  {COLS.map(h => (
                    <TableHead key={h} className="text-xs whitespace-nowrap">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.slice(0, 8).map((r, i) => (
                  <TableRow key={i}>
                    {COLS.map(k => (
                      <TableCell key={k} className="text-xs whitespace-nowrap">{r[k] === null ? "—" : String(r[k])}</TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <p className="text-xs text-muted-foreground p-2">Anteprima prime 8 righe</p>
          </div>
        </>
      )}

      {isRunning && (
        <div className="space-y-2">
          <Progress value={progress} />
          <p className="text-sm text-muted-foreground">
            Import in corso… {Math.round(progress)}%
            {stats && (
              <> · {stats.inserted.toLocaleString()} nuovi · {stats.updated.toLocaleString()} aggiornati · {stats.unchanged.toLocaleString()} invariati</>
            )}
          </p>
        </div>
      )}

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {stats && !isRunning && !error && (
        <div className="rounded-lg border p-4 space-y-3">
          <h3 className="font-semibold">Import completato</h3>
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary">{stats.total.toLocaleString()} righe</Badge>
            <Badge className="bg-green-600">{stats.inserted.toLocaleString()} nuovi</Badge>
            <Badge className="bg-blue-600">{stats.updated.toLocaleString()} aggiornati</Badge>
            <Badge variant="outline">{stats.unchanged.toLocaleString()} invariati</Badge>
          </div>
          <Button variant="outline" onClick={() => { setFile(null); setRows([]); reset(); }}>
            Nuovo import
          </Button>
        </div>
      )}
    </div>
  );
}

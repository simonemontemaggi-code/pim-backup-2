import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertCircle, FileSpreadsheet, Play } from "lucide-react";
import { parseQuery07Xlsx, type Q07Row } from "@/lib/query07Parser";
import { useQuery07Import } from "@/hooks/useQuery07Import";
import { toast } from "@/hooks/use-toast";

const COLS = [
  "wcdls", "wcdcv", "wcdcl", "wcdpa", "wnrsc", "wdtvi", "wdtvf",
  "wprun", "wprui", "wtpbl", "wqtxm", "wqtxn", "wcpam", "wscon",
  "wqtms", "wsimp", "wnpun", "writac", "wriatc",
] as const;

export function Query07Panel() {
  const [file, setFile] = useState<File | null>(null);
  const [rows, setRows] = useState<Q07Row[]>([]);
  const [parsing, setParsing] = useState(false);
  const [warnings, setWarnings] = useState<string[]>([]);
  const { run, reset, isRunning, progress, stats, error } = useQuery07Import();

  const handleFile = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    setFile(f);
    setRows([]);
    setWarnings([]);
    reset();
    setParsing(true);
    try {
      const res = await parseQuery07Xlsx(f);
      setRows(res.rows);
      setWarnings(res.warnings);
      toast({ title: "File letto", description: `${res.rows.length.toLocaleString()} righe trovate` });
    } catch (e: any) {
      toast({ title: "Errore parsing", description: e?.message ?? "Errore", variant: "destructive" });
    } finally {
      setParsing(false);
    }
  };

  const handleImport = () => {
    if (rows.length === 0) return;
    run(rows);
  };

  return (
    <div className="space-y-6">
      <div className="rounded-lg border bg-card p-4 space-y-2">
        <div className="flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Query 07 — Listini di Vendita Campagne</h2>
          <Badge variant="secondary">PIM-only</Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          Carica l'estrazione XLSX della QUERY 07. Aggiorna le righe già presenti
          (chiave: articolo + listino + cat. vendita + cliente + scaglione + data inizio + data fine)
          quando uno qualsiasi dei campi non chiave è cambiato (prezzi, codice campagna,
          sconti, omaggi, punti, WRITAC/WRIATC). Inserisce le combinazioni nuove.
          Non elimina mai righe (le campagne scadute restano in archivio).
          Nessun export verso AS400.
        </p>
        <p className="text-xs text-muted-foreground">
          Mapping per posizione (19 colonne): wcdls, wcdcv, wcdcl, wcdpa, wnrsc, wdtvi, wdtvf,
          wprun, wprui, wtpbl, wqtxm, wqtxn, wcpam, wscon, wqtms, wsimp, wnpun, writac, wriatc.
          Target: <code>listini_vendita_campagne</code>.
        </p>
      </div>

      <FileDropZone
        accept=".xlsx,.xls"
        multiple={false}
        onFiles={handleFile}
        label={file ? `${file.name} — ${(file.size / 1024 / 1024).toFixed(2)} MB` : "Trascina il file XLSX o clicca per selezionare"}
        className="p-8"
        disabled={isRunning}
      />

      {parsing && <p className="text-sm text-muted-foreground">Lettura file in corso…</p>}

      {warnings.length > 0 && (
        <Alert variant="default">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{warnings.join(" · ")}</AlertDescription>
        </Alert>
      )}

      {rows.length > 0 && !isRunning && !stats && (
        <>
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex flex-wrap items-center gap-3">
              <Badge>{rows.length.toLocaleString()} righe da processare</Badge>
              <span className="text-sm text-muted-foreground">
                Update + insert nuovi (chunk da 1.000)
              </span>
            </div>
            <Button onClick={handleImport} disabled={isRunning}>
              <Play className="mr-2 h-4 w-4" /> Avvia import
            </Button>
          </div>

          <div className="rounded-lg border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  {COLS.map(h => (
                    <TableHead key={h} className="text-xs whitespace-nowrap">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.slice(0, 8).map((r, i) => (
                  <TableRow key={i}>
                    {COLS.map(k => {
                      const v = r[k as keyof Q07Row];
                      return (
                        <TableCell key={k} className="text-xs whitespace-nowrap">
                          {v === null || v === undefined ? "—" : String(v)}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <p className="text-xs text-muted-foreground p-2">Anteprima prime 8 righe</p>
          </div>
        </>
      )}

      {isRunning && (
        <div className="space-y-2">
          <Progress value={progress} />
          <p className="text-sm text-muted-foreground">
            Import in corso… {Math.round(progress)}%
            {stats && (
              <> · {stats.updated.toLocaleString()} aggiornati · {stats.inserted.toLocaleString()} inseriti · {stats.unchanged.toLocaleString()} invariati</>
            )}
          </p>
        </div>
      )}

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {stats && !isRunning && !error && (
        <div className="rounded-lg border p-4 space-y-3">
          <h3 className="font-semibold">Import completato</h3>
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary">{stats.total.toLocaleString()} totali</Badge>
            <Badge className="bg-blue-600">{stats.updated.toLocaleString()} aggiornati</Badge>
            <Badge className="bg-green-600">{stats.inserted.toLocaleString()} inseriti</Badge>
            <Badge variant="outline">{stats.unchanged.toLocaleString()} invariati</Badge>
          </div>
          <Button variant="outline" onClick={() => { setFile(null); setRows([]); reset(); }}>
            Nuovo import
          </Button>
        </div>
      )}
    </div>
  );
}

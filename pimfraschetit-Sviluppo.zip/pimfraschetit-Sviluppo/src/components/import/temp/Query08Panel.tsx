import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AlertCircle, FileSpreadsheet, Play } from "lucide-react";
import { parseQuery08Xlsx, type Q08Row } from "@/lib/query08Parser";
import { useQuery08Import } from "@/hooks/useQuery08Import";
import { toast } from "@/hooks/use-toast";

const COLS = [
  "wcdpa", "wcdls", "wcdcv", "wcdcl",
  "wnrsc", "wmova",
  "wsm01", "wsm02", "wsm03", "wsmim",
  "wcmri", "wcbve", "wvdim",
  "war01", "wta01", "wco01", "wic01",
  "wfcsv",
  "wrcls", "wrccv", "wrccl",
] as const;

export function Query08Panel() {
  const [file, setFile] = useState<File | null>(null);
  const [rows, setRows] = useState<Q08Row[]>([]);
  const [parsing, setParsing] = useState(false);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [overwrite, setOverwrite] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const { run, reset, isRunning, progress, stats, error } = useQuery08Import();

  const handleFile = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    setFile(f);
    setRows([]);
    setWarnings([]);
    reset();
    setParsing(true);
    try {
      const res = await parseQuery08Xlsx(f);
      setRows(res.rows);
      setWarnings(res.warnings);
      toast({ title: "File letto", description: `${res.rows.length.toLocaleString()} righe trovate` });
    } catch (e: any) {
      toast({ title: "Errore parsing", description: e?.message ?? "Errore", variant: "destructive" });
    } finally {
      setParsing(false);
    }
  };

  const handleImport = () => {
    if (rows.length === 0) return;
    if (overwrite) { setConfirmOpen(true); return; }
    run(rows, { overwrite: false });
  };

  const confirmOverwrite = () => {
    setConfirmOpen(false);
    run(rows, { overwrite: true });
  };

  return (
    <div className="space-y-6">
      <div className="rounded-lg border bg-card p-4 space-y-2">
        <div className="flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Query 08 — Listini di Vendita Criteri di Prezzo</h2>
          <Badge variant="secondary">PIM-only</Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          Carica l'estrazione XLSX della QUERY 08. Aggiorna su <code>listini_vendita_criteri_prezzo</code>
          tutti i 17 campi non-chiave (scaglioni <code>wsm01/02/03</code>, <code>wnrsc</code>, <code>wmova</code>,
          <code>wsmim</code>, magazzino/base/dim <code>wcmri/wcbve/wvdim</code>, arrotondamenti
          <code>war01/wta01/wco01/wic01</code>, <code>wfcsv</code>, riferimenti listino
          <code>wrcls/wrccv/wrccl</code>) — solo se almeno un valore cambia. Chiave: articolo + listino + cat. vendita + cliente.
          Inserisce le combinazioni nuove. Non elimina mai righe. Nessun export verso AS400.
        </p>
        <p className="text-xs text-muted-foreground">
          Mapping per posizione (21 colonne): wcdpa, wcdls, wcdcv, wcdcl, wnrsc, wmova,
          wsm01, wsm02, wsm03, wsmim, wcmri, wcbve, wvdim, war01, wta01, wco01, wic01,
          wfcsv, wrcls, wrccv, wrccl.
        </p>
      </div>

      <FileDropZone
        accept=".xlsx,.xls"
        multiple={false}
        onFiles={handleFile}
        label={file ? `${file.name} — ${(file.size / 1024 / 1024).toFixed(2)} MB` : "Trascina il file XLSX o clicca per selezionare"}
        className="p-8"
        disabled={isRunning}
      />

      {parsing && <p className="text-sm text-muted-foreground">Lettura file in corso…</p>}

      {warnings.length > 0 && (
        <Alert variant="default">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{warnings.join(" · ")}</AlertDescription>
        </Alert>
      )}

      {rows.length > 0 && !isRunning && !stats && (
        <>
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex flex-wrap items-center gap-3">
              <Badge>{rows.length.toLocaleString()} righe da processare</Badge>
              <span className="text-sm text-muted-foreground">
                {overwrite
                  ? "Sovrascrivi: elimina TUTTE le righe esistenti, poi inserisce il file"
                  : "Aggiorna: update sui campi cambiati + insert nuovi (chunk da 1.000)"}
              </span>
            </div>
            <div className="flex items-center gap-3 rounded-md border bg-muted/30 p-3">
              <Switch id="q08-overwrite" checked={overwrite} onCheckedChange={setOverwrite} />
              <Label htmlFor="q08-overwrite" className="cursor-pointer text-sm">
                Sovrascrivi tutta la tabella
              </Label>
              {overwrite && (
                <Badge variant="destructive" className="ml-auto">⚠ Cancella tutte le righe esistenti</Badge>
              )}
            </div>
            <Button onClick={handleImport} disabled={isRunning} variant={overwrite ? "destructive" : "default"}>
              <Play className="mr-2 h-4 w-4" />
              {overwrite ? "Sovrascrivi e importa" : "Avvia import"}
            </Button>
          </div>

          <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Sovrascrivere tutta la tabella?</AlertDialogTitle>
                <AlertDialogDescription>
                  Verranno eliminate <strong>tutte</strong> le righe attualmente presenti in
                  <code className="mx-1">listini_vendita_criteri_prezzo</code> e sostituite con le
                  {" "}{rows.length.toLocaleString()} righe del file caricato. L'operazione non è reversibile.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Annulla</AlertDialogCancel>
                <AlertDialogAction onClick={confirmOverwrite} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  Sì, sovrascrivi
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          <div className="rounded-lg border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  {COLS.map(h => (
                    <TableHead key={h} className="text-xs whitespace-nowrap">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.slice(0, 8).map((r, i) => (
                  <TableRow key={i}>
                    {COLS.map(k => {
                      const v = r[k as keyof Q08Row];
                      return (
                        <TableCell key={k} className="text-xs whitespace-nowrap">
                          {v === null || v === undefined ? "—" : String(v)}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <p className="text-xs text-muted-foreground p-2">Anteprima prime 8 righe</p>
          </div>
        </>
      )}

      {isRunning && (
        <div className="space-y-2">
          <Progress value={progress} />
          <p className="text-sm text-muted-foreground">
            Import in corso… {Math.round(progress)}%
            {stats && (
              <> · {stats.updated.toLocaleString()} aggiornati · {stats.inserted.toLocaleString()} inseriti · {stats.unchanged.toLocaleString()} invariati</>
            )}
          </p>
        </div>
      )}

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {stats && !isRunning && !error && (
        <div className="rounded-lg border p-4 space-y-3">
          <h3 className="font-semibold">Import completato</h3>
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary">{stats.total.toLocaleString()} totali</Badge>
            <Badge className="bg-blue-600">{stats.updated.toLocaleString()} aggiornati</Badge>
            <Badge className="bg-green-600">{stats.inserted.toLocaleString()} inseriti</Badge>
            <Badge variant="outline">{stats.unchanged.toLocaleString()} invariati</Badge>
          </div>
          <Button variant="outline" onClick={() => { setFile(null); setRows([]); reset(); }}>
            Nuovo import
          </Button>
        </div>
      )}
    </div>
  );
}

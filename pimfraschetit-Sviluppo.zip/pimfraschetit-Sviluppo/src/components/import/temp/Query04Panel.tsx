import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertCircle, FileSpreadsheet, Play } from "lucide-react";
import { parseQuery04Xlsx, type Q04Row } from "@/lib/query04Parser";
import { useQuery04Import } from "@/hooks/useQuery04Import";
import { toast } from "@/hooks/use-toast";

const COLS = [
  "cdpar", "cdfor", "cdcat", "dtvai", "dtvaf", "cdval", "rifli",
  "qtsc1", "prsc1", "scfa1", "scfb1",
  "wmasc", "wprsc", "wscfa", "wscfb", "wscfc", "wscfd", "wscfe", "wctri", "wcpfa", "wcpfb", "wcpfc",
] as const;

export function Query04Panel() {
  const [file, setFile] = useState<File | null>(null);
  const [rows, setRows] = useState<Q04Row[]>([]);
  const [parsing, setParsing] = useState(false);
  const [warnings, setWarnings] = useState<string[]>([]);
  const { run, reset, isRunning, progress, stats, error } = useQuery04Import();

  const handleFile = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    setFile(f);
    setRows([]);
    setWarnings([]);
    reset();
    setParsing(true);
    try {
      const res = await parseQuery04Xlsx(f);
      setRows(res.rows);
      setWarnings(res.warnings);
      toast({ title: "File letto", description: `${res.rows.length.toLocaleString()} righe valide` });
    } catch (e: any) {
      toast({ title: "Errore parsing", description: e?.message ?? "Errore", variant: "destructive" });
    } finally {
      setParsing(false);
    }
  };

  const handleImport = () => {
    if (rows.length === 0) return;
    run(rows);
  };

  return (
    <div className="space-y-6">
      <div className="rounded-lg border bg-card p-4 space-y-2">
        <div className="flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Query 04 — Archivio Listini Fraschetti / Cataloghi Fornitori</h2>
          <Badge variant="secondary">PIM-only</Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          Carica l'estrazione XLSX della QUERY 04. Aggiorna solo i campi differenti
          sulle righe esistenti (chiave articolo + fornitore + catalogo + data
          validità) e inserisce le nuove combinazioni. Non elimina mai righe.
          Nessun export verso AS400.
        </p>
        <p className="text-xs text-muted-foreground">
          Mapping per posizione (57 colonne): anagrafici WANCT00F (nrz02, daz02,
          cdcat, cdpar, cdfor, daoff, rifli, dtvai, dtvaf, cdval, gioff, catri,
          notec, avcat, cdrcf, usorc), 5 scaglioni completi (qtsc/prsc/scfa/scfb/masc/sisc)
          e campi calcolati WANCTW0F (wmasc, wprsc, wscfa-e, wctri, wcpfa, wcpfb, wcpfc).
          Target: <code>archivio_listini_fraschetti</code>. Chiave naturale:
          <code> (cdpar, cdfor, cdcat, dtvai)</code>.
        </p>
      </div>

      <FileDropZone
        accept=".xlsx,.xls"
        multiple={false}
        onFiles={handleFile}
        label={file ? `${file.name} — ${(file.size / 1024 / 1024).toFixed(2)} MB` : "Trascina il file XLSX o clicca per selezionare"}
        className="p-8"
        disabled={isRunning}
      />

      {parsing && <p className="text-sm text-muted-foreground">Lettura file in corso…</p>}

      {warnings.length > 0 && (
        <Alert variant="default">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{warnings.join(" · ")}</AlertDescription>
        </Alert>
      )}

      {rows.length > 0 && !isRunning && !stats && (
        <>
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex flex-wrap items-center gap-3">
              <Badge>{rows.length.toLocaleString()} righe da processare</Badge>
              <span className="text-sm text-muted-foreground">
                Update differenziale + insert nuovi (chunk da 3.000)
              </span>
            </div>
            <Button onClick={handleImport} disabled={isRunning}>
              <Play className="mr-2 h-4 w-4" /> Avvia import
            </Button>
          </div>

          <div className="rounded-lg border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  {COLS.map(h => (
                    <TableHead key={h} className="text-xs whitespace-nowrap">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.slice(0, 5).map((r, i) => (
                  <TableRow key={i}>
                    {COLS.map(k => (
                      <TableCell key={k} className="text-xs whitespace-nowrap max-w-[160px] truncate">
                        {r[k as keyof Q04Row] === null || r[k as keyof Q04Row] === undefined ? "—" : String(r[k as keyof Q04Row])}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <p className="text-xs text-muted-foreground p-2">Anteprima prime 5 righe</p>
          </div>
        </>
      )}

      {isRunning && (
        <div className="space-y-2">
          <Progress value={progress} />
          <p className="text-sm text-muted-foreground">
            Import in corso… {Math.round(progress)}%
            {stats && (
              <> · {stats.updated.toLocaleString()} aggiornati · {stats.inserted.toLocaleString()} inseriti · {stats.unchanged.toLocaleString()} invariati</>
            )}
          </p>
        </div>
      )}

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {stats && !isRunning && !error && (
        <div className="rounded-lg border p-4 space-y-3">
          <h3 className="font-semibold">Import completato</h3>
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary">{stats.total.toLocaleString()} totali</Badge>
            <Badge className="bg-blue-600">{stats.updated.toLocaleString()} aggiornati</Badge>
            <Badge className="bg-green-600">{stats.inserted.toLocaleString()} inseriti</Badge>
            <Badge variant="outline">{stats.unchanged.toLocaleString()} invariati</Badge>
          </div>
          <Button variant="outline" onClick={() => { setFile(null); setRows([]); reset(); }}>
            Nuovo import
          </Button>
        </div>
      )}
    </div>
  );
}

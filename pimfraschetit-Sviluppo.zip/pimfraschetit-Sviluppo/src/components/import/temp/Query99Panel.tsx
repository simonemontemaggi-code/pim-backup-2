import { useMemo, useState } from "react";
import * as XLSX from "xlsx";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertCircle, FileSpreadsheet, Play } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface Row {
  cdpar: string;
  ricarico: number;
}

interface Stats {
  total: number;
  updated: number;
  unchanged: number;
  not_found: number;
}

function pad6(s: string) {
  const digits = String(s ?? "").replace(/\D/g, "");
  if (!digits) return "";
  return digits.padStart(6, "0");
}

async function parseFile(file: File): Promise<{ rows: Row[]; warnings: string[] }> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const raw = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: "" });
  if (!raw.length) return { rows: [], warnings: ["File vuoto"] };

  const warnings: string[] = [];
  const seen = new Set<string>();
  const rows: Row[] = [];
  // Skip header se prima riga contiene "cdpar"
  let start = 0;
  const h0 = String(raw[0]?.[0] ?? "").toLowerCase().trim();
  const h1 = String(raw[0]?.[1] ?? "").toLowerCase().trim();
  if (h0.includes("cdpar") || h1.includes("ricar")) start = 1;

  for (let i = start; i < raw.length; i++) {
    const r = raw[i];
    if (!r || (r[0] === "" && r[1] === "")) continue;
    const cdpar = pad6(String(r[0] ?? ""));
    const ricStr = String(r[1] ?? "").replace(",", ".").trim();
    const ric = parseFloat(ricStr);
    if (!cdpar) { warnings.push(`Riga ${i + 1}: cdpar mancante`); continue; }
    if (!Number.isFinite(ric)) { warnings.push(`Riga ${i + 1}: ricarico non numerico (${ricStr})`); continue; }
    if (seen.has(cdpar)) { warnings.push(`Riga ${i + 1}: cdpar ${cdpar} duplicato (uso primo)`); continue; }
    seen.add(cdpar);
    rows.push({ cdpar, ricarico: ric });
  }
  return { rows, warnings: warnings.slice(0, 20) };
}

const CHUNK = 500;

export function Query99Panel() {
  const [wcdls, setWcdls] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [rows, setRows] = useState<Row[]>([]);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [parsing, setParsing] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stats, setStats] = useState<Stats | null>(null);
  const [error, setError] = useState<string | null>(null);

  const canRun = useMemo(
    () => wcdls.trim().length > 0 && rows.length > 0 && !isRunning,
    [wcdls, rows, isRunning],
  );

  const handleFile = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    setFile(f);
    setRows([]);
    setWarnings([]);
    setStats(null);
    setError(null);
    setProgress(0);
    setParsing(true);
    try {
      const res = await parseFile(f);
      setRows(res.rows);
      setWarnings(res.warnings);
      toast({ title: "File letto", description: `${res.rows.length} righe valide` });
    } catch (e: any) {
      toast({ title: "Errore parsing", description: e?.message ?? "Errore", variant: "destructive" });
    } finally {
      setParsing(false);
    }
  };

  const reset = () => {
    setFile(null);
    setRows([]);
    setWarnings([]);
    setStats(null);
    setError(null);
    setProgress(0);
  };

  const run = async () => {
    setIsRunning(true);
    setError(null);
    setStats(null);
    setProgress(0);
    const agg: Stats = { total: 0, updated: 0, unchanged: 0, not_found: 0 };
    try {
      for (let i = 0; i < rows.length; i += CHUNK) {
        const chunk = rows.slice(i, i + CHUNK);
        const { data, error: err } = await supabase.rpc(
          "import_query99_ricarico" as any,
          { p_wcdls: wcdls.trim(), p_rows: chunk as any },
        );
        if (err) throw err;
        const r = (data ?? {}) as Stats;
        agg.total += r.total ?? 0;
        agg.updated += r.updated ?? 0;
        agg.unchanged += r.unchanged ?? 0;
        agg.not_found += r.not_found ?? 0;
        setProgress(Math.min(100, ((i + chunk.length) / rows.length) * 100));
        setStats({ ...agg });
      }
      setProgress(100);
      toast({ title: "Import completato", description: `${agg.updated} ricarichi aggiornati` });
    } catch (e: any) {
      console.error("[Q99] errore:", e);
      setError(e?.message ?? "Errore");
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="rounded-lg border bg-card p-4 space-y-2">
        <div className="flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Query 99 — Aggiustamento Ricarichi</h2>
          <Badge variant="secondary">PIM-only</Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          Aggiorna il campo <code>wsm01</code> (Ricarico) in <code>listini_vendita_criteri_prezzo</code>
          {" "}solo per gli articoli elencati nel file e per il listino indicato.
          Non inserisce righe nuove; non tocca articoli fuori elenco; non tocca altri campi.
        </p>
        <p className="text-xs text-muted-foreground">
          File: 2 colonne <code>cdpar</code> (6 cifre, padded auto) e <code>ricarico</code> (numerico, es. 35 o 35.5).
        </p>
      </div>

      <div className="rounded-lg border p-4 space-y-2">
        <Label htmlFor="q99-wcdls" className="text-sm font-medium">
          Listino di destinazione (<code>wcdls</code>)
        </Label>
        <Input
          id="q99-wcdls"
          value={wcdls}
          onChange={(e) => setWcdls(e.target.value)}
          placeholder="es. 001"
          disabled={isRunning}
          className="max-w-xs"
        />
        <p className="text-xs text-muted-foreground">
          Solo le righe di questo listino verranno aggiornate.
        </p>
      </div>

      <FileDropZone
        accept=".xlsx,.xls"
        multiple={false}
        onFiles={handleFile}
        label={file ? `${file.name} — ${(file.size / 1024).toFixed(1)} KB` : "Trascina XLSX (cdpar, ricarico) o clicca"}
        className="p-8"
        disabled={isRunning}
      />

      {parsing && <p className="text-sm text-muted-foreground">Lettura file…</p>}

      {warnings.length > 0 && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="text-xs">
            {warnings.join(" · ")}
          </AlertDescription>
        </Alert>
      )}

      {rows.length > 0 && !isRunning && !stats && (
        <>
          <div className="rounded-lg border p-4 flex flex-wrap items-center gap-3">
            <Badge>{rows.length} righe pronte</Badge>
            <span className="text-sm text-muted-foreground">
              Verrà aggiornato <code>wsm01</code> per ogni cdpar sul listino <strong>{wcdls || "—"}</strong>.
            </span>
            <Button onClick={run} disabled={!canRun} className="ml-auto">
              <Play className="mr-2 h-4 w-4" /> Avvia aggiornamento
            </Button>
          </div>

          <div className="rounded-lg border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs">cdpar</TableHead>
                  <TableHead className="text-xs">ricarico</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.slice(0, 20).map((r) => (
                  <TableRow key={r.cdpar}>
                    <TableCell className="text-xs font-mono">{r.cdpar}</TableCell>
                    <TableCell className="text-xs">{r.ricarico}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <p className="text-xs text-muted-foreground p-2">
              Anteprima prime 20 righe (totale {rows.length})
            </p>
          </div>
        </>
      )}

      {isRunning && (
        <div className="space-y-2">
          <Progress value={progress} />
          <p className="text-sm text-muted-foreground">
            Aggiornamento in corso… {Math.round(progress)}%
            {stats && (
              <> · {stats.updated} aggiornati · {stats.unchanged} invariati · {stats.not_found} non trovati</>
            )}
          </p>
        </div>
      )}

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {stats && !isRunning && !error && (
        <div className="rounded-lg border p-4 space-y-3">
          <h3 className="font-semibold">Aggiornamento completato</h3>
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary">{stats.total} totali</Badge>
            <Badge className="bg-blue-600">{stats.updated} aggiornati</Badge>
            <Badge variant="outline">{stats.unchanged} invariati</Badge>
            {stats.not_found > 0 && (
              <Badge variant="destructive">{stats.not_found} non trovati su listino {wcdls}</Badge>
            )}
          </div>
          <Button variant="outline" onClick={reset}>Nuovo aggiornamento</Button>
        </div>
      )}
    </div>
  );
}

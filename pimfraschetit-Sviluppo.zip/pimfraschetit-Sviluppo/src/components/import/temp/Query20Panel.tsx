import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertCircle, FileSpreadsheet, Play } from "lucide-react";
import { parseQuery20Xlsx, type Q20Row } from "@/lib/query20Parser";
import { useQuery20Import } from "@/hooks/useQuery20Import";
import { toast } from "@/hooks/use-toast";
import { useConfirm } from "@/components/ui/confirm-dialog";

const COLS: (keyof Q20Row)[] = [
  "wchfil","wdtcre","wdtdec","wdtvar","wnofil","wnotei",
  "worcre","worvar","wposst","wpospr","wprogr","wstato",
  "wutcre","wutvar",
];

export function Query20Panel() {
  const [file, setFile] = useState<File | null>(null);
  const [rows, setRows] = useState<Q20Row[]>([]);
  const [parsing, setParsing] = useState(false);
  const [warnings, setWarnings] = useState<string[]>([]);
  const { run, reset, isRunning, progress, stats, error } = useQuery20Import();
  const confirm = useConfirm();

  const handleFile = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    setFile(f);
    setRows([]);
    setWarnings([]);
    reset();
    setParsing(true);
    try {
      const res = await parseQuery20Xlsx(f);
      setRows(res.rows);
      setWarnings(res.warnings);
      toast({ title: "File letto", description: `${res.rows.length.toLocaleString()} cambi futuri trovati` });
    } catch (e: any) {
      toast({ title: "Errore parsing", description: e?.message ?? "Errore", variant: "destructive" });
    } finally {
      setParsing(false);
    }
  };

  const handleImport = async () => {
    if (rows.length === 0) return;
    const ok = await confirm({
      title: "Sostituzione cambi futuri",
      description: "Questo import elimina tutte le righe future esistenti in storico_assortimenti (wdtdec > oggi) e le sostituisce con quelle del file. Lo storico passato resta intatto. Procedere?",
      confirmText: "Procedi",
      cancelText: "Annulla",
      destructive: true,
    });
    if (!ok) return;
    run(rows);
  };

  return (
    <div className="space-y-6">
      <div className="rounded-lg border bg-card p-4 space-y-2">
        <div className="flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Query 20 — Storico Assortimenti (cambi futuri)</h2>
          <Badge variant="destructive">Replace future</Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          Carica l'estrazione XLSX della QUERY 20 (WANPAW1L0S, righe con <code>wdtdec &gt; oggi</code>).
          L'import <strong>elimina</strong> le righe future esistenti di <code>storico_assortimenti</code>
          e le sostituisce con quelle del file. Lo storico passato non viene toccato.
        </p>
        <p className="text-xs text-muted-foreground">
          Mapping per posizione (14 colonne): wchfil, wdtcre, wdtdec, wdtvar, wnofil, wnotei,
          worcre, worvar, wposst, wpospr, wprogr, wstato, wutcre, wutvar.
        </p>
      </div>

      <FileDropZone
        accept=".xlsx,.xls"
        multiple={false}
        onFiles={handleFile}
        label={file ? `${file.name} — ${(file.size / 1024 / 1024).toFixed(2)} MB` : "Trascina il file XLSX o clicca per selezionare"}
        className="p-8"
        disabled={isRunning}
      />

      {parsing && <p className="text-sm text-muted-foreground">Lettura file in corso…</p>}

      {warnings.length > 0 && (
        <Alert variant="default">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{warnings.join(" · ")}</AlertDescription>
        </Alert>
      )}

      {rows.length > 0 && !isRunning && !stats && (
        <>
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex flex-wrap items-center gap-3">
              <Badge>{rows.length.toLocaleString()} righe da caricare</Badge>
              <span className="text-sm text-muted-foreground">Delete future + insert (chunk da 2.000)</span>
            </div>
            <Button onClick={handleImport} disabled={isRunning} variant="destructive">
              <Play className="mr-2 h-4 w-4" /> Avvia import (sostituisce cambi futuri)
            </Button>
          </div>

          <div className="rounded-lg border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  {COLS.map(h => (
                    <TableHead key={h} className="text-xs whitespace-nowrap">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.slice(0, 8).map((r, i) => (
                  <TableRow key={i}>
                    {COLS.map(k => (
                      <TableCell key={k} className="text-xs whitespace-nowrap max-w-[200px] truncate">
                        {r[k] === null || r[k] === undefined ? "—" : String(r[k]).trim()}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <p className="text-xs text-muted-foreground p-2">Anteprima prime 8 righe (wchfil mostrato trimmato)</p>
          </div>
        </>
      )}

      {isRunning && (
        <div className="space-y-2">
          <Progress value={progress} />
          <p className="text-sm text-muted-foreground">
            Import in corso… {Math.round(progress)}%
            {stats && (
              <> · {stats.deleted.toLocaleString()} eliminati · {stats.inserted.toLocaleString()} inseriti</>
            )}
          </p>
        </div>
      )}

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {stats && !isRunning && !error && (
        <div className="rounded-lg border p-4 space-y-3">
          <h3 className="font-semibold">Import completato</h3>
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline">{stats.deleted.toLocaleString()} righe future eliminate</Badge>
            <Badge className="bg-green-600">{stats.inserted.toLocaleString()} righe inserite</Badge>
          </div>
          <Button variant="outline" onClick={() => { setFile(null); setRows([]); reset(); }}>
            Nuovo import
          </Button>
        </div>
      )}
    </div>
  );
}

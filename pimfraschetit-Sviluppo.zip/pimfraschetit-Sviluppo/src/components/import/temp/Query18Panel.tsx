import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertCircle, FileSpreadsheet, Play, PowerOff } from "lucide-react";
import { parseQuery18Xlsx, type Q18Row } from "@/lib/query18Parser";
import { useQuery18Import } from "@/hooks/useQuery18Import";
import { toast } from "@/hooks/use-toast";

const COLS: (keyof Q18Row)[] = ["cdfor", "rasf2", "rasfo"];

export function Query18Panel() {
  const [file, setFile] = useState<File | null>(null);
  const [rows, setRows] = useState<Q18Row[]>([]);
  const [parsing, setParsing] = useState(false);
  const [warnings, setWarnings] = useState<string[]>([]);
  const { run, deactivateMissing, reset, isRunning, progress, stats, error, deactivated } = useQuery18Import();

  const handleFile = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    setFile(f);
    setRows([]);
    setWarnings([]);
    reset();
    setParsing(true);
    try {
      const res = await parseQuery18Xlsx(f);
      setRows(res.rows);
      setWarnings(res.warnings);
      toast({ title: "File letto", description: `${res.rows.length.toLocaleString()} fornitori trovati` });
    } catch (e: any) {
      toast({ title: "Errore parsing", description: e?.message ?? "Errore", variant: "destructive" });
    } finally {
      setParsing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="rounded-lg border bg-card p-4 space-y-2">
        <div className="flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Query 18 — Archivio Fornitori</h2>
          <Badge variant="secondary">3 colonne</Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          Carica l'estrazione XLSX della QUERY 18 (fornitori con <code>ata19 ≠ 'A'</code>, ovvero non annullati).
          Inserisce nuovi codici, aggiorna ragione sociale e riattiva fornitori precedentemente disattivati.
        </p>
        <p className="text-xs text-muted-foreground">
          Mapping per posizione (3 colonne): cdfor, rasf2, rasfo.
          Target: <code>archivio_fornitori_fraschetti</code>. I campi PIM-only <code>buyer</code> e
          <code> demand_planner</code> non vengono mai modificati. L'azione "disattiva mancanti" marca come
          <code> is_active=false</code> i fornitori non presenti nel file.
        </p>
      </div>

      <FileDropZone
        accept=".xlsx,.xls"
        multiple={false}
        onFiles={handleFile}
        label={file ? `${file.name} — ${(file.size / 1024 / 1024).toFixed(2)} MB` : "Trascina il file XLSX o clicca per selezionare"}
        className="p-8"
        disabled={isRunning}
      />

      {parsing && <p className="text-sm text-muted-foreground">Lettura file in corso…</p>}

      {warnings.length > 0 && (
        <Alert variant="default">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{warnings.join(" · ")}</AlertDescription>
        </Alert>
      )}

      {rows.length > 0 && !isRunning && !stats && (
        <>
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex flex-wrap items-center gap-3">
              <Badge>{rows.length.toLocaleString()} fornitori da processare</Badge>
              <span className="text-sm text-muted-foreground">Upsert mirato (chunk da 1.000)</span>
            </div>
            <Button onClick={() => run(rows)} disabled={isRunning}>
              <Play className="mr-2 h-4 w-4" /> Avvia import
            </Button>
          </div>

          <div className="rounded-lg border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  {COLS.map(h => (
                    <TableHead key={h} className="text-xs whitespace-nowrap">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.slice(0, 8).map((r, i) => (
                  <TableRow key={i}>
                    {COLS.map(k => (
                      <TableCell key={k} className="text-xs whitespace-nowrap">{r[k] === null ? "—" : String(r[k])}</TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <p className="text-xs text-muted-foreground p-2">Anteprima prime 8 righe</p>
          </div>
        </>
      )}

      {isRunning && (
        <div className="space-y-2">
          <Progress value={progress} />
          <p className="text-sm text-muted-foreground">
            Import in corso… {Math.round(progress)}%
            {stats && (
              <> · {stats.inserted.toLocaleString()} nuovi · {stats.updated.toLocaleString()} aggiornati · {stats.unchanged.toLocaleString()} invariati</>
            )}
          </p>
        </div>
      )}

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {stats && !isRunning && !error && (
        <div className="rounded-lg border p-4 space-y-3">
          <h3 className="font-semibold">Import completato</h3>
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary">{stats.total.toLocaleString()} righe</Badge>
            <Badge className="bg-green-600">{stats.inserted.toLocaleString()} nuovi</Badge>
            <Badge className="bg-blue-600">{stats.updated.toLocaleString()} aggiornati</Badge>
            <Badge variant="outline">{stats.unchanged.toLocaleString()} invariati</Badge>
            {stats.reactivated > 0 && (
              <Badge className="bg-amber-600">{stats.reactivated.toLocaleString()} riattivati</Badge>
            )}
          </div>

          <div className="border-t pt-3 space-y-2">
            <p className="text-sm text-muted-foreground">
              Opzionale: disattiva i fornitori non presenti nell'estrazione (annullati in AS400).
              Non verranno cancellati, solo marcati <code>is_active=false</code>.
            </p>
            <Button variant="outline" onClick={() => deactivateMissing(rows)}>
              <PowerOff className="mr-2 h-4 w-4" /> Disattiva fornitori mancanti
            </Button>
            {deactivated !== null && (
              <p className="text-sm">
                <Badge variant="destructive">{deactivated.toLocaleString()} fornitori disattivati</Badge>
              </p>
            )}
          </div>

          <Button variant="outline" onClick={() => { setFile(null); setRows([]); reset(); }}>
            Nuovo import
          </Button>
        </div>
      )}
    </div>
  );
}

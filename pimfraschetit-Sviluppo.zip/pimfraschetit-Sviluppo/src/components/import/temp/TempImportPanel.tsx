import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Database } from "lucide-react";
import { Query01Panel } from "./Query01Panel";
import { Query02Panel } from "./Query02Panel";
import { Query03Panel } from "./Query03Panel";
import { Query04Panel } from "./Query04Panel";
import { Query05Panel } from "./Query05Panel";
import { Query06Panel } from "./Query06Panel";
import { Query07Panel } from "./Query07Panel";
import { Query08Panel } from "./Query08Panel";
import { Query09Panel } from "./Query09Panel";
import { Query10Panel } from "./Query10Panel";
import { Query11Panel } from "./Query11Panel";
import { Query12Panel } from "./Query12Panel";
import { Query13Panel } from "./Query13Panel";
import { Query14Panel } from "./Query14Panel";
import { Query15Panel } from "./Query15Panel";
import { Query16Panel } from "./Query16Panel";
import { Query17Panel } from "./Query17Panel";
import { Query18Panel } from "./Query18Panel";
import { Query19Panel } from "./Query19Panel";
import { Query20Panel } from "./Query20Panel";
import { Query99Panel } from "./Query99Panel";
import { CatalogoCartaPanel } from "./CatalogoCartaPanel";

interface QueryDef {
  id: string;
  label: string;
  table: string;
  panel: React.ComponentType;
}

const QUERIES: QueryDef[] = [
  {
    id: "query01",
    label: "Query 01 — Archivio Articoli Fraschetti",
    table: "archivio_articoli_fraschetti",
    panel: Query01Panel,
  },
  {
    id: "query02",
    label: "Query 02 — Anagrafica Articoli Fornitori",
    table: "archivio_anag_art_fornitore",
    panel: Query02Panel,
  },
  {
    id: "query03",
    label: "Query 03 — Archivio Codici a Barre",
    table: "archivio_codici_barre_fraschetti",
    panel: Query03Panel,
  },
  {
    id: "query04",
    label: "Query 04 — Archivio Listini / Cataloghi Fornitori",
    table: "archivio_listini_fraschetti",
    panel: Query04Panel,
  },
  {
    id: "query05",
    label: "Query 05 — Differenziale Cambio",
    table: "differenziale_cambio",
    panel: Query05Panel,
  },
  {
    id: "query06",
    label: "Query 06 — Tassi di Cambio",
    table: "tassi_di_cambio",
    panel: Query06Panel,
  },
  {
    id: "query07",
    label: "Query 07 — Listini di Vendita Campagne",
    table: "listini_vendita_campagne",
    panel: Query07Panel,
  },
  {
    id: "query08",
    label: "Query 08 — Listini di Vendita Criteri di Prezzo",
    table: "listini_vendita_criteri_prezzo",
    panel: Query08Panel,
  },
  {
    id: "query09",
    label: "Query 09 — Listini Definizione di Base",
    table: "listini_vendita_def_base",
    panel: Query09Panel,
  },
  {
    id: "query10",
    label: "Query 10 — Listini Vendita Dettagli",
    table: "listini_vendita_dettagli",
    panel: Query10Panel,
  },
  {
    id: "query11",
    label: "Query 11 — Listini di Vendita Testate",
    table: "listini_vendita_testate",
    panel: Query11Panel,
  },
  {
    id: "query12",
    label: "Query 12 — Prezzi in Attesa",
    table: "prezzi_in_attesa",
    panel: Query12Panel,
  },
  {
    id: "query13",
    label: "Query 13 — Promo Strutturata Campagne Associate",
    table: "promo_strutturate_campagne",
    panel: Query13Panel,
  },
  {
    id: "query14",
    label: "Query 14 — Promo Strutturata Condizioni",
    table: "promo_strutturate_condizioni",
    panel: Query14Panel,
  },
  {
    id: "query15",
    label: "Query 15 — Promo Strutturate Elementi",
    table: "promo_strutturate_elementi",
    panel: Query15Panel,
  },
  {
    id: "query16",
    label: "Query 16 — Promo Strutturate Testate",
    table: "promo_strutturate_testate",
    panel: Query16Panel,
  },
  {
    id: "query17",
    label: "Query 17 — Nomenclatura Combinata",
    table: "nomenclatura_combinata",
    panel: Query17Panel,
  },
  {
    id: "query18",
    label: "Query 18 — Archivio Fornitori",
    table: "archivio_fornitori_fraschetti",
    panel: Query18Panel,
  },
  {
    id: "query19",
    label: "Query 19 — Listini Vendita Condizioni",
    table: "listini_vendita_condizioni",
    panel: Query19Panel,
  },
  {
    id: "query20",
    label: "Query 20 — Storico Assortimenti (futuri)",
    table: "storico_assortimenti",
    panel: Query20Panel,
  },
  {
    id: "query99",
    label: "Query 99 — Aggiustamento Ricarichi",
    table: "listini_vendita_criteri_prezzo",
    panel: Query99Panel,
  },
  {
    id: "catalogo_carta",
    label: "Cataloghi Carta — Titolo/Dettaglio/Scheda",
    table: "archivio_articoli_fraschetti",
    panel: CatalogoCartaPanel,
  },
];

export function TempImportPanel() {
  const [selected, setSelected] = useState<string>(QUERIES[0].id);
  const current = QUERIES.find(q => q.id === selected) ?? QUERIES[0];
  const PanelComponent = current.panel;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr] gap-6">
      <aside className="space-y-2">
        <div className="flex items-center gap-2 px-2 py-1">
          <Database className="h-4 w-4 text-muted-foreground" />
          <span className="text-xs uppercase tracking-wider text-muted-foreground">Estrazioni disponibili</span>
        </div>
        {QUERIES.map(q => (
          <Button
            key={q.id}
            variant={q.id === selected ? "default" : "ghost"}
            className="w-full justify-start text-left h-auto py-2"
            onClick={() => setSelected(q.id)}
          >
            <div className="flex flex-col items-start">
              <span className="text-sm">{q.label}</span>
              <span className="text-[10px] text-muted-foreground font-mono">{q.table}</span>
            </div>
          </Button>
        ))}
        <div className="px-2 pt-4">
          <Badge variant="outline" className="text-[10px]">Altre query in arrivo</Badge>
        </div>
      </aside>

      <main>
        <PanelComponent />
      </main>
    </div>
  );
}

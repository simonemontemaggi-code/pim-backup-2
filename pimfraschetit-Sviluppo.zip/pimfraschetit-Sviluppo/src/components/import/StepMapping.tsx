import { useMemo } from "react";
import { Loader2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { TEMPLATES, type ImportType } from "@/lib/csvTemplates";

interface Props {
  csvHeaders: string[];
  csvPreview: Record<string, string>[];
  importType: ImportType;
  mapping: Record<string, string>;
  onMappingChange: (mapping: Record<string, string>) => void;
  onBack: () => void;
  onNext: () => void;
  isLoading?: boolean;
}

export function StepMapping({ csvHeaders, csvPreview, importType, mapping, onMappingChange, onBack, onNext, isLoading = false }: Props) {
  const tpl = TEMPLATES[importType];

  const unmappedRequired = useMemo(() => {
    const mappedFields = new Set(Object.values(mapping));
    return tpl.required.filter((f) => !mappedFields.has(f));
  }, [mapping, tpl.required]);

  const setField = (csvCol: string, dbField: string) => {
    const next = { ...mapping };
    // Remove previous mapping to this dbField
    for (const [k, v] of Object.entries(next)) {
      if (v === dbField) delete next[k];
    }
    if (dbField === "__skip__") {
      delete next[csvCol];
    } else {
      next[csvCol] = dbField;
    }
    onMappingChange(next);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-medium mb-1">Anteprima dati (prime 3 righe)</h3>
        <div className="overflow-x-auto border rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                {csvHeaders.map((h) => (
                  <TableHead key={h} className="text-xs whitespace-nowrap">{h}</TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {csvPreview.slice(0, 3).map((row, i) => (
                <TableRow key={i}>
                  {csvHeaders.map((h) => (
                    <TableCell key={h} className="text-xs whitespace-nowrap max-w-[200px] truncate">{row[h]}</TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-medium mb-3">Mappatura colonne</h3>
        {unmappedRequired.length > 0 && (
          <div className="mb-3 flex flex-wrap gap-1">
            <span className="text-xs text-destructive">Campi obbligatori mancanti:</span>
            {unmappedRequired.map((f) => (
              <Badge key={f} variant="destructive" className="text-xs">{f}</Badge>
            ))}
          </div>
        )}
        <div className="grid gap-2">
          {csvHeaders.map((csvCol) => (
            <div key={csvCol} className="flex items-center gap-3">
              <span className="text-sm font-mono w-40 truncate">{csvCol}</span>
              <span className="text-muted-foreground">→</span>
              <Select value={mapping[csvCol] ?? "__skip__"} onValueChange={(v) => setField(csvCol, v)}>
                <SelectTrigger className="w-52">
                  <SelectValue placeholder="Salta" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__skip__">— Salta —</SelectItem>
                  {tpl.headers.map((h) => (
                    <SelectItem key={h} value={h}>
                      {h} {tpl.required.includes(h) ? "*" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack} disabled={isLoading}>← Indietro</Button>
        <Button disabled={unmappedRequired.length > 0 || isLoading} onClick={onNext}>
          {isLoading ? (
            <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Validazione in corso…</>
          ) : (
            <>Avanti →</>
          )}
        </Button>
      </div>
    </div>
  );
}

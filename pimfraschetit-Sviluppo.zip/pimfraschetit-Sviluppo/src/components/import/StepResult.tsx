import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Download } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { downloadXlsx } from "@/lib/xlsxExport";

interface Props {
  progress: number;
  isRunning: boolean;
  stats: { created: number; updated: number; skipped: number; errors: number };
  reportRows: Record<string, string>[];
  phaseLabel?: string;
  importType?: string;
}

const MAX_INLINE = 20;

export function StepResult({ progress, isRunning, stats, reportRows, phaseLabel, importType }: Props) {
  const navigate = useNavigate();

  const errorRows = reportRows.filter((r) => r.import_result === "error");
  const isSupplierImport = importType === "fornitori_buyer_dp";
  const codeField = importType === "articoli_attributi_dettaglio" ? "sku" : "cdpar";

  const downloadReport = () => {
    downloadXlsx(
      `import_report_${new Date().toISOString().slice(0, 10)}.xlsx`,
      reportRows,
      { sheetName: "Report" },
    );
  };

  return (
    <div className="space-y-6">
      {isRunning ? (
        <>
          <h3 className="text-sm font-medium">
            {phaseLabel || (progress < 10 ? "Caricamento articoli esistenti..." : "Importazione in corso...")}
          </h3>
          <Progress value={progress} className="h-3" />
          <p className="text-sm text-muted-foreground">{Math.round(progress)}%</p>
        </>
      ) : (
        <>
          <h3 className="text-lg font-semibold">Import completato ✅</h3>
          <div className="flex gap-3 flex-wrap">
            <Badge className="bg-green-600">{stats.created} creati</Badge>
            <Badge variant="secondary">{stats.updated} aggiornati</Badge>
            <Badge variant="destructive">{stats.errors} errori</Badge>
            <Badge variant="outline">{stats.skipped} saltati</Badge>
          </div>

          {errorRows.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-semibold text-destructive">Dettaglio errori</h4>
              <div className="border rounded-md overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-muted">
                    <tr>
                      <th className="text-left px-3 py-2 font-medium w-40">{codeField}</th>
                      <th className="text-left px-3 py-2 font-medium">Errore</th>
                    </tr>
                  </thead>
                  <tbody>
                    {errorRows.slice(0, MAX_INLINE).map((r, i) => (
                      <tr key={i} className="border-t">
                        <td className="px-3 py-2 font-mono text-xs">{String(r[codeField] ?? r.cdpar ?? r.sku ?? "").trim() || "—"}</td>
                        <td className="px-3 py-2 text-destructive">{r.error_message || "Errore sconosciuto"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {errorRows.length > MAX_INLINE && (
                  <div className="px-3 py-2 text-xs text-muted-foreground bg-muted/50 border-t">
                    …e altri {errorRows.length - MAX_INLINE} errori. Scarica il report per l'elenco completo.
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="flex gap-3">
            <Button variant="outline" onClick={downloadReport}>
              <Download className="mr-2 h-4 w-4" /> Scarica report
            </Button>
            <Button onClick={() => navigate(isSupplierImport ? "/pim/suppliers" : "/pim/articles")}>
              {isSupplierImport ? "Vai ai fornitori" : "Vai agli articoli"}
            </Button>
          </div>
        </>
      )}
    </div>
  );
}

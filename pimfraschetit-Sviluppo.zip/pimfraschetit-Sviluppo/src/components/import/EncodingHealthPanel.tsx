import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Download, RefreshCw, CheckCircle2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { useState } from "react";

const REPL = "\uFFFD"; // U+FFFD REPLACEMENT CHARACTER

interface CorruptedRow {
  cdpar: string;
  depar: string | null;
  attr_key: string;
  value: string;
}

/** Estrae dalle `attributes` jsonb tutte le coppie (attr_key, value) contenenti U+FFFD. */
function extractCorruptedFields(attributes: any): { key: string; value: string }[] {
  const out: { key: string; value: string }[] = [];
  const gamma = attributes?.gamma_attrs;
  if (gamma && typeof gamma === "object") {
    for (const [k, v] of Object.entries<any>(gamma)) {
      const val = v?.value;
      if (typeof val === "string" && val.includes(REPL)) out.push({ key: k, value: val });
    }
  }
  // Fallback: scan generico su qualunque stringa
  const seen = new Set<string>();
  const walk = (node: any, path: string) => {
    if (node == null) return;
    if (typeof node === "string") {
      if (node.includes(REPL) && !seen.has(path)) {
        seen.add(path);
        out.push({ key: path, value: node });
      }
      return;
    }
    if (typeof node === "object") {
      for (const [k, v] of Object.entries(node)) walk(v, path ? `${path}.${k}` : k);
    }
  };
  walk(attributes, "");
  // Dedup su key
  const dedup = new Map<string, string>();
  for (const r of out) if (!dedup.has(r.key)) dedup.set(r.key, r.value);
  return Array.from(dedup, ([key, value]) => ({ key, value }));
}

export function EncodingHealthPanel() {
  const [downloading, setDownloading] = useState(false);

  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ["encoding-health-count"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("pim_count_articoli_attributi_corrotti" as any);
      if (error) throw error;
      return { count: (data as number) ?? 0 };
    },
    staleTime: 30_000,
  });

  const downloadCsv = async () => {
    setDownloading(true);
    try {
      const { data: rows, error } = await supabase.rpc("pim_list_articoli_attributi_corrotti" as any);
      if (error) throw error;
      const out: CorruptedRow[] = [];
      for (const r of (rows as any[]) ?? []) {
        const attrs = r.attributes;
        if (!attrs) continue;
        const fields = extractCorruptedFields(attrs);
        for (const f of fields) {
          out.push({
            cdpar: String(r.cdpar ?? "").trim(),
            depar: r.depar ?? null,
            attr_key: f.key,
            value: f.value,
          });
        }
      }
      if (out.length === 0) {
        toast({ title: "Nessuna riga corrotta trovata", description: "I dati sono puliti." });
        return;
      }
      const esc = (v: any) => {
        const s = String(v ?? "");
        return /[",;\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
      };
      const header = "cdpar;depar;attr_key;valore_corrotto\n";
      const body = out.map((r) => [r.cdpar, r.depar, r.attr_key, r.value].map(esc).join(";")).join("\n");
      const csv = "\uFEFF" + header + body;
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `articoli_attributi_corrotti_${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      toast({ title: `Scaricate ${out.length} righe corrotte`, description: `${new Set(out.map((r) => r.cdpar)).size} articoli distinti` });
    } catch (e: any) {
      toast({ title: "Errore export", description: e?.message ?? String(e), variant: "destructive" });
    } finally {
      setDownloading(false);
    }
  };

  const count = data?.count ?? 0;

  return (
    <div className="border rounded-lg p-4 space-y-3 bg-card">
      <div className="flex items-start gap-3">
        <div className={`rounded-full p-2 ${count > 0 ? "bg-destructive/10 text-destructive" : "bg-emerald-500/10 text-emerald-600"}`}>
          {count > 0 ? <AlertTriangle className="h-5 w-5" /> : <CheckCircle2 className="h-5 w-5" />}
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-sm">Controllo qualità attributi articoli</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            Verifica gli articoli con caratteri corrotti (<code className="font-mono px-1 rounded bg-muted">{REPL}</code>) nei campi{" "}
            <code className="font-mono">attributes</code>. Corruzione tipica: file CSV aperto/risalvato in Excel con encoding sbagliato,
            i caratteri accentati (à, è, ì, ò, ù, °, €) diventano <code className="font-mono">{REPL}</code> in modo <strong>irreversibile</strong>.
            Per ripristinarli serve ri-importare il CSV sorgente in UTF-8.
          </p>
        </div>
      </div>

      <div className="flex items-center gap-3 flex-wrap">
        {isLoading ? (
          <Badge variant="outline">Conteggio in corso…</Badge>
        ) : (
          <Badge variant={count > 0 ? "destructive" : "outline"} className="text-sm">
            {count.toLocaleString("it-IT")} articol{count === 1 ? "o" : "i"} con attributi corrotti
          </Badge>
        )}
        <Button variant="outline" size="sm" onClick={() => refetch()} disabled={isFetching}>
          <RefreshCw className={`h-3.5 w-3.5 mr-1 ${isFetching ? "animate-spin" : ""}`} />
          Ricalcola
        </Button>
        {count > 0 && (
          <Button size="sm" onClick={downloadCsv} disabled={downloading}>
            <Download className="h-3.5 w-3.5 mr-1" />
            {downloading ? "Preparazione…" : "Scarica lista CSV"}
          </Button>
        )}
      </div>

      {count > 0 && (
        <p className="text-[11px] text-muted-foreground border-t pt-2">
          <strong>Come correggere:</strong> scarica la lista, apri il CSV sorgente originale (quello con i caratteri corretti),
          filtra le righe indicate, salva in <strong>CSV UTF-8</strong> e ri-importa dalla tab "Import CSV" con il template
          "Articoli — Attributi Dettaglio". Il decoder attuale blocca automaticamente i file che contengono già{" "}
          <code className="font-mono">{REPL}</code>.
        </p>
      )}
    </div>
  );
}

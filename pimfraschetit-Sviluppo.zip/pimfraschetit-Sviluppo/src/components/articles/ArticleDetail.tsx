import { useEffect, useRef, useState, useMemo, useCallback, KeyboardEvent } from "react";
import { useSearchParams } from "react-router-dom";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useForm } from "react-hook-form";
import { useArticle } from "@/hooks/useArticles";
import { usePermissions } from "@/lib/permissions";
import { useAuth } from "@/contexts/AuthContext";
import { useSaveArticle } from "@/hooks/useSaveArticle";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Save, X, Plus, Trash2 } from "lucide-react";
import { TabPriceLists } from "./tabs/TabPriceLists";
import { TabBarcodes } from "./tabs/TabBarcodes";
import { TabPurchase } from "./tabs/TabPurchase";
import { TabMedia } from "./tabs/TabMedia";
import { TabSync } from "./tabs/TabSync";
import { TabSalesPriceCriteria } from "./tabs/TabSalesPriceCriteria";
import { TabInventory } from "./tabs/TabInventory";
import { LookupManager } from "./LookupManager";
import { LookupSelect } from "./LookupSelect";
import { GammaAttributeFields } from "./GammaAttributeFields";
import { AssortmentStatusPanel } from "./AssortmentStatusPanel";
import { VariantiCollegateTable } from "./VariantiCollegateTable";
import { AiMarketingPanel, AiFieldButton } from "@/components/ai/AiMarketingPanel";
import { useInsertAssortmentHistory, useAssortmentStatus } from "@/hooks/useAssortmentHistory";
import { todayAs400 } from "@/lib/dateUtils";
import { ValidatedInput } from "./ValidatedInput";
import { FIELD_RULES, validateAll } from "@/lib/fieldValidation";
import { toast } from "@/hooks/use-toast";
import { useOnlineAssortments, computeIsB2bOnline, b2bValueToMode, b2bModeToValue, type B2bOverrideMode } from "@/hooks/useOnlineAssortments";

/* ── Field definitions ─────────────────────────────────────────── */

const REGISTRY_FIELDS: { name: string; label: string; readOnly?: boolean; lookup?: string; parentField?: string; labelOnly?: boolean; pimOnly?: boolean; computed?: boolean }[] = [
  { name: "cdpar", label: "Codice Parte", readOnly: true },
  { name: "cod_padre", label: "Cod. Padre", pimOnly: true },
  { name: "depar", label: "Descrizione" },
  { name: "wdeag", label: "Estensione Descrizione" },
  { name: "clas2", label: "Brand", lookup: "clas2" },
  { name: "nmdis", label: "Linea Brand", lookup: "linea_brand", parentField: "clas2", labelOnly: true, pimOnly: true },
  { name: "clmer", label: "Settore", lookup: "clmer" },
  { name: "reparto", label: "Reparto", lookup: "reparto", parentField: "clmer", labelOnly: true, pimOnly: true },
  { name: "gamma", label: "Gamma", lookup: "gamma", parentField: "reparto", labelOnly: true, pimOnly: true },
  { name: "lipro", label: "Linea Prodotto" },
  { name: "wcdst", label: "Classe Trasporto", lookup: "wcdst" },
  { name: "cdst1", label: "Codice Statistico 1", readOnly: true },
  { name: "clas1", label: "Classificazione 1", readOnly: true },
  { name: "cdiva", label: "Codice IVA", lookup: "cdiva" },
  { name: "pcfor", label: "Fornitore Principale" },
  { name: "_rasfo", label: "Ragione Sociale", readOnly: true, computed: true },
  { name: "buyer", label: "Buyer", lookup: "buyer", pimOnly: true },
  { name: "demand_planner", label: "Demand Planner", lookup: "demand_planner", pimOnly: true },
  { name: "wfuas", label: "Assortimento", lookup: "wfuas" },
  { name: "wstag", label: "Stagionalità", lookup: "wstag" },
];

const UM_FORNITORE_FIELDS: { name: string; label: string; type?: string; supplierField?: boolean; selectOptions?: { label: string; value: string }[] }[] = [
  { name: "umord", label: "UM Fornitore", supplierField: true, selectOptions: [
    { label: "—", value: "" },
    { label: "PZ", value: "PZ" }, { label: "CF", value: "CF" }, { label: "CT", value: "CT" },
    { label: "PL", value: "PL" }, { label: "XC", value: "XC" }, { label: "RT", value: "RT" },
    { label: "PA", value: "PA" }, { label: "MT", value: "MT" }, { label: "BL", value: "BL" },
    { label: "KG", value: "KG" }, { label: "CP", value: "CP" }, { label: "SC", value: "SC" },
    { label: "SR", value: "SR" }, { label: "MQ", value: "MQ" }, { label: "BB", value: "BB" },
    { label: "FG", value: "FG" }, { label: "DE", value: "DE" }, { label: "DZ", value: "DZ" },
    { label: "TN", value: "TN" }, { label: "XM", value: "XM" },
  ] },
  { name: "umfaf", label: "Fattore Conv.", type: "number", supplierField: true },
];

const UM_STOCCAGGIO_FIELDS: { name: string; label: string; type?: string; lookup?: string }[] = [
  { name: "unmis", label: "UM Stoccaggio", lookup: "unmis" },
  { name: "umfat", label: "Fattore Conv.", type: "number" },
];

const UM_VENDITA_FIELDS: { name: string; label: string; type?: string; lookup?: string; readOnly?: boolean; mirrorField?: string; selectOptions?: { label: string; value: string }[] }[] = [
  { name: "umalt", label: "UM Vendita", lookup: "umalt" },
  { name: "wfcs1", label: "Fattore Conv.", type: "number" },
  { name: "wvvii", label: "Apribilità", selectOptions: [
    { label: "NON APRIBILE", value: "" },
    { label: "APRIBILE", value: "N" },
  ] },
  { name: "untec", label: "UM Tecnica", lookup: "untec" },
  { name: "umfaa", label: "Fatt. Conv. UM Imballo", type: "number" },
];

const OTHER_UNITS_FIELDS: { name: string; label: string; type?: string; lookup?: string; selectOptions?: { label: string; value: string }[] }[] = [
  { name: "wfc2x", label: "Imballo di vendita", type: "number" },
  { name: "wclve", label: "Classe di Vendita", lookup: "wclve" },
  { name: "wfcvr", label: "Variabile SI / NO", selectOptions: [{ label: "NO", value: "N" }] },
];

const ALL_UM_FIELDS = [...UM_FORNITORE_FIELDS, ...UM_STOCCAGGIO_FIELDS, ...UM_VENDITA_FIELDS, ...OTHER_UNITS_FIELDS];

// PIM-only fields stored inside attributes jsonb
const PIM_ATTRIBUTE_FIELDS = ["reparto", "gamma", "buyer", "demand_planner"];

const ALL_FLAT_FIELDS = [
  ...REGISTRY_FIELDS.filter(f => !f.computed).map((f) => f.name),
  ...ALL_UM_FIELDS.map((f) => f.name),
  "b2b_product_title",
  "descrizione_variante",
  "b2b_product_description",
  "description_ecommerce",
  "seo_title",
  "seo_description",
  "tags",
  "attributes",
  "b2b_online_active",
  "master_pack",
  "catalogo_carta_titolo",
  "catalogo_carta_dettaglio",
  "catalogo_carta_scheda",
];

/* ── Component ─────────────────────────────────────────────────── */

interface Props {
  cdpar: string;
  onDirtyChange?: (dirty: boolean, isPending: boolean, hasErrors?: boolean, errors?: Record<string, string>) => void;
}

export function ArticleDetail({ cdpar, onDirtyChange }: Props) {
  const { data: article, isLoading } = useArticle(cdpar);
  const { sectionVisible, can, canField, fieldVisible } = usePermissions();
  const { role } = useAuth();

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!article) {
    return <div className="p-6 text-muted-foreground">Articolo non trovato.</div>;
  }

  return <ArticleForm article={article} sectionVisible={sectionVisible} can={can} canField={canField} fieldVisible={fieldVisible} isAdmin={role === "admin"} onDirtyChange={onDirtyChange} />;
}

/* ── Main Form ─────────────────────────────────────────────────── */

function ArticleForm({
  article,
  sectionVisible,
  can,
  canField,
  fieldVisible,
  isAdmin,
  onDirtyChange,
}: {
  article: Record<string, any>;
  sectionVisible: (s: any) => boolean;
  can: (action: "read" | "write", section: any) => boolean;
  canField: (action: "read" | "write", section: any, fieldKey: string) => boolean;
  fieldVisible: (section: any, fieldKey: string) => boolean;
  isAdmin: boolean;
  onDirtyChange?: (dirty: boolean, isPending: boolean, hasErrors?: boolean, errors?: Record<string, string>) => void;
}) {
  const canWriteRegistry = can("write", "articles_registry");
  const canWriteLogistics = can("write", "articles_units");
  const canWriteMarketing = can("write", "articles_marketing");
  const qc = useQueryClient();

  // Prefetch tab data so switching is instant
  // NOTE: master table (archivio_articoli_fraschetti) stores cdpar PADDED to 15 chars,
  // but all auxiliary tables (fornitore, listini, media, barcodes...) use the TRIMMED value.
  useEffect(() => {
    const cdpar = article.cdpar;
    const cdparKey = (cdpar ?? "").trim();
    qc.prefetchQuery({
      queryKey: ["purchase_section", cdparKey],
      queryFn: async () => {
        const { data, error } = await supabase
          .from("archivio_anag_art_fornitore")
          .select("*")
          .eq("cdpar", cdparKey)
          .order("cdfor", { ascending: true });
        if (error) throw error;
        return { suppliers: (data ?? []) as Record<string, any>[] };
      },
      staleTime: 5 * 60 * 1000,
    });
    qc.prefetchQuery({
      queryKey: ["price_lists", cdparKey],
      queryFn: async () => {
        const { data, error } = await supabase
          .from("archivio_listini_fraschetti")
          .select("id,cdpar,cdfor,rifli,dtvai,dtvaf,cdval,wprsc,prsc1,wscfa,wscfb,wscfc,wscfd,wscfe,wmasc,wfcas,wcpfa,wcpfb,wcpfc,wuord,wusto")
          .eq("cdpar", cdparKey)
          .order("dtvai", { ascending: false });
        if (error) throw error;
        return data ?? [];
      },
      staleTime: 5 * 60 * 1000,
    });
    // Prefetch sales price criteria
    qc.fetchQuery({
      queryKey: ["app_settings", "primary_price_list"],
      queryFn: async () => {
        const { data, error } = await supabase
          .from("app_settings")
          .select("setting_value")
          .eq("setting_key", "primary_price_list")
          .maybeSingle();
        if (error) throw error;
        if (!data?.setting_value) return null;
        return typeof data.setting_value === "string" ? data.setting_value : null;
      },
      staleTime: 300_000,
    }).then((pl) => {
      if (pl) {
        qc.prefetchQuery({
          queryKey: ["sales_price_criteria", cdparKey, pl],
          queryFn: async () => {
            const cdparPadded = cdparKey.padEnd(15, " ");
            const { data, error } = await supabase
              .from("listini_vendita_criteri_prezzo")
              .select("id,wcdls,wcdcv,wcdcl,wcdpa,wnrsc,wsm01,wsm02")
              .in("wcdpa", [cdparKey, cdparPadded])
              .order("wcdls", { ascending: true });
            if (error) throw error;
            return data ?? [];
          },
          staleTime: 5 * 60 * 1000,
        });
      }
    });
    // Prefetch barcodes (try both padded and zero-stripped variants for safety)
    const noLeadingZeros = cdparKey.replace(/^0+/, '') || '0';
    qc.prefetchQuery({
      queryKey: ["barcodes", cdparKey],
      queryFn: async () => {
        const { data, error } = await supabase
          .from("archivio_codici_barre_fraschetti")
          .select("*")
          .or(`wcdpa.eq.${cdparKey},wcdpa.eq.${noLeadingZeros}`)
          .order("wcpba", { ascending: true });
        if (error) throw error;
        return (data ?? []) as Record<string, any>[];
      },
      staleTime: 5 * 60 * 1000,
    });
  }, [article.cdpar, qc]);

  // Extract PIM attribute fields from attributes jsonb for form defaults
  const articleAttrs = (article.attributes ?? {}) as Record<string, any>;
  const defaults: Record<string, any> = {};
  ALL_FLAT_FIELDS.forEach((f) => {
    if (PIM_ATTRIBUTE_FIELDS.includes(f)) {
      defaults[f] = articleAttrs[f] ?? "";
    } else if (f === "b2b_online_active") {
      defaults[f] = (article[f] ?? null) as boolean | null;
    } else {
      defaults[f] = article[f] ?? (f === "tags" ? [] : f === "attributes" ? {} : "");
    }
  });
  defaults.attributes = article.attributes ?? {};

  const { register, handleSubmit, watch, setValue, getValues, formState: { isDirty }, reset } = useForm({
    defaultValues: defaults,
  });

  // Centralized: apply AI-generated tags merging with current form value
  const applyAiTags = useCallback((incoming: string[] | string | unknown) => {
    const arr = Array.isArray(incoming) ? incoming : [];
    const current = (getValues("tags") ?? []) as string[];
    const normalized = arr
      .map((t) => String(t).toLowerCase().trim())
      .filter(Boolean);
    const merged = Array.from(new Set([...current, ...normalized]));
    setValue("tags", merged, { shouldDirty: true, shouldTouch: true, shouldValidate: true });
  }, [getValues, setValue]);

  // Reset when article changes (navigation)
  useEffect(() => {
    const attrs = (article.attributes ?? {}) as Record<string, any>;
    const newDefaults: Record<string, any> = {};
    ALL_FLAT_FIELDS.forEach((f) => {
      if (PIM_ATTRIBUTE_FIELDS.includes(f)) {
        newDefaults[f] = attrs[f] ?? "";
      } else if (f === "b2b_online_active") {
        newDefaults[f] = (article[f] ?? null) as boolean | null;
      } else {
        newDefaults[f] = article[f] ?? (f === "tags" ? [] : f === "attributes" ? {} : "");
      }
    });
    newDefaults.attributes = article.attributes ?? {};
    reset(newDefaults);
    setAssortmentEffectiveDate("");
  }, [article.cdpar]);

  // Fetch primary supplier data for supplier-sourced fields (umord, umfaf)
  // Supplier-sourced editable fields (umord, umfaf)
  const primarySupplierRaw = watch("pcfor");
  const primarySupplier = (primarySupplierRaw ?? "").trim();
  const cdparTrimmed = (article.cdpar ?? "").trim();
  const { data: supplierData } = useQuery({
    queryKey: ["primary_supplier", cdparTrimmed, primarySupplier],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("archivio_anag_art_fornitore")
        .select("umord,umfaf")
        .eq("cdpar", cdparTrimmed)
        .eq("cdfor", primarySupplier)
        .maybeSingle();
      if (error) throw error;
      return data as Record<string, any> | null;
    },
    enabled: !!primarySupplier,
    staleTime: 5 * 60 * 1000,
  });

  // Fetch supplier ragione sociale
  const { data: supplierName } = useQuery({
    queryKey: ["supplier_name", primarySupplier],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("archivio_fornitori_fraschetti")
        .select("rasfo")
        .eq("cdfor", primarySupplier)
        .maybeSingle();
      if (error) throw error;
      return data?.rasfo ?? "";
    },
    enabled: !!primarySupplier,
    staleTime: 10 * 60 * 1000,
  });

  const [supplierEdits, setSupplierEdits] = useState<Record<string, any>>({});
  const supplierDirty = Object.keys(supplierEdits).length > 0;

  // Reset supplier edits when supplier data changes
  useEffect(() => {
    setSupplierEdits({});
  }, [supplierData]);

  const getSupplierValue = (field: string) => {
    if (field in supplierEdits) return supplierEdits[field];
    return supplierData?.[field] ?? "";
  };

  const setSupplierValue = (field: string, value: any) => {
    setSupplierEdits((prev) => ({ ...prev, [field]: value }));
  };

  const formRef = useRef<HTMLFormElement>(null);
  useEffect(() => {
    const handler = () => formRef.current?.requestSubmit();
    document.addEventListener("pim:save", handler);
    return () => document.removeEventListener("pim:save", handler);
  }, []);

  const mutation = useSaveArticle({
    table: "archivio_articoli_fraschetti",
    recordId: article.cdpar,
    oldValues: article,
  });
  const insertAssortmentHistory = useInsertAssortmentHistory();
  const { data: assortmentStatus } = useAssortmentStatus(article.cdpar);

  // Effective date (AAAAMMGG) for the assortment status change, set when wfuas is modified
  const [assortmentEffectiveDate, setAssortmentEffectiveDate] = useState<string>("");
  // Fonte di verità unica per lo stato attuale: archivio_articoli_fraschetti.wfuas
  // (è la stessa che alimenta la lista articoli e la logica B2B).
  // Lo `storico_assortimenti` viene usato solo per cronologia e per le modifiche
  // future pianificate, NON per sovrascrivere il valore attuale.
  const rawWfuas = (article.wfuas ?? "") as string;
  const originalWfuas = rawWfuas;
  const currentWfuas = (watch("wfuas") ?? "") as string;
  const wfuasChanged = currentWfuas !== originalWfuas;

  // Field-level validation errors (managed by ValidatedInput)
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [submitAttempted, setSubmitAttempted] = useState(false);
  const handleValidationChange = useCallback((name: string, error: string | null) => {
    setFieldErrors((prev) => {
      if (error) {
        if (prev[name] === error) return prev;
        return { ...prev, [name]: error };
      }
      if (!(name in prev)) return prev;
      const { [name]: _, ...rest } = prev;
      return rest;
    });
  }, []);
  const hasErrors = Object.keys(fieldErrors).length > 0;

  // Notify parent of dirty/pending state
  useEffect(() => {
    onDirtyChange?.(isDirty || supplierDirty, mutation.isPending, hasErrors, fieldErrors);
  }, [isDirty, supplierDirty, mutation.isPending, hasErrors, fieldErrors, onDirtyChange]);

  const onSubmit = async (values: Record<string, any>) => {
    setSubmitAttempted(true);
    // Final validation pass on registered fields
    const finalErrors = validateAll(values);
    if (Object.keys(finalErrors).length > 0) {
      setFieldErrors((prev) => ({ ...prev, ...finalErrors }));
      const first = Object.values(finalErrors)[0];
      toast({ title: "Errori di validazione", description: first, variant: "destructive" });
      return;
    }
    // Clean numeric fields
    ALL_UM_FIELDS.forEach((f) => {
      if (f.type === "number" && values[f.name] === "") {
        values[f.name] = null;
      }
    });
    // Normalize cod_padre: pad with leading zeros to 6 digits, null if empty
    if ("cod_padre" in values) {
      const cp = String(values.cod_padre ?? "").trim();
      if (!cp) {
        values.cod_padre = null;
      } else if (/^\d{1,6}$/.test(cp)) {
        values.cod_padre = cp.padStart(6, "0");
      } else {
        toast({ title: "Cod. Padre non valido", description: "Deve essere numerico (max 6 cifre)", variant: "destructive" });
        return;
      }
    }
    // Merge PIM-only fields into attributes jsonb
    const attrs = { ...(values.attributes ?? {}) };
    const pimSnapshot: Record<string, any> = {};
    PIM_ATTRIBUTE_FIELDS.forEach((f) => {
      if (values[f] !== undefined) {
        attrs[f] = values[f] || null;
        pimSnapshot[f] = values[f]; // keep for reset
        delete values[f]; // remove from top-level to avoid saving as column
      }
    });
    values.attributes = attrs;

    // Handle assortment status change → insert into storico_assortimenti (append-only log)
    if (wfuasChanged && assortmentEffectiveDate) {
      try {
        await insertAssortmentHistory.mutateAsync({
          cdpar: article.cdpar,
          wstato: currentWfuas,
          wdtdec: assortmentEffectiveDate,
          maxProgr: assortmentStatus?.maxProgr ?? 0,
        });
      } catch (e) {
        console.error("Failed to insert storico_assortimenti", e);
      }
      // If effective date is in the future, do NOT update wfuas on the article yet.
      // AS400 will activate the new status on wdtdec — keep the raw DB value untouched.
      if (assortmentEffectiveDate > todayAs400()) {
        values.wfuas = rawWfuas;
      }
    }

    // Save supplier edits if any
    if (supplierDirty && primarySupplier) {
      const cleaned = { ...supplierEdits };
      UM_FORNITORE_FIELDS.forEach((f) => {
        if (f.supplierField && f.type === "number" && cleaned[f.name] === "") {
          cleaned[f.name] = null;
        }
      });
      supabase
        .from("archivio_anag_art_fornitore")
        .update(cleaned as any)
        .eq("cdpar", cdparTrimmed)
        .eq("cdfor", primarySupplier)
        .then(() => {
          // Export AS400 JSON for supplier-side change
          import("@/lib/as400Export").then(({ exportAs400Change }) => {
            exportAs400Change({
              record: article.cdpar,
              table: "archivio_anag_art_fornitore",
              change: {
                operation: "update",
                key: { cdpar: cdparTrimmed, cdfor: primarySupplier },
                fields: cleaned,
              },
              filenamePrefix: "as400_fornitore",
            });
          });
          setSupplierEdits({});
          qc.invalidateQueries({ queryKey: ["primary_supplier", cdparTrimmed, primarySupplier] });
        });
    }

    mutation.mutate(values, {
      onSuccess: () => {
        // Restore PIM fields at top-level for form state after save
        const resetValues = { ...values, ...pimSnapshot };
        reset(resetValues);
        setAssortmentEffectiveDate("");
      },
    });
  };

  // Marketing state
  const tags = (watch("tags") ?? []) as string[];
  // Filter out PIM-managed fields from the generic attributes display
  const rawAttributes = (watch("attributes") ?? {}) as Record<string, string>;
  const attributes = useMemo(() => {
    const filtered: Record<string, string> = {};
    for (const [key, val] of Object.entries(rawAttributes)) {
      if (!PIM_ATTRIBUTE_FIELDS.includes(key)) {
        filtered[key] = val;
      }
    }
    return filtered;
  }, [rawAttributes]);
  const [tagInput, setTagInput] = useState("");
  const [tagSuggestOpen, setTagSuggestOpen] = useState(false);
  const [highlightIdx, setHighlightIdx] = useState(0);
  const trimmedTagInput = tagInput.trim().toLowerCase();
  const { data: tagSuggestions = [] } = useQuery({
    queryKey: ["tag-suggestions", trimmedTagInput],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("search_article_tags", { q: trimmedTagInput, lim: 10 });
      if (error) throw error;
      return (data ?? []) as { tag: string; usage_count: number }[];
    },
    enabled: trimmedTagInput.length >= 3,
    staleTime: 30_000,
  });
  const filteredSuggestions = tagSuggestions.filter((s) => !tags.includes(s.tag));

  const addTag = (raw: string) => {
    const v = raw.trim().toLowerCase();
    if (!v) return;
    if (!tags.includes(v)) {
      setValue("tags", [...tags, v], { shouldDirty: true });
    }
    setTagInput("");
    setTagSuggestOpen(false);
    setHighlightIdx(0);
  };
  const handleTagKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (tagSuggestOpen && filteredSuggestions.length > 0) {
      if (e.key === "ArrowDown") { e.preventDefault(); setHighlightIdx((i) => Math.min(i + 1, filteredSuggestions.length - 1)); return; }
      if (e.key === "ArrowUp") { e.preventDefault(); setHighlightIdx((i) => Math.max(i - 1, 0)); return; }
      if (e.key === "Enter") {
        e.preventDefault();
        addTag(filteredSuggestions[highlightIdx]?.tag ?? tagInput);
        return;
      }
      if (e.key === "Escape") { setTagSuggestOpen(false); return; }
    }
    if (e.key === "Enter" && tagInput.trim()) {
      e.preventDefault();
      addTag(tagInput);
    }
  };
  const removeTag = (tag: string) => setValue("tags", tags.filter((t) => t !== tag), { shouldDirty: true });

  // Build visible tabs
  type TabDef = { id: string; label: string; visible: boolean };
  const tabDefs: TabDef[] = [
    { id: "anagrafica", label: "Anagrafica", visible: true },
    { id: "codici-barre", label: "Codici a Barre", visible: sectionVisible("articles_registry") },
    { id: "acquisto", label: "Acquisto", visible: sectionVisible("articles_purchase") },
    { id: "listini", label: "Costario", visible: sectionVisible("articles_pricing") },
    { id: "marketing", label: "Contenuti B2B", visible: sectionVisible("articles_marketing") },
    { id: "media", label: "Media", visible: sectionVisible("media_library") },
    { id: "documenti", label: "Documenti", visible: sectionVisible("media_library") },
    { id: "giacenze", label: "Giacenze", visible: true },
    { id: "sync", label: "Sync AS400", visible: isAdmin },
  ];
  const visibleTabs = tabDefs.filter((t) => t.visible);

  const [searchParams, setSearchParams] = useSearchParams();
  const tabFromUrl = searchParams.get("tab");
  const initialTab = visibleTabs.find((t) => t.id === tabFromUrl)?.id ?? visibleTabs[0]?.id ?? "anagrafica";

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <Tabs
        value={initialTab}
        onValueChange={(v) => {
          const sp = new URLSearchParams(searchParams);
          sp.set("tab", v);
          setSearchParams(sp, { replace: true });
        }}
        className="flex flex-col h-full"
      >
        <div className="border-b bg-card px-4 shrink-0">
          <TabsList className="h-9 bg-transparent gap-0 p-0">
            {visibleTabs.map((tab) => (
              <TabsTrigger
                key={tab.id}
                value={tab.id}
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none text-xs px-3 h-9"
              >
                {tab.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        <div className="flex-1 overflow-y-auto">
          {/* ── Anagrafica ── */}
          <TabsContent value="anagrafica" className="mt-0 p-6">
            <form ref={formRef} onSubmit={handleSubmit(onSubmit)} className="space-y-5">
              <Section title="Anagrafica" actions={<LookupManager />}>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-x-5 gap-y-3">
                  {REGISTRY_FIELDS.filter((f) => fieldVisible("articles_registry", f.name)).map((f) => {
                    const canWriteField = canField("write", "articles_registry", f.name);
                    return (
                    <CompactField
                      key={f.name}
                      label={f.label}
                      pimOnly={f.pimOnly}
                      colSpan={f.name === "wfuas" ? 2 : undefined}
                    >
                      {f.computed && f.name === "_rasfo" ? (
                        <Input
                          value={supplierName ?? ""}
                          readOnly
                          className="h-8 text-sm px-2 bg-muted"
                        />
                      ) : f.lookup && canWriteField && !f.readOnly ? (
                        <LookupSelect
                          category={f.lookup}
                          value={watch(f.name) ?? ""}
                          onChange={(v) => {
                            const val = v === "__empty__" ? "" : v;
                            setValue(f.name, val, { shouldDirty: true });
                            if (f.name === "clmer") setValue("reparto", "", { shouldDirty: true });
                            if (f.name === "clmer" || f.name === "reparto") setValue("gamma", "", { shouldDirty: true });
                            if (f.name === "wcdst") {
                              setValue("cdst1", val, { shouldDirty: true });
                              setValue("clas1", val, { shouldDirty: true });
                            }
                          }}
                          parentCode={f.parentField ? (watch(f.parentField) || undefined) : undefined}
                          labelOnly={f.labelOnly}
                          className="h-8 text-sm"
                        />
                      ) : FIELD_RULES[f.name] && !f.readOnly ? (
                        <ValidatedInput
                          id={f.name}
                          name={f.name}
                          rule={FIELD_RULES[f.name]}
                          value={watch(f.name) ?? ""}
                          onChange={(v) => setValue(f.name, v, { shouldDirty: true })}
                          onValidationChange={handleValidationChange}
                          readOnly={!canWriteField}
                          forceShowError={submitAttempted}
                          className={`h-8 text-sm px-2 ${f.name === "cdpar" ? "font-mono" : ""} ${!canWriteField ? "bg-muted" : ""}`}
                        />
                      ) : (
                        <Input
                          id={f.name}
                          {...register(f.name)}
                          readOnly={f.readOnly || !canWriteField}
                          className={`h-8 text-sm px-2 ${f.name === "cdpar" ? "font-mono" : ""} ${(!canWriteField || f.readOnly) ? "bg-muted" : ""}`}
                        />
                      )}
                      {f.name === "wfuas" && fieldVisible("articles_registry", "wfuas") && (
                        <AssortmentStatusPanel
                          cdpar={article.cdpar}
                          formStatus={currentWfuas}
                          originalStatus={originalWfuas}
                          effectiveDate={assortmentEffectiveDate}
                          onEffectiveDateChange={setAssortmentEffectiveDate}
                          onEditFuture={(wstato, wdtdec) => {
                            setValue("wfuas", wstato, { shouldDirty: true });
                            setAssortmentEffectiveDate(wdtdec);
                          }}
                          disabled={!canField("write", "articles_registry", "wfuas")}
                        />
                      )}
                    </CompactField>
                    );
                  })}
                </div>

                {/* Assortment status panel is rendered inside the wfuas cell above */}

                {/* Attributi Gamma - dynamic based on gamma selection */}
                {watch("gamma") && (
                  <GammaAttributeFields
                    gammaCode={watch("gamma")}
                    currentValues={((watch("attributes") ?? {}) as Record<string, any>).gamma_attrs ?? {}}
                    onChange={(gammaAttrs) => {
                      const attrs = { ...(watch("attributes") ?? {}) as Record<string, any>, gamma_attrs: gammaAttrs };
                      setValue("attributes", attrs, { shouldDirty: true });
                    }}
                    readOnly={!canWriteRegistry}
                  />
                )}
               </Section>

               {/* ── Unità di Misura (3-column layout) ── */}
               <Section title="Unità di Misura">
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                   {/* UM Fornitore */}
                   <div className="space-y-3 md:border-r md:pr-4">
                     <h4 className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">UM Fornitore</h4>
                     {UM_FORNITORE_FIELDS.filter((f) => fieldVisible("articles_purchase", f.name)).map((f) => {
                       const canWriteF = canField("write", "articles_purchase", f.name);
                       return (
                       <CompactField key={f.name} label={f.label}>
                         {f.supplierField && f.selectOptions ? (
                           canWriteF && primarySupplier ? (
                             <Select value={getSupplierValue(f.name) || "__empty__"} onValueChange={(v) => setSupplierValue(f.name, v === "__empty__" ? "" : v)}>
                               <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                               <SelectContent>
                                 {f.selectOptions.map((opt) => (
                                   <SelectItem key={opt.value || "__empty__"} value={opt.value || "__empty__"}>{opt.label}</SelectItem>
                                 ))}
                               </SelectContent>
                             </Select>
                           ) : (
                             <Input value={f.selectOptions?.find(o => o.value === (getSupplierValue(f.name) ?? ""))?.label ?? getSupplierValue(f.name) ?? ""} readOnly className="h-8 text-sm px-2 bg-muted" />
                           )
                         ) : f.supplierField ? (
                           <Input value={getSupplierValue(f.name)} onChange={(e) => setSupplierValue(f.name, e.target.value)} type={f.type ?? "text"} readOnly={!canWriteF || !primarySupplier} className={`h-8 text-sm px-2 ${!canWriteF || !primarySupplier ? "bg-muted" : ""}`} />
                         ) : FIELD_RULES[f.name] ? (
                           <ValidatedInput
                             id={f.name}
                             name={f.name}
                             rule={FIELD_RULES[f.name]}
                             value={watch(f.name) ?? ""}
                             onChange={(v) => setValue(f.name, v, { shouldDirty: true })}
                             onValidationChange={handleValidationChange}
                             readOnly={!canWriteF}
                             forceShowError={submitAttempted}
                             className={`h-8 text-sm px-2 ${!canWriteF ? "bg-muted" : ""}`}
                           />
                         ) : (
                           <Input id={f.name} {...register(f.name)} type={f.type ?? "text"} readOnly={!canWriteF} className={`h-8 text-sm px-2 ${!canWriteF ? "bg-muted" : ""}`} />
                         )}
                       </CompactField>
                       );
                     })}
                   </div>

                   {/* UM Stoccaggio */}
                   <div className="space-y-3 md:border-r md:pr-4">
                     <h4 className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">UM Stoccaggio</h4>
                     {UM_STOCCAGGIO_FIELDS.filter((f) => fieldVisible("articles_units", f.name)).map((f) => {
                       const canWriteF = canField("write", "articles_units", f.name);
                       return (
                       <CompactField key={f.name} label={f.label}>
                         {f.lookup && canWriteF ? (
                           <LookupSelect category={f.lookup} value={watch(f.name) ?? ""} onChange={(v) => setValue(f.name, v === "__empty__" ? "" : v, { shouldDirty: true })} className="h-8 text-sm" />
                         ) : FIELD_RULES[f.name] ? (
                           <ValidatedInput
                             id={f.name}
                             name={f.name}
                             rule={FIELD_RULES[f.name]}
                             value={watch(f.name) ?? ""}
                             onChange={(v) => setValue(f.name, v, { shouldDirty: true })}
                             onValidationChange={handleValidationChange}
                             readOnly={!canWriteF}
                             forceShowError={submitAttempted}
                             className={`h-8 text-sm px-2 ${!canWriteF ? "bg-muted" : ""}`}
                           />
                         ) : (
                           <Input id={f.name} {...register(f.name)} type={f.type ?? "text"} readOnly={!canWriteF} className={`h-8 text-sm px-2 ${!canWriteF ? "bg-muted" : ""}`} />
                         )}
                       </CompactField>
                       );
                     })}
                   </div>

                   {/* UM Vendita */}
                   <div className="space-y-3">
                     <h4 className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">UM Vendita</h4>
                     {UM_VENDITA_FIELDS.filter((f) => fieldVisible("articles_units", f.name)).map((f) => {
                       const canWriteF = canField("write", "articles_units", f.name);
                       return (
                       <CompactField key={f.name} label={f.label}>
                         {f.selectOptions ? (
                           canWriteF ? (
                             <Select value={watch(f.name) ? watch(f.name) : "__empty__"} onValueChange={(v) => setValue(f.name, v === "__empty__" ? "" : v, { shouldDirty: true })}>
                               <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                               <SelectContent>
                                 {f.selectOptions.map((opt) => (
                                   <SelectItem key={opt.value || "__empty__"} value={opt.value || "__empty__"}>{opt.label}</SelectItem>
                                 ))}
                               </SelectContent>
                             </Select>
                           ) : (
                             <Input value={f.selectOptions?.find(o => o.value === (watch(f.name) ?? ""))?.label ?? watch(f.name) ?? ""} readOnly className="h-8 text-sm px-2 bg-muted" />
                           )
                         ) : f.lookup && canWriteF ? (
                           <LookupSelect category={f.lookup} value={watch(f.name) ?? ""} onChange={(v) => setValue(f.name, v === "__empty__" ? "" : v, { shouldDirty: true })} className="h-8 text-sm" />
                         ) : f.lookup ? (
                           <Input value={watch(f.name) ?? ""} readOnly className="h-8 text-sm px-2 bg-muted" />
                         ) : FIELD_RULES[f.name] ? (
                           <ValidatedInput
                             id={f.name}
                             name={f.name}
                             rule={FIELD_RULES[f.name]}
                             value={watch(f.name) ?? ""}
                             onChange={(v) => setValue(f.name, v, { shouldDirty: true })}
                             onValidationChange={handleValidationChange}
                             readOnly={f.readOnly || !canWriteF}
                             forceShowError={submitAttempted}
                             className={`h-8 text-sm px-2 ${(f.readOnly || !canWriteF) ? "bg-muted" : ""}`}
                           />
                         ) : (
                           <Input id={f.name} {...register(f.name)} type={f.type ?? "text"} readOnly={f.readOnly || !canWriteF} className={`h-8 text-sm px-2 ${(f.readOnly || !canWriteF) ? "bg-muted" : ""}`} />
                         )}
                       </CompactField>
                       );
                     })}
                   </div>
                 </div>

                 {/* Other fields */}
                 <div className="grid grid-cols-2 md:grid-cols-3 gap-x-5 gap-y-3 mt-4 pt-4 border-t">
                   {OTHER_UNITS_FIELDS.filter((f) => fieldVisible("articles_units", f.name)).map((f) => {
                     const canWriteF = canField("write", "articles_units", f.name);
                     return (
                     <CompactField key={f.name} label={f.label}>
                       {f.selectOptions ? (
                         canWriteF ? (
                           <Select value={watch(f.name) ? watch(f.name) : "__empty__"} onValueChange={(v) => setValue(f.name, v === "__empty__" ? "" : v, { shouldDirty: true })}>
                             <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                             <SelectContent>
                               {f.selectOptions.map((opt) => (
                                 <SelectItem key={opt.value || "__empty__"} value={opt.value || "__empty__"}>{opt.label}</SelectItem>
                               ))}
                             </SelectContent>
                           </Select>
                         ) : (
                           <Input value={f.selectOptions?.find(o => o.value === (watch(f.name) ?? ""))?.label ?? watch(f.name) ?? ""} readOnly className="h-8 text-sm px-2 bg-muted" />
                         )
                        ) : f.lookup && canWriteF ? (
                          <LookupSelect category={f.lookup} value={watch(f.name) ?? ""} onChange={(v) => setValue(f.name, v === "__empty__" ? "" : v, { shouldDirty: true })} className="h-8 text-sm" />
                        ) : FIELD_RULES[f.name] ? (
                          <ValidatedInput
                            id={f.name}
                            name={f.name}
                            rule={FIELD_RULES[f.name]}
                            value={watch(f.name) ?? ""}
                            onChange={(v) => setValue(f.name, v, { shouldDirty: true })}
                            onValidationChange={handleValidationChange}
                            readOnly={!canWriteF}
                            forceShowError={submitAttempted}
                            className={`h-8 text-sm px-2 ${!canWriteF ? "bg-muted" : ""}`}
                          />
                        ) : (
                          <Input id={f.name} {...register(f.name)} type={f.type ?? "text"} readOnly={!canWriteF} className={`h-8 text-sm px-2 ${!canWriteF ? "bg-muted" : ""}`} />
                        )}
                     </CompactField>
                     );
                   })}
                 </div>
               </Section>
             </form>
           </TabsContent>

          {/* ── Codici a Barre ── */}
          <TabsContent value="codici-barre" className="mt-0 p-6">
            <Section title="Codici a Barre">
              <TabBarcodes article={article} />
            </Section>
          </TabsContent>

          {/* ── Acquisto ── */}
          <TabsContent value="acquisto" className="mt-0 p-6">
            <Section title="Acquisto">
              <TabPurchase article={article} />
            </Section>
          </TabsContent>

          {/* ── Costario ── */}
          <TabsContent value="listini" className="mt-0 p-6">
            <Section title="Costario" actions={<div id="costario-header-slot" />}>
              <TabPriceLists article={article} />
            </Section>
            <div className="mt-4">
              <Section title="Criteri Prezzo LV">
                <TabSalesPriceCriteria article={article} />
              </Section>
            </div>
          </TabsContent>

          {/* ── Contenuti B2B ── */}
          <TabsContent value="marketing" className="mt-0 p-6">
            <form ref={formRef} onSubmit={handleSubmit(onSubmit)} className="space-y-5">
              <Section title="Contenuti B2B" pimOnly>
                <MarketingSection
                  cdpar={(article.cdpar ?? "").trim()}
                  codPadre={(article as any).cod_padre ?? null}
                  dbWfuas={(article.wfuas ?? "") as string}
                  b2bOnlineEffective={(article as any).b2b_online_effective}
                  register={register}
                  watch={watch}
                  setValue={setValue}
                  canWrite={canWriteMarketing}
                  tags={tags}
                  tagInput={tagInput}
                  setTagInput={setTagInput}
                  handleTagKeyDown={handleTagKeyDown}
                  removeTag={removeTag}
                  addTag={addTag}
                  tagSuggestOpen={tagSuggestOpen}
                  setTagSuggestOpen={setTagSuggestOpen}
                  highlightIdx={highlightIdx}
                  setHighlightIdx={setHighlightIdx}
                  filteredSuggestions={filteredSuggestions}
                  trimmedTagInput={trimmedTagInput}
                  applyAiTags={applyAiTags}
                />
              </Section>
              <Section title="Cataloghi Cartacei" pimOnly>
                {(() => {
                  const cc_titolo = (watch("catalogo_carta_titolo" as any) ?? "") as string;
                  const cc_dettaglio = (watch("catalogo_carta_dettaglio" as any) ?? "") as string;
                  const cc_scheda = (watch("catalogo_carta_scheda" as any) ?? "") as string;
                  return (
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-1 md:col-span-2">
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-medium">Titolo</label>
                          <span className={`text-[10px] tabular-nums ${cc_titolo.length > 37 ? "text-destructive" : "text-muted-foreground"}`}>{cc_titolo.length}/37</span>
                        </div>
                        <Input maxLength={37} disabled={!canWriteMarketing} {...register("catalogo_carta_titolo" as any)} />
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-medium">Dettaglio</label>
                          <span className={`text-[10px] tabular-nums ${cc_dettaglio.length > 29 ? "text-destructive" : "text-muted-foreground"}`}>{cc_dettaglio.length}/29</span>
                        </div>
                        <Input maxLength={29} disabled={!canWriteMarketing} {...register("catalogo_carta_dettaglio" as any)} />
                      </div>
                      <div className="space-y-1 md:col-span-2">
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-medium">Scheda</label>
                          <span className={`text-[10px] tabular-nums ${cc_scheda.length > 340 ? "text-destructive" : "text-muted-foreground"}`}>{cc_scheda.length}/340</span>
                        </div>
                        <Textarea rows={5} maxLength={340} disabled={!canWriteMarketing} {...register("catalogo_carta_scheda" as any)} />
                      </div>
                    </div>
                  );
                })()}
              </Section>
              <Section title="Varianti collegate">
                <VariantiCollegateTable
                  currentCdpar={(article.cdpar ?? "").trim()}
                  codPadre={(article as any).cod_padre ?? null}
                />
              </Section>
            </form>
          </TabsContent>

          {/* ── Media ── */}
          <TabsContent value="media" className="mt-0 p-6">
            <Section title="Media" pimOnly>
              <TabMedia article={article} mode="media" />
            </Section>
          </TabsContent>

          {/* ── Documenti ── */}
          <TabsContent value="documenti" className="mt-0 p-6">
            <Section title="Schede Tecniche & Documenti" pimOnly>
              <TabMedia article={article} mode="docs" />
            </Section>
          </TabsContent>

          {/* ── Giacenze ── */}
          <TabsContent value="giacenze" className="mt-0 p-6">
            <TabInventory cdpar={article.cdpar} />
          </TabsContent>

          {/* ── Sync AS400 ── */}
          <TabsContent value="sync" className="mt-0 p-6">
            <Section title="Sync AS400" adminOnly>
              <TabSync article={article} />
            </Section>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}

/* ── Section wrapper ──────────────────────────────────────────── */

function Section({ title, actions, pimOnly, adminOnly, children }: { title: string; actions?: React.ReactNode; pimOnly?: boolean; adminOnly?: boolean; children: React.ReactNode }) {
  return (
    <section className={`rounded-lg border bg-card shadow-sm ${adminOnly ? "border-destructive/40" : ""}`}>
      <div className={`px-4 py-2 border-b rounded-t-lg flex items-center justify-between ${adminOnly ? "bg-destructive/10 border-destructive/30" : "bg-muted/50"}`}>
        <h2 className={`text-sm font-semibold ${adminOnly ? "text-destructive" : pimOnly ? "text-blue-600" : "text-foreground"}`}>{title}</h2>
        {actions}
      </div>
      <div className="p-4">
        {children}
      </div>
    </section>
  );
}

function CompactField({ label, pimOnly, colSpan, children }: { label: string; pimOnly?: boolean; colSpan?: number; children: React.ReactNode }) {
  const spanClass = colSpan === 2 ? "col-span-2" : colSpan === 3 ? "col-span-3" : "";
  return (
    <div className={`flex flex-col gap-1 ${spanClass}`}>
      <span className={`text-[11px] leading-tight truncate ${pimOnly ? "text-blue-600 font-semibold" : "text-muted-foreground"}`}>{label}</span>
      {children}
    </div>
  );
}

/* ── Contenuti B2B inline section ─────────────────────────────── */

function MarketingSection({
  cdpar, dbWfuas, b2bOnlineEffective, register, watch, setValue, canWrite, tags,
  tagInput, setTagInput,
  handleTagKeyDown, removeTag, addTag,
  tagSuggestOpen, setTagSuggestOpen,
  highlightIdx, setHighlightIdx,
  filteredSuggestions, trimmedTagInput,
  applyAiTags,
}: any) {
  const b2bTitle = (watch("b2b_product_title") ?? "") as string;
  const b2bDesc = (watch("b2b_product_description") ?? "") as string;
  const descVariante = (watch("descrizione_variante") ?? "") as string;
  const ecomDesc = (watch("description_ecommerce") ?? "") as string;
  const seoTitle = (watch("seo_title") ?? "") as string;
  const seoDesc = (watch("seo_description") ?? "") as string;
  const b2bOverride = watch("b2b_online_active") as boolean | null;
  const formWfuas = (watch("wfuas") ?? "") as string;
  const articleWfuas = ((dbWfuas ?? formWfuas) as string).trim();
  const { data: onlineAssortments = [] } = useOnlineAssortments();
  const b2bOnline = b2bOverride == null && typeof b2bOnlineEffective === "boolean"
    ? b2bOnlineEffective
    : computeIsB2bOnline(b2bOverride, articleWfuas, onlineAssortments);
  const b2bMode = b2bValueToMode(b2bOverride);
  const isArticleWfuasOnline = onlineAssortments.map((v) => v.trim()).includes(articleWfuas);

  const setFieldValue = (field: string, value: string | string[]) => {
    setValue(field, value, { shouldDirty: true, shouldTouch: true, shouldValidate: true });
  };

  return (
    <div className="space-y-6">
      {/* ── Vendita Online B2B (master switch) ── */}
      <div className={`rounded-lg border-2 p-4 transition-colors ${b2bOnline ? "border-primary/50 bg-primary/5" : "border-muted bg-muted/30"}`}>
        <div className="flex items-center gap-3 mb-2">
          <Label className="text-base font-semibold flex items-center gap-2">
            🛒 Vendita Online B2B
            <span
              title={b2bOnline ? "Online" : "Offline"}
              className={`inline-block h-2.5 w-2.5 rounded-full ${b2bOnline ? "bg-green-500" : "bg-red-500"}`}
            />
            {b2bMode !== "auto" && (
              <Badge variant="outline" className="text-[10px]">override manuale</Badge>
            )}
          </Label>
        </div>
        <div className="flex items-center gap-3">
          <Select
            value={b2bMode}
            onValueChange={(v) => setValue("b2b_online_active", b2bModeToValue(v as B2bOverrideMode), { shouldDirty: true })}
            disabled={!canWrite}
          >
            <SelectTrigger className="h-9 w-[260px] text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="auto">Auto (da assortimento)</SelectItem>
              <SelectItem value="force_on">Forza online</SelectItem>
              <SelectItem value="force_off">Forza offline</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground flex-1">
            {b2bMode === "auto"
              ? `Auto: wfuas DB ${articleWfuas || "—"} ${isArticleWfuasOnline ? "è in lista online" : "NON è in lista online"}. Stato effettivo: ${b2bOnline ? "ONLINE" : "OFFLINE"}.`
              : b2bMode === "force_on"
                ? "Override manuale: l'articolo è forzato online indipendentemente da wfuas."
                : "Override manuale: l'articolo è forzato offline indipendentemente da wfuas."}
          </p>
        </div>
      </div>

      {/* ── AI Generation Panel ── */}
      {canWrite && cdpar && (
        <div className="rounded-lg border border-primary/20 bg-gradient-to-br from-primary/5 to-transparent p-4">
          <AiMarketingPanel
            cdpar={cdpar}
            canWrite={canWrite}
            currentTags={tags}
            setField={setFieldValue}
            applyAiTags={applyAiTags}
          />
        </div>
      )}


      {/* ── Prodotto B2B ── */}
      <div className="space-y-4">

        <div>
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Scheda Prodotto</h3>
          <p className="text-xs text-muted-foreground mb-3">Nome e descrizione principale del prodotto per il catalogo B2B.</p>
        </div>
        <div className="space-y-1.5">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-1">
              <Label className="text-sm text-blue-600 font-semibold">Titolo Prodotto</Label>
              <AiFieldButton cdpar={cdpar} field="title" canWrite={canWrite} onApply={(v) => setFieldValue("b2b_product_title", String(v).slice(0, 150))} />
            </div>
            <span className={`text-xs tabular-nums ${b2bTitle.length > 150 ? "text-destructive font-semibold" : "text-muted-foreground"}`}>{b2bTitle.length}/150</span>
          </div>
          <Input
            {...register("b2b_product_title", { maxLength: 150 })}
            readOnly={!canWrite}
            maxLength={150}
            placeholder="Nome prodotto per il catalogo B2B..."
            className={`h-9 text-sm ${!canWrite ? "bg-muted" : ""}`}
          />
        </div>
        <div className="space-y-1.5">
          <div className="flex justify-between items-center">
            <Label className="text-sm text-blue-600 font-semibold">Descrizione Variante</Label>
            <span className={`text-xs tabular-nums ${descVariante.length > 255 ? "text-destructive font-semibold" : "text-muted-foreground"}`}>{descVariante.length}/255</span>
          </div>
          <Input
            {...register("descrizione_variante", { maxLength: 255 })}
            readOnly={!canWrite}
            maxLength={255}
            placeholder="Es: Versione 33x70 colore blu..."
            className={`h-9 text-sm ${!canWrite ? "bg-muted" : ""}`}
          />
        </div>
        <div className="space-y-1.5">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-1">
              <Label className="text-sm text-blue-600 font-semibold">Descrizione Prodotto</Label>
              <AiFieldButton cdpar={cdpar} field="description" canWrite={canWrite} onApply={(v) => setFieldValue("b2b_product_description", String(v).slice(0, 2000))} />
            </div>
            <span className={`text-xs tabular-nums ${b2bDesc.length > 2000 ? "text-destructive font-semibold" : "text-muted-foreground"}`}>{b2bDesc.length}/2000</span>
          </div>
          <Textarea
            {...register("b2b_product_description", { maxLength: 2000 })}
            readOnly={!canWrite}
            maxLength={2000}
            placeholder="Descrizione professionale e completa del prodotto..."
            className={`min-h-[140px] text-sm ${!canWrite ? "bg-muted" : ""}`}
          />
        </div>
      </div>

      {/* ── Descrizione Breve E-commerce ── */}
      <div className="space-y-4">
        <div>
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">E-commerce</h3>
          <p className="text-xs text-muted-foreground mb-3">Testo breve per la scheda prodotto sul portale e-commerce.</p>
        </div>
        <div className="space-y-1.5">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-1">
              <Label className="text-sm text-blue-600 font-semibold">Descrizione Breve E-commerce</Label>
              <AiFieldButton cdpar={cdpar} field="short_description" canWrite={canWrite} onApply={(v) => setFieldValue("description_ecommerce", String(v).slice(0, 230))} />
            </div>
            <span className={`text-xs tabular-nums ${ecomDesc.length > 230 ? "text-destructive font-semibold" : "text-muted-foreground"}`}>{ecomDesc.length}/230</span>
          </div>
          <Textarea
            {...register("description_ecommerce", { maxLength: 230 })}
            readOnly={!canWrite}
            maxLength={230}
            placeholder="Testo sintetico per il portale e-commerce..."
            className={`min-h-[80px] text-sm ${!canWrite ? "bg-muted" : ""}`}
          />
        </div>
      </div>

      {/* ── SEO & Visibilità Online ── */}
      <div className="space-y-4">
        <div>
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">SEO & Visibilità Online</h3>
          <p className="text-xs text-muted-foreground mb-3">Titolo e descrizione per l'indicizzazione su motori di ricerca.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-1">
                <Label className="text-sm text-blue-600 font-semibold">SEO Title</Label>
                <AiFieldButton cdpar={cdpar} field="seo_title" canWrite={canWrite} onApply={(v) => setFieldValue("seo_title", String(v).slice(0, 60))} />
              </div>
              <span className={`text-xs tabular-nums ${seoTitle.length > 60 ? "text-destructive font-semibold" : "text-muted-foreground"}`}>{seoTitle.length}/60</span>
            </div>
            <Input {...register("seo_title", { maxLength: 60 })} readOnly={!canWrite} maxLength={60}
              placeholder="Titolo pagina prodotto per Google..."
              className={`h-9 text-sm ${!canWrite ? "bg-muted" : ""}`} />
          </div>
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-1">
                <Label className="text-sm text-blue-600 font-semibold">SEO Description</Label>
                <AiFieldButton cdpar={cdpar} field="seo_description" canWrite={canWrite} onApply={(v) => setFieldValue("seo_description", String(v).slice(0, 160))} />
              </div>
              <span className={`text-xs tabular-nums ${seoDesc.length > 160 ? "text-destructive font-semibold" : "text-muted-foreground"}`}>{seoDesc.length}/160</span>
            </div>
            <Input {...register("seo_description", { maxLength: 160 })} readOnly={!canWrite} maxLength={160}
              placeholder="Meta description per motori di ricerca..."
              className={`h-9 text-sm ${!canWrite ? "bg-muted" : ""}`} />
          </div>
        </div>
      </div>

      {/* ── Classificazione & Ricerca ── */}
      <div className="space-y-3">
        <div>
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1">
            Classificazione & Ricerca
            <AiFieldButton
              cdpar={cdpar}
              field="tags"
              canWrite={canWrite}
              onApply={(v) => applyAiTags(v)}
            />
          </h3>
          <p className="text-xs text-muted-foreground mb-3">Tag per filtrare e raggruppare i prodotti nel catalogo B2B.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {tags.map((tag: string) => (
            <Badge key={tag} variant="secondary" className="text-sm gap-1.5 px-3 py-1">
              {tag}
              {canWrite && <X className="h-3.5 w-3.5 cursor-pointer hover:text-destructive transition-colors" onClick={() => removeTag(tag)} />}
            </Badge>
          ))}
          {tags.length === 0 && (
            <span className="text-xs text-muted-foreground italic">Nessun tag associato</span>
          )}
        </div>
        {canWrite && (
          <div className="relative max-w-md">
            <Input
              value={tagInput}
              onChange={(e: any) => { setTagInput(e.target.value); setTagSuggestOpen(true); setHighlightIdx(0); }}
              onKeyDown={handleTagKeyDown}
              onFocus={() => setTagSuggestOpen(true)}
              onBlur={() => setTimeout(() => setTagSuggestOpen(false), 150)}
              placeholder="Digita almeno 3 caratteri per vedere i suggerimenti..."
              className="h-9 text-sm"
            />
            {tagSuggestOpen && trimmedTagInput.length >= 3 && filteredSuggestions.length > 0 && (
              <div className="absolute z-50 mt-1 w-full bg-popover border border-border rounded-md shadow-md max-h-64 overflow-y-auto">
                <div className="px-2 py-1 text-[10px] uppercase tracking-wider text-muted-foreground border-b">
                  Tag esistenti — clicca per riutilizzare
                </div>
                {filteredSuggestions.map((s, idx) => (
                  <button
                    key={s.tag}
                    type="button"
                    onMouseDown={(e) => { e.preventDefault(); addTag(s.tag); }}
                    onMouseEnter={() => setHighlightIdx(idx)}
                    className={`w-full text-left px-2 py-1.5 text-sm flex items-center justify-between hover:bg-accent ${idx === highlightIdx ? "bg-accent" : ""}`}
                  >
                    <span>{s.tag}</span>
                    <span className="text-xs text-muted-foreground">{s.usage_count}×</span>
                  </button>
                ))}
              </div>
            )}
            {tagSuggestOpen && trimmedTagInput.length >= 3 && filteredSuggestions.length === 0 && (
              <div className="absolute z-50 mt-1 w-full bg-popover border border-border rounded-md shadow-md px-2 py-2 text-xs text-muted-foreground">
                Nessun tag esistente — premi Invio per creare "{trimmedTagInput}"
              </div>
            )}
          </div>
        )}
      </div>

      {/* ── Logistica B2B (PIM-only) ── */}
      <div className="space-y-3 rounded-lg border bg-card p-4">
        <div>
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Logistica B2B</h3>
          <p className="text-xs text-muted-foreground mt-1">Dati logistici gestiti solo nel PIM, non inviati ad AS400.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-sm text-blue-600 font-semibold">Confezionamento master (pz/cartone)</Label>
            <Input
              {...register("master_pack", { valueAsNumber: true })}
              type="number"
              min={1}
              step={1}
              readOnly={!canWrite}
              placeholder="Es. 24"
              className={`h-9 text-sm ${!canWrite ? "bg-muted" : ""}`}
            />
            <p className="text-[11px] text-muted-foreground">Numero di pezzi per cartone master.</p>
          </div>
        </div>
      </div>
    </div>

  );
}

import { useState, useRef, useCallback, useEffect, useMemo } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useVirtualizer } from "@tanstack/react-virtual";
import { Image as ImageIcon, ArrowUp, ArrowDown, ArrowUpDown } from "lucide-react";
import { useArticles, useDistinctValues } from "@/hooks/useArticles";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { getMediaCdparCandidates } from "@/lib/mediaUtils";
import { useAuth } from "@/contexts/AuthContext";
import { usePermissions } from "@/lib/permissions";
import { useLookupValues } from "@/hooks/useLookupValues";
import { usePromoOptions, useTemaOptions, usePromoFilterCdpars } from "@/hooks/usePromoArticleFilter";
import { useOnlineAssortments, computeIsB2bOnline } from "@/hooks/useOnlineAssortments";
import { useVisibleAssortments } from "@/hooks/useVisibleAssortments";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Download, Package, Plus, AlertCircle, ListChecks, X } from "lucide-react";
import { ExportModal } from "./ExportModal";
import { BulkSearchDialog } from "./BulkSearchDialog";
import { MultiSelectFilter, type FilterOption } from "./MultiSelectFilter";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";

const ROW_HEIGHT = 44;

type SortKey = "cdpar" | "stock" | "depar" | "clmer" | "reparto" | "gamma" | "wfuas" | "unmis" | "pcfor" | "rasfo" | "b2b";

const COLUMNS: { key: string; label: string; cls: string; sortKey?: SortKey }[] = [
  { key: "img", label: "", cls: "w-[40px]" },
  { key: "cdpar", label: "Codice", cls: "w-[70px]", sortKey: "cdpar" },
  { key: "stock", label: "Giac.", cls: "w-[50px] text-right", sortKey: "stock" },
  { key: "depar", label: "Descrizione", cls: "flex-1 min-w-[180px]", sortKey: "depar" },
  { key: "clmer", label: "Settore", cls: "w-[120px]", sortKey: "clmer" },
  { key: "reparto", label: "Reparto", cls: "w-[120px]", sortKey: "reparto" },
  { key: "gamma", label: "Gamma", cls: "w-[100px]", sortKey: "gamma" },
  { key: "wfuas", label: "Assort.", cls: "w-[70px]", sortKey: "wfuas" },
  { key: "unmis", label: "UM", cls: "w-[45px]", sortKey: "unmis" },
  { key: "pcfor", label: "Forn.", cls: "w-[75px]", sortKey: "pcfor" },
  { key: "rasfo", label: "Ragione Sociale", cls: "w-[150px]", sortKey: "rasfo" },
  { key: "b2b", label: "B2B", cls: "w-[70px]", sortKey: "b2b" },
];

export function ArticleList() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const queryClient = useQueryClient();
  const { user, profile } = useAuth();
  const { canAction } = usePermissions();
  const canCreateNewArticle = canAction("articles_registry", "create");
  const urlSearch = searchParams.get("search") || "";
  const [search, setSearch] = useState(urlSearch);
  const [debouncedSearch, setDebouncedSearch] = useState(urlSearch);
  const [clmer, setClmer] = useState<string[]>([]);
  const [reparto, setReparto] = useState<string[]>([]);
  const [gamma, setGamma] = useState<string[]>([]);
  const [wfuas, setWfuas] = useState<string[]>([]);
  const [pcfor, setPcfor] = useState<string[]>([]);
  const [clas2, setClas2] = useState<string[]>([]);
  const [promoWp, setPromoWp] = useState<number[]>([]);
  const [temaIds, setTemaIds] = useState<string[]>([]);
  const [availabilityFilter, setAvailabilityFilter] = useState<"all" | "available" | "unavailable">("all");
  const [b2bFilter, setB2bFilter] = useState<"all" | "online" | "offline">("all");
  const [page, setPage] = useState(0);
  const [sortKey, setSortKey] = useState<SortKey | null>(null);
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
  const toggleSort = (k: SortKey) => {
    if (sortKey === k) {
      if (sortDir === "asc") setSortDir("desc");
      else { setSortKey(null); setSortDir("asc"); }
    } else { setSortKey(k); setSortDir("asc"); }
  };

  const { data: visibleAssortments } = useVisibleAssortments();

  const [exportOpen, setExportOpen] = useState(false);
  const [newDialogOpen, setNewDialogOpen] = useState(false);
  const [newCdpar, setNewCdpar] = useState("");
  const [newDepar, setNewDepar] = useState("");
  const [debouncedNewCdpar, setDebouncedNewCdpar] = useState("");
  const [bulkOpen, setBulkOpen] = useState(false);
  const [bulkCdpars, setBulkCdpars] = useState<string[] | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const t = setTimeout(() => { setDebouncedSearch(search); setPage(0); }, 400);
    return () => clearTimeout(t);
  }, [search]);

  // Sync from URL search param when navigating from header
  useEffect(() => {
    const q = searchParams.get("search") || "";
    if (q !== search) {
      setSearch(q);
      setDebouncedSearch(q);
      setPage(0);
    }
  }, [searchParams]);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedNewCdpar(newCdpar.trim().toUpperCase()), 300);
    return () => clearTimeout(t);
  }, [newCdpar]);

  const { data: existingArticle } = useQuery({
    queryKey: ["article-exists", debouncedNewCdpar],
    queryFn: async () => {
      const { data } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("id")
        .eq("cdpar", debouncedNewCdpar)
        .maybeSingle();
      return data;
    },
    enabled: debouncedNewCdpar.length >= 1,
  });

  const isArticleDuplicate = !!existingArticle && debouncedNewCdpar === newCdpar.trim().toUpperCase();
  const canCreateArticle = newCdpar.trim().length > 0 && newCdpar.trim().length <= 15 && newDepar.trim().length > 0 && !isArticleDuplicate;

  const createArticleMutation = useMutation({
    mutationFn: async () => {
      const code = newCdpar.trim().toUpperCase();
      const desc = newDepar.trim();
      if (!code) throw new Error("Codice articolo richiesto.");
      if (!desc) throw new Error("Descrizione richiesta.");
      const { data: existing } = await supabase.from("archivio_articoli_fraschetti").select("id").eq("cdpar", code).maybeSingle();
      if (existing) throw new Error(`Articolo ${code} già esistente.`);
      const { error } = await supabase.from("archivio_articoli_fraschetti").insert({ cdpar: code, depar: desc });
      if (error) throw error;
      await supabase.from("audit_log" as any).insert({
        table_name: "archivio_articoli_fraschetti", record_id: code, operation: "insert",
        new_values: { cdpar: code, depar: desc }, changed_fields: ["cdpar", "depar"],
        user_id: user?.id, user_email: profile?.email,
      });
      return code;
    },
    onSuccess: (code) => {
      toast({ title: "Articolo creato" });
      setNewCdpar(""); setNewDepar(""); setNewDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["articles"] });
      navigate(`/pim/articles/${encodeURIComponent(code)}`);
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const { data: promoCdpars, isFetching: promoCdparsLoading } = usePromoFilterCdpars(promoWp, temaIds);
  const promoFilterActive = promoWp.length > 0 || temaIds.length > 0;

  // Combine bulk-pasted codes with promo filter (intersect if both active)
  const effectiveCdpars = useMemo<string[] | undefined>(() => {
    const bulk = bulkCdpars;
    if (bulk && bulk.length > 0 && promoFilterActive) {
      if (promoCdparsLoading && !promoCdpars) return undefined;
      const promoSet = new Set((promoCdpars ?? []).map((c) => c.trim()));
      return bulk.filter((c) => promoSet.has(c.trim()));
    }
    if (bulk && bulk.length > 0) return bulk;
    if (promoFilterActive) return promoCdparsLoading && !promoCdpars ? undefined : (promoCdpars ?? []);
    return undefined;
  }, [bulkCdpars, promoFilterActive, promoCdpars, promoCdparsLoading]);

  const { data, isLoading, isFetching } = useArticles({
    search: debouncedSearch,
    clmer: clmer.length > 0 ? clmer : undefined,
    reparto: reparto.length > 0 ? reparto : undefined,
    gamma: gamma.length > 0 ? gamma : undefined,
    wfuas: wfuas.length > 0 ? wfuas : undefined,
    pcfor: pcfor.length > 0 ? pcfor : undefined,
    clas2: clas2.length > 0 ? clas2 : undefined,
    cdpars: effectiveCdpars,
    page,
  });


  // Lookup values for labels
  const { data: clmerLookup } = useLookupValues("clmer");
  const { data: repartoLookup } = useLookupValues("reparto");
  const { data: gammaLookup } = useLookupValues("gamma");
  const { data: onlineAssortments = [] } = useOnlineAssortments();

  const clmerMap = useMemo(() => {
    const m: Record<string, string> = {};
    (clmerLookup ?? []).forEach((l) => { m[l.code] = l.label || l.code; });
    return m;
  }, [clmerLookup]);

  const repartoMap = useMemo(() => {
    const m: Record<string, string> = {};
    (repartoLookup ?? []).forEach((l) => { m[l.code] = l.label || l.code; });
    return m;
  }, [repartoLookup]);

  const gammaMap = useMemo(() => {
    const m: Record<string, string> = {};
    (gammaLookup ?? []).forEach((l) => { m[l.code] = l.label || l.code; });
    return m;
  }, [gammaLookup]);

  // Promo & Tema options
  const { data: promoOptionsRaw } = usePromoOptions();
  const { data: temaOptionsRaw } = useTemaOptions(promoWp);
  const promoOptions: FilterOption[] = useMemo(
    () => (promoOptionsRaw ?? []).map((p) => ({ value: String(p.wpprgf), label: p.label })),
    [promoOptionsRaw]
  );
  const temaOptions: FilterOption[] = useMemo(
    () => (temaOptionsRaw ?? []).map((t) => ({ value: t.id, label: t.nome })),
    [temaOptionsRaw]
  );

  // Distinct values for filters
  // Distinct values for filters
  const { data: clmerValues } = useDistinctValues("clmer");
  const { data: wfuasValues } = useDistinctValues("wfuas");
  const { data: pcforValues } = useDistinctValues("pcfor");
  const { data: clas2Values } = useDistinctValues("clas2");
  // Build filter options
  const clmerOptions: FilterOption[] = useMemo(
    () => (clmerValues ?? []).map((v) => ({ value: v, label: clmerMap[v] || v })),
    [clmerValues, clmerMap]
  );

  // Reparto options from lookup, filtered by selected settore
  const repartoOptions: FilterOption[] = useMemo(() => {
    const lookups = repartoLookup ?? [];
    if (clmer.length > 0) {
      return lookups
        .filter((l) => l.parent_code && clmer.includes(l.parent_code))
        .map((l) => ({ value: l.code, label: l.label || l.code }));
    }
    return lookups.map((l) => ({ value: l.code, label: l.label || l.code }));
  }, [repartoLookup, clmer]);

  // Gamma options from lookup, filtered by selected reparto
  const gammaOptions: FilterOption[] = useMemo(() => {
    const lookups = gammaLookup ?? [];
    if (reparto.length > 0) {
      return lookups
        .filter((l) => l.parent_code && reparto.includes(l.parent_code))
        .map((l) => ({ value: l.code, label: l.label || l.code }));
    }
    return lookups.map((l) => ({ value: l.code, label: l.label || l.code }));
  }, [gammaLookup, reparto]);

  const wfuasOptions: FilterOption[] = useMemo(
    () => (wfuasValues ?? []).map((v) => ({ value: v, label: v })),
    [wfuasValues]
  );

  // Supplier map — fetch ALL suppliers (paginated to bypass 1000 row limit)
  const { data: suppliers } = useQuery({
    queryKey: ["suppliers-map"],
    queryFn: async () => {
      const allSuppliers: { cdfor: string; rasfo: string | null }[] = [];
      let from = 0;
      const batchSize = 1000;
      while (true) {
        const { data, error } = await supabase
          .from("archivio_fornitori_fraschetti")
          .select("cdfor,rasfo")
          .range(from, from + batchSize - 1);
        if (error) throw error;
        if (!data || data.length === 0) break;
        allSuppliers.push(...data);
        if (data.length < batchSize) break;
        from += batchSize;
      }
      return Object.fromEntries(allSuppliers.map((s) => [s.cdfor?.trim(), s.rasfo?.trim() ?? ""]));
    },
    staleTime: 300_000,
  });
  const supplierMap = suppliers ?? {};

  const pcforOptions: FilterOption[] = useMemo(() => {
    const seen = new Set<string>();
    const out: FilterOption[] = [];
    for (const raw of pcforValues ?? []) {
      const code = (raw ?? "").trim();
      if (!code || seen.has(code)) continue;
      seen.add(code);
      const name = supplierMap[code];
      out.push({ value: code, label: name ? `${code} - ${name}` : code });
    }
    out.sort((a, b) => a.label.localeCompare(b.label));
    return out;
  }, [pcforValues, supplierMap]);

  const clas2Options: FilterOption[] = useMemo(() => {
    const seen = new Set<string>();
    const out: FilterOption[] = [];
    for (const raw of clas2Values ?? []) {
      const code = (raw ?? "").trim();
      if (!code || seen.has(code)) continue;
      seen.add(code);
      out.push({ value: code, label: code });
    }
    out.sort((a, b) => a.label.localeCompare(b.label));
    return out;
  }, [clas2Values]);

  // Articles are already filtered server-side for reparto/gamma; keep this as a safety net for search RPC results.
  const filteredArticles = useMemo(() => {
    let rows = data?.data ?? [];
    if (reparto.length > 0) {
      rows = rows.filter((a: any) => {
        const val = a.attributes?.reparto;
        return val && reparto.includes(val);
      });
    }
    if (gamma.length > 0) {
      rows = rows.filter((a: any) => {
        const val = a.attributes?.gamma;
        return val && gamma.includes(val);
      });
    }
    return rows;
  }, [data?.data, reparto, gamma]);

  // Inventory map for visible rows (key = first 6 chars of cdpar)
  const inventoryKeys = useMemo(
    () => Array.from(new Set(filteredArticles.map((a: any) => (a.cdpar ?? "").trim().slice(0, 6)).filter(Boolean))),
    [filteredArticles]
  );
  const { data: inventoryMap } = useQuery({
    queryKey: ["article-inventory-map", inventoryKeys],
    queryFn: async () => {
      if (inventoryKeys.length === 0) return {};
      const { data } = await supabase
        .from("article_inventory" as any)
        .select("cdpar, quantity")
        .in("cdpar", inventoryKeys);
      const map: Record<string, number> = {};
      (data ?? []).forEach((r: any) => { map[(r.cdpar ?? "").trim()] = Number(r.quantity); });
      return map;
    },
    enabled: inventoryKeys.length > 0,
    staleTime: 60_000,
  });
  const inventory = inventoryMap ?? {};
  const getStock = useCallback((cdpar: string) => inventory[cdpar.trim().slice(0, 6)], [inventory]);

  const sortedArticles = useMemo(() => {
    if (!sortKey) return filteredArticles;
    const getVal = (a: any): string | number => {
      const attrs = a.attributes ?? {};
      switch (sortKey) {
        case "cdpar": return (a.cdpar ?? "").trim().toLowerCase();
        case "stock": return getStock(a.cdpar ?? "") ?? Number.NEGATIVE_INFINITY;
        case "depar": return (a.depar ?? "").toString().toLowerCase();
        case "clmer": return (clmerMap[a.clmer] || a.clmer || "").toString().toLowerCase();
        case "reparto": return (repartoMap[attrs.reparto] || attrs.reparto || "").toString().toLowerCase();
        case "gamma": return (gammaMap[attrs.gamma] || attrs.gamma || "").toString().toLowerCase();
        case "wfuas": return (a.wfuas ?? "").toString().toLowerCase();
        case "unmis": return (a.unmis ?? "").toString().toLowerCase();
        case "pcfor": return (a.pcfor ?? "").toString().trim().toLowerCase();
        case "rasfo": return (supplierMap[(a.pcfor ?? "").trim()] || "").toString().toLowerCase();
        case "b2b": return computeIsB2bOnline(a.b2b_online_active, a.wfuas, onlineAssortments) ? 1 : 0;
      }
    };
    const sorted = [...filteredArticles].sort((a, b) => {
      const va = getVal(a); const vb = getVal(b);
      if (va < vb) return sortDir === "asc" ? -1 : 1;
      if (va > vb) return sortDir === "asc" ? 1 : -1;
      return 0;
    });
    return sorted;
  }, [filteredArticles, sortKey, sortDir, getStock, clmerMap, repartoMap, gammaMap, supplierMap, onlineAssortments]);

  const displayArticles = useMemo(() => {
    let rows = sortedArticles;
    if (availabilityFilter === "available") {
      rows = rows.filter((a: any) => (getStock(a.cdpar ?? "") ?? 0) > 0);
    } else if (availabilityFilter === "unavailable") {
      rows = rows.filter((a: any) => (getStock(a.cdpar ?? "") ?? 0) <= 0);
    }
    if (b2bFilter === "online") {
      rows = rows.filter((a: any) => computeIsB2bOnline(a.b2b_online_active, a.wfuas, onlineAssortments));
    } else if (b2bFilter === "offline") {
      rows = rows.filter((a: any) => !computeIsB2bOnline(a.b2b_online_active, a.wfuas, onlineAssortments));
    }
    return rows;
  }, [sortedArticles, availabilityFilter, b2bFilter, getStock, onlineAssortments]);

  const extraFiltersActive = availabilityFilter !== "all" || b2bFilter !== "all";
  const totalCount = (reparto.length > 0 || gamma.length > 0 || extraFiltersActive) ? displayArticles.length : (data?.count ?? 0);
  const pageSize = data?.pageSize ?? 25;
  const totalPages = Math.ceil((data?.count ?? 0) / pageSize);

  // Thumbnails
  const cdpars = useMemo(
    () => Array.from(new Set(displayArticles.map((a: any) => (a.cdpar ?? "").trim()).filter(Boolean))),
    [displayArticles]
  );
  const { data: mediaMap } = useQuery({
    queryKey: ["article-thumbs", cdpars],
    queryFn: async () => {
      if (cdpars.length === 0) return {};
      const cdparCandidates = Array.from(new Set(cdpars.flatMap((cdpar) => getMediaCdparCandidates(cdpar))));
      const { data } = await supabase
        .from("article_media")
        .select("cdpar, public_url, updated_at")
        .in("cdpar", cdparCandidates)
        .eq("media_type", "image")
        .eq("is_primary", true);
      const map: Record<string, string> = {};
      (data ?? []).forEach((m: any) => {
        const key = (m.cdpar ?? "").trim();
        if (!key || !m.public_url) return;
        const sep = m.public_url.includes("?") ? "&" : "?";
        map[key] = m.updated_at ? `${m.public_url}${sep}v=${encodeURIComponent(m.updated_at)}` : m.public_url;
      });
      return map;
    },
    enabled: cdpars.length > 0,
    staleTime: 60_000,
  });
  const thumbs = mediaMap ?? {};

  const virtualizer = useVirtualizer({
    count: displayArticles.length,
    getScrollElement: () => scrollRef.current,
    estimateSize: () => ROW_HEIGHT,
    overscan: 10,
  });

  useEffect(() => {
    const focusHandler = () => searchRef.current?.focus();
    document.addEventListener("pim:focus-search", focusHandler);
    return () => { document.removeEventListener("pim:focus-search", focusHandler); };
  }, []);

  const handleRowClick = useCallback((cdpar: string) => navigate(`/pim/articles/${encodeURIComponent(cdpar)}`), [navigate]);

  const hasFilters = search || clmer.length > 0 || reparto.length > 0 || gamma.length > 0 || wfuas.length > 0 || pcfor.length > 0 || clas2.length > 0 || promoWp.length > 0 || temaIds.length > 0 || availabilityFilter !== "all" || b2bFilter !== "all" || (bulkCdpars && bulkCdpars.length > 0);

  const resetFilters = () => {
    setSearch(""); setClmer([]); setReparto([]); setGamma([]); setWfuas([]); setPcfor([]); setClas2([]);
    setPromoWp([]); setTemaIds([]); setAvailabilityFilter("all"); setB2bFilter("all"); setBulkCdpars(null); setPage(0);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center gap-2 px-4 py-2.5 border-b shrink-0">

        {/* Filters */}
        <div className="flex items-center gap-1.5">
          <MultiSelectFilter
            label="Settore"
            options={clmerOptions}
            selected={clmer}
            onChange={(v) => { setClmer(v); setReparto([]); setGamma([]); setPage(0); }}
            searchable
          />
          <MultiSelectFilter
            label="Reparto"
            options={repartoOptions}
            selected={reparto}
            onChange={(v) => { setReparto(v); setGamma([]); setPage(0); }}
            searchable
          />
          <MultiSelectFilter
            label="Gamma"
            options={gammaOptions}
            selected={gamma}
            onChange={(v) => { setGamma(v); setPage(0); }}
            searchable
          />
          <MultiSelectFilter
            label="Assortimento"
            options={wfuasOptions}
            selected={wfuas}
            onChange={(v) => { setWfuas(v); setPage(0); }}
          />
          <MultiSelectFilter
            label="Fornitore"
            options={pcforOptions}
            selected={pcfor}
            onChange={(v) => { setPcfor(v); setPage(0); }}
            searchable
          />
          <MultiSelectFilter
            label="Brand"
            options={clas2Options}
            selected={clas2}
            onChange={(v) => { setClas2(v); setPage(0); }}
            searchable
          />
          <MultiSelectFilter
            label="Promo"
            options={promoOptions}
            selected={promoWp.map(String)}
            onChange={(v) => { setPromoWp(v.map((x) => Number(x))); setTemaIds([]); setPage(0); }}
            searchable
          />
          <MultiSelectFilter
            label="Offerta"
            options={temaOptions}
            selected={temaIds}
            onChange={(v) => { setTemaIds(v); setPage(0); }}
            searchable
          />
          {/* Toggle Disponibilità: grigio → verde → rosso */}
          {(() => {
            const v = availabilityFilter;
            const cycle = () => { setAvailabilityFilter(v === "all" ? "available" : v === "available" ? "unavailable" : "all"); setPage(0); };
            const cls = v === "available"
              ? "bg-emerald-600 text-white border-emerald-600 hover:bg-emerald-700"
              : v === "unavailable"
              ? "bg-rose-600 text-white border-rose-600 hover:bg-rose-700"
              : "bg-background text-foreground hover:bg-accent";
            return (
              <button
                type="button"
                onClick={cycle}
                className={`h-8 px-2.5 rounded-md border text-xs font-medium transition-colors ${cls}`}
                title="Tutti → Disponibili (verde) → Non disponibili (rosso)"
              >
                Disponibili
              </button>
            );
          })()}
          {/* Toggle B2B: grigio → verde → rosso */}
          {(() => {
            const v = b2bFilter;
            const cycle = () => { setB2bFilter(v === "all" ? "online" : v === "online" ? "offline" : "all"); setPage(0); };
            const cls = v === "online"
              ? "bg-emerald-600 text-white border-emerald-600 hover:bg-emerald-700"
              : v === "offline"
              ? "bg-rose-600 text-white border-rose-600 hover:bg-rose-700"
              : "bg-background text-foreground hover:bg-accent";
            return (
              <button
                type="button"
                onClick={cycle}
                className={`h-8 px-2.5 rounded-md border text-xs font-medium transition-colors ${cls}`}
                title="Tutti → Online B2B (verde) → Offline B2B (rosso)"
              >
                Online B2B
              </button>
            );
          })()}
          {hasFilters && (
            <Button variant="ghost" size="sm" className="h-8 text-xs px-2" onClick={resetFilters}>
              Azzera
            </Button>
          )}
        </div>

        {/* Right: Actions + pagination */}
        <div className="ml-auto flex items-center gap-2">
          {bulkCdpars && bulkCdpars.length > 0 && (
            <Badge variant="secondary" className="h-7 gap-1 pr-1">
              <ListChecks className="h-3 w-3" />
              Elenco codici ({bulkCdpars.length})
              <button
                type="button"
                onClick={() => { setBulkCdpars(null); setPage(0); }}
                className="ml-0.5 rounded hover:bg-background/60 p-0.5"
                title="Rimuovi filtro elenco"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          )}

          <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => setBulkOpen(true)}>
            <ListChecks className="mr-1.5 h-3.5 w-3.5" /> Cerca da elenco
          </Button>

          <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => setExportOpen(true)}>
            <Download className="mr-1.5 h-3.5 w-3.5" /> Esporta
          </Button>



          {canCreateNewArticle && (
          <Dialog open={newDialogOpen} onOpenChange={setNewDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="h-8 text-xs">
                <Plus className="mr-1 h-3.5 w-3.5" /> Nuovo
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Nuovo Articolo</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div>
                  <Label className="text-xs">Codice Articolo (max 15 car.)</Label>
                  <Input
                    value={newCdpar}
                    onChange={(e) => setNewCdpar(e.target.value.toUpperCase().slice(0, 15))}
                    className="h-8 text-sm font-mono"
                    placeholder="es. 001234"
                  />
                  {isArticleDuplicate && (
                    <p className="text-xs text-destructive flex items-center gap-1 mt-1">
                      <AlertCircle className="h-3 w-3" /> Articolo già esistente
                    </p>
                  )}
                </div>
                <div>
                  <Label className="text-xs">Descrizione</Label>
                  <Input
                    value={newDepar}
                    onChange={(e) => setNewDepar(e.target.value)}
                    className="h-8 text-sm"
                    placeholder="Descrizione articolo"
                  />
                </div>
              </div>
              <DialogFooter>
                <DialogClose asChild><Button variant="outline" size="sm">Annulla</Button></DialogClose>
                <Button size="sm" onClick={() => createArticleMutation.mutate()} disabled={!canCreateArticle || createArticleMutation.isPending}>
                  Crea
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          )}

          <div className="h-5 w-px bg-border mx-1" />

          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            {isFetching && <span className="text-primary animate-pulse text-[10px]">●</span>}
            <span className="tabular-nums">{totalCount.toLocaleString("it-IT")}</span>
            <Button variant="ghost" size="icon" className="h-7 w-7" disabled={page === 0} onClick={() => setPage(page - 1)}>
              <ChevronLeft className="h-3.5 w-3.5" />
            </Button>
            <span className="tabular-nums">{page + 1}/{totalPages || 1}</span>
            <Button variant="ghost" size="icon" className="h-7 w-7" disabled={page >= totalPages - 1} onClick={() => setPage(page + 1)}>
              <ChevronRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Column headers */}
      <div className="flex items-center border-b bg-muted/50 text-[11px] font-medium text-muted-foreground px-4 shrink-0" style={{ height: 32 }}>
        {COLUMNS.map((col) => {
          const active = col.sortKey && sortKey === col.sortKey;
          const Icon = !col.sortKey ? null : !active ? ArrowUpDown : sortDir === "asc" ? ArrowUp : ArrowDown;
          return (
            <div key={col.key} className={`${col.cls} px-1.5 truncate`}>
              {col.sortKey ? (
                <button
                  type="button"
                  onClick={() => toggleSort(col.sortKey!)}
                  className={`inline-flex items-center gap-1 hover:text-foreground ${active ? "text-foreground" : ""}`}
                >
                  {col.label}
                  {Icon && <Icon className={`h-3 w-3 ${active ? "" : "opacity-40"}`} />}
                </button>
              ) : col.label}
            </div>
          );
        })}
      </div>

      {/* Rows */}
      <div ref={scrollRef} className="overflow-y-auto flex-1">
        {isLoading && filteredArticles.length === 0 ? (
          <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">Caricamento...</div>
        ) : filteredArticles.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
            <Package className="h-10 w-10 text-muted-foreground/30 mb-3" />
            <p className="font-medium text-sm">Nessun articolo trovato</p>
            <p className="text-xs mt-1">Prova a modificare i filtri di ricerca</p>
            {hasFilters && (
              <Button variant="outline" size="sm" className="mt-3" onClick={resetFilters}>
                Azzera filtri
              </Button>
            )}
          </div>
        ) : (
          <div style={{ height: virtualizer.getTotalSize(), width: "100%", position: "relative" }}>
            {virtualizer.getVirtualItems().map((vRow) => {
              const article = displayArticles[vRow.index] as Record<string, any>;
              const attrs = article.attributes ?? {};
              const articleCdpar = (article.cdpar ?? "").trim();
              return (
                <div
                  key={vRow.key}
                  data-index={vRow.index}
                  className={`absolute left-0 right-0 flex items-center px-4 text-xs border-b cursor-pointer transition-colors hover:bg-accent/50 ${vRow.index % 2 === 1 ? "bg-muted/20" : ""}`}
                  style={{ height: ROW_HEIGHT, transform: `translateY(${vRow.start}px)` }}
                  onClick={() => handleRowClick(articleCdpar)}
                >
                  <div className="w-[40px] px-1 flex items-center justify-center">
                    {thumbs[articleCdpar] ? (
                      <img src={thumbs[articleCdpar]} alt="" className="h-7 w-7 rounded object-cover" loading="lazy" />
                    ) : (
                      <div className="h-7 w-7 rounded bg-muted flex items-center justify-center">
                        <ImageIcon className="h-3 w-3 text-muted-foreground/40" />
                      </div>
                    )}
                  </div>
                  <div className="w-[70px] px-1.5 truncate font-mono">{articleCdpar}</div>
                  <div className="w-[50px] px-1.5 truncate text-right tabular-nums">
                    {(() => {
                      const q = getStock(articleCdpar);
                      if (q === undefined) return <span className="text-muted-foreground/40">—</span>;
                      const cls = q > 0 ? "text-green-600" : q < 0 ? "text-red-600" : "text-muted-foreground";
                      return <span className={cls}>{q.toLocaleString("it-IT")}</span>;
                    })()}
                  </div>
                  <div className="flex-1 min-w-[180px] px-1.5 truncate">{article.depar}</div>
                  <div className="w-[120px] px-1.5 truncate">{clmerMap[article.clmer] || article.clmer}</div>
                  <div className="w-[120px] px-1.5 truncate">{repartoMap[attrs.reparto] || attrs.reparto || ""}</div>
                  <div className="w-[100px] px-1.5 truncate">{gammaMap[attrs.gamma] || attrs.gamma || ""}</div>
                  <div className="w-[70px] px-1.5 truncate">{article.wfuas}</div>
                  <div className="w-[45px] px-1.5 truncate">{article.unmis}</div>
                  <div className="w-[75px] px-1.5 truncate font-mono">{article.pcfor?.trim()}</div>
                  <div className="w-[150px] px-1.5 truncate">{supplierMap[article.pcfor?.trim()] || ""}</div>
                  <div className="w-[70px] px-1.5">
                    {(() => {
                      const isOnline = computeIsB2bOnline(article.b2b_online_active, article.wfuas, onlineAssortments);
                      const manual = article.b2b_online_active === true || article.b2b_online_active === false;
                      const title = isOnline
                        ? (manual ? "Forzato online manualmente" : `Auto: wfuas ${article.wfuas} è online`)
                        : (manual ? "Forzato offline manualmente" : `Auto: wfuas ${article.wfuas ?? "—"} non è online`);
                      return (
                        <span title={title} className="inline-flex items-center gap-1">
                          <span className={`inline-block h-2.5 w-2.5 rounded-full ${isOnline ? "bg-green-500" : "bg-red-500"}`} />
                          {manual && <span className="text-[10px] text-muted-foreground">*</span>}
                        </span>
                      );
                    })()}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <ExportModal
        open={exportOpen}
        onClose={() => setExportOpen(false)}
        totalCount={totalCount}
        filters={{
          search: debouncedSearch,
          clmer: clmer.length > 0 ? clmer : undefined,
          lipro: undefined,
          wfuas: wfuas.length > 0 ? wfuas : undefined,
          pcfor: pcfor.length > 0 ? pcfor : undefined,
          reparto: reparto.length > 0 ? reparto : undefined,
          gamma: gamma.length > 0 ? gamma : undefined,
          clas2: clas2.length > 0 ? clas2 : undefined,
          cdpars: effectiveCdpars,
          availability: availabilityFilter !== "all" ? availabilityFilter : undefined,
          b2bOnline: b2bFilter !== "all" ? b2bFilter : undefined,
          visibleAssortments,
        }}
      />

      <BulkSearchDialog
        open={bulkOpen}
        onClose={() => setBulkOpen(false)}
        onConfirm={(codes) => { setBulkCdpars(codes.length > 0 ? codes : null); setPage(0); }}
        initialCodes={bulkCdpars}
      />
    </div>
  );
}

import { useGammaAttributes, GammaAttribute, deriveDisplayName } from "@/hooks/useGammaAttributes";
import { useLookupValues } from "@/hooks/useLookupValues";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface GammaAttrValues {
  [attrName: string]: { value: string; unit: string };
}

interface Props {
  gammaCode: string;
  currentValues: GammaAttrValues;
  onChange: (values: GammaAttrValues) => void;
  readOnly?: boolean;
}

export function GammaAttributeFields({ gammaCode, currentValues, onChange, readOnly }: Props) {
  const { data: attributes = [], isLoading } = useGammaAttributes(gammaCode);

  if (isLoading) return null;
  if (attributes.length === 0) return null;

  const handleChange = (attrName: string, field: "value" | "unit", val: string) => {
    const prev = currentValues[attrName] ?? { value: "", unit: "" };
    onChange({
      ...currentValues,
      [attrName]: { ...prev, [field]: val },
    });
  };

  return (
    <div className="mt-4 space-y-1.5">
      <div className="flex items-center gap-2">
        <Label className="text-xs text-blue-600 font-semibold">Attributi Gamma</Label>
        <Badge variant="outline" className="text-[9px] h-4 border-primary/50 text-primary">PIM</Badge>
      </div>
      <div className="space-y-2">
        {attributes.map((attr) => (
          <AttributeRow
            key={attr.id}
            attr={attr}
            value={currentValues[attr.attribute_name] ?? { value: "", unit: "" }}
            onChange={(field, v) => handleChange(attr.attribute_name, field, v)}
            readOnly={readOnly}
          />
        ))}
      </div>
    </div>
  );
}

function AttributeRow({
  attr, value, onChange, readOnly,
}: {
  attr: GammaAttribute;
  value: { value: string; unit: string };
  onChange: (field: "value" | "unit", v: string) => void;
  readOnly?: boolean;
}) {
  // Variants from lookup_values (preferred) or legacy options
  const { data: lookupOpts = [] } = useLookupValues(attr.lookup_category ?? undefined);
  const variantSource = attr.lookup_category && lookupOpts.length > 0
    ? lookupOpts.map((o) => ({ value: o.code, label: o.label || o.code }))
    : attr.options.map((o) => ({ value: o.option_value, label: o.option_label || o.option_value }));

  const showError = attr.is_required && !value.value.trim();
  const label = attr.display_name || deriveDisplayName(attr.attribute_name);

  return (
    <div className="flex items-center gap-2">
      <span
        className={`text-[11px] w-[160px] shrink-0 truncate ${attr.is_required ? "font-semibold" : ""}`}
        title={attr.attribute_name}
      >
        {label}
        {attr.is_required && <span className="text-destructive ml-0.5">*</span>}
      </span>

      {/* Unit selector (legacy menu UM) */}
      {attr.has_unit_select && attr.options.length > 0 && (
        readOnly ? (
          <Input value={value.unit} readOnly className="h-8 text-sm w-20 bg-muted" />
        ) : (
          <Select
            value={value.unit || "__empty__"}
            onValueChange={(v) => onChange("unit", v === "__empty__" ? "" : v)}
          >
            <SelectTrigger className="h-8 text-sm w-20">
              <SelectValue placeholder="UM" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__empty__">—</SelectItem>
              {attr.options.map((opt) => (
                <SelectItem key={opt.id} value={opt.option_value}>
                  {opt.option_label || opt.option_value}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )
      )}

      {/* Value: dropdown if variants exist, otherwise free text */}
      {variantSource.length > 0 ? (
        readOnly ? (
          <Input value={value.value} readOnly className={`h-8 text-sm flex-1 bg-muted ${showError ? "border-destructive" : ""}`} />
        ) : (
          <Select
            value={value.value || "__empty__"}
            onValueChange={(v) => onChange("value", v === "__empty__" ? "" : v)}
          >
            <SelectTrigger className={`h-8 text-sm flex-1 ${showError ? "border-destructive" : ""}`}>
              <SelectValue placeholder="Seleziona…" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__empty__">— Vuoto —</SelectItem>
              {variantSource.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )
      ) : (
        <Input
          value={value.value}
          onChange={(e) => onChange("value", e.target.value)}
          readOnly={readOnly}
          placeholder="Valore..."
          className={`h-8 text-sm flex-1 ${readOnly ? "bg-muted" : ""} ${showError ? "border-destructive" : ""}`}
        />
      )}
    </div>
  );
}

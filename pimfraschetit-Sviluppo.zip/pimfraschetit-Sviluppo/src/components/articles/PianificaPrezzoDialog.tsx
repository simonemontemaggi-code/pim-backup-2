import { useState, useMemo } from "react";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import { jsDateToAs400, as400DateToDisplay } from "@/lib/dateUtils";
import { useUpsertPrezzoInAttesa, usePrezziInAttesa } from "@/hooks/usePrezziInAttesa";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { exportAs400Change, buildAs400Payload, downloadAs400Json } from "@/lib/as400Export";

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  cdpar: string;
  wcdls: string;
  wcdca: string | null;
  currentPrice: number | null;
  newPrice: number;
  wsm01: number | null;
  wsm02: number | null;
  /** Criterio row id — required for immediate update of wsm01/wsm02 */
  criterioId?: string | null;
  /** Original wsm01/wsm02 — used to detect if criteri must be updated immediately */
  originalWsm01?: number | null;
  originalWsm02?: number | null;
  onSuccess?: () => void;
}

export function PianificaPrezzoDialog({
  open, onOpenChange, cdpar, wcdls, wcdca, currentPrice, newPrice,
  wsm01, wsm02, criterioId, originalWsm01, originalWsm02, onSuccess,
}: Props) {
  const tomorrow = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    d.setHours(0, 0, 0, 0);
    return d;
  }, []);
  const today = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  }, []);

  const [immediate, setImmediate] = useState(false);
  const [date, setDate] = useState<Date>(tomorrow);
  const upsert = useUpsertPrezzoInAttesa(cdpar);
  const { data: existing = [] } = usePrezziInAttesa(cdpar, wcdls, wcdca);
  const qc = useQueryClient();
  const { user, profile } = useAuth();

  const todayStr = jsDateToAs400(new Date());
  const futureExisting = existing.filter((e) => (e.wdtin ?? "") >= todayStr);

  const handleSave = async () => {
    // ---------- IMMEDIATE PATH: update prmil + criteri, no prezzi_in_attesa ----------
    if (immediate) {
      try {
        const changes: { table: string; change: any }[] = [];

        // 1. Update prmil in listini_vendita_dettagli
        const { error: dErr } = await supabase
          .from("listini_vendita_dettagli" as any)
          .update({ prmil: newPrice } as any)
          .eq("cdarl", cdpar)
          .eq("cdlsl", wcdls);
        if (dErr) throw dErr;
        changes.push({
          table: "listini_vendita_dettagli",
          change: {
            operation: "update",
            key: { cdarl: cdpar, cdlsl: wcdls },
            fields: { prmil: newPrice },
          },
        });

        // 2. Update wsm01/wsm02 in criteri if changed
        const sm01Changed = originalWsm01 != null && wsm01 != null && Number(originalWsm01) !== Number(wsm01);
        const sm02Changed = originalWsm02 != null && wsm02 != null && Number(originalWsm02) !== Number(wsm02);
        if (criterioId && (sm01Changed || sm02Changed)) {
          const critFields: Record<string, any> = {};
          if (sm01Changed) critFields.wsm01 = wsm01;
          if (sm02Changed) critFields.wsm02 = wsm02;
          const { error: cErr } = await supabase
            .from("listini_vendita_criteri_prezzo")
            .update(critFields as any)
            .eq("id", criterioId);
          if (cErr) throw cErr;
          changes.push({
            table: "listini_vendita_criteri_prezzo",
            change: {
              operation: "update",
              key: { wcdpa: cdpar, wcdls },
              fields: critFields,
            },
          });
        }

        // 3. Download AS400 JSON (no prezzi_in_attesa entry)
        downloadAs400Json(
          buildAs400Payload({
            user: profile?.email ?? user?.email,
            record: cdpar,
            changes,
          }),
          "as400_prezzo_immediato",
        );

        toast({ title: "Prezzo aggiornato", description: "Il nuovo prezzo è in vigore da subito." });
        qc.invalidateQueries({ queryKey: ["sales_price_dettagli", cdpar] });
        qc.invalidateQueries({ queryKey: ["sales_price_criteria", cdpar] });
        qc.invalidateQueries({ queryKey: ["criterio_for_pianifica", cdpar] });
        onOpenChange(false);
        onSuccess?.();
      } catch (e: any) {
        toast({ title: "Errore", description: e.message, variant: "destructive" });
      }
      return;
    }

    // ---------- SCHEDULED PATH: insert into prezzi_in_attesa ----------
    if (!date) {
      toast({ title: "Data richiesta", variant: "destructive" });
      return;
    }
    const wdtin = jsDateToAs400(date);
    if (wdtin <= todayStr) {
      toast({ title: "Data non valida", description: "Deve essere futura, oppure usa Applica subito.", variant: "destructive" });
      return;
    }
    const conflict = futureExisting.find((e) => e.wdtin === wdtin);
    if (conflict) {
      toast({
        title: "Pianificazione esistente",
        description: `Esiste già un prezzo pianificato per il ${as400DateToDisplay(wdtin)}. Modificalo nella tabella Prezzi in Attesa.`,
        variant: "destructive",
      });
      return;
    }
    try {
      await upsert.mutateAsync({
        wcdpa: cdpar,
        wcdls,
        wcdca,
        wprun: newPrice,
        wprui: newPrice,
        wsm01,
        wsm02,
        wdtin,
      });
      toast({ title: "Pianificato", description: `Nuovo prezzo in vigore dal ${as400DateToDisplay(wdtin)}.` });
      onOpenChange(false);
      onSuccess?.();
    } catch (e: any) {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Modifica prezzo di listino</DialogTitle>
          <DialogDescription>
            {immediate
              ? "Il prezzo verrà aggiornato subito (prmil) e i criteri ricarico se modificati. Nessuna pianificazione."
              : "Verrà creato un record in Prezzi in Attesa che entrerà in vigore alla data scelta."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-md border p-3 bg-muted/30">
              <div className="text-xs text-muted-foreground uppercase tracking-wide">Prezzo attuale</div>
              <div className="text-lg font-mono">
                {currentPrice != null ? currentPrice.toFixed(2).replace(".", ",") : "—"}
              </div>
            </div>
            <div className="rounded-md border p-3 bg-primary/10 border-primary/30">
              <div className="text-xs text-muted-foreground uppercase tracking-wide">Nuovo prezzo</div>
              <div className="text-lg font-mono font-semibold text-primary">
                {newPrice.toFixed(2).replace(".", ",")}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between rounded-md border p-3">
            <div>
              <Label htmlFor="immediate-toggle" className="cursor-pointer">Applica subito (oggi)</Label>
              <p className="text-xs text-muted-foreground mt-0.5">
                Aggiorna direttamente prmil e i criteri (no Prezzi in Attesa).
              </p>
            </div>
            <Switch id="immediate-toggle" checked={immediate} onCheckedChange={setImmediate} />
          </div>

          {!immediate && (
            <div className="space-y-2">
              <Label>Data inizio validità</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "dd/MM/yyyy") : <span>Seleziona data</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={(d) => d && setDate(d)}
                    disabled={(d) => d <= today}
                    initialFocus
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
            </div>
          )}

          {!immediate && futureExisting.length > 0 && (
            <div className="text-xs text-muted-foreground border-l-2 border-warning pl-2">
              Esistono già {futureExisting.length} pianificazione/i futura/e:{" "}
              {futureExisting.map((e) => as400DateToDisplay(e.wdtin)).join(", ")}.
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Annulla</Button>
          <Button onClick={handleSave} disabled={upsert.isPending}>
            {upsert.isPending ? "Salvataggio..." : immediate ? "Applica subito" : "Pianifica"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

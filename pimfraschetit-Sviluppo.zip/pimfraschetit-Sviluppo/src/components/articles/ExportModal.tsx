import { useState, useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "@/hooks/use-toast";
import { Download } from "lucide-react";
import Papa from "papaparse";
import * as XLSX from "xlsx";
import { computeIsB2bOnline, buildOnlineB2bOrFilter } from "@/hooks/useOnlineAssortments";
import { computeNetPrice } from "@/lib/priceUtils";

export interface ExportFilters {
  search?: string;
  clmer?: string[];
  lipro?: string[];
  wfuas?: string[];
  pcfor?: string[];
  reparto?: string[];
  gamma?: string[];
  clas2?: string[];
  cdpars?: string[]; // pre-computed cdpar list (e.g. from promo/tema filter)
  availability?: "all" | "available" | "unavailable";
  b2bOnline?: "all" | "online" | "offline";
  visibleAssortments?: string[];
}

interface Props {
  open: boolean;
  onClose: () => void;
  totalCount: number;
  filters?: ExportFilters;
}

const COLUMN_GROUPS = [
  {
    label: "ANAGRAFICA",
    columns: [
      { key: "cdpar", label: "Codice", default: true },
      { key: "depar", label: "Descrizione", default: true },
      { key: "nmcat", label: "Catalogo", default: true },
      { key: "clmer", label: "Settore (clmer)", default: true },
      { key: "reparto", label: "Reparto", default: false },
      { key: "gamma", label: "Gamma", default: false },
      { key: "lipro", label: "Linea", default: true },
      { key: "cdst1", label: "Stato", default: true },
      { key: "clas1", label: "Classe 1", default: true },
      { key: "clas2", label: "Brand (clas2)", default: true },
      { key: "nmdis", label: "Linea Brand", default: false },
      { key: "cdiva", label: "IVA", default: true },
      { key: "pcfor", label: "Fornitore", default: true },
    ],
  },
  {
    label: "ACQUISTO",
    columns: [
      { key: "netto_acquisto", label: "Netto Acquisto €", default: false },
    ],
  },
  {
    label: "UM & VENDITA",
    columns: [
      { key: "unmis", label: "UM", default: true },
      { key: "untec", label: "UM Tecnica", default: true },
      { key: "umfat", label: "Fatt. conv.", default: false },
      { key: "umalt", label: "UM alt.", default: false },
      { key: "wimba", label: "Imballo", default: false },
    ],
  },
  {
    label: "STATO",
    columns: [
      { key: "wfuas", label: "Assortimento", default: true },
      { key: "b2b_online", label: "B2B", default: true },
      { key: "as400_sync_status", label: "Sync Status", default: true },
      { key: "updated_at", label: "Ultimo aggiorn.", default: true },
    ],
  },
  {
    label: "LISTINO 01",
    columns: [
      { key: "listino_01_ricarico", label: "Ricarico % (wsm01)", default: false },
      { key: "listino_01_prezzo", label: "Prezzo finale", default: false },
    ],
  },
];

const PAD6_COLUMNS = new Set(["cdpar"]);
const BATCH = 1000;

function hasAnyFilter(f?: ExportFilters): boolean {
  if (!f) return false;
  return Boolean(
    (f.search && f.search.trim().length >= 1) ||
    (f.clmer && f.clmer.length) ||
    (f.lipro && f.lipro.length) ||
    (f.wfuas && f.wfuas.length) ||
    (f.pcfor && f.pcfor.length) ||
    (f.reparto && f.reparto.length) ||
    (f.gamma && f.gamma.length) ||
    (f.clas2 && f.clas2.length) ||
    (Array.isArray(f.cdpars)) ||
    (f.availability && f.availability !== "all") ||
    (f.b2bOnline && f.b2bOnline !== "all")
  );
}

function expandPcfor(pcfor: string[]): string[] {
  return Array.from(
    new Set(pcfor.flatMap((c) => {
      const t = c.trim();
      return [t, t.padEnd(6, " ")];
    }))
  );
}

function expandClas2(clas2: string[]): string[] {
  return Array.from(
    new Set(clas2.flatMap((c) => {
      const t = c.trim();
      return [t, t.padEnd(6, " ")];
    }))
  );
}

function expandCdpars(cdpars: string[]): string[] {
  const out = new Set<string>();
  for (const c of cdpars) {
    if (!c) continue;
    const trimmed = c.trim();
    if (!trimmed) continue;
    const variants = new Set<string>([trimmed]);
    if (/^\d+$/.test(trimmed) && trimmed.length < 6) {
      variants.add(trimmed.padStart(6, "0"));
    }
    for (const v of variants) {
      out.add(v);
      out.add(v.padEnd(15, " "));
    }
    out.add(c);
  }
  return Array.from(out);
}

/** Apply server-side filters (everything except reparto/gamma which are JSONB attrs, and availability which is client-side).
 * b2bOnline="online" is applied server-side using the online_assortments list.
 * b2bOnline="offline" stays client-side (the NOT IN condition is awkward via PostgREST). */
function applyServerFilters(query: any, f: ExportFilters, onlineAssortments: string[] = []) {
  const { search, clmer, lipro, wfuas, pcfor, clas2, cdpars, visibleAssortments, b2bOnline } = f;

  if (search && search.trim().length >= 1) {
    const s = search.trim().replace(/[%,]/g, "");
    query = query.or(`cdpar.ilike.%${s}%,depar.ilike.%${s}%`);
  }

  // visible assortments intersected with wfuas filter
  if (visibleAssortments && visibleAssortments.length > 0) {
    if (wfuas && wfuas.length > 0) {
      const intersection = wfuas.filter((v) => visibleAssortments.includes(v));
      query = query.in("wfuas", intersection.length > 0 ? intersection : ["__none__"]);
    } else {
      query = query.in("wfuas", visibleAssortments);
    }
  } else if (wfuas && wfuas.length > 0) {
    query = query.in("wfuas", wfuas);
  }

  if (clmer && clmer.length > 0) query = query.in("clmer", clmer);
  if (lipro && lipro.length > 0) query = query.in("lipro", lipro);
  if (pcfor && pcfor.length > 0) query = query.in("pcfor", expandPcfor(pcfor));
  if (clas2 && clas2.length > 0) query = query.in("clas2", expandClas2(clas2));

  if (Array.isArray(cdpars)) {
    // filtro cdpar (bulk paste / promo): normalizza per il pad DB
    const expanded = cdpars.length > 0 ? expandCdpars(cdpars) : ["__none__"];
    query = query.in("cdpar", expanded);
  }

  // b2b online: applica server-side quando modalità = "online"
  if (b2bOnline === "online") {
    query = query.or(buildOnlineB2bOrFilter(onlineAssortments));
  }

  return query;
}

function applyAttrFilter(rows: any[], f: ExportFilters): any[] {
  let out = rows;
  if (f.reparto && f.reparto.length > 0) {
    const set = new Set(f.reparto);
    out = out.filter((r) => r.attributes?.reparto && set.has(r.attributes.reparto));
  }
  if (f.gamma && f.gamma.length > 0) {
    const set = new Set(f.gamma);
    out = out.filter((r) => r.attributes?.gamma && set.has(r.attributes.gamma));
  }
  return out;
}

export function ExportModal({ open, onClose, totalCount, filters }: Props) {
  const filtersActive = hasAnyFilter(filters);
  const hasVisibleAssortments = Boolean(filters?.visibleAssortments && filters.visibleAssortments.length > 0);
  const [scope, setScope] = useState<"all" | "filtered" | "online">(filtersActive ? "filtered" : "all");
  const [format, setFormat] = useState<"csv" | "xlsx">("xlsx");
  const [selectedCols, setSelectedCols] = useState<Set<string>>(
    new Set(COLUMN_GROUPS.flatMap((g) => g.columns.filter((c) => c.default).map((c) => c.key)))
  );
  const [exporting, setExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [dbTotalCount, setDbTotalCount] = useState<number | null>(null);
  const [filteredCount, setFilteredCount] = useState<number | null>(null);
  const [onlineCount, setOnlineCount] = useState<number | null>(null);
  const [onlineAssortments, setOnlineAssortments] = useState<string[]>([]);

  const needsAttrScan = useMemo(
    () => Boolean(
      filters?.reparto?.length ||
      filters?.gamma?.length ||
      (filters?.availability && filters.availability !== "all") ||
      // offline b2b resta client-side → count approssimato
      (filters?.b2bOnline === "offline")
    ),
    [filters?.reparto, filters?.gamma, filters?.availability, filters?.b2bOnline]
  );

  // Fetch real total + filtered count when modal opens
  useEffect(() => {
    if (!open) return;
    setDbTotalCount(null);
    setFilteredCount(null);
    setOnlineCount(null);
    setScope(filtersActive ? "filtered" : "all");

    supabase
      .from("archivio_articoli_fraschetti")
      .select("id", { count: "exact", head: true })
      .then(({ count }) => setDbTotalCount(count ?? 0));

    // load online_assortments once, then compute filtered count
    (async () => {
      const { data: setting } = await supabase
        .from("app_settings")
        .select("setting_value")
        .eq("setting_key", "online_assortments")
        .maybeSingle();
      const val = setting?.setting_value;
      const list = Array.isArray(val) ? (val as string[]) : [];
      setOnlineAssortments(list);

      if (filtersActive && filters) {
        let q: any = supabase
          .from("archivio_articoli_fraschetti")
          .select("id", { count: "exact", head: true });
        q = applyServerFilters(q, filters, list);
        const { count } = await q;
        setFilteredCount(count ?? 0);
      }
    })();

    if (hasVisibleAssortments) {
      supabase
        .from("archivio_articoli_fraschetti")
        .select("id", { count: "exact", head: true })
        .in("wfuas", filters!.visibleAssortments!)
        .then(({ count }) => setOnlineCount(count ?? 0));
    }
  }, [open, filtersActive, filters, hasVisibleAssortments]);

  const realTotalCount = dbTotalCount ?? totalCount;

  const toggleCol = (key: string) => {
    setSelectedCols((prev) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  };

  const toggleGroup = (group: typeof COLUMN_GROUPS[0], allSelected: boolean) => {
    setSelectedCols((prev) => {
      const next = new Set(prev);
      group.columns.forEach((c) => allSelected ? next.delete(c.key) : next.add(c.key));
      return next;
    });
  };

  const handleExport = async () => {
    setExporting(true);
    setProgress(0);
    const cols = Array.from(selectedCols);
    const wantsB2b = cols.includes("b2b_online");
    const wantsRicarico = cols.includes("listino_01_ricarico");
    const wantsPrezzo = cols.includes("listino_01_prezzo");
    const wantsListino = wantsRicarico || wantsPrezzo;
    const wantsReparto = cols.includes("reparto");
    const wantsGamma = cols.includes("gamma");
    const wantsAttrCols = wantsReparto || wantsGamma;
    const wantsNetto = cols.includes("netto_acquisto");
    // virtual cols are not real DB fields
    const VIRTUAL_COLS = new Set([
      "b2b_online",
      "listino_01_ricarico",
      "listino_01_prezzo",
      "reparto",
      "gamma",
      "netto_acquisto",
    ]);
    const dbCols = cols.filter((c) => !VIRTUAL_COLS.has(c));
    if (wantsB2b) {
      if (!dbCols.includes("b2b_online_active")) dbCols.push("b2b_online_active");
      if (!dbCols.includes("wfuas")) dbCols.push("wfuas");
    }
    if (wantsListino && !dbCols.includes("cdpar")) dbCols.push("cdpar");
    if (wantsNetto) {
      if (!dbCols.includes("cdpar")) dbCols.push("cdpar");
      if (!dbCols.includes("pcfor")) dbCols.push("pcfor");
    }

    // client-side filter flags (only when scope==="filtered")
    // Nota: b2bOnline="online" ora è applicato server-side dentro applyServerFilters.
    // Solo "offline" resta client-side (NOT IN awkward via PostgREST).
    const clientB2bOffline = scope === "filtered" && filters?.b2bOnline === "offline";
    const clientAvail = scope === "filtered" && filters?.availability && filters.availability !== "all";

    // ensure helper cols for client-side filters
    if (clientB2bOffline) {
      if (!dbCols.includes("b2b_online_active")) dbCols.push("b2b_online_active");
      if (!dbCols.includes("wfuas")) dbCols.push("wfuas");
    }
    if (clientAvail && !dbCols.includes("cdpar")) dbCols.push("cdpar");

    // ensure attributes is fetched if we need to filter by / export reparto-gamma
    const needAttrs = Boolean(
      (scope === "filtered" && (filters?.reparto?.length || filters?.gamma?.length)) || wantsAttrCols
    );
    const selectCols = needAttrs && !dbCols.includes("attributes")
      ? [...dbCols, "attributes"].join(", ")
      : dbCols.join(", ");

    // online_assortments già caricati all'apertura del modal
    let allRows: any[] = [];
    let offset = 0;
    // approximate target for progress
    const target =
      scope === "filtered" ? (filteredCount ?? realTotalCount) :
      scope === "online" ? (onlineCount ?? realTotalCount) :
      realTotalCount;

    try {
      while (true) {
        let q: any = supabase
          .from("archivio_articoli_fraschetti")
          .select(selectCols)
          .order("cdpar")
          .range(offset, offset + BATCH - 1);

        if (scope === "filtered" && filters) {
          q = applyServerFilters(q, filters, onlineAssortments);
        } else if (scope === "online" && hasVisibleAssortments) {
          q = q.in("wfuas", filters!.visibleAssortments!);
        }

        const { data, error } = await q;
        if (error) throw error;
        const batch = data ?? [];
        const needAttrFilter = scope === "filtered" && Boolean(filters?.reparto?.length || filters?.gamma?.length);
        let filtered: any[] = needAttrFilter ? applyAttrFilter(batch, filters!) : batch;

        // client-side: b2b offline filter
        if (clientB2bOffline) {
          filtered = filtered.filter((r) =>
            !computeIsB2bOnline(r.b2b_online_active, r.wfuas, onlineAssortments)
          );
        }

        allRows = allRows.concat(filtered);

        if (target > 0) {
          setProgress(Math.min(100, ((offset + batch.length) / target) * 100));
        }

        if (batch.length < BATCH) break;
        offset += BATCH;
      }

      // client-side: availability filter (needs stock lookup in bulk)
      if (clientAvail) {
        const wantAvail = filters!.availability === "available";
        const cdparKeys = Array.from(new Set(allRows.map((r) => String(r.cdpar ?? "").trim().slice(0, 6)).filter(Boolean)));
        const stockMap = new Map<string, number>();
        const CHUNK = 1000;
        for (let i = 0; i < cdparKeys.length; i += CHUNK) {
          const slice = cdparKeys.slice(i, i + CHUNK);
          const { data: inv, error: invErr } = await supabase
            .from("article_inventory" as any)
            .select("cdpar, quantity")
            .in("cdpar", slice);
          if (invErr) throw invErr;
          (inv ?? []).forEach((row: any) => {
            stockMap.set(String(row.cdpar ?? "").trim(), Number(row.quantity ?? 0));
          });
        }
        allRows = allRows.filter((r) => {
          const q = stockMap.get(String(r.cdpar ?? "").trim().slice(0, 6)) ?? 0;
          return wantAvail ? q > 0 : q <= 0;
        });
      }

      // compute B2B virtual column + strip helper fields
      if (wantsB2b) {
        allRows = allRows.map((row) => {
          const r: any = { ...row };
          r.b2b_online = computeIsB2bOnline(r.b2b_online_active, r.wfuas, onlineAssortments) ? "SI" : "NO";
          if (!cols.includes("b2b_online_active")) delete r.b2b_online_active;
          if (!cols.includes("wfuas")) delete r.wfuas;
          return r;
        });
      } else if (clientB2bOffline) {
        // strip helper fields added only for filtering
        allRows = allRows.map((row) => {
          const r: any = { ...row };
          if (!cols.includes("b2b_online_active")) delete r.b2b_online_active;
          if (!cols.includes("wfuas")) delete r.wfuas;
          return r;
        });
      }

      // Listino 01: ricarico (wsm01) e prezzo finale via RPC
      if (wantsListino) {
        const cdparKeys = Array.from(new Set(allRows.map((r) => String(r.cdpar ?? "").trim()).filter(Boolean)));
        const ricMap = new Map<string, number | null>();
        const prezzoMap = new Map<string, number | null>();
        const CHUNK = 500;

        if (wantsRicarico) {
          // criteri usa wcdpa padded a 6 — query con entrambe le forme
          for (let i = 0; i < cdparKeys.length; i += CHUNK) {
            const slice = cdparKeys.slice(i, i + CHUNK);
            const padded = slice.map((c) => c.padStart(6, "0"));
            const variants = Array.from(new Set([...slice, ...padded]));
            const { data: cri, error: criErr } = await supabase
              .from("listini_vendita_criteri_prezzo")
              .select("wcdpa,wsm01")
              .eq("wcdls", "01")
              .in("wcdpa", variants);
            if (criErr) throw criErr;
            (cri ?? []).forEach((row: any) => {
              const key = String(row.wcdpa ?? "").trim();
              ricMap.set(key, row.wsm01 != null ? Number(row.wsm01) : null);
            });
          }
        }

        if (wantsPrezzo) {
          for (let i = 0; i < cdparKeys.length; i += CHUNK) {
            const slice = cdparKeys.slice(i, i + CHUNK);
            const { data: pr, error: prErr } = await supabase.rpc("pim_prezzo_listino_batch", {
              _cdpars: slice,
              _cdls: "01",
            });
            if (prErr) throw prErr;
            (pr ?? []).forEach((row: any) => {
              const key = String(row.cdpar ?? "").trim();
              prezzoMap.set(key, row.prezzo != null ? Number(row.prezzo) : null);
            });
          }
        }

        allRows = allRows.map((row) => {
          const key = String(row.cdpar ?? "").trim();
          const r: any = { ...row };
          if (wantsRicarico) r.listino_01_ricarico = ricMap.get(key) ?? null;
          if (wantsPrezzo) r.listino_01_prezzo = prezzoMap.get(key) ?? null;
          return r;
        });
      }

      // Reparto / Gamma dagli attributi articolo
      if (wantsAttrCols) {
        allRows = allRows.map((row) => {
          const r: any = { ...row };
          const attrs = row.attributes ?? {};
          if (wantsReparto) r.reparto = attrs?.reparto ?? null;
          if (wantsGamma) r.gamma = attrs?.gamma ?? null;
          return r;
        });
      }

      // Netto Acquisto € (riga fornitore abituale, fallback prima riga)
      if (wantsNetto) {
        const cdparKeys = Array.from(new Set(allRows.map((r) => String(r.cdpar ?? "").trim()).filter(Boolean)));
        const supplierRows = new Map<string, any[]>();
        const CHUNK = 500;
        for (let i = 0; i < cdparKeys.length; i += CHUNK) {
          const slice = cdparKeys.slice(i, i + CHUNK);
          const { data: sup, error: supErr } = await supabase
            .from("archivio_anag_art_fornitore")
            .select("cdpar,cdfor,wprsc,wscfa,wscfb,wscfc,wscfd,wscfe,wmasc,wcpfa,wcpfb,wcpfc")
            .in("cdpar", slice);
          if (supErr) throw supErr;
          (sup ?? []).forEach((row: any) => {
            const key = String(row.cdpar ?? "").trim();
            const list = supplierRows.get(key) ?? [];
            list.push(row);
            supplierRows.set(key, list);
          });
        }
        allRows = allRows.map((row) => {
          const key = String(row.cdpar ?? "").trim();
          const list = supplierRows.get(key) ?? [];
          const habitual = String(row.pcfor ?? "").trim();
          const picked =
            (habitual ? list.find((s) => String(s.cdfor ?? "").trim() === habitual) : undefined) ?? list[0];
          const r: any = { ...row };
          r.netto_acquisto = picked ? computeNetPrice(picked) : null;
          return r;
        });
      }

      // strip helper fields aggiunti solo per il calcolo
      allRows = allRows.map((row) => {
        const r: any = { ...row };
        if (!cols.includes("attributes")) delete r.attributes;
        if (wantsNetto && !cols.includes("pcfor")) delete r.pcfor;
        return r;
      });


      // pad cdpar
      const padCols = cols.filter((c) => PAD6_COLUMNS.has(c));
      if (padCols.length > 0) {
        allRows = allRows.map((row) => {
          const r = { ...row };
          for (const col of padCols) {
            if (r[col] != null) r[col] = String(r[col]).padStart(6, "0");
          }
          return r;
        });
      }

      const ts = new Date().toISOString().replace(/[:-]/g, "").slice(0, 15);
      let blob: Blob;
      let ext: string;
      if (format === "xlsx") {
        const ws = XLSX.utils.json_to_sheet(allRows, { header: cols });
        // force text format for cdpar to preserve leading zeros
        if (cols.includes("cdpar")) {
          const range = XLSX.utils.decode_range(ws["!ref"] || "A1");
          const cdparIdx = cols.indexOf("cdpar");
          for (let R = range.s.r + 1; R <= range.e.r; R++) {
            const cell = ws[XLSX.utils.encode_cell({ r: R, c: cdparIdx })];
            if (cell) { cell.t = "s"; cell.z = "@"; }
          }
        }
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Articoli");
        const buf = XLSX.write(wb, { type: "array", bookType: "xlsx" });
        blob = new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
        ext = "xlsx";
      } else {
        const csv = Papa.unparse(allRows, { delimiter: ";", columns: cols });
        blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" });
        ext = "csv";
      }
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `articoli_export_${ts}.${ext}`;
      a.click();
      URL.revokeObjectURL(url);

      toast({ title: `Esportati ${allRows.length.toLocaleString("it-IT")} articoli ✅` });
      onClose();
    } catch (e: any) {
      toast({ title: "Errore export", description: e?.message ?? String(e), variant: "destructive" });
    } finally {
      setExporting(false);
    }
  };

  const filteredLabel = filteredCount === null
    ? "…"
    : `${needsAttrScan ? "≈ " : ""}${filteredCount.toLocaleString("it-IT")}`;

  return (
    <Dialog open={open} onOpenChange={(o) => !o && !exporting && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>Esporta Articoli</DialogTitle></DialogHeader>

        <div className="space-y-4">
          <RadioGroup value={scope} onValueChange={(v) => setScope(v as any)}>
            <div className="flex items-center gap-2">
              <RadioGroupItem value="all" id="all" />
              <Label htmlFor="all">Tutti gli articoli ({realTotalCount.toLocaleString("it-IT")})</Label>
            </div>
            <div className="flex items-center gap-2">
              <RadioGroupItem value="filtered" id="filtered" disabled={!filtersActive} />
              <Label htmlFor="filtered" className={!filtersActive ? "text-muted-foreground" : ""}>
                Solo filtrati ({filtersActive ? filteredLabel : "nessun filtro"})
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <RadioGroupItem value="online" id="online" disabled={!hasVisibleAssortments} />
              <Label htmlFor="online" className={!hasVisibleAssortments ? "text-muted-foreground" : ""}>
                Solo online da sistema ({hasVisibleAssortments ? (onlineCount === null ? "…" : onlineCount.toLocaleString("it-IT")) : "non configurato"})
              </Label>
            </div>
          </RadioGroup>

          <div className="border-t pt-3">
            <Label className="text-xs font-bold text-muted-foreground uppercase mb-2 block">Formato</Label>
            <div className="text-sm text-muted-foreground">Excel (.xlsx)</div>
          </div>

          <div className="space-y-3 max-h-60 overflow-auto">
            {COLUMN_GROUPS.map((group) => {
              const allSelected = group.columns.every((c) => selectedCols.has(c.key));
              return (
                <div key={group.label}>
                  <div className="flex items-center gap-2 mb-1">
                    <Checkbox checked={allSelected} onCheckedChange={() => toggleGroup(group, allSelected)} />
                    <span className="text-xs font-bold text-muted-foreground uppercase">{group.label}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-1 pl-6">
                    {group.columns.map((col) => (
                      <div key={col.key} className="flex items-center gap-2">
                        <Checkbox checked={selectedCols.has(col.key)} onCheckedChange={() => toggleCol(col.key)} />
                        <span className="text-xs">{col.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

          {exporting && <Progress value={progress} className="h-2" />}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={exporting}>Annulla</Button>
          <Button onClick={handleExport} disabled={exporting || selectedCols.size === 0}>
            <Download className="mr-2 h-4 w-4" /> Esporta ({selectedCols.size} colonne)
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

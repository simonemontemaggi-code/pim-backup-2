import { useState } from "react";
import { Plus, Trash2, Settings2, ChevronDown, ChevronRight, GripVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import {
  useGammaAttributes,
  useAddGammaAttribute,
  useDeleteGammaAttribute,
  useUpdateGammaAttribute,
  useAddGammaAttributeOption,
  useDeleteGammaAttributeOption,
} from "@/hooks/useGammaAttributes";
import { toast } from "@/hooks/use-toast";

interface Props {
  gammaCode: string;
}

export function GammaAttributeConfig({ gammaCode }: Props) {
  const { data: attributes = [], isLoading } = useGammaAttributes(gammaCode);
  const addAttr = useAddGammaAttribute();
  const deleteAttr = useDeleteGammaAttribute();
  const updateAttr = useUpdateGammaAttribute();
  const addOption = useAddGammaAttributeOption();
  const deleteOption = useDeleteGammaAttributeOption();

  const [newName, setNewName] = useState("");
  const [newRequired, setNewRequired] = useState(false);
  const [newHasUnit, setNewHasUnit] = useState(false);
  const [expandedAttr, setExpandedAttr] = useState<string | null>(null);
  const [newOptionValue, setNewOptionValue] = useState("");

  const handleAddAttr = async () => {
    if (!newName.trim()) return;
    try {
      await addAttr.mutateAsync({
        gamma_code: gammaCode,
        attribute_name: newName.trim(),
        is_required: newRequired,
        has_unit_select: newHasUnit,
        sort_order: attributes.length,
      });
      toast({ title: "Attributo aggiunto" });
      setNewName("");
      setNewRequired(false);
      setNewHasUnit(false);
    } catch (e: any) {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    }
  };

  const handleAddOption = async (attrId: string) => {
    if (!newOptionValue.trim()) return;
    try {
      await addOption.mutateAsync({
        gamma_attribute_id: attrId,
        gamma_code: gammaCode,
        option_value: newOptionValue.trim(),
      });
      setNewOptionValue("");
    } catch (e: any) {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    }
  };

  if (isLoading) return <p className="text-xs text-muted-foreground p-2">Caricamento...</p>;

  return (
    <div className="space-y-2 border-l-2 border-primary/30 pl-3 ml-2 mt-2">
      <h4 className="text-xs font-semibold text-primary">Attributi per gamma "{gammaCode}"</h4>

      {attributes.length === 0 && (
        <p className="text-xs text-muted-foreground">Nessun attributo configurato</p>
      )}

      {attributes.map((attr) => (
        <Collapsible
          key={attr.id}
          open={expandedAttr === attr.id}
          onOpenChange={(open) => setExpandedAttr(open ? attr.id : null)}
        >
          <div className="flex items-center gap-1.5 group rounded px-1 py-0.5 hover:bg-muted/50">
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="icon" className="h-5 w-5 shrink-0">
                {expandedAttr === attr.id ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
              </Button>
            </CollapsibleTrigger>
            <span className="text-xs font-medium flex-1 truncate" title={attr.attribute_name}>
              {attr.display_name || attr.attribute_name}
              <span className="text-[9px] text-muted-foreground ml-1">({attr.attribute_name})</span>
            </span>
            {attr.lookup_category && (
              <Badge variant="outline" className="text-[9px] h-4 px-1 border-blue-500 text-blue-600">LOOKUP</Badge>
            )}
            {attr.is_required && (
              <Badge variant="destructive" className="text-[9px] h-4 px-1">*OBB</Badge>
            )}
            {attr.has_unit_select && (
              <Badge variant="outline" className="text-[9px] h-4 px-1">UM</Badge>
            )}
            <span className="text-[10px] text-muted-foreground">{attr.options.length} opz.</span>
            <Button
              size="icon" variant="ghost"
              className="h-5 w-5 opacity-0 group-hover:opacity-100 text-destructive"
              onClick={() => deleteAttr.mutate({ id: attr.id, gamma_code: gammaCode })}
            >
              <Trash2 className="h-3 w-3" />
            </Button>
          </div>

          <CollapsibleContent className="pl-6 space-y-1.5 pb-2">
            {/* Display name editor */}
            <div className="flex items-center gap-1.5 py-1">
              <Label className="text-[10px] w-20 shrink-0">Etichetta UI</Label>
              <Input
                defaultValue={attr.display_name || ""}
                placeholder={attr.attribute_name}
                onBlur={(e) => {
                  const v = e.target.value.trim();
                  if (v !== (attr.display_name || "")) {
                    updateAttr.mutate({ id: attr.id, gamma_code: gammaCode, display_name: v || null });
                  }
                }}
                className="h-6 text-xs flex-1"
              />
            </div>

            {/* Lookup category info */}
            {attr.lookup_category && (
              <div className="text-[10px] text-muted-foreground">
                Varianti gestite in <span className="font-mono text-blue-600">{attr.lookup_category}</span>
              </div>
            )}

            {/* Toggles */}
            <div className="flex items-center gap-4 py-1">
              <div className="flex items-center gap-1.5">
                <Switch
                  checked={attr.is_required}
                  onCheckedChange={(v) => updateAttr.mutate({ id: attr.id, gamma_code: gammaCode, is_required: v })}
                  className="h-4 w-7"
                />
                <Label className="text-[10px]">Obbligatorio</Label>
              </div>
              <div className="flex items-center gap-1.5">
                <Switch
                  checked={attr.has_unit_select}
                  onCheckedChange={(v) => updateAttr.mutate({ id: attr.id, gamma_code: gammaCode, has_unit_select: v })}
                  className="h-4 w-7"
                />
                <Label className="text-[10px]">Menu UM</Label>
              </div>
            </div>

            {/* Options list */}
            {attr.has_unit_select && (
              <div className="space-y-1">
                <span className="text-[10px] text-muted-foreground font-medium">Opzioni menu a tendina:</span>
                {attr.options.map((opt) => (
                  <div key={opt.id} className="flex items-center gap-1.5 group/opt">
                    <span className="text-xs font-mono w-16 truncate">{opt.option_value}</span>
                    {opt.option_label && <span className="text-[10px] text-muted-foreground truncate">({opt.option_label})</span>}
                    <Button
                      size="icon" variant="ghost"
                      className="h-4 w-4 opacity-0 group-hover/opt:opacity-100 text-destructive ml-auto"
                      onClick={() => deleteOption.mutate({ id: opt.id, gamma_code: gammaCode })}
                    >
                      <Trash2 className="h-2.5 w-2.5" />
                    </Button>
                  </div>
                ))}
                <div className="flex items-center gap-1.5">
                  <Input
                    value={newOptionValue}
                    onChange={(e) => setNewOptionValue(e.target.value)}
                    placeholder="es. kg"
                    className="h-6 text-xs w-20"
                    onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); handleAddOption(attr.id); } }}
                  />
                  <Button size="sm" variant="outline" className="h-6 text-[10px] px-2" onClick={() => handleAddOption(attr.id)}>
                    <Plus className="h-2.5 w-2.5 mr-0.5" /> Opzione
                  </Button>
                </div>
              </div>
            )}
          </CollapsibleContent>
        </Collapsible>
      ))}

      {/* Add new attribute */}
      <div className="border-t pt-2 mt-2 space-y-1.5">
        <div className="flex items-center gap-1.5">
          <Input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Nome attributo..."
            className="h-7 text-xs flex-1"
            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); handleAddAttr(); } }}
          />
          <Button size="sm" variant="outline" className="h-7 text-xs" onClick={handleAddAttr} disabled={!newName.trim()}>
            <Plus className="h-3 w-3 mr-0.5" /> Attributo
          </Button>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <Switch checked={newRequired} onCheckedChange={setNewRequired} className="h-4 w-7" />
            <Label className="text-[10px]">Obbligatorio</Label>
          </div>
          <div className="flex items-center gap-1.5">
            <Switch checked={newHasUnit} onCheckedChange={setNewHasUnit} className="h-4 w-7" />
            <Label className="text-[10px]">Menu UM</Label>
          </div>
        </div>
      </div>
    </div>
  );
}

import { forwardRef, useEffect, useState, ChangeEvent, FocusEvent } from "react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { FieldRule, sanitizeInput, validateField } from "@/lib/fieldValidation";

interface Props {
  id?: string;
  name: string;
  rule: FieldRule;
  value: string;
  onChange: (val: string) => void;
  onValidationChange?: (name: string, error: string | null) => void;
  readOnly?: boolean;
  className?: string;
  placeholder?: string;
  /** show error immediately (e.g. on submit attempt). default: only after blur */
  forceShowError?: boolean;
}

/**
 * Input that filters disallowed characters on-type and reports validation errors.
 * Errors are shown after first blur (or when forceShowError is true).
 */
export const ValidatedInput = forwardRef<HTMLInputElement, Props>(function ValidatedInput(
  { id, name, rule, value, onChange, onValidationChange, readOnly, className, placeholder, forceShowError },
  ref,
) {
  const [touched, setTouched] = useState(false);
  const error = readOnly ? null : validateField(rule, value);
  const showError = !!error && (touched || forceShowError);

  // Notify parent of validation status (only when field is editable)
  useEffect(() => {
    if (readOnly) {
      onValidationChange?.(name, null);
    } else {
      onValidationChange?.(name, error);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [error, readOnly, name]);

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const cleaned = sanitizeInput(rule, e.target.value);
    onChange(cleaned);
  };

  const handleBlur = (_e: FocusEvent<HTMLInputElement>) => {
    setTouched(true);
  };

  return (
    <div className="space-y-0.5">
      <Input
        ref={ref}
        id={id}
        name={name}
        value={value ?? ""}
        onChange={handleChange}
        onBlur={handleBlur}
        readOnly={readOnly}
        placeholder={placeholder}
        inputMode={rule.kind === "int" ? "numeric" : rule.kind === "decimal" ? "decimal" : undefined}
        className={cn(
          className,
          showError && "border-destructive focus-visible:ring-destructive",
        )}
        aria-invalid={showError || undefined}
      />
      {showError && (
        <p className="text-[10px] text-destructive leading-tight">{error}</p>
      )}
    </div>
  );
});

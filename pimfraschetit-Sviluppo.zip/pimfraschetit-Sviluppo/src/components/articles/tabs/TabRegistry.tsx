import { useEffect, useRef } from "react";
import { useForm, Controller } from "react-hook-form";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/lib/permissions";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { useOnlineAssortments, computeIsB2bOnline, b2bValueToMode, b2bModeToValue, type B2bOverrideMode } from "@/hooks/useOnlineAssortments";

const FIELDS: { name: string; label: string; readOnly?: boolean }[] = [
  { name: "cdpar", label: "Codice Parte", readOnly: true },
  { name: "depar", label: "Descrizione" },
  { name: "nmdis", label: "Linea Brand" },
  { name: "clmer", label: "Settore" },
  { name: "lipro", label: "Linea Prodotto" },
  { name: "wcdst", label: "Codice Statistico" },
  { name: "cdst1", label: "Codice Statistico 1", readOnly: true },
  { name: "clas1", label: "Classificazione 1", readOnly: true },
  { name: "clas2", label: "Brand" },
  { name: "cdiva", label: "Codice IVA" },
  { name: "pcfor", label: "Fornitore Principale" },
  { name: "cod_padre", label: "Cod. Padre (6 cifre)" },
];

interface Props {
  article: Record<string, any>;
}

export function TabRegistry({ article }: Props) {
  const { can } = usePermissions();
  const canWrite = can("write", "articles_registry");
  const queryClient = useQueryClient();

  const { register, handleSubmit, control, watch, formState: { isDirty } } = useForm({
    defaultValues: {
      ...Object.fromEntries(FIELDS.map((f) => [f.name, article[f.name] ?? ""])),
      b2b_online_active: (article.b2b_online_active ?? null) as boolean | null,
    },
  });

  const { data: onlineAssortments = [] } = useOnlineAssortments();
  const currentOverride = watch("b2b_online_active") as boolean | null;
  const currentWfuas = (watch("wfuas" as any) ?? article.wfuas) as string | undefined;
  const isOnlineEffective = computeIsB2bOnline(currentOverride, currentWfuas, onlineAssortments);
  const mode = b2bValueToMode(currentOverride);

  const formRef = useRef<HTMLFormElement>(null);
  useEffect(() => {
    const handler = () => formRef.current?.requestSubmit();
    document.addEventListener("pim:save", handler);
    return () => document.removeEventListener("pim:save", handler);
  }, []);

  const mutation = useMutation({
    mutationFn: async (values: Record<string, any>) => {
      const { cdpar, ...updates } = values;
      // Normalize cod_padre: pad with zeros to 6 digits if numeric, or set null if empty
      if ("cod_padre" in updates) {
        const cp = String(updates.cod_padre ?? "").trim();
        if (!cp) {
          updates.cod_padre = null;
        } else if (/^\d{1,6}$/.test(cp)) {
          updates.cod_padre = cp.padStart(6, "0");
        } else {
          throw new Error("Cod. Padre deve essere numerico (max 6 cifre)");
        }
      }
      const { error } = await supabase
        .from("archivio_articoli_fraschetti")
        .update(updates as any)
        .eq("cdpar", cdpar);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Salvato", description: "Anagrafica aggiornata." });
      queryClient.invalidateQueries({ queryKey: ["article", article.cdpar] });
      queryClient.invalidateQueries({ queryKey: ["articles"] });
    },
    onError: (e: Error) => {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    },
  });

  return (
    <form ref={formRef} onSubmit={handleSubmit((v) => mutation.mutate(v))} className="space-y-4">
      <div className="rounded-md border-2 border-primary/40 p-3 bg-primary/5 space-y-2">
        <div className="flex items-center gap-3">
          <span className="text-sm font-semibold">🛒 Vendita Online B2B</span>
          <span
            title={isOnlineEffective ? "Online" : "Offline"}
            className={`inline-block h-2.5 w-2.5 rounded-full ${isOnlineEffective ? "bg-green-500" : "bg-red-500"}`}
          />
        </div>
        <div className="flex items-center gap-2">
          <Controller
            name="b2b_online_active"
            control={control}
            render={({ field }) => (
              <Select
                value={b2bValueToMode(field.value as boolean | null)}
                onValueChange={(v) => field.onChange(b2bModeToValue(v as B2bOverrideMode))}
                disabled={!canWrite}
              >
                <SelectTrigger className="h-8 w-[260px] text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">Auto (da assortimento)</SelectItem>
                  <SelectItem value="force_on">Forza online</SelectItem>
                  <SelectItem value="force_off">Forza offline</SelectItem>
                </SelectContent>
              </Select>
            )}
          />
          <p className="text-xs text-muted-foreground">
            {mode === "auto"
              ? `Auto: wfuas ${currentWfuas ?? "—"} ${onlineAssortments.includes(currentWfuas ?? "") ? "è in lista online" : "NON è in lista online"}.`
              : mode === "force_on"
                ? "Override manuale: forzato online."
                : "Override manuale: forzato offline."}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {FIELDS.map((f) => (
          <div key={f.name} className="space-y-1">
            <Label htmlFor={f.name} className="text-xs text-muted-foreground">{f.label}</Label>
            <Input
              id={f.name}
              {...register(f.name as any)}
              readOnly={f.readOnly || !canWrite}
              className={`h-8 text-sm ${f.name === "cdpar" ? "font-mono" : ""} ${(!canWrite || f.readOnly) ? "bg-muted" : ""}`}
            />
          </div>
        ))}
      </div>
      {canWrite && (
        <Button type="submit" size="sm" disabled={!isDirty || mutation.isPending}>
          {mutation.isPending ? "Salvataggio..." : "Salva Anagrafica"}
        </Button>
      )}
    </form>
  );
}

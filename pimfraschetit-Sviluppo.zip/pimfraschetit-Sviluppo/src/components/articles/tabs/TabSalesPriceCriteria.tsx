import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient, keepPreviousData } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/lib/permissions";
import { useActivePriceList } from "@/hooks/useActivePriceList";
import { computeListPriceFromStoc, computeSupplierCostBase } from "@/lib/priceUtils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";
import { Pencil, Save, X, Trash2, CalendarIcon, Info } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  usePrezziInAttesa, useUpsertPrezzoInAttesa, useDeletePrezzoInAttesa,
} from "@/hooks/usePrezziInAttesa";
import { as400DateToDisplay, as400DateToJsDate, jsDateToAs400 } from "@/lib/dateUtils";
import { PianificaPrezzoDialog } from "@/components/articles/PianificaPrezzoDialog";

const COLS = [
  { key: "wcdls", label: "Listino", readOnly: true },
  { key: "wsm01", label: "Ricarico", readOnly: false, decimals: 2 },
  { key: "wsm02", label: "Ricarico Radd. List.", readOnly: false, decimals: 2 },
  { key: "prmil", label: "Prezzo di Listino", readOnly: true, decimals: 2 },
];

function formatDecimal(val: any, decimals?: number): string {
  if (val == null || val === "") return "";
  const n = Number(val);
  if (isNaN(n)) return String(val);
  if (decimals != null) return n.toFixed(decimals).replace(".", ",");
  return String(val);
}

function computeNewPrmil(currentPrmil: number, oldSm01: number, oldSm02: number, newSm01: number, newSm02: number): number {
  // Reverse-derive base from current prmil & old ricarichi, then re-apply with new
  const oldFactor = (1 + (oldSm01 || 0) / 100) * (1 + (oldSm02 || 0) / 100);
  if (!oldFactor) return currentPrmil;
  const base = currentPrmil / oldFactor;
  const newFactor = (1 + (newSm01 || 0) / 100) * (1 + (newSm02 || 0) / 100);
  return Math.round(base * newFactor * 100) / 100;
}

function computeDerivedPrmil(netPrice: number, sm01: any, sm02: any): number {
  return computeListPriceFromStoc(netPrice, sm01, sm02);
}

interface Props {
  article: Record<string, any>;
}

export function TabSalesPriceCriteria({ article }: Props) {
  const { can } = usePermissions();
  const canWrite = can("write", "articles_pricing");
  const queryClient = useQueryClient();
  const [editId, setEditId] = useState<string | null>(null);
  const [editRow, setEditRow] = useState<Record<string, any>>({});
  const [pianificaOpen, setPianificaOpen] = useState(false);
  const [pianificaCtx, setPianificaCtx] = useState<{
    currentPrice: number | null; newPrice: number;
    wsm01: number | null; wsm02: number | null;
    criterioId: string | null; originalWsm01: number | null; originalWsm02: number | null;
  } | null>(null);

  const { data: activePriceList, isLoading: isLoadingPL } = useActivePriceList();
  const cdparKey = (article.cdpar ?? "").trim();
  const cdparPadded = cdparKey.padEnd(15, " ");
  const cdfor = (article.pcfor ?? "").trim() || null;

  const { data: rows = [], isLoading, isFetching } = useQuery({
    queryKey: ["sales_price_criteria", cdparKey, activePriceList],
    queryFn: async () => {
      // wcdpa nel DB è quasi sempre trimmed, ma possiamo trovare anche varianti paddate.
      // .in() con stringhe contenenti spazi finali rompe il parser PostgREST,
      // quindi usiamo .or() che gestisce correttamente il quoting.
      const orClause = `wcdpa.eq."${cdparKey}",wcdpa.eq."${cdparPadded}"`;
      const { data, error } = await supabase
        .from("listini_vendita_criteri_prezzo")
        .select("id,wcdls,wcdcv,wcdcl,wcdpa,wnrsc,wsm01,wsm02")
        .or(orClause)
        .order("wcdls", { ascending: true });
      if (error) {
        console.error("[TabSalesPriceCriteria] query error", { cdparKey, activePriceList, error });
        throw error;
      }
      console.debug("[TabSalesPriceCriteria] result", { cdparKey, activePriceList, count: data?.length ?? 0 });
      return data ?? [];
    },
    enabled: !!activePriceList && !!cdparKey,
    staleTime: 60_000,
    placeholderData: keepPreviousData,
  });

  const { data: costRows = [] } = useQuery({
    queryKey: ["sales_price_cost_rows", cdparKey],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("archivio_listini_fraschetti")
        .select("id,cdfor,cdval,dtvai,dtvaf,wprsc,prsc1,wscfa,wscfb,wscfc,wscfd,wscfe,wmasc,wfcas,wcpfa,wcpfb,wcpfc")
        .eq("cdpar", cdparKey)
        .order("dtvai", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Record<string, any>[];
    },
    enabled: !!cdparKey,
    staleTime: 5 * 60 * 1000,
    placeholderData: keepPreviousData,
  });

  // Suppliers in cost rows → differenziale_cambio (per wscfa corrector)
  const supplierCodes = useMemo(() => {
    const s = new Set<string>();
    costRows.forEach((r: any) => { if (r.cdfor) s.add(String(r.cdfor).trim()); });
    return Array.from(s);
  }, [costRows]);

  const { data: diffMap = {} } = useQuery({
    queryKey: ["spc_diff_cambio", supplierCodes.sort().join(",")],
    enabled: supplierCodes.length > 0,
    queryFn: async () => {
      // SOLO riga differenziale cambio (wcacq='§DC')
      const { data, error } = await supabase
        .from("differenziale_cambio")
        .select("wcdfo,wscfa")
        .in("wcdfo", supplierCodes)
        .eq("wcacq", "§DC");
      if (error) throw error;
      const m: Record<string, number> = {};
      (data ?? []).forEach((d: any) => { m[String(d.wcdfo).trim()] = Number(d.wscfa) || 0; });
      return m;
    },
    staleTime: 5 * 60 * 1000,
  });


  const { data: rateMap = {} } = useQuery({
    queryKey: ["spc_tassi_latest_eur"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("tassi_di_cambio")
        .select("cdval,cdva2,dtval,cambi")
        .order("dtval", { ascending: false });
      if (error) throw error;
      const m: Record<string, number> = {};
      (data ?? []).forEach((t: any) => {
        const from = String(t.cdval ?? "").trim().toUpperCase();
        const to = String(t.cdva2 ?? "").trim().toUpperCase();
        if (!from || (to && to !== "EURO" && to !== "EUR")) return;
        if (!(from in m)) m[from] = Number(t.cambi) || 0;
      });
      m["EUR"] = 1; m["EURO"] = 1;
      return m;
    },
    staleTime: 5 * 60 * 1000,
  });

  function toEur(value: number, cdval: any, cdfor: any): number | null {
    const code = String(cdval ?? "").trim().toUpperCase();
    const wscfa = diffMap[String(cdfor ?? "").trim()] ?? 0;
    if (!code || code === "EUR" || code === "EURO") return value;
    const rate = rateMap[code] ?? 0;
    if (!rate) return null;
    const denom = rate * (1 - wscfa / 100);
    if (denom === 0) return null;
    return value / denom;
  }



  const selectedCostRow = useMemo(() => {
    if (!costRows.length) return null;
    const preferredSupplier = String(cdfor ?? "").trim();
    const sortedRows = [...costRows].sort((a, b) => {
      const aPreferred = preferredSupplier && String(a.cdfor ?? "").trim() === preferredSupplier ? 1 : 0;
      const bPreferred = preferredSupplier && String(b.cdfor ?? "").trim() === preferredSupplier ? 1 : 0;
      if (aPreferred !== bPreferred) return bPreferred - aPreferred;
      return (Number(b.dtvai) || 0) - (Number(a.dtvai) || 0);
    });
    return sortedRows[0] ?? null;
  }, [costRows, cdfor]);

  const selectedCostBase = useMemo(() => {
    if (!selectedCostRow) return null;
    const stoc = computeSupplierCostBase(selectedCostRow);
    return toEur(stoc, selectedCostRow.cdval, selectedCostRow.cdfor);
  }, [selectedCostRow, diffMap, rateMap]);

  const { data: prezziAttesa = [] } = usePrezziInAttesa(cdparKey, activePriceList, cdfor);
  const upsertAttesa = useUpsertPrezzoInAttesa(cdparKey);
  const deleteAttesa = useDeletePrezzoInAttesa(cdparKey);

  // Prezzo "stored" su listini_vendita_dettagli per listino 01 (usato come override
  // del base01Prmil quando esiste un prezzo in attesa futuro per il listino 01).
  const { data: storedPrmil01 = null } = useQuery({
    queryKey: ["sales_price_dettagli_prmil01", cdparKey],
    enabled: !!cdparKey,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("listini_vendita_dettagli" as any)
        .select("prmil")
        .eq("cdarl", cdparKey)
        .eq("cdlsl", "01")
        .maybeSingle();
      if (error) throw error;
      const v = (data as any)?.prmil;
      return v == null ? null : Number(v);
    },
    staleTime: 30_000,
  });

  // Esiste un prezzo in attesa futuro per il listino 01 e non ancora effettuato (wvaef != 'S').
  // Il hook usePrezziInAttesa filtra già wcdls = activePriceList (== "01") e wvaef != 'S'.
  const todayStrLV = jsDateToAs400(new Date());
  const hasFuturePending01 = useMemo(
    () => prezziAttesa.some((p) => (p.wdtin ?? "") > todayStrLV),
    [prezziAttesa, todayStrLV],
  );

  const [editAttesaId, setEditAttesaId] = useState<string | null>(null);
  const [editAttesaRow, setEditAttesaRow] = useState<{ wprun: string; wdtin: Date | null }>({ wprun: "", wdtin: null });

  // "Save" criterio → opens Pianifica dialog
  const handleSaveCriterio = (row: any) => {
    const oldSm01 = Number(row.wsm01) || 0;
    const oldSm02 = Number(row.wsm02) || 0;
    const newSm01 = editRow.wsm01 === "" || editRow.wsm01 == null ? oldSm01 : Number(editRow.wsm01);
    const newSm02 = editRow.wsm02 === "" || editRow.wsm02 == null ? oldSm02 : Number(editRow.wsm02);
    const currentPrmil = computePrmilForRow(row) ?? 0;
    if (!currentPrmil) {
      toast({ title: "Prezzo corrente non disponibile", description: "Impossibile ricalcolare.", variant: "destructive" });
      return;
    }
    const newPrmil = selectedCostBase
      ? computeDerivedPrmil(selectedCostBase, newSm01, newSm02)
      : computeNewPrmil(currentPrmil, oldSm01, oldSm02, newSm01, newSm02);
    setPianificaCtx({
      currentPrice: currentPrmil, newPrice: newPrmil,
      wsm01: newSm01, wsm02: newSm02,
      criterioId: row.id, originalWsm01: oldSm01, originalWsm02: oldSm02,
    });
    setPianificaOpen(true);
  };

  const visibleRows = useMemo(
    () => rows.filter((r: any) => {
      const code = String(r.wcdls ?? "").trim();
      return /^[0-9]/.test(code) && code !== "02";
    }),
    [rows],
  );


  // Listino 01 è la base calcolata dai criteri: Netto Stoc EUR × ricarichi 01.
  // Tutti gli altri listini derivano come prmil_N = prmil_01 × (1 + wsm01_N/100) × (1 + wsm02_N/100).
  const listino01Row = useMemo(
    () => visibleRows.find((r: any) => String(r.wcdls ?? "").trim() === "01"),
    [visibleRows],
  );
  const base01Prmil = useMemo(() => {
    // Override: se c'è un prezzo in attesa futuro per il listino 01, usa il prmil
    // attualmente memorizzato in listini_vendita_dettagli (prezzo "in vigore oggi"),
    // così la riga 01 e tutti i derivati riflettono il prezzo corrente, non quello
    // ricalcolato dai criteri (che entrerà in vigore alla data pianificata).
    if (hasFuturePending01 && storedPrmil01 != null) return storedPrmil01;
    if (!listino01Row) return null;
    const sm01 = Number(listino01Row.wsm01) || 0;
    const sm02 = Number(listino01Row.wsm02) || 0;
    if (selectedCostBase != null) return computeDerivedPrmil(selectedCostBase, sm01, sm02);
    return null;
  }, [listino01Row, selectedCostBase, hasFuturePending01, storedPrmil01]);

  // Listini 10/11/12: ricarico da listini_vendita_condizioni
  // (chiave: wcdls + wcdst Classe Trasporto dell'articolo)

  const articleClasse = String(article.wcdst ?? "").trim();
  const { data: condRows = [] } = useQuery({
    queryKey: ["sales_price_condizioni", articleClasse],
    enabled: !!articleClasse,
    queryFn: async () => {
      // wcdst è paddato in DB (es. "Z               "): usa ilike "Z%" + trim client-side
      const { data, error } = await supabase
        .from("listini_vendita_condizioni")
        .select("wcdls,wcdst,wsm01,wsm02")
        .ilike("wcdst", `${articleClasse}%`)
        .in("wcdls", ["10", "11", "12"]);
      if (error) throw error;
      return ((data ?? []) as any[]).filter(
        (r) => String(r.wcdst ?? "").trim() === articleClasse,
      );
    },

    staleTime: 5 * 60 * 1000,
  });

  const syntheticRows = useMemo(() => {
    if (!articleClasse) return [];
    const map = new Map<string, any>();
    condRows.forEach((c: any) => {
      const code = String(c.wcdls ?? "").trim();
      if (!map.has(code)) map.set(code, c);
    });
    return ["10", "11", "12"].map((code) => {
      const c = map.get(code);
      return {
        id: `__syn_${code}`,
        wcdls: code,
        wcdpa: cdparKey,
        wsm01: c ? Number(c.wsm01) || 0 : 0,
        wsm02: c ? Number(c.wsm02) || 0 : 0,
        _synthetic: true,
        _hasCondizioni: !!c,
      };
    });
  }, [condRows, articleClasse, cdparKey]);

  const displayRows = useMemo(() => {
    // Inserisci synthetic 10/11/12 subito dopo listino 01
    const out: any[] = [];
    let inserted = false;
    for (const r of visibleRows) {
      out.push(r);
      const code = String(r.wcdls ?? "").trim();
      if (!inserted && code === "01") {
        out.push(...syntheticRows);
        inserted = true;
      }
    }
    if (!inserted) out.push(...syntheticRows);
    return out;
  }, [visibleRows, syntheticRows]);

  function computePrmilForRow(row: any): number | null {
    const code = String(row.wcdls ?? "").trim();
    const sm01 = Number(row.wsm01) || 0;
    const sm02 = Number(row.wsm02) || 0;
    if (code === "01") {
      // Override: prezzo in attesa futuro per il 01 → mostra prmil memorizzato.
      if (hasFuturePending01 && storedPrmil01 != null) return storedPrmil01;
      if (selectedCostBase != null) return computeDerivedPrmil(selectedCostBase, sm01, sm02);
      return null;
    }
    if (base01Prmil == null) return null;
    const factor = (1 + sm01 / 100) * (1 + sm02 / 100);
    return Math.round(base01Prmil * factor * 100) / 100;
  }


  if ((isLoadingPL && !activePriceList) || (isLoading && rows.length === 0)) {
    return <div className="p-4 text-muted-foreground">Caricamento...</div>;
  }

  if (!activePriceList) {
    return (
      <div className="text-sm text-muted-foreground">
        Nessun listino principale configurato. Vai in <strong>Admin &gt; Impostazioni</strong> per selezionarne uno.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Listini di vendita */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold">Listini di vendita</h3>
          <span className="text-xs text-muted-foreground">
            {displayRows.length} criteri
            {isFetching && <span className="ml-1 opacity-60">↻</span>}
          </span>
        </div>

        {displayRows.length === 0 ? (

          <div className="text-sm text-muted-foreground">Nessun criterio prezzo trovato per l'articolo.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="border-b">
                  {COLS.map((c) => (
                    <th key={c.key} className="px-1.5 py-1.5 text-left font-medium text-muted-foreground whitespace-nowrap">{c.label}</th>
                  ))}
                  {canWrite && <th className="px-1 py-1.5 w-14" />}
                </tr>
              </thead>
              <tbody>
                {displayRows.map((row: any) => {
                  const isSynthetic = !!row._synthetic;
                  const isEditing = !isSynthetic && editId === row.id;
                  const code = String(row.wcdls ?? "").trim();
                  const isBase = code === "01";
                  const prmilVal = computePrmilForRow(row);
                  return (
                    <tr key={row.id} className={cn("border-b hover:bg-accent/30", isSynthetic && "bg-muted/20")}>

                      {COLS.map((c) => (
                        <td key={c.key} className="px-1.5 py-1">
                          {c.key === "prmil" ? (
                            (() => {
                              const sm01 = Number(row.wsm01) || 0;
                              const sm02 = Number(row.wsm02) || 0;
                              return (
                                <TooltipProvider delayDuration={150}>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <span className="inline-flex items-center gap-1 cursor-help whitespace-nowrap">
                                        {formatDecimal(prmilVal, c.decimals)}
                                        <Info className="h-3 w-3 text-muted-foreground/60" />
                                      </span>
                                    </TooltipTrigger>
                                    <TooltipContent side="left" className="text-xs">
                                      {isBase ? (
                                        <>
                                          <div className="font-semibold mb-1">Listino 01 — Prezzo base</div>
                                          {selectedCostRow && (
                                            <div className="mb-1 text-muted-foreground">
                                              Base da fornitore principale {String(selectedCostRow.cdfor ?? "").trim()}
                                            </div>
                                          )}
                                          <div className="font-mono">
                                            {sm02 !== 0
                                              ? "Netto Stoc € × (1 + Ricarico/100) × (1 + Ricarico Radd. List./100)"
                                              : "Netto Stoc € × (1 + Ricarico/100)"}

                                          </div>
                                          {selectedCostBase != null && (
                                            <div className="font-mono mt-1 pt-1 border-t">
                                              {sm02 !== 0 ? (
                                                <>{formatDecimal(selectedCostBase, 4)} × (1 + {formatDecimal(sm01, 2)}/100) × (1 + {formatDecimal(sm02, 2)}/100) = <b>{formatDecimal(prmilVal, 2)}</b></>
                                              ) : (
                                                <>{formatDecimal(selectedCostBase, 4)} × (1 + {formatDecimal(sm01, 2)}/100) = <b>{formatDecimal(prmilVal, 2)}</b></>
                                              )}
                                            </div>
                                          )}
                                        </>
                                      ) : (
                                        <>
                                          <div className="font-semibold mb-1">
                                            Listino {code} — Derivato dal Listino 01
                                            {isSynthetic && (
                                              <span className="ml-1 text-muted-foreground font-normal">
                                                (ricarico da Condizioni Vendita · Classe Trasporto {articleClasse || "—"})
                                              </span>
                                            )}

                                          </div>
                                          <div className="font-mono">
                                            {sm02 !== 0
                                              ? "Prezzo Listino 01 × (1 + Ricarico/100) × (1 + Ricarico Radd. List./100)"
                                              : "Prezzo Listino 01 × (1 + Ricarico/100)"}
                                          </div>
                                          {base01Prmil != null ? (
                                            <div className="font-mono mt-1 pt-1 border-t">
                                              {sm02 !== 0 ? (
                                                <>{formatDecimal(base01Prmil, 2)} × (1 + {formatDecimal(sm01, 2)}/100) × (1 + {formatDecimal(sm02, 2)}/100) = <b>{formatDecimal(prmilVal, 2)}</b></>
                                              ) : (
                                                <>{formatDecimal(base01Prmil, 2)} × (1 + {formatDecimal(sm01, 2)}/100) = <b>{formatDecimal(prmilVal, 2)}</b></>
                                              )}
                                            </div>
                                          ) : (
                                            <div className="text-muted-foreground mt-1 pt-1 border-t">
                                              Prezzo Listino 01 non disponibile.
                                            </div>
                                          )}
                                          {isSynthetic && !row._hasCondizioni && (
                                            <div className="text-muted-foreground mt-1 pt-1 border-t">
                                              Nessuna condizione trovata per classe {articleClasse} / listino {code}: ricarico = 0.
                                            </div>
                                          )}
                                        </>
                                      )}

                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              );
                            })()
                          ) : isEditing && !c.readOnly ? (
                            <Input
                              className="h-6 text-xs p-1 min-w-[60px]"
                              type="number"
                              step="0.01"
                              value={editRow[c.key] ?? ""}
                              onChange={(e) => setEditRow({ ...editRow, [c.key]: e.target.value })}
                            />
                          ) : (
                            <span className="truncate block whitespace-nowrap">{formatDecimal(row[c.key], c.decimals)}</span>
                          )}
                        </td>
                      ))}
                      {canWrite && (
                        <td className="px-1 py-1">
                          <div className="flex gap-0.5">
                            {isSynthetic ? (
                              <span className="text-[10px] text-muted-foreground px-1">auto</span>
                            ) : isEditing ? (
                              <>
                                <Button size="icon" variant="ghost" className="h-5 w-5" onClick={() => handleSaveCriterio(row)} title="Pianifica nuovo prezzo">
                                  <Save className="h-3 w-3" />
                                </Button>
                                <Button size="icon" variant="ghost" className="h-5 w-5" onClick={() => setEditId(null)}>
                                  <X className="h-3 w-3" />
                                </Button>
                              </>
                            ) : (
                              <Button size="icon" variant="ghost" className="h-5 w-5" onClick={() => { setEditId(row.id); setEditRow({ ...row }); }}>
                                <Pencil className="h-3 w-3" />
                              </Button>
                            )}
                          </div>
                        </td>
                      )}

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Prezzi in Attesa */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold">Prezzi in Attesa</h3>
          <span className="text-xs text-muted-foreground">
            {prezziAttesa.length} pianificati
          </span>
        </div>

        {prezziAttesa.length === 0 ? (
          <div className="text-xs text-muted-foreground">Nessun prezzo pianificato per questo listino/fornitore.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="border-b">
                  <th className="px-1.5 py-1.5 text-left font-medium text-muted-foreground">Prezzo Unit.</th>
                  <th className="px-1.5 py-1.5 text-left font-medium text-muted-foreground">Validità da</th>
                  <th className="px-1.5 py-1.5 text-left font-medium text-muted-foreground">Ricarico</th>
                  <th className="px-1.5 py-1.5 text-left font-medium text-muted-foreground">Ricarico Radd. List.</th>
                  <th className="px-1.5 py-1.5 text-left font-medium text-muted-foreground">Stato</th>
                  {canWrite && <th className="px-1 py-1.5 w-20" />}
                </tr>
              </thead>
              <tbody>
                {prezziAttesa.map((p) => {
                  const isEditing = editAttesaId === p.id;
                  return (
                    <tr key={p.id} className="border-b hover:bg-accent/30">
                      <td className="px-1.5 py-1">
                        {isEditing ? (
                          <Input
                            className="h-6 text-xs p-1 min-w-[80px]"
                            type="number"
                            step="0.01"
                            value={editAttesaRow.wprun}
                            onChange={(e) => setEditAttesaRow({ ...editAttesaRow, wprun: e.target.value })}
                          />
                        ) : (
                          formatDecimal(p.wprun, 2)
                        )}
                      </td>
                      <td className="px-1.5 py-1">
                        {isEditing ? (
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button variant="outline" size="sm" className="h-6 text-xs px-2">
                                <CalendarIcon className="mr-1 h-3 w-3" />
                                {editAttesaRow.wdtin ? format(editAttesaRow.wdtin, "dd/MM/yyyy") : "—"}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={editAttesaRow.wdtin ?? undefined}
                                onSelect={(d) => d && setEditAttesaRow({ ...editAttesaRow, wdtin: d })}
                                disabled={(d) => d <= new Date(new Date().setHours(0, 0, 0, 0))}
                                initialFocus
                                className={cn("p-3 pointer-events-auto")}
                              />
                            </PopoverContent>
                          </Popover>
                        ) : (
                          as400DateToDisplay(p.wdtin)
                        )}
                      </td>
                      <td className="px-1.5 py-1">{formatDecimal(p.wsm01, 2)}</td>
                      <td className="px-1.5 py-1">{formatDecimal(p.wsm02, 2)}</td>
                      <td className="px-1.5 py-1 whitespace-nowrap">{p.wvaef === "S" ? "Attivo" : p.wvaef ?? "—"}</td>
                      {canWrite && (
                        <td className="px-1 py-1">
                          <div className="flex gap-0.5">
                            {isEditing ? (
                              <>
                                <Button
                                  size="icon" variant="ghost" className="h-5 w-5"
                                  onClick={async () => {
                                    if (!editAttesaRow.wdtin || !editAttesaRow.wprun) {
                                      toast({ title: "Compila prezzo e data", variant: "destructive" });
                                      return;
                                    }
                                    try {
                                      await upsertAttesa.mutateAsync({
                                        id: p.id,
                                        wprun: Number(editAttesaRow.wprun),
                                        wprui: Number(editAttesaRow.wprun),
                                        wdtin: jsDateToAs400(editAttesaRow.wdtin),
                                      });
                                      toast({ title: "Aggiornato" });
                                      setEditAttesaId(null);
                                    } catch (e: any) {
                                      toast({ title: "Errore", description: e.message, variant: "destructive" });
                                    }
                                  }}
                                >
                                  <Save className="h-3 w-3" />
                                </Button>
                                <Button size="icon" variant="ghost" className="h-5 w-5" onClick={() => setEditAttesaId(null)}>
                                  <X className="h-3 w-3" />
                                </Button>
                              </>
                            ) : (
                              <>
                                <Button
                                  size="icon" variant="ghost" className="h-5 w-5"
                                  onClick={() => {
                                    setEditAttesaId(p.id);
                                    setEditAttesaRow({
                                      wprun: p.wprun?.toString() ?? "",
                                      wdtin: as400DateToJsDate(p.wdtin),
                                    });
                                  }}
                                >
                                  <Pencil className="h-3 w-3" />
                                </Button>
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button size="icon" variant="ghost" className="h-5 w-5 text-destructive">
                                      <Trash2 className="h-3 w-3" />
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Conferma eliminazione</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        Eliminare il prezzo pianificato per il {as400DateToDisplay(p.wdtin)}?
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Annulla</AlertDialogCancel>
                                      <AlertDialogAction
                                        onClick={async () => {
                                          try {
                                            await deleteAttesa.mutateAsync(p.id);
                                            toast({ title: "Eliminato" });
                                          } catch (e: any) {
                                            toast({ title: "Errore", description: e.message, variant: "destructive" });
                                          }
                                        }}
                                      >Elimina</AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {pianificaCtx && activePriceList && (
        <PianificaPrezzoDialog
          open={pianificaOpen}
          onOpenChange={setPianificaOpen}
          cdpar={cdparKey}
          wcdls={activePriceList}
          wcdca={cdfor}
          currentPrice={pianificaCtx.currentPrice}
          newPrice={pianificaCtx.newPrice}
          wsm01={pianificaCtx.wsm01}
          wsm02={pianificaCtx.wsm02}
          criterioId={pianificaCtx.criterioId}
          originalWsm01={pianificaCtx.originalWsm01}
          originalWsm02={pianificaCtx.originalWsm02}
          onSuccess={() => setEditId(null)}
        />
      )}
    </div>
  );
}

import { useInventory, useInventoryHistory } from "@/hooks/useInventory";
import { useUserDisplayNames } from "@/hooks/useUserDisplayNames";
import { formatQty } from "@/lib/inventoryImport";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Package, TrendingDown, TrendingUp } from "lucide-react";

interface Props {
  cdpar: string;
}

const SOURCE_LABEL: Record<string, string> = {
  import_manual: "Import manuale",
  import_auto: "Import automatico",
  manual: "Manuale",
};

export function TabInventory({ cdpar }: Props) {
  const { data: inventory, isLoading: loadingInv } = useInventory(cdpar);
  const { data: history, isLoading: loadingHist } = useInventoryHistory(cdpar, 50);
  const { display: displayUser } = useUserDisplayNames((history ?? []).map((h) => h.user_id));



  return (
    <div className="space-y-6">
      {/* Giacenza attuale */}
      <div className="rounded-lg border bg-card p-6">
        <div className="flex items-center gap-3 mb-2">
          <Package className="h-5 w-5 text-muted-foreground" />
          <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
            Giacenza attuale
          </h2>
        </div>
        {loadingInv ? (
          <Skeleton className="h-12 w-40" />
        ) : inventory ? (
          <>
            <div className="text-4xl font-bold tabular-nums">
              {formatQty(Number(inventory.quantity))}
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              Ultimo aggiornamento:{" "}
              {new Date(inventory.updated_at).toLocaleString("it-IT")}
            </div>
          </>
        ) : (
          <div className="text-muted-foreground text-sm">
            Nessuna giacenza registrata per questo articolo.
          </div>
        )}
      </div>

      {/* Storico movimenti */}
      <div className="rounded-lg border bg-card">
        <div className="p-4 border-b">
          <h3 className="font-medium">Ultime 50 movimentazioni</h3>
        </div>
        {loadingHist ? (
          <div className="p-4 space-y-2">
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-8 w-full" />
          </div>
        ) : history && history.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data/Ora</TableHead>
                <TableHead className="text-right">Q.tà precedente</TableHead>
                <TableHead className="text-right">Q.tà nuova</TableHead>
                <TableHead className="text-right">Delta</TableHead>
                <TableHead>Origine</TableHead>
                <TableHead>Utente</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {history.map((h) => {
                const delta = Number(h.delta);
                const isPositive = delta > 0;
                const isNegative = delta < 0;
                return (
                  <TableRow key={h.id}>
                    <TableCell className="font-mono text-xs">
                      {new Date(h.created_at).toLocaleString("it-IT")}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      {h.quantity_old === null ? "—" : formatQty(Number(h.quantity_old))}
                    </TableCell>
                    <TableCell className="text-right tabular-nums font-medium">
                      {formatQty(Number(h.quantity_new))}
                    </TableCell>
                    <TableCell
                      className={`text-right tabular-nums font-medium ${
                        isPositive ? "text-green-600" : isNegative ? "text-red-600" : ""
                      }`}
                    >
                      <span className="inline-flex items-center gap-1 justify-end">
                        {isPositive && <TrendingUp className="h-3 w-3" />}
                        {isNegative && <TrendingDown className="h-3 w-3" />}
                        {delta > 0 ? "+" : ""}
                        {formatQty(delta)}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {SOURCE_LABEL[h.source] ?? h.source}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {displayUser(h.user_id, h.user_email)}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        ) : (
          <div className="p-8 text-center text-muted-foreground text-sm">
            Nessun movimento registrato.
          </div>
        )}
      </div>
    </div>
  );
}

import { useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/lib/permissions";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";

const FIELDS: { name: string; label: string; type?: string; fixed?: string; fixedLabel?: string; selectOptions?: { label: string; value: string }[] }[] = [
  { name: "unmis", label: "UM Stoccaggio" },
  { name: "untec", label: "UM Tecnica" },
  { name: "umfat", label: "Fatt. Conv. UM Tec→Stoc", type: "number" },
  { name: "umalt", label: "UM Alternativa" },
  { name: "umfaa", label: "Fatt. Conv. UM Alt→Stoc", type: "number" },
  { name: "wimba", label: "Imballo" },
  { name: "wdset", label: "Descrizione Etichette" },
  { name: "wdeag", label: "Estensione Descrizione" },
  { name: "wfuas", label: "Assortimento" },
  { name: "wstag", label: "Stagionalità" },
  { name: "wclve", label: "Classe di Vendita" },
  { name: "wvvii", label: "Vincolo Imballo" },
  { name: "wfcvr", label: "Variabile SI / NO", selectOptions: [{ label: "NO", value: "N" }] },
  { name: "wfcs1", label: "Fatt. Conv UmSt/UmV1", type: "number" },
  { name: "wfc2x", label: "Fatt. Conv UmV2/UmSt", type: "number" },
  { name: "wumrf", label: "UM Riferimento UmV2" },
];

interface Props {
  article: Record<string, any>;
}

export function TabUnitsSales({ article }: Props) {
  const { can } = usePermissions();
  const canWrite = can("write", "articles_units");
  const queryClient = useQueryClient();

  const { register, handleSubmit, watch, setValue, formState: { isDirty } } = useForm({
    defaultValues: Object.fromEntries(FIELDS.map((f) => [f.name, article[f.name] ?? ""])),
  });

  const formRef = useRef<HTMLFormElement>(null);
  useEffect(() => {
    const handler = () => formRef.current?.requestSubmit();
    document.addEventListener("pim:save", handler);
    return () => document.removeEventListener("pim:save", handler);
  }, []);

  const mutation = useMutation({
    mutationFn: async (values: Record<string, any>) => {
      const cleaned = { ...values };
      FIELDS.forEach((f) => {
        if ("type" in f && f.type === "number" && cleaned[f.name] === "") {
          cleaned[f.name] = null;
        }
      });
      const { error } = await supabase
        .from("archivio_articoli_fraschetti")
        .update(cleaned as any)
        .eq("cdpar", article.cdpar);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Salvato", description: "Unità di misura e vendita aggiornate." });
      queryClient.invalidateQueries({ queryKey: ["article", article.cdpar] });
      queryClient.invalidateQueries({ queryKey: ["articles"] });
    },
    onError: (e: Error) => {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    },
  });

  return (
    <form ref={formRef} onSubmit={handleSubmit((v) => mutation.mutate(v))} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {FIELDS.map((f) => (
          <div key={f.name} className="space-y-1">
            <Label htmlFor={f.name} className="text-xs text-muted-foreground">{f.label}</Label>
            {f.selectOptions ? (
              canWrite ? (
                <Select
                  value={watch(f.name) || "__empty__"}
                  onValueChange={(v) => setValue(f.name, v === "__empty__" ? "" : v, { shouldDirty: true })}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {f.selectOptions.map((opt) => (
                      <SelectItem key={opt.value || "__empty__"} value={opt.value || "__empty__"}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <Input
                  value={f.selectOptions.find(o => o.value === (watch(f.name) ?? ""))?.label ?? watch(f.name) ?? ""}
                  readOnly
                  className="h-8 text-sm bg-muted"
                />
              )
            ) : (
              <Input
                id={f.name}
                {...register(f.name)}
                type={f.type ?? "text"}
                readOnly={!canWrite}
                className={`h-8 text-sm ${!canWrite ? "bg-muted" : ""}`}
              />
            )}
          </div>
        ))}
      </div>
      {canWrite && (
        <Button type="submit" size="sm" disabled={!isDirty || mutation.isPending}>
          {mutation.isPending ? "Salvataggio..." : "Salva UM & Vendita"}
        </Button>
      )}
    </form>
  );
}

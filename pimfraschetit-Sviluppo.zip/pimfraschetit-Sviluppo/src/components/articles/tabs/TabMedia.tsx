import { useState, useCallback, useRef } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Trash2, Download, FileText, AlertTriangle, Paperclip, GripVertical, Video, Eye, BookMarked, Store, ArrowUpAZ } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { usePermissions } from "@/lib/permissions";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { generateDatasheet } from "@/lib/generateDatasheet";
import {
  buildImagePath,
  buildDatasheetPath,
  buildSafetyPath,
  buildAssemblyPath,
  buildCertificationPath,
  buildCollectionPath,
  buildExpoPath,
  buildVideoPath,
  getMediaCdparCandidates,
  getFileExt,
  parseImageProgressiveFromFilename,
  normalizeArticleImageOrdering,
} from "@/lib/mediaUtils";
import {
  MEDIA_UPLOAD_CONCURRENCY,
  buildPublicMediaUrl,
  getStartingProgressives,
  runWithConcurrency,
} from "@/lib/mediaUpload";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  useSortable,
  rectSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { maybeOptimizePdf } from "@/lib/maybeOptimizePdf";
import ExpoCompositionEditor from "@/components/articles/ExpoCompositionEditor";

interface Props {
  article: any;
  mode?: "media" | "docs";
}

function SortableImage({
  img,
  cdpar,
  canWrite,
  isPrimary,
  onDelete,
}: {
  img: any;
  cdpar: string;
  canWrite: boolean;
  isPrimary: boolean;
  onDelete: (item: any) => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: img.id,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    zIndex: isDragging ? 50 : undefined,
  };

  return (
    <div ref={setNodeRef} style={style} className="relative border rounded-md overflow-hidden group">
      {canWrite && (
        <button
          {...attributes}
          {...listeners}
          className="absolute top-1 right-1 z-10 cursor-grab active:cursor-grabbing touch-none"
        >
          <GripVertical className="h-4 w-4 text-muted-foreground/70" />
        </button>
      )}
      <img src={getCacheBustedMediaUrl(img.public_url, img.updated_at)} alt={img.original_filename} className="w-full h-36 object-contain bg-muted p-1" onError={(e) => { (e.target as HTMLImageElement).src = ''; (e.target as HTMLImageElement).alt = 'Immagine non disponibile'; }} />
      {isPrimary && (
        <Badge className="absolute top-1 left-1 text-[10px] px-1">⭐ Primaria</Badge>
      )}
      <div className="absolute bottom-0 inset-x-0 bg-foreground/70 p-1 flex justify-end opacity-0 group-hover:opacity-100 transition-opacity">
        {canWrite && (
          <button onClick={() => onDelete(img)} className="text-red-400">
            <Trash2 className="h-3 w-3" />
          </button>
        )}
      </div>
      <p className="text-[10px] p-1 truncate">
        {img.original_filename || `${cdpar}_${img.sort_order}.${getFileExt(img.storage_path)}`}
      </p>
    </div>
  );
}

const getCacheBustedMediaUrl = (url: string | null | undefined, version: string | null | undefined) => {
  if (!url) return "";
  if (!version) return url;
  const separator = url.includes("?") ? "&" : "?";
  return `${url}${separator}v=${encodeURIComponent(version)}`;
};

export function TabMedia({ article, mode = "media" }: Props) {
  const confirm = useConfirm();
  const queryClient = useQueryClient();
  const { can } = usePermissions();
  const canWrite = can("write", "media_library");
  const cdpar = (article.cdpar ?? "").trim();
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});
  const [localImages, setLocalImages] = useState<any[] | null>(null);
  const [saving, setSaving] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } })
  );

  const { data: media = [] as any[] } = useQuery({
    queryKey: ["article_media", cdpar],
    queryFn: async () => {
      const cdparCandidates = getMediaCdparCandidates(cdpar);
      const { data, error } = await supabase
        .from("article_media")
        .select("*")
        .in("cdpar", cdparCandidates)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      setLocalImages(null);
      return data as any[];
    },
  });

  const dedupedMedia = (() => {
    const structured = new Set<string>();
    for (const m of media) {
      if ((m as any).storage_path?.startsWith("articles/")) {
        structured.add((m as any).cdpar + "::" + (m as any).media_type);
      }
    }
    return media.filter((m: any) => {
      if (m.storage_path?.startsWith("articles/")) return true;
      const key = m.cdpar + "::" + m.media_type;
      return !structured.has(key);
    });
  })();

  const serverImages = dedupedMedia.filter((m: any) => m.media_type === "image");
  const images = localImages ?? serverImages;
  const videos = dedupedMedia.filter((m: any) => m.media_type === "video");
  const datasheet = dedupedMedia.find((m: any) => m.media_type === "pdf_datasheet");
  const safety = dedupedMedia.find((m: any) => m.media_type === "pdf_safety");
  const assembly = dedupedMedia.find((m: any) => m.media_type === "pdf_assembly");
  const certification = dedupedMedia.find((m: any) => m.media_type === "pdf_certification");
  const collection = dedupedMedia.find((m: any) => m.media_type === "pdf_collection");
  const expo = dedupedMedia.find((m: any) => m.media_type === "pdf_expo");

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["article_media", cdpar] });

  const uploadFile = useCallback(
    async (files: File[], mediaType: string) => {
      const batchStartedAt = Date.now();
      const uploadEntries = files.map((file, index) => ({
        file,
        ext: getFileExt(file.name),
        uploadKey: `${batchStartedAt}-${index}-${file.name}`,
      }));

      let completed = 0;
      let failed = 0;
      let lastErrorMessage = "";

      try {
        setUploadProgress((prev) => ({
          ...prev,
          ...Object.fromEntries(uploadEntries.map(({ uploadKey }) => [uploadKey, 15])),
        }));

        const needsProgressive = mediaType === "image" || mediaType === "document" || mediaType === "video";
        const startingProgressives = await getStartingProgressives(
          needsProgressive ? uploadEntries.map(() => ({ cdpar, mediaType })) : [{ cdpar, mediaType }]
        );
        const progressiveKey = `${cdpar}::${mediaType}`;
        const nextProgressives = { ...startingProgressives };

        // Live lookup completo per l'articolo: serve sovrascrivere SEMPRE le righe esistenti
        // senza affidarsi a insert/upsert che può violare uq_article_media_cdpar_type_filename.
        const cdparCandidates = getMediaCdparCandidates(cdpar);
        const { data: existingRows, error: existingLookupError } = await supabase
          .from("article_media")
          .select("id, cdpar, storage_path, progressive, sort_order, original_filename")
          .in("cdpar", cdparCandidates)
          .eq("media_type", mediaType);
        if (existingLookupError) throw existingLookupError;

        const existingByName = new Map<string, any>();
        const existingByBaseName = new Map<string, any>();
        const existingByProgressive = new Map<number, any>();
        const existingByStoragePath = new Map<string, any>();
        const usedProgressives = new Set<number>();
        const stripExt = (name: string) => name.replace(/\.[^/.]+$/, "").trim().toLowerCase();
        for (const row of (existingRows ?? []) as any[]) {
          if (row.original_filename) {
            existingByName.set(row.original_filename, row);
            const base = stripExt(row.original_filename);
            if (base && !existingByBaseName.has(base)) existingByBaseName.set(base, row);
          }
          if (row.storage_path) {
            existingByStoragePath.set(row.storage_path, row);
            // anche il basename del path, per match cross-estensione su file caricati con path canonico
            const pathFile = row.storage_path.split("/").pop() ?? "";
            const base = stripExt(pathFile);
            if (base && !existingByBaseName.has(base)) existingByBaseName.set(base, row);
          }
          if (row.progressive != null) {
            usedProgressives.add(row.progressive);
            // Escludi lo slot "P{cdpar}" e lo slot bare "{cdpar}" dall'indice per-progressive:
            // sono slot distinti che non devono collidere con `{cdpar}_N`.
            const baseFn = row.original_filename ? stripExt(row.original_filename) : "";
            const cdparLower = cdpar.toLowerCase();
            const isPName = baseFn === `p${cdparLower}`;
            const isBareName = baseFn === cdparLower;
            if (!isPName && !isBareName && !existingByProgressive.has(row.progressive)) {
              existingByProgressive.set(row.progressive, row);
            }
          }
        }

        const reserveNextProgressive = () => {
          let progressive = nextProgressives[progressiveKey] ?? 1;
          while (usedProgressives.has(progressive)) progressive++;
          usedProgressives.add(progressive);
          nextProgressives[progressiveKey] = progressive + 1;
          return progressive;
        };

        const plannedUploads = uploadEntries.map(({ file, ext, uploadKey }) => {
          // Overwrite priority: filename completo → nome senza estensione → path canonico → progressive.
          const fromFilenameProg = mediaType === "image"
            ? parseImageProgressiveFromFilename(cdpar, file.name)
            : null;
          const canonicalImagePath = fromFilenameProg != null
            ? buildImagePath(cdpar, fromFilenameProg, ext, file.name)
            : null;
          const fileBase = stripExt(file.name);
          const existing =
            existingByName.get(file.name) ||
            (fileBase ? existingByBaseName.get(fileBase) : undefined) ||
            (canonicalImagePath ? existingByStoragePath.get(canonicalImagePath) : undefined) ||
            (fromFilenameProg != null ? existingByProgressive.get(fromFilenameProg) : undefined);

          const displacedStoragePathRow = canonicalImagePath
            ? existingByStoragePath.get(canonicalImagePath)
            : undefined;
          const displacedProgressiveRow = fromFilenameProg != null
            ? existingByProgressive.get(fromFilenameProg)
            : undefined;

          if (existing) {
            // Forza il percorso canonico per le immagini se il filename indica un progressive.
            let storagePath = existing.storage_path as string;
            if (mediaType === "image" && canonicalImagePath) storagePath = canonicalImagePath;
            const progressive = fromFilenameProg ?? existing.progressive ?? existing.sort_order ?? 1;
            usedProgressives.add(progressive);
            const displacedProgressiveId = displacedProgressiveRow?.id !== existing.id
              ? (displacedProgressiveRow?.id as string | undefined)
              : undefined;
            const displacedProgressiveTarget = displacedProgressiveId
              ? (existing.progressive ?? existing.sort_order ?? reserveNextProgressive())
              : null;
            const displacedStoragePathId = displacedStoragePathRow?.id !== existing.id
              ? (displacedStoragePathRow?.id as string | undefined)
              : undefined;
            const displacedStoragePathTarget = displacedStoragePathId ? (existing.storage_path as string) : null;
            const displacedStoragePathTemp = displacedStoragePathId
              ? `${existing.storage_path}.swap-${batchStartedAt}-${uploadKey}`
              : null;
            return {
              file,
              uploadKey,
              progressive,
              storagePath,
              existingId: existing.id as string,
              displacedProgressiveId,
              displacedProgressiveTarget,
              displacedStoragePathId,
              displacedStoragePathTarget,
              displacedStoragePathTemp,
            };
          }

          // Nuova riga: se il filename suggerisce un progressive libero, usalo;
          // se è già occupato (es. dallo slot P{cdpar}) o non c'è, prendi il prossimo libero.
          const progressive = needsProgressive
            ? (fromFilenameProg != null && !usedProgressives.has(fromFilenameProg)
                ? fromFilenameProg
                : reserveNextProgressive())
            : 1;
          if (needsProgressive && fromFilenameProg != null) usedProgressives.add(progressive);

          let storagePath: string;
          if (mediaType === "image") storagePath = buildImagePath(cdpar, progressive, ext, file.name);
          else if (mediaType === "video") storagePath = buildVideoPath(cdpar, progressive, ext);
          else if (mediaType === "pdf_datasheet") storagePath = buildDatasheetPath(cdpar);
          else if (mediaType === "pdf_safety") storagePath = buildSafetyPath(cdpar);
          else if (mediaType === "pdf_assembly") storagePath = buildAssemblyPath(cdpar);
          else if (mediaType === "pdf_certification") storagePath = buildCertificationPath(cdpar);
          else if (mediaType === "pdf_collection") storagePath = buildCollectionPath(cdpar);
          else if (mediaType === "pdf_expo") storagePath = buildExpoPath(cdpar);
          else storagePath = buildVideoPath(cdpar, progressive, ext);

          return { file, uploadKey, progressive, storagePath, existingId: null as string | null, displacedProgressiveId: undefined, displacedProgressiveTarget: null, displacedStoragePathId: undefined, displacedStoragePathTarget: null, displacedStoragePathTemp: null };
        });

        const overwriteExistingRow = async (rowId: string, file: File, mediaType: string, storagePath: string, progressive: number) => {
          const { error } = await supabase.from("article_media").update({
            storage_path: storagePath,
            public_url: buildPublicMediaUrl(storagePath),
            file_size: file.size,
            original_filename: file.name,
            updated_at: new Date().toISOString(),
            progressive,
            sort_order: progressive,
            is_primary: mediaType === "image" && progressive === 1,
          } as any).eq("id", rowId);
          return error;
        };

        const findFallbackExistingRow = async (file: File, mediaType: string, storagePath: string, progressive: number) => {
          const byFilename = await supabase
            .from("article_media")
            .select("id")
            .in("cdpar", cdparCandidates)
            .eq("media_type", mediaType)
            .eq("original_filename", file.name)
            .limit(1);
          if (byFilename.data?.[0]) return (byFilename.data[0] as any).id as string;

          const byStorage = await supabase
            .from("article_media")
            .select("id")
            .in("cdpar", cdparCandidates)
            .eq("media_type", mediaType)
            .eq("storage_path", storagePath)
            .limit(1);
          if (byStorage.data?.[0]) return (byStorage.data[0] as any).id as string;

          const byProgressive = await supabase
            .from("article_media")
            .select("id")
            .in("cdpar", cdparCandidates)
            .eq("media_type", mediaType)
            .eq("progressive", progressive)
            .limit(1);
          return (byProgressive.data?.[0] as any)?.id as string | undefined;
        };

        await runWithConcurrency(plannedUploads, MEDIA_UPLOAD_CONCURRENCY, async ({ file, uploadKey, progressive, storagePath, existingId, displacedProgressiveId, displacedProgressiveTarget, displacedStoragePathId, displacedStoragePathTarget, displacedStoragePathTemp }) => {
          setUploadProgress((prev) => ({ ...prev, [uploadKey]: 45 }));

          const fileToUpload = mediaType.startsWith("pdf_") ? await maybeOptimizePdf(file) : file;
          const { error: uploadError } = await supabase.storage.from("pim-media").upload(storagePath, fileToUpload, { upsert: true });
          if (uploadError) {
            failed++;
            lastErrorMessage = uploadError.message;
            setUploadProgress((prev) => { const next = { ...prev }; delete next[uploadKey]; return next; });
            return;
          }

          setUploadProgress((prev) => ({ ...prev, [uploadKey]: 80 }));

          let dbError: any = null;
          if (existingId) {
            if (displacedStoragePathId && displacedStoragePathTemp) {
              const { error } = await supabase.from("article_media").update({
                storage_path: displacedStoragePathTemp,
                public_url: buildPublicMediaUrl(displacedStoragePathTemp),
              } as any).eq("id", displacedStoragePathId);
              if (error) dbError = error;
            }
            if (displacedProgressiveId && displacedProgressiveTarget != null) {
              const { error } = await supabase.from("article_media").update({
                progressive: displacedProgressiveTarget,
                sort_order: displacedProgressiveTarget,
                is_primary: mediaType === "image" && displacedProgressiveTarget === 1,
              } as any).eq("id", displacedProgressiveId);
              if (error) dbError = error;
            }
            if (!dbError) dbError = await overwriteExistingRow(existingId, file, mediaType, storagePath, progressive);
            if (!dbError && displacedStoragePathId && displacedStoragePathTarget) {
              const { error } = await supabase.from("article_media").update({
                storage_path: displacedStoragePathTarget,
                public_url: buildPublicMediaUrl(displacedStoragePathTarget),
              } as any).eq("id", displacedStoragePathId);
              if (error) dbError = error;
            }
          } else {
            const { error: insertError } = await supabase.from("article_media").insert({
              cdpar,
              media_type: mediaType,
              storage_path: storagePath,
              public_url: buildPublicMediaUrl(storagePath),
              original_filename: file.name,
              file_size: file.size,
              is_primary: mediaType === "image" && progressive === 1,
              progressive,
              sort_order: progressive,
            } as any);

            if (insertError && insertError.message?.includes("duplicate key value violates unique constraint")) {
              // Race condition o lookup stale: recupera per filename/path/progressive e sovrascrivi.
              const staleRowId = await findFallbackExistingRow(file, mediaType, storagePath, progressive);
              if (staleRowId) {
                dbError = await overwriteExistingRow(staleRowId, file, mediaType, storagePath, progressive);
              } else {
                dbError = insertError;
              }
            } else {
              dbError = insertError;
            }
          }

          if (dbError) {
            failed++;
            lastErrorMessage = dbError.message;
            setUploadProgress((prev) => { const next = { ...prev }; delete next[uploadKey]; return next; });
            return;
          }

          completed++;
          setUploadProgress((prev) => { const next = { ...prev }; delete next[uploadKey]; return next; });
        });

        if (mediaType === "image") {
          await normalizeArticleImageOrdering(cdpar);
        }
        queryClient.invalidateQueries({ queryKey: ["article_media", cdpar] });
        toast({
          title: failed > 0 ? `Upload completato con ${failed} errori` : "Upload completato ✅",
          description:
            failed > 0
              ? lastErrorMessage || `${completed} file caricati correttamente`
              : `${completed} file caricati`,
          variant: failed > 0 && completed === 0 ? "destructive" : undefined,
        });
      } catch (e: any) {
        setUploadProgress((prev) => {
          const next = { ...prev };
          uploadEntries.forEach(({ uploadKey }) => delete next[uploadKey]);
          return next;
        });
        toast({ title: "Errore upload", description: e.message, variant: "destructive" });
      }
    },
    [cdpar, queryClient]
  );

  const deleteMedia = async (item: any) => {
    if (!(await confirm({ title: "Eliminare questo file?", destructive: true, confirmText: "Elimina" }))) return;
    await supabase.storage.from("pim-media").remove([item.storage_path]);
    await supabase.from("article_media").delete().eq("id", item.id);

    if (item.media_type === "image") {
      const remaining = serverImages.filter((i: any) => i.id !== item.id);
      for (let i = 0; i < remaining.length; i++) {
        await supabase.from("article_media").update({
          sort_order: i + 1,
          is_primary: i === 0,
        } as any).eq("id", remaining[i].id);
      }
    }
    invalidate();
    toast({ title: "File eliminato" });
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    const oldIndex = images.findIndex((i: any) => i.id === active.id);
    const newIndex = images.findIndex((i: any) => i.id === over.id);
    if (oldIndex === -1 || newIndex === -1) return;

    const reordered = arrayMove(images, oldIndex, newIndex).map((img: any, idx: number) => ({
      ...img,
      sort_order: idx + 1,
      is_primary: idx === 0,
    }));

    setLocalImages(reordered);
    setSaving(true);

    try {
      for (let i = 0; i < reordered.length; i++) {
        const { error } = await supabase.from("article_media").update({
          sort_order: i + 1,
          is_primary: i === 0,
        } as any).eq("id", reordered[i].id);
        if (error) throw error;
      }
      toast({ title: "Ordine aggiornato ✅" });
      invalidate();
    } catch (e: any) {
      setLocalImages(null);
      toast({ title: "Errore riordino", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const sortImagesAZ = async () => {
    const current = images;
    if (current.length < 2) return;
    const sorted = [...current].sort((a: any, b: any) => {
      const nameA = (a.original_filename || "").toLowerCase();
      const nameB = (b.original_filename || "").toLowerCase();
      return nameA.localeCompare(nameB, "it");
    }).map((img: any, idx: number) => ({
      ...img,
      sort_order: idx + 1,
      is_primary: idx === 0,
    }));

    setLocalImages(sorted);
    setSaving(true);

    try {
      for (let i = 0; i < sorted.length; i++) {
        const { error } = await supabase.from("article_media").update({
          sort_order: i + 1,
          is_primary: i === 0,
        } as any).eq("id", sorted[i].id);
        if (error) throw error;
      }
      toast({ title: "Ordine alfabetico applicato ✅" });
      invalidate();
    } catch (e: any) {
      setLocalImages(null);
      toast({ title: "Errore riordino", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handleGenerateDatasheet = async () => {
    try {
      await generateDatasheet(article, media);
      invalidate();
    } catch (e: any) {
      toast({ title: "Errore generazione PDF", description: e.message, variant: "destructive" });
    }
  };

  // Upload progress bar (shared)
  const progressBars = Object.entries(uploadProgress).map(([key, val]) => (
    <div key={key} className="flex items-center gap-2">
      <span className="text-xs truncate max-w-[200px]">{key.split("-").slice(2).join("-") || key}</span>
      <Progress value={val || 50} className="h-2 flex-1" />
    </div>
  ));

  /* ── MODE: media (images + videos) ── */
  if (mode === "media") {
    return (
      <div className="space-y-4">
        {saving && <span className="text-xs text-muted-foreground animate-pulse">Salvataggio ordine...</span>}
        {progressBars}

        {/* Images */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="font-medium text-xs text-muted-foreground uppercase tracking-wide">Immagini</h3>
            {canWrite && images.length > 1 && (
              <button
                onClick={sortImagesAZ}
                disabled={saving}
                className="text-xs flex items-center gap-1 text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50"
              >
                <ArrowUpAZ className="h-3 w-3" /> A-Z
              </button>
            )}
          </div>
          {canWrite && (
            <FileDropZone
              accept="image/jpeg,image/png,image/webp"
              onFiles={(files) => uploadFile(files, "image")}
              label="Trascina immagini (JPG, PNG, WebP)"
            />
          )}
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
            <SortableContext items={images.map((i: any) => i.id)} strategy={rectSortingStrategy}>
              <div className="grid grid-cols-3 lg:grid-cols-5 gap-3">
                {images.map((img: any, index: number) => (
                  <SortableImage key={img.id} img={img} cdpar={cdpar} canWrite={canWrite} isPrimary={index === 0} onDelete={deleteMedia} />
                ))}
                {images.length === 0 && <p className="text-xs text-muted-foreground col-span-4">Nessuna immagine</p>}
              </div>
            </SortableContext>
          </DndContext>
        </div>

        {/* Videos */}
        <div className="space-y-2">
          <h3 className="font-medium text-xs text-muted-foreground uppercase tracking-wide">Video</h3>
          {canWrite && (
            <FileDropZone
              accept="video/mp4,video/webm,video/quicktime,video/x-msvideo"
              onFiles={(files) => uploadFile(files, "video")}
              label="Trascina video (MP4, WebM, MOV, AVI)"
            />
          )}
          {videos.map((vid: any) => (
            <div key={vid.id} className="flex items-center gap-2 text-sm border rounded-md p-2">
              <Video className="h-4 w-4 text-blue-500 shrink-0" />
              <span className="truncate flex-1">{vid.original_filename}</span>
              <span className="text-xs text-muted-foreground">{((vid.file_size ?? 0) / (1024 * 1024)).toFixed(1)} MB</span>
              <a href={vid.public_url} target="_blank" rel="noreferrer"><Download className="h-4 w-4" /></a>
              {canWrite && <button onClick={() => deleteMedia(vid)}><Trash2 className="h-4 w-4 text-destructive" /></button>}
            </div>
          ))}
          {videos.length === 0 && <p className="text-xs text-muted-foreground">Nessun video</p>}
        </div>
      </div>
    );
  }

  /* ── MODE: docs (datasheets, safety, other docs) ── */
  return (
    <div className="space-y-4">
      {progressBars}


      <div className="grid md:grid-cols-2 gap-4">
        {/* Scheda Tecnica */}
        <DocSlot
          title="Scheda Tecnica"
          icon={<FileText className="h-3.5 w-3.5" />}
          item={datasheet}
          canWrite={canWrite}
          onDelete={deleteMedia}
          onUpload={(files) => uploadFile(files, "pdf_datasheet")}
          generateButton={
            canWrite && !datasheet ? (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="icon" variant="outline" className="h-6 w-6" onClick={handleGenerateDatasheet}>
                    <FileText className="h-3.5 w-3.5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Genera Scheda Tecnica PDF</TooltipContent>
              </Tooltip>
            ) : undefined
          }
        />

        {/* Scheda Sicurezza */}
        <DocSlot
          title="Scheda Sicurezza"
          icon={<AlertTriangle className="h-3.5 w-3.5" />}
          item={safety}
          canWrite={canWrite}
          onDelete={deleteMedia}
          onUpload={(files) => uploadFile(files, "pdf_safety")}
        />

        {/* Scheda Montaggio */}
        <DocSlot
          title="Scheda Montaggio"
          icon={<Paperclip className="h-3.5 w-3.5" />}
          item={assembly}
          canWrite={canWrite}
          onDelete={deleteMedia}
          onUpload={(files) => uploadFile(files, "pdf_assembly")}
        />

        {/* Certificazioni */}
        <DocSlot
          title="Certificazioni"
          icon={<FileText className="h-3.5 w-3.5" />}
          item={certification}
          canWrite={canWrite}
          onDelete={deleteMedia}
          onUpload={(files) => uploadFile(files, "pdf_certification")}
        />

        {/* Collezione */}
        <DocSlot
          title="Collezione"
          icon={<BookMarked className="h-3.5 w-3.5" />}
          item={collection}
          canWrite={canWrite}
          onDelete={deleteMedia}
          onUpload={(files) => uploadFile(files, "pdf_collection")}
        />

      </div>

      {/* Composizione Expo (sostituisce il PDF Expo) */}
      <div className="mt-4">
        <ExpoCompositionEditor cdpar={article?.cdpar ?? ""} canWrite={canWrite} />
      </div>

    </div>
  );
}


/* ── DocSlot: single-document upload slot ─────────────────────── */

function DocSlot({
  title,
  icon,
  item,
  canWrite,
  onDelete,
  onUpload,
  generateButton,
}: {
  title: string;
  icon: React.ReactNode;
  item: any;
  canWrite: boolean;
  onDelete: (item: any) => void;
  onUpload: (files: File[]) => void;
  generateButton?: React.ReactNode;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <h3 className="font-medium text-xs text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
          {icon} {title}
        </h3>
        {generateButton}
      </div>
      {item ? (
        <div className="flex items-center gap-2 text-sm border rounded-md p-2">
          {icon}
          <span className="truncate flex-1">{item.original_filename}</span>
          <Tooltip>
            <TooltipTrigger asChild>
              <a href={item.public_url} target="_blank" rel="noreferrer" className="hover:text-primary">
                <Eye className="h-4 w-4" />
              </a>
            </TooltipTrigger>
            <TooltipContent>Visualizza</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                type="button"
                onClick={async (e) => {
                  e.preventDefault();
                  try {
                    const res = await fetch(item.public_url);
                    if (!res.ok) throw new Error(`HTTP ${res.status}`);
                    const blob = await res.blob();
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement("a");
                    a.href = url;
                    a.download = item.original_filename || "documento.pdf";
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                  } catch (err: any) {
                    toast({ title: "Errore download", description: err.message, variant: "destructive" });
                  }
                }}
                className="hover:text-primary"
              >
                <Download className="h-4 w-4" />
              </button>
            </TooltipTrigger>
            <TooltipContent>Scarica</TooltipContent>
          </Tooltip>
          {canWrite && <button onClick={() => onDelete(item)}><Trash2 className="h-4 w-4 text-destructive" /></button>}
        </div>
      ) : (
        canWrite && (
          <FileDropZone
            accept=".pdf"
            multiple={false}
            onFiles={onUpload}
            label={`Carica ${title.toLowerCase()} (PDF)`}
          />
        )
      )}
    </div>
  );
}
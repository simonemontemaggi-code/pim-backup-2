
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/lib/permissions";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { Copy, Upload } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { buildAs400Payload } from "@/lib/as400Export";

const STATUS_COLORS: Record<string, string> = {
  new: "bg-blue-500/10 text-blue-600 border-blue-200",
  modified: "bg-warning/10 text-warning border-warning/30",
  synced: "bg-success/10 text-success border-success/30",
  error: "bg-destructive/10 text-destructive border-destructive/30",
};

interface Props {
  article: Record<string, any>;
}

export function TabSync({ article }: Props) {
  const { can } = usePermissions();
  const { user } = useAuth();
  const canWrite = can("write", "as400_sync");
  const queryClient = useQueryClient();
  const status = article.as400_sync_status ?? "new";

  // Build AS400 sync payload (strips PIM-only fields, normalizes codes)
  const cdparKey = (article.cdpar ?? "").trim();
  const operation: "insert" | "update" = status === "new" ? "insert" : "update";
  const payload = buildAs400Payload({
    user: user?.email ?? null,
    record: cdparKey,
    changes: [
      {
        table: "archivio_articoli_fraschetti",
        change: {
          operation,
          key: { cdpar: cdparKey },
          fields: article,
        },
      },
    ],
  });
  const payloadJson = JSON.stringify(payload, null, 2);

  // Sync queue history
  const { data: history = [] } = useQuery({
    queryKey: ["sync_history", cdparKey],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("as400_sync_queue" as any)
        .select("*")
        .eq("cdpar", cdparKey)
        .order("created_at", { ascending: false })
        .limit(10);
      if (error) throw error;
      return data ?? [];
    },
  });

  const addToQueue = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("as400_sync_queue" as any).insert({
        cdpar: cdparKey,
        operation: status === "new" ? "insert" : "update",
        payload,
        status: "pending",
      });
      if (error) throw error;
      // Update article sync status (master uses padded cdpar)
      if (status !== "new") {
        await supabase
          .from("archivio_articoli_fraschetti")
          .update({ as400_sync_status: "pending" })
          .eq("cdpar", article.cdpar);
      }
    },
    onSuccess: () => {
      toast({ title: "Aggiunto alla coda", description: `${cdparKey} in coda di sincronizzazione.` });
      queryClient.invalidateQueries({ queryKey: ["sync_history", cdparKey] });
      queryClient.invalidateQueries({ queryKey: ["article", article.cdpar] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const copyJson = async () => {
    await navigator.clipboard.writeText(payloadJson);
    toast({ title: "Copiato", description: "JSON copiato negli appunti." });
  };

  return (
    <div className="space-y-6">
      {/* Status */}
      <div className="flex items-center gap-3">
        <span className="text-sm text-muted-foreground">Stato sincronizzazione:</span>
        <Badge className={STATUS_COLORS[status] ?? STATUS_COLORS.new}>
          {status.toUpperCase()}
        </Badge>
        {article.updated_at && (
          <span className="text-xs text-muted-foreground">
            Ultimo aggiornamento: {new Date(article.updated_at).toLocaleString("it-IT")}
          </span>
        )}
      </div>

      {/* JSON Preview */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-semibold">Payload AS400</h3>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={copyJson}>
              <Copy className="h-3 w-3 mr-1" /> Copia JSON
            </Button>
            {canWrite && (
              <Button size="sm" onClick={() => addToQueue.mutate()} disabled={addToQueue.isPending}>
                <Upload className="h-3 w-3 mr-1" /> Aggiungi a coda
              </Button>
            )}
          </div>
        </div>
        <pre className="bg-[#1e1e2e] text-[#cdd6f4] p-4 rounded-lg text-xs font-mono overflow-auto max-h-[300px] border">
          {payloadJson}
        </pre>
      </div>

      {/* History */}
      <div>
        <h3 className="text-sm font-semibold mb-2">Storico sincronizzazioni</h3>
        {history.length === 0 ? (
          <p className="text-sm text-muted-foreground">Nessuna sincronizzazione registrata.</p>
        ) : (
          <div className="space-y-1">
            <div className="flex text-xs font-medium text-muted-foreground border-b pb-1">
              <div className="w-[150px]">Data</div>
              <div className="w-[80px]">Operazione</div>
              <div className="w-[80px]">Stato</div>
              <div className="flex-1">Errore</div>
            </div>
            {history.map((h: any) => (
              <div key={h.id} className="flex text-xs py-1 border-b">
                <div className="w-[150px]">{new Date(h.created_at).toLocaleString("it-IT")}</div>
                <div className="w-[80px]">{h.operation}</div>
                <div className="w-[80px]">
                  <Badge variant="outline" className={`text-[10px] ${STATUS_COLORS[h.status] ?? ""}`}>
                    {h.status}
                  </Badge>
                </div>
                <div className="flex-1 text-destructive truncate">{h.error_message}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

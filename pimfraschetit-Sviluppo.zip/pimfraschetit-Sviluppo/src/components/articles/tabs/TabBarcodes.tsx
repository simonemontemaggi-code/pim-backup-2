import { useState, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/lib/permissions";
import { useAuth } from "@/contexts/AuthContext";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, Plus, Trash2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { buildAs400Payload, downloadAs400Json } from "@/lib/as400Export";

interface Props {
  article: Record<string, any>;
}

const BARCODE_FIELDS = [
  { key: "wcpba", label: "Codice a Barre", w: "w-32" },
  { key: "wcofl", label: "TC", w: "w-16", dropdown: true },
  { key: "wcbda", label: "Data Attivazione", w: "w-20" },
] as const;

let newRowCounter = 0;

export function TabBarcodes({ article }: Props) {
  const { can } = usePermissions();
  const canWrite = can("write", "articles_registry");
  const { user, profile } = useAuth();
  const queryClient = useQueryClient();

  const cdparTrimmed = (article.cdpar ?? "").trim();
  const cdparNoLeadingZeros = cdparTrimmed.replace(/^0+/, "") || "0";

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["barcodes", cdparTrimmed],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("archivio_codici_barre_fraschetti")
        .select("id,wcdpa,wcpba,wcofl,wcbda")
        .or(`wcdpa.eq.${cdparTrimmed},wcdpa.eq.${cdparNoLeadingZeros}`)
        .order("wcpba", { ascending: true });
      if (error) throw error;
      return (data ?? []) as Record<string, any>[];
    },
    staleTime: 5 * 60 * 1000,
  });

  // Fetch distinct wcofl values for TC dropdown
  const { data: tcOptions = [""] } = useQuery({
    queryKey: ["barcode_tc_options"],
    queryFn: async () => {
      const { data } = await supabase
        .from("archivio_codici_barre_fraschetti")
        .select("wcofl")
        .not("wcofl", "is", null)
        .limit(1000);
      const vals = new Set<string>([""]);
      (data ?? []).forEach((r: any) => {
        const v = r.wcofl?.trim();
        if (v) vals.add(v);
      });
      return [...vals].sort();
    },
    staleTime: 30 * 60 * 1000,
  });

  const [edits, setEdits] = useState<Record<string, Record<string, any>>>({});
  const [newRows, setNewRows] = useState<{ tempId: string; values: Record<string, any> }[]>([]);

  const onChange = useCallback((rowId: string, field: string, value: string) => {
    setEdits((prev) => ({
      ...prev,
      [rowId]: { ...(prev[rowId] ?? {}), [field]: value },
    }));
  }, []);

  const onNewRowChange = useCallback((tempId: string, field: string, value: string) => {
    setNewRows((prev) =>
      prev.map((r) => (r.tempId === tempId ? { ...r, values: { ...r.values, [field]: value } } : r))
    );
  }, []);

  const addNewRow = useCallback(() => {
    newRowCounter++;
    setNewRows((prev) => [
      ...prev,
      { tempId: `new-${newRowCounter}`, values: {} },
    ]);
  }, []);

  const removeNewRow = useCallback((tempId: string) => {
    setNewRows((prev) => prev.filter((r) => r.tempId !== tempId));
  }, []);

  const hasDirty = Object.keys(edits).length > 0 || newRows.length > 0;

  const saveMutation = useMutation({
    mutationFn: async () => {
      const promises: Promise<any>[] = [];

      for (const [rowId, changes] of Object.entries(edits)) {
        if (Object.keys(changes).length === 0) continue;
        const cleaned: Record<string, any> = {};
        for (const [k, v] of Object.entries(changes)) {
          cleaned[k] = v === "" ? null : v;
        }
        promises.push(
          supabase
            .from("archivio_codici_barre_fraschetti")
            .update(cleaned as any)
            .eq("id", rowId)
            .then(({ error }) => { if (error) throw error; }) as unknown as Promise<any>
        );
      }

      for (const newRow of newRows) {
        const cleaned: Record<string, any> = { wcdpa: cdparTrimmed };
        for (const [k, v] of Object.entries(newRow.values)) {
          cleaned[k] = v === "" ? null : v;
        }
        promises.push(
          supabase
            .from("archivio_codici_barre_fraschetti")
            .insert(cleaned as any)
            .then(({ error }) => { if (error) throw error; }) as unknown as Promise<any>
        );
      }

      await Promise.all(promises);

      // Build & download AS400 JSON for all barcode changes
      const changes: { table: string; change: any }[] = [];
      for (const [rowId, fields] of Object.entries(edits)) {
        if (Object.keys(fields).length === 0) continue;
        const baseRow = rows.find((r: any) => r.id === rowId);
        changes.push({
          table: "archivio_codici_barre_fraschetti",
          change: {
            operation: "update",
            key: { id: rowId, wcdpa: baseRow?.wcdpa ?? cdparTrimmed },
            fields,
          },
        });
      }
      for (const newRow of newRows) {
        changes.push({
          table: "archivio_codici_barre_fraschetti",
          change: {
            operation: "insert",
            key: { wcdpa: cdparTrimmed },
            fields: { wcdpa: cdparTrimmed, ...newRow.values },
          },
        });
      }
      if (changes.length > 0) {
        downloadAs400Json(
          buildAs400Payload({
            user: profile?.email ?? user?.email,
            record: article.cdpar,
            changes,
          }),
          "as400_barcode",
        );
      }

      await supabase.from("audit_log" as any).insert({
        table_name: "archivio_codici_barre_fraschetti",
        record_id: article.cdpar,
        operation: newRows.length > 0 ? "insert+update" : "update",
        old_values: {},
        new_values: { edits, newRows: newRows.map((r) => r.values) },
        changed_fields: [
          ...new Set([
            ...Object.values(edits).flatMap((e) => Object.keys(e)),
            ...newRows.flatMap((r) => Object.keys(r.values)),
          ]),
        ],
        user_id: user?.id,
        user_email: profile?.email,
      });
    },
    onSuccess: () => {
      toast({ title: "Salvato", description: "Codici a barre aggiornati." });
      setEdits({});
      setNewRows([]);
      queryClient.invalidateQueries({ queryKey: ["barcodes", cdparTrimmed] });
    },
    onError: (e: Error) => {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    },
  });

  if (isLoading) return <div className="py-2 text-xs text-muted-foreground">Caricamento...</div>;

  return (
    <div className="space-y-2">
      {canWrite && (
        <div className="flex justify-between items-center">
          <Button size="sm" variant="outline" onClick={addNewRow}>
            <Plus className="h-3.5 w-3.5 mr-1" />
            Aggiungi codice a barre
          </Button>
          {hasDirty && (
            <Button size="sm" onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending}>
              <Save className="h-3.5 w-3.5 mr-1" />
              {saveMutation.isPending ? "Salvataggio..." : "Salva Codici a Barre"}
            </Button>
          )}
        </div>
      )}

      {rows.length === 0 && newRows.length === 0 && (
        <div className="px-3 py-3 text-xs text-muted-foreground">Nessun codice a barre disponibile.</div>
      )}

      {(rows.length > 0 || newRows.length > 0) && (
        <div className="overflow-x-auto">
          <div className="space-y-1 min-w-[400px]">
            {/* Header */}
            <div className="grid gap-x-2 gap-y-0.5" style={{ gridTemplateColumns: `1fr 100px 140px ${canWrite ? '32px' : ''}` }}>
              {BARCODE_FIELDS.map((f) => (
                <span key={`h-${f.key}`} className="text-[10px] leading-tight text-muted-foreground truncate">
                  {f.label}
                </span>
              ))}
              {canWrite && <span />}
            </div>

            {/* Existing rows */}
            {rows.map((row) => {
              const rowId = row.id;
              const rowEdits = edits[rowId] ?? {};
              return (
                <div key={rowId} className="grid gap-x-2 gap-y-0.5" style={{ gridTemplateColumns: `1fr 100px 140px ${canWrite ? '32px' : ''}` }}>
                  {BARCODE_FIELDS.map((f) => {
                    const isReadOnly = !canWrite;
                    const currentValue = rowEdits[f.key] !== undefined ? rowEdits[f.key] : (row[f.key] ?? "");
                    const isDirty = rowEdits[f.key] !== undefined;

                    if ("dropdown" in f && f.dropdown && !isReadOnly) {
                      return (
                        <Select
                          key={f.key}
                          value={String(currentValue)}
                          onValueChange={(v) => onChange(rowId, f.key, v === "__empty__" ? "" : v)}
                        >
                          <SelectTrigger className={`h-7 text-xs px-1.5 ${isDirty ? "border-destructive ring-1 ring-destructive/30" : ""}`}>
                            <SelectValue placeholder="—" />
                          </SelectTrigger>
                          <SelectContent>
                            {tcOptions.map((opt) => (
                              <SelectItem key={opt || "__empty__"} value={opt || "__empty__"}>
                                {opt || "—"}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      );
                    }

                    return (
                      <Input
                        key={f.key}
                        value={currentValue}
                        onChange={(e) => onChange(rowId, f.key, e.target.value)}
                        readOnly={isReadOnly}
                        className={`h-7 text-xs px-1.5 ${isReadOnly ? "bg-muted" : ""} ${isDirty ? "border-destructive ring-1 ring-destructive/30 text-destructive" : ""}`}
                      />
                    );
                  })}
                  {canWrite && <span />}
                </div>
              );
            })}

            {/* New rows */}
            {newRows.map((newRow) => (
              <div
                key={newRow.tempId}
                className="grid gap-x-2 gap-y-0.5 border border-green-500/40 rounded p-0.5 bg-green-500/5"
                style={{ gridTemplateColumns: `1fr 100px 140px 32px` }}
              >
                {BARCODE_FIELDS.map((f) => {
                  if ("dropdown" in f && f.dropdown) {
                    return (
                      <Select
                        key={f.key}
                        value={String(newRow.values[f.key] ?? "")}
                        onValueChange={(v) => onNewRowChange(newRow.tempId, f.key, v === "__empty__" ? "" : v)}
                      >
                        <SelectTrigger className="h-7 text-xs px-1.5">
                          <SelectValue placeholder="—" />
                        </SelectTrigger>
                        <SelectContent>
                          {tcOptions.map((opt) => (
                            <SelectItem key={opt || "__empty__"} value={opt || "__empty__"}>
                              {opt || "—"}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    );
                  }
                  return (
                    <Input
                      key={f.key}
                      value={newRow.values[f.key] ?? ""}
                      onChange={(e) => onNewRowChange(newRow.tempId, f.key, e.target.value)}
                      placeholder={f.label}
                      className="h-7 text-xs px-1.5"
                    />
                  );
                })}
                <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => removeNewRow(newRow.tempId)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="text-xs text-muted-foreground">{rows.length} codici a barre trovati</div>
    </div>
  );
}

import { useState, useMemo, useEffect } from "react";
import { createPortal } from "react-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { computeNetPrice, computeStocPrice, computeSupplierCostBase } from "@/lib/priceUtils";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/lib/permissions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Plus, Trash2, Save, X, Pencil, Star, ChevronDown, CalendarClock } from "lucide-react";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { PianificaPrezzoDialog } from "@/components/articles/PianificaPrezzoDialog";
import { useActivePriceList } from "@/hooks/useActivePriceList";

const COLS = [
  { key: "cdfor", label: "Forn." },
  { key: "rifli", label: "Rif. Listino" },
  { key: "dtvai", label: "Val. Da" },
  { key: "dtvaf", label: "Val. A" },
  { key: "cdval", label: "Valuta" },
  { key: "wprsc", label: "Prezzo", decimals: 5 },
  { key: "wscfa", label: "Sc.A", decimals: 2 },
  { key: "wscfb", label: "Sc.B", decimals: 2 },
  { key: "wscfc", label: "Sc.C", decimals: 2 },
  { key: "wscfd", label: "Sc.D", decimals: 2 },
  { key: "wscfe", label: "Sc.E", decimals: 2 },
  { key: "wmasc", label: "Magg.", decimals: 2 },
  { key: "prsc1", label: "Cost For", decimals: 5 },
  { key: "wfcas", label: "Fc.As." },
  { key: "wcpfa", label: "Dazio", decimals: 2 },
  { key: "wcpfb", label: "Trasp.", decimals: 2 },
  { key: "wcpfc", label: "Altro", decimals: 2 },
  { key: "wuord", label: "UM Ord." },
  { key: "wusto", label: "UM Sto." },
  { key: "_netto_acq", label: "Netto Acq" },
  { key: "_netto_stoc", label: "Netto Stoc" },
  { key: "_diff_cambio", label: "Diff. Cambio" },
  { key: "_netto_acq_eur", label: "Netto Acq €" },
  { key: "_netto_stoc_eur", label: "Netto Stoc €" },
];


const CURRENCY_SYMBOLS: Record<string, string> = {
  EUR: "€", EURO: "€",
  USD: "$", "DOL$": "$", DOL: "$", DOLL: "$", DOLA: "$",
  GBP: "£", CHF: "CHF", JPY: "¥", CNY: "¥",
};
function currencySymbol(code: any): string {
  const c = String(code ?? "").trim().toUpperCase();
  return CURRENCY_SYMBOLS[c] ?? (c || "€");
}

function formatDecimal(val: any, decimals?: number): string {
  if (val == null || val === "") return "";
  const n = Number(val);
  if (isNaN(n)) return String(val);
  if (decimals != null) return n.toFixed(decimals).replace(".", ",");
  return String(val);
}

interface Props {
  article: Record<string, any>;
}

export function TabPriceLists({ article }: Props) {
  const { can, canField, fieldVisible } = usePermissions();
  const canWrite = can("write", "articles_pricing");
  const queryClient = useQueryClient();
  const [editId, setEditId] = useState<string | null>(null);
  const [editRow, setEditRow] = useState<Record<string, any>>({});
  const [addMode, setAddMode] = useState(false);
  const [newRow, setNewRow] = useState<Record<string, any>>({});
  const [pianificaOpen, setPianificaOpen] = useState(false);
  const [pianificaCtx, setPianificaCtx] = useState<{
    currentPrice: number | null; newPrice: number; wsm01: number | null; wsm02: number | null;
  } | null>(null);

  const cdparKey = (article.cdpar ?? "").trim();
  const cdparPadded = cdparKey.padEnd(15, " ");
  const cdfor = (article.pcfor ?? "").trim() || null;
  const { data: activePriceList } = useActivePriceList();
  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["price_lists", cdparKey, "v2"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("archivio_listini_fraschetti")
        .select("id,cdpar,cdfor,rifli,dtvai,dtvaf,cdval,wprsc,prsc1,wscfa,wscfb,wscfc,wscfd,wscfe,wmasc,wfcas,wcpfa,wcpfb,wcpfc,wuord,wusto,wcaaa,wcsaa")
        .eq("cdpar", cdparKey)
        .order("dtvai", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 30_000,
  });

  // Suppliers present in the rows → load differenziale_cambio
  const supplierCodes = useMemo(() => {
    const s = new Set<string>();
    rows.forEach((r: any) => { if (r.cdfor) s.add(String(r.cdfor)); });
    return Array.from(s);
  }, [rows]);

  const { data: diffMap = {} } = useQuery({
    queryKey: ["diff_cambio", supplierCodes.sort().join(",")],
    enabled: supplierCodes.length > 0,
    queryFn: async () => {
      // SOLO riga differenziale cambio (wcacq='§DC'), non la "Generico"
      const { data, error } = await supabase
        .from("differenziale_cambio")
        .select("wcdfo,wan02,wcacq,wscfa,wcdva")
        .in("wcdfo", supplierCodes)
        .eq("wcacq", "§DC");
      if (error) throw error;
      const m: Record<string, any> = {};
      (data ?? []).forEach((d: any) => { m[String(d.wcdfo).trim()] = d; });
      return m;
    },
    staleTime: 5 * 60 * 1000,
  });


  // Latest exchange rate per (cdval → EURO)
  const { data: rateMap = {} } = useQuery({
    queryKey: ["tassi_cambio_latest_eur"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("tassi_di_cambio")
        .select("cdval,cdva2,dtval,cambi")
        .order("dtval", { ascending: false });
      if (error) throw error;
      const m: Record<string, number> = {};
      (data ?? []).forEach((t: any) => {
        const from = String(t.cdval ?? "").trim().toUpperCase();
        const to = String(t.cdva2 ?? "").trim().toUpperCase();
        if (!from || (to && to !== "EURO" && to !== "EUR")) return;
        if (!(from in m)) m[from] = Number(t.cambi) || 0;
      });
      m["EUR"] = 1; m["EURO"] = 1;
      return m;
    },
    staleTime: 5 * 60 * 1000,
  });

  // Latest market rate per cdval from currency_rates_daily
  const { data: marketMap = {} } = useQuery({
    queryKey: ["currency_rates_daily_latest_map"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("currency_rates_daily")
        .select("cdval,market_rate,delta_pct,rate_date")
        .order("rate_date", { ascending: false });
      if (error) throw error;
      const m: Record<string, { market: number; delta: number | null; date: string }> = {};
      (data ?? []).forEach((r: any) => {
        const code = String(r.cdval ?? "").trim().toUpperCase();
        if (!code || code in m) return;
        m[code] = {
          market: Number(r.market_rate) || 0,
          delta: r.delta_pct == null ? null : Number(r.delta_pct),
          date: r.rate_date,
        };
      });
      return m;
    },
    staleTime: 5 * 60 * 1000,
  });

  // Conversione in EUR: valore / (cambio * (1 - wscfa/100))
  // wscfa = correttore differenziale fornitore (può essere 0 se assente)
  function convertToEur(value: number, cdval: any, cdfor: any): { eur: number | null; rate: number; wscfa: number; reason?: string } {
    const code = String(cdval ?? "").trim().toUpperCase();
    const dc = diffMap[String(cdfor ?? "").trim()];
    const wscfa = dc ? (Number(dc.wscfa) || 0) : 0;
    if (!code || code === "EUR" || code === "EURO") {
      return { eur: value, rate: 1, wscfa: 0 };
    }
    const rate = rateMap[code] ?? 0;
    if (!rate) return { eur: null, rate: 0, wscfa, reason: "Cambio non disponibile" };
    const denom = rate * (1 - wscfa / 100);
    if (denom === 0) return { eur: null, rate, wscfa, reason: "Denominatore nullo" };
    return { eur: value / denom, rate, wscfa };
  }

  function getDiffWscfa(cdfor: any): number | null {
    const dc = diffMap[String(cdfor ?? "").trim()];
    if (!dc) return null;
    return Number(dc.wscfa) || 0;
  }



  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("archivio_listini_fraschetti")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Eliminato", description: "Riga listino eliminata." });
      queryClient.invalidateQueries({ queryKey: ["price_lists", cdparKey] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const saveMutation = useMutation({
    mutationFn: async ({ id, values }: { id?: string; values: Record<string, any> }) => {
      const cleaned = { ...values };
      for (const k of ["wprsc", "wscfa", "wscfb", "wscfc", "wscfd", "wscfe", "wmasc", "dtvai", "dtvaf", "wcpfa", "wcpfb", "wcpfc", "prsc1", "wfcas"]) {
        cleaned[k] = cleaned[k] === "" || cleaned[k] == null ? null : Number(cleaned[k]);
      }
      if (cleaned.dtvaf && cleaned.dtvai && cleaned.dtvaf <= cleaned.dtvai) {
        throw new Error("La data fine validità deve essere successiva alla data inizio.");
      }
      // These are virtual UI columns: Netto Acq is calculated from the current
      // visible cost fields, while stored wcaaa/wcsaa are not edited here.
      delete cleaned._netto_acq;
      delete cleaned._netto_stoc;
      delete cleaned._netto_acq_eur;
      delete cleaned._netto_stoc_eur;
      delete cleaned.id;
      delete cleaned.cdpar;

      if (id) {
        const { error } = await supabase.from("archivio_listini_fraschetti").update(cleaned as any).eq("id", id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("archivio_listini_fraschetti").insert({ ...cleaned, cdpar: cdparKey });
        if (error) throw error;
      }
      return { id: editId };
    },
    onSuccess: () => {
      toast({ title: "Salvato", description: "Listino aggiornato." });
      setEditId(null);
      setAddMode(false);
      setNewRow({});
      queryClient.invalidateQueries({ queryKey: ["price_lists", cdparKey] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  // Find the habitual supplier row: pcfor match with the most recent dtvai
  const habitualSupplier = article.pcfor?.trim() || "";
  const habitualRowId = useMemo(() => {
    if (!habitualSupplier) return null;
    const matching = rows.filter((r: any) => r.cdfor?.trim() === habitualSupplier);
    if (matching.length === 0) return null;
    matching.sort((a: any, b: any) => (Number(b.dtvai) || 0) - (Number(a.dtvai) || 0));
    return matching[0].id;
  }, [rows, habitualSupplier]);

  const [headerSlot, setHeaderSlot] = useState<HTMLElement | null>(null);
  useEffect(() => {
    const el = document.getElementById("costario-header-slot");
    setHeaderSlot(el);
  }, []);

  // Active list criterio (wsm01/wsm02) + current prmil for "Pianifica nuovo listino"
  const { data: criterioInfo } = useQuery({
    queryKey: ["criterio_for_pianifica", cdparKey, activePriceList],
    enabled: !!activePriceList,
    queryFn: async () => {
      const [{ data: criList }, { data: detList }] = await Promise.all([
        supabase.from("listini_vendita_criteri_prezzo").select("wsm01,wsm02").in("wcdpa", [cdparKey, cdparPadded]).eq("wcdls", activePriceList!).limit(1),
        supabase.from("listini_vendita_dettagli" as any).select("prmil").in("cdarl", [cdparKey, cdparPadded]).eq("cdlsl", activePriceList!).limit(1),
      ]);
      const cri = (criList ?? [])[0] as any;
      const det = (detList ?? [])[0] as any;
      return {
        wsm01: cri?.wsm01 != null ? Number(cri.wsm01) : null,
        wsm02: cri?.wsm02 != null ? Number(cri.wsm02) : null,
        prmil: (det as any)?.prmil != null ? Number((det as any).prmil) : null,
      };
    },
    staleTime: 60_000,
  });

  function handlePianifica(row: any) {
    if (!activePriceList) {
      toast({ title: "Listino non configurato", variant: "destructive" });
      return;
    }
    if (!criterioInfo?.wsm01 && !criterioInfo?.wsm02) {
      toast({ title: "Criterio prezzo mancante", description: "Nessun ricarico configurato per questo listino.", variant: "destructive" });
      return;
    }
    const merged = { ...row, ...editRow };
    const netto = computeSupplierCostBase(merged);
    const sm01 = criterioInfo.wsm01 ?? 0;
    const sm02 = criterioInfo.wsm02 ?? 0;
    const factor = (1 + sm01 / 100) * (1 + sm02 / 100);
    const newPrmil = Math.round(netto * factor * 100) / 100;
    setPianificaCtx({
      currentPrice: criterioInfo?.prmil ?? null,
      newPrice: newPrmil,
      wsm01: sm01,
      wsm02: sm02,
    });
    setPianificaOpen(true);
  }


  // Build effective rate items (must be before any early return to keep hook order stable)
  const rateItems = useMemo(() => {
    const seen = new Set<string>();
    const items: { code: string; rate: number; diff: number; effective: number }[] = [];
    rows.forEach((r: any) => {
      const code = String(r.cdval ?? "").trim().toUpperCase();
      if (!code || code === "EUR" || code === "EURO") return;
      if (seen.has(code)) return;
      seen.add(code);
      const rate = rateMap[code];
      if (!rate) return;
      const dc = diffMap[String(r.cdfor ?? "").trim()];
      let diff = 0;
      if (dc) {
        const wan02 = String(dc.wan02 ?? "").trim().toUpperCase();
        const wcacq = String(dc.wcacq ?? "").trim().toUpperCase();
        if (wan02 !== "A" && wcacq === "Â§DC") {
          diff = Number(dc.wscfa) || 0;
        }
      }
      const effective = rate * (1 - diff / 100);
      items.push({ code, rate, diff, effective });
    });
    return items;
  }, [rows, rateMap, diffMap]);

  if (isLoading) return <div className="p-4 text-muted-foreground">Caricamento...</div>;

  const visibleCols = COLS.filter((c) => c.key.startsWith("_netto") || fieldVisible("articles_pricing", c.key));

  const COMPUTED = new Set(["_netto_acq", "_netto_stoc", "_diff_cambio", "_netto_acq_eur", "_netto_stoc_eur"]);

  function renderComputed(c: { key: string }, r: any) {
    const acq = computeNetPrice(r);
    const stoc = computeStocPrice(r);

    const sym = currencySymbol(r.cdval);
    const fmt = (n: number) => n.toFixed(5).replace(".", ",");
    const fmtPct = (n: number) => `${n.toFixed(2).replace(".", ",")}%`;
    const fmtRate = (n: number) => n.toFixed(4).replace(".", ",");

    if (c.key === "_netto_acq") {
      return <Badge variant="secondary" className="text-[10px]">{sym}{fmt(acq)}</Badge>;
    }
    if (c.key === "_netto_stoc") {
      return <Badge variant="secondary" className="text-[10px]">{sym}{fmt(stoc)}</Badge>;
    }
    if (c.key === "_diff_cambio") {
      const w = getDiffWscfa(r.cdfor);
      if (w == null) return <Badge variant="outline" className="text-[10px] text-muted-foreground">—</Badge>;
      return <Badge variant="secondary" className="text-[10px]" title={`wscfa fornitore ${r.cdfor}`}>{fmtPct(w)}</Badge>;
    }
    if (c.key === "_netto_acq_eur" || c.key === "_netto_stoc_eur") {
      const base = c.key === "_netto_acq_eur" ? acq : stoc;
      const { eur, rate, wscfa, reason } = convertToEur(base, r.cdval, r.cdfor);
      if (eur == null) {
        return <Badge variant="outline" className="text-[10px] text-muted-foreground" title={reason}>—</Badge>;
      }
      const code = String(r.cdval ?? "").trim().toUpperCase();
      const isEur = !code || code === "EUR" || code === "EURO";
      const tooltip = isEur
        ? `${sym}${fmt(base)} (già in €)`
        : `${sym}${fmt(base)} / ${fmtRate(rate)} ${wscfa ? `× (1 - ${fmtPct(wscfa)})` : ""} = €${fmt(eur)}`;
      return <Badge variant="default" className="text-[10px]" title={tooltip}>€{fmt(eur)}</Badge>;
    }
    return null;
  }






  const enrichedItems = rateItems.map((it) => {
    const mk = marketMap[it.code];
    const localDelta = mk && it.effective
      ? ((mk.market - it.effective) / it.effective) * 100
      : null;
    return { ...it, market: mk?.market ?? null, delta: localDelta };
  });

  const deltaCls = (d: number | null) =>
    d == null ? "text-muted-foreground"
    : Math.abs(d) < 2 ? "text-emerald-600 dark:text-emerald-400"
    : Math.abs(d) < 5 ? "text-amber-600 dark:text-amber-400"
    : "text-destructive";

  const headerBadge = enrichedItems.length === 0 ? null : (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          className="inline-flex items-center gap-2 rounded-md border bg-background px-2 py-1 text-[11px] hover:bg-accent transition-colors"
        >
          <span className="font-semibold text-muted-foreground uppercase tracking-wide text-[10px]">
            Δ Mercato
          </span>
          {enrichedItems.map((it) => (
            <span key={it.code} className="inline-flex items-center gap-1">
              <span className="font-mono font-semibold">{it.code}</span>
              <span className={`font-semibold ${deltaCls(it.delta)}`}>
                {it.delta != null ? `${it.delta > 0 ? "+" : ""}${it.delta.toFixed(1)}%` : "—"}
              </span>
            </span>
          ))}
          <ChevronDown className="h-3 w-3 text-muted-foreground" />
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-3 text-xs space-y-2">
        <div className="font-semibold text-muted-foreground uppercase tracking-wide text-[10px]">
          Cambio effettivo → EUR
        </div>
        {enrichedItems.map((it) => (
          <div key={it.code} className="space-y-0.5 border-b last:border-b-0 pb-1.5 last:pb-0">
            <div className="flex items-center justify-between">
              <span className="font-mono font-semibold">{it.code}</span>
              <span className="font-mono text-primary font-semibold">
                {it.effective.toLocaleString("it-IT", { maximumFractionDigits: 4 })}
              </span>
            </div>
            <div className="flex justify-between text-[10px] text-muted-foreground">
              <span>AS400: {it.rate.toLocaleString("it-IT", { maximumFractionDigits: 4 })}{it.diff !== 0 && ` · diff ${it.diff > 0 ? "+" : ""}${it.diff}%`}</span>
            </div>
            <div className="flex justify-between text-[10px]">
              <span className="text-muted-foreground">
                Mercato: {it.market != null ? it.market.toLocaleString("it-IT", { maximumFractionDigits: 4 }) : "—"}
              </span>
              <span className={`font-semibold ${deltaCls(it.delta)}`}>
                {it.delta != null ? `Δ ${it.delta > 0 ? "+" : ""}${it.delta.toFixed(2)}%` : "Δ —"}
              </span>
            </div>
          </div>
        ))}
      </PopoverContent>
    </Popover>
  );

  return (
    <div className="space-y-3">
      {headerSlot && headerBadge && createPortal(headerBadge, headerSlot)}
      <div className="flex items-center justify-end gap-3">
        <span className="text-sm text-muted-foreground">{rows.length} costi trovati</span>
        {canWrite && !addMode && (
          <Button size="sm" variant="outline" onClick={() => { setAddMode(true); setNewRow({}); }}>
            <Plus className="h-3 w-3 mr-1" /> Aggiungi
          </Button>
        )}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="border-b">
              {visibleCols.map((c) => (
                <th key={c.key} className="px-1.5 py-1.5 text-left font-medium text-muted-foreground whitespace-nowrap">{c.label}</th>
              ))}
              {canWrite && <th className="px-1 py-1.5 w-14" />}
            </tr>
          </thead>
          <tbody>
            {rows.map((row: any) => {
              const isEditing = editId === row.id;
              const r = isEditing ? editRow : row;
              const isHabitual = row.id === habitualRowId;
              return (
                <tr key={row.id} className={`border-b ${isHabitual ? "bg-primary/10 ring-1 ring-inset ring-primary/30" : "hover:bg-accent/30"}`}>
                  {visibleCols.map((c) => {
                    const canWriteField = !COMPUTED.has(c.key) && canField("write", "articles_pricing", c.key);
                    return (
                    <td key={c.key} className="px-1.5 py-1">
                      {COMPUTED.has(c.key) ? (
                        renderComputed(c, r)
                      ) : isEditing && canWriteField ? (
                        <Input className="h-6 text-xs p-1 min-w-[50px]" value={editRow[c.key] ?? ""} onChange={(e) => setEditRow({ ...editRow, [c.key]: e.target.value })} />
                      ) : c.key === "cdfor" && isHabitual ? (
                        <span className="flex items-center gap-1 font-semibold text-primary whitespace-nowrap">
                          <Star className="h-3 w-3 fill-primary" />{row[c.key] ?? ""}
                        </span>
                      ) : (
                        <span className="truncate block whitespace-nowrap">{formatDecimal(row[c.key], (c as any).decimals)}</span>
                      )}
                    </td>
                    );
                  })}
                  {canWrite && (
                    <td className="px-1 py-1">
                      <div className="flex gap-0.5">
                        {isEditing ? (
                          <>
                            <Button size="icon" variant="ghost" className="h-5 w-5" onClick={() => saveMutation.mutate({ id: row.id, values: editRow })} title="Salva costo">
                              <Save className="h-3 w-3" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-5 w-5 text-primary" onClick={() => handlePianifica(row)} title="Pianifica nuovo prezzo di listino">
                              <CalendarClock className="h-3 w-3" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-5 w-5" onClick={() => setEditId(null)}>
                              <X className="h-3 w-3" />
                            </Button>
                          </>
                        ) : (
                          <>
                    <Button size="icon" variant="ghost" className="h-5 w-5" onClick={() => { setEditId(row.id); setEditRow({ ...row }); }}>
                      <Pencil className="h-3 w-3" />
                    </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button size="icon" variant="ghost" className="h-5 w-5 text-destructive">
                                  <Trash2 className="h-3 w-3" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Conferma eliminazione</AlertDialogTitle>
                                  <AlertDialogDescription>Eliminare questa riga listino?</AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Annulla</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => deleteMutation.mutate(row.id)}>Elimina</AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </>
                        )}
                      </div>
                    </td>
                  )}
                </tr>
              );
            })}

            {/* Add row */}
            {addMode && (
              <tr className="border-b bg-primary/5">
                {visibleCols.map((c) => (
                  <td key={c.key} className="px-1.5 py-1">
                    {COMPUTED.has(c.key) ? (
                      <span className="text-muted-foreground">—</span>
                    ) : (
                      <Input className="h-6 text-xs p-1 min-w-[50px]" value={newRow[c.key] ?? ""} onChange={(e) => setNewRow({ ...newRow, [c.key]: e.target.value })} />
                    )}
                  </td>
                ))}
                <td className="px-1 py-1">
                  <div className="flex gap-0.5">
                    <Button size="icon" variant="ghost" className="h-5 w-5" onClick={() => saveMutation.mutate({ values: newRow })}>
                      <Save className="h-3 w-3" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-5 w-5" onClick={() => setAddMode(false)}>
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {pianificaCtx && activePriceList && (
        <PianificaPrezzoDialog
          open={pianificaOpen}
          onOpenChange={setPianificaOpen}
          cdpar={cdparKey}
          wcdls={activePriceList}
          wcdca={cdfor}
          currentPrice={pianificaCtx.currentPrice}
          newPrice={pianificaCtx.newPrice}
          wsm01={pianificaCtx.wsm01}
          wsm02={pianificaCtx.wsm02}
          onSuccess={() => setEditId(null)}
        />
      )}
    </div>
  );
}

import { useMemo, useState, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/lib/permissions";
import { useAuth } from "@/contexts/AuthContext";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, Star } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Props {
  article: Record<string, any>;
}

/* ── Column definitions ─────────────────────────────────────── */

const DROPDOWN_OPTIONS: Record<string, string[]> = {
  wviqm: ["", "S", "N"],
  wviim: ["", "S", "N"],
  wqtde: ["", "S", "N"],
  wtaim: ["", "A", "E", "T"],
  wumqm: ["", "KG", "LT", "MT", "NR", "PZ", "SC"],
  wumim: ["", "KG", "LT", "MT", "NR", "PZ", "SC"],
  cdval: ["", "EUR", "USD", "GBP", "CHF", "JPY", "CNY"],
};

const SUPPLIER_FIELDS = [
  { key: "cdfor", label: "Cod. Forn.", w: "w-20", readOnly: true },
  { key: "cdpfo", label: "Cod. Art. Forn.", w: "w-24" },
  { key: "qtmio", label: "Qtà Min. ACQ.", w: "w-16", type: "number" },
  { key: "wumqm", label: "UM Qtà MIN", w: "w-14", dropdown: true },
  { key: "wimbf", label: "Imballo Forn.", w: "w-16", type: "number" },
  { key: "wumim", label: "UM Imb. For.", w: "w-14", dropdown: true },
  { key: "wviqm", label: "Viqm", w: "w-12", dropdown: true },
  { key: "wviim", label: "Viim", w: "w-12", dropdown: true },
  { key: "wqtde", label: "Qtà Decimali", w: "w-12", dropdown: true },
  { key: "wtaim", label: "Arr. Imb.", w: "w-16", dropdown: true },
  { key: "cdval", label: "Valuta", w: "w-16", dropdown: true },
] as const;

/* ── Main component ─────────────────────────────────────────── */

export function TabPurchase({ article }: Props) {
  const { can, canField, fieldVisible } = usePermissions();
  const canWrite = can("write", "articles_purchase");
  const { user, profile } = useAuth();
  const queryClient = useQueryClient();

  const habitualSupplier = article.pcfor?.trim() || "";
  const cdparKey = (article.cdpar ?? "").trim();

  const { data, isLoading, error } = useQuery({
    queryKey: ["purchase_section", cdparKey],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("archivio_anag_art_fornitore")
        .select("*")
        .eq("cdpar", cdparKey)
        .order("cdfor", { ascending: true });
      if (error) throw error;
      return {
        suppliers: (data ?? []) as Record<string, any>[],
      };
    },
    staleTime: 5 * 60 * 1000,
  });

  // Fetch distinct values for dropdowns to merge with defaults
  const { data: distinctValues } = useQuery({
    queryKey: ["purchase_dropdown_options"],
    queryFn: async () => {
      const fields = Object.keys(DROPDOWN_OPTIONS);
      const results: Record<string, string[]> = {};
      const { data: rows } = await supabase
        .from("archivio_anag_art_fornitore")
        .select(fields.join(","))
        .limit(1000);
      for (const field of fields) {
        const vals = new Set(DROPDOWN_OPTIONS[field]);
        (rows ?? []).forEach((r: any) => {
          const v = r[field];
          if (v != null && String(v).trim() !== "") vals.add(String(v).trim());
        });
        results[field] = [...vals].sort();
      }
      return results;
    },
    staleTime: 30 * 60 * 1000,
  });

  const dropdownOptions = distinctValues ?? DROPDOWN_OPTIONS;

  /* ── Editable state for suppliers ─────────────────────────── */
  const [supplierEdits, setSupplierEdits] = useState<Record<string, Record<string, any>>>({});

  const onSupplierChange = useCallback((rowId: string, field: string, value: string) => {
    setSupplierEdits((prev) => ({
      ...prev,
      [rowId]: { ...(prev[rowId] ?? {}), [field]: value },
    }));
  }, []);

  const supplierRows = useMemo(() => data?.suppliers ?? [], [data]);

  const hasDirty = Object.keys(supplierEdits).length > 0;

  /* ── Save mutation ────────────────────────────────────────── */
  const saveMutation = useMutation({
    mutationFn: async () => {
      const promises: Promise<any>[] = [];

      for (const [rowId, changes] of Object.entries(supplierEdits)) {
        if (Object.keys(changes).length === 0) continue;
        const cleaned: Record<string, any> = {};
        for (const [k, v] of Object.entries(changes)) {
          const fieldDef = SUPPLIER_FIELDS.find((f) => f.key === k);
          if (fieldDef && "type" in fieldDef && fieldDef.type === "number") {
            cleaned[k] = v === "" ? null : Number(v);
          } else {
            cleaned[k] = v === "" ? null : v;
          }
        }
        promises.push(
          supabase
            .from("archivio_anag_art_fornitore")
            .update(cleaned as any)
            .eq("id", rowId)
            .then(({ error }) => { if (error) throw error; }) as unknown as Promise<any>
        );
      }

      await Promise.all(promises);

      await supabase.from("audit_log" as any).insert({
        table_name: "purchase_section",
        record_id: article.cdpar,
        operation: "update",
        old_values: {},
        new_values: { supplierEdits },
        changed_fields: [...Object.keys(supplierEdits)],
        user_id: user?.id,
        user_email: profile?.email,
      });
    },
    onSuccess: () => {
      toast({ title: "Salvato", description: "Dati acquisto aggiornati." });
      setSupplierEdits({});
      queryClient.invalidateQueries({ queryKey: ["purchase_section", cdparKey] });
    },
    onError: (e: Error) => {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    },
  });

  if (isLoading) return <div className="py-2 text-xs text-muted-foreground">Caricamento...</div>;
  if (error) return <div className="py-2 text-xs text-destructive">Errore caricamento dati acquisto.</div>;

  return (
    <div className="space-y-4">
      {canWrite && hasDirty && (
        <div className="flex justify-end">
          <Button size="sm" onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending}>
            <Save className="h-3.5 w-3.5 mr-1" />
            {saveMutation.isPending ? "Salvataggio..." : "Salva Acquisto"}
          </Button>
        </div>
      )}

      <PurchaseBlock title="Dati Fornitore" count={supplierRows.length}>
        {supplierRows.length > 0 ? (
          <EditableGrid
            fields={SUPPLIER_FIELDS.filter((f) => fieldVisible("articles_purchase", f.key))}
            rows={supplierRows}
            edits={supplierEdits}
            onChange={onSupplierChange}
            canWrite={canWrite}
            canFieldWrite={(fieldKey: string) => canField("write", "articles_purchase", fieldKey)}
            habitualSupplier={habitualSupplier}
            dropdownOptions={dropdownOptions}
          />
        ) : (
          <EmptyState message="Nessun dato fornitore disponibile." />
        )}
      </PurchaseBlock>
    </div>
  );
}

/* ── Sub-components ─────────────────────────────────────────── */

function PurchaseBlock({ title, count, children }: { title: string; count: number; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center gap-2">
        <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{title}</h3>
        <span className="text-[10px] text-muted-foreground">({count})</span>
      </div>
      {children}
    </div>
  );
}

function EditableGrid({
  fields,
  rows,
  edits,
  onChange,
  canWrite,
  canFieldWrite,
  habitualSupplier,
  dropdownOptions,
}: {
  fields: readonly { key: string; label: string; w: string; type?: string; readOnly?: boolean; dropdown?: boolean }[];
  rows: Record<string, any>[];
  edits: Record<string, Record<string, any>>;
  onChange: (rowId: string, field: string, value: string) => void;
  canWrite: boolean;
  canFieldWrite?: (fieldKey: string) => boolean;
  habitualSupplier: string;
  dropdownOptions: Record<string, string[]>;
}) {
  return (
    <div className="space-y-1">
      {rows.map((row, rowIndex) => {
        const rowId = row.id ?? `row-${rowIndex}`;
        const rowEdits = edits[rowId] ?? {};
        const isHabitual = habitualSupplier && row.cdfor?.trim() === habitualSupplier;

        return (
          <div key={rowId}>
            {rowIndex === 0 && (
              <div className="grid gap-x-2 gap-y-0.5" style={{ gridTemplateColumns: `repeat(${fields.length}, minmax(0, 1fr))` }}>
                {fields.map((f) => (
                  <span key={`h-${f.key}`} className="text-[10px] leading-tight text-muted-foreground truncate">
                    {f.label}
                  </span>
                ))}
              </div>
            )}
            <div
              className={`grid gap-x-2 gap-y-0.5 rounded-sm px-1 py-0.5 ${isHabitual ? "bg-primary/10 ring-1 ring-primary/30" : ""}`}
              style={{ gridTemplateColumns: `repeat(${fields.length}, minmax(0, 1fr))` }}
            >
              {fields.map((f) => {
                const isReadOnly = !canWrite || f.readOnly || (canFieldWrite ? !canFieldWrite(f.key) : false);
                const currentValue = rowEdits[f.key] !== undefined ? rowEdits[f.key] : (row[f.key] ?? "");
                const isDirty = rowEdits[f.key] !== undefined;

                if (f.dropdown && !isReadOnly) {
                  const options = dropdownOptions[f.key] ?? DROPDOWN_OPTIONS[f.key] ?? [];
                  return (
                    <Select
                      key={f.key}
                      value={String(currentValue)}
                      onValueChange={(v) => onChange(rowId, f.key, v === "__empty__" ? "" : v)}
                    >
                      <SelectTrigger className={`h-7 text-xs px-1.5 ${isDirty ? "border-primary" : ""}`}>
                        <SelectValue placeholder="—" />
                      </SelectTrigger>
                      <SelectContent>
                        {options.map((opt) => (
                          <SelectItem key={opt || "__empty__"} value={opt || "__empty__"}>
                            {opt || "—"}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  );
                }

                return (
                  <div key={f.key} className="flex items-center gap-1">
                    {f.key === "cdfor" && isHabitual && (
                      <Star className="h-3 w-3 text-primary fill-primary shrink-0" />
                    )}
                    <Input
                      value={currentValue}
                      onChange={(e) => onChange(rowId, f.key, e.target.value)}
                      readOnly={isReadOnly}
                      type={f.type ?? "text"}
                      className={`h-7 text-xs px-1.5 ${isReadOnly ? "bg-muted" : ""} ${isDirty ? "border-primary" : ""} ${f.key === "cdfor" && isHabitual ? "font-semibold text-primary" : ""}`}
                    />
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function EmptyState({ message }: { message: string }) {
  return <div className="px-3 py-3 text-xs text-muted-foreground">{message}</div>;
}

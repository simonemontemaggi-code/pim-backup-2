import { useLookupValues } from "@/hooks/useLookupValues";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

interface Props {
  category: string;
  value: string;
  onChange: (val: string) => void;
  disabled?: boolean;
  className?: string;
  placeholder?: string;
  parentCode?: string;
  labelOnly?: boolean;
}

export function LookupSelect({ category, value, onChange, disabled, className, placeholder, parentCode, labelOnly }: Props) {
  const { data: allOptions = [] } = useLookupValues(category);

  // Trim value: AS400 often pads codes with trailing spaces (e.g. "X              ")
  // while lookup_values.code stores them trimmed.
  const trimmedValue = (value ?? "").trim();

  // Filter by parent if provided
  const options = parentCode
    ? allOptions.filter((o) => o.parent_code === parentCode)
    : allOptions;

  const selected = options.find((o) => o.code === trimmedValue);
  const displayLabel = selected
    ? labelOnly
      ? (selected.label && selected.label !== selected.code ? selected.label : selected.code)
      : selected.label && selected.label !== selected.code
        ? `${selected.code} — ${selected.label}`
        : selected.code
    : undefined;

  return (
    <Select value={trimmedValue || ""} onValueChange={onChange} disabled={disabled}>
      <SelectTrigger className={className ?? "h-7 text-xs"}>
        {displayLabel ? (
          <span className="truncate text-xs">{displayLabel}</span>
        ) : (
          <SelectValue placeholder={placeholder ?? "—"} />
        )}
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="__empty__">
          <span className="text-muted-foreground">— Vuoto —</span>
        </SelectItem>
        {options.map((opt) => (
          <SelectItem key={opt.id} value={opt.code}>
            {labelOnly ? (
              <span className="text-xs">{opt.label && opt.label !== opt.code ? opt.label : opt.code}</span>
            ) : (
              <>
                <span className="font-mono text-xs">{opt.code}</span>
                {opt.label && opt.label !== opt.code && (
                  <span className="text-muted-foreground ml-1.5 text-xs">— {opt.label}</span>
                )}
              </>
            )}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

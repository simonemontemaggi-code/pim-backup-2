import { useEffect, useState } from "react";
import { format } from "date-fns";
import { AlertTriangle, CalendarIcon, CircleDot, Clock, Pencil, X, Loader2 } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import {
  useAssortmentStatus,
  useDeleteAssortmentFuture,
} from "@/hooks/useAssortmentHistory";
import {
  as400DateToDisplay,
  as400DateToJsDate,
  jsDateToAs400,
  todayAs400Date,
} from "@/lib/dateUtils";
import { toast } from "sonner";

interface Props {
  cdpar: string;
  /** Current value of wfuas in the form (may differ from DB if user just changed it) */
  formStatus: string;
  /** Effective DB value of wfuas (current state from history) */
  originalStatus: string;
  /** Selected effective date in AAAAMMGG (controlled) */
  effectiveDate: string;
  onEffectiveDateChange: (as400: string) => void;
  /** Called when user clicks "Modifica" on a planned change → preload editor */
  onEditFuture?: (wstato: string, wdtdec: string) => void;
  disabled?: boolean;
}

export function AssortmentStatusPanel({
  cdpar,
  formStatus,
  originalStatus,
  effectiveDate,
  onEffectiveDateChange,
  onEditFuture,
  disabled,
}: Props) {
  const { data } = useAssortmentStatus(cdpar);
  const deleteFuture = useDeleteAssortmentFuture();
  const statusChanged = (formStatus ?? "") !== (originalStatus ?? "");

  // Default the effective date to today when the user first changes status
  useEffect(() => {
    if (statusChanged && !effectiveDate) {
      onEffectiveDateChange(jsDateToAs400(todayAs400Date()));
    }
    if (!statusChanged && effectiveDate) {
      onEffectiveDateChange("");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusChanged]);

  const [open, setOpen] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const selectedDate = effectiveDate ? as400DateToJsDate(effectiveDate) : undefined;

  const handleDelete = async () => {
    if (!data?.future) return;
    try {
      await deleteFuture.mutateAsync({ cdpar, wprogr: data.future.wprogr });
      toast.success("Pianificazione annullata");
    } catch (e: any) {
      toast.error(`Errore: ${e?.message ?? e}`);
    } finally {
      setConfirmDelete(false);
    }
  };

  const handleEditFuture = () => {
    if (!data?.future || !onEditFuture) return;
    onEditFuture(data.future.wstato, data.future.wdtdec);
  };

  return (
    <>
      <div className="mt-3 rounded-md border border-border bg-muted/30 px-3 py-3 space-y-2.5 text-xs">
        {/* Riga: Stato attuale (sempre da archivio.wfuas → originalStatus) */}
        <div className="flex items-center gap-2">
          <CircleDot className="h-3 w-3 text-muted-foreground shrink-0" />
          <span className="text-muted-foreground w-20 shrink-0">Attuale</span>
          {originalStatus ? (
            <Badge variant="secondary" className="font-mono">
              {originalStatus}
            </Badge>
          ) : (
            <span className="text-muted-foreground italic">—</span>
          )}
          {data?.current && (
            <span className="text-muted-foreground">
              dal {as400DateToDisplay(data.current.wdtdec)}
            </span>
          )}
        </div>

        {/* Warning: storico disallineato rispetto a archivio.wfuas */}
        {data?.current && originalStatus && data.current.wstato !== originalStatus && (
          <div className="flex items-start gap-2 rounded border border-amber-500/40 bg-amber-500/10 px-2 py-1.5 text-amber-700 dark:text-amber-400">
            <AlertTriangle className="h-3 w-3 mt-0.5 shrink-0" />
            <span>
              Storico disallineato: ultima riga{" "}
              <span className="font-mono font-semibold">{data.current.wstato}</span> dal{" "}
              {as400DateToDisplay(data.current.wdtdec)}. Lo stato attuale ({originalStatus})
              è quello sincronizzato da AS400.
            </span>
          </div>
        )}


        {/* Riga: Pianificato (se esiste) */}
        {data?.future && (
          <div className="flex items-center gap-2">
            <Clock className="h-3 w-3 text-primary shrink-0" />
            <span className="text-muted-foreground w-20 shrink-0">Pianificato</span>
            <Badge variant="outline" className="font-mono border-primary text-primary">
              {data.future.wstato}
            </Badge>
            <span className="text-muted-foreground">
              dal {as400DateToDisplay(data.future.wdtdec)}
            </span>
            {!disabled && (
              <div className="ml-auto flex items-center gap-1">
                {onEditFuture && (
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    className="h-6 px-2 text-xs"
                    onClick={handleEditFuture}
                    disabled={deleteFuture.isPending}
                  >
                    <Pencil className="h-3 w-3 mr-1" />
                    Modifica
                  </Button>
                )}
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  className="h-6 px-2 text-xs text-destructive hover:text-destructive"
                  onClick={() => setConfirmDelete(true)}
                  disabled={deleteFuture.isPending}
                >
                  {deleteFuture.isPending ? (
                    <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                  ) : (
                    <X className="h-3 w-3 mr-1" />
                  )}
                  Annulla
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Riga: Decorrenza nuovo stato (solo quando wfuas è stato modificato) */}
        {statusChanged && (
          <div className="flex items-center gap-2 pt-1.5 border-t border-border/60">
            <CalendarIcon className="h-3 w-3 text-muted-foreground shrink-0" />
            <Label className="text-muted-foreground w-20 shrink-0">Decorrenza</Label>
            <Popover open={open} onOpenChange={setOpen}>
              <PopoverTrigger asChild>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  disabled={disabled}
                  className={cn(
                    "h-7 px-2 text-xs justify-start font-normal",
                    !selectedDate && "text-muted-foreground"
                  )}
                >
                  {selectedDate ? format(selectedDate, "dd/MM/yyyy") : "Scegli data"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(d) => {
                    if (d) {
                      onEffectiveDateChange(jsDateToAs400(d));
                      setOpen(false);
                    }
                  }}
                  disabled={(d) => {
                    const today = todayAs400Date();
                    return d < today;
                  }}
                  initialFocus
                  className={cn("p-3 pointer-events-auto")}
                />
              </PopoverContent>
            </Popover>
            <span className="text-muted-foreground">→ Nuovo:</span>
            <Badge variant="default" className="font-mono">
              {formStatus || "—"}
            </Badge>
          </div>
        )}
      </div>

      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Annullare la pianificazione?</AlertDialogTitle>
            <AlertDialogDescription>
              Lo stato pianificato{" "}
              <span className="font-mono font-semibold">{data?.future?.wstato}</span> dal{" "}
              {as400DateToDisplay(data?.future?.wdtdec)} verrà rimosso. Lo stato attuale
              resterà{" "}
              <span className="font-mono font-semibold">
                {data?.current?.wstato ?? originalStatus}
              </span>
              . AS400 si allineerà alla prossima sincronizzazione.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Conferma</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

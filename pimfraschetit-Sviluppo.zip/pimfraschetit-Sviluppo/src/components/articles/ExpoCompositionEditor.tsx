import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import * as XLSX from "xlsx";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Trash2, Plus, Store, GripVertical, Search, Loader2, Save, FileSpreadsheet, Download } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

type ExpoRow = {
  id?: string;
  _key: string;
  child_cdpar: string;
  quantity: number;
  note: string | null;
  sort_order: number;
  // resolved metadata
  description?: string | null;
};

interface Props {
  cdpar: string;
  canWrite: boolean;
}

const padCdpar = (v: string) => {
  const digits = (v || "").replace(/\D/g, "");
  return digits ? digits.padStart(6, "0") : "";
};

// PostgREST `.in()` strips trailing spaces from URL-encoded values, so matching
// the AS400 cdpar (padded to 16 chars with trailing spaces) fails. We query with
// ilike-prefix OR clauses (chunked) to robustly resolve descriptions.
async function fetchDescriptions(codes6: string[]): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  const clean = Array.from(new Set(codes6.filter((c) => /^\d{6}$/.test(c))));
  if (clean.length === 0) return map;
  const CHUNK = 50;
  for (let i = 0; i < clean.length; i += CHUNK) {
    const slice = clean.slice(i, i + CHUNK);
    const orExpr = slice.map((c) => `cdpar.ilike.${c}%`).join(",");
    const { data: arts } = await supabase
      .from("archivio_articoli_fraschetti")
      .select("cdpar, depar")
      .or(orExpr);
    for (const a of arts ?? []) {
      const key = (a.cdpar ?? "").trim();
      if (key && !map.has(key)) map.set(key, (a.depar ?? "").trim());
    }
  }
  return map;
}

export default function ExpoCompositionEditor({ cdpar, canWrite }: Props) {
  const qc = useQueryClient();
  const parent = padCdpar(cdpar);

  const { data, isLoading } = useQuery({
    queryKey: ["article_expo_items", parent],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("article_expo_items")
        .select("id, child_cdpar, quantity, note, sort_order")
        .eq("parent_cdpar", parent)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      const codes = Array.from(new Set((data ?? []).map((r) => r.child_cdpar.trim())));
      const descMap = await fetchDescriptions(codes);
      return (data ?? []).map((r, i) => ({
        ...r,
        _key: r.id!,
        sort_order: r.sort_order ?? i,
        description: descMap.get((r.child_cdpar ?? "").trim()) ?? null,
      })) as ExpoRow[];
    },
    enabled: !!parent,
  });

  const [rows, setRows] = useState<ExpoRow[]>([]);
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    if (data) {
      setRows(data);
      setDirty(false);
    }
  }, [data]);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  const handleDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const oldIdx = rows.findIndex((r) => r._key === active.id);
    const newIdx = rows.findIndex((r) => r._key === over.id);
    if (oldIdx < 0 || newIdx < 0) return;
    const next = arrayMove(rows, oldIdx, newIdx).map((r, i) => ({ ...r, sort_order: i }));
    setRows(next);
    setDirty(true);
  };

  const addRow = async (cdparChild: string, description?: string) => {
    const padded = padCdpar(cdparChild);
    if (!padded) return;
    if (padded === parent) {
      toast({ title: "Non puoi aggiungere l'articolo a se stesso", variant: "destructive" });
      return;
    }
    if (rows.some((r) => r.child_cdpar === padded)) {
      toast({ title: "Articolo già presente nell'Expo", variant: "destructive" });
      return;
    }
    let desc = description ?? null;
    if (!desc) {
      const map = await fetchDescriptions([padded]);
      desc = map.get(padded) ?? null;
    }
    setRows((prev) => [
      ...prev,
      {
        _key: `new-${Date.now()}-${Math.random()}`,
        child_cdpar: padded,
        quantity: 1,
        note: null,
        sort_order: prev.length,
        description: desc,
      },
    ]);
    setDirty(true);
  };

  const updateRow = (key: string, patch: Partial<ExpoRow>) => {
    setRows((prev) => prev.map((r) => (r._key === key ? { ...r, ...patch } : r)));
    setDirty(true);
  };

  const removeRow = (key: string) => {
    setRows((prev) => prev.filter((r) => r._key !== key).map((r, i) => ({ ...r, sort_order: i })));
    setDirty(true);
  };

  const bulkAdd = async (text: string) => {
    const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    if (lines.length === 0) return;
    type Parsed = { cdpar: string; qty: number; note: string | null };
    const parsed: Parsed[] = [];
    lines.forEach((line, idx) => {
      const cols = line.split(/\t|;|,|\s{2,}/).map((c) => c.trim()).filter(Boolean);
      if (idx === 0) {
        const head = cols.join(" ").toLowerCase();
        if (head.includes("cod") || head.includes("qt") || head.includes("descr")) return;
      }
      const code = padCdpar(cols[0] ?? "");
      if (!code) return;
      const qtyRaw = (cols[1] ?? "").replace(",", ".");
      const qty = Number(qtyRaw);
      const note = cols.slice(2).join(" ").trim() || null;
      parsed.push({ cdpar: code, qty: Number.isFinite(qty) && qty > 0 ? qty : 1, note });
    });
    if (parsed.length === 0) {
      toast({ title: "Nessuna riga valida nel testo incollato", variant: "destructive" });
      return;
    }

    const newCodes = parsed
      .map((p) => p.cdpar)
      .filter((c) => c !== parent && !rows.some((r) => r.child_cdpar === c));
    const uniqueNewCodes = Array.from(new Set(newCodes));
    const descMap = await fetchDescriptions(uniqueNewCodes);

    let added = 0;
    let updated = 0;
    let skipped = 0;
    let notFound = 0;

    setRows((prev) => {
      const next = [...prev];
      const seenInPaste = new Set<string>();
      for (const p of parsed) {
        if (p.cdpar === parent) { skipped++; continue; }
        if (seenInPaste.has(p.cdpar)) continue;
        seenInPaste.add(p.cdpar);
        const existingIdx = next.findIndex((r) => r.child_cdpar === p.cdpar);
        if (existingIdx >= 0) {
          next[existingIdx] = {
            ...next[existingIdx],
            quantity: p.qty,
            note: p.note ?? next[existingIdx].note,
          };
          updated++;
        } else {
          next.push({
            _key: `new-${Date.now()}-${Math.random()}`,
            child_cdpar: p.cdpar,
            quantity: p.qty,
            note: p.note,
            sort_order: next.length,
            description: descMap.get(p.cdpar) ?? null,
          });
          if (!descMap.has(p.cdpar)) notFound++;
          added++;
        }
      }
      return next.map((r, i) => ({ ...r, sort_order: i }));
    });
    setDirty(true);
    toast({
      title: "Righe incollate",
      description: `${added} aggiunti · ${updated} aggiornati${notFound ? ` · ${notFound} non trovati` : ""}${skipped ? ` · ${skipped} saltati` : ""}`,
    });
  };

  const save = async () => {
    if (!parent) return;
    // Validate
    for (const r of rows) {
      if (!padCdpar(r.child_cdpar)) {
        toast({ title: "Codice articolo non valido", variant: "destructive" });
        return;
      }
      if (!(Number(r.quantity) > 0)) {
        toast({ title: `Quantità non valida per ${r.child_cdpar}`, variant: "destructive" });
        return;
      }
    }
    setSaving(true);
    try {
      const existingIds = new Set((data ?? []).map((r) => r.id!));
      const currentIds = new Set(rows.filter((r) => r.id).map((r) => r.id!));
      const toDelete = [...existingIds].filter((id) => !currentIds.has(id));

      if (toDelete.length > 0) {
        const { error } = await supabase.from("article_expo_items").delete().in("id", toDelete);
        if (error) throw error;
      }

      const toInsert = rows
        .filter((r) => !r.id)
        .map((r) => ({
          parent_cdpar: parent,
          child_cdpar: padCdpar(r.child_cdpar),
          quantity: Number(r.quantity),
          note: r.note?.trim() ? r.note.trim() : null,
          sort_order: r.sort_order,
        }));
      if (toInsert.length > 0) {
        const { error } = await supabase.from("article_expo_items").insert(toInsert);
        if (error) throw error;
      }

      const toUpdate = rows.filter((r) => r.id);
      for (const r of toUpdate) {
        const { error } = await supabase
          .from("article_expo_items")
          .update({
            quantity: Number(r.quantity),
            note: r.note?.trim() ? r.note.trim() : null,
            sort_order: r.sort_order,
          })
          .eq("id", r.id!);
        if (error) throw error;
      }

      toast({ title: "Composizione Expo salvata" });
      await qc.invalidateQueries({ queryKey: ["article_expo_items", parent] });
      setDirty(false);
    } catch (e: any) {
      toast({ title: "Errore salvataggio", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const downloadTemplate = () => {
    const ws = XLSX.utils.aoa_to_sheet([
      ["Codice", "Qta"],
      ["011152", 2],
      ["011154", 1],
    ]);
    ws["!cols"] = [{ wch: 12 }, { wch: 8 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Expo");
    XLSX.writeFile(wb, "template_expo.xlsx");
  };

  const handleXlsxFile = async (file: File) => {
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array" });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const raw = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: "" });
      if (!raw.length) {
        toast({ title: "File vuoto", variant: "destructive" });
        return;
      }
      const tsv = raw
        .map((r) => `${String(r[0] ?? "")}\t${String(r[1] ?? "")}`)
        .join("\n");
      await bulkAdd(tsv);
    } catch (e: any) {
      toast({ title: "Errore lettura XLSX", description: e?.message, variant: "destructive" });
    }
  };

  return (
    <div className="border rounded-md p-3 bg-card">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2 text-sm font-semibold text-primary">
          <Store className="h-4 w-4" />
          Composizione Expo
          <Badge variant="secondary" className="ml-1">{rows.length}</Badge>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="ghost" onClick={downloadTemplate} title="Scarica template XLSX">
            <Download className="h-3.5 w-3.5 mr-1" />
            Template
          </Button>
          {canWrite && (
            <Button size="sm" onClick={save} disabled={!dirty || saving}>
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" /> : <Save className="h-3.5 w-3.5 mr-1" />}
              Salva
            </Button>
          )}
        </div>
      </div>


      {isLoading ? (
        <div className="text-xs text-muted-foreground py-4 text-center">Caricamento…</div>
      ) : rows.length === 0 ? (
        <div className="text-xs text-muted-foreground py-4 text-center border border-dashed rounded">
          Nessun articolo nella composizione Expo.
        </div>
      ) : (
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
          <SortableContext items={rows.map((r) => r._key)} strategy={verticalListSortingStrategy}>
            <div className="space-y-1.5">
              {rows.map((r) => (
                <ExpoRowItem
                  key={r._key}
                  row={r}
                  canWrite={canWrite}
                  onChange={(patch) => updateRow(r._key, patch)}
                  onRemove={() => removeRow(r._key)}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      )}

      {canWrite && (
        <div className="mt-3">
          <ArticlePicker excludeCdpar={parent} onPick={(c, d) => addRow(c, d)} onBulk={bulkAdd} onXlsx={handleXlsxFile} />
        </div>
      )}
    </div>
  );
}


function ExpoRowItem({
  row,
  canWrite,
  onChange,
  onRemove,
}: {
  row: ExpoRow;
  canWrite: boolean;
  onChange: (patch: Partial<ExpoRow>) => void;
  onRemove: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: row._key,
  });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="flex items-center gap-2 p-2 border rounded bg-background"
    >
      {canWrite && (
        <button
          {...attributes}
          {...listeners}
          className="cursor-grab active:cursor-grabbing touch-none text-muted-foreground"
        >
          <GripVertical className="h-4 w-4" />
        </button>
      )}
      <div className="font-mono text-xs font-semibold w-16 shrink-0">{row.child_cdpar}</div>
      <div className="flex-1 min-w-0 text-xs text-muted-foreground truncate" title={row.description ?? ""}>
        {row.description ?? <span className="italic">— articolo non trovato —</span>}
      </div>
      <Input
        type="number"
        min={0}
        step="1"
        value={row.quantity}
        onChange={(e) => onChange({ quantity: Number(e.target.value) })}
        className="w-20 h-8 text-xs"
        disabled={!canWrite}
      />
      <Input
        placeholder="Note"
        value={row.note ?? ""}
        onChange={(e) => onChange({ note: e.target.value })}
        className="w-40 h-8 text-xs"
        disabled={!canWrite}
      />
      {canWrite && (
        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={onRemove}>
          <Trash2 className="h-3.5 w-3.5 text-destructive" />
        </Button>
      )}
    </div>
  );
}

function ArticlePicker({
  excludeCdpar,
  onPick,
  onBulk,
  onXlsx,
}: {
  excludeCdpar: string;
  onPick: (cdpar: string, description?: string) => void;
  onBulk: (text: string) => void | Promise<void>;
  onXlsx: (file: File) => void | Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Array<{ cdpar: string; depar: string }>>([]);
  const [loading, setLoading] = useState(false);
  const [manual, setManual] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);


  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const text = e.clipboardData.getData("text");
    if (text && (text.includes("\n") || text.includes("\t"))) {
      e.preventDefault();
      onBulk(text);
      setOpen(false);
      setQ("");
      setManual("");
    }
  };


  useEffect(() => {
    if (!open) return;
    const term = q.trim();
    if (term.length < 2) {
      setResults([]);
      return;
    }
    const handle = setTimeout(async () => {
      setLoading(true);
      const isNumeric = /^\d+$/.test(term);
      let query = supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar, depar")
        .limit(20);
      if (isNumeric) {
        const padded = term.padStart(6, "0");
        query = query.or(`cdpar.ilike.%${term}%,cdpar.eq.${padded}`);
      } else {
        query = query.ilike("depar", `%${term}%`);
      }
      const { data } = await query;
      setResults((data ?? []).filter((a: any) => a.cdpar !== excludeCdpar) as any);
      setLoading(false);
    }, 250);
    return () => clearTimeout(handle);
  }, [q, open, excludeCdpar]);

  return (
    <div className="flex gap-2">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="flex-1 justify-start">
            <Search className="h-3.5 w-3.5 mr-2" />
            Cerca articolo da aggiungere…
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[420px] p-2" align="start">
          <Input
            autoFocus
            placeholder="Cerca o incolla da Excel (TAB: codice qty note)…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onPaste={handlePaste}
            className="h-8 text-xs mb-2"
          />

          <div className="max-h-64 overflow-auto">
            {loading && <div className="text-xs text-muted-foreground py-2 text-center">Ricerca…</div>}
            {!loading && q.trim().length >= 2 && results.length === 0 && (
              <div className="text-xs text-muted-foreground py-2 text-center">Nessun risultato</div>
            )}
            {results.map((a) => (
              <button
                key={a.cdpar}
                className="w-full text-left p-1.5 hover:bg-muted rounded text-xs flex items-center gap-2"
                onClick={() => {
                  onPick(a.cdpar, a.depar);
                  setOpen(false);
                  setQ("");
                }}
              >
                <span className="font-mono font-semibold w-14">{a.cdpar}</span>
                <span className="flex-1 truncate text-muted-foreground">{a.depar}</span>
              </button>
            ))}
          </div>
        </PopoverContent>
      </Popover>
      <div className="flex gap-1">
        <Input
          placeholder="Codice / incolla"
          value={manual}
          onChange={(e) => setManual(e.target.value)}
          onPaste={handlePaste}
          className="w-28 h-8 text-xs"
        />

        <Button
          size="sm"
          variant="secondary"
          onClick={() => {
            if (manual.trim()) {
              onPick(manual.trim());
              setManual("");
            }
          }}
        >
          <Plus className="h-3.5 w-3.5" />
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".xlsx,.xls"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onXlsx(f);
            if (fileInputRef.current) fileInputRef.current.value = "";
          }}
        />
        <Button
          size="sm"
          variant="outline"
          onClick={() => fileInputRef.current?.click()}
          title="Carica XLSX (Codice, Qta)"
        >
          <FileSpreadsheet className="h-3.5 w-3.5" />
        </Button>
      </div>
    </div>
  );
}


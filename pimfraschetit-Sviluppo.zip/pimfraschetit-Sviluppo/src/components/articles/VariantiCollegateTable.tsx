import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useOnlineAssortments, computeIsB2bOnline } from "@/hooks/useOnlineAssortments";
import { ExternalLink } from "lucide-react";

interface Props {
  currentCdpar: string;
  codPadre: string | null | undefined;
}

interface VariantRow {
  cdpar: string;
  depar: string | null;
  descrizione_variante: string | null;
  b2b_product_title: string | null;
  wfuas: string | null;
  b2b_online_active: boolean | null;
}

export function VariantiCollegateTable({ currentCdpar, codPadre }: Props) {
  const cur = (currentCdpar ?? "").trim();
  const parent = ((codPadre ?? "").trim() || cur);

  const { data: onlineAssortments = [] } = useOnlineAssortments();

  const { data, isLoading } = useQuery({
    queryKey: ["article-variants", parent],
    enabled: !!parent,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar, depar, descrizione_variante, b2b_product_title, wfuas, b2b_online_active")
        .eq("cod_padre", parent)
        .order("cdpar")
        .limit(200);
      if (error) throw error;
      return (data ?? []).map((r: any) => ({
        cdpar: (r.cdpar as string).trim(),
        depar: r.depar,
        descrizione_variante: r.descrizione_variante,
        b2b_product_title: r.b2b_product_title,
        wfuas: (r.wfuas as string | null)?.trim() ?? null,
        b2b_online_active: r.b2b_online_active,
      })) as VariantRow[];
    },
    staleTime: 60_000,
  });

  if (isLoading) {
    return <Skeleton className="h-24 w-full" />;
  }

  if (!data || data.length === 0) {
    return (
      <p className="text-xs text-muted-foreground italic">
        Nessuna variante collegata{codPadre ? ` al codice padre ${parent}` : ""}.
      </p>
    );
  }

  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground">
        {data.length} variant{data.length === 1 ? "e" : "i"} con codice padre{" "}
        <span className="font-mono font-semibold">{parent}</span>
      </p>
      <div className="rounded-md border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="h-9 w-[110px]">Codice</TableHead>
              <TableHead className="h-9">Descrizione variante</TableHead>
              <TableHead className="h-9">Titolo B2B</TableHead>
              <TableHead className="h-9 w-[110px]">Assortim.</TableHead>
              <TableHead className="h-9 w-[90px] text-center">Online</TableHead>
              <TableHead className="h-9 w-[60px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((v) => {
              const isCurrent = v.cdpar === cur;
              const online = computeIsB2bOnline(v.b2b_online_active, v.wfuas ?? "", onlineAssortments);
              return (
                <TableRow key={v.cdpar} className={isCurrent ? "bg-primary/5" : ""}>
                  <TableCell className="py-2 font-mono text-xs">
                    {v.cdpar}
                    {isCurrent && (
                      <Badge variant="outline" className="ml-1.5 text-[9px] px-1 py-0">
                        questo
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="py-2 text-xs">
                    {v.descrizione_variante || v.depar || <span className="text-muted-foreground">—</span>}
                  </TableCell>
                  <TableCell className="py-2 text-xs">
                    {v.b2b_product_title || <span className="text-muted-foreground">—</span>}
                  </TableCell>
                  <TableCell className="py-2 text-xs font-mono">
                    {v.wfuas || <span className="text-muted-foreground">—</span>}
                  </TableCell>
                  <TableCell className="py-2 text-center">
                    <span
                      title={online ? "Online" : "Offline"}
                      className={`inline-block h-2.5 w-2.5 rounded-full ${online ? "bg-green-500" : "bg-red-500"}`}
                    />
                  </TableCell>
                  <TableCell className="py-2 text-right">
                    {!isCurrent && (
                      <Link
                        to={`/pim/articles/${encodeURIComponent(v.cdpar)}?tab=marketing`}
                        className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                      >
                        <ExternalLink className="h-3 w-3" />
                        Apri
                      </Link>
                    )}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

import { useNavigate } from "react-router-dom";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";
import { ArticleDetail } from "./ArticleDetail";

interface Props {
  cdpar: string | null;
  onClose: () => void;
}

export function ArticleSlideOver({ cdpar, onClose }: Props) {
  const navigate = useNavigate();

  return (
    <Sheet open={!!cdpar} onOpenChange={(open) => { if (!open) onClose(); }}>
      <SheetContent side="right" className="w-full sm:max-w-[60vw] overflow-y-auto p-0">
        <SheetHeader className="px-6 pt-6 pb-2 flex flex-row items-center justify-between">
          <SheetTitle className="font-mono text-lg">{cdpar}</SheetTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => { onClose(); navigate(`/pim/articles/${encodeURIComponent(cdpar!)}`); }}
          >
            <ExternalLink className="h-4 w-4 mr-1" /> Apri
          </Button>
        </SheetHeader>
        {cdpar && <ArticleDetail cdpar={cdpar} />}
      </SheetContent>
    </Sheet>
  );
}

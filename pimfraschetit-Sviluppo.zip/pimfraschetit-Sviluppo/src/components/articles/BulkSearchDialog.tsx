import { useMemo, useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ListChecks } from "lucide-react";

interface Props {
  open: boolean;
  onClose: () => void;
  onConfirm: (codes: string[]) => void;
  initialCodes?: string[] | null;
}

function parseCodes(raw: string): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const tok of raw.split(/[\s,;]+/)) {
    const t = tok.trim();
    if (!t) continue;
    if (seen.has(t)) continue;
    seen.add(t);
    out.push(t);
  }
  return out;
}

export function BulkSearchDialog({ open, onClose, onConfirm, initialCodes }: Props) {
  const [text, setText] = useState("");

  useEffect(() => {
    if (open) setText(initialCodes && initialCodes.length > 0 ? initialCodes.join("\n") : "");
  }, [open, initialCodes]);

  const codes = useMemo(() => parseCodes(text), [text]);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ListChecks className="h-4 w-4" /> Cerca da elenco codici
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-2">
          <p className="text-xs text-muted-foreground">
            Incolla i codici articolo (uno per riga, oppure separati da spazio, virgola o tab).
            Puoi copiare direttamente una colonna da Excel.
          </p>
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={"013002\n013003\n013098\n..."}
            className="font-mono text-xs h-64"
            autoFocus
          />
          <div className="text-xs text-muted-foreground">
            <strong className="text-foreground">{codes.length}</strong> codici riconosciuti
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Annulla</Button>
          <Button
            onClick={() => { onConfirm(codes); onClose(); }}
            disabled={codes.length === 0}
          >
            Applica filtro ({codes.length})
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

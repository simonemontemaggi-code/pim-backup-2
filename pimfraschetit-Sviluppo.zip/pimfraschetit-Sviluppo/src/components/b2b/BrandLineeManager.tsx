import { useState } from "react";
import { useLookupValues, useAddLookupValue, useUpdateLookupValue, useDeleteLookupValue } from "@/hooks/useLookupValues";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Pencil, Trash2, Check, X, Loader2, ChevronDown, ChevronRight, Image as ImageIcon } from "lucide-react";
import { toast } from "sonner";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { MediaUploader } from "@/components/b2b/MediaUploader";

interface Props {
  clas2: string;
}

const DESC_MAX = 250;

export function BrandLineeManager({ clas2 }: Props) {
  const confirm = useConfirm();
  const { data: all = [], isLoading } = useLookupValues("linea_brand");
  const linee = all.filter((v) => v.parent_code === clas2);

  const addMutation = useAddLookupValue();
  const updateMutation = useUpdateLookupValue();
  const deleteMutation = useDeleteLookupValue();

  const [newCode, setNewCode] = useState("");
  const [newLabel, setNewLabel] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editCode, setEditCode] = useState("");
  const [editLabel, setEditLabel] = useState("");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const handleAdd = async () => {
    if (!newCode.trim()) return;
    try {
      await addMutation.mutateAsync({
        category: "linea_brand",
        code: newCode.trim(),
        label: newLabel.trim() || newCode.trim(),
        parent_category: "clas2",
        parent_code: clas2,
      });
      toast.success(`Linea "${newCode.trim()}" aggiunta`);
      setNewCode("");
      setNewLabel("");
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  const startEdit = (v: { id: string; code: string; label: string | null }) => {
    setEditingId(v.id);
    setEditCode(v.code);
    setEditLabel(v.label ?? "");
  };
  const cancelEdit = () => {
    setEditingId(null);
    setEditCode("");
    setEditLabel("");
  };
  const saveEdit = async () => {
    if (!editingId || !editCode.trim()) return;
    try {
      await updateMutation.mutateAsync({
        id: editingId,
        code: editCode.trim(),
        label: editLabel.trim() || editCode.trim(),
      });
      toast.success("Linea aggiornata");
      cancelEdit();
    } catch (e: any) {
      toast.error(e.message);
    }
  };
  const handleDelete = async (id: string, code: string) => {
    if (!(await confirm({ title: `Eliminare la linea "${code}"?`, destructive: true, confirmText: "Elimina" }))) return;
    try {
      await deleteMutation.mutateAsync(id);
      toast.success("Linea eliminata");
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  const updateField = async (id: string, patch: { image_url?: string | null; description?: string | null }) => {
    try {
      await updateMutation.mutateAsync({ id, ...patch });
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  return (
    <Card className="p-5 space-y-3">
      <div className="flex items-center justify-between">
        <Label className="text-sm font-semibold">Linee del Brand</Label>
        <Badge variant="outline" className="text-xs">{linee.length} linee</Badge>
      </div>

      <ScrollArea className="max-h-[32rem] border rounded-md">
        <div className="p-2 space-y-1">
          {isLoading ? (
            <div className="flex items-center justify-center p-4">
              <Loader2 className="h-4 w-4 animate-spin" />
            </div>
          ) : linee.length === 0 ? (
            <p className="text-xs text-muted-foreground p-2">Nessuna linea associata. Aggiungi la prima qui sotto.</p>
          ) : (
            linee.map((v) => {
              const isExpanded = expandedId === v.id;
              const desc = v.description ?? "";
              return (
                <div key={v.id} className="rounded border bg-card/50">
                  <div className="flex items-center gap-2 px-2 py-1 hover:bg-muted/50 group">
                    {editingId === v.id ? (
                      <>
                        <Input
                          value={editCode}
                          onChange={(e) => setEditCode(e.target.value)}
                          className="h-7 text-xs font-mono w-32"
                          onKeyDown={(e) => { if (e.key === "Enter") saveEdit(); if (e.key === "Escape") cancelEdit(); }}
                          autoFocus
                        />
                        <Input
                          value={editLabel}
                          onChange={(e) => setEditLabel(e.target.value)}
                          placeholder="Descrizione"
                          className="h-7 text-xs flex-1"
                          onKeyDown={(e) => { if (e.key === "Enter") saveEdit(); if (e.key === "Escape") cancelEdit(); }}
                        />
                        <Button size="icon" variant="ghost" className="h-6 w-6 text-green-600" onClick={saveEdit} title="Salva">
                          <Check className="h-3.5 w-3.5" />
                        </Button>
                        <Button size="icon" variant="ghost" className="h-6 w-6" onClick={cancelEdit} title="Annulla">
                          <X className="h-3.5 w-3.5" />
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button
                          size="icon" variant="ghost" className="h-6 w-6 shrink-0"
                          onClick={() => setExpandedId(isExpanded ? null : v.id)}
                          title={isExpanded ? "Comprimi" : "Espandi"}
                        >
                          {isExpanded ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
                        </Button>
                        {v.image_url ? (
                          <img src={v.image_url} alt={v.code} className="h-7 w-7 object-cover rounded border shrink-0" />
                        ) : (
                          <div className="h-7 w-7 rounded border bg-muted flex items-center justify-center shrink-0">
                            <ImageIcon className="h-3.5 w-3.5 text-muted-foreground/50" />
                          </div>
                        )}
                        <span className="text-xs font-mono w-28 shrink-0 truncate">{v.code}</span>
                        <span className="text-xs text-muted-foreground flex-1 truncate">{v.label}</span>
                        <Badge variant="outline" className="text-[10px] h-5 border-primary/50 text-primary">PIM</Badge>
                        <Button
                          size="icon" variant="ghost"
                          className="h-6 w-6 opacity-0 group-hover:opacity-100"
                          onClick={() => startEdit(v)}
                          title="Modifica codice/nome"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          size="icon" variant="ghost"
                          className="h-6 w-6 opacity-0 group-hover:opacity-100 text-destructive"
                          onClick={() => handleDelete(v.id, v.code)}
                          title="Elimina"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </>
                    )}
                  </div>

                  {isExpanded && editingId !== v.id && (
                    <div className="p-3 border-t bg-muted/20 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <MediaUploader
                        label="Immagine linea"
                        hint="Consigliato 800×800"
                        currentUrl={v.image_url}
                        storagePath={`brands/${clas2}/linee/${v.code}`}
                        onUploaded={(url) => updateField(v.id, { image_url: url })}
                      />
                      <div className="space-y-2">
                        <Label className="text-xs">Breve descrizione</Label>
                        <Textarea
                          rows={5}
                          value={desc}
                          maxLength={DESC_MAX}
                          placeholder="Breve descrizione della linea..."
                          onChange={(e) => {
                            // local optimistic update via mutation onBlur instead;
                            // here aggiorniamo direttamente la cache attraverso onBlur
                          }}
                          onBlur={(e) => {
                            const val = e.target.value.trim();
                            if ((v.description ?? "") !== val) {
                              updateField(v.id, { description: val || null });
                            }
                          }}
                          defaultValue={desc}
                          key={v.id + (v.description ?? "")}
                        />
                        <div className="text-[10px] text-muted-foreground text-right">
                          max {DESC_MAX} caratteri
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </ScrollArea>

      <div className="flex items-center gap-2 pt-2 border-t">
        <Input
          value={newCode}
          onChange={(e) => setNewCode(e.target.value)}
          placeholder="Codice linea"
          className="h-8 text-xs w-36 font-mono"
          onKeyDown={(e) => { if (e.key === "Enter") handleAdd(); }}
        />
        <Input
          value={newLabel}
          onChange={(e) => setNewLabel(e.target.value)}
          placeholder="Descrizione (opzionale)"
          className="h-8 text-xs flex-1"
          onKeyDown={(e) => { if (e.key === "Enter") handleAdd(); }}
        />
        <Button size="sm" variant="outline" className="h-8" onClick={handleAdd} disabled={!newCode.trim() || addMutation.isPending}>
          <Plus className="h-3.5 w-3.5 mr-1" /> Aggiungi
        </Button>
      </div>
    </Card>
  );
}

import { Link2 } from "lucide-react";

interface Props {
  image?: string | null;
  title?: string | null;
  subtitle?: string | null;
  cta?: string | null;
  link?: string | null;
}

/**
 * Replica fedele del PromoSlider del B2B (banner di settore).
 * Logica CTA:
 * - se `cta` valorizzato → mostra il pulsante
 * - altrimenti se `link` valorizzato → tutta l'immagine diventa cliccabile
 */
export function PromoSlidePreview({ image, title, subtitle, cta, link }: Props) {
  const hasCta = !!(cta && cta.trim());
  const hasLink = !!(link && link.trim());
  const wholeClickable = !hasCta && hasLink;

  return (
    <div className="relative w-full rounded-lg overflow-hidden border bg-muted" style={{ aspectRatio: "16/6" }}>
      {image ? (
        <img src={image} alt={title || ""} className="w-full h-full object-cover" />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center text-sm text-muted-foreground">
          Nessuna immagine
        </div>
      )}
      <div className="absolute inset-0 bg-gradient-to-r from-foreground/60 via-foreground/30 to-transparent" />
      <div className="absolute inset-0 flex flex-col justify-center px-8 md:px-12">
        {title && (
          <h3 className="text-xl md:text-3xl text-white font-bold mb-1 drop-shadow-lg">{title}</h3>
        )}
        {subtitle && (
          <p className="text-sm md:text-base text-white/90 mb-4 max-w-md drop-shadow">{subtitle}</p>
        )}
        {hasCta && (
          <span className="inline-flex items-center self-start px-5 py-2 rounded-md bg-primary text-primary-foreground text-sm font-medium">
            {cta}
          </span>
        )}
      </div>
      {wholeClickable && (
        <>
          <div className="absolute inset-0 ring-2 ring-primary/40 ring-inset rounded-lg pointer-events-none" />
          <div className="absolute top-2 right-2 inline-flex items-center gap-1 rounded-md bg-primary/90 px-2 py-1 text-[10px] font-semibold text-primary-foreground shadow">
            <Link2 className="h-3 w-3" /> Immagine cliccabile → {link}
          </div>
        </>
      )}
    </div>
  );
}

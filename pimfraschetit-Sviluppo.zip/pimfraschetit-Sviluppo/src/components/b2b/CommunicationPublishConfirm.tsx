import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Send } from "lucide-react";

export interface AudienceFilters {
  customer_codes?: string[];
  agent_codes?: string[];
  zone_codes?: string[];
}

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  title: string;
  targetApps: string[];
  audience: AudienceFilters | null;
  onConfirm: () => void;
  loading?: boolean;
}

const MAX_PREVIEW = 15;

function GroupList({ label, codes }: { label: string; codes: string[] }) {
  if (codes.length === 0) return null;
  const preview = codes.slice(0, MAX_PREVIEW);
  const rest = codes.length - preview.length;
  return (
    <div>
      <div className="text-sm font-medium mb-1">{label} ({codes.length})</div>
      <div className="flex flex-wrap gap-1">
        {preview.map((c) => (
          <Badge key={c} variant="outline" className="font-mono text-xs">{c}</Badge>
        ))}
        {rest > 0 && <Badge variant="secondary" className="text-xs">+{rest} altri</Badge>}
      </div>
    </div>
  );
}

export function CommunicationPublishConfirm({ open, onOpenChange, title, targetApps, audience, onConfirm, loading }: Props) {
  const hasB2b = targetApps.includes("b2b");
  const hasAgent = targetApps.includes("agent_hub");
  const noApp = !hasB2b && !hasAgent;
  const af = audience ?? {};
  const totalAudience =
    (af.customer_codes?.length ?? 0) +
    (af.agent_codes?.length ?? 0) +
    (af.zone_codes?.length ?? 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Confermi la pubblicazione?</DialogTitle>
          <DialogDescription>{title}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div>
            <div className="text-sm font-medium mb-1.5">Portali destinatari</div>
            {noApp ? (
              <div className="flex items-center gap-2 text-sm text-destructive">
                <AlertCircle className="h-4 w-4" />
                Nessun portale selezionato — la comunicazione non sarà visibile a nessuno.
              </div>
            ) : (
              <div className="flex gap-1.5">
                {hasB2b && <Badge>B2B clienti</Badge>}
                {hasAgent && <Badge>Portale Agenti</Badge>}
              </div>
            )}
          </div>

          <div>
            <div className="text-sm font-medium mb-1.5">Destinatari</div>
            {totalAudience === 0 ? (
              <p className="text-sm text-muted-foreground">
                Nessun filtro impostato: sarà visibile a <strong>tutti</strong> gli utenti dei portali selezionati.
              </p>
            ) : (
              <div className="space-y-3">
                <GroupList label="Clienti" codes={af.customer_codes ?? []} />
                <GroupList label="Agenti" codes={af.agent_codes ?? []} />
                <GroupList label="Zone" codes={af.zone_codes ?? []} />
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>Annulla</Button>
          <Button onClick={onConfirm} disabled={loading || noApp}>
            <Send className="h-4 w-4 mr-2" />
            {loading ? "Pubblicazione…" : "Conferma e pubblica"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { useRef, useState } from "react";
import { Upload, Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { maybeOptimizePdf } from "@/lib/maybeOptimizePdf";

interface Props {
  label: string;
  currentUrl?: string | null;
  storagePath: string; // es: brands/{clas2}/logo
  onUploaded: (publicUrl: string | null) => void;
  accept?: string;
  aspect?: "square" | "wide";
  hint?: string;
}

export function MediaUploader({
  label,
  currentUrl,
  storagePath,
  onUploaded,
  accept = "image/*",
  aspect = "square",
  hint,
}: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const handleFile = async (file: File) => {
    setUploading(true);
    try {
      const toUpload = await maybeOptimizePdf(file);
      const ext = file.name.split(".").pop()?.toLowerCase() || "png";
      const fullPath = `${storagePath}.${ext}`;
      const { error } = await supabase.storage
        .from("pim-media")
        .upload(fullPath, toUpload, { upsert: true, contentType: toUpload.type || file.type });
      if (error) throw error;
      const { data } = supabase.storage.from("pim-media").getPublicUrl(fullPath);
      // Aggiungiamo un cache-bust per forzare il refresh in CDN/browser quando
      // si sovrascrive lo stesso path (upsert) con una nuova immagine.
      const bustedUrl = `${data.publicUrl}?v=${Date.now()}`;
      onUploaded(bustedUrl);
      toast.success(`${label} caricato`);
    } catch (e: any) {
      toast.error(`Errore upload: ${e.message}`);
    } finally {
      setUploading(false);
    }
  };

  const onPick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">{label}</span>
        {currentUrl && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onUploaded(null)}
            type="button"
          >
            <X className="h-3 w-3 mr-1" /> Rimuovi
          </Button>
        )}
      </div>
      <div
        className={`border-2 border-dashed rounded-lg p-3 flex items-center justify-center cursor-pointer hover:bg-muted/50 transition ${
          aspect === "wide" ? "h-32" : "h-40"
        }`}
        onClick={() => inputRef.current?.click()}
      >
        {uploading ? (
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        ) : currentUrl ? (
          <img
            src={currentUrl}
            alt={label}
            className="max-h-full max-w-full object-contain"
          />
        ) : (
          <div className="text-center text-muted-foreground text-sm">
            <Upload className="h-6 w-6 mx-auto mb-1" />
            Clicca o trascina
            {hint && (
              <div className="text-xs text-muted-foreground/70 mt-1">{hint}</div>
            )}
          </div>
        )}
      </div>
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        className="hidden"
        onChange={onPick}
      />
    </div>
  );
}

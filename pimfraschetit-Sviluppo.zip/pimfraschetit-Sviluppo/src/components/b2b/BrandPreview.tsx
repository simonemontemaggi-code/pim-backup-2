interface Props {
  displayName?: string | null;
  fallbackName: string;
  tagline?: string | null;
  description?: string | null;
  logoUrl?: string | null;
  heroImageUrl?: string | null;
  gradientFrom?: string | null;
}

/**
 * Replica visivamente l'header brand del B2B (es. Bosch).
 * Il gradiente parte dal colore "from" e sfuma verso "to".
 * Se "to" è "transparent" (default), si vede l'hero image dietro sulla destra.
 */
export function BrandPreview({
  displayName,
  fallbackName,
  tagline,
  description,
  logoUrl,
  heroImageUrl,
  gradientFrom,
}: Props) {
  const from = gradientFrom || "#1e40af";
  const name = displayName?.trim() || fallbackName;

  const toResolved = `${from}00`;

  return (
    <div className="rounded-xl overflow-hidden border shadow-sm">
      <div className="relative min-h-[280px] flex items-center bg-muted">
        {heroImageUrl && (
          <img
            src={heroImageUrl}
            alt=""
            className="absolute inset-0 w-full h-full object-cover"
          />
        )}
        <div
          className="absolute inset-0"
          style={{
            background: `linear-gradient(120deg, ${from} 0%, ${from} 30%, ${toResolved} 100%)`,
          }}
        />
        <div className="relative z-10 flex items-start gap-6 p-8 w-full">
          <div className="bg-white rounded-lg p-4 shadow-md flex items-center justify-center w-32 h-32 shrink-0">
            {logoUrl ? (
              <img
                src={logoUrl}
                alt={name}
                className="max-w-full max-h-full object-contain"
              />
            ) : (
              <span className="text-xs text-muted-foreground text-center">
                Nessun logo
              </span>
            )}
          </div>
          <div className="flex-1 text-white max-w-xl">
            <h2 className="text-3xl font-bold mb-1 drop-shadow">{name}</h2>
            {tagline && (
              <p className="italic text-white/90 mb-3 drop-shadow">"{tagline}"</p>
            )}
            {description && (
              <p className="text-sm text-white/95 leading-relaxed mb-4 line-clamp-4 drop-shadow">
                {description}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

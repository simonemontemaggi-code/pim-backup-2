export type HotspotType = "article" | "url" | "assortment";

export interface Hotspot {
  id: string;
  page: number; // 1-based
  x: number; // 0..1
  y: number; // 0..1
  w: number; // 0..1
  h: number; // 0..1
  type?: HotspotType; // default: "article"
  cdpar?: string;
  url?: string;
  assortment_id?: string;
  label?: string;
}

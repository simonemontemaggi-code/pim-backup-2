import { useState, useMemo } from "react";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Layers, AlertTriangle } from "lucide-react";
import type { Hotspot } from "./types";
import { findOverlapPairs } from "./resolveOverlaps";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  hotspots: Hotspot[];
  currentPage: number;
  numPages: number;
  onApply: (opts: { padding: number; strategy: "both" | "larger"; pages: number[] }) => void;
}

export function ResolveOverlapsDialog({ open, onOpenChange, hotspots, currentPage, numPages, onApply }: Props) {
  const [padding, setPadding] = useState(0.005); // 0.5%
  const [strategy, setStrategy] = useState<"both" | "larger">("both");

  const stats = useMemo(() => {
    const pageOnly = hotspots.filter((h) => h.page === currentPage);
    return {
      pagePairs: findOverlapPairs(pageOnly).length,
      pageCount: pageOnly.length,
      allPairs: findOverlapPairs(hotspots).length,
      allCount: hotspots.length,
    };
  }, [hotspots, currentPage, open]);

  const allPagesArr = Array.from({ length: numPages }, (_, i) => i + 1);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Layers className="h-4 w-4" /> Riduci sovrapposizioni
          </DialogTitle>
          <DialogDescription>
            Riduce automaticamente gli hotspot accavallati lasciando un piccolo margine tra loro.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2 text-sm">
          <div className="rounded border p-3 space-y-1.5 text-xs">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Sovrapposizioni pagina {currentPage}</span>
              <span className="font-semibold">{stats.pagePairs} coppie / {stats.pageCount} hotspot</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Sovrapposizioni totali catalogo</span>
              <span className="font-semibold">{stats.allPairs} coppie / {stats.allCount} hotspot</span>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-xs flex justify-between">
              <span>Padding minimo tra hotspot</span>
              <span className="font-mono text-muted-foreground">{(padding * 100).toFixed(2)}%</span>
            </Label>
            <Slider
              value={[padding * 1000]}
              onValueChange={(v) => setPadding(v[0] / 1000)}
              min={0}
              max={30}
              step={1}
            />
          </div>

          <div className="space-y-2">
            <Label className="text-xs">Strategia</Label>
            <RadioGroup value={strategy} onValueChange={(v) => setStrategy(v as "both" | "larger")}>
              <div className="flex items-start gap-2">
                <RadioGroupItem value="both" id="s-both" className="mt-0.5" />
                <Label htmlFor="s-both" className="text-xs font-normal cursor-pointer">
                  <span className="font-medium">Riduci entrambi</span> in modo proporzionale
                </Label>
              </div>
              <div className="flex items-start gap-2">
                <RadioGroupItem value="larger" id="s-larger" className="mt-0.5" />
                <Label htmlFor="s-larger" className="text-xs font-normal cursor-pointer">
                  <span className="font-medium">Riduci solo il più grande</span> della coppia
                </Label>
              </div>
            </RadioGroup>
          </div>

          <div className="rounded bg-amber-50 border border-amber-200 p-2 text-xs text-amber-800 flex gap-1.5">
            <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
            <span>Hotspot duplicati (stessa posizione esatta) non vengono toccati: vanno cancellati a mano.</span>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Annulla</Button>
          <Button
            variant="secondary"
            disabled={stats.pagePairs === 0}
            onClick={() => onApply({ padding, strategy, pages: [currentPage] })}
          >
            Solo pagina ({stats.pagePairs})
          </Button>
          <Button
            disabled={stats.allPairs === 0}
            onClick={() => onApply({ padding, strategy, pages: allPagesArr })}
          >
            Tutto catalogo ({stats.allPairs})
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import type { PdfDoc } from "./usePdfDocument";
import type { Hotspot } from "./types";

export interface CodeCandidate {
  code: string;       // 6 cifre
  page: number;       // 1-based
  x: number;          // 0..1 (top-left origin)
  y: number;
  w: number;
  h: number;
  pageAspect: number; // pageW / pageH (per geometria adattiva)
}

const CODE_RE = /\b\d{6}\b/g;

/**
 * Estrae tutti i candidati a 6 cifre da una pagina PDF, con bounding box normalizzata
 * in coordinate top-left origin (0..1).
 */
export async function extractCodeCandidatesFromPage(
  doc: PdfDoc,
  pageNumber: number
): Promise<CodeCandidate[]> {
  const page = await doc.getPage(pageNumber);
  const viewport = page.getViewport({ scale: 1 });
  const pageW = viewport.width;
  const pageH = viewport.height;
  const textContent = await page.getTextContent();

  const out: CodeCandidate[] = [];

  for (const item of textContent.items as Array<{
    str: string;
    transform: number[];
    width: number;
    height: number;
  }>) {
    const str = item.str;
    if (!str || !/\d/.test(str)) continue;

    // transform = [a, b, c, d, e, f]; e = x, f = y (PDF user space, origin bottom-left)
    const tx = item.transform?.[4] ?? 0;
    const ty = item.transform?.[5] ?? 0;
    const itemH = item.height || Math.abs(item.transform?.[3] ?? 10);
    const itemW = item.width || str.length * itemH * 0.5;

    // Convert to top-left origin viewport coords
    const topY = pageH - ty - itemH;

    let m: RegExpExecArray | null;
    CODE_RE.lastIndex = 0;
    while ((m = CODE_RE.exec(str)) !== null) {
      const code = m[0];
      const startIdx = m.index;
      const charW = itemW / Math.max(str.length, 1);
      const codeX = tx + startIdx * charW;
      const codeW = code.length * charW;

      out.push({
        code,
        page: pageNumber,
        x: Math.max(0, Math.min(1, codeX / pageW)),
        y: Math.max(0, Math.min(1, topY / pageH)),
        w: Math.max(0, Math.min(1, codeW / pageW)),
        h: Math.max(0, Math.min(1, itemH / pageH)),
        pageAspect: pageW / pageH,
      });
    }
  }

  return out;
}

export type HotspotShape = "image" | "code";

/**
 * Costruisce un hotspot dal candidato.
 * - shape="image": espande verso l'alto per coprire la presunta foto prodotto.
 * - shape="code": bbox stretta sul solo codice articolo (con piccolo padding).
 */
export function buildHotspotFromCode(c: CodeCandidate, id: string, shape: HotspotShape = "image"): Hotspot {
  if (shape === "code") {
    const padX = Math.max(c.w * 0.15, 0.004);
    const padY = Math.max(c.h * 0.3, 0.004);
    let x = c.x - padX;
    let y = c.y - padY;
    let w = c.w + padX * 2;
    let h = c.h + padY * 2;
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > 1) w = 1 - x;
    if (y + h > 1) h = 1 - y;
    return { id, page: c.page, x, y, w, h, type: "article", cdpar: c.code };
  }
  // Larghezza target: max(3x larghezza codice, 12% pagina)
  const targetW = Math.max(c.w * 3, 0.12);
  // Altezza adattiva al formato pagina: su pagine quadrate o orizzontali
  // moltiplicare per pageAspect mantiene la stessa forma visiva sull'immagine.
  const targetH = targetW * 1.1 * (c.pageAspect || 0.707);

  // Centrato orizzontalmente sul codice
  const cx = c.x + c.w / 2;
  let x = cx - targetW / 2;

  // Bordo inferiore ~5% sotto il codice (così include anche il codice)
  const bottom = Math.min(1, c.y + c.h + 0.005);
  let y = bottom - targetH;

  // Clamp
  if (x < 0) x = 0;
  if (x + targetW > 1) x = 1 - targetW;
  if (y < 0) y = 0;
  if (y + targetH > 1) y = 1 - targetH;

  return {
    id,
    page: c.page,
    x,
    y,
    w: Math.min(targetW, 1),
    h: Math.min(targetH, 1),
    type: "article",
    cdpar: c.code,
  };
}

/** Pad cdpar a 15 char come richiesto dallo schema. */
export function padCdpar(code: string): string {
  return code.padEnd(15, " ");
}

/**
 * Raggruppa i candidati per (page, cod_padre): se sullo stesso foglio ci sono
 * 2+ varianti con lo stesso padre, le sostituisce con un singolo "candidato padre"
 * la cui bbox è l'unione delle bbox figlie. I figli isolati passano invariati.
 *
 * @param candidates lista già filtrata di codici riconosciuti in archivio
 * @param parentMap  Map<code6, parent6> dei codici che hanno un cod_padre
 */
export function groupCandidatesByParent(
  candidates: CodeCandidate[],
  parentMap: Map<string, string>
): CodeCandidate[] {
  // groups[page][parent] = candidates[]
  const groups = new Map<string, CodeCandidate[]>();
  const ungrouped: CodeCandidate[] = [];

  for (const c of candidates) {
    const parent = parentMap.get(c.code);
    if (!parent) {
      ungrouped.push(c);
      continue;
    }
    const key = `${c.page}::${parent}`;
    const arr = groups.get(key);
    if (arr) arr.push(c);
    else groups.set(key, [c]);
  }

  const out: CodeCandidate[] = [...ungrouped];
  for (const [key, members] of groups.entries()) {
    if (members.length < 2) {
      // singolo: tienilo come variante
      out.push(...members);
      continue;
    }
    const parent = key.split("::")[1];
    // Unione bbox
    let minX = 1, minY = 1, maxX = 0, maxY = 0;
    for (const m of members) {
      if (m.x < minX) minX = m.x;
      if (m.y < minY) minY = m.y;
      if (m.x + m.w > maxX) maxX = m.x + m.w;
      if (m.y + m.h > maxY) maxY = m.y + m.h;
    }
    out.push({
      code: parent,
      page: members[0].page,
      x: minX,
      y: minY,
      w: Math.max(0.001, maxX - minX),
      h: Math.max(0.001, maxY - minY),
      pageAspect: members[0].pageAspect,
    });
  }
  return out;
}

import type { Hotspot } from "./types";

const MIN_SIZE = 0.02;
const EPS = 1e-6;

export interface ResolveOptions {
  padding: number;          // 0..0.05 in unità normalizzate
  strategy: "both" | "larger";
  pages?: number[];         // se omesso, tutte
}

export interface ResolveResult {
  resolved: Hotspot[];
  resolvedPairs: number;    // coppie risolte
  unresolvedPairs: number;  // coppie non risolvibili (min size)
  duplicates: number;       // hotspot con bbox identica
}

interface Box { l: number; t: number; r: number; b: number }

function box(h: Hotspot): Box {
  return { l: h.x, t: h.y, r: h.x + h.w, b: h.y + h.h };
}

function overlap(a: Box, b: Box): { ox: number; oy: number } {
  const ox = Math.max(0, Math.min(a.r, b.r) - Math.max(a.l, b.l));
  const oy = Math.max(0, Math.min(a.b, b.b) - Math.max(a.t, b.t));
  return { ox, oy };
}

function bboxKey(h: Hotspot): string {
  return `${h.page}|${h.x.toFixed(4)}|${h.y.toFixed(4)}|${h.w.toFixed(4)}|${h.h.toFixed(4)}`;
}

export function findOverlapPairs(hotspots: Hotspot[]): Array<[Hotspot, Hotspot]> {
  const byPage = new Map<number, Hotspot[]>();
  for (const h of hotspots) {
    const arr = byPage.get(h.page) ?? [];
    arr.push(h);
    byPage.set(h.page, arr);
  }
  const pairs: Array<[Hotspot, Hotspot]> = [];
  for (const arr of byPage.values()) {
    for (let i = 0; i < arr.length; i++) {
      for (let j = i + 1; j < arr.length; j++) {
        const o = overlap(box(arr[i]), box(arr[j]));
        if (o.ox > EPS && o.oy > EPS) pairs.push([arr[i], arr[j]]);
      }
    }
  }
  return pairs;
}

/** Riduce 'a' e 'b' lungo l'asse di overlap minore. Ritorna true se ha modificato qualcosa. */
function shrinkPair(a: Hotspot, b: Hotspot, opts: ResolveOptions): boolean {
  const ba = box(a);
  const bb = box(b);
  const o = overlap(ba, bb);
  if (o.ox <= EPS || o.oy <= EPS) return false;

  // bbox identica → duplicato, non gestito qui
  if (
    Math.abs(a.x - b.x) < EPS &&
    Math.abs(a.y - b.y) < EPS &&
    Math.abs(a.w - b.w) < EPS &&
    Math.abs(a.h - b.h) < EPS
  ) return false;

  const pad = Math.max(0, opts.padding);

  if (o.ox < o.oy) {
    // Riduci lungo X
    const aCenter = (ba.l + ba.r) / 2;
    const bCenter = (bb.l + bb.r) / 2;
    const [left, right] = aCenter < bCenter ? [a, b] : [b, a];
    const bLeft = box(left);
    const bRight = box(right);
    const split = (bLeft.r + bRight.l) / 2;

    if (opts.strategy === "larger") {
      const aArea = a.w * a.h;
      const bArea = b.w * b.h;
      const bigger = aArea >= bArea ? a : b;
      const smaller = bigger === a ? b : a;
      const bSm = box(smaller);
      const bBg = box(bigger);
      // Riduci solo il bigger lasciando il smaller intatto
      if (bigger === left) {
        const newR = bSm.l - pad;
        const newW = newR - bBg.l;
        if (newW < MIN_SIZE) return false;
        bigger.w = newW;
      } else {
        const newL = bSm.r + pad;
        const newW = bBg.r - newL;
        if (newW < MIN_SIZE) return false;
        bigger.x = newL;
        bigger.w = newW;
      }
    } else {
      // Riduci entrambi proporzionalmente attorno al punto di split
      const newLeftR = split - pad / 2;
      const newRightL = split + pad / 2;
      const newLeftW = newLeftR - bLeft.l;
      const newRightW = bRight.r - newRightL;
      if (newLeftW < MIN_SIZE || newRightW < MIN_SIZE) return false;
      left.w = newLeftW;
      right.x = newRightL;
      right.w = newRightW;
    }
  } else {
    // Riduci lungo Y
    const aCenter = (ba.t + ba.b) / 2;
    const bCenter = (bb.t + bb.b) / 2;
    const [top, bot] = aCenter < bCenter ? [a, b] : [b, a];
    const bTop = box(top);
    const bBot = box(bot);
    const split = (bTop.b + bBot.t) / 2;

    if (opts.strategy === "larger") {
      const aArea = a.w * a.h;
      const bArea = b.w * b.h;
      const bigger = aArea >= bArea ? a : b;
      const smaller = bigger === a ? b : a;
      const bSm = box(smaller);
      const bBg = box(bigger);
      if (bigger === top) {
        const newB = bSm.t - pad;
        const newH = newB - bBg.t;
        if (newH < MIN_SIZE) return false;
        bigger.h = newH;
      } else {
        const newT = bSm.b + pad;
        const newH = bBg.b - newT;
        if (newH < MIN_SIZE) return false;
        bigger.y = newT;
        bigger.h = newH;
      }
    } else {
      const newTopB = split - pad / 2;
      const newBotT = split + pad / 2;
      const newTopH = newTopB - bTop.t;
      const newBotH = bBot.b - newBotT;
      if (newTopH < MIN_SIZE || newBotH < MIN_SIZE) return false;
      top.h = newTopH;
      bot.y = newBotT;
      bot.h = newBotH;
    }
  }
  return true;
}

export function resolveOverlaps(hotspots: Hotspot[], opts: ResolveOptions): ResolveResult {
  // Clona gli hotspot target (rispettando filtro pagine), gli altri restano com'erano
  const targetPages = opts.pages ? new Set(opts.pages) : null;
  const working: Hotspot[] = hotspots.map((h) =>
    !targetPages || targetPages.has(h.page) ? { ...h } : h
  );

  // Conta duplicati
  const seenKeys = new Map<string, number>();
  for (const h of working) {
    if (targetPages && !targetPages.has(h.page)) continue;
    const k = bboxKey(h);
    seenKeys.set(k, (seenKeys.get(k) ?? 0) + 1);
  }
  let duplicates = 0;
  for (const c of seenKeys.values()) if (c > 1) duplicates += c - 1;

  let resolvedPairs = 0;
  let unresolvedPairs = 0;
  const MAX_PASSES = 5;

  for (let pass = 0; pass < MAX_PASSES; pass++) {
    const pairs = findOverlapPairs(
      targetPages ? working.filter((h) => targetPages.has(h.page)) : working
    );
    if (pairs.length === 0) break;

    let changedAny = false;
    for (const [a, b] of pairs) {
      const ok = shrinkPair(a, b, opts);
      if (ok) {
        changedAny = true;
        if (pass === 0) resolvedPairs++;
      } else if (pass === MAX_PASSES - 1) {
        unresolvedPairs++;
      }
    }
    if (!changedAny) {
      // Pairs rimaste: non risolvibili
      unresolvedPairs += pairs.length;
      break;
    }
  }

  // Clamp finale
  for (const h of working) {
    if (targetPages && !targetPages.has(h.page)) continue;
    if (h.x < 0) { h.w += h.x; h.x = 0; }
    if (h.y < 0) { h.h += h.y; h.y = 0; }
    if (h.x + h.w > 1) h.w = 1 - h.x;
    if (h.y + h.h > 1) h.h = 1 - h.y;
    if (h.w < MIN_SIZE) h.w = MIN_SIZE;
    if (h.h < MIN_SIZE) h.h = MIN_SIZE;
  }

  return { resolved: working, resolvedPairs, unresolvedPairs, duplicates };
}

import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, ChevronLeft, ChevronRight, ExternalLink, Package, Layers } from "lucide-react";
import { useArticleForB2bOverlay } from "@/hooks/useArticleForB2bOverlay";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface Props {
  cdpar: string | null;
  onClose: () => void;
}

/**
 * Overlay prodotto in stile B2B mockup (palette avorio + verde scuro,
 * font Montserrat). Replica visiva del ProductDetail del progetto B2B,
 * popolato con dati PIM. Tema scoped via CSS variables sul wrapper.
 */
export function B2bProductOverlay({ cdpar, onClose }: Props) {
  const open = !!cdpar;
  // Codice attivo (può essere il cdpar passato OPPURE una variante scelta nell'overlay)
  const [activeCdpar, setActiveCdpar] = useState<string | null>(cdpar);
  useEffect(() => {
    setActiveCdpar(cdpar);
  }, [cdpar]);

  const { data, isLoading, error } = useArticleForB2bOverlay(activeCdpar);
  const [activeIdx, setActiveIdx] = useState(0);
  const navigate = useNavigate();

  // Reset gallery quando cambia articolo
  if (data && activeIdx >= data.images.length) {
    setTimeout(() => setActiveIdx(0), 0);
  }

  // Varianti: cerca articoli che hanno cod_padre = activeCdpar (trim)
  const variantsKey = activeCdpar?.trim() ?? "";
  const { data: variants } = useQuery({
    queryKey: ["b2b-overlay-variants", variantsKey],
    enabled: !!variantsKey,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar, depar, descrizione_variante")
        .eq("cod_padre", variantsKey)
        .order("cdpar")
        .limit(100);
      if (error) throw error;
      return (data ?? []).map((r) => ({
        cdpar: (r.cdpar as string).trim(),
        depar: r.depar as string | null,
        descrizione_variante: (r as { descrizione_variante?: string | null }).descrizione_variante ?? null,
      }));
    },
  });

  const images = data?.images ?? [];
  const current = images[activeIdx];

  return (
    <Sheet open={open} onOpenChange={(o) => !o && onClose()}>
      <SheetContent
        side="right"
        className="w-full sm:max-w-2xl p-0 border-l-0 [&>button]:hidden"
        style={{
          // Tema B2B mockup scoped
          background: "hsl(40 33% 98%)",
          color: "hsl(30 10% 12%)",
          fontFamily: "'Montserrat', sans-serif",
        }}
      >
        {isLoading && (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="h-8 w-8 animate-spin" style={{ color: "hsl(149 50% 22%)" }} />
          </div>
        )}

        {!isLoading && (error || !data) && (
          <div className="flex items-center justify-center h-full text-sm" style={{ color: "hsl(0 72% 51%)" }}>
            {error ? "Errore caricamento articolo" : "Articolo non trovato"}
          </div>
        )}

        {data && (
          <ScrollArea className="h-full">
            <div className="p-6 space-y-6">
              {/* Header */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 flex-wrap">
                  {data.brand && (
                    <Badge
                      className="text-xs font-semibold uppercase tracking-wide border-0"
                      style={{ background: "hsl(149 50% 22%)", color: "white" }}
                    >
                      {data.brand}
                    </Badge>
                  )}
                  <span className="text-xs font-mono" style={{ color: "hsl(30 8% 50%)" }}>
                    Cod. {data.cdpar}
                  </span>
                  {data.ean && (
                    <span className="text-xs font-mono" style={{ color: "hsl(30 8% 50%)" }}>
                      EAN {data.ean}
                    </span>
                  )}
                </div>
                <h2
                  className="text-2xl font-semibold leading-tight"
                  style={{ fontFamily: "'Montserrat', sans-serif" }}
                >
                  {data.title || "(senza titolo)"}
                </h2>
              </div>

              {/* Galleria */}
              <div className="space-y-3">
                <div
                  className="rounded-xl overflow-hidden flex items-center justify-center aspect-square"
                  style={{
                    background: "hsl(35 30% 91%)",
                    boxShadow: "0 12px 40px -10px hsl(30 10% 12% / 0.15)",
                  }}
                >
                  {current ? (
                    <img
                      src={current.url}
                      alt={data.title}
                      className="max-w-full max-h-full object-contain"
                    />
                  ) : (
                    <Package className="h-16 w-16" style={{ color: "hsl(30 8% 50%)" }} />
                  )}
                </div>

                {images.length > 1 && (
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8 shrink-0"
                      onClick={() => setActiveIdx((i) => Math.max(0, i - 1))}
                      disabled={activeIdx === 0}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <div className="flex gap-2 overflow-x-auto flex-1">
                      {images.map((img, i) => (
                        <button
                          key={img.url}
                          type="button"
                          onClick={() => setActiveIdx(i)}
                          className="shrink-0 rounded-lg overflow-hidden border-2 transition"
                          style={{
                            borderColor: i === activeIdx ? "hsl(149 50% 22%)" : "transparent",
                            background: "hsl(35 30% 91%)",
                            width: 64,
                            height: 64,
                          }}
                        >
                          <img src={img.url} alt="" className="w-full h-full object-contain" />
                        </button>
                      ))}
                    </div>
                    <Button
                      type="button"
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8 shrink-0"
                      onClick={() => setActiveIdx((i) => Math.min(images.length - 1, i + 1))}
                      disabled={activeIdx === images.length - 1}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>

              {/* Descrizione */}
              {data.description && (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold uppercase tracking-wide" style={{ color: "hsl(149 50% 22%)" }}>
                    Descrizione
                  </h3>
                  <p className="text-sm leading-relaxed whitespace-pre-line" style={{ color: "hsl(30 10% 25%)" }}>
                    {data.description}
                  </p>
                </div>
              )}

              {/* Specifiche tecniche */}
              {data.attributes && Object.keys(data.attributes).length > 0 && (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold uppercase tracking-wide" style={{ color: "hsl(149 50% 22%)" }}>
                    Specifiche tecniche
                  </h3>
                  <div className="rounded-lg overflow-hidden" style={{ background: "hsl(35 30% 91%)" }}>
                    <dl className="divide-y" style={{ borderColor: "hsl(35 20% 88%)" }}>
                      {Object.entries(data.attributes)
                        .filter(([_, v]) => v !== null && v !== "" && typeof v !== "object")
                        .slice(0, 30)
                        .map(([k, v]) => (
                          <div key={k} className="grid grid-cols-2 gap-3 px-3 py-2 text-sm">
                            <dt className="font-medium" style={{ color: "hsl(30 10% 25%)" }}>
                              {k}
                            </dt>
                            <dd style={{ color: "hsl(30 10% 12%)" }}>{String(v)}</dd>
                          </div>
                        ))}
                    </dl>
                  </div>
                </div>
              )}

              {/* Varianti del codice padre */}
              {variants && variants.length > 0 && (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold uppercase tracking-wide flex items-center gap-2" style={{ color: "hsl(149 50% 22%)" }}>
                    <Layers className="h-4 w-4" />
                    Varianti disponibili ({variants.length})
                  </h3>
                  <div className="rounded-lg overflow-hidden divide-y" style={{ background: "hsl(35 30% 91%)", borderColor: "hsl(35 20% 88%)" }}>
                    {variants.map((v) => {
                      const isActive = v.cdpar === activeCdpar?.trim();
                      return (
                        <button
                          key={v.cdpar}
                          type="button"
                          onClick={() => {
                            if (!isActive) {
                              setActiveCdpar(v.cdpar);
                              setActiveIdx(0);
                            }
                          }}
                          className="w-full text-left px-3 py-2 text-sm transition hover:opacity-80 flex items-center gap-3"
                          style={{
                            background: isActive ? "hsl(149 50% 22% / 0.1)" : "transparent",
                            borderColor: "hsl(35 20% 88%)",
                          }}
                        >
                          <span className="font-mono text-xs shrink-0" style={{ color: "hsl(149 50% 22%)" }}>
                            {v.cdpar}
                          </span>
                          <span className="flex-1 truncate" style={{ color: "hsl(30 10% 25%)" }}>
                            {v.descrizione_variante || v.depar || "—"}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* CTA */}
              <div className="pt-4 border-t" style={{ borderColor: "hsl(35 20% 88%)" }}>
                <Button
                  className="w-full"
                  style={{
                    background: "hsl(149 50% 22%)",
                    color: "white",
                    fontFamily: "'Montserrat', sans-serif",
                  }}
                  onClick={() => {
                    navigate(`/pim/articles/${encodeURIComponent(data.cdpar)}`);
                    onClose();
                  }}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Apri scheda PIM completa
                </Button>
              </div>
            </div>
          </ScrollArea>
        )}
      </SheetContent>
    </Sheet>
  );
}

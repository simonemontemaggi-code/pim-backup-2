// Configurazione worker pdf.js per Vite
import * as pdfjsLib from "pdfjs-dist";
// @ts-ignore - import worker as URL string (Vite)
import pdfWorker from "pdfjs-dist/build/pdf.worker.min.mjs?url";

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

export { pdfjsLib };

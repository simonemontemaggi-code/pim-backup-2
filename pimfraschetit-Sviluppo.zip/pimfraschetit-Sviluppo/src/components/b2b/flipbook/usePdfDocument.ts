import { useEffect, useState } from "react";
import { pdfjsLib } from "./pdfWorker";

export type PdfDoc = Awaited<ReturnType<typeof pdfjsLib.getDocument>["promise"]>;

export function usePdfDocument(url: string | null | undefined) {
  const [doc, setDoc] = useState<PdfDoc | null>(null);
  const [numPages, setNumPages] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!url) {
      setDoc(null);
      setNumPages(0);
      return;
    }
    let cancelled = false;
    setLoading(true);
    setError(null);
    const task = pdfjsLib.getDocument(url);
    task.promise
      .then((d) => {
        if (cancelled) return;
        setDoc(d);
        setNumPages(d.numPages);
        setLoading(false);
      })
      .catch((e) => {
        if (cancelled) return;
        setError(e.message ?? "Errore caricamento PDF");
        setLoading(false);
      });
    return () => {
      cancelled = true;
      task.destroy();
    };
  }, [url]);

  return { doc, numPages, loading, error };
}

/** Renderizza una pagina PDF su un canvas e ritorna il dataURL */
export async function renderPageToDataUrl(
  doc: PdfDoc,
  pageNumber: number,
  scale = 1.5
): Promise<{ dataUrl: string; width: number; height: number }> {
  const page = await doc.getPage(pageNumber);
  const viewport = page.getViewport({ scale });
  const canvas = document.createElement("canvas");
  canvas.width = viewport.width;
  canvas.height = viewport.height;
  const ctx = canvas.getContext("2d")!;
  await page.render({ canvasContext: ctx, viewport, canvas }).promise;
  return {
    dataUrl: canvas.toDataURL("image/jpeg", 0.85),
    width: viewport.width,
    height: viewport.height,
  };
}

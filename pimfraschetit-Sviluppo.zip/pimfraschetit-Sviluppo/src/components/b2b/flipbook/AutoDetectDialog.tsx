import { useState } from "react";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Loader2, Wand2, CheckCircle2, XCircle, AlertTriangle } from "lucide-react";

export type MergeStrategy = "add" | "replace" | "skip";
export type HotspotShape = "image" | "code";

export interface AutoDetectResult {
  candidatesCount: number;
  matchedCodes: string[];
  hotspotsToCreate: number;
  pagesScanned: number[];
  existingOnPages: number;
}

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  scanning: boolean;
  progress: number;
  result: AutoDetectResult | null;
  onConfirm: (strategy: MergeStrategy, shape: HotspotShape) => void;
}

export function AutoDetectDialog({ open, onOpenChange, scanning, progress, result, onConfirm }: Props) {
  const [strategy, setStrategy] = useState<MergeStrategy>("replace");
  const [shape, setShape] = useState<HotspotShape>("image");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wand2 className="h-4 w-4" /> Auto-rilevamento hotspot
          </DialogTitle>
          <DialogDescription>
            Estraggo i codici a 6 cifre dal PDF e li confronto con l'archivio articoli.
          </DialogDescription>
        </DialogHeader>

        {scanning && (
          <div className="space-y-2 py-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> Scansione in corso... {progress}%
            </div>
            <Progress value={progress} />
          </div>
        )}

        {!scanning && result && (
          <div className="space-y-3 py-2 text-sm">
            <div className="rounded border p-3 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Pagine scansionate</span>
                <span className="font-medium">{result.pagesScanned.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Codici a 6 cifre trovati (univoci)</span>
                <span className="font-medium">{result.candidatesCount}</span>
              </div>
              <div className="flex items-center justify-between text-emerald-600">
                <span className="flex items-center gap-1.5"><CheckCircle2 className="h-3.5 w-3.5" /> Articoli riconosciuti</span>
                <span className="font-semibold">{result.matchedCodes.length}</span>
              </div>
              <div className="flex items-center justify-between text-muted-foreground">
                <span className="flex items-center gap-1.5"><XCircle className="h-3.5 w-3.5" /> Scartati (non in archivio)</span>
                <span>{result.candidatesCount - result.matchedCodes.length}</span>
              </div>
              <div className="border-t pt-2 flex items-center justify-between">
                <span className="text-muted-foreground">Hotspot da creare</span>
                <span className="font-bold text-primary">{result.hotspotsToCreate}</span>
              </div>
            </div>

            <div className="rounded border p-3 space-y-2">
              <div className="text-xs font-medium">Forma dell'hotspot</div>
              <RadioGroup value={shape} onValueChange={(v) => setShape(v as HotspotShape)}>
                <div className="flex items-start gap-2">
                  <RadioGroupItem value="image" id="s-image" className="mt-0.5" />
                  <Label htmlFor="s-image" className="text-xs font-normal cursor-pointer">
                    <span className="font-medium">Sull'immagine prodotto</span> — l'hotspot copre la foto sopra il codice
                  </Label>
                </div>
                <div className="flex items-start gap-2">
                  <RadioGroupItem value="code" id="s-code" className="mt-0.5" />
                  <Label htmlFor="s-code" className="text-xs font-normal cursor-pointer">
                    <span className="font-medium">Solo sul codice articolo</span> — bbox stretta sul testo del codice
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {result.existingOnPages > 0 && (
              <div className="rounded border border-amber-300 bg-amber-50 p-3 space-y-2">
                <div className="flex items-center gap-1.5 text-amber-800 text-xs font-medium">
                  <AlertTriangle className="h-3.5 w-3.5" />
                  {result.existingOnPages} hotspot già esistenti su queste pagine
                </div>
                <RadioGroup value={strategy} onValueChange={(v) => setStrategy(v as MergeStrategy)}>
                  <div className="flex items-start gap-2">
                    <RadioGroupItem value="replace" id="r-replace" className="mt-0.5" />
                    <Label htmlFor="r-replace" className="text-xs font-normal cursor-pointer">
                      <span className="font-medium">Sostituisci</span> — rimuovi i vecchi hotspot delle pagine scansionate
                    </Label>
                  </div>
                  <div className="flex items-start gap-2">
                    <RadioGroupItem value="add" id="r-add" className="mt-0.5" />
                    <Label htmlFor="r-add" className="text-xs font-normal cursor-pointer">
                      <span className="font-medium">Aggiungi</span> — mantieni i vecchi (possibili duplicati)
                    </Label>
                  </div>
                  <div className="flex items-start gap-2">
                    <RadioGroupItem value="skip" id="r-skip" className="mt-0.5" />
                    <Label htmlFor="r-skip" className="text-xs font-normal cursor-pointer">
                      <span className="font-medium">Salta pagine già lavorate</span>
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            )}
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={scanning}>
            Annulla
          </Button>
          <Button
            onClick={() => onConfirm(strategy, shape)}
            disabled={scanning || !result || result.hotspotsToCreate === 0}
          >
            <Wand2 className="h-4 w-4 mr-1" />
            Crea {result?.hotspotsToCreate ?? 0} hotspot
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import HTMLFlipBook from "react-pageflip";
import {
  Loader2,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  List,
  X,
  ZoomIn,
  ZoomOut,
  Download,
  Printer,
  Share2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Slider } from "@/components/ui/slider";
import { toast } from "sonner";
import { usePdfDocument, renderPageToDataUrl } from "./usePdfDocument";
import type { Hotspot } from "./types";

interface Props {
  pdfUrl: string;
  hotspots?: Hotspot[];
  onHotspotClick?: (h: Hotspot) => void;
  onClose?: () => void;
}

interface PageData {
  dataUrl: string;
  width: number;
  height: number;
}

type FlipBookRef = {
  pageFlip: () => {
    flip: (page: number) => void;
    flipPrev: () => void;
    flipNext: () => void;
  };
};

// Palette B2B mockup (scoped via inline style)
const B2B = {
  canvas: "hsl(40 33% 98%)",
  toolbar: "hsl(35 30% 91%)",
  border: "hsl(35 20% 88%)",
  text: "hsl(30 10% 12%)",
  muted: "hsl(30 8% 50%)",
  primary: "hsl(149 50% 22%)",
  hover: "hsl(35 20% 85%)",
};

function PageContent({
  pageNumber,
  pageData,
  hotspots,
  onHotspotClick,
}: {
  pageNumber: number;
  pageData?: PageData;
  hotspots: Hotspot[];
  onHotspotClick?: (h: Hotspot) => void;
}) {
  const pageHotspots = hotspots.filter((h) => h.page === pageNumber);
  return (
    <div className="relative w-full h-full bg-white select-none">
      {pageData ? (
        <>
          <img
            src={pageData.dataUrl}
            alt={`Pagina ${pageNumber}`}
            className="w-full h-full object-contain pointer-events-none"
            draggable={false}
          />
          {pageHotspots.map((h) => (
            <button
              key={h.id}
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onHotspotClick?.(h);
              }}
              className="absolute cursor-pointer bg-transparent border-0 p-0 m-0 outline-none focus:outline-none"
              style={{
                left: `${h.x * 100}%`,
                top: `${h.y * 100}%`,
                width: `${h.w * 100}%`,
                height: `${h.h * 100}%`,
              }}
              title={h.label || h.cdpar || h.url || ""}
              aria-label={h.label || h.cdpar || "hotspot"}
            />
          ))}
        </>
      ) : (
        <div className="flex items-center justify-center h-full">
          <Loader2 className="h-6 w-6 animate-spin" style={{ color: B2B.muted }} />
        </div>
      )}
    </div>
  );
}

export function FlipbookViewer({ pdfUrl, hotspots = [], onHotspotClick, onClose }: Props) {
  const { doc, numPages, loading, error } = usePdfDocument(pdfUrl);
  const [pages, setPages] = useState<Record<number, PageData>>({});
  const [thumbs, setThumbs] = useState<Record<number, string>>({});
  const [currentPage, setCurrentPage] = useState(0);
  const [showIndex, setShowIndex] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [pageInput, setPageInput] = useState("");
  const [zoom, setZoom] = useState(1);
  const flipRef = useRef<FlipBookRef | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const [stageSize, setStageSize] = useState({ w: 0, h: 0 });

  // Misura dinamica dell'area pagine
  useLayoutEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const update = () => {
      const r = el.getBoundingClientRect();
      setStageSize({ w: r.width, h: r.height });
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    window.addEventListener("resize", update);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", update);
    };
  }, []);

  // Render pagine on-demand (corrente +/- 2)
  useEffect(() => {
    if (!doc) return;
    const toRender: number[] = [];
    for (let i = -2; i <= 3; i++) {
      const p = currentPage + i + 1;
      if (p >= 1 && p <= numPages && !pages[p]) toRender.push(p);
    }
    if (toRender.length === 0) return;

    let cancelled = false;
    (async () => {
      for (const p of toRender) {
        if (cancelled) return;
        try {
          const data = await renderPageToDataUrl(doc, p, 1.5);
          if (!cancelled) setPages((s) => ({ ...s, [p]: data }));
        } catch (e) {
          console.error("render page", p, e);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [doc, currentPage, numPages]);

  // Render miniature
  useEffect(() => {
    if (!doc || !showIndex) return;
    let cancelled = false;
    (async () => {
      for (let p = 1; p <= numPages; p++) {
        if (cancelled || thumbs[p]) continue;
        try {
          const data = await renderPageToDataUrl(doc, p, 0.3);
          if (!cancelled) setThumbs((s) => ({ ...s, [p]: data.dataUrl }));
        } catch (e) {
          console.error("thumb", p, e);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [doc, showIndex, numPages]);

  const goToPage = (p: number) => {
    const target = Math.max(0, Math.min(numPages - 1, p));
    flipRef.current?.pageFlip()?.flip(target);
  };

  const toggleFullscreen = async () => {
    const el = containerRef.current;
    if (!el) return;
    if (!document.fullscreenElement) {
      await el.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      await document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const onChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, []);

  const handleDownload = () => {
    const a = document.createElement("a");
    a.href = pdfUrl;
    a.download = "";
    a.target = "_blank";
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handlePrint = () => {
    try {
      const iframe = document.createElement("iframe");
      iframe.style.position = "fixed";
      iframe.style.right = "0";
      iframe.style.bottom = "0";
      iframe.style.width = "0";
      iframe.style.height = "0";
      iframe.style.border = "0";
      iframe.src = pdfUrl;
      iframe.onload = () => {
        try {
          iframe.contentWindow?.focus();
          iframe.contentWindow?.print();
        } catch {
          window.open(pdfUrl, "_blank");
        }
      };
      document.body.appendChild(iframe);
    } catch {
      window.open(pdfUrl, "_blank");
    }
  };

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(pdfUrl);
      toast.success("Link copiato negli appunti");
    } catch {
      toast.error("Impossibile copiare il link");
    }
  };

  const aspect = useMemo(() => {
    const first = pages[1];
    if (!first) return 1.41; // A4 default
    return first.height / first.width;
  }, [pages]);

  // Calcolo basato sulle dimensioni reali del container (zoom NON incluso)
  const bookDims = useMemo(() => {
    const padding = 24;
    const availW = Math.max(280, stageSize.w - padding * 2);
    const availH = Math.max(300, stageSize.h - padding * 2);
    let pageW = Math.min(availW / 2, availH / aspect);
    pageW = Math.max(220, Math.min(pageW, 800));
    const pageH = pageW * aspect;
    return { pageW: Math.floor(pageW), pageH: Math.floor(pageH) };
  }, [aspect, stageSize.w, stageSize.h]);

  if (error) {
    return (
      <div className="flex items-center justify-center h-full" style={{ color: "hsl(0 72% 51%)" }}>
        Errore: {error}
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="flex flex-col h-full overflow-hidden"
      style={{ background: B2B.canvas, color: B2B.text, fontFamily: "'Montserrat', sans-serif" }}
    >
      {/* Area principale: indice + stage */}
      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* Indice miniature */}
        {showIndex && (
          <div className="w-56 border-r shrink-0" style={{ background: B2B.toolbar, borderColor: B2B.border }}>
            <ScrollArea className="h-full">
              <div className="p-2 grid grid-cols-2 gap-2">
                {Array.from({ length: numPages }).map((_, i) => {
                  const p = i + 1;
                  const active = p === currentPage + 1 || p === currentPage + 2;
                  return (
                    <button
                      key={p}
                      onClick={() => goToPage(i)}
                      className="border rounded overflow-hidden text-xs transition"
                      style={{
                        borderColor: active ? B2B.primary : B2B.border,
                        boxShadow: active ? `0 0 0 2px hsl(149 50% 22% / 0.3)` : undefined,
                        background: B2B.canvas,
                      }}
                    >
                      {thumbs[p] ? (
                        <img src={thumbs[p]} alt={`p ${p}`} className="w-full block" />
                      ) : (
                        <div className="aspect-[1/1.41] flex items-center justify-center" style={{ background: B2B.hover }}>
                          <Loader2 className="h-3 w-3 animate-spin" />
                        </div>
                      )}
                      <div className="text-center py-0.5" style={{ background: B2B.hover }}>{p}</div>
                    </button>
                  );
                })}
              </div>
            </ScrollArea>
          </div>
        )}

        {/* Stage: a zoom 1 blocchiamo l'overflow perché l'animazione pageflip crea elementi fuori area */}
        <div
          ref={stageRef}
          className={zoom > 1 ? "flex-1 overflow-auto min-w-0 min-h-0" : "flex-1 overflow-hidden min-w-0 min-h-0"}
        >
          <div
            className="w-full h-full flex items-center justify-center p-3"
            style={{
              minWidth: zoom > 1 ? `${zoom * 100}%` : undefined,
              minHeight: zoom > 1 ? `${zoom * 100}%` : undefined,
            }}
          >
            {loading || !doc || !numPages || stageSize.w === 0 ? (
              <Loader2 className="h-8 w-8 animate-spin" style={{ color: B2B.muted }} />
            ) : (
              (() => {
                // Cover singola: react-pageflip in landscape disegna la cover come pagina destra,
                // lasciando uno spazio vuoto a sinistra. Centriamo manualmente con un translateX
                // pari a metà pagina quando siamo sulla cover (pagina 0) o sulla retrocopertina
                // (ultima pagina, indice numPages-1).
                const isCover = currentPage === 0;
                const isBackCover = numPages > 0 && currentPage === numPages - 1;
                const offsetX = isCover
                  ? -bookDims.pageW / 2
                  : isBackCover
                  ? bookDims.pageW / 2
                  : 0;
                return (
                  <div
                    style={{
                      width: `${bookDims.pageW * 2}px`,
                      height: `${bookDims.pageH}px`,
                      overflow: "hidden",
                      contain: "layout paint",
                      transform: `scale(${zoom}) translateX(${offsetX}px)`,
                      transformOrigin: "center center",
                      transition: "transform 0.35s ease",
                    }}
                  >

                <HTMLFlipBook
                  ref={flipRef}
                  width={bookDims.pageW}
                  height={bookDims.pageH}
                  size="fixed"
                  minWidth={220}
                  maxWidth={1000}
                  minHeight={300}
                  maxHeight={1400}
                  showCover={true}
                  mobileScrollSupport={true}
                  onFlip={(e: { data: number }) => setCurrentPage(e.data)}
                  className=""
                  style={{}}
                  startPage={0}
                  drawShadow={true}
                  flippingTime={700}
                  usePortrait={false}
                  startZIndex={0}
                  autoSize={false}
                  maxShadowOpacity={0.5}
                  clickEventForward={true}
                  useMouseEvents={true}
                  swipeDistance={30}
                  showPageCorners={true}
                  disableFlipByClick={false}
                >
                  {Array.from({ length: numPages }).map((_, i) => (
                    <div key={i + 1} className="bg-white shadow-lg">
                      <PageContent
                        pageNumber={i + 1}
                        pageData={pages[i + 1]}
                        hotspots={hotspots}
                        onHotspotClick={onHotspotClick}
                      />
                    </div>
                  ))}
                </HTMLFlipBook>
                  </div>
                );
              })()
            )}
          </div>
        </div>
      </div>

      {/* Toolbar in basso */}
      <div
        className="flex items-center justify-between gap-3 px-3 py-2 border-t shrink-0 flex-wrap"
        style={{ background: B2B.toolbar, borderColor: B2B.border }}
      >
        {/* Sinistra: Indice */}
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => setShowIndex((s) => !s)}
            style={{ color: B2B.text }}
          >
            <List className="h-4 w-4 mr-1" /> Indice
          </Button>
        </div>

        {/* Centro: navigazione pagine */}
        <div className="flex items-center gap-2">
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8"
            style={{ color: B2B.text }}
            onClick={() => flipRef.current?.pageFlip()?.flipPrev()}
            disabled={loading || currentPage <= 0}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="text-sm tabular-nums flex items-center">
            <Input
              className="inline-block w-14 h-7 text-center"
              style={{ background: B2B.canvas, borderColor: B2B.border, color: B2B.text }}
              value={pageInput || (currentPage + 1).toString()}
              onChange={(e) => setPageInput(e.target.value.replace(/\D/g, ""))}
              onBlur={() => {
                if (pageInput) {
                  goToPage(parseInt(pageInput) - 1);
                  setPageInput("");
                }
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  goToPage(parseInt(pageInput) - 1);
                  setPageInput("");
                  (e.target as HTMLInputElement).blur();
                }
              }}
            />
            <span className="ml-2" style={{ color: B2B.muted }}>/ {numPages || "?"}</span>
          </div>
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8"
            style={{ color: B2B.text }}
            onClick={() => flipRef.current?.pageFlip()?.flipNext()}
            disabled={loading || currentPage >= numPages - 1}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        {/* Destra: zoom + azioni */}
        <div className="flex items-center gap-1">
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8"
            style={{ color: B2B.text }}
            onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.1).toFixed(2)))}
            title="Riduci"
          >
            <ZoomOut className="h-4 w-4" />
          </Button>
          <div className="w-24 px-1" onDoubleClick={() => setZoom(1)} title="Doppio click per reset">
            <Slider
              value={[zoom]}
              min={0.5}
              max={2}
              step={0.1}
              onValueChange={(v) => setZoom(v[0])}
            />
          </div>
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8"
            style={{ color: B2B.text }}
            onClick={() => setZoom((z) => Math.min(2, +(z + 0.1).toFixed(2)))}
            title="Ingrandisci"
          >
            <ZoomIn className="h-4 w-4" />
          </Button>

          <div className="w-px h-5 mx-1" style={{ background: B2B.border }} />

          <Button size="icon" variant="ghost" className="h-8 w-8" style={{ color: B2B.text }} onClick={handlePrint} title="Stampa">
            <Printer className="h-4 w-4" />
          </Button>
          <Button size="icon" variant="ghost" className="h-8 w-8" style={{ color: B2B.text }} onClick={handleDownload} title="Scarica PDF">
            <Download className="h-4 w-4" />
          </Button>
          <Button size="icon" variant="ghost" className="h-8 w-8" style={{ color: B2B.text }} onClick={handleShare} title="Condividi link">
            <Share2 className="h-4 w-4" />
          </Button>
          <Button size="icon" variant="ghost" className="h-8 w-8" style={{ color: B2B.text }} onClick={toggleFullscreen} title="Schermo intero">
            {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </Button>
          {onClose && (
            <Button size="icon" variant="ghost" className="h-8 w-8" style={{ color: B2B.text }} onClick={onClose} title="Chiudi">
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

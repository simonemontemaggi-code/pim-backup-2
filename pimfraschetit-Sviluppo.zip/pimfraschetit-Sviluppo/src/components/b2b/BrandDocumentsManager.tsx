import { useEffect, useRef, useState } from "react";
import { Upload, Loader2, Trash2, FileText, ExternalLink } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { maybeOptimizePdf } from "@/lib/maybeOptimizePdf";

type Category = "centri_assistenza" | "piu_info";

interface BrandDocument {
  id: string;
  title: string;
  file_url: string;
  file_name: string | null;
  file_size: number | null;
  sort_order: number;
}

interface Props {
  clas2: string;
  category: Category;
  title: string;
  description?: string;
}

const fmtSize = (n: number | null) => {
  if (!n) return "";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
};

export function BrandDocumentsManager({ clas2, category, title, description }: Props) {
  const [docs, setDocs] = useState<BrandDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const confirm = useConfirm();

  const load = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("brand_documents")
      .select("id, title, file_url, file_name, file_size, sort_order")
      .eq("clas2", clas2)
      .eq("category", category)
      .order("sort_order", { ascending: true })
      .order("created_at", { ascending: true });
    setDocs((data as BrandDocument[]) || []);
    setLoading(false);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clas2, category]);

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const startOrder = docs.length;
      let i = 0;
      for (const file of Array.from(files)) {
        if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) {
          toast.error(`${file.name}: solo PDF`);
          continue;
        }
        const optimized = await maybeOptimizePdf(file);
        const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
        const path = `brands/${clas2}/docs/${category}/${crypto.randomUUID()}_${safeName}`;
        const { error: upErr } = await supabase.storage
          .from("pim-media")
          .upload(path, optimized, { upsert: false, contentType: "application/pdf" });
        if (upErr) throw upErr;
        const { data: pub } = supabase.storage.from("pim-media").getPublicUrl(path);
        const { error: insErr } = await supabase.from("brand_documents").insert({
          clas2,
          category,
          title: file.name.replace(/\.pdf$/i, ""),
          file_url: pub.publicUrl,
          file_name: file.name,
          file_size: optimized.size,
          sort_order: startOrder + i,
          created_by: user?.id ?? null,
        });
        if (insErr) throw insErr;
        i++;
      }
      toast.success("Documenti caricati");
      await load();
    } catch (e: any) {
      toast.error(`Errore upload: ${e.message}`);
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const updateTitle = async (id: string, newTitle: string) => {
    setDocs((d) => d.map((x) => (x.id === id ? { ...x, title: newTitle } : x)));
  };

  const saveTitle = async (id: string, newTitle: string) => {
    await supabase.from("brand_documents").update({ title: newTitle }).eq("id", id);
  };

  const remove = async (doc: BrandDocument) => {
    if (!(await confirm({ title: `Eliminare "${doc.title}"?`, destructive: true, confirmText: "Elimina" }))) return;
    try {
      const m = doc.file_url.match(/\/pim-media\/(.+?)(\?.*)?$/);
      if (m) await supabase.storage.from("pim-media").remove([m[1]]);
    } catch (_) {
      /* best effort */
    }
    await supabase.from("brand_documents").delete().eq("id", doc.id);
    toast.success("Documento eliminato");
    await load();
  };

  return (
    <Card className="p-5 space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold">{title}</h3>
          {description && <p className="text-xs text-muted-foreground">{description}</p>}
        </div>
        <Button
          type="button"
          size="sm"
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
        >
          {uploading ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Upload className="h-4 w-4 mr-2" />
          )}
          Aggiungi PDF
        </Button>
        <input
          ref={inputRef}
          type="file"
          accept="application/pdf"
          multiple
          className="hidden"
          onChange={(e) => handleFiles(e.target.files)}
        />
      </div>

      {loading ? (
        <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
      ) : docs.length === 0 ? (
        <div className="text-sm text-muted-foreground border border-dashed rounded-md p-4 text-center">
          Nessun documento caricato.
        </div>
      ) : (
        <div className="space-y-2">
          {docs.map((d) => (
            <div
              key={d.id}
              className="flex items-center gap-2 border rounded-md p-2 bg-card"
            >
              <FileText className="h-5 w-5 text-muted-foreground shrink-0" />
              <Input
                value={d.title}
                onChange={(e) => updateTitle(d.id, e.target.value)}
                onBlur={(e) => saveTitle(d.id, e.target.value)}
                className="flex-1"
              />
              <span className="text-xs text-muted-foreground whitespace-nowrap">
                {fmtSize(d.file_size)}
              </span>
              <Button variant="ghost" size="icon" asChild>
                <a href={d.file_url} target="_blank" rel="noreferrer">
                  <ExternalLink className="h-4 w-4" />
                </a>
              </Button>
              <Button variant="ghost" size="icon" onClick={() => remove(d)}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}

import { ChevronRight, Link2 } from "lucide-react";

interface Props {
  image?: string | null;
  title?: string | null;
  subtitle?: string | null;
  cta?: string | null;
  link?: string | null;
}

/**
 * Replica fedele dell'HeroSlider della homepage B2B (16:5.5).
 * Logica CTA:
 * - se `cta` valorizzato → mostra il pulsante (link → cliente al link)
 * - altrimenti se `link` valorizzato → tutta l'immagine diventa cliccabile
 */
export function HeroSlidePreview({ image, title, subtitle, cta, link }: Props) {
  const hasCta = !!(cta && cta.trim());
  const hasLink = !!(link && link.trim());
  const wholeClickable = !hasCta && hasLink;

  return (
    <div
      className="relative w-full overflow-hidden rounded-lg border bg-muted"
      style={{ aspectRatio: "16/5.5" }}
    >
      {image ? (
        <img src={image} alt={title || ""} className="h-full w-full object-cover" />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center text-sm text-muted-foreground">
          Nessuna immagine
        </div>
      )}
      <div className="absolute inset-0 bg-gradient-to-r from-foreground/70 via-foreground/30 to-transparent" />
      <div className="absolute inset-0 flex flex-col justify-center px-8 md:px-12">
        {title && (
          <h2 className="text-2xl md:text-3xl font-bold text-primary-foreground mb-2 max-w-lg">
            {title}
          </h2>
        )}
        {subtitle && (
          <p className="text-sm md:text-base text-primary-foreground/85 mb-5 max-w-md">
            {subtitle}
          </p>
        )}
        {hasCta && (
          <span className="inline-flex w-fit items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground">
            {cta}
            <ChevronRight className="h-4 w-4" />
          </span>
        )}
      </div>
      {wholeClickable && (
        <>
          <div className="absolute inset-0 ring-2 ring-primary/40 ring-inset rounded-lg pointer-events-none" />
          <div className="absolute top-2 right-2 inline-flex items-center gap-1 rounded-md bg-primary/90 px-2 py-1 text-[10px] font-semibold text-primary-foreground shadow">
            <Link2 className="h-3 w-3" /> Immagine cliccabile → {link}
          </div>
        </>
      )}
    </div>
  );
}

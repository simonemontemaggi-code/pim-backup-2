import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Check, ChevronsUpDown, Link as LinkIcon, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel } from "@/components/ui/select";
import { cn } from "@/lib/utils";

/**
 * Tipi di destinazione supportati.
 * *_index → pagina indice (nessuna selezione secondaria)
 * *       → risorsa specifica (richiede combobox)
 */
export type LinkTargetType =
  | "url"
  | "promo_index"
  | "promo"
  | "offerta"
  | "assortment_index"
  | "assortment"
  | "brand_index"
  | "brand"
  | "catalog_index"
  | "catalog";

interface Props {
  value: string | null | undefined;
  onChange: (url: string) => void;
}

const INDEX_URL: Record<string, string> = {
  promo_index: "/offers",
  assortment_index: "/assortimenti",
  brand_index: "/brands",
  catalog_index: "/cataloghi",
};

const SINGLE_PREFIX: Record<string, string> = {
  assortment: "/assortment/",
  brand: "/brand/",
  catalog: "/catalogo/",
};

const TYPE_LABEL: Record<string, string> = {
  promo: "una Promo",
  offerta: "un'Offerta",
  assortment: "un Assortimento",
  brand: "un Brand",
  catalog: "un Catalogo",
};

/** Slug catalogo: lowercase, senza accenti, run di non [a-z0-9] → singolo '-', trim. */
function slugifyCatalog(name: string): string {
  return (name || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

/** Rimuove accenti e lowercase per la ricerca. */
function norm(s: string): string {
  return (s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

/** Converte YYYYMMDD numerico AS400 in Date (o null). */
function as400NumToDate(n: number | null | undefined): Date | null {
  if (!n || !Number.isFinite(Number(n))) return null;
  const s = String(Math.trunc(Number(n))).padStart(8, "0");
  if (s.length !== 8) return null;
  const y = Number(s.slice(0, 4));
  const m = Number(s.slice(4, 6));
  const d = Number(s.slice(6, 8));
  if (!y || !m || !d) return null;
  return new Date(y, m - 1, d);
}

function toDate(v: string | Date | null | undefined): Date | null {
  if (!v) return null;
  if (v instanceof Date) return v;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}

function startOfDay(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

type Status = "past" | "current" | "future" | "unknown";

function computeStatus(from: Date | null, to: Date | null, today: Date): Status {
  if (!from && !to) return "unknown";
  const t = today.getTime();
  const f = from ? startOfDay(from).getTime() : -Infinity;
  const e = to ? startOfDay(to).getTime() : Infinity;
  if (t < f) return "future";
  if (t > e) return "past";
  return "current";
}

/** Analizza un `link_url` e restituisce tipo + slug (per Offerta: `${promoId}__${tema_id}`). */
function parseUrl(url: string | null | undefined): { type: LinkTargetType; slug: string } {
  const u = (url || "").trim();
  if (!u) return { type: "url", slug: "" };

  const off = u.match(/^\/offers\/([^/]+)\/([^/]+)\/?$/);
  if (off) return { type: "offerta", slug: `${off[1]}__${off[2]}` };

  const pr = u.match(/^\/offers\/([^/]+)\/?$/);
  if (pr) return { type: "promo", slug: pr[1] };

  for (const [t, p] of Object.entries(INDEX_URL)) {
    if (u === p || u === `${p}/`) return { type: t as LinkTargetType, slug: "" };
  }

  for (const [t, p] of Object.entries(SINGLE_PREFIX)) {
    if (u.startsWith(p)) {
      const rest = u.slice(p.length).replace(/\/$/, "");
      if (rest) return { type: t as LinkTargetType, slug: rest };
    }
  }

  return { type: "url", slug: u };
}

function buildUrl(type: LinkTargetType, slug: string): string {
  if (type === "url") return slug;
  if (INDEX_URL[type]) return INDEX_URL[type];
  if (type === "offerta") {
    const [promoId, themeId] = slug.split("__");
    if (!promoId || !themeId) return "";
    return `/offers/${promoId}/${themeId}`;
  }
  if (type === "promo") return slug ? `/offers/${slug}` : "";
  const p = SINGLE_PREFIX[type];
  if (!p || !slug) return "";
  return `${p}${slug}`;
}

const NEEDS_PICKER = new Set<LinkTargetType>(["promo", "offerta", "assortment", "brand", "catalog"]);
const TYPES_WITH_DATES = new Set<LinkTargetType>(["promo", "offerta", "assortment"]);

export function LinkTargetPicker({ value, onChange }: Props) {
  const initial = useMemo(() => parseUrl(value), []); // eslint-disable-line react-hooks/exhaustive-deps
  const [type, setType] = useState<LinkTargetType>(initial.type);
  const [slug, setSlug] = useState<string>(initial.slug);

  useEffect(() => {
    const p = parseUrl(value);
    setType(p.type);
    setSlug(p.slug);
  }, [value]);

  const update = (nextType: LinkTargetType, nextSlug: string) => {
    setType(nextType);
    setSlug(nextSlug);
    onChange(buildUrl(nextType, nextSlug));
  };

  const finalUrl = buildUrl(type, slug);

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-2">
        <Select value={type} onValueChange={(v) => update(v as LinkTargetType, "")}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="max-h-[420px]">
            <SelectItem value="url">URL personalizzato</SelectItem>

            <SelectGroup>
              <SelectLabel>Promo</SelectLabel>
              <SelectItem value="promo_index">Pagina di tutte le Promo</SelectItem>
              <SelectItem value="promo">Una Promo specifica</SelectItem>
              <SelectItem value="offerta">Un'Offerta specifica</SelectItem>
            </SelectGroup>

            <SelectGroup>
              <SelectLabel>Assortimenti</SelectLabel>
              <SelectItem value="assortment_index">Pagina Assortimenti</SelectItem>
              <SelectItem value="assortment">Un Assortimento specifico</SelectItem>
            </SelectGroup>

            <SelectGroup>
              <SelectLabel>Brand</SelectLabel>
              <SelectItem value="brand_index">Pagina Brand</SelectItem>
              <SelectItem value="brand">Un Brand specifico</SelectItem>
            </SelectGroup>

            <SelectGroup>
              <SelectLabel>Cataloghi</SelectLabel>
              <SelectItem value="catalog_index">Pagina Cataloghi</SelectItem>
              <SelectItem value="catalog">Un Catalogo (sfogliabile)</SelectItem>
            </SelectGroup>
          </SelectContent>
        </Select>

        {type === "url" ? (
          <Input
            value={slug}
            onChange={(e) => update("url", e.target.value)}
            placeholder="/category/utensili"
          />
        ) : NEEDS_PICKER.has(type) ? (
          <EntityDialog type={type} value={slug} onChange={(v) => update(type, v)} />
        ) : (
          <div className="flex items-center h-10 px-3 text-sm text-muted-foreground border rounded-md bg-muted/40">
            Nessuna selezione richiesta
          </div>
        )}
      </div>
      {finalUrl && (
        <p className="text-[11px] text-muted-foreground flex items-center gap-1">
          <LinkIcon className="h-3 w-3" /> {finalUrl}
        </p>
      )}
    </div>
  );
}

interface Option {
  value: string;
  label: string;
  hint?: string;
  status: Status;
  from: Date | null;
  to: Date | null;
}

type FilterKey = "current_future" | "current" | "future" | "past" | "all";

const FILTER_LABEL: Record<FilterKey, string> = {
  current_future: "In corso + Future",
  current: "In corso",
  future: "Future",
  past: "Passate",
  all: "Tutte",
};

const STATUS_BADGE: Record<Status, { label: string; className: string } | null> = {
  current: { label: "Attiva", className: "bg-emerald-100 text-emerald-800 hover:bg-emerald-100 border-emerald-200" },
  future: { label: "Futura", className: "bg-blue-100 text-blue-800 hover:bg-blue-100 border-blue-200" },
  past: { label: "Scaduta", className: "bg-muted text-muted-foreground hover:bg-muted border-transparent" },
  unknown: null,
};

function EntityDialog({
  type,
  value,
  onChange,
}: {
  type: LinkTargetType;
  value: string;
  onChange: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<FilterKey>("current_future");

  const { data: options = [], isLoading } = useQuery<Option[]>({
    queryKey: ["link-target-picker", type],
    staleTime: 300_000,
    queryFn: async () => {
      const today = startOfDay(new Date());

      if (type === "catalog") {
        const { data, error } = await supabase
          .from("b2b_catalogs")
          .select("name,is_published_b2b,sort_order")
          .eq("is_published_b2b", true)
          .order("sort_order", { ascending: true });
        if (error) throw error;
        const seen = new Set<string>();
        const out: Option[] = [];
        for (const r of (data || []) as any[]) {
          const name = (r.name || "").trim();
          if (!name) continue;
          const slug = slugifyCatalog(name);
          if (!slug || seen.has(slug)) continue;
          seen.add(slug);
          out.push({
            value: slug,
            label: name,
            hint: `slug: ${slug} · apre lo sfogliabile`,
            status: "unknown",
            from: null,
            to: null,
          });
        }
        return out;
      }

      if (type === "brand") {
        const { data, error } = await supabase
          .from("archivio_brand_fraschetti")
          .select("clas2,display_name,nome_as400_brand,is_published_b2b")
          .eq("is_published_b2b", true)
          .order("display_name", { ascending: true });
        if (error) throw error;
        return (data || []).map((r: any) => ({
          value: r.clas2,
          label: r.display_name || r.nome_as400_brand || "(senza nome)",
          status: "unknown" as Status,
          from: null,
          to: null,
        }));
      }

      if (type === "assortment") {
        const { data, error } = await supabase
          .from("b2b_assortments")
          .select("slug,name,is_active,sort_order,valid_from,valid_to")
          .eq("is_active", true)
          .not("slug", "is", null)
          .order("sort_order", { ascending: true });
        if (error) throw error;
        return (data || [])
          .filter((r: any) => r.slug)
          .map((r: any) => {
            const from = toDate(r.valid_from);
            const to = toDate(r.valid_to);
            const status = computeStatus(from, to, today);
            const hint = from || to
              ? `dal ${from ? from.toLocaleDateString("it-IT") : "—"} al ${to ? to.toLocaleDateString("it-IT") : "—"}`
              : undefined;
            return {
              value: r.slug,
              label: r.name || "(senza nome)",
              hint,
              status,
              from,
              to,
            } as Option;
          });
      }

      if (type === "promo") {
        const { data: testate, error: e1 } = await supabase
          .from("promo_strutturate_testate")
          .select("wpcca,wpprgf,wprogr,wptpbd,wpdvali,wpdvalf")
          .eq("visible_b2b", true)
          .order("wprogr", { ascending: false })
          .limit(500);
        if (e1) throw e1;
        const wpprgfList = (testate || []).map((t: any) => Number(t.wpprgf)).filter((v: any) => Number.isFinite(v));
        const temiByWpprgf = new Map<number, { nome: string | null; sort_order: number | null }[]>();
        if (wpprgfList.length) {
          const { data: temi, error: e2 } = await supabase
            .from("promo_strutturate_temi")
            .select("wpprgf,nome,sort_order")
            .in("wpprgf", wpprgfList);
          if (e2) throw e2;
          for (const t of temi || []) {
            const key = Number((t as any).wpprgf);
            const arr = temiByWpprgf.get(key) || [];
            arr.push({ nome: (t as any).nome, sort_order: (t as any).sort_order });
            temiByWpprgf.set(key, arr);
          }
        }
        return (testate || []).map((r: any) => {
          const temi = temiByWpprgf.get(Number(r.wpprgf)) || [];
          const first = [...temi].sort((a, b) => (a.sort_order ?? 999) - (b.sort_order ?? 999))[0];
          const label = r.wptpbd?.trim() || first?.nome?.trim() || r.wpcca;
          const from = as400NumToDate(r.wpdvali);
          const to = as400NumToDate(r.wpdvalf);
          const status = computeStatus(from, to, today);
          const hint = from || to
            ? `dal ${from ? from.toLocaleDateString("it-IT") : "—"} al ${to ? to.toLocaleDateString("it-IT") : "—"}`
            : undefined;
          return { value: String(r.wpprgf), label, hint, status, from, to };
        });
      }

      if (type === "offerta") {
        const { data: testate, error: e1 } = await supabase
          .from("promo_strutturate_testate")
          .select("wpcca,wpprgf,wprogr,wptpbd")
          .eq("visible_b2b", true)
          .order("wprogr", { ascending: false })
          .limit(500);
        if (e1) throw e1;
        const testateByWpprgf = new Map<number, { label: string }>();
        for (const t of testate || []) {
          const key = Number((t as any).wpprgf);
          if (Number.isFinite(key)) {
            testateByWpprgf.set(key, { label: (t as any).wptpbd?.trim() || String(key) });
          }
        }
        const wpprgfList = Array.from(testateByWpprgf.keys());
        if (!wpprgfList.length) return [];
        const { data: temi, error: e2 } = await supabase
          .from("promo_strutturate_temi")
          .select("id,nome,sort_order,wpprgf,dal,al")
          .in("wpprgf", wpprgfList)
          .order("sort_order", { ascending: true })
          .limit(2000);
        if (e2) throw e2;
        const firstByWpprgf = new Map<number, string>();
        for (const t of temi || []) {
          const key = Number((t as any).wpprgf);
          if (!firstByWpprgf.has(key) && (t as any).nome?.trim()) {
            firstByWpprgf.set(key, (t as any).nome.trim());
          }
        }
        return (temi || [])
          .map((r: any) => {
            const key = Number(r.wpprgf);
            const testata = testateByWpprgf.get(key);
            if (!testata) return null;
            const promoLabel = testata.label || firstByWpprgf.get(key) || String(key);
            const from = toDate(r.dal);
            const to = toDate(r.al);
            const status = computeStatus(from, to, today);
            const dateHint = from || to
              ? ` · dal ${from ? from.toLocaleDateString("it-IT") : "—"} al ${to ? to.toLocaleDateString("it-IT") : "—"}`
              : "";
            return {
              value: `${key}__${r.id}`,
              label: r.nome?.trim() || "(offerta senza nome)",
              hint: `nella promo ${promoLabel}${dateHint}`,
              status,
              from,
              to,
            } as Option;
          })
          .filter(Boolean) as Option[];
      }

      return [];
    },
  });

  const hasDates = TYPES_WITH_DATES.has(type);
  const current = options.find((o) => o.value === value);

  const filtered = useMemo(() => {
    const q = norm(query.trim());
    let list = options;
    if (hasDates) {
      list = list.filter((o) => {
        if (filter === "all") return true;
        if (filter === "current_future") return o.status === "current" || o.status === "future" || o.status === "unknown";
        if (filter === "current") return o.status === "current" || o.status === "unknown";
        if (filter === "future") return o.status === "future";
        if (filter === "past") return o.status === "past";
        return true;
      });
    }
    if (q) {
      list = list.filter((o) => norm(`${o.label} ${o.hint || ""}`).includes(q));
    }
    // Ordina: current (per to asc), future (per from asc), past (per to desc), unknown ultimi mantenendo ordine
    const rank: Record<Status, number> = { current: 0, future: 1, past: 2, unknown: 3 };
    return [...list].sort((a, b) => {
      const r = rank[a.status] - rank[b.status];
      if (r !== 0) return r;
      if (a.status === "current") return (a.to?.getTime() ?? Infinity) - (b.to?.getTime() ?? Infinity);
      if (a.status === "future") return (a.from?.getTime() ?? Infinity) - (b.from?.getTime() ?? Infinity);
      if (a.status === "past") return (b.to?.getTime() ?? 0) - (a.to?.getTime() ?? 0);
      return 0;
    });
  }, [options, query, filter, hasDates]);

  useEffect(() => {
    if (open) {
      setQuery("");
      setFilter(hasDates ? "current_future" : "all");
    }
  }, [open, hasDates]);

  return (
    <>
      <Button
        type="button"
        variant="outline"
        role="combobox"
        onClick={() => setOpen(true)}
        className="justify-between font-normal w-full"
      >
        <span className={cn("truncate text-left", !current && "text-muted-foreground")}>
          {current ? current.label : isLoading ? "Caricamento…" : "Seleziona…"}
        </span>
        <ChevronsUpDown className="h-4 w-4 opacity-50 shrink-0" />
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl p-0 gap-0">
          <DialogHeader className="px-6 pt-6 pb-3">
            <DialogTitle>Seleziona {TYPE_LABEL[type] || "una risorsa"}</DialogTitle>
          </DialogHeader>

          <div className="px-6 pb-3 space-y-3 border-b">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Cerca per nome…"
                className="pl-9 h-11 text-base"
              />
            </div>

            {hasDates && (
              <Tabs value={filter} onValueChange={(v) => setFilter(v as FilterKey)}>
                <TabsList className="grid w-full grid-cols-5">
                  {(Object.keys(FILTER_LABEL) as FilterKey[]).map((k) => (
                    <TabsTrigger key={k} value={k} className="text-xs">
                      {FILTER_LABEL[k]}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>
            )}
          </div>

          <ScrollArea className="max-h-[50vh]">
            <div className="p-2">
              {isLoading ? (
                <div className="py-10 text-center text-sm text-muted-foreground">Caricamento…</div>
              ) : filtered.length === 0 ? (
                <div className="py-10 text-center text-sm text-muted-foreground">
                  Nessun risultato con questi filtri
                </div>
              ) : (
                <ul className="space-y-0.5">
                  {filtered.map((o) => {
                    const badge = STATUS_BADGE[o.status];
                    const selected = o.value === value;
                    return (
                      <li key={o.value}>
                        <button
                          type="button"
                          onClick={() => {
                            onChange(o.value);
                            setOpen(false);
                          }}
                          className={cn(
                            "w-full flex items-start gap-2 rounded-md px-3 py-2 text-left text-sm transition-colors hover:bg-accent hover:text-accent-foreground",
                            selected && "bg-accent/60",
                          )}
                        >
                          <Check className={cn("mt-0.5 h-4 w-4 shrink-0", selected ? "opacity-100" : "opacity-0")} />
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="truncate font-medium">{o.label}</span>
                              {badge && (
                                <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 h-4", badge.className)}>
                                  {badge.label}
                                </Badge>
                              )}
                            </div>
                            {o.hint && (
                              <div className="text-[11px] text-muted-foreground truncate mt-0.5">{o.hint}</div>
                            )}
                          </div>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </ScrollArea>

          <DialogFooter className="px-6 py-3 border-t sm:justify-between flex-row items-center">
            <span className="text-xs text-muted-foreground">
              {filtered.length} di {options.length} {options.length === 1 ? "risultato" : "risultati"}
            </span>
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Annulla
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

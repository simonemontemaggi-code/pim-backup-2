import { useMemo, useState } from "react";
import { ArrowDown, ArrowUp, ArrowUpDown, FileSpreadsheet, FileText } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  downloadCustomersExcel,
  downloadCustomersPdf,
  fmtAdoptionDate,
} from "@/lib/adoptionExport";
import type { AdoptionCustomerRow } from "@/hooks/usePortalAdoption";


type SortKey =
  | "code"
  | "name"
  | "zone"
  | "agent"
  | "activatedAt"
  | "vdcAttivo"
  | "vdcOrdini"
  | "ordiniCliente"
  | "ordiniAgente"
  | "ultimoOrdineCliente"
  | "ultimoOrdineAgente";

const COLUMNS: { key: SortKey; label: string; numeric?: boolean }[] = [
  { key: "code", label: "Codice" },
  { key: "name", label: "Ragione sociale" },
  { key: "zone", label: "Zona" },
  { key: "agent", label: "Agente" },
  { key: "activatedAt", label: "Attivo B2B dal" },
  { key: "vdcAttivo", label: "VdC" },
  { key: "vdcOrdini", label: "VdC ord." },
  { key: "ordiniCliente", label: "Ord. cliente", numeric: true },
  { key: "ordiniAgente", label: "Ord. agente", numeric: true },
  { key: "ultimoOrdineCliente", label: "Ult. ord. cliente" },
  { key: "ultimoOrdineAgente", label: "Ult. ord. agente" },
];

const fmtDate = fmtAdoptionDate;

export function CustomerDrilldownDialog({
  open,
  onOpenChange,
  title,
  subtitle,
  rows,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  title: string;
  subtitle?: string;
  rows: AdoptionCustomerRow[];
}) {
  const [sortKey, setSortKey] = useState<SortKey>("name");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    const base = term
      ? rows.filter(
          (r) =>
            r.code.toLowerCase().includes(term) ||
            r.name.toLowerCase().includes(term) ||
            r.zone.toLowerCase().includes(term) ||
            r.agent.toLowerCase().includes(term) ||
            (r.agentName ?? "").toLowerCase().includes(term),
        )
      : rows;
    const dir = sortDir === "asc" ? 1 : -1;
    return [...base].sort((a, b) => {
      const va = a[sortKey];
      const vb = b[sortKey];
      if (typeof va === "number" && typeof vb === "number") return (va - vb) * dir;
      if (typeof va === "boolean" && typeof vb === "boolean")
        return ((va ? 1 : 0) - (vb ? 1 : 0)) * dir;
      return String(va ?? "").localeCompare(String(vb ?? ""), "it") * dir;
    });
  }, [rows, q, sortKey, sortDir]);

  const toggleSort = (k: SortKey) => {
    if (k === sortKey) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(k);
      setSortDir("asc");
    }
  };

  const slug = title.replace(/[^\w]+/g, "_").slice(0, 60);

  const exportExcel = () => downloadCustomersExcel(`${slug}.xlsx`, filtered);

  const exportPdf = () =>
    downloadCustomersPdf({
      filename: `${slug}.pdf`,
      title,
      subtitle,
      rows: filtered,
    });


  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[95vw] xl:max-w-[1200px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            {subtitle ? `${subtitle} · ` : ""}
            {filtered.length} clienti
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-wrap items-center gap-2">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Cerca cliente, codice, agente…"
            className="h-8 w-64"
          />
          <div className="ml-auto flex gap-2">
            <Button size="sm" variant="outline" onClick={exportExcel}>
              <FileSpreadsheet className="mr-1.5 h-3.5 w-3.5" /> Excel
            </Button>
            <Button size="sm" variant="outline" onClick={exportPdf}>
              <FileText className="mr-1.5 h-3.5 w-3.5" /> PDF
            </Button>
          </div>
        </div>

        <div className="max-h-[65vh] overflow-auto rounded-md border">
          <table className="w-full text-xs">
            <thead className="sticky top-0 z-10 bg-muted">
              <tr>
                {COLUMNS.map((c) => (
                  <th
                    key={c.key}
                    onClick={() => toggleSort(c.key)}
                    className={`cursor-pointer select-none whitespace-nowrap px-2 py-2 font-medium ${
                      c.numeric ? "text-right" : "text-left"
                    }`}
                  >
                    <span className="inline-flex items-center gap-1">
                      {c.label}
                      {sortKey === c.key ? (
                        sortDir === "asc" ? (
                          <ArrowUp className="h-3 w-3" />
                        ) : (
                          <ArrowDown className="h-3 w-3" />
                        )
                      ) : (
                        <ArrowUpDown className="h-3 w-3 opacity-30" />
                      )}
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((r) => (
                <tr key={r.code} className="border-t hover:bg-muted/40">
                  <td className="px-2 py-1.5 font-mono">{r.code}</td>
                  <td className="px-2 py-1.5">{r.name || "—"}</td>
                  <td className="px-2 py-1.5">{r.zone}</td>
                  <td className="px-2 py-1.5">
                    {r.agentName ? `${r.agent} · ${r.agentName}` : r.agent}
                  </td>
                  <td className="px-2 py-1.5">{fmtDate(r.activatedAt)}</td>
                  <td className="px-2 py-1.5">
                    {r.vdcAttivo ? <Badge variant="secondary">VdC</Badge> : "—"}
                  </td>
                  <td className="px-2 py-1.5">
                    {r.vdcOrdini ? <Badge variant="secondary">Sì</Badge> : "—"}
                  </td>
                  <td className="px-2 py-1.5 text-right tabular-nums">{r.ordiniCliente}</td>
                  <td className="px-2 py-1.5 text-right tabular-nums">{r.ordiniAgente}</td>
                  <td className="px-2 py-1.5">{fmtDate(r.ultimoOrdineCliente)}</td>
                  <td className="px-2 py-1.5">{fmtDate(r.ultimoOrdineAgente)}</td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={COLUMNS.length} className="px-2 py-6 text-center text-muted-foreground">
                    Nessun cliente
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </DialogContent>
    </Dialog>
  );
}

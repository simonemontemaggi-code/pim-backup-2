import { useMemo, useState } from "react";
import { Loader2, Search, Inbox, Check, X, ArrowUp, ArrowDown, ArrowUpDown } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  useSelfOnboardingList,
  useSelfOnboardingPendingCount,
  type SelfOnboardingRequest,
  type SelfOnboardingStatus,
} from "@/hooks/useSelfOnboardingRequests";
import SelfOnboardingRequestDrawer from "./SelfOnboardingRequestDrawer";

function fmtDate(iso: string) {
  try {
    return new Date(iso).toLocaleString("it-IT", { dateStyle: "short", timeStyle: "short" });
  } catch {
    return iso;
  }
}

function ConsentIcon({ ok, title }: { ok: boolean | null | undefined; title: string }) {
  return ok ? (
    <Check className="h-3.5 w-3.5 text-green-600" aria-label={title}>
      <title>{title} · sì</title>
    </Check>
  ) : (
    <X className="h-3.5 w-3.5 text-muted-foreground/40" aria-label={title}>
      <title>{title} · no</title>
    </X>
  );
}

type SortKey = "ragione_sociale" | "partita_iva" | "citta" | "codice_ateco" | "created_at";
type SortDir = "asc" | "desc";

function SortHeader({
  label,
  colKey,
  sort,
  setSort,
  className,
}: {
  label: string;
  colKey: SortKey;
  sort: { key: SortKey; dir: SortDir };
  setSort: (s: { key: SortKey; dir: SortDir }) => void;
  className?: string;
}) {
  const active = sort.key === colKey;
  const Icon = !active ? ArrowUpDown : sort.dir === "asc" ? ArrowUp : ArrowDown;
  return (
    <th className={`text-left px-3 py-2 font-medium ${className ?? ""}`}>
      <button
        type="button"
        className="inline-flex items-center gap-1 hover:text-foreground"
        onClick={() =>
          setSort({
            key: colKey,
            dir: active && sort.dir === "asc" ? "desc" : "asc",
          })
        }
      >
        {label}
        <Icon className="h-3 w-3 opacity-60" />
      </button>
    </th>
  );
}

function RequestsTable({
  status,
  search,
  onPick,
}: {
  status: SelfOnboardingStatus;
  search: string;
  onPick: (r: SelfOnboardingRequest) => void;
}) {
  const { data, isLoading } = useSelfOnboardingList(status);
  const [sort, setSort] = useState<{ key: SortKey; dir: SortDir }>({
    key: "created_at",
    dir: "desc",
  });

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const rows = data ?? [];
    const searched = !q
      ? rows
      : rows.filter((r) =>
          [
            r.ragione_sociale,
            r.partita_iva,
            r.email_aziendale,
            r.telefono,
            r.codice_ateco,
            r.descrizione_ateco,
          ]
            .filter(Boolean)
            .some((v) => (v as string).toLowerCase().includes(q)),
        );
    const sorted = [...searched].sort((a, b) => {
      const va = (a as any)[sort.key] ?? "";
      const vb = (b as any)[sort.key] ?? "";
      if (sort.key === "created_at") {
        const da = new Date(va || 0).getTime();
        const db = new Date(vb || 0).getTime();
        return sort.dir === "asc" ? da - db : db - da;
      }
      const cmp = String(va).localeCompare(String(vb), "it", { sensitivity: "base" });
      return sort.dir === "asc" ? cmp : -cmp;
    });
    return sorted;
  }, [data, search, sort]);

  const emptyLabel =
    status === "pending"
      ? "Nessuna richiesta in attesa"
      : status === "reviewing"
        ? "Nessuna richiesta in revisione"
        : status === "approved"
          ? "Nessuna richiesta approvata"
          : "Nessuna richiesta respinta";

  return (
    <div className="rounded-lg border bg-card overflow-hidden">
      <TooltipProvider>
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <SortHeader label="Ragione Sociale" colKey="ragione_sociale" sort={sort} setSort={setSort} />
              <SortHeader label="P.IVA" colKey="partita_iva" sort={sort} setSort={setSort} />
              <th className="text-left px-3 py-2 font-medium">Email</th>
              <SortHeader label="Città (Prov)" colKey="citta" sort={sort} setSort={setSort} />
              <SortHeader label="ATECO" colKey="codice_ateco" sort={sort} setSort={setSort} />
              <th className="text-left px-3 py-2 font-medium">Consensi</th>
              <SortHeader label="Inviata il" colKey="created_at" sort={sort} setSort={setSort} />
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan={7} className="text-center py-12 text-muted-foreground">
                  <Loader2 className="h-5 w-5 animate-spin inline" />
                </td>
              </tr>
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={7} className="text-center py-12 text-muted-foreground">
                  <Inbox className="h-6 w-6 mx-auto mb-2 opacity-50" />
                  {emptyLabel}
                </td>
              </tr>
            ) : (
              filtered.map((r) => (
                <tr
                  key={r.id}
                  onClick={() => onPick(r)}
                  className="border-t hover:bg-muted/30 cursor-pointer"
                >
                  <td className="px-3 py-2 font-medium">{r.ragione_sociale ?? "—"}</td>
                  <td className="px-3 py-2 font-mono text-xs">{r.partita_iva ?? "—"}</td>
                  <td className="px-3 py-2 text-xs">{r.email_aziendale ?? "—"}</td>
                  <td className="px-3 py-2">
                    {r.citta ?? "—"}
                    {r.provincia ? ` (${r.provincia})` : ""}
                  </td>
                  <td className="px-3 py-2">
                    {r.codice_ateco ? (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span className="font-mono text-xs">{r.codice_ateco}</span>
                        </TooltipTrigger>
                        {r.descrizione_ateco && (
                          <TooltipContent className="max-w-xs">{r.descrizione_ateco}</TooltipContent>
                        )}
                      </Tooltip>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex items-center gap-1.5">
                      <ConsentIcon ok={r.consenso_privacy} title="Privacy" />
                      <ConsentIcon ok={r.consenso_termini} title="Condizioni di Vendita" />
                      <ConsentIcon ok={r.consenso_clausole} title="Clausole restrittive" />
                      <ConsentIcon ok={r.marketing_newsletter} title="Newsletter" />
                    </div>
                  </td>
                  <td className="px-3 py-2 text-xs">{fmtDate(r.created_at)}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </TooltipProvider>
    </div>
  );
}


export default function SelfOnboardingRequestsTab() {
  const [tab, setTab] = useState<SelfOnboardingStatus>("pending");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<SelfOnboardingRequest | null>(null);
  const { data: pendingCount = 0 } = useSelfOnboardingPendingCount();

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cerca per ragione sociale, P.IVA, email, telefono o ATECO…"
            className="pl-9"
          />
        </div>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as SelfOnboardingStatus)}>
        <TabsList>
          <TabsTrigger value="pending" className="gap-2">
            In attesa
            {pendingCount > 0 && (
              <Badge className="bg-warning/15 text-warning border-warning/30 hover:bg-warning/20 h-5 px-1.5">
                {pendingCount}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="reviewing">In revisione</TabsTrigger>
          <TabsTrigger value="approved">Approvate</TabsTrigger>
          <TabsTrigger value="rejected">Respinte</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="mt-3">
          <RequestsTable status="pending" search={search} onPick={setSelected} />
        </TabsContent>
        <TabsContent value="reviewing" className="mt-3">
          <RequestsTable status="reviewing" search={search} onPick={setSelected} />
        </TabsContent>
        <TabsContent value="approved" className="mt-3">
          <RequestsTable status="approved" search={search} onPick={setSelected} />
        </TabsContent>
        <TabsContent value="rejected" className="mt-3">
          <RequestsTable status="rejected" search={search} onPick={setSelected} />
        </TabsContent>
      </Tabs>

      <SelfOnboardingRequestDrawer request={selected} onOpenChange={(v) => !v && setSelected(null)} />
    </div>
  );
}

import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useRejectCustomerRequest } from "@/hooks/useCustomerRequestMutations";
import type { CustomerRequest } from "@/hooks/useCustomerRequests";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  request: CustomerRequest;
  onSuccess?: () => void;
}

export default function RejectRequestDialog({ open, onOpenChange, request, onSuccess }: Props) {
  const [reason, setReason] = useState("");
  const reject = useRejectCustomerRequest();
  const canSubmit = reason.trim().length >= 5 && !reject.isPending;

  const submit = async () => {
    if (!canSubmit) return;
    await reject.mutateAsync({ id: request.id, rejection_reason: reason.trim() });
    setReason("");
    onOpenChange(false);
    onSuccess?.();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Respingi richiesta</DialogTitle>
          <DialogDescription>
            Indica la motivazione: verrà mostrata all'agente che ha inviato la scheda.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-1.5 py-2">
          <Label htmlFor="reason">Motivazione</Label>
          <Textarea
            id="reason"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            rows={5}
            placeholder="es. P.IVA non valida, cliente già esistente con codice…"
          />
          <p className="text-xs text-muted-foreground">Minimo 5 caratteri.</p>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={reject.isPending}>
            Annulla
          </Button>
          <Button variant="destructive" onClick={submit} disabled={!canSubmit}>
            {reject.isPending ? "Salvataggio…" : "Respingi"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

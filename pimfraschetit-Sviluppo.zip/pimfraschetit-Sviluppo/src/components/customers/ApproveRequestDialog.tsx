import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useApproveCustomerRequest } from "@/hooks/useCustomerRequestMutations";
import type { CustomerRequest } from "@/hooks/useCustomerRequests";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  request: CustomerRequest;
  onSuccess?: () => void;
}

const CODE_RE = /^[A-Z0-9]{4,6}$/i;

// Listini "base" disponibili (allineati a BASE_LISTINI in src/lib/promoListini.ts)
const BASE_LISTINI = ["01", "02", "03", "04", "05", "06", "07", "10", "11", "12", "20", "51", "71"];
const PRIORITY = ["01", "10", "11", "12"];

export default function ApproveRequestDialog({ open, onOpenChange, request, onSuccess }: Props) {
  const [code, setCode] = useState("");
  const [zona, setZona] = useState(request.zona ?? "");
  const [priceList, setPriceList] = useState<string>("");
  const [notes, setNotes] = useState("");
  const approve = useApproveCustomerRequest();

  const { data: listini = [] } = useQuery({
    queryKey: ["approve_dialog_listini"],
    staleTime: 5 * 60 * 1000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("listini_vendita_testate")
        .select("cdlst, dslst")
        .in("cdlst", BASE_LISTINI);
      if (error) throw error;
      return (data ?? []).map((r: any) => ({ cdlst: r.cdlst, dslst: (r.dslst ?? "").trim() }));
    },
  });

  const orderedListini = useMemo(() => {
    const map = new Map(listini.map((l) => [l.cdlst, l.dslst]));
    const priority = PRIORITY.filter((c) => map.has(c)).map((c) => ({ cdlst: c, dslst: map.get(c)! }));
    const rest = listini
      .filter((l) => !PRIORITY.includes(l.cdlst))
      .sort((a, b) => a.cdlst.localeCompare(b.cdlst));
    return [...priority, ...rest];
  }, [listini]);

  const codeValid = CODE_RE.test(code.trim());
  const canSubmit = codeValid && !!priceList && !approve.isPending;

  const submit = async () => {
    if (!canSubmit) return;
    const raw = code.trim().toUpperCase();
    await approve.mutateAsync({
      id: request.id,
      assigned_customer_code: raw,
      assigned_zona: zona.trim() || null,
      assigned_price_list: priceList,
      review_notes: notes.trim() || null,
    });
    setCode("");
    setPriceList("");
    setNotes("");
    onOpenChange(false);
    onSuccess?.();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Conferma codifica cliente</DialogTitle>
          <DialogDescription>
            Assegna il codice AS400 a <strong>{request.ragione_sociale}</strong>.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="space-y-1.5">
            <Label htmlFor="code">Codice Cliente (4-6 caratteri)</Label>
            <Input
              id="code"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="es. 12345"
              maxLength={6}
              className="font-mono uppercase"
            />
            {code && !codeValid && (
              <p className="text-xs text-destructive">Formato non valido: 4-6 caratteri alfanumerici.</p>
            )}
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="listino">
              Listino <span className="text-destructive">*</span>
            </Label>
            <Select value={priceList} onValueChange={setPriceList}>
              <SelectTrigger id="listino">
                <SelectValue placeholder="Seleziona listino" />
              </SelectTrigger>
              <SelectContent>
                {orderedListini.map((l) => (
                  <SelectItem key={l.cdlst} value={l.cdlst}>
                    <span className="font-mono mr-2">{l.cdlst}</span>
                    {l.dslst}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="zona">Zona</Label>
            <Input id="zona" value={zona} onChange={(e) => setZona(e.target.value)} />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="notes">Note interne (opzionali)</Label>
            <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={approve.isPending}>
            Annulla
          </Button>
          <Button onClick={submit} disabled={!canSubmit}>
            {approve.isPending ? "Salvataggio…" : "Conferma codifica"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

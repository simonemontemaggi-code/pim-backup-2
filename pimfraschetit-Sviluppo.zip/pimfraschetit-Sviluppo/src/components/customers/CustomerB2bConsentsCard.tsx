import { Check, X, ShieldCheck, Info, Mail, Phone, Clock } from "lucide-react";

export interface B2bConsents {
  gdpr_consent?: boolean | null; // deprecato — ignorato
  product_updates?: boolean | null; // deprecato — ignorato
  newsletter_subscribed: boolean | null;
  terms_accepted_at?: string | null;
  marketing_consent_at?: string | null;
  marketing_consent_source?: string | null;
}

export interface B2bAccess {
  phone_number: string | null;
  phone_set_at: string | null;
}

function formatDate(iso?: string | null) {
  if (!iso) return null;
  try {
    return new Date(iso).toLocaleString("it-IT");
  } catch {
    return null;
  }
}

function sourceLabel(src?: string | null) {
  if (!src) return null;
  if (src === "signup") return "primo accesso";
  if (src === "account") return "area personale";
  return src;
}

export function CustomerB2bConsentsCard({
  authUserId,
  consents,
  access,
}: {
  authUserId: string | null;
  consents: B2bConsents | null | undefined;
  access?: B2bAccess | null;
}) {
  const notRegistered = !authUserId;
  const termsAt = formatDate(consents?.terms_accepted_at);
  const marketingAt = formatDate(consents?.marketing_consent_at);
  const marketingSrc = sourceLabel(consents?.marketing_consent_source);
  const phoneSetAt = formatDate(access?.phone_set_at);
  const newsletterOn = consents?.newsletter_subscribed === true;

  return (
    <div className="rounded-lg border bg-card p-4 space-y-3">
      <div className="flex items-center gap-2">
        <ShieldCheck className="h-4 w-4 text-primary" />
        <h3 className="text-sm font-semibold">Privacy & Consensi B2B</h3>
      </div>

      {notRegistered ? (
        <div className="flex items-start gap-2 rounded-md border border-dashed bg-muted/30 p-3 text-xs text-muted-foreground">
          <Info className="h-4 w-4 mt-0.5 shrink-0" />
          <div>Cliente non ancora registrato al portale B2B — nessun consenso disponibile.</div>
        </div>
      ) : (
        <div className="space-y-2">
          {/* Accettazione contratti */}
          <div className="flex items-start justify-between gap-3 rounded-md border bg-background/50 p-3">
            <div className="min-w-0">
              <div className="text-sm font-medium">Accettazione contratti</div>
              <div className="text-xs text-muted-foreground mt-0.5">
                Condizioni di Vendita + Privacy Policy (obbligatori al primo accesso).
              </div>
              {termsAt && (
                <div className="text-[11px] text-muted-foreground mt-1 flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  Accettati il <span className="font-mono">{termsAt}</span>
                </div>
              )}
            </div>
            {termsAt ? (
              <div className="flex items-center gap-1 shrink-0 rounded-full px-2 py-0.5 text-xs font-medium bg-green-100 text-green-800 dark:bg-green-950/40 dark:text-green-300">
                <Check className="h-3 w-3" />
                Accettati
              </div>
            ) : (
              <div className="flex items-center gap-1 shrink-0 rounded-full px-2 py-0.5 text-xs font-medium bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-300">
                <X className="h-3 w-3" />
                In attesa primo accesso
              </div>
            )}
          </div>

          {/* Newsletter */}
          <div className="flex items-start justify-between gap-3 rounded-md border bg-background/50 p-3">
            <div className="min-w-0">
              <div className="text-sm font-medium flex items-center gap-1.5">
                <Mail className="h-3.5 w-3.5 text-muted-foreground" />
                Newsletter commerciale
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">
                Comunicazioni promozionali e novità di catalogo.
              </div>
              {marketingAt && (
                <div className="text-[11px] text-muted-foreground mt-1 flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  Ultimo aggiornamento: <span className="font-mono">{marketingAt}</span>
                  {marketingSrc && <span className="italic"> · via {marketingSrc}</span>}
                </div>
              )}
            </div>
            <div
              className={`flex items-center gap-1 shrink-0 rounded-full px-2 py-0.5 text-xs font-medium ${
                newsletterOn
                  ? "bg-green-100 text-green-800 dark:bg-green-950/40 dark:text-green-300"
                  : "bg-muted text-muted-foreground"
              }`}
            >
              {newsletterOn ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
              {newsletterOn ? "Iscritto" : "Non iscritto"}
            </div>
          </div>

          {/* Cellulare */}
          <div className="flex items-start justify-between gap-3 rounded-md border bg-background/50 p-3">
            <div className="min-w-0">
              <div className="text-sm font-medium flex items-center gap-1.5">
                <Phone className="h-3.5 w-3.5 text-muted-foreground" />
                Cellulare verificato
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">
                Numero raccolto al primo accesso al portale.
              </div>
              {phoneSetAt && (
                <div className="text-[11px] text-muted-foreground mt-1 flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  Impostato il <span className="font-mono">{phoneSetAt}</span>
                </div>
              )}
            </div>
            <div className="shrink-0 text-xs font-mono">
              {access?.phone_number ?? <span className="text-muted-foreground italic">Non fornito</span>}
            </div>
          </div>
        </div>
      )}

      <p className="text-[11px] text-muted-foreground italic">
        Consensi gestiti dal cliente nel portale B2B. Modificabili solo dal cliente stesso.
      </p>
    </div>
  );
}

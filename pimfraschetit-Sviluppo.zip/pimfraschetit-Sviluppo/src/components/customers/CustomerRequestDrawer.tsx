import { useState } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Check, X, RotateCcw, Printer } from "lucide-react";
import { printCustomerRequest } from "@/lib/printRequestPdf";
import { usePermissions } from "@/lib/permissions";
import type { CustomerRequest } from "@/hooks/useCustomerRequests";
import ApproveRequestDialog from "./ApproveRequestDialog";
import RejectRequestDialog from "./RejectRequestDialog";
import ReopenRequestDialog from "./ReopenRequestDialog";

interface Props {
  request: CustomerRequest | null;
  onOpenChange: (v: boolean) => void;
}

function StatusBadge({ status }: { status: CustomerRequest["status"] }) {
  if (status === "pending")
    return <Badge className="bg-warning/15 text-warning hover:bg-warning/20 border-warning/30">In attesa</Badge>;
  if (status === "approved")
    return <Badge className="bg-success/15 text-success hover:bg-success/20 border-success/30">Confermata</Badge>;
  return <Badge className="bg-destructive/15 text-destructive hover:bg-destructive/20 border-destructive/30">Respinta</Badge>;
}

function Field({ label, value, fullWidth }: { label: string; value: string | null | undefined; fullWidth?: boolean }) {
  return (
    <div className={`space-y-0.5${fullWidth ? " col-span-2" : ""}`}>
      <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="text-sm whitespace-pre-wrap break-words">{value && value.trim() ? value : <span className="text-muted-foreground">—</span>}</div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <h3 className="text-sm font-semibold text-foreground/80">{title}</h3>
      <div className="grid grid-cols-2 gap-3 rounded-md border bg-card p-3">{children}</div>
    </div>
  );
}

function fmtDate(iso: string | null | undefined) {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString("it-IT", { dateStyle: "medium", timeStyle: "short" });
  } catch {
    return iso;
  }
}

export default function CustomerRequestDrawer({ request, onOpenChange }: Props) {
  const { can } = usePermissions();
  const canWrite = can("write", "customer_requests");
  const [approveOpen, setApproveOpen] = useState(false);
  const [rejectOpen, setRejectOpen] = useState(false);
  const [reopenOpen, setReopenOpen] = useState(false);

  if (!request) return null;
  const isPending = request.status === "pending";

  return (
    <>
      <Sheet open={!!request} onOpenChange={onOpenChange}>
        <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <div className="flex items-center gap-2">
              <SheetTitle className="flex-1">{request.ragione_sociale ?? "Senza nome"}</SheetTitle>
              <StatusBadge status={request.status} />
            </div>
            <SheetDescription>
              Inviata il {fmtDate(request.created_at)} da {request.agent_name ?? request.agent_code ?? "—"}
            </SheetDescription>
          </SheetHeader>

          <div className="space-y-5 mt-5">
            <Section title="Anagrafica">
              <Field label="Ragione Sociale" value={request.ragione_sociale} />
              <Field label="P.IVA" value={request.partita_iva} />
              <Field label="Codice Fiscale" value={request.codice_fiscale} />
              <Field label="Categoria" value={request.categoria} />
            </Section>

            <Section title="Indirizzo">
              <Field label="Indirizzo" value={request.indirizzo} />
              <Field label="CAP" value={request.cap} />
              <Field label="Città" value={request.citta} />
              <Field label="Provincia" value={request.provincia} />
              <Field label="Zona" value={request.zona} />
              <Field label="Diversa destinazione" value={request.diversa_destinazione} />
            </Section>

            <Section title="Contatti & Referente">
              <Field label="Telefono Negozio" value={request.telefono_negozio} />
              <Field label="Email" value={request.email} />
              <Field label="PEC" value={request.pec} />
              <Field label="Codice SDI" value={request.codice_sdi} />
              <Field label="Nome Referente" value={request.nome_referente} />
              <Field label="Cellulare Referente" value={request.cellulare_referente} />
            </Section>

            <Section title="Informazioni Commerciali">
              <Field label="Importanza" value={request.importanza} />
              <Field label="Giorno Visita" value={request.giorno_visita} />
              <Field label="Frequenza Visite" value={request.frequenza_visite} />
              <Field label="Giorno Chiusura" value={request.giorno_chiusura} />
              <Field label="Grossisti Concorrenti" value={request.grossisti_concorrenti} />
              <Field label="Fornitori Presenti" value={request.fornitori_presenti} />
              <Field label="Vendite Online" value={request.vendite_online} />
              <Field label="Presenza PC" value={request.presenza_pc} />
              <Field label="Note Scarico" value={request.note_scarico} />
              <Field label="Note Varie" value={request.note_varie} />
            </Section>

            <Section title="Pagamento & Bancari">
              <Field label="Modalità Pagamento" value={request.modalita_pagamento} />
              <Field label="Modalità (altro)" value={request.modalita_altro} />
              <Field label="Descrizione Pagamento" value={request.descrizione_pagamento} fullWidth />
              <Field label="Banca" value={request.banca} />
              <Field label="Filiale" value={request.filiale} />
              <Field label="IBAN" value={request.iban} />
            </Section>

            <Section title="Agente">
              <Field label="Nome" value={request.agent_name} />
              <Field label="Codice Agente" value={request.agent_code} />
              <Field label="Email" value={request.agent_email} />
            </Section>

            {!isPending && (
              <>
                <Separator />
                <Section title="Esito">
                  <Field label="Gestita il" value={fmtDate(request.reviewed_at)} />
                  <Field label="Gestita da (user id)" value={request.reviewed_by} />
                  {request.status === "approved" ? (
                    <>
                      <Field label="Codice Cliente assegnato" value={request.assigned_customer_code} />
                      <Field label="Zona assegnata" value={request.assigned_zona} />
                      <Field label="Listino assegnato" value={request.assigned_price_list} />
                      <div className="col-span-2">
                        <Field label="Note interne" value={request.review_notes} />
                      </div>
                    </>
                  ) : (
                    <div className="col-span-2">
                      <Field label="Motivazione" value={request.rejection_reason} />
                    </div>
                  )}
                </Section>
              </>
            )}

            <div className="flex justify-end gap-2 pt-2 pb-6">
              <Button variant="outline" onClick={() => printCustomerRequest(request)}>
                <Printer className="h-4 w-4 mr-1" /> Stampa PDF
              </Button>
              {isPending && canWrite && (
                <>
                  <Button variant="outline" onClick={() => setRejectOpen(true)}>
                    <X className="h-4 w-4 mr-1" /> Respingi
                  </Button>
                  <Button onClick={() => setApproveOpen(true)}>
                    <Check className="h-4 w-4 mr-1" /> Conferma codifica
                  </Button>
                </>
              )}
              {!isPending && canWrite && (
                <Button variant="outline" onClick={() => setReopenOpen(true)}>
                  <RotateCcw className="h-4 w-4 mr-1" /> Riapri
                </Button>
              )}
            </div>
          </div>
        </SheetContent>
      </Sheet>

      {isPending && (
        <>
          <ApproveRequestDialog
            open={approveOpen}
            onOpenChange={setApproveOpen}
            request={request}
            onSuccess={() => onOpenChange(false)}
          />
          <RejectRequestDialog
            open={rejectOpen}
            onOpenChange={setRejectOpen}
            request={request}
            onSuccess={() => onOpenChange(false)}
          />
        </>
      )}
      {!isPending && (
        <ReopenRequestDialog
          open={reopenOpen}
          onOpenChange={setReopenOpen}
          requestId={request.id}
          onSuccess={() => onOpenChange(false)}
        />
      )}
    </>
  );
}

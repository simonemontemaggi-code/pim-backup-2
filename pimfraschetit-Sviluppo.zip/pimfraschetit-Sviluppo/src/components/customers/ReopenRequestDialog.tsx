import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useReopenCustomerRequest } from "@/hooks/useCustomerRequestMutations";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  requestId: string;
  onSuccess?: () => void;
}

export default function ReopenRequestDialog({ open, onOpenChange, requestId, onSuccess }: Props) {
  const reopen = useReopenCustomerRequest();
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Riaprire la richiesta?</AlertDialogTitle>
          <AlertDialogDescription>
            Lo stato tornerà a "In attesa" e verranno cancellati codice assegnato, zona e motivazioni.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={reopen.isPending}>Annulla</AlertDialogCancel>
          <AlertDialogAction
            onClick={async (e) => {
              e.preventDefault();
              await reopen.mutateAsync(requestId);
              onOpenChange(false);
              onSuccess?.();
            }}
          >
            Riapri
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

import { useMemo, useState } from "react";
import { Loader2, Search, Inbox } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  useCustomerRequestsList,
  useCustomerRequestsPendingCount,
  type CustomerRequest,
  type CustomerRequestStatus,
} from "@/hooks/useCustomerRequests";
import CustomerRequestDrawer from "./CustomerRequestDrawer";

function fmtDate(iso: string) {
  try {
    return new Date(iso).toLocaleString("it-IT", { dateStyle: "short", timeStyle: "short" });
  } catch {
    return iso;
  }
}

function RequestsTable({
  status,
  search,
  onPick,
}: {
  status: CustomerRequestStatus;
  search: string;
  onPick: (r: CustomerRequest) => void;
}) {
  const { data, isLoading } = useCustomerRequestsList(status);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const rows = data ?? [];
    if (!q) return rows;
    return rows.filter((r) =>
      [r.ragione_sociale, r.partita_iva, r.agent_name, r.agent_code]
        .filter(Boolean)
        .some((v) => (v as string).toLowerCase().includes(q)),
    );
  }, [data, search]);

  const emptyLabel =
    status === "pending"
      ? "Nessuna richiesta in attesa"
      : status === "approved"
        ? "Nessuna richiesta confermata"
        : "Nessuna richiesta respinta";

  return (
    <div className="rounded-lg border bg-card overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
          <tr>
            <th className="text-left px-3 py-2 font-medium">Ragione Sociale</th>
            <th className="text-left px-3 py-2 font-medium">P.IVA</th>
            <th className="text-left px-3 py-2 font-medium">Città (Prov)</th>
            <th className="text-left px-3 py-2 font-medium">Agente</th>
            <th className="text-left px-3 py-2 font-medium">Inviata il</th>
            {status !== "pending" && (
              <th className="text-left px-3 py-2 font-medium">
                {status === "approved" ? "Codice assegnato" : "Motivazione"}
              </th>
            )}
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            <tr>
              <td colSpan={6} className="text-center py-12 text-muted-foreground">
                <Loader2 className="h-5 w-5 animate-spin inline" />
              </td>
            </tr>
          ) : filtered.length === 0 ? (
            <tr>
              <td colSpan={6} className="text-center py-12 text-muted-foreground">
                <Inbox className="h-6 w-6 mx-auto mb-2 opacity-50" />
                {emptyLabel}
              </td>
            </tr>
          ) : (
            filtered.map((r) => (
              <tr
                key={r.id}
                onClick={() => onPick(r)}
                className="border-t hover:bg-muted/30 cursor-pointer"
              >
                <td className="px-3 py-2 font-medium">{r.ragione_sociale ?? "—"}</td>
                <td className="px-3 py-2 font-mono text-xs">{r.partita_iva ?? "—"}</td>
                <td className="px-3 py-2">
                  {r.citta ?? "—"}
                  {r.provincia ? ` (${r.provincia})` : ""}
                </td>
                <td className="px-3 py-2 text-xs">
                  {r.agent_name ?? "—"}
                  {r.agent_code ? <span className="text-muted-foreground"> · {r.agent_code}</span> : null}
                </td>
                <td className="px-3 py-2 text-xs">{fmtDate(r.created_at)}</td>
                {status === "approved" && (
                  <td className="px-3 py-2 font-mono text-xs">{r.assigned_customer_code ?? "—"}</td>
                )}
                {status === "rejected" && (
                  <td className="px-3 py-2 text-xs max-w-[280px] truncate" title={r.rejection_reason ?? ""}>
                    {r.rejection_reason ?? "—"}
                  </td>
                )}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default function CustomerRequestsTab() {
  const [tab, setTab] = useState<CustomerRequestStatus>("pending");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<CustomerRequest | null>(null);
  const { data: pendingCount = 0 } = useCustomerRequestsPendingCount();

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cerca per ragione sociale, P.IVA o agente…"
            className="pl-9"
          />
        </div>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as CustomerRequestStatus)}>
        <TabsList>
          <TabsTrigger value="pending" className="gap-2">
            In attesa
            {pendingCount > 0 && (
              <Badge className="bg-warning/15 text-warning border-warning/30 hover:bg-warning/20 h-5 px-1.5">
                {pendingCount}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="approved">Confermati</TabsTrigger>
          <TabsTrigger value="rejected">Respinti</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="mt-3">
          <RequestsTable status="pending" search={search} onPick={setSelected} />
        </TabsContent>
        <TabsContent value="approved" className="mt-3">
          <RequestsTable status="approved" search={search} onPick={setSelected} />
        </TabsContent>
        <TabsContent value="rejected" className="mt-3">
          <RequestsTable status="rejected" search={search} onPick={setSelected} />
        </TabsContent>
      </Tabs>

      <CustomerRequestDrawer request={selected} onOpenChange={(v) => !v && setSelected(null)} />
    </div>
  );
}

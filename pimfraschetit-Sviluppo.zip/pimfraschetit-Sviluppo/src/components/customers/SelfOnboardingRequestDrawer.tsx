import { useState } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Check, X, Eye, Loader2, Printer, Trash2 } from "lucide-react";
import { printSelfOnboardingRequest } from "@/lib/printRequestPdf";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { usePermissions } from "@/lib/permissions";
import { useAuth } from "@/contexts/AuthContext";
import {
  useUpdateSelfOnboardingStatus,
  useDeleteSelfOnboardingRequest,
  type SelfOnboardingRequest,
  type SelfOnboardingStatus,
} from "@/hooks/useSelfOnboardingRequests";

interface Props {
  request: SelfOnboardingRequest | null;
  onOpenChange: (v: boolean) => void;
}

function StatusBadge({ status }: { status: SelfOnboardingStatus }) {
  if (status === "pending" || (status as string) === "new")
    return <Badge className="bg-warning/15 text-warning hover:bg-warning/20 border-warning/30">In attesa</Badge>;
  if (status === "reviewing")
    return <Badge className="bg-primary/15 text-primary hover:bg-primary/20 border-primary/30">In revisione</Badge>;
  if (status === "approved")
    return <Badge className="bg-success/15 text-success hover:bg-success/20 border-success/30">Approvata</Badge>;
  return <Badge className="bg-destructive/15 text-destructive hover:bg-destructive/20 border-destructive/30">Respinta</Badge>;
}

function Field({ label, value, fullWidth }: { label: string; value: string | null | undefined; fullWidth?: boolean }) {
  return (
    <div className={`space-y-0.5${fullWidth ? " col-span-2" : ""}`}>
      <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="text-sm whitespace-pre-wrap break-words">
        {value && String(value).trim() ? value : <span className="text-muted-foreground">—</span>}
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <h3 className="text-sm font-semibold text-foreground/80">{title}</h3>
      <div className="grid grid-cols-2 gap-3 rounded-md border bg-card p-3">{children}</div>
    </div>
  );
}

function ConsentBadge({ label, ok }: { label: string; ok: boolean | null | undefined }) {
  return (
    <Badge
      variant="outline"
      className={
        ok
          ? "bg-success/10 text-success border-success/30"
          : "bg-muted text-muted-foreground border-muted-foreground/20"
      }
    >
      {ok ? <Check className="h-3 w-3 mr-1" /> : <X className="h-3 w-3 mr-1" />}
      {label}
    </Badge>
  );
}

function fmtDate(iso: string | null | undefined) {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString("it-IT", { dateStyle: "medium", timeStyle: "short" });
  } catch {
    return iso;
  }
}

export default function SelfOnboardingRequestDrawer({ request, onOpenChange }: Props) {
  const { can } = usePermissions();
  const { role } = useAuth();
  const isAdmin = role === "admin";
  const canWrite = can("write", "customers");
  const mutation = useUpdateSelfOnboardingStatus();
  const deleteMutation = useDeleteSelfOnboardingRequest();
  const [confirm, setConfirm] = useState<null | SelfOnboardingStatus>(null);
  const [deleteOpen, setDeleteOpen] = useState(false);

  if (!request) return null;
  const isPending = request.status === "pending" || (request.status as string) === "new";
  const isReviewing = request.status === "reviewing";

  const handleConfirm = () => {
    if (!confirm) return;
    mutation.mutate(
      { id: request.id, status: confirm },
      {
        onSuccess: () => {
          setConfirm(null);
          onOpenChange(false);
        },
      },
    );
  };

  const confirmCopy =
    confirm === "approved"
      ? {
          title: "Approvare la richiesta?",
          desc: "Lo status passerà ad 'approved'. La codifica del cliente in AS400 va poi completata manualmente.",
          cta: "Approva",
        }
      : confirm === "rejected"
        ? { title: "Respingere la richiesta?", desc: "Lo status passerà a 'rejected'.", cta: "Respingi" }
        : { title: "Mettere in revisione?", desc: "Lo status passerà a 'reviewing'.", cta: "In revisione" };

  return (
    <>
      <Sheet open={!!request} onOpenChange={onOpenChange}>
        <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <div className="flex items-center gap-2">
              <SheetTitle className="flex-1">{request.ragione_sociale ?? "Senza nome"}</SheetTitle>
              <StatusBadge status={request.status} />
            </div>
            <SheetDescription>Inviata il {fmtDate(request.created_at)}</SheetDescription>
          </SheetHeader>

          <div className="space-y-5 mt-5">
            <Section title="Azienda">
              <Field label="Ragione Sociale" value={request.ragione_sociale} />
              <Field label="P.IVA" value={request.partita_iva} />
              <Field label="Email aziendale" value={request.email_aziendale} />
              <Field
                label="Telefono"
                value={
                  request.telefono
                    ? `${request.prefisso_internazionale ?? ""} ${request.telefono}`.trim()
                    : null
                }
              />
              <Field label="PEC" value={request.pec} />
              <Field label="SDI" value={request.sdi} />
              <Field label="Tipologia" value={request.tipologia} />
              <Field label="Settore rivenditore" value={request.settore_rivenditore} />
              <Field label="Tipo (altro)" value={request.tipo_altro} />
              <Field label="Descrizione attività" value={request.descrizione_attivita} fullWidth />
              {request.codice_ateco && (
                <div className="space-y-0.5 col-span-2">
                  <div className="text-xs uppercase tracking-wide text-muted-foreground">Codice ATECO</div>
                  <div className="font-mono font-bold text-sm">{request.codice_ateco}</div>
                  {request.descrizione_ateco && (
                    <div className="text-xs text-muted-foreground">{request.descrizione_ateco}</div>
                  )}
                </div>
              )}
            </Section>

            <Section title="Referente">
              <Field label="Nome" value={request.nome} />
              <Field label="Cognome" value={request.cognome} />
            </Section>

            <Section title="Indirizzo">
              <Field label="Indirizzo" value={request.indirizzo} fullWidth />
              <Field label="Città" value={request.citta} />
              <Field label="Provincia" value={request.provincia} />
              <Field label="CAP" value={request.cap} />
            </Section>

            <Section title="Note admin">
              <Field label="Note" value={request.notes_admin} fullWidth />
            </Section>

            <div className="space-y-2">
              <h3 className="text-sm font-semibold text-foreground/80">Consensi</h3>
              <div className="flex flex-wrap gap-2 rounded-md border bg-card p-3">
                <ConsentBadge label="Privacy Policy" ok={request.consenso_privacy} />
                <ConsentBadge label="Condizioni di Vendita" ok={request.consenso_termini} />
                <ConsentBadge label="Clausole restrittive" ok={request.consenso_clausole} />
                <ConsentBadge label="Newsletter" ok={request.marketing_newsletter} />
                <ConsentBadge label="SMS" ok={request.marketing_sms} />
              </div>
            </div>

            {!isPending && (
              <>
                <Separator />
                <Section title="Esito">
                  <Field label="Gestita il" value={fmtDate(request.processed_at)} />
                  <Field label="Gestita da (user id)" value={request.processed_by} />
                </Section>
              </>
            )}

            {request.payload_json && (
              <details className="rounded-md border bg-muted/30 p-3">
                <summary className="text-sm font-semibold cursor-pointer text-foreground/80">
                  Payload B2B (JSON)
                </summary>
                <pre className="mt-2 text-xs overflow-x-auto whitespace-pre-wrap break-all">
                  {JSON.stringify(request.payload_json, null, 2)}
                </pre>
              </details>
            )}

            <div className="flex justify-end gap-2 pt-2 pb-6">
              <Button variant="outline" onClick={() => printSelfOnboardingRequest(request)}>
                <Printer className="h-4 w-4 mr-1" /> Stampa PDF
              </Button>
              {isAdmin && (
                <Button variant="destructive" onClick={() => setDeleteOpen(true)}>
                  <Trash2 className="h-4 w-4 mr-1" /> Elimina
                </Button>
              )}
              {canWrite && (isPending || isReviewing) && (
                <>
                  {isPending && (
                    <Button variant="outline" onClick={() => setConfirm("reviewing")}>
                      <Eye className="h-4 w-4 mr-1" /> In revisione
                    </Button>
                  )}
                  <Button variant="outline" onClick={() => setConfirm("rejected")}>
                    <X className="h-4 w-4 mr-1" /> Rifiuta
                  </Button>
                  <Button onClick={() => setConfirm("approved")}>
                    <Check className="h-4 w-4 mr-1" /> Approva
                  </Button>
                </>
              )}
            </div>
          </div>
        </SheetContent>
      </Sheet>

      <AlertDialog open={!!confirm} onOpenChange={(v) => !v && setConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{confirmCopy.title}</AlertDialogTitle>
            <AlertDialogDescription>{confirmCopy.desc}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={mutation.isPending}>Annulla</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirm} disabled={mutation.isPending}>
              {mutation.isPending && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
              {confirmCopy.cta}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={deleteOpen} onOpenChange={(v) => !v && setDeleteOpen(false)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminare la richiesta?</AlertDialogTitle>
            <AlertDialogDescription>
              L'azione è definitiva e non reversibile. La richiesta verrà rimossa dal database.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteMutation.isPending}>Annulla</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                deleteMutation.mutate(request.id, {
                  onSuccess: () => {
                    setDeleteOpen(false);
                    onOpenChange(false);
                  },
                });
              }}
              disabled={deleteMutation.isPending}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteMutation.isPending && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

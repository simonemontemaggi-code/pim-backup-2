import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";

export function ForceChangePasswordGate({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [checking, setChecking] = useState(true);
  const [mustChange, setMustChange] = useState(false);
  const [pwd, setPwd] = useState("");
  const [pwd2, setPwd2] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!user) {
      setChecking(false);
      return;
    }
    (async () => {
      const { data } = await (supabase as any)
        .from("department_sub_users")
        .select("id, must_change_password")
        .eq("sub_user_id", user.id)
        .maybeSingle();
      setMustChange(!!data?.must_change_password);
      setChecking(false);
    })();
  }, [user]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pwd.length < 6) {
      toast.error("Password troppo corta (min 6)");
      return;
    }
    if (pwd !== pwd2) {
      toast.error("Le password non coincidono");
      return;
    }
    setSubmitting(true);
    const { data, error } = await supabase.functions.invoke("sub-user-change-password", {
      body: { password: pwd },
    });
    setSubmitting(false);
    if (error || (data as any)?.error) {
      toast.error((data as any)?.error ?? error?.message ?? "Errore cambio password");
      return;
    }
    toast.success("Password aggiornata");
    setMustChange(false);
  };

  if (checking) return null;
  if (!mustChange) return <>{children}</>;

  return (
    <div className="flex min-h-screen items-center justify-center bg-sidebar">
      <Card className="w-full max-w-sm mx-4">
        <CardHeader className="text-center space-y-2">
          <CardTitle className="text-xl">Imposta una nuova password</CardTitle>
          <p className="text-sm text-muted-foreground">
            Al primo accesso devi scegliere una password personale.
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="new-pwd">Nuova password</Label>
              <Input id="new-pwd" type="password" required value={pwd} onChange={(e) => setPwd(e.target.value)} autoFocus />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-pwd-2">Conferma password</Label>
              <Input id="new-pwd-2" type="password" required value={pwd2} onChange={(e) => setPwd2(e.target.value)} />
            </div>
            <Button type="submit" className="w-full" disabled={submitting}>
              {submitting ? "Salvataggio..." : "Imposta password"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

import { Navigate } from "react-router-dom";
import { usePermissions } from "@/lib/permissions";
import type { SectionKey } from "@/contexts/AuthContext";

interface Props {
  section: SectionKey;
  redirectTo?: string;
  children: React.ReactNode;
}

export function SectionGuard({ section, redirectTo = "/pim/controls", children }: Props) {
  const { sectionVisible } = usePermissions();
  if (!sectionVisible(section)) return <Navigate to={redirectTo} replace />;
  return <>{children}</>;
}

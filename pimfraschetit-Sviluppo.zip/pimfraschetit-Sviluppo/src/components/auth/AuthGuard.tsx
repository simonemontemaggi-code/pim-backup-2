import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";
import { ForceChangePasswordGate } from "./ForceChangePasswordGate";

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const { session, profile, loading, role, permissions, signOut } = useAuth();
  const navigate = useNavigate();
  const [signingOut, setSigningOut] = useState(false);

  const handleSwitchAccount = async () => {
    if (signingOut) return;

    setSigningOut(true);
    try {
      await signOut();
      navigate("/login", { replace: true });
    } finally {
      setSigningOut(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="space-y-4 w-64">
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
        </div>
      </div>
    );
  }

  if (!session) return <Navigate to="/login" replace />;

  if (!profile) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold text-destructive">Accesso negato</h1>
          <p className="text-muted-foreground">Il tuo profilo non è stato trovato. Contatta il reparto IT.</p>
          <Button onClick={handleSwitchAccount} disabled={signingOut}>
            <LogOut className="h-4 w-4" />
            {signingOut ? "Disconnessione..." : "Esci e accedi con un altro account"}
          </Button>
        </div>
      </div>
    );
  }

  // Only PIM staff can access this app: customers/agents and users without any
  // section permission are blocked (the PIM is not their portal).
  const isStaff =
    role === "admin" ||
    (role !== "customer" &&
      role !== "agent" &&
      Object.values(permissions ?? {}).some((p) => p !== "hidden"));

  if (!isStaff) {
    return (
      <div className="flex h-screen items-center justify-center p-6">
        <div className="text-center space-y-4 max-w-md">
          <h1 className="text-2xl font-bold text-destructive">Accesso non autorizzato</h1>
          <p className="text-muted-foreground">
            Questo portale è riservato allo staff Fraschetti. Se sei un cliente o un agente, usa il portale
            dedicato. Per assistenza contatta il reparto IT.
          </p>
          <Button onClick={handleSwitchAccount} disabled={signingOut}>
            <LogOut className="h-4 w-4" />
            {signingOut ? "Disconnessione..." : "Esci e accedi con un altro account"}
          </Button>
        </div>
      </div>
    );
  }

  return <ForceChangePasswordGate>{children}</ForceChangePasswordGate>;
}


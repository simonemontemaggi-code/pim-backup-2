import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search, CheckCircle2, RotateCcw } from "lucide-react";
import { format } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";

type Row = {
  query: string; n: number; n_users: number; n_customers: number;
  last_seen: string; n_b2b: number; n_agent: number; resolved_at: string | null;
};

export function SearchMissesTable({ rows, hideResolved }: { rows: Row[]; hideResolved: boolean }) {
  const qc = useQueryClient();
  const { user } = useAuth();
  // Escludi rumore: query puramente numeriche e query testuali < 3 caratteri
  const isNoise = (q: string) => {
    const t = (q ?? "").trim();
    return /^[0-9]+$/.test(t) || t.length < 3;
  };
  const filtered = rows.filter((r) => !isNoise(r.query) && (!hideResolved || !r.resolved_at));

  const toggleResolved = async (r: Row) => {
    if (r.resolved_at) {
      const { error } = await supabase.from("search_miss_resolutions" as any).delete().eq("query", r.query);
      if (error) return toast.error(error.message);
      toast.success("Riaperta");
    } else {
      const { error } = await supabase.from("search_miss_resolutions" as any).upsert({
        query: r.query, resolved_by: user?.id,
      });
      if (error) return toast.error(error.message);
      toast.success("Marcata come gestita");
    }
    qc.invalidateQueries({ queryKey: ["nav-search-agg"] });
  };

  return (
    <div className="rounded-md border bg-card">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Query</TableHead>
            <TableHead className="text-right">Occorrenze</TableHead>
            <TableHead className="text-right">Utenti</TableHead>
            <TableHead className="text-right">Clienti</TableHead>
            <TableHead>Sorgente</TableHead>
            <TableHead>Ultima</TableHead>
            <TableHead className="text-right">Azioni</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filtered.length === 0 ? (
            <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-6">Nessun risultato.</TableCell></TableRow>
          ) : filtered.map((r) => (
            <TableRow key={r.query} className={r.resolved_at ? "opacity-60" : ""}>
              <TableCell className="font-mono text-xs">
                <div className="flex items-center gap-2">
                  <span>{r.query}</span>
                  {r.resolved_at && <Badge variant="secondary" className="text-[10px]">gestita</Badge>}
                </div>
              </TableCell>
              <TableCell className="text-right tabular-nums">{r.n}</TableCell>
              <TableCell className="text-right tabular-nums">{r.n_users}</TableCell>
              <TableCell className="text-right tabular-nums">{r.n_customers}</TableCell>
              <TableCell className="text-xs">
                {r.n_b2b > 0 && <Badge variant="outline" className="mr-1">B2B {r.n_b2b}</Badge>}
                {r.n_agent > 0 && <Badge variant="outline">Agent {r.n_agent}</Badge>}
              </TableCell>
              <TableCell className="text-xs text-muted-foreground">
                {r.last_seen ? format(new Date(r.last_seen), "dd/MM/yy HH:mm") : "—"}
              </TableCell>
              <TableCell className="text-right">
                <Button asChild size="sm" variant="ghost" title="Cerca in catalogo">
                  <Link to={`/pim/articles?search=${encodeURIComponent(r.query)}`}>
                    <Search className="h-4 w-4" />
                  </Link>
                </Button>
                <Button size="sm" variant="ghost" onClick={() => toggleResolved(r)}
                  title={r.resolved_at ? "Riapri" : "Marca come gestita"}>
                  {r.resolved_at ? <RotateCcw className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

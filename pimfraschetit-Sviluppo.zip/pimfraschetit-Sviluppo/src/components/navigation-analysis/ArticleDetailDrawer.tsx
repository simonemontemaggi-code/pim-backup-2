import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { useArticleTimeseries, useArticleSearchReferrers } from "@/hooks/useNavigationAnalysis";
import { ArticleTrendChart } from "./ArticleTrendChart";
import { Card, CardContent } from "@/components/ui/card";
import { format } from "date-fns";

export function ArticleDetailDrawer({
  cdpar, from, to, open, onOpenChange,
}: {
  cdpar: string | null; from: Date; to: Date;
  open: boolean; onOpenChange: (v: boolean) => void;
}) {
  const { data: series = [] } = useArticleTimeseries(cdpar, from, to);
  const { data: refs = [] } = useArticleSearchReferrers(cdpar, from, to);

  const totals = series.reduce(
    (acc, r) => ({
      views: acc.views + Number(r.views),
      cart: acc.cart + Number(r.cart_adds),
      orders: acc.orders + Number(r.orders),
    }),
    { views: 0, cart: 0, orders: 0 },
  );
  const conv = totals.views > 0 ? ((totals.orders / totals.views) * 100).toFixed(1) : "0.0";

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Andamento articolo {cdpar}</SheetTitle>
        </SheetHeader>
        <div className="mt-4 grid grid-cols-4 gap-2">
          {[
            ["Views", totals.views], ["Carrello", totals.cart],
            ["Ordini", totals.orders], ["Conv. %", conv],
          ].map(([k, v]) => (
            <Card key={k as string}><CardContent className="p-3">
              <div className="text-xs text-muted-foreground">{k}</div>
              <div className="text-xl font-semibold tabular-nums">{v}</div>
            </CardContent></Card>
          ))}
        </div>
        <div className="mt-4">
          <ArticleTrendChart data={series} />
        </div>
        <div className="mt-6">
          <h3 className="text-sm font-semibold mb-2">Ricerche correlate (entro 10 min dalla view)</h3>
          {refs.length === 0 ? (
            <div className="text-xs text-muted-foreground">Nessuna ricerca correlata trovata.</div>
          ) : (
            <ul className="text-xs space-y-1">
              {refs.map((r) => (
                <li key={r.query} className="flex justify-between border-b py-1">
                  <span className="font-mono">{r.query}</span>
                  <span className="text-muted-foreground">{r.n} · {format(new Date(r.last_seen), "dd/MM/yy")}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Link } from "react-router-dom";
import { ExternalLink, LineChart, ArrowUp, ArrowDown, ArrowUpDown } from "lucide-react";
import { useArticleMeta } from "@/hooks/useNavigationAnalysis";
import { useMemo, useState } from "react";

type Row = { cdpar: string; views: number; cart_adds: number; orders: number; conversion_rate: number };
type SortKey = "cdpar" | "descr" | "brand" | "views" | "cart_adds" | "orders" | "conversion_rate";
type SortDir = "asc" | "desc";

export function ArticlePerformanceTable({
  rows,
  onSelect,
}: {
  rows: Row[];
  onSelect: (cdpar: string) => void;
}) {
  const codes = useMemo(() => rows.map((r) => r.cdpar), [rows]);
  const { data: meta } = useArticleMeta(codes);
  const [sortKey, setSortKey] = useState<SortKey>("views");
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  const toggleSort = (key: SortKey) => {
    if (key === sortKey) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir(key === "cdpar" || key === "descr" || key === "brand" ? "asc" : "desc");
    }
  };

  const sortedRows = useMemo(() => {
    const arr = [...rows];
    const dir = sortDir === "asc" ? 1 : -1;
    arr.sort((a, b) => {
      let va: any;
      let vb: any;
      if (sortKey === "descr") {
        va = meta?.get(a.cdpar)?.descr ?? "";
        vb = meta?.get(b.cdpar)?.descr ?? "";
      } else if (sortKey === "brand") {
        va = meta?.get(a.cdpar)?.brand ?? "";
        vb = meta?.get(b.cdpar)?.brand ?? "";
      } else if (sortKey === "cdpar") {
        va = a.cdpar; vb = b.cdpar;
      } else {
        va = a[sortKey]; vb = b[sortKey];
      }
      if (typeof va === "number" && typeof vb === "number") return (va - vb) * dir;
      return String(va).localeCompare(String(vb), "it", { numeric: true }) * dir;
    });
    return arr;
  }, [rows, sortKey, sortDir, meta]);

  const SortIcon = ({ k }: { k: SortKey }) => {
    if (sortKey !== k) return <ArrowUpDown className="h-3 w-3 opacity-40" />;
    return sortDir === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />;
  };

  const HeadBtn = ({ k, label, align = "left" }: { k: SortKey; label: string; align?: "left" | "right" }) => (
    <button
      type="button"
      onClick={() => toggleSort(k)}
      className={`inline-flex items-center gap-1 hover:text-foreground transition-colors ${align === "right" ? "justify-end w-full" : ""}`}
    >
      {label}
      <SortIcon k={k} />
    </button>
  );

  return (
    <TooltipProvider delayDuration={150}>
      <div className="rounded-md border bg-card">
        <Table className="table-fixed text-sm">
          <TableHeader>
            <TableRow>
              <TableHead className="w-[90px] h-9 py-1.5"><HeadBtn k="cdpar" label="SKU" /></TableHead>
              <TableHead className="h-9 py-1.5"><HeadBtn k="descr" label="Descrizione" /></TableHead>
              <TableHead className="w-[90px] h-9 py-1.5"><HeadBtn k="brand" label="Brand" /></TableHead>
              <TableHead className="w-[80px] h-9 py-1.5 text-right"><HeadBtn k="views" label="Views" align="right" /></TableHead>
              <TableHead className="w-[80px] h-9 py-1.5 text-right"><HeadBtn k="cart_adds" label="Carrello" align="right" /></TableHead>
              <TableHead className="w-[80px] h-9 py-1.5 text-right"><HeadBtn k="orders" label="Ordini" align="right" /></TableHead>
              <TableHead className="w-[80px] h-9 py-1.5 text-right"><HeadBtn k="conversion_rate" label="Conv. %" align="right" /></TableHead>
              <TableHead className="w-[88px] h-9 py-1.5 text-right">Azioni</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedRows.length === 0 ? (
              <TableRow><TableCell colSpan={8} className="text-center text-muted-foreground py-6">Nessun dato nel periodo.</TableCell></TableRow>
            ) : sortedRows.map((r) => {
              const m = meta?.get(r.cdpar);
              const descr = m?.descr ?? "—";
              return (
                <TableRow key={r.cdpar}>
                  <TableCell className="font-mono py-1.5">{r.cdpar}</TableCell>
                  <TableCell className="py-1.5">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <span className="block truncate cursor-default">{descr}</span>
                      </TooltipTrigger>
                      <TooltipContent side="top" className="max-w-md whitespace-normal">
                        {descr}
                      </TooltipContent>
                    </Tooltip>
                  </TableCell>
                  <TableCell className="truncate py-1.5">{m?.brand ?? "—"}</TableCell>
                  <TableCell className="text-right tabular-nums py-1.5">{r.views}</TableCell>
                  <TableCell className="text-right tabular-nums py-1.5">{r.cart_adds}</TableCell>
                  <TableCell className="text-right tabular-nums py-1.5">{r.orders}</TableCell>
                  <TableCell className="text-right tabular-nums py-1.5">{Number(r.conversion_rate).toFixed(1)}</TableCell>
                  <TableCell className="text-right py-1 whitespace-nowrap">
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => onSelect(r.cdpar)} title="Andamento">
                      <LineChart className="h-4 w-4" />
                    </Button>
                    <Button asChild size="sm" variant="ghost" className="h-7 w-7 p-0" title="Apri scheda">
                      <Link to={`/pim/articles/${r.cdpar}`}>
                        <ExternalLink className="h-4 w-4" />
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}

          </TableBody>
        </Table>
      </div>
    </TooltipProvider>
  );
}

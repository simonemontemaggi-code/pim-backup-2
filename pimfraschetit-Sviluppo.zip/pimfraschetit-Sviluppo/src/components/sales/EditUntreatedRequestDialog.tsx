import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Pencil } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export interface EditableRequest {
  id: string;
  fornitore: string;
  codice_articolo_fornitore: string;
  descrizione: string;
  quantita: number;
  nota: string | null;
  cliente_codice: string;
  cliente_nominativo: string;
}

interface Props {
  open: boolean;
  request: EditableRequest | null;
  onOpenChange: (open: boolean) => void;
}

export default function EditUntreatedRequestDialog({ open, request, onOpenChange }: Props) {
  const qc = useQueryClient();
  const { user } = useAuth();

  const [fornitore, setFornitore] = useState("");
  const [codArt, setCodArt] = useState("");
  const [descrizione, setDescrizione] = useState("");
  const [quantita, setQuantita] = useState<number>(1);
  const [nota, setNota] = useState("");

  useEffect(() => {
    if (!request) return;
    setFornitore(request.fornitore ?? "");
    setCodArt(request.codice_articolo_fornitore ?? "");
    setDescrizione(request.descrizione ?? "");
    setQuantita(Number(request.quantita ?? 1));
    setNota(request.nota ?? "");
  }, [request]);

  const save = useMutation({
    mutationFn: async () => {
      if (!request) throw new Error("Richiesta non selezionata");
      const desc = descrizione.trim();
      if (!desc) throw new Error("La descrizione è obbligatoria");
      const qta = Number(quantita);
      if (!Number.isFinite(qta) || qta <= 0) throw new Error("Quantità non valida");

      const { error } = await supabase
        .from("richieste_ordini_non_trattati")
        .update({
          fornitore: fornitore.trim(),
          codice_articolo_fornitore: codArt.trim(),
          descrizione: desc,
          quantita: qta,
          nota: nota.trim() || null,
          edited_at: new Date().toISOString(),
          edited_by: user?.id ?? null,
        } as never)
        .eq("id", request.id);
      if (error) throw error;
    },
    onSuccess: async () => {
      toast.success("Richiesta aggiornata");
      await qc.resetQueries({ queryKey: ["sales-untreated-orders"] });
      await qc.refetchQueries({ queryKey: ["sales-untreated-orders"], type: "active" });
      onOpenChange(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={(o) => !save.isPending && onOpenChange(o)}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Modifica richiesta</DialogTitle>
          <DialogDescription>
            {request && (
              <>
                Cliente <span className="font-medium text-foreground">{request.cliente_codice}</span> — {request.cliente_nominativo}
              </>
            )}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label htmlFor="edit-fornitore">Fornitore</Label>
              <Input id="edit-fornitore" value={fornitore} onChange={(e) => setFornitore(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label htmlFor="edit-cod-art">Cod. articolo fornitore</Label>
              <Input id="edit-cod-art" value={codArt} onChange={(e) => setCodArt(e.target.value)} />
            </div>
          </div>
          <div className="space-y-1">
            <Label htmlFor="edit-descrizione">Descrizione</Label>
            <Input id="edit-descrizione" value={descrizione} onChange={(e) => setDescrizione(e.target.value)} />
          </div>
          <div className="space-y-1 w-32">
            <Label htmlFor="edit-quantita">Quantità</Label>
            <Input
              id="edit-quantita"
              type="number"
              min={1}
              step={1}
              value={quantita}
              onChange={(e) => setQuantita(Number(e.target.value))}
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="edit-nota">Nota</Label>
            <Textarea id="edit-nota" rows={3} value={nota} onChange={(e) => setNota(e.target.value)} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={save.isPending}>
            Annulla
          </Button>
          <Button onClick={() => save.mutate()} disabled={save.isPending}>
            <Pencil className="h-3.5 w-3.5 mr-1" />
            Salva
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Download, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { buildOrderTxt, downloadTxt, type BatchPayload } from "@/lib/orderTxtFormat";

export function OrderDownloadButton({
  count,
  selectedIds,
  onDownloaded,
}: {
  count: number;
  selectedIds?: string[];
  onDownloaded?: () => void;
}) {
  const qc = useQueryClient();
  const hasSelection = (selectedIds?.length ?? 0) > 0;
  const effectiveCount = hasSelection ? selectedIds!.length : count;

  const mut = useMutation({
    mutationFn: async () => {
      const args = hasSelection ? { p_order_ids: selectedIds } : {};
      const { data, error } = await supabase.rpc("generate_order_download_batch" as any, args as any);
      if (error) throw error;
      return data as unknown as BatchPayload;
    },
    onSuccess: (payload) => {
      if (!payload || (payload.orders_count ?? 0) === 0) {
        toast({ title: "Nessun ordine da scaricare" });
        return;
      }
      const txt = buildOrderTxt(payload);
      downloadTxt(payload.file_name || `ordini_${Date.now()}.txt`, txt);
      toast({ title: `Scaricati ${payload.orders_count} ordini ✅` });
      qc.invalidateQueries({ queryKey: ["sales-orders-pending"] });
      qc.invalidateQueries({ queryKey: ["sales-orders-downloaded"] });
      onDownloaded?.();
    },
    onError: (e: any) => toast({ title: "Errore scarico", description: e.message, variant: "destructive" }),
  });

  return (
    <Button onClick={() => mut.mutate()} disabled={effectiveCount === 0 || mut.isPending}>
      {mut.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Download className="h-4 w-4 mr-2" />}
      {hasSelection ? `Scarica ${effectiveCount} selezionati` : `Scarica ${effectiveCount} ordini`}
    </Button>
  );
}

export function RegenerateBatchButton({ batchId, fileName }: { batchId: string; fileName: string | null }) {
  const mut = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.rpc("regenerate_order_download_batch" as any, { p_batch_id: batchId });
      if (error) throw error;
      return data as unknown as BatchPayload;
    },
    onSuccess: (payload) => {
      const txt = buildOrderTxt(payload);
      downloadTxt(payload.file_name || fileName || `ordini_${batchId}.txt`, txt);
    },
    onError: (e: any) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });
  return (
    <Button size="sm" variant="outline" onClick={(e) => { e.stopPropagation(); mut.mutate(); }} disabled={mut.isPending}>
      {mut.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <Download className="h-3 w-3" />}
      <span className="ml-1">TXT</span>
    </Button>
  );
}

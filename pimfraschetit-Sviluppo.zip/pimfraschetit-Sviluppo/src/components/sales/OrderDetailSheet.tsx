import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2, Package, Tags, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface OrderInfo {
  id: string;
  transmission_id: string | null;
  codice_cliente: string | null;
  company_name: string | null;
  created_at: string;
  total: number | null;
  tipo: "negozio" | "agente";
  agent_label: string | null;
  zone_code: string | null;
  listino: string | null;
}

type PromoPill = { campagna: string; offerta: string; sconto: number | null };



const fmtEuro = (n: number | null | undefined) =>
  new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" }).format(Number(n ?? 0));
const fmtPct = (n: number) =>
  new Intl.NumberFormat("it-IT", { maximumFractionDigits: 0 }).format(Math.round(n)) + "%";
const fmtDate = (s: string | null | undefined) => {
  if (!s) return "—";
  const d = new Date(s);
  if (isNaN(d.getTime())) return "—";
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

const todayIso = () => new Date().toISOString().slice(0, 10);

export function OrderDetailSheet({
  order,
  onClose,
}: {
  order: OrderInfo | null;
  onClose: () => void;
}) {
  const orderId = order?.id ?? null;
  const listino = order?.listino ?? null;
  const { role } = useAuth();
  const isAdmin = role === "admin";
  const qc = useQueryClient();
  const [confirm1Open, setConfirm1Open] = useState(false);
  const [confirm2Open, setConfirm2Open] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const handleDelete = async () => {
    if (!order) return;
    setDeleting(true);
    const { error } = await supabase.from("customer_orders").delete().eq("id", order.id);
    setDeleting(false);
    setConfirm2Open(false);
    if (error) {
      toast.error(
        error.message?.includes("row-level security")
          ? "Solo gli amministratori possono eliminare ordini."
          : `Errore: ${error.message}`,
      );
      return;
    }
    toast.success(`Ordine ${order.transmission_id ?? order.id.slice(0, 8)} eliminato.`);
    await Promise.all([
      qc.invalidateQueries({ queryKey: ["sales-orders-pending"] }),
      qc.invalidateQueries({ queryKey: ["downloaded-orders"] }),
    ]);
    onClose();
  };

  const { data: orderNote } = useQuery({
    queryKey: ["order-note", orderId],
    enabled: !!orderId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("customer_orders")
        .select("note")
        .eq("id", orderId!)
        .maybeSingle();
      if (error) throw error;
      return (data?.note ?? "") as string;
    },
  });

  const { data: items, isLoading } = useQuery({
    queryKey: ["order-items", orderId],
    enabled: !!orderId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("customer_order_items")
        .select("id, product_id, sku, name, brand, quantity, unit_price, line_total, applied_promo")
        .eq("order_id", orderId!)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });

  const skus = (items ?? [])
    .map((i: any) => (i.sku ?? i.product_id ?? "").toString().trim())
    .filter(Boolean);

  // Prezzo di listino "ufficiale" via RPC (stessa fonte di Costario / Agent Hub / B2B)
  const { data: listinoMap } = useQuery({
    queryKey: ["order-items-listino-rpc", listino, skus.sort().join(",")],
    enabled: !!listino && skus.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("pim_prezzo_listino_batch", {
        _cdpars: skus,
        _cdls: listino!,
      });
      if (error) throw error;
      const m = new Map<string, number>();
      (data ?? []).forEach((r: any) => m.set((r.cdpar ?? "").trim(), Number(r.prezzo ?? 0)));
      return m;
    },
  });

  // Descrizioni complete (titolo prodotto + variante) dagli articoli
  const { data: descMap } = useQuery({
    queryKey: ["order-items-desc", skus.sort().join(",")],
    enabled: skus.length > 0,
    queryFn: async () => {
      const padded = skus.map((s) => s.padEnd(15, " "));
      const { data, error } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar, b2b_product_title, descrizione_variante")
        .in("cdpar", padded);
      if (error) throw error;
      const m = new Map<string, { title: string | null; variant: string | null }>();
      (data ?? []).forEach((r: any) =>
        m.set((r.cdpar ?? "").trim(), {
          title: r.b2b_product_title ?? null,
          variant: r.descrizione_variante ?? null,
        }),
      );
      return m;
    },
  });

  // Promo strutturate attive oggi che includono uno degli articoli (via tema_articoli)
  const { data: promoMap } = useQuery({
    queryKey: ["order-items-promo-v2", skus.sort().join(",")],
    enabled: skus.length > 0,
    queryFn: async () => {
      const today = todayIso();
      const { data: ta, error: e1 } = await supabase
        .from("promo_strutturate_tema_articoli")
        .select("cdpar, tema_id")
        .in("cdpar", skus);
      if (e1) throw e1;
      const temaIds = Array.from(new Set((ta ?? []).map((r: any) => r.tema_id)));
      if (temaIds.length === 0) return new Map<string, PromoPill[]>();
      const { data: temi, error: e2 } = await supabase
        .from("promo_strutturate_temi")
        .select("id, nome, sconto_pct, dal, al, wpprgf")
        .in("id", temaIds);
      if (e2) throw e2;
      const wpprgfs = Array.from(new Set((temi ?? []).map((t: any) => t.wpprgf).filter(Boolean)));
      const { data: testate } = wpprgfs.length
        ? await supabase
            .from("promo_strutturate_testate")
            .select("wpprgf, wptpbd, wpcca, wpdvali, wpdvalf")
            .in("wpprgf", wpprgfs)
        : { data: [] as any[] };
      const testataByWp = new Map<string, any>();
      (testate ?? []).forEach((t: any) => testataByWp.set(t.wpprgf, t));

      const temaInfo = new Map<string, { campagna: string; offerta: string; sconto: number | null; active: boolean }>();
      (temi ?? []).forEach((t: any) => {
        const tt = testataByWp.get(t.wpprgf);
        const dal = (t.dal ?? tt?.wpdvali ?? "").toString().slice(0, 10);
        const al = (t.al ?? tt?.wpdvalf ?? "").toString().slice(0, 10);
        const active = (!dal || dal <= today) && (!al || al >= today);
        const campagna = (tt?.wptpbd ?? tt?.wpcca ?? `#${t.wpprgf}`).toString().trim();
        const offerta = (t.nome ?? "Offerta").toString().trim();
        const sconto = t.sconto_pct != null ? Number(t.sconto_pct) : null;
        temaInfo.set(t.id, { campagna, offerta, sconto, active });
      });

      const result = new Map<string, PromoPill[]>();
      (ta ?? []).forEach((r: any) => {
        const info = temaInfo.get(r.tema_id);
        if (!info || !info.active) return;
        const k = (r.cdpar ?? "").trim();
        const arr = result.get(k) ?? [];
        const dup = arr.some(
          (p) => p.campagna === info.campagna && p.offerta === info.offerta && p.sconto === info.sconto,
        );
        if (!dup) arr.push({ campagna: info.campagna, offerta: info.offerta, sconto: info.sconto });
        result.set(k, arr);
      });
      return result;
    },
  });

  const totalCalc = (items ?? []).reduce(
    (s, it: any) => s + Number(it.line_total ?? Number(it.unit_price ?? 0) * Number(it.quantity ?? 0)),
    0,
  );

  return (
    <Sheet open={!!order} onOpenChange={(o) => { if (!o) onClose(); }}>
      <SheetContent side="right" className="w-full sm:max-w-[60vw] overflow-y-auto">
        <SheetHeader>
          <div className="flex items-start justify-between gap-3 pr-8">
            <SheetTitle className="flex items-center gap-2">
              <Package className="h-5 w-5 text-primary" />
              Ordine {order?.transmission_id ?? order?.id.slice(0, 8)}
              {order && (
                order.tipo === "negozio" ? (
                  <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 border-blue-200">Cliente CC</Badge>
                ) : (
                  <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100 border-amber-200">Agente CA</Badge>
                )
              )}
            </SheetTitle>
            {isAdmin && order && (
              <Button
                variant="destructive"
                size="sm"
                onClick={() => setConfirm1Open(true)}
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Elimina ordine
              </Button>
            )}
          </div>
        </SheetHeader>

        <AlertDialog open={confirm1Open} onOpenChange={setConfirm1Open}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Sei sicuro di voler eliminare questo ordine?</AlertDialogTitle>
              <AlertDialogDescription>
                Ordine <strong>{order?.transmission_id ?? order?.id.slice(0, 8)}</strong>
                {order?.company_name ? <> — {order.company_name}</> : null}
                {order?.total != null ? <> — {fmtEuro(order.total)}</> : null}.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Annulla</AlertDialogCancel>
              <AlertDialogAction
                onClick={(e) => {
                  e.preventDefault();
                  setConfirm1Open(false);
                  setConfirm2Open(true);
                }}
              >
                Sì, continua
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        <AlertDialog open={confirm2Open} onOpenChange={(o) => !deleting && setConfirm2Open(o)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Eliminazione definitiva</AlertDialogTitle>
              <AlertDialogDescription>
                Una volta eliminato, l'ordine <strong>NON sarà più recuperabile</strong>.
                Confermi l'eliminazione definitiva?
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={deleting}>No, annulla</AlertDialogCancel>
              <AlertDialogAction
                disabled={deleting}
                onClick={(e) => {
                  e.preventDefault();
                  handleDelete();
                }}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {deleting ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
                Sì, elimina definitivamente
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {order && (
          <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
            <div>
              <div className="text-muted-foreground text-xs">Cliente</div>
              <div className="font-medium">{order.codice_cliente} · {order.company_name ?? "—"}</div>
            </div>
            <div>
              <div className="text-muted-foreground text-xs">Zona</div>
              <div>{order.zone_code ?? "—"}</div>
            </div>
            <div>
              <div className="text-muted-foreground text-xs">Agente</div>
              <div>{order.agent_label ?? "—"}</div>
            </div>
            <div>
              <div className="text-muted-foreground text-xs">Data e ora trasmissione</div>
              <div className="whitespace-nowrap">{fmtDate(order.created_at)}</div>
            </div>
            <div>
              <div className="text-muted-foreground text-xs">Listino</div>
              <div className="font-mono">{order.listino ?? "—"}</div>
            </div>
            <div>
              <div className="text-muted-foreground text-xs">Totale ordine</div>
              <div className="font-semibold">{fmtEuro(order.total)}</div>
            </div>
          </div>
        )}

        {orderNote && orderNote.trim().length > 0 && (
          <div className="mt-4 p-3 rounded-md border bg-amber-50 border-amber-200">
            <div className="text-xs font-semibold text-amber-800 mb-1">Note dell'ordine</div>
            <div className="text-sm text-amber-900 whitespace-pre-wrap">{orderNote}</div>
          </div>
        )}

        <div className="mt-6">
          <h3 className="text-sm font-semibold mb-2">Righe ordine</h3>
          {isLoading ? (
            <div className="flex items-center gap-2 text-muted-foreground p-6 justify-center">
              <Loader2 className="h-4 w-4 animate-spin" /> Caricamento…
            </div>
          ) : !items || items.length === 0 ? (
            <div className="border rounded-md p-6 text-center text-muted-foreground text-sm">
              Nessuna riga.
            </div>
          ) : (
            <div className="border rounded-md overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>SKU</TableHead>
                    <TableHead>Articolo</TableHead>
                    <TableHead className="text-right">Q.tà</TableHead>
                    <TableHead className="text-right">Listino</TableHead>
                    <TableHead className="text-right">Prezzo</TableHead>
                    <TableHead className="text-right">Risparmio</TableHead>
                    <TableHead>Promo</TableHead>
                    <TableHead className="text-right">Totale</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.map((it: any) => {
                    const sku = (it.sku ?? it.product_id ?? "").toString().trim();
                    const base = listinoMap?.get(sku);
                    const baseNet = base != null ? base / 2 : null;
                    const unit = Number(it.unit_price ?? 0);
                    const sconto = baseNet != null && baseNet > 0 ? ((baseNet - unit) / baseNet) * 100 : null;
                    const promos = promoMap?.get(sku) ?? [];

                    const info = descMap?.get(sku);
                    const composed = info?.title
                      ? [info.title, info.variant].filter(Boolean).join(" ")
                      : (it.name ?? "—");

                    return (
                      <TableRow key={it.id}>
                        <TableCell className="font-mono text-xs">{sku || "—"}</TableCell>
                        <TableCell className="max-w-[280px]">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="font-medium line-clamp-2 cursor-default">{composed}</div>
                            </TooltipTrigger>
                            <TooltipContent className="max-w-sm">{composed}</TooltipContent>
                          </Tooltip>
                          {it.brand && <div className="text-xs text-muted-foreground">{it.brand}</div>}
                        </TableCell>
                        <TableCell className="text-right">{Number(it.quantity ?? 0)}</TableCell>
                        <TableCell className="text-right text-muted-foreground">
                          {base != null ? fmtEuro(base) : "—"}
                        </TableCell>
                        <TableCell className="text-right">
                          <div>{fmtEuro(unit)}</div>
                        </TableCell>
                        <TableCell className="text-right">
                          {baseNet != null && unit < baseNet - 0.01 ? (
                            <TooltipProvider delayDuration={100}>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Badge
                                    variant="outline"
                                    className="cursor-help border-green-300 text-green-700 bg-green-50"
                                  >
                                    {sconto != null ? `−${fmtPct(Math.abs(sconto))}` : `−${fmtEuro(baseNet - unit)}`}
                                  </Badge>
                                </TooltipTrigger>
                                <TooltipContent side="left" className="text-xs space-y-1">
                                  <div className="font-semibold">Dettaglio sconto</div>
                                  <div className="grid grid-cols-2 gap-x-3">
                                    <span className="text-muted-foreground">Listino {order?.listino ?? ""}</span>
                                    <span className="text-right font-mono">{fmtEuro(base!)}</span>
                                    <span className="text-muted-foreground">Base netta (Listino / 2)</span>
                                    <span className="text-right font-mono">{fmtEuro(baseNet)}</span>
                                    <span className="text-muted-foreground">Prezzo pagato</span>
                                    <span className="text-right font-mono">{fmtEuro(unit)}</span>
                                    <span className="font-semibold">Risparmio</span>
                                    <span className="text-right font-mono font-semibold">−{fmtEuro(baseNet - unit)}</span>
                                    <span className="text-muted-foreground">Sconto %</span>
                                    <span className="text-right font-mono">
                                      {sconto != null ? `−${fmtPct(Math.abs(sconto))}` : "—"}
                                    </span>
                                  </div>
                                  {promos.length > 0 && (
                                    <div className="pt-1 border-t mt-1">
                                      <div className="text-muted-foreground">Promo collegate:</div>
                                      {promos.map((p, i) => (
                                        <div key={i}>
                                          • <span className="font-medium">{p.campagna}</span>
                                          {" → "}
                                          {p.offerta}
                                          {p.sconto != null ? ` −${p.sconto}%` : ""}
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          ) : baseNet != null && unit > baseNet + 0.01 ? (
                            <TooltipProvider delayDuration={100}>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Badge
                                    variant="outline"
                                    className="cursor-help border-red-300 text-red-700 bg-red-50"
                                  >
                                    +{fmtEuro(unit - baseNet)}
                                  </Badge>
                                </TooltipTrigger>
                                <TooltipContent side="left" className="text-xs space-y-1 max-w-xs">
                                  <div className="font-semibold text-red-700">Prezzo superiore alla base netta</div>
                                  <div className="grid grid-cols-2 gap-x-3">
                                    <span className="text-muted-foreground">Listino {order?.listino ?? ""}</span>
                                    <span className="text-right font-mono">{fmtEuro(base!)}</span>
                                    <span className="text-muted-foreground">Base netta (Listino / 2)</span>
                                    <span className="text-right font-mono">{fmtEuro(baseNet)}</span>
                                    <span className="text-muted-foreground">Prezzo pagato</span>
                                    <span className="text-right font-mono">{fmtEuro(unit)}</span>
                                    <span className="font-semibold">Differenza</span>
                                    <span className="text-right font-mono font-semibold">+{fmtEuro(unit - baseNet)}</span>
                                  </div>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {it.applied_promo ? (() => {
                            const parts = String(it.applied_promo)
                              .split(" · ")
                              .map((s) => s.trim())
                              .filter(Boolean);
                            if (parts.length >= 2) {
                              const norm = (s: string) =>
                                s.replace(/\s*-?\d+([.,]\d+)?\s*%\s*$/i, "").trim().toLowerCase();
                              const camp = parts[0];
                              const off = parts[1];
                              const nc = norm(camp);
                              const no = norm(off);
                              const redundant = nc === no || no.startsWith(nc) || nc.startsWith(no);
                              const pills = redundant ? [off] : [camp, off];
                              return (
                                <div className="flex flex-wrap gap-1">
                                  {pills.map((p, i) => (
                                    <Badge key={i} variant="secondary" className="gap-1">
                                      {i === 0 ? <Tags className="h-3 w-3" /> : null}
                                      <span>{p}</span>
                                    </Badge>
                                  ))}
                                </div>
                              );
                            }
                            return (
                              <Badge variant="secondary" className="gap-1">
                                <Tags className="h-3 w-3" /> {it.applied_promo}
                              </Badge>
                            );
                          })() : promos.length > 0 ? (
                            <div className="flex flex-wrap gap-1">
                              {promos.map((p, i) => (
                                <Badge key={i} variant="secondary" className="gap-1">
                                  <Tags className="h-3 w-3" />
                                  <span className="font-medium">{p.campagna}</span>
                                  <span className="opacity-70">·</span>
                                  <span>
                                    {p.offerta}
                                    {p.sconto != null ? ` −${p.sconto}%` : ""}
                                  </span>
                                </Badge>
                              ))}
                            </div>
                          ) : (
                            <span className="text-muted-foreground text-xs">—</span>
                          )}
                        </TableCell>


                        <TableCell className="text-right font-medium">
                          {fmtEuro(it.line_total ?? unit * Number(it.quantity ?? 0))}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                  <TableRow className="bg-muted/40 font-semibold">
                    <TableCell colSpan={7} className="text-right">Totale righe</TableCell>
                    <TableCell className="text-right">{fmtEuro(totalCalc)}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          )}
          <p className="text-xs text-muted-foreground mt-2">
            Risparmio = differenza tra la base netta (Listino {order?.listino ?? "—"} / 2) e il prezzo applicato in ordine.
            Le promo elencate sono quelle strutturate attive oggi che includono l'articolo.
          </p>
        </div>
      </SheetContent>
    </Sheet>
  );
}

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { ParsedOrder } from "@/pages/SalesPromoControlPage";

const currency = new Intl.NumberFormat("it-IT", {
  style: "currency",
  currency: "EUR",
});
const qtyFmt = new Intl.NumberFormat("it-IT", { maximumFractionDigits: 3 });

type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  order: ParsedOrder | null;
  scaricoLabel: string;
  customer?: { company_name: string | null; zone_code: string | null };
  promoCdparSet?: Set<string> | null;
  articleMap?: Map<string, { descrizione: string | null }>;
  priceMap?: Map<string, number>;
  custCdls?: string | null;
};

export function OrderDetailDialog({ open, onOpenChange, order, scaricoLabel, customer, promoCdparSet, articleMap, priceMap, custCdls }: Props) {
  if (!order) return null;

  // Applica fallback prezzo listino/2 quando prezzo riga = 0
  const displayLines = order.lines.map((l) => {
    let effPrice = l.price;
    let fallback = false;
    if ((!l.price || l.price === 0) && custCdls && priceMap) {
      const lp = priceMap.get(`${custCdls}|${l.cdpar}`);
      if (lp && lp > 0) {
        effPrice = lp / 2;
        fallback = true;
      }
    }
    const effValue = fallback ? l.qty * effPrice : l.value;
    return { ...l, effPrice, effValue, fallback };
  });
  const totalDisplay = displayLines.reduce((s, l) => s + l.effValue, 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            Ordine <span className="font-mono">{order.orderNumber}</span>
          </DialogTitle>
          <DialogDescription>
            {scaricoLabel} • Cliente <span className="font-mono">{order.custCode}</span>
            {customer?.company_name ? ` — ${customer.company_name}` : ""}
            {customer?.zone_code ? ` • Zona ${customer.zone_code}` : ""}
            {custCdls ? ` • Listino ${custCdls}` : ""}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-semibold">Righe articolo ({order.lines.length})</h3>
              <div className="text-sm text-muted-foreground">
                Totale <span className="font-semibold text-foreground">{currency.format(totalDisplay)}</span>
              </div>
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Cdpar</TableHead>
                  <TableHead>Descrizione</TableHead>
                  <TableHead className="text-right">Qty</TableHead>
                  <TableHead className="text-right">Prezzo</TableHead>
                  <TableHead className="text-right">Valore</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {displayLines.map((l, i) => {
                  const inPromo = promoCdparSet?.has(l.cdpar);
                  const desc = articleMap?.get(l.cdpar)?.descrizione;
                  return (
                    <TableRow key={i} className={inPromo ? "bg-primary/10" : undefined}>
                      <TableCell className="font-mono align-top">
                        {l.cdpar}
                        {inPromo && (
                          <span className="ml-2 text-[10px] uppercase text-primary font-semibold">promo</span>
                        )}
                      </TableCell>
                      <TableCell className="align-top max-w-md">
                        {desc ? (
                          <span className="text-sm">{desc}</span>
                        ) : (
                          <span className="text-xs text-muted-foreground italic">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right align-top">{qtyFmt.format(l.qty)}</TableCell>
                      <TableCell className="text-right align-top">
                        {currency.format(l.effPrice)}
                        {l.fallback && (
                          <span
                            className="ml-1 text-[10px] text-muted-foreground"
                            title="Prezzo da listino cliente / 2 (riga ordine a 0)"
                          >
                            *
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="text-right align-top font-medium">{currency.format(l.effValue)}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
            {displayLines.some((l) => l.fallback) && (
              <p className="mt-2 text-xs text-muted-foreground">
                * Prezzo derivato dal listino <span className="font-mono">{custCdls}</span> del cliente, diviso 2 (la riga ordine aveva prezzo 0).
              </p>
            )}
          </div>

          {order.notes.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold mb-2">Note ({order.notes.length})</h3>
              <div className="rounded border bg-muted/30 p-3 text-sm whitespace-pre-wrap font-mono">
                {order.notes.map((n) => n.text).join("\n")}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

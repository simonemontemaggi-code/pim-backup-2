import { useMemo, useState } from "react";
import { downloadXlsxAoa } from "@/lib/xlsxExport";
import { useQuery } from "@tanstack/react-query";
import { ArrowDown, ArrowUp, ArrowUpDown, FileDown, Loader2, PackageCheck, Search, StickyNote } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { RegenerateBatchButton } from "./OrderDownloadButton";
import { OrderDetailSheet } from "./OrderDetailSheet";
import { usePermissions } from "@/lib/permissions";

const fmtDateParts = (s: string | null | undefined): { date: string; time: string } => {
  if (!s) return { date: "—", time: "" };
  const d = new Date(s);
  if (isNaN(d.getTime())) return { date: "—", time: "" };
  const pad = (n: number) => String(n).padStart(2, "0");
  return {
    date: `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${String(d.getFullYear()).slice(-2)}`,
    time: `${pad(d.getHours())}:${pad(d.getMinutes())}`,
  };
};

function DateTimeCell({ value }: { value: string | null | undefined }) {
  const { date, time } = fmtDateParts(value);
  return (
    <div className="flex flex-col leading-tight">
      <span className="text-xs font-medium text-foreground">{date}</span>
      {time && <span className="text-[11px] font-mono text-muted-foreground">{time}</span>}
    </div>
  );
}

function TipoBadge({ tipo }: { tipo: "negozio" | "agente" }) {
  return tipo === "negozio" ? (
    <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 border-blue-200">CC</Badge>
  ) : (
    <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100 border-amber-200">CA</Badge>
  );
}

const initials = (name: string | null | undefined): string => {
  if (!name) return "—";
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "—";
  return (parts[0][0] + (parts[parts.length - 1][0] ?? "")).toUpperCase();
};

interface Row {
  order_id: string;
  batch_id: string;
  batch_created_at: string;
  batch_user_name: string | null;
  batch_file_name: string | null;
  progressivo: number;
  transmission_id: string | null;
  codice_cliente: string | null;
  codice_agente: string | null;
  zone_code: string | null;
  listino: string | null;
  company_name: string | null;
  total: number | null;
  origine: string | null;
  tipo: "negozio" | "agente";
  created_at: string;
  note: string | null;
  items_count: number;
}

const todayISO = () => {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};

const isoDateOfTimestamp = (s: string): string => {
  const d = new Date(s);
  if (isNaN(d.getTime())) return "";
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};

type SortKey =
  | "batch_created_at" | "batch_user_name" | "codice_agente" | "zone_code"
  | "codice_cliente" | "company_name" | "transmission_id" | "tipo"
  | "created_at" | "items_count" | "total";
type SortDir = "asc" | "desc";

function SortableHead({
  label, sortKey, current, dir, onClick, align,
}: {
  label: string;
  sortKey: SortKey;
  current: SortKey;
  dir: SortDir;
  onClick: (k: SortKey) => void;
  align?: "right";
}) {
  const active = current === sortKey;
  const Icon = !active ? ArrowUpDown : dir === "asc" ? ArrowUp : ArrowDown;
  return (
    <TableHead className={cn(align === "right" && "text-right")}>
      <button
        type="button"
        onClick={() => onClick(sortKey)}
        className={cn(
          "inline-flex items-center gap-1 hover:text-foreground transition-colors",
          align === "right" && "ml-auto",
          active ? "text-foreground font-semibold" : "text-muted-foreground",
        )}
      >
        <span>{label}</span>
        <Icon className={cn("h-3 w-3", active ? "opacity-100" : "opacity-50")} />
      </button>
    </TableHead>
  );
}

export function DownloadedOrdersTab() {
  const { canAction } = usePermissions();
  const canDownload = canAction("sales_orders", "download_orders");
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [search, setSearch] = useState("");
  const [tipoFilter, setTipoFilter] = useState<"all" | "negozio" | "agente">("all");
  const [agentFilter, setAgentFilter] = useState<string>("all");
  const [zoneFilter, setZoneFilter] = useState<string>("all");
  const [noteFilter, setNoteFilter] = useState<"all" | "with" | "without">("all");
  const [fromDate, setFromDate] = useState<string>(todayISO);
  const [toDate, setToDate] = useState<string>(todayISO);
  const [sortKey, setSortKey] = useState<SortKey>("batch_created_at");
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  const toggleSort = (k: SortKey) => {
    if (sortKey === k) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(k); setSortDir(k === "batch_created_at" || k === "created_at" || k === "items_count" || k === "total" ? "desc" : "asc"); }
  };
  const toggleNoteFilter = () =>
    setNoteFilter((prev) => (prev === "all" ? "with" : prev === "with" ? "without" : "all"));

  const { data: rows, isLoading, isError, error: queryError } = useQuery({
    queryKey: ["sales-orders-downloaded-flat", fromDate, toDate],
    queryFn: async (): Promise<Row[]> => {
      // Helper: esegue una `.in(col, ids)` a chunk per evitare URL > ~8KB
      // che vengono rifiutati da PostgREST/Cloudflare con HTTP 400.
      async function fetchInChunks<T>(
        ids: string[],
        chunkSize: number,
        fn: (chunk: string[]) => PromiseLike<{ data: T[] | null; error: any }>,
      ): Promise<T[]> {
        const out: T[] = [];
        for (let i = 0; i < ids.length; i += chunkSize) {
          const chunk = ids.slice(i, i + chunkSize);
          const { data, error } = await fn(chunk);
          if (error) throw error;
          if (data) out.push(...data);
        }
        return out;
      }

      // 1) Batch nel range di date visibile (server-side, non client-side)
      let bq = supabase
        .from("order_download_batches")
        .select("id, created_at, created_by, file_name")
        .order("created_at", { ascending: false });
      if (fromDate) bq = bq.gte("created_at", `${fromDate}T00:00:00Z`);
      if (toDate) bq = bq.lte("created_at", `${toDate}T23:59:59.999Z`);
      const { data: batches, error } = await bq;
      if (error) throw error;
      const batchList = (batches ?? []) as any[];
      if (!batchList.length) return [];

      const userIds = Array.from(new Set(batchList.map((b) => b.created_by).filter(Boolean)));
      const profs = userIds.length
        ? await fetchInChunks<any>(userIds, 200, (chunk) =>
            supabase.from("profiles").select("user_id, full_name").in("user_id", chunk),
          )
        : [];
      const userMap = new Map((profs ?? []).map((p: any) => [p.user_id, p.full_name]));

      const batchIds = batchList.map((b) => b.id);
      const items = await fetchInChunks<any>(batchIds, 200, (chunk) =>
        supabase
          .from("order_download_batch_items")
          .select("batch_id, order_id, progressivo")
          .in("batch_id", chunk),
      );
      const orderIds = items.map((i: any) => i.order_id);

      const orders = orderIds.length
        ? await fetchInChunks<any>(orderIds, 200, (chunk) =>
            supabase
              .from("customer_orders")
              .select("id, transmission_id, codice_cliente, codice_agente, total, origine, created_at, listino, note")
              .in("id", chunk),
          )
        : [];
      const orderMap = new Map((orders ?? []).map((o: any) => [o.id, o]));

      const codes = Array.from(new Set((orders ?? []).map((o: any) => o.codice_cliente).filter(Boolean)));
      const customers = codes.length
        ? await fetchInChunks<any>(codes, 200, (chunk) =>
            supabase
              .from("customers")
              .select("customer_code, company_name, zone_code, original_agent_code, assigned_agent_id")
              .in("customer_code", chunk),
          )
        : [];
      const custMap = new Map((customers ?? []).map((c: any) => [c.customer_code, c]));

      const effectiveAgentCode = (o: any): string | null => {
        if (o.codice_agente) return o.codice_agente;
        const c = o.codice_cliente ? (custMap.get(o.codice_cliente) as any) : undefined;
        return c?.original_agent_code ?? null;
      };

      const assignedIds = Array.from(
        new Set((customers ?? []).map((c: any) => c.assigned_agent_id).filter(Boolean) as string[]),
      );
      const assignedAgents = assignedIds.length
        ? await fetchInChunks<any>(assignedIds, 200, (chunk) =>
            supabase.from("profiles").select("id, agent_code").in("id", chunk),
          )
        : [];
      const agentById = new Map<string, string | null>(
        (assignedAgents ?? []).map((a: any) => [a.id, a.agent_code]),
      );

      const countMap = new Map<string, number>();
      if (orderIds.length) {
        const oi = await fetchInChunks<any>(orderIds, 200, (chunk) =>
          supabase.from("customer_order_items").select("order_id").in("order_id", chunk),
        );
        oi.forEach((r: any) => {
          countMap.set(r.order_id, (countMap.get(r.order_id) ?? 0) + 1);
        });
      }

      const batchById = new Map(batchList.map((b) => [b.id, b]));

      const result: Row[] = [];
      items.forEach((it: any) => {
        const o = orderMap.get(it.order_id);
        const b = batchById.get(it.batch_id);
        if (!o || !b) return;
        const c = o.codice_cliente ? (custMap.get(o.codice_cliente) as any) : undefined;
        let agentCode = effectiveAgentCode(o);
        if (!agentCode && c?.assigned_agent_id) {
          agentCode = agentById.get(c.assigned_agent_id) ?? null;
        }
        result.push({
          order_id: o.id,
          batch_id: it.batch_id,
          batch_created_at: b.created_at,
          batch_user_name: b.created_by ? userMap.get(b.created_by) ?? null : null,
          batch_file_name: b.file_name ?? null,
          progressivo: it.progressivo,
          transmission_id: o.transmission_id,
          codice_cliente: o.codice_cliente,
          codice_agente: agentCode,
          zone_code: c?.zone_code ?? null,
          listino: o.listino ?? null,
          company_name: c?.company_name ?? null,
          total: o.total,
          origine: o.origine,
          tipo: (o.origine === "NE" ? "negozio" : "agente") as "negozio" | "agente",
          created_at: o.created_at,
          note: o.note ?? null,
          items_count: countMap.get(o.id) ?? 0,
        });
      });

      result.sort((a, b) => {
        const t = b.batch_created_at.localeCompare(a.batch_created_at);
        if (t !== 0) return t;
        return b.progressivo - a.progressivo;
      });
      return result;
    },
  });

  const list = rows ?? [];

  const agents = useMemo(() => {
    const s = new Set<string>();
    list.forEach((r) => r.codice_agente && s.add(r.codice_agente));
    return Array.from(s).sort();
  }, [list]);

  const zones = useMemo(() => {
    const s = new Set<string>();
    list.forEach((r) => r.zone_code && s.add(r.zone_code));
    return Array.from(s).sort();
  }, [list]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return list.filter((r) => {
      if (tipoFilter !== "all" && r.tipo !== tipoFilter) return false;
      if (agentFilter !== "all" && r.codice_agente !== agentFilter) return false;
      if (zoneFilter !== "all" && r.zone_code !== zoneFilter) return false;
      if (noteFilter !== "all") {
        const hasNote = !!r.note && r.note.trim().length > 0;
        if (noteFilter === "with" && !hasNote) return false;
        if (noteFilter === "without" && hasNote) return false;
      }
      const d = isoDateOfTimestamp(r.batch_created_at);
      if (fromDate && d < fromDate) return false;
      if (toDate && d > toDate) return false;
      if (!q) return true;
      return (
        r.codice_cliente?.toLowerCase().includes(q) ||
        r.company_name?.toLowerCase().includes(q) ||
        r.transmission_id?.toLowerCase().includes(q)
      );
    });
  }, [list, search, tipoFilter, agentFilter, zoneFilter, noteFilter, fromDate, toDate]);

  const sorted = useMemo(() => {
    const arr = [...filtered];
    const dir = sortDir === "asc" ? 1 : -1;
    const cmp = (a: any, b: any) => {
      if (a == null && b == null) return 0;
      if (a == null) return 1;
      if (b == null) return -1;
      if (typeof a === "number" && typeof b === "number") return (a - b) * dir;
      return String(a).localeCompare(String(b), "it", { numeric: true, sensitivity: "base" }) * dir;
    };
    arr.sort((x, y) => cmp((x as any)[sortKey], (y as any)[sortKey]));
    return arr;
  }, [filtered, sortKey, sortDir]);

  const totals = useMemo(() => {
    const value = filtered.reduce((s, r) => s + Number(r.total ?? 0), 0);
    const righe = filtered.reduce((s, r) => s + Number(r.items_count ?? 0), 0);
    return { count: filtered.length, value, righe };
  }, [filtered]);

  const fmtEuro = (n: number | null | undefined) =>
    new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" }).format(Number(n ?? 0));


  const handleExportCsv = () => {
    const headers = [
      "Data scarico", "Ora scarico", "Utente", "Agente", "Zona",
      "Cod. Cliente", "Ragione Sociale", "N. ordine", "Tipo",
      "Data trasmissione", "Ora trasmissione", "N. righe", "Valore €", "Note",
    ];
    const aoa: any[][] = [headers];
    filtered.forEach((r) => {
      const bp = fmtDateParts(r.batch_created_at);
      const tp = fmtDateParts(r.created_at);
      aoa.push([
        bp.date, bp.time,
        r.batch_user_name ?? "",
        r.codice_agente ?? "",
        r.zone_code ?? "",
        r.codice_cliente ?? "",
        r.company_name ?? "",
        r.transmission_id ?? "",
        r.tipo === "negozio" ? "CC" : "CA",
        tp.date, tp.time,
        Number(r.items_count),
        Number(r.total ?? 0),
        r.note ?? "",
      ]);
    });
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, "0");
    const stamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}`;
    downloadXlsxAoa(`report_ordini_scaricati_${stamp}.xlsx`, aoa, { sheetName: "Ordini" });
  };

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 text-muted-foreground p-8 justify-center">
        <Loader2 className="h-4 w-4 animate-spin" /> Caricamento…
      </div>
    );
  }
  if (isError) {
    return (
      <div className="border border-destructive/40 rounded-md p-6 text-center text-destructive text-sm">
        Errore nel caricamento degli scarichi:<br />
        <span className="font-mono text-xs">{(queryError as any)?.message ?? String(queryError)}</span>
      </div>
    );
  }
  if (!list.length) {
    return (
      <div className="border rounded-md p-8 text-center text-muted-foreground">
        Nessuno scarico effettuato nel periodo selezionato.
      </div>
    );
  }

  return (
    <TooltipProvider delayDuration={150}>
      <div className="space-y-4">
        <div className="flex flex-wrap gap-2 items-center">
          <div className="flex items-center gap-1.5">
            <Label className="text-xs text-muted-foreground">Da</Label>
            <Input
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="w-[150px] h-9"
            />
          </div>
          <div className="flex items-center gap-1.5">
            <Label className="text-xs text-muted-foreground">A</Label>
            <Input
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="w-[150px] h-9"
            />
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => { const t = todayISO(); setFromDate(t); setToDate(t); }}
          >
            Oggi
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="ml-auto"
            onClick={handleExportCsv}
            disabled={filtered.length === 0}
          >
            <FileDown className="h-4 w-4 mr-2" />
            Report Ordini
          </Button>
        </div>
        <div className="flex flex-wrap gap-2 items-center">
          <div className="relative flex-1 min-w-[240px]">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Cerca codice, ragione sociale, n° ordine…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8"
            />
          </div>
          <Select value={tipoFilter} onValueChange={(v) => setTipoFilter(v as any)}>
            <SelectTrigger className="w-[160px]"><SelectValue placeholder="Tipo" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tutti i tipi</SelectItem>
              <SelectItem value="negozio">Cliente CC</SelectItem>
              <SelectItem value="agente">Agente CA</SelectItem>
            </SelectContent>
          </Select>
          <Select value={agentFilter} onValueChange={setAgentFilter}>
            <SelectTrigger className="w-[200px]"><SelectValue placeholder="Agente" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tutti gli agenti</SelectItem>
              {agents.map((code) => (
                <SelectItem key={code} value={code}>{code}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={zoneFilter} onValueChange={setZoneFilter}>
            <SelectTrigger className="w-[160px]"><SelectValue placeholder="Zona" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tutte le zone</SelectItem>
              {zones.map((z) => (
                <SelectItem key={z} value={z}>{z}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <TooltipProvider delayDuration={150}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  className={`h-9 w-9 px-0 ${
                    noteFilter === "all"
                      ? "text-muted-foreground"
                      : noteFilter === "with"
                      ? "text-green-600 border-green-300 hover:text-green-700 hover:bg-green-50"
                      : "text-amber-500 border-amber-300 hover:text-amber-600 hover:bg-amber-50"
                  }`}
                  onClick={toggleNoteFilter}
                >
                  <StickyNote className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                {noteFilter === "all"
                  ? "Tutti gli ordini"
                  : noteFilter === "with"
                  ? "Solo ordini con note"
                  : "Solo ordini senza note"}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>

        <div className="text-sm text-muted-foreground">
          Scaricati: <span className="font-semibold text-foreground">{totals.count}</span>
          {" · "}
          <span className="font-semibold text-foreground">{fmtEuro(totals.value)}</span>
          {" · "}
          {totals.righe} righe
        </div>




        {filtered.length === 0 ? (
          <div className="border rounded-md p-8 text-center text-muted-foreground">
            Nessun risultato per i filtri attuali.
          </div>
        ) : (
        <div className="border rounded-md overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <SortableHead label="Data scarico" sortKey="batch_created_at" current={sortKey} dir={sortDir} onClick={toggleSort} />
                <SortableHead label="Utente" sortKey="batch_user_name" current={sortKey} dir={sortDir} onClick={toggleSort} />
                <SortableHead label="Agente" sortKey="codice_agente" current={sortKey} dir={sortDir} onClick={toggleSort} />
                <SortableHead label="Zona" sortKey="zone_code" current={sortKey} dir={sortDir} onClick={toggleSort} />
                <SortableHead label="Cod. Cliente" sortKey="codice_cliente" current={sortKey} dir={sortDir} onClick={toggleSort} />
                <SortableHead label="Rag. Sociale" sortKey="company_name" current={sortKey} dir={sortDir} onClick={toggleSort} />
                <SortableHead label="N. ordine" sortKey="transmission_id" current={sortKey} dir={sortDir} onClick={toggleSort} />
                <SortableHead label="Tipo" sortKey="tipo" current={sortKey} dir={sortDir} onClick={toggleSort} />
                <SortableHead label="Data trasmissione" sortKey="created_at" current={sortKey} dir={sortDir} onClick={toggleSort} />
                <SortableHead label="N. righe" sortKey="items_count" current={sortKey} dir={sortDir} onClick={toggleSort} align="right" />
                <SortableHead label="Val. €" sortKey="total" current={sortKey} dir={sortDir} onClick={toggleSort} align="right" />
                <TableHead className="text-right">Azioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sorted.map((o) => (
                <TableRow
                  key={o.order_id}
                  className="cursor-pointer hover:bg-accent/40"
                  onClick={() =>
                    setSelectedOrder({
                      id: o.order_id,
                      transmission_id: o.transmission_id,
                      codice_cliente: o.codice_cliente,
                      company_name: o.company_name,
                      created_at: o.created_at,
                      total: o.total,
                      tipo: o.tipo,
                      zone_code: o.zone_code,
                      agent_label: o.codice_agente ?? null,
                      listino: o.listino,
                    })
                  }
                >
                  <TableCell className="whitespace-nowrap"><DateTimeCell value={o.batch_created_at} /></TableCell>
                  <TableCell>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <span className="font-mono text-xs">{initials(o.batch_user_name)}</span>
                      </TooltipTrigger>
                      <TooltipContent>{o.batch_user_name ?? "—"}</TooltipContent>
                    </Tooltip>
                  </TableCell>
                  <TableCell>{o.codice_agente ?? "—"}</TableCell>
                  <TableCell className="font-bold">{o.zone_code ?? "—"}</TableCell>
                  <TableCell>{o.codice_cliente ?? "—"}</TableCell>
                  <TableCell className="font-bold">{o.company_name ?? "—"}</TableCell>
                  <TableCell>
                    <div className="inline-flex items-center gap-1.5">
                      <span className="text-xs text-muted-foreground">{o.transmission_id ?? "—"}</span>
                      {o.note && o.note.trim().length > 0 && (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span
                              className="inline-flex items-center text-amber-600 cursor-help"
                              onClick={(e) => e.stopPropagation()}
                              aria-label="Ordine con nota"
                            >
                              <StickyNote className="h-4 w-4" />
                            </span>
                          </TooltipTrigger>
                          <TooltipContent side="top" className="max-w-sm">
                            <div className="text-xs font-semibold mb-1">Nota ordine</div>
                            <div className="text-xs whitespace-pre-wrap">
                              {o.note.length > 400 ? o.note.slice(0, 400) + "…" : o.note}
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      )}
                    </div>
                  </TableCell>
                  <TableCell><TipoBadge tipo={o.tipo} /></TableCell>
                  <TableCell className="whitespace-nowrap"><DateTimeCell value={o.created_at} /></TableCell>
                  <TableCell className="text-right">{o.items_count}</TableCell>
                  <TableCell className="text-right">{fmtEuro(o.total)}</TableCell>
                  <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <span className="inline-block">
                          {canDownload ? (
                            <RegenerateBatchButton batchId={o.batch_id} fileName={o.batch_file_name} />
                          ) : (
                            <span className="text-xs text-muted-foreground">—</span>
                          )}
                        </span>
                      </TooltipTrigger>
                      <TooltipContent>{canDownload ? "Download txt intero scarico" : "Permesso scarico non concesso"}</TooltipContent>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <OrderDetailSheet order={selectedOrder} onClose={() => setSelectedOrder(null)} />
        </div>
        )}
      </div>
    </TooltipProvider>
  );
}

export const DownloadedOrdersTabIcon = PackageCheck;

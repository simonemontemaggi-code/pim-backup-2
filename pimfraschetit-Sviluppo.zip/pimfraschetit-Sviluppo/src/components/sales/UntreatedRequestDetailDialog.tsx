import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  CheckCircle2,
  Circle,
  FileText,
  PackageCheck,
  Send,
  ShoppingCart,
  Truck,
  XCircle,
  Pencil,
  Sparkles,
  ThumbsDown,
  ThumbsUp,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

interface RequestRow {
  id: string;
  fornitore: string;
  codice_articolo_fornitore: string;
  descrizione: string;
  quantita: number;
  nota: string | null;
  cliente_codice: string;
  cliente_nominativo: string;
  agente_codice: string | null;
  agente_cognome: string | null;
  agente_nome: string | null;
  created_at: string;
  created_by?: string | null;
  status_updated_at: string | null;
  status_updated_by?: string | null;
  stato: string;
  confermato: boolean | null;
  confermato_at?: string | null;
  preventivo_note: string | null;
  preventivo_note_at?: string | null;
  preventivo_note_by?: string | null;
  chiuso_da: "vendite" | "acquisti" | null;
  chiusura_motivo: string | null;
  chiuso_at?: string | null;
  chiuso_by?: string | null;
  cdpar_codificato: string | null;
  codificato_at?: string | null;
  codificato_by?: string | null;
  ordine_cliente_ref: string | null;
  ordine_cliente_at?: string | null;
  ordine_cliente_by?: string | null;
  ordine_fornitore_ref: string | null;
  ordine_fornitore_at?: string | null;
  ordine_fornitore_by?: string | null;
  in_arrivo_at?: string | null;
  in_arrivo_by?: string | null;
  arrivato_at?: string | null;
  arrivato_by?: string | null;
  edited_at?: string | null;
  edited_by?: string | null;
}

interface Props {
  open: boolean;
  request: RequestRow | null;
  onOpenChange: (open: boolean) => void;
}

function fmt(iso?: string | null) {
  if (!iso) return "";
  try {
    return new Date(iso).toLocaleString("it-IT", { dateStyle: "short", timeStyle: "short" });
  } catch {
    return iso;
  }
}

type TimelineEvent = {
  key: string;
  label: string;
  at: string;
  userId?: string | null;
  fallbackUser?: string;
  icon: React.ComponentType<{ className?: string }>;
  tone: string;
  extra?: string;
};

export default function UntreatedRequestDetailDialog({ open, request, onOpenChange }: Props) {
  const userIds = useMemo(() => {
    if (!request) return [] as string[];
    return Array.from(
      new Set(
        [
          request.created_by,
          request.status_updated_by,
          request.preventivo_note_by,
          request.chiuso_by,
          request.codificato_by,
          request.ordine_cliente_by,
          request.ordine_fornitore_by,
          request.arrivato_by,
          request.edited_by,
        ].filter((v): v is string => !!v),
      ),
    );
  }, [request]);

  const { data: displayMap } = useQuery({
    queryKey: ["untreated-detail-display-names", userIds.sort().join(",")],
    enabled: open && userIds.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_user_display_names", { _ids: userIds });
      if (error) throw error;
      const map: Record<string, { display: string | null; email: string | null }> = {};
      (data ?? []).forEach((r: any) => {
        map[r.id] = { display: r.display ?? null, email: r.email ?? null };
      });
      return map;
    },
  });

  const userName = (id?: string | null, fallback?: string) => {
    if (!id) return fallback ?? "—";
    const r = displayMap?.[id];
    return r?.display || fallback || r?.email || id.slice(0, 8);
  };

  const events = useMemo<TimelineEvent[]>(() => {
    if (!request) return [];
    const agente = [request.agente_cognome, request.agente_nome].filter(Boolean).join(" ") || undefined;
    const list: TimelineEvent[] = [];
    list.push({
      key: "created",
      label: "Richiesta creata",
      at: request.created_at,
      userId: request.created_by,
      fallbackUser: agente,
      icon: Sparkles,
      tone: "text-amber-600 bg-amber-100",
    });
    if (request.status_updated_at && request.stato !== "in_lavorazione") {
      // status_updated_at reflects the latest state change; we still show it if past initial state
      list.push({
        key: "sent-purchases",
        label: "Inviata ad Acquisti",
        at: request.status_updated_at,
        userId: request.status_updated_by,
        icon: Send,
        tone: "text-blue-700 bg-blue-100",
      });
    }
    if (request.preventivo_note_at) {
      list.push({
        key: "preventivo",
        label: "Preventivo creato",
        at: request.preventivo_note_at,
        userId: request.preventivo_note_by,
        icon: FileText,
        tone: "text-violet-700 bg-violet-100",
        extra: request.preventivo_note ?? undefined,
      });
    }
    if (request.confermato_at) {
      const accepted = request.confermato === true;
      list.push({
        key: "decision",
        label: accepted ? "Preventivo accettato" : "Preventivo rifiutato",
        at: request.confermato_at,
        fallbackUser: agente,
        icon: accepted ? ThumbsUp : ThumbsDown,
        tone: accepted ? "text-emerald-700 bg-emerald-100" : "text-rose-700 bg-rose-100",
      });
    }
    if (request.codificato_at) {
      list.push({
        key: "codificato",
        label: "Articolo codificato",
        at: request.codificato_at,
        userId: request.codificato_by,
        icon: CheckCircle2,
        tone: "text-cyan-700 bg-cyan-100",
        extra: request.cdpar_codificato ? `Cdpar: ${request.cdpar_codificato.trim()}` : undefined,
      });
    }
    if (request.ordine_cliente_at) {
      list.push({
        key: "ordine-cliente",
        label: "Ordine cliente creato",
        at: request.ordine_cliente_at,
        userId: request.ordine_cliente_by,
        icon: ShoppingCart,
        tone: "text-indigo-700 bg-indigo-100",
        extra: request.ordine_cliente_ref ?? undefined,
      });
    }
    if (request.ordine_fornitore_at) {
      list.push({
        key: "ordine-fornitore",
        label: "Ordine fornitore inviato",
        at: request.ordine_fornitore_at,
        userId: request.ordine_fornitore_by,
        icon: Truck,
        tone: "text-sky-700 bg-sky-100",
        extra: request.ordine_fornitore_ref ?? undefined,
      });
    }
    if (request.in_arrivo_at) {
      list.push({
        key: "in-arrivo",
        label: "Ordine fornitore effettuato · in arrivo",
        at: request.in_arrivo_at,
        userId: request.in_arrivo_by,
        icon: Truck,
        tone: "text-orange-700 bg-orange-100",
      });
    }
    if (request.arrivato_at) {
      list.push({
        key: "arrivato",
        label: "Merce arrivata",
        at: request.arrivato_at,
        userId: request.arrivato_by,
        icon: PackageCheck,
        tone: "text-teal-700 bg-teal-100",
      });
    }
    if (request.chiuso_at) {
      const isNull = request.stato === "nulla";
      list.push({
        key: "closed",
        label: isNull ? "Richiesta annullata" : "Richiesta chiusa",
        at: request.chiuso_at,
        userId: request.chiuso_by,
        fallbackUser: request.chiuso_da === "vendite" ? "Vendite" : request.chiuso_da === "acquisti" ? "Acquisti" : undefined,
        icon: XCircle,
        tone: isNull ? "text-rose-700 bg-rose-100" : "text-slate-700 bg-slate-200",
        extra: request.chiusura_motivo ?? undefined,
      });
    }
    if (request.edited_at) {
      list.push({
        key: "edited",
        label: "Ultima modifica dati",
        at: request.edited_at,
        userId: request.edited_by,
        icon: Pencil,
        tone: "text-orange-700 bg-orange-100",
      });
    }
    return list.sort((a, b) => new Date(a.at).getTime() - new Date(b.at).getTime());
  }, [request]);

  if (!request) return null;

  const agenteNome = [request.agente_cognome, request.agente_nome].filter(Boolean).join(" ");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            Dettaglio richiesta
            <Badge variant="secondary" className="font-mono text-[10px]">
              #{request.id.slice(0, 8)}
            </Badge>
          </DialogTitle>
          <DialogDescription>
            Informazioni complete e cronologia stati.
          </DialogDescription>
        </DialogHeader>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Info */}
          <div className="space-y-3 text-sm">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Informazioni</h3>
            <InfoRow label="Cliente" value={`${request.cliente_codice} — ${request.cliente_nominativo}`} />
            <InfoRow
              label="Agente"
              value={request.agente_codice ? `${request.agente_codice}${agenteNome ? ` — ${agenteNome}` : ""}` : "—"}
            />
            <InfoRow label="Fornitore" value={request.fornitore || "—"} />
            <InfoRow label="Cod. articolo" value={request.codice_articolo_fornitore || "—"} mono />
            <InfoRow label="Descrizione" value={request.descrizione || "—"} />
            <InfoRow label="Quantità" value={String(request.quantita ?? 0)} />
            {request.nota && <InfoRow label="Nota" value={request.nota} multiline />}
            {request.preventivo_note && <InfoRow label="Nota preventivo" value={request.preventivo_note} multiline />}
            {request.cdpar_codificato && <InfoRow label="Cdpar" value={request.cdpar_codificato.trim()} mono />}
            {request.ordine_cliente_ref && <InfoRow label="Rif. ord. cliente" value={request.ordine_cliente_ref} mono />}
            {request.ordine_fornitore_ref && <InfoRow label="Rif. ord. fornitore" value={request.ordine_fornitore_ref} mono />}
            {request.chiusura_motivo && (
              <InfoRow
                label={request.stato === "nulla" ? "Motivo annullamento" : "Motivo chiusura"}
                value={request.chiusura_motivo}
                multiline
              />
            )}
          </div>

          {/* Timeline */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Cronologia stati</h3>
            <ol className="relative border-l border-border ml-3 space-y-4">
              {events.map((ev) => {
                const Icon = ev.icon;
                return (
                  <li key={ev.key} className="pl-6 relative">
                    <span
                      className={cn(
                        "absolute -left-[13px] top-0 flex h-6 w-6 items-center justify-center rounded-full ring-4 ring-background",
                        ev.tone,
                      )}
                    >
                      <Icon className="h-3.5 w-3.5" />
                    </span>
                    <div className="text-sm font-medium leading-tight">{ev.label}</div>
                    <div className="text-xs text-muted-foreground tabular-nums">
                      {fmt(ev.at)} · {userName(ev.userId, ev.fallbackUser)}
                    </div>
                    {ev.extra && (
                      <div className="mt-1 text-xs bg-muted/50 rounded px-2 py-1 whitespace-pre-wrap break-words">
                        {ev.extra}
                      </div>
                    )}
                  </li>
                );
              })}
              {events.length === 0 && (
                <li className="pl-6 relative text-sm text-muted-foreground">
                  <Circle className="absolute -left-[9px] top-1 h-3 w-3" />
                  Nessun evento registrato.
                </li>
              )}
            </ol>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function InfoRow({ label, value, mono, multiline }: { label: string; value: string; mono?: boolean; multiline?: boolean }) {
  return (
    <div className="grid grid-cols-[110px_1fr] gap-2 items-start">
      <span className="text-xs text-muted-foreground pt-0.5">{label}</span>
      <span
        className={cn(
          "text-sm break-words",
          mono && "font-mono text-xs",
          multiline && "whitespace-pre-wrap",
        )}
      >
        {value}
      </span>
    </div>
  );
}

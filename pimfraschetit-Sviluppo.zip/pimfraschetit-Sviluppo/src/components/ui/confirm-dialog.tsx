import { createContext, useCallback, useContext, useRef, useState, ReactNode } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface ConfirmOptions {
  title?: string;
  description?: string;
  confirmText?: string;
  cancelText?: string;
  destructive?: boolean;
}

interface PromptOptions {
  title?: string;
  description?: string;
  defaultValue?: string;
  placeholder?: string;
  confirmText?: string;
  cancelText?: string;
}

interface DialogsContextType {
  confirm: (opts: ConfirmOptions) => Promise<boolean>;
  prompt: (opts: PromptOptions) => Promise<string | null>;
}

const DialogsContext = createContext<DialogsContextType | null>(null);

export function DialogsProvider({ children }: { children: ReactNode }) {
  const [confirmState, setConfirmState] = useState<(ConfirmOptions & { open: boolean }) | null>(null);
  const [promptState, setPromptState] = useState<(PromptOptions & { open: boolean; value: string }) | null>(null);
  const confirmResolver = useRef<((v: boolean) => void) | null>(null);
  const promptResolver = useRef<((v: string | null) => void) | null>(null);

  const confirm = useCallback((opts: ConfirmOptions) => {
    setConfirmState({ ...opts, open: true });
    return new Promise<boolean>((resolve) => {
      confirmResolver.current = resolve;
    });
  }, []);

  const prompt = useCallback((opts: PromptOptions) => {
    setPromptState({ ...opts, open: true, value: opts.defaultValue ?? "" });
    return new Promise<string | null>((resolve) => {
      promptResolver.current = resolve;
    });
  }, []);

  const handleConfirm = (result: boolean) => {
    confirmResolver.current?.(result);
    confirmResolver.current = null;
    setConfirmState((s) => (s ? { ...s, open: false } : null));
  };

  const handlePrompt = (result: string | null) => {
    promptResolver.current?.(result);
    promptResolver.current = null;
    setPromptState((s) => (s ? { ...s, open: false } : null));
  };

  return (
    <DialogsContext.Provider value={{ confirm, prompt }}>
      {children}

      <AlertDialog
        open={confirmState?.open ?? false}
        onOpenChange={(o) => { if (!o) handleConfirm(false); }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{confirmState?.title ?? "Conferma"}</AlertDialogTitle>
            {confirmState?.description && (
              <AlertDialogDescription className="whitespace-pre-line">
                {confirmState.description}
              </AlertDialogDescription>
            )}
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => handleConfirm(false)}>
              {confirmState?.cancelText ?? "Annulla"}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => handleConfirm(true)}
              className={confirmState?.destructive ? "bg-destructive text-destructive-foreground hover:bg-destructive/90" : undefined}
            >
              {confirmState?.confirmText ?? "Conferma"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog
        open={promptState?.open ?? false}
        onOpenChange={(o) => { if (!o) handlePrompt(null); }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{promptState?.title ?? "Inserisci valore"}</DialogTitle>
            {promptState?.description && (
              <DialogDescription>{promptState.description}</DialogDescription>
            )}
          </DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handlePrompt(promptState?.value ?? "");
            }}
          >
            <Input
              autoFocus
              value={promptState?.value ?? ""}
              placeholder={promptState?.placeholder}
              onChange={(e) =>
                setPromptState((s) => (s ? { ...s, value: e.target.value } : null))
              }
            />
            <DialogFooter className="mt-4">
              <Button type="button" variant="outline" onClick={() => handlePrompt(null)}>
                {promptState?.cancelText ?? "Annulla"}
              </Button>
              <Button type="submit">{promptState?.confirmText ?? "Conferma"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </DialogsContext.Provider>
  );
}

export function useConfirm() {
  const ctx = useContext(DialogsContext);
  if (!ctx) throw new Error("useConfirm must be used within DialogsProvider");
  return ctx.confirm;
}

export function usePrompt() {
  const ctx = useContext(DialogsContext);
  if (!ctx) throw new Error("usePrompt must be used within DialogsProvider");
  return ctx.prompt;
}

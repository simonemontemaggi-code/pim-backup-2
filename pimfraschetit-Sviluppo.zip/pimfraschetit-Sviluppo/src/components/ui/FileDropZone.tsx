import { useCallback, useEffect, useRef, useState } from "react";
import { Upload } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileDropZoneProps {
  accept?: string;
  multiple?: boolean;
  disabled?: boolean;
  label: string;
  className?: string;
  onFiles: (files: File[]) => void;
}

/**
 * Unified drag-and-drop + click file upload zone.
 * Uses useEffect listeners on document to prevent native browser drop,
 * and capture-phase handlers on the zone itself for reliable event interception.
 */
export function FileDropZone({
  accept,
  multiple = true,
  disabled = false,
  label,
  className,
  onFiles,
}: FileDropZoneProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const zoneRef = useRef<HTMLDivElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const dragCounter = useRef(0);

  // Prevent browser-level native drop (navigates away) while this component is mounted
  useEffect(() => {
    const preventNativeDrop = (e: DragEvent) => {
      // Only prevent if not inside our zone
      if (zoneRef.current && !zoneRef.current.contains(e.target as Node)) {
        e.preventDefault();
        e.dataTransfer && (e.dataTransfer.dropEffect = "none");
      }
    };
    const preventNativeDragOver = (e: DragEvent) => {
      if (zoneRef.current && !zoneRef.current.contains(e.target as Node)) {
        e.preventDefault();
        e.dataTransfer && (e.dataTransfer.dropEffect = "none");
      }
    };

    document.addEventListener("drop", preventNativeDrop, true);
    document.addEventListener("dragover", preventNativeDragOver, true);
    return () => {
      document.removeEventListener("drop", preventNativeDrop, true);
      document.removeEventListener("dragover", preventNativeDragOver, true);
    };
  }, []);

  // Use native addEventListener in capture phase for reliability inside portals/iframes
  useEffect(() => {
    const zone = zoneRef.current;
    if (!zone || disabled) return;

    const handleDragEnter = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      dragCounter.current++;
      if (e.dataTransfer) e.dataTransfer.dropEffect = "copy";
      setIsDragOver(true);
    };

    const handleDragOver = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.dataTransfer) e.dataTransfer.dropEffect = "copy";
    };

    const handleDragLeave = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      dragCounter.current--;
      if (dragCounter.current <= 0) {
        dragCounter.current = 0;
        setIsDragOver(false);
      }
    };

    const handleDrop = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      dragCounter.current = 0;
      setIsDragOver(false);

      const files = e.dataTransfer?.files;
      if (files && files.length > 0) {
        onFiles(Array.from(files));
      }
    };

    zone.addEventListener("dragenter", handleDragEnter, true);
    zone.addEventListener("dragover", handleDragOver, true);
    zone.addEventListener("dragleave", handleDragLeave, true);
    zone.addEventListener("drop", handleDrop, true);

    return () => {
      zone.removeEventListener("dragenter", handleDragEnter, true);
      zone.removeEventListener("dragover", handleDragOver, true);
      zone.removeEventListener("dragleave", handleDragLeave, true);
      zone.removeEventListener("drop", handleDrop, true);
    };
  }, [disabled, onFiles]);

  const handleClick = useCallback(() => {
    if (!disabled) inputRef.current?.click();
  }, [disabled]);

  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files;
      if (files && files.length > 0) {
        onFiles(Array.from(files));
      }
      // Reset so the same file can be re-selected
      e.target.value = "";
    },
    [onFiles]
  );

  return (
    <div
      ref={zoneRef}
      onClick={handleClick}
      className={cn(
        "border-2 border-dashed rounded-lg p-4 text-center transition-colors",
        disabled
          ? "cursor-not-allowed opacity-60"
          : "cursor-pointer hover:border-primary/50",
        isDragOver && !disabled && "border-primary bg-primary/5 ring-2 ring-primary/20",
        className
      )}
    >
      <Upload className="mx-auto h-5 w-5 text-muted-foreground mb-1" />
      <span className="text-xs text-muted-foreground">
        {isDragOver ? "Rilascia i file qui" : label}
      </span>
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple={multiple}
        className="hidden"
        disabled={disabled}
        onChange={handleInputChange}
      />
    </div>
  );
}

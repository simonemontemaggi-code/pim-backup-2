import { useRef, useState } from "react";
import * as XLSX from "xlsx";
import { Loader2, Upload, FileSpreadsheet, AlertCircle, CheckCircle2, Download } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { pad6Cdpar } from "@/lib/csvTemplates";
import { yyyymmddToInputValue } from "@/lib/as400DateUtils";
import type { TestataRow } from "./PromoTestateList";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  testata: TestataRow;
  existingSortOrder: number;
  onDone: () => void;
}

interface RawRow {
  nome: string;
  confezioni: number | null;
  sconto: number | null;
  cdpar: string;
}

interface Grouped {
  nome: string;
  confezioni: number | null;
  sconto: number | null;
  cdpars: string[];
}

const normCdpar = (v: string | null | undefined) => pad6Cdpar(v ?? "");
const padCdpar = (v: string) => normCdpar(v).padEnd(15, " ");

const numOrNull = (v: any): number | null => {
  if (v == null || v === "") return null;
  const s = String(v).trim().replace("%", "").replace(",", ".");
  const n = parseFloat(s);
  return Number.isFinite(n) ? n : null;
};

function findCol(headers: string[], patterns: RegExp[]): number {
  for (let i = 0; i < headers.length; i++) {
    const h = (headers[i] ?? "").toString().toLowerCase().trim();
    if (patterns.some((p) => p.test(h))) return i;
  }
  return -1;
}

async function parseFile(file: File): Promise<{ rows: RawRow[]; warnings: string[] }> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const aoa = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: "" });
  if (!aoa.length) return { rows: [], warnings: ["File vuoto"] };
  const headers = (aoa[0] ?? []).map((h: any) => String(h ?? ""));
  const warnings: string[] = [];

  let cNome = findCol(headers, [/nome.*offerta|offerta|tema|titolo/]);
  let cConf = findCol(headers, [/confezion/]);
  let cSco = findCol(headers, [/sconto/]);
  let cCd = findCol(headers, [/cdpar|codice.*art|cod.*art|articolo/]);

  // fallback: posizione
  if (cNome < 0) cNome = 0;
  if (cConf < 0) cConf = 1;
  if (cSco < 0) cSco = 2;
  if (cCd < 0) cCd = 3;

  const rows: RawRow[] = [];
  for (let i = 1; i < aoa.length; i++) {
    const r = aoa[i] ?? [];
    if (r.every((v: any) => v === "" || v == null)) continue;
    const nome = String(r[cNome] ?? "").trim();
    const cd = normCdpar(String(r[cCd] ?? "").trim());
    if (!nome || !cd) continue;
    rows.push({
      nome,
      confezioni: numOrNull(r[cConf]),
      sconto: numOrNull(r[cSco]),
      cdpar: cd,
    });
  }
  if (rows.length === 0) warnings.push("Nessuna riga valida trovata");
  return { rows, warnings };
}

function groupRows(rows: RawRow[]): Grouped[] {
  const map = new Map<string, Grouped>();
  for (const r of rows) {
    const key = r.nome;
    if (!map.has(key)) {
      map.set(key, { nome: r.nome, confezioni: r.confezioni, sconto: r.sconto, cdpars: [] });
    }
    const g = map.get(key)!;
    if (g.confezioni == null && r.confezioni != null) g.confezioni = r.confezioni;
    if (g.sconto == null && r.sconto != null) g.sconto = r.sconto;
    if (!g.cdpars.includes(r.cdpar)) g.cdpars.push(r.cdpar);
  }
  return Array.from(map.values());
}

export function BundleImportDialog({ open, onOpenChange, testata, existingSortOrder, onDone }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [rows, setRows] = useState<RawRow[]>([]);
  const [groups, setGroups] = useState<Grouped[]>([]);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [parsing, setParsing] = useState(false);
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState<{ temi: number; articoli: number; skipped: string[] } | null>(null);

  const reset = () => {
    setFile(null); setRows([]); setGroups([]); setWarnings([]); setResult(null);
  };

  const handleFile = async (f: File | null) => {
    if (!f) return;
    setFile(f);
    setParsing(true);
    setResult(null);
    try {
      const res = await parseFile(f);
      setRows(res.rows);
      setGroups(groupRows(res.rows));
      setWarnings(res.warnings);
    } catch (e: any) {
      toast({ title: "Errore parsing", description: e?.message ?? "Errore", variant: "destructive" });
    } finally {
      setParsing(false);
    }
  };

  const yyyymmddOrNull = (v: any): string | null => {
    if (v == null || v === "") return null;
    const s = String(v).trim();
    return /^\d{8}$/.test(s) ? s : null;
  };

  const runImport = async () => {
    if (groups.length === 0) return;
    setImporting(true);
    const wpprgf = testata.wpprgf!;
    const defaultDal = yyyymmddToInputValue(testata.wpdvali) || null;
    const defaultAl = yyyymmddToInputValue(testata.wpdvalf) || null;
    const wdtvi = yyyymmddOrNull((testata as any).wpindoi);
    const wdtvf = yyyymmddOrNull((testata as any).wpindof);

    let createdTemi = 0;
    let linkedArticoli = 0;
    const skipped: string[] = [];

    try {
      // Verifica articoli già usati in altri temi della stessa promo
      const allCdpars = Array.from(new Set(groups.flatMap((g) => g.cdpars)));
      const lookupPadded = allCdpars.map(padCdpar);
      const lookupAll = [...allCdpars, ...lookupPadded];

      // articoli esistenti in archivio — chunk per evitare URL too long su .in()
      const archSet = new Set<string>();
      const CHUNK = 200;
      for (let i = 0; i < lookupAll.length; i += CHUNK) {
        const slice = lookupAll.slice(i, i + CHUNK);
        const { data: archData, error: archErr } = await supabase
          .from("archivio_articoli_fraschetti")
          .select("cdpar")
          .in("cdpar", slice);
        if (archErr) throw archErr;
        for (const r of (archData ?? []) as any[]) archSet.add(normCdpar(r.cdpar));
      }

      // temi esistenti della promo
      const { data: temiData } = await supabase
        .from("promo_strutturate_temi")
        .select("id, wpprgf").eq("wpprgf", wpprgf);
      const temiIds = ((temiData ?? []) as any[]).map((t) => t.id);
      const occupied = new Map<string, string>();
      if (temiIds.length) {
        const { data: linkData } = await supabase
          .from("promo_strutturate_tema_articoli")
          .select("tema_id, cdpar").in("tema_id", temiIds);
        for (const l of (linkData ?? []) as any[]) {
          occupied.set(normCdpar(l.cdpar), l.tema_id);
        }
      }

      // pool articoli già presenti nella promo
      const { data: poolData } = await supabase
        .from("promo_strutturate_articoli" as any)
        .select("cdpar").eq("wpprgf", wpprgf);
      const poolSet = new Set<string>(((poolData ?? []) as any[]).map((r: any) => normCdpar(r.cdpar)));

      let sortIdx = existingSortOrder;

      for (const g of groups) {
        const validCdpars: string[] = [];
        for (const c of g.cdpars) {
          if (!archSet.has(c)) { skipped.push(`${c} (non trovato in archivio) — offerta "${g.nome}"`); continue; }
          if (occupied.has(c)) { skipped.push(`${c} (già in un'altra offerta) — "${g.nome}"`); continue; }
          validCdpars.push(c);
        }

        // crea tema
        const { data: tema, error: teErr } = await supabase
          .from("promo_strutturate_temi")
          .insert({
            wpprgf,
            nome: g.nome,
            sort_order: sortIdx++,
            tipo: "bundle",
            dal: defaultDal,
            al: defaultAl,
            bundle_confezioni: g.confezioni,
            sconto_pct: g.sconto,
          } as any)
          .select("id").single();
        if (teErr || !tema) throw teErr ?? new Error("Insert tema fallito");
        createdTemi++;

        if (validCdpars.length === 0) continue;

        // pool
        const toInsertPool = validCdpars.filter((c) => !poolSet.has(c));
        if (toInsertPool.length) {
          const poolRows = toInsertPool.map((c) => ({
            wpprgf, wpprge: null, cdpar: c, source: "manual", wdtvi, wdtvf,
          }));
          const { error: poolErr } = await supabase
            .from("promo_strutturate_articoli" as any)
            .upsert(poolRows as any, { onConflict: "wpprgf,wpprge,cdpar", ignoreDuplicates: true });
          if (poolErr) throw poolErr;
          toInsertPool.forEach((c) => poolSet.add(c));
        }

        // link
        const linkRows = validCdpars.map((c) => ({ tema_id: tema.id, cdpar: padCdpar(c) }));
        const { error: linkErr } = await supabase
          .from("promo_strutturate_tema_articoli")
          .upsert(linkRows as any, { onConflict: "tema_id,cdpar", ignoreDuplicates: true });
        if (linkErr) throw linkErr;
        linkedArticoli += validCdpars.length;
        validCdpars.forEach((c) => occupied.set(c, tema.id));
      }

      setResult({ temi: createdTemi, articoli: linkedArticoli, skipped });
      toast({ title: "Import completato", description: `${createdTemi} offerte, ${linkedArticoli} articoli` });
      onDone();
    } catch (e: any) {
      toast({ title: "Errore import", description: e?.message ?? "Errore", variant: "destructive" });
    } finally {
      setImporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) reset(); onOpenChange(v); }}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5 text-primary" /> Import offerte Bundle
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="text-xs text-muted-foreground">
            Carica un file XLSX con colonne: <b>Nome offerta</b>, <b>N° confezioni richieste</b>, <b>Sconto %</b>, <b>Codice articolo</b>.
            Le righe con lo stesso nome offerta verranno raggruppate. Verrà creata un'offerta Bundle per ogni nome distinto, con gli articoli collegati.
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <input ref={inputRef} type="file" accept=".xlsx,.xls" className="hidden"
              onChange={(e) => handleFile(e.target.files?.[0] ?? null)} />
            <Button variant="outline" onClick={() => inputRef.current?.click()} disabled={parsing || importing}>
              <Upload className="h-4 w-4 mr-2" />
              {file ? `${file.name} — ${(file.size / 1024).toFixed(1)} KB` : "Seleziona file XLSX"}
            </Button>
            <Button variant="ghost" size="sm" onClick={() => {
              const aoa = [
                ["Nome offerta", "N° confezioni richieste", "Sconto %", "Codice articolo"],
                ["Offerta Primavera", 3, 10, "499315"],
                ["Offerta Primavera", 3, 10, "499316"],
                ["Offerta Primavera", 3, 10, "499317"],
                ["Bundle Estate", 5, 15, "499320"],
                ["Bundle Estate", 5, 15, "499321"],
              ];
              const ws = XLSX.utils.aoa_to_sheet(aoa);
              ws["!cols"] = [{ wch: 24 }, { wch: 22 }, { wch: 10 }, { wch: 16 }];
              const wb = XLSX.utils.book_new();
              XLSX.utils.book_append_sheet(wb, ws, "Bundle");
              XLSX.writeFile(wb, "esempio-import-bundle.xlsx");
            }}>
              <Download className="h-4 w-4 mr-2" /> Scarica esempio
            </Button>
          </div>

          {parsing && <div className="text-sm text-muted-foreground flex items-center gap-2"><Loader2 className="h-3 w-3 animate-spin" /> Lettura file…</div>}

          {warnings.length > 0 && (
            <Alert><AlertCircle className="h-4 w-4" /><AlertDescription>{warnings.join(" · ")}</AlertDescription></Alert>
          )}

          {!result && groups.length > 0 && (
            <>
              <div className="flex flex-wrap items-center gap-2">
                <Badge>{groups.length} offerte da creare</Badge>
                <Badge variant="secondary">{rows.length} righe articolo</Badge>
              </div>
              <ScrollArea className="h-[280px] border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs">Nome offerta</TableHead>
                      <TableHead className="text-xs">N° confezioni</TableHead>
                      <TableHead className="text-xs">Sconto %</TableHead>
                      <TableHead className="text-xs">Articoli</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {groups.map((g) => (
                      <TableRow key={g.nome}>
                        <TableCell className="text-xs font-medium">{g.nome}</TableCell>
                        <TableCell className="text-xs">{g.confezioni ?? "—"}</TableCell>
                        <TableCell className="text-xs">{g.sconto ?? "—"}</TableCell>
                        <TableCell className="text-xs font-mono">{g.cdpars.join(", ")}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </>
          )}

          {result && (
            <div className="rounded-lg border p-4 space-y-2">
              <div className="flex items-center gap-2 font-medium text-sm">
                <CheckCircle2 className="h-4 w-4 text-green-600" /> Import completato
              </div>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-green-600">{result.temi} offerte create</Badge>
                <Badge className="bg-blue-600">{result.articoli} articoli collegati</Badge>
                {result.skipped.length > 0 && <Badge variant="outline">{result.skipped.length} scartati</Badge>}
              </div>
              {result.skipped.length > 0 && (
                <ScrollArea className="h-[140px] mt-2 border rounded p-2 text-xs space-y-1">
                  {result.skipped.map((s, i) => <div key={i} className="text-muted-foreground">• {s}</div>)}
                </ScrollArea>
              )}
            </div>
          )}
        </div>

        <DialogFooter>
          {!result ? (
            <>
              <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={importing}>Annulla</Button>
              <Button onClick={runImport} disabled={importing || groups.length === 0}>
                {importing ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : null}
                Importa {groups.length > 0 && `(${groups.length} offerte)`}
              </Button>
            </>
          ) : (
            <Button onClick={() => onOpenChange(false)}>Chiudi</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

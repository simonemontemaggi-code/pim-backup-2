import { useEffect, useState } from "react";
import { Lock } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { PromoTestataForm } from "./PromoTestataForm";
import { PromoArticoliTab } from "./PromoArticoliTab";
import { PromoTemiTab } from "./PromoTemiTab";
import { PromoSblocchiTab } from "./PromoSblocchiTab";
import { PromoDestinatariTab } from "./PromoDestinatariTab";
import { PromoCoverUploader } from "./PromoCoverUploader";
import { usePermissions } from "@/lib/permissions";

import type { TestataRow } from "./PromoTestateList";

interface Props {
  testata: TestataRow;
  onSaved: () => void;
}

export function PromoTestataDetail({ testata, onSaved }: Props) {
  const { can, canField } = usePermissions();
  const canWrite = can("write", "promo_strutturate");
  // Field-level override sulla section Promo Strutturate (es. admin può mettere "Immagine promo" o "Tab Offerte" in sola lettura)
  const canEditCover = canWrite && canField("write", "promo_strutturate", "promo_cover_image");
  const canEditOfferte = canWrite && canField("write", "promo_strutturate", "promo_offerte_tab");
  const showSblocchi = !!testata.unlock_enabled;
  const [tab, setTab] = useState("generale");
  const [dirty, setDirty] = useState(false);
  const [pendingTab, setPendingTab] = useState<string | null>(null);

  useEffect(() => {
    setTab("generale");
    setDirty(false);
    setPendingTab(null);
  }, [testata.id]);

  const handleTabChange = (next: string) => {
    if (next === tab) return;
    if (dirty && tab === "generale") {
      setPendingTab(next);
      return;
    }
    setTab(next);
  };

  return (
    <>
      <Tabs value={tab} onValueChange={handleTabChange} className="flex h-full min-h-0 flex-col overflow-hidden">
        <TabsList className="self-start">
          <TabsTrigger value="generale">Generale</TabsTrigger>
          <TabsTrigger value="destinatari">Destinatari</TabsTrigger>
          <TabsTrigger value="temi">Offerte</TabsTrigger>
          <TabsTrigger value="articoli">Articoli</TabsTrigger>
          
          {showSblocchi && <TabsTrigger value="sblocchi">Sblocchi</TabsTrigger>}
        </TabsList>
        <div className="min-h-0 flex-1 overflow-hidden pt-3">
          <TabsContent value="generale" className="mt-0 h-full overflow-auto space-y-4">
            <PromoCoverUploader
              wpprgf={testata.wpprgf ?? null}
              value={(testata as any).cover_image_url ?? null}
              onChange={() => onSaved()}
              canEdit={canEditCover}
            />
            <fieldset
              disabled={!canWrite}
              className={!canWrite ? "opacity-90 [&_button]:!cursor-not-allowed" : undefined}
              style={!canWrite ? { pointerEvents: "auto" } : undefined}
            >
              <PromoTestataForm testata={testata} onSaved={onSaved} onDirtyChange={setDirty} />
            </fieldset>
          </TabsContent>
          <TabsContent value="temi" className="mt-0 h-full min-h-0 overflow-hidden data-[state=active]:flex flex-col">
            <PromoTemiTab testata={testata} canEdit={canEditOfferte} />
          </TabsContent>
          <fieldset
            disabled={!canWrite}
            className={`min-h-0 h-full ${!canWrite ? "opacity-90 [&_button]:!cursor-not-allowed" : ""}`}
            style={!canWrite ? { pointerEvents: "auto" } : undefined}
          >
            <TabsContent value="destinatari" className="mt-0 h-full overflow-auto">
              <PromoDestinatariTab testata={testata} onSaved={onSaved} />
            </TabsContent>
            <TabsContent value="articoli" className="mt-0 h-full overflow-auto">
              <PromoArticoliTab testata={testata} />
            </TabsContent>
            {showSblocchi && (
              <TabsContent value="sblocchi" className="mt-0 h-full overflow-auto">
                <PromoSblocchiTab testata={testata} />
              </TabsContent>
            )}
          </fieldset>
        </div>
      </Tabs>

      <AlertDialog open={!!pendingTab} onOpenChange={(o) => !o && setPendingTab(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Modifiche non salvate</AlertDialogTitle>
            <AlertDialogDescription>
              Hai modifiche non salvate nella scheda Generale. Se cambi tab le perderai. Vuoi continuare?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (pendingTab) {
                  setDirty(false);
                  setTab(pendingTab);
                  setPendingTab(null);
                }
              }}
            >
              Scarta modifiche
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

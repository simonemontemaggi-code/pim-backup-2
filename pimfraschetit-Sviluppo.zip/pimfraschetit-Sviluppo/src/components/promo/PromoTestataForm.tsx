import { useEffect, useMemo, useRef, useState } from "react";
import { Save, ChevronDown, ChevronRight as ChevR, Settings2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { PromoField } from "./PromoField";
import { TESTATE_FIELDS, computePromoStato, computePromoValidita, TESTATA_FORCED_VALUES, TESTATA_PIM_ONLY_FIELDS } from "./fields";
import { usePromoSave } from "@/hooks/usePromoSave";


import { ListiniExcludePicker } from "./ListiniExcludePicker";
import { ReconcileListiniDialog } from "./ReconcileListiniDialog";
import {
  computeTargetListini,
  previewReconcile,
  applyReconcile,
  padCdlst,
  type ReconcilePreviewItem,
} from "@/lib/promoListini";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "@/hooks/use-toast";
import { exportAs400Change } from "@/lib/as400Export";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import type { TestataRow } from "./PromoTestateList";

interface Props {
  testata: TestataRow;
  onSaved: () => void;
  onDirtyChange?: (dirty: boolean) => void;
}

export function PromoTestataForm({ testata, onSaved, onDirtyChange }: Props) {
  const [values, setValues] = useState<Record<string, any>>({});
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [reconcileOpen, setReconcileOpen] = useState(false);
  const [reconcilePreview, setReconcilePreview] = useState<{
    items: ReconcilePreviewItem[];
    totalAdd: number;
    totalRemove: number;
    affectedElements: number;
  } | null>(null);
  const [reconcileLoading, setReconcileLoading] = useState(false);
  const initialRef = useRef<string>("");
  const qc = useQueryClient();
  const { user, profile } = useAuth();

  useEffect(() => {
    const init = {
      ...testata,
      excluded_listini: ((testata as any).excluded_listini ?? []).map(padCdlst),
    };
    setValues(init);
    initialRef.current = JSON.stringify(init);
    onDirtyChange?.(false);
  }, [testata.id]);

  // Sync cover_image_url when changed externally (PromoCoverUploader)
  // to evitare che il successivo save del form patchi null e cancelli la cover.
  useEffect(() => {
    const extUrl = (testata as any).cover_image_url ?? null;
    setValues((s) => {
      if (!s || Object.keys(s).length === 0) return s;
      if ((s.cover_image_url ?? null) === extUrl) return s;
      const next = { ...s, cover_image_url: extUrl };
      try {
        const baseline = JSON.parse(initialRef.current || "{}");
        baseline.cover_image_url = extUrl;
        initialRef.current = JSON.stringify(baseline);
      } catch {}
      return next;
    });
  }, [(testata as any).cover_image_url]);

  const dirty = useMemo(() => {
    if (!initialRef.current) return false;
    return JSON.stringify(values) !== initialRef.current;
  }, [values]);

  useEffect(() => {
    onDirtyChange?.(dirty);
  }, [dirty]);

  // Autosave silenzioso su modifica campi: salta se cambia la copertura listini
  // (richiede reconcile manuale), se wpcca non è valido o se mancano obbligatori.
  useEffect(() => {
    if (!dirty || save.isPending) return;
    const oldExcluded = ((testata as any).excluded_listini ?? []).map(padCdlst).sort().join(",");
    const newExcluded = ((values.excluded_listini ?? []) as string[]).map(padCdlst).sort().join(",");
    const coperturaChanged =
      (testata as any).wpinls !== values.wpinls || oldExcluded !== newExcluded;
    if (coperturaChanged) return;

    const ccaRaw = String(values.wpcca ?? "").trim().toUpperCase();
    if (!/^[A-Z0-9]{8}$/.test(ccaRaw)) return;

    const requiredDefs = TESTATE_FIELDS.filter((f) => f.required && !f.readOnly);
    const missing = requiredDefs.some((f) => {
      const v = values[f.key];
      return v === null || v === undefined || v === "" || v === 0;
    });
    if (missing) return;

    const t = setTimeout(() => {
      const snapshot = JSON.stringify(values);
      save.mutate(
        {
          newValues: {
            ...values,
            ...TESTATA_FORCED_VALUES,
            wpstato: computedStato,
            wpdvali: computedValidita.wpdvali,
            wpdvalf: computedValidita.wpdvalf,
          },
          operation: "update",
        },
        {
          onSuccess: () => {
            initialRef.current = snapshot;
            onDirtyChange?.(false);
            onSaved();
          },
        },
      );
    }, 800);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [values, dirty]);

  // Stato calcolato dall'unione degli intervalli sell-in / sell-out
  const computedStato = useMemo(
    () => computePromoStato(values, values.wpstato),
    [values.wpindii, values.wpindif, values.wpindoi, values.wpindof, values.wpstato],
  );

  // Validità globale calcolata (min inizio / max fine)
  const computedValidita = useMemo(
    () => computePromoValidita(values),
    [values.wpindii, values.wpindif, values.wpindoi, values.wpindof],
  );

  const save = usePromoSave({
    table: "promo_strutturate_testate",
    keyColumns: { wprogr: testata.wprogr },
    recordId: testata.wpprgf ?? testata.wprogr ?? "",
    oldValues: testata,
    filenamePrefix: "as400_promo_testata",
    invalidate: [["promo_testate"]],
    pimOnlyFields: [...TESTATA_PIM_ONLY_FIELDS],
  });

  /** Esegue il save effettivo della testata (chiamato sia diretto sia dopo conferma reconcile). */
  const persistTestata = async () => {
    const merged = {
      ...values,
      ...TESTATA_FORCED_VALUES,
      wpstato: computedStato,
      wpdvali: computedValidita.wpdvali,
      wpdvalf: computedValidita.wpdvalf,
    };
    const snapshot = JSON.stringify(merged);
    return new Promise<void>((resolve, reject) => {
      save.mutate(
        { newValues: merged, operation: "update" },
        {
          onSuccess: () => {
            // Allinea baseline dirty per evitare il prompt "modifiche non salvate"
            // quando l'utente cambia tab subito dopo il save.
            setValues(merged);
            initialRef.current = snapshot;
            onDirtyChange?.(false);
            onSaved();
            resolve();
          },
          onError: (e) => reject(e),
        },
      );
    });
  };


  const handleSave = async () => {
    // Validazione campi obbligatori
    const requiredDefs = TESTATE_FIELDS.filter((f) => f.required && !f.readOnly);
    const missing = requiredDefs.filter((f) => {
      const v = values[f.key];
      return v === null || v === undefined || v === "" || v === 0;
    });
    if (missing.length > 0) {
      toast({
        title: "Campi obbligatori mancanti",
        description: missing.map((f) => f.label).join(", "),
        variant: "destructive",
      });
      return;
    }

    // Validazione codice campagna (wpcca): 8 caratteri alfanumerici univoci
    const ccaRaw = String(values.wpcca ?? "").trim().toUpperCase();
    if (ccaRaw.length !== 8) {
      toast({ title: "Codice campagna non valido", description: "Deve essere esattamente 8 caratteri.", variant: "destructive" });
      return;
    }
    if (!/^[A-Z0-9]{8}$/.test(ccaRaw)) {
      toast({ title: "Codice campagna non valido", description: "Solo lettere e numeri, niente caratteri speciali.", variant: "destructive" });
      return;
    }
    if (ccaRaw !== String(testata.wpcca ?? "").trim().toUpperCase()) {
      const { data: dup, error: dupErr } = await supabase
        .from("promo_strutturate_testate")
        .select("wpprgf")
        .eq("wpcca", ccaRaw)
        .neq("id", testata.id)
        .limit(1)
        .maybeSingle();
      if (dupErr) {
        toast({ title: "Errore verifica codice", description: dupErr.message, variant: "destructive" });
        return;
      }
      if (dup) {
        toast({ title: "Codice campagna già esistente", description: `Usato da promo n° ${dup.wpprgf}.`, variant: "destructive" });
        return;
      }
    }
    // Normalizza wpcca nei values
    if (values.wpcca !== ccaRaw) {
      setValues((s) => ({ ...s, wpcca: ccaRaw }));
      values.wpcca = ccaRaw;
    }

    // Se cambia la copertura listini e ci sono campagne esistenti, chiedi conferma
    const oldExcluded = ((testata as any).excluded_listini ?? []).map(padCdlst).sort().join(",");
    const newExcluded = ((values.excluded_listini ?? []) as string[]).map(padCdlst).sort().join(",");
    const wpinlsChanged = (testata as any).wpinls !== values.wpinls;
    const excludedChanged = oldExcluded !== newExcluded;
    const coperturaChanged = wpinlsChanged || excludedChanged;

    if (!coperturaChanged || !testata.wpprgf) {
      await persistTestata();
      return;
    }

    // Calcola preview impatto
    setReconcileLoading(true);
    setReconcileOpen(true);
    try {
      const newTarget = computeTargetListini(
        values.wpinls,
        values.excluded_listini ?? [],
      );
      const preview = await previewReconcile(testata.wpprgf, newTarget);
      // Nessun impatto su campagne esistenti → salva direttamente la testata
      // senza bloccare l'utente nel dialog.
      if (preview.totalAdd === 0 && preview.totalRemove === 0) {
        setReconcileOpen(false);
        setReconcilePreview(null);
        await persistTestata();
        return;
      }
      setReconcilePreview(preview);
    } catch (e: any) {
      toast({ title: "Errore preview", description: e.message, variant: "destructive" });
      setReconcileOpen(false);
    } finally {
      setReconcileLoading(false);
    }
  };

  const handleReconcileConfirm = async () => {
    if (!reconcilePreview || !testata.wpprgf) return;
    setReconcileLoading(true);
    try {
      // 1. Applica diff sulle campagne
      const result = await applyReconcile({
        testataWpprgf: testata.wpprgf,
        preview: reconcilePreview.items,
        defaultDateInizio: values.wpindoi ?? null,
        defaultDateFine: values.wpindof ?? null,
      });

      // 2. Salva la testata (excluded_listini + altri campi)
      await persistTestata();

      // 3. Export AS400 aggregato per la sync listini
      exportAs400Change({
        user: profile?.email ?? user?.email,
        record: String(testata.wpprgf),
        table: "promo_strutturate_campagne",
        change: {
          operation: "update",
          key: { wpprgta: testata.wpprgf },
          fields: {
            sync_listini: {
              added: reconcilePreview.items.flatMap((i) =>
                i.toAdd.map((c) => ({ wpprgea: i.wpprge, wpcdlsa: c })),
              ),
              removed: reconcilePreview.items.flatMap((i) =>
                i.toRemove.map((c) => ({ wpprgea: i.wpprge, wpcdlsa: c })),
              ),
            },
          },
        },
        filenamePrefix: "as400_promo_listini_sync",
      });

      toast({
        title: "Listini riconciliati",
        description: `${result.inserted} aggiunte, ${result.deleted} rimosse.`,
      });
      qc.invalidateQueries({ queryKey: ["promo_campagne"] });
      qc.invalidateQueries({ queryKey: ["promo_elementi"] });
      setReconcileOpen(false);
      setReconcilePreview(null);
    } catch (e: any) {
      toast({ title: "Errore riconciliazione", description: e.message, variant: "destructive" });
    } finally {
      setReconcileLoading(false);
    }
  };

  const main = TESTATE_FIELDS.filter((f) => f.group !== "advanced");
  const adv = TESTATE_FIELDS.filter((f) => f.group === "advanced");

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">
            Promo #{testata.wpprgf ?? "—"}{" "}
            <span className="text-muted-foreground font-normal">
              {testata.wptpbd?.trim()}
            </span>
          </h2>
        </div>
        <Button onClick={handleSave} disabled={save.isPending} size="sm">
          <Save className="h-4 w-4 mr-1" />
          {save.isPending ? "Salvataggio…" : "Salva"}
        </Button>
      </div>




      <Card className="p-4 space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {main.map((def) => (
            <PromoField
              key={def.key}
              def={def}
              value={def.key === "wpstato" ? computedStato : values[def.key]}
              onChange={(v) => setValues((s) => ({ ...s, [def.key]: v }))}
              className={def.width === 2 ? "col-span-2" : undefined}
            />
          ))}
        </div>

        {/* Picker listini esclusi: visibile solo quando wpinls = E */}
        {values.wpinls === "E" && (
          <div className="border-t pt-3">
            <div className="flex items-center gap-2 mb-2 text-sm font-medium">
              <Settings2 className="h-4 w-4 text-muted-foreground" />
              Configura listini esclusi
            </div>
            <ListiniExcludePicker
              value={values.excluded_listini ?? []}
              onChange={(next) => setValues((s) => ({ ...s, excluded_listini: next }))}
            />
          </div>
        )}
      </Card>


      {adv.length > 0 && (
        <Card className="p-2">
          <button
            type="button"
            onClick={() => setAdvancedOpen((s) => !s)}
            className="w-full flex items-center gap-2 text-sm font-medium px-2 py-1 hover:bg-muted/50 rounded"
          >
            {advancedOpen ? <ChevronDown className="h-4 w-4" /> : <ChevR className="h-4 w-4" />}
            Avanzati ({adv.length})
          </button>
          {advancedOpen && (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 p-2 pt-3">
              {adv.map((def) => (
                <PromoField
                  key={def.key}
                  def={def}
                  value={values[def.key]}
                  onChange={(v) => setValues((s) => ({ ...s, [def.key]: v }))}
                />
              ))}
            </div>
          )}
        </Card>
      )}

      <ReconcileListiniDialog
        open={reconcileOpen}
        loading={reconcileLoading}
        preview={reconcilePreview}
        onCancel={() => {
          setReconcileOpen(false);
          setReconcilePreview(null);
        }}
        onConfirm={handleReconcileConfirm}
      />
    </div>
  );
}

import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { exportAs400Change } from "@/lib/as400Export";

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  onCreated: (newId: string) => void;
}

export function NewPromoDialog({ open, onOpenChange, onCreated }: Props) {
  const qc = useQueryClient();
  const { user, profile } = useAuth();
  const [descr, setDescr] = useState("");
  const [cca, setCca] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!descr.trim()) {
      toast({ title: "Manca descrizione", variant: "destructive" });
      return;
    }
    const ccaTrim = cca.trim().toUpperCase();
    if (ccaTrim.length !== 8) {
      toast({ title: "Codice campagna non valido", description: "Deve essere esattamente 8 caratteri.", variant: "destructive" });
      return;
    }
    if (!/^[A-Z0-9]{8}$/.test(ccaTrim)) {
      toast({ title: "Codice campagna non valido", description: "Solo lettere e numeri, niente caratteri speciali.", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      // Check unicità wpcca
      const { data: existing, error: chkErr } = await supabase
        .from("promo_strutturate_testate")
        .select("wpprgf")
        .eq("wpcca", ccaTrim)
        .limit(1)
        .maybeSingle();
      if (chkErr) throw chkErr;
      if (existing) {
        toast({ title: "Codice campagna già esistente", description: `Usato da promo n° ${existing.wpprgf}.`, variant: "destructive" });
        setBusy(false);
        return;
      }

      // Compute next wpprgf and wprogr
      const [{ data: maxF }, { data: maxR }] = await Promise.all([
        supabase
          .from("promo_strutturate_testate")
          .select("wpprgf")
          .order("wpprgf", { ascending: false, nullsFirst: false })
          .limit(1)
          .single(),
        supabase
          .from("promo_strutturate_testate")
          .select("wprogr")
          .order("wprogr", { ascending: false, nullsFirst: false })
          .limit(1)
          .single(),
      ]);
      const nextF = Number(maxF?.wpprgf ?? 0) + 1;
      const nextR = Number(maxR?.wprogr ?? 0) + 1;

      const insertObj: any = {
        wpprgf: nextF,
        wprogr: nextR,
        wptpbd: descr.trim(),
        wpcca: ccaTrim,
        wpstato: "V",
        wptpca: "P",
        // Valori di sistema sempre forzati
        wpcadt: "N",
        wpdtls: "T",
        // Default copertura listini: tutti (T), nessun escluso
        wpinls: "T",
        excluded_listini: [],
      };

      const { data, error } = await supabase
        .from("promo_strutturate_testate")
        .insert(insertObj)
        .select("id")
        .single();
      if (error) throw error;

      // Audit + AS400 export
      try {
        await supabase.from("audit_log" as any).insert({
          table_name: "promo_strutturate_testate",
          record_id: String(nextF),
          operation: "insert",
          new_values: insertObj,
          changed_fields: Object.keys(insertObj),
          user_id: user?.id,
          user_email: profile?.email,
        });
      } catch (e) {
        console.warn(e);
      }

      exportAs400Change({
        user: profile?.email ?? user?.email,
        record: String(nextF),
        table: "promo_strutturate_testate",
        change: { operation: "insert", key: { wprogr: nextR }, fields: insertObj },
        filenamePrefix: "as400_promo_testata",
      });

      qc.invalidateQueries({ queryKey: ["promo_testate"] });
      toast({ title: "Promo creata", description: `N° ${nextF}` });
      setDescr("");
      setCca("");
      onCreated(data.id);
      onOpenChange(false);
    } catch (e: any) {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Nuova Promo Strutturata</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <Label>Descrizione *</Label>
            <Input value={descr} onChange={(e) => setDescr(e.target.value)} maxLength={36} />
            <p className="text-xs text-muted-foreground mt-1">
              Numero promo e progressivo verranno assegnati automaticamente.
            </p>
          </div>
          <div>
            <Label>Codice campagna *</Label>
            <Input
              value={cca}
              onChange={(e) => setCca(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8))}
              maxLength={8}
              placeholder="8 caratteri (lettere/numeri)"
              className="font-mono uppercase"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Esattamente 8 caratteri, solo lettere e numeri. Deve essere univoco.
            </p>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={busy}>
            Annulla
          </Button>
          <Button onClick={submit} disabled={busy}>
            {busy && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
            Crea
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

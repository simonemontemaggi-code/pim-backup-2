import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, Download, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { useUserDisplayNames } from "@/hooks/useUserDisplayNames";
import type { TestataRow } from "./PromoTestateList";
import { downloadXlsxAoa } from "@/lib/xlsxExport";

interface Sblocco {
  id: string;
  wpprgf: number;
  cdcli: string;
  var_cli: string | null;
  data_sblocco: string;
  importo_sblocco: number | null;
  ordine_ref: string | null;
  modalita: string | null;
  note: string | null;
  user_email: string | null;
  user_id: string | null;
}

const MODE_LABEL: Record<string, string> = {
  primo_ordine: "Primo ordine",
  cumulativa: "Cumulativa",
  singolo_ordine: "Singolo ordine",
};

interface Props {
  testata: TestataRow;
}

export function PromoSblocchiTab({ testata }: Props) {
  const confirm = useConfirm();
  const wpprgf = testata.wpprgf!;
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["promo_sblocchi", wpprgf],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("promo_strutturate_sblocchi")
        .select("*")
        .eq("wpprgf", wpprgf)
        .order("data_sblocco", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Sblocco[];
    },
  });
  const { display: displayUser } = useUserDisplayNames(rows.map((r) => r.user_id));


  const del = async (id: string) => {
    if (!(await confirm({ title: "Eliminare questa registrazione di sblocco?", destructive: true, confirmText: "Elimina" }))) return;
    const { error } = await supabase.from("promo_strutturate_sblocchi").delete().eq("id", id);
    if (error) toast({ title: "Errore", description: error.message, variant: "destructive" });
    else qc.invalidateQueries({ queryKey: ["promo_sblocchi", wpprgf] });
  };

  const exportCsv = () => {
    if (rows.length === 0) return;
    const header = ["data", "cliente", "var_cli", "modalita", "importo", "ordine_ref", "note", "user"];
    const aoa: any[][] = [header];
    rows.forEach((r) => {
      aoa.push([
        new Date(r.data_sblocco).toISOString(),
        r.cdcli,
        r.var_cli ?? "",
        r.modalita ?? "",
        r.importo_sblocco ?? "",
        r.ordine_ref ?? "",
        r.note ?? "",
        displayUser(r.user_id, r.user_email),
      ]);
    });
    downloadXlsxAoa(`sblocchi_promo_${wpprgf}.xlsx`, aoa, { sheetName: "Sblocchi" });
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="text-sm text-muted-foreground">
          {isLoading ? "Caricamento…" : `${rows.length} clienti hanno sbloccato la promo`}
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" onClick={exportCsv} disabled={rows.length === 0}>
            <Download className="h-4 w-4 mr-1" /> Esporta XLSX
          </Button>
          <Button size="sm" onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4 mr-1" /> Aggiungi sblocco
          </Button>
        </div>
      </div>

      {isLoading ? (
        <Card className="p-6 flex items-center gap-2 text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Caricamento…
        </Card>
      ) : rows.length === 0 ? (
        <Card className="p-6 text-sm text-muted-foreground text-center">
          Nessun cliente ha ancora sbloccato la promo. Le registrazioni automatiche da ordini reali arriveranno con l'integrazione futura.
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs uppercase">
              <tr>
                <th className="text-left px-3 py-2">Data sblocco</th>
                <th className="text-left px-3 py-2">Cliente</th>
                <th className="text-left px-3 py-2">Modalità</th>
                <th className="text-right px-3 py-2">Importo €</th>
                <th className="text-left px-3 py-2">Ordine rif.</th>
                <th className="text-left px-3 py-2">Note</th>
                <th className="px-2"></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="border-t hover:bg-muted/30">
                  <td className="px-3 py-1.5 text-xs">{new Date(r.data_sblocco).toLocaleString("it-IT")}</td>
                  <td className="px-3 py-1.5 font-mono text-xs">{r.cdcli}{r.var_cli ? `/${r.var_cli}` : ""}</td>
                  <td className="px-3 py-1.5 text-xs">{r.modalita ? MODE_LABEL[r.modalita] ?? r.modalita : "—"}</td>
                  <td className="px-3 py-1.5 text-right tabular-nums">{r.importo_sblocco != null ? r.importo_sblocco.toFixed(2) : "—"}</td>
                  <td className="px-3 py-1.5 font-mono text-xs">{r.ordine_ref ?? "—"}</td>
                  <td className="px-3 py-1.5 text-xs text-muted-foreground truncate max-w-[200px]">{r.note ?? "—"}</td>
                  <td className="px-2 text-right">
                    <Button size="sm" variant="ghost" className="h-7 px-2 text-destructive" onClick={() => del(r.id)}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <AddSbloccoDialog
        open={open}
        onOpenChange={setOpen}
        wpprgf={wpprgf}
        defaultModalita={testata.unlock_mode ?? null}
        onAdded={() => qc.invalidateQueries({ queryKey: ["promo_sblocchi", wpprgf] })}
      />
    </div>
  );
}

function AddSbloccoDialog({
  open, onOpenChange, wpprgf, defaultModalita, onAdded,
}: {
  open: boolean; onOpenChange: (b: boolean) => void; wpprgf: number;
  defaultModalita: string | null; onAdded: () => void;
}) {
  const { user, profile } = useAuth();
  const [cdcli, setCdcli] = useState("");
  const [varCli, setVarCli] = useState("");
  const [importo, setImporto] = useState<string>("");
  const [ordineRef, setOrdineRef] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!cdcli.trim()) {
      toast({ title: "Codice cliente obbligatorio", variant: "destructive" });
      return;
    }
    setBusy(true);
    const { error } = await supabase.from("promo_strutturate_sblocchi").insert({
      wpprgf,
      cdcli: cdcli.trim(),
      var_cli: varCli.trim() || null,
      importo_sblocco: importo === "" ? null : Number(importo),
      ordine_ref: ordineRef.trim() || null,
      note: note.trim() || null,
      modalita: defaultModalita,
      user_id: user?.id,
      user_email: profile?.email,
    });
    setBusy(false);
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Sblocco registrato" });
    setCdcli(""); setVarCli(""); setImporto(""); setOrdineRef(""); setNote("");
    onAdded();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Aggiungi sblocco manuale</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Codice cliente *</Label>
              <Input value={cdcli} onChange={(e) => setCdcli(e.target.value)} className="font-mono" />
            </div>
            <div>
              <Label>Variante cliente</Label>
              <Input value={varCli} onChange={(e) => setVarCli(e.target.value)} className="font-mono" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Importo che ha sbloccato €</Label>
              <Input value={importo} onChange={(e) => setImporto(e.target.value)} type="number" step="0.01" />
            </div>
            <div>
              <Label>Ordine di riferimento</Label>
              <Input value={ordineRef} onChange={(e) => setOrdineRef(e.target.value)} />
            </div>
          </div>
          <div>
            <Label>Note</Label>
            <Input value={note} onChange={(e) => setNote(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={busy}>Annulla</Button>
          <Button onClick={submit} disabled={busy}>
            {busy && <Loader2 className="h-4 w-4 mr-1 animate-spin" />} Registra
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { Lock } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

interface Props {
  enabled: boolean;
  mode: string | null;
  threshold: number | null;
  onChange: (patch: { unlock_enabled?: boolean; unlock_mode?: string | null; unlock_threshold?: number | null }) => void;
}

const MODES = [
  {
    value: "primo_ordine",
    label: "Primo ordine raggiunge la soglia",
    desc: "Il primo ordine del cliente nel periodo deve toccare la soglia €. Da quel momento la promo è attiva su quell'ordine e su tutti i successivi del periodo.",
  },
  {
    value: "cumulativa",
    label: "Cumulativa nel periodo",
    desc: "La somma degli ordini del cliente nel periodo deve raggiungere la soglia €. La promo si attiva sugli ordini successivi.",
  },
  {
    value: "singolo_ordine",
    label: "Sblocco su singolo ordine",
    desc: "Quando un singolo ordine raggiunge la soglia €, la promo si attiva da quel momento e resta valida per tutto il periodo.",
  },
];

export function PromoUnlockRulesCard({ enabled, mode, threshold, onChange }: Props) {
  return (
    <Card className="p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm font-medium">
          <Lock className="h-4 w-4 text-muted-foreground" />
          Condizioni di attivazione (B2B)
          <span className="text-xs text-muted-foreground font-normal ml-2">PIM-only</span>
        </div>
        <div className="flex items-center gap-2">
          <Label htmlFor="unlock-enabled" className="text-sm">Richiede sblocco</Label>
          <Switch
            id="unlock-enabled"
            checked={enabled}
            onCheckedChange={(v) => onChange({ unlock_enabled: v, unlock_mode: v ? (mode ?? "primo_ordine") : null })}
          />
        </div>
      </div>

      {!enabled ? (
        <p className="text-xs text-muted-foreground">
          La promo è sempre attiva per i clienti del listino, senza condizioni di importo minimo.
        </p>
      ) : (
        <div className="space-y-3 pt-1">
          <RadioGroup
            value={mode ?? "primo_ordine"}
            onValueChange={(v) => onChange({ unlock_mode: v })}
            className="space-y-2"
          >
            {MODES.map((m) => (
              <label
                key={m.value}
                htmlFor={`mode-${m.value}`}
                className="flex items-start gap-3 p-2 rounded-md border hover:bg-muted/30 cursor-pointer"
              >
                <RadioGroupItem id={`mode-${m.value}`} value={m.value} className="mt-0.5" />
                <div className="flex-1">
                  <div className="text-sm font-medium">{m.label}</div>
                  <div className="text-xs text-muted-foreground">{m.desc}</div>
                </div>
              </label>
            ))}
          </RadioGroup>

          <div className="flex items-center gap-3">
            <Label className="text-sm shrink-0 w-32">Soglia €</Label>
            <Input
              type="number"
              step="0.01"
              min={0}
              value={threshold ?? ""}
              onChange={(e) => onChange({ unlock_threshold: e.target.value === "" ? null : Number(e.target.value) })}
              placeholder="es. 500.00"
              className="max-w-xs"
            />
          </div>
        </div>
      )}
    </Card>
  );
}

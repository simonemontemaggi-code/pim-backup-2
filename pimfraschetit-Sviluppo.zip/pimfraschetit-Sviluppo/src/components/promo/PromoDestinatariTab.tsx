import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Save, Users, Plus, X, Loader2, Upload, Database } from "lucide-react";
import * as XLSX from "xlsx";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Eye, EyeOff, UserCheck } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandInput, CommandList, CommandEmpty, CommandItem, CommandGroup } from "@/components/ui/command";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { PromoUnlockRulesCard } from "./PromoUnlockRulesCard";
import type { TestataRow } from "./PromoTestateList";

interface Props { testata: TestataRow; onSaved?: () => void }

type CustomerMode = "all" | "rules" | "manual" | "from_as400";

interface CustomerRuleBlock {
  zone_code?: string[];
  province?: string[];
  agent_code?: string[];
}

interface CustomersDest {
  customer_mode: CustomerMode;
  rules: CustomerRuleBlock[];
  manual_includes: string[];
  manual_excludes: string[];
}

const DEFAULT_CUST: CustomersDest = { customer_mode: "all", rules: [], manual_includes: [], manual_excludes: [] };

// ------- helpers -------
function ChipList({ items, onRemove }: { items: string[]; onRemove: (v: string) => void }) {
  if (items.length === 0) return <span className="text-xs text-muted-foreground">Nessuno</span>;
  return (
    <div className="flex flex-wrap gap-1">
      {items.map((v) => (
        <Badge key={v} variant="secondary" className="gap-1">
          {v}
          <button onClick={() => onRemove(v)} className="hover:text-destructive">
            <X className="h-3 w-3" />
          </button>
        </Badge>
      ))}
    </div>
  );
}

function MultiPicker({
  label, values, onChange, options, loading,
}: {
  label: string;
  values: string[];
  onChange: (v: string[]) => void;
  options: { value: string; label: string }[];
  loading?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const toggle = (v: string) =>
    onChange(values.includes(v) ? values.filter((x) => x !== v) : [...values, v]);
  return (
    <div className="space-y-1">
      <Label className="text-xs">{label}</Label>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="w-full justify-start font-normal h-8">
            {values.length === 0 ? (
              <span className="text-muted-foreground">Tutti</span>
            ) : (
              <span>{values.length} selezionati</span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="p-0 w-80" align="start">
          <Command>
            <CommandInput placeholder={`Cerca ${label.toLowerCase()}...`} />
            <CommandList>
              {loading ? (
                <div className="p-3 text-xs text-muted-foreground flex items-center gap-2">
                  <Loader2 className="h-3 w-3 animate-spin" /> Carico…
                </div>
              ) : (
                <>
                  <CommandEmpty>Nessun risultato.</CommandEmpty>
                  <CommandGroup>
                    {options.map((o) => (
                      <CommandItem key={o.value} onSelect={() => toggle(o.value)}>
                        <input
                          type="checkbox"
                          checked={values.includes(o.value)}
                          readOnly
                          className="mr-2"
                        />
                        <span className="text-xs">{o.label}</span>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </>
              )}
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
      {values.length > 0 && (
        <div className="flex flex-wrap gap-1 pt-1">
          {values.map((v) => (
            <Badge key={v} variant="outline" className="text-xs gap-1">
              {v}
              <button onClick={() => toggle(v)}><X className="h-3 w-3" /></button>
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}

function useDistinctCustomerValues(field: "zone_code" | "province" | "original_agent_code") {
  return useQuery({
    queryKey: ["customers_distinct", field],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("customers")
        .select(field)
        .not(field, "is", null)
        .limit(5000);
      if (error) throw error;
      const set = new Set<string>();
      (data ?? []).forEach((r: any) => {
        const v = String(r[field] ?? "").trim();
        if (v) set.add(v);
      });
      return Array.from(set).sort().map((v) => ({ value: v, label: v }));
    },
  });
}

function CustomerSearchAdd({ onPick, exclude }: { onPick: (code: string) => void; exclude: string[] }) {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const { data: results, isFetching } = useQuery({
    queryKey: ["customer_search_dest", q],
    enabled: q.length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("customers")
        .select("customer_code, company_name")
        .or(`customer_code.ilike.%${q}%,company_name.ilike.%${q}%`)
        .limit(20);
      if (error) throw error;
      return data ?? [];
    },
  });
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="h-8">
          <Plus className="h-3 w-3 mr-1" /> Aggiungi cliente
        </Button>
      </PopoverTrigger>
      <PopoverContent className="p-0 w-96" align="start">
        <div className="p-2 border-b">
          <Input
            placeholder="Codice o ragione sociale (min 2)"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="h-8"
            autoFocus
          />
        </div>
        <ScrollArea className="max-h-72">
          {isFetching && <div className="p-2 text-xs text-muted-foreground">Cerco…</div>}
          {(results ?? []).map((r: any) => {
            const dis = exclude.includes(r.customer_code);
            return (
              <button
                key={r.customer_code}
                disabled={dis}
                onClick={() => { onPick(r.customer_code); setOpen(false); setQ(""); }}
                className="w-full text-left px-3 py-1.5 text-xs hover:bg-muted disabled:opacity-50"
              >
                <span className="font-mono">{r.customer_code}</span> — {r.company_name}
              </button>
            );
          })}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}

function CustomerRuleBlockEditor({
  block, onChange, onRemove,
}: {
  block: CustomerRuleBlock;
  onChange: (b: CustomerRuleBlock) => void;
  onRemove: () => void;
}) {
  const zone = useDistinctCustomerValues("zone_code");
  const prov = useDistinctCustomerValues("province");
  const agent = useDistinctCustomerValues("original_agent_code");
  return (
    <Card className="p-3 space-y-2 bg-muted/20">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium">Blocco regole (AND interno)</span>
        <Button variant="ghost" size="sm" onClick={onRemove} className="h-6 px-2">
          <X className="h-3 w-3" />
        </Button>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-2">
        <MultiPicker label="Zona" values={block.zone_code ?? []} onChange={(v) => onChange({ ...block, zone_code: v })} options={zone.data ?? []} loading={zone.isLoading} />
        <MultiPicker label="Provincia" values={block.province ?? []} onChange={(v) => onChange({ ...block, province: v })} options={prov.data ?? []} loading={prov.isLoading} />
        <MultiPicker label="Agente" values={block.agent_code ?? []} onChange={(v) => onChange({ ...block, agent_code: v })} options={agent.data ?? []} loading={agent.isLoading} />
      </div>
    </Card>
  );
}

// ------- main component -------
export function PromoDestinatariTab({ testata, onSaved }: Props) {
  const qc = useQueryClient();
  const [cust, setCust] = useState<CustomersDest>(DEFAULT_CUST);
  const [unlock, setUnlock] = useState<{ enabled: boolean; mode: string | null; threshold: number | null }>({
    enabled: !!testata.unlock_enabled,
    mode: (testata.unlock_mode as string | null) ?? null,
    threshold: (testata.unlock_threshold as number | null) ?? null,
  });
  const [saving, setSaving] = useState(false);
  const [bannerVis, setBannerVis] = useState<"T" | "A" | "N">(
    ((testata as any).b2b_banner_visibility as "T" | "A" | "N") || "T",
  );
  const [savingVis, setSavingVis] = useState(false);

  useEffect(() => {
    setBannerVis(((testata as any).b2b_banner_visibility as "T" | "A" | "N") || "T");
  }, [testata.id, (testata as any).b2b_banner_visibility]);

  const handleVisibilityChange = async (v: "T" | "A" | "N") => {
    if (!v || v === bannerVis) return;
    const prev = bannerVis;
    setBannerVis(v);
    setSavingVis(true);
    try {
      const { error } = await supabase
        .from("promo_strutturate_testate")
        .update({ b2b_banner_visibility: v } as any)
        .eq("id", testata.id);
      if (error) throw error;
      toast({ title: "Visibilità banner aggiornata" });
      onSaved?.();
    } catch (e: any) {
      setBannerVis(prev);
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    } finally {
      setSavingVis(false);
    }
  };

  useEffect(() => {
    setUnlock({
      enabled: !!testata.unlock_enabled,
      mode: (testata.unlock_mode as string | null) ?? null,
      threshold: (testata.unlock_threshold as number | null) ?? null,
    });
  }, [testata.id, testata.unlock_enabled, testata.unlock_mode, testata.unlock_threshold]);

  const { data: custDb } = useQuery({
    queryKey: ["promo_dest_clienti", testata.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("promo_strutturate_destinatari_clienti")
        .select("*").eq("testata_id", testata.id).maybeSingle();
      return data;
    },
  });

  useEffect(() => {
    if (custDb) {
      setCust({
        customer_mode: (custDb.customer_mode ?? "all") as CustomerMode,
        rules: (custDb.rules as any) ?? [],
        manual_includes: custDb.manual_includes ?? [],
        manual_excludes: custDb.manual_excludes ?? [],
      });
    }
  }, [custDb]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const cPayload = {
        testata_id: testata.id,
        customer_mode: cust.customer_mode,
        rules: cust.rules as any,
        manual_includes: cust.manual_includes,
        manual_excludes: cust.manual_excludes,
      };
      const r1 = await supabase
        .from("promo_strutturate_destinatari_clienti")
        .upsert(cPayload as any, { onConflict: "testata_id" });
      if (r1.error) throw r1.error;
      const r2 = await supabase
        .from("promo_strutturate_testate")
        .update({
          unlock_enabled: unlock.enabled,
          unlock_mode: unlock.enabled ? unlock.mode : null,
          unlock_threshold: unlock.enabled ? unlock.threshold : null,
        })
        .eq("id", testata.id);
      if (r2.error) throw r2.error;
      toast({ title: "Destinatari salvati" });
      qc.invalidateQueries({ queryKey: ["promo_dest_clienti", testata.id] });
      onSaved?.();
    } catch (e: any) {
      toast({ title: "Errore salvataggio", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          Definisci a quali clienti è riservata questa promo. L'ambito articoli si configura per ogni offerta nel tab "Offerte".
        </p>
        <Button onClick={handleSave} disabled={saving} size="sm">
          <Save className="h-4 w-4 mr-1" />{saving ? "Salvataggio…" : "Salva"}
        </Button>
      </div>

      <PromoUnlockRulesCard
        enabled={unlock.enabled}
        mode={unlock.mode}
        threshold={unlock.threshold}
        onChange={(patch) => setUnlock((s) => ({
          enabled: patch.unlock_enabled ?? s.enabled,
          mode: patch.unlock_mode !== undefined ? patch.unlock_mode : s.mode,
          threshold: patch.unlock_threshold !== undefined ? patch.unlock_threshold : s.threshold,
        }))}
      />

      <Card className="p-4 space-y-2">
        <div className="flex items-center justify-between gap-3">
          <div>
            <div className="text-sm font-medium flex items-center gap-2">
              <Eye className="h-4 w-4 text-primary" /> Visibilità banner B2B
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Decide chi vede banner/locandine di questa promo sul B2B. Non modifica il calcolo della promo né l'elenco destinatari.
            </p>
          </div>
          <ToggleGroup
            type="single"
            value={bannerVis}
            onValueChange={(v) => handleVisibilityChange(v as "T" | "A" | "N")}
            disabled={savingVis}
          >
            <ToggleGroupItem value="T" aria-label="Tutti" className="gap-1">
              <Eye className="h-4 w-4" /> Tutti
            </ToggleGroupItem>
            <ToggleGroupItem value="A" aria-label="Solo aderenti" className="gap-1">
              <UserCheck className="h-4 w-4" /> Solo aderenti
            </ToggleGroupItem>
            <ToggleGroupItem value="N" aria-label="Nessuno" className="gap-1">
              <EyeOff className="h-4 w-4" /> Nessuno
            </ToggleGroupItem>
          </ToggleGroup>
        </div>
      </Card>

      <Card className="p-4 space-y-3">
        <div className="flex items-center gap-2 text-sm font-medium">
          <Users className="h-4 w-4 text-primary" /> Clienti destinatari
        </div>
        <RadioGroup
          value={cust.customer_mode}
          onValueChange={(v) => setCust((s) => ({ ...s, customer_mode: v as CustomerMode }))}
          className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-2"
        >
          {[
            { v: "all", l: "Tutti i clienti del listino", d: "Promo aperta a tutti i clienti che hanno il listino della promo." },
            { v: "rules", l: "Filtra per regole", d: "Solo clienti che soddisfano almeno uno dei blocchi di regole." },
            { v: "manual", l: "Solo lista manuale", d: "Solo i clienti aggiunti esplicitamente sotto." },
            { v: "from_as400", l: "Sincronizza da AS400", d: "Lista letta live dalla tabella adepromo: cambia AS400 → cambia tutto, zero azioni manuali." },
          ].map((m) => (
            <label key={m.v} htmlFor={`cm-${m.v}`} className="flex items-start gap-2 p-2 rounded border hover:bg-muted/30 cursor-pointer">
              <RadioGroupItem id={`cm-${m.v}`} value={m.v} className="mt-0.5" />
              <div>
                <div className="text-sm font-medium">{m.l}</div>
                <div className="text-xs text-muted-foreground">{m.d}</div>
              </div>
            </label>
          ))}
        </RadioGroup>

        {cust.customer_mode === "rules" && (
          <div className="space-y-2 pt-2">
            {cust.rules.map((b, i) => (
              <CustomerRuleBlockEditor
                key={i}
                block={b}
                onChange={(nb) => setCust((s) => ({ ...s, rules: s.rules.map((x, j) => (j === i ? nb : x)) }))}
                onRemove={() => setCust((s) => ({ ...s, rules: s.rules.filter((_, j) => j !== i) }))}
              />
            ))}
            <Button variant="outline" size="sm" onClick={() => setCust((s) => ({ ...s, rules: [...s.rules, {}] }))}>
              <Plus className="h-3 w-3 mr-1" /> Aggiungi blocco regole (OR)
            </Button>
          </div>
        )}

        {cust.customer_mode === "from_as400" && (
          <AdepromoLivePreview
            promoCode={testata.wpcca}
            excludes={cust.manual_excludes}
            includes={cust.manual_includes}
          />
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t">
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-1">
              <Label className="text-xs">
                Includi manualmente
                {cust.customer_mode === "from_as400" && (
                  <span className="ml-1 text-[10px] text-muted-foreground font-normal">
                    (aggiunti alla lista live)
                  </span>
                )}
              </Label>
              <div className="flex items-center gap-1">
                <ImportFromAdepromo
                  promoCode={testata.wpcca}
                  onImport={(codes) => setCust((s) => ({ ...s, manual_includes: Array.from(new Set([...s.manual_includes, ...codes])) }))}
                />
                <BulkImportCustomers
                  onImport={(codes) => setCust((s) => ({ ...s, manual_includes: Array.from(new Set([...s.manual_includes, ...codes])) }))}
                />
                <CustomerSearchAdd
                  exclude={cust.manual_includes}
                  onPick={(c) => setCust((s) => ({ ...s, manual_includes: Array.from(new Set([...s.manual_includes, c])) }))}
                />
              </div>
            </div>
            <ChipList items={cust.manual_includes} onRemove={(v) => setCust((s) => ({ ...s, manual_includes: s.manual_includes.filter((x) => x !== v) }))} />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-1">
              <Label className="text-xs">Escludi manualmente</Label>
              <div className="flex items-center gap-1">
                <BulkImportCustomers
                  onImport={(codes) => setCust((s) => ({ ...s, manual_excludes: Array.from(new Set([...s.manual_excludes, ...codes])) }))}
                />
                <CustomerSearchAdd
                  exclude={cust.manual_excludes}
                  onPick={(c) => setCust((s) => ({ ...s, manual_excludes: Array.from(new Set([...s.manual_excludes, c])) }))}
                />
              </div>
            </div>
            <ChipList items={cust.manual_excludes} onRemove={(v) => setCust((s) => ({ ...s, manual_excludes: s.manual_excludes.filter((x) => x !== v) }))} />
          </div>
        </div>



      </Card>
    </div>
  );
}

// ───────── Bulk import (XLSX/CSV/paste) ─────────
function BulkImportCustomers({ onImport }: { onImport: (codes: string[]) => void }) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [checking, setChecking] = useState(false);
  const [valid, setValid] = useState<string[]>([]);
  const [missing, setMissing] = useState<string[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);

  const reset = () => { setText(""); setValid([]); setMissing([]); };

  const parseCodes = (raw: string): string[] => {
    return Array.from(new Set(
      raw.split(/[\s,;]+/)
        .map((s) => s.trim())
        .filter(Boolean)
    ));
  };

  const handleFile = async (file: File) => {
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: "array" });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<any>(sheet, { header: 1, blankrows: false });
    const codes: string[] = [];
    for (const r of rows) {
      const cell = (r as any[])[0];
      if (cell == null) continue;
      const s = String(cell).trim();
      if (!s) continue;
      // skip header-like row
      if (codes.length === 0 && /^(codice|customer|cod|code|cliente)/i.test(s)) continue;
      codes.push(s);
    }
    setText(codes.join("\n"));
  };

  const verify = async () => {
    setChecking(true);
    try {
      const codes = parseCodes(text);
      if (codes.length === 0) { setValid([]); setMissing([]); return; }
      const { data, error } = await supabase
        .from("customers")
        .select("customer_code")
        .in("customer_code", codes);
      if (error) throw error;
      const found = new Set((data ?? []).map((r: any) => r.customer_code));
      setValid(codes.filter((c) => found.has(c)));
      setMissing(codes.filter((c) => !found.has(c)));
    } catch (e: any) {
      toast({ title: "Errore verifica", description: e.message, variant: "destructive" });
    } finally {
      setChecking(false);
    }
  };

  const confirm = () => {
    if (valid.length === 0) {
      toast({ title: "Nessun codice valido", variant: "destructive" });
      return;
    }
    onImport(valid);
    toast({ title: `${valid.length} clienti aggiunti` });
    setOpen(false);
    reset();
  };

  return (
    <>
      <Button variant="outline" size="sm" className="h-8" onClick={() => setOpen(true)}>
        <Upload className="h-3 w-3 mr-1" /> Importa
      </Button>
      <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) reset(); }}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Importa clienti da elenco</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-xs text-muted-foreground">
              Carica un file XLSX/CSV con una sola colonna di codici cliente (la prima colonna; eventuale intestazione viene ignorata),
              oppure incolla i codici sotto separati da virgola, spazio o nuova riga.
            </p>
            <div className="flex items-center gap-2">
              <input
                ref={fileRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); e.currentTarget.value = ""; }}
              />
              <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()}>
                <Upload className="h-3 w-3 mr-1" /> Carica file
              </Button>
              <span className="text-xs text-muted-foreground">XLSX, XLS, CSV</span>
            </div>
            <Textarea
              rows={8}
              value={text}
              onChange={(e) => { setText(e.target.value); setValid([]); setMissing([]); }}
              placeholder={"Es:\n100123\n100456\n200789"}
              className="font-mono text-xs"
            />
            <div className="flex items-center gap-2">
              <Button size="sm" variant="secondary" onClick={verify} disabled={checking || !text.trim()}>
                {checking ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : null}
                Verifica codici
              </Button>
              {(valid.length > 0 || missing.length > 0) && (
                <span className="text-xs">
                  <Badge variant="secondary" className="mr-1">{valid.length} validi</Badge>
                  {missing.length > 0 && <Badge variant="destructive">{missing.length} non trovati</Badge>}
                </span>
              )}
            </div>
            {missing.length > 0 && (
              <div className="text-xs text-destructive max-h-24 overflow-auto border rounded p-2">
                Non trovati: <span className="font-mono">{missing.join(", ")}</span>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>Annulla</Button>
            <Button size="sm" onClick={confirm} disabled={valid.length === 0}>
              Aggiungi {valid.length > 0 ? `(${valid.length})` : ""}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

// ───────── Import from AS400 (adepromo table, refreshed daily) ─────────
function ImportFromAdepromo({ promoCode, onImport }: { promoCode: string | null | undefined; onImport: (codes: string[]) => void }) {
  const [open, setOpen] = useState(false);

  const { data, isFetching, refetch } = useQuery({
    queryKey: ["adepromo_import", promoCode],
    enabled: open && !!promoCode,
    queryFn: async () => {
      const { data: rows, error } = await supabase
        .from("adepromo")
        .select("codice, created_at")
        .eq("promo_code", promoCode!)
        .limit(20000);
      if (error) throw error;
      const codes = Array.from(new Set((rows ?? []).map((r: any) => String(r.codice).trim()).filter(Boolean)));
      const lastUpdate = (rows ?? []).reduce<string | null>((acc, r: any) => {
        if (!acc || (r.created_at && r.created_at > acc)) return r.created_at;
        return acc;
      }, null);

      // verifica match in customers
      let valid: string[] = [];
      let missing: string[] = [];
      if (codes.length > 0) {
        // chunk per evitare URL troppo lunghi
        const CHUNK = 500;
        const found = new Set<string>();
        for (let i = 0; i < codes.length; i += CHUNK) {
          const slice = codes.slice(i, i + CHUNK);
          const { data: cust, error: e2 } = await supabase
            .from("customers")
            .select("customer_code")
            .in("customer_code", slice);
          if (e2) throw e2;
          (cust ?? []).forEach((c: any) => found.add(c.customer_code));
        }
        valid = codes.filter((c) => found.has(c));
        missing = codes.filter((c) => !found.has(c));
      }
      return { codes, valid, missing, lastUpdate };
    },
  });

  const confirm = () => {
    if (!data || data.valid.length === 0) {
      toast({ title: "Nessun cliente da importare", variant: "destructive" });
      return;
    }
    onImport(data.valid);
    toast({ title: `${data.valid.length} clienti importati da AS400` });
    setOpen(false);
  };

  if (!promoCode) return null;

  return (
    <>
      <Button variant="outline" size="sm" className="h-8" onClick={() => setOpen(true)}>
        <Database className="h-3 w-3 mr-1" /> Da AS400
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Importa clienti da AS400 (adepromo)</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-xs text-muted-foreground">
              Estrae i clienti collegati alla promo <span className="font-mono font-semibold">{promoCode}</span> dalla tabella
              di sincronizzazione AS400 (<span className="font-mono">adepromo</span>). L'elenco viene aggiornato ogni giorno —
              ad ogni import vengono presi i dati più recenti disponibili.
            </p>
            {isFetching ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground py-6 justify-center">
                <Loader2 className="h-4 w-4 animate-spin" /> Lettura adepromo…
              </div>
            ) : data ? (
              <div className="space-y-2">
                <div className="flex flex-wrap gap-2 items-center">
                  <Badge variant="secondary">{data.codes.length} righe in adepromo</Badge>
                  <Badge>{data.valid.length} clienti trovati</Badge>
                  {data.missing.length > 0 && (
                    <Badge variant="destructive">{data.missing.length} non trovati in anagrafica</Badge>
                  )}
                  {data.lastUpdate && (
                    <span className="text-xs text-muted-foreground ml-auto">
                      Ultimo aggiornamento: {new Date(data.lastUpdate).toLocaleString("it-IT")}
                    </span>
                  )}
                </div>
                {data.missing.length > 0 && (
                  <div className="text-xs text-destructive max-h-24 overflow-auto border rounded p-2">
                    Non trovati: <span className="font-mono">{data.missing.join(", ")}</span>
                  </div>
                )}
                <Button size="sm" variant="ghost" onClick={() => refetch()} disabled={isFetching}>
                  <Loader2 className={`h-3 w-3 mr-1 ${isFetching ? "animate-spin" : "hidden"}`} /> Ricarica
                </Button>
              </div>
            ) : null}
          </div>
          <DialogFooter>
            <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>Annulla</Button>
            <Button size="sm" onClick={confirm} disabled={!data || data.valid.length === 0}>
              Importa {data?.valid.length ? `(${data.valid.length})` : ""}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}


// ───────── Live preview when mode = from_as400 ─────────
function AdepromoLivePreview({ promoCode, excludes, includes }: { promoCode: string | null | undefined; excludes: string[]; includes: string[] }) {
  const [showList, setShowList] = useState(false);
  const [filter, setFilter] = useState("");
  const { data, isFetching } = useQuery({
    queryKey: ["adepromo_live_preview", promoCode],
    enabled: !!promoCode,
    queryFn: async () => {
      const { data: rows, error } = await supabase
        .from("adepromo")
        .select("codice, created_at")
        .eq("promo_code", promoCode!)
        .limit(20000);
      if (error) throw error;
      const codes = Array.from(new Set((rows ?? []).map((r: any) => String(r.codice).trim()).filter(Boolean))).sort();
      const lastUpdate = (rows ?? []).reduce<string | null>((acc, r: any) => {
        if (!acc || (r.created_at && r.created_at > acc)) return r.created_at;
        return acc;
      }, null);
      return { codes, lastUpdate };
    },
    refetchOnWindowFocus: true,
  });

  if (!promoCode) {
    return (
      <Card className="p-3 bg-muted/30 text-xs text-muted-foreground">
        Codice promo (wpcca) mancante: impossibile sincronizzare da AS400.
      </Card>
    );
  }

  const liveCodes = data?.codes ?? [];
  const liveSet = new Set(liveCodes);
  const extraIncludes = includes.filter((c) => !liveSet.has(c));
  const total = liveCodes.length;
  const merged = Array.from(new Set([...liveCodes, ...includes])).sort();
  const effective = merged.filter((c) => !excludes.includes(c)).length;
  const filtered = merged.filter((c) => !filter || c.toLowerCase().includes(filter.toLowerCase()));


  return (
    <Card className="p-3 space-y-2 bg-primary/5 border-primary/30">
      <div className="flex items-center gap-2 text-sm">
        <Database className="h-4 w-4 text-primary" />
        <span className="font-medium">Sincronizzazione live da AS400</span>
        <span className="text-xs text-muted-foreground">
          (tabella <span className="font-mono">adepromo</span>, promo <span className="font-mono">{promoCode}</span>)
        </span>
      </div>
      {isFetching ? (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="h-3 w-3 animate-spin" /> Lettura in corso…
        </div>
      ) : (
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="secondary">{total} clienti in adepromo</Badge>
          {extraIncludes.length > 0 && (
            <>
              <span className="text-muted-foreground text-xs">+</span>
              <Badge variant="default" className="bg-success text-success-foreground">{extraIncludes.length} inclusi manualmente</Badge>
            </>
          )}
          {(excludes.length > 0 || extraIncludes.length > 0) && (
            <>
              {excludes.length > 0 && (
                <>
                  <span className="text-muted-foreground text-xs">−</span>
                  <Badge variant="outline">{excludes.length} esclusi</Badge>
                </>
              )}
              <span className="text-muted-foreground text-xs">=</span>
              <Badge>{effective} effettivi</Badge>
            </>
          )}
          <Button
            size="sm"
            variant="ghost"
            className="h-6 px-2 text-xs"
            onClick={() => setShowList((v) => !v)}
          disabled={merged.length === 0}
          >
            {showList ? "Nascondi elenco" : "Mostra elenco"}
          </Button>
          {data?.lastUpdate && (
            <span className="text-xs text-muted-foreground ml-auto">
              Ultimo aggiornamento: {new Date(data.lastUpdate).toLocaleString("it-IT")}
            </span>
          )}
        </div>
      )}
      {showList && data && (
        <div className="space-y-2 pt-1">
          <div className="flex items-center gap-2">
            <Input
              placeholder="Filtra codice…"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="h-7 text-xs"
            />
            <Button
              size="sm"
              variant="outline"
              className="h-7 text-xs"
              onClick={() => {
                navigator.clipboard.writeText(filtered.join("\n"));
                toast({ title: `Copiati ${filtered.length} codici` });
              }}
            >
              Copia
            </Button>
            <span className="text-xs text-muted-foreground whitespace-nowrap">
              {filtered.length} / {merged.length}
            </span>
          </div>
          <ScrollArea className="h-64 rounded border bg-background">
            <div className="p-2 flex flex-wrap gap-1">
              {filtered.map((c) => {
                const excluded = excludes.includes(c);
                const manualOnly = !liveSet.has(c);
                return (
                  <Badge
                    key={c}
                    variant={excluded ? "outline" : manualOnly ? "default" : "secondary"}
                    className={`font-mono text-[10px] ${excluded ? "line-through opacity-60" : ""} ${manualOnly && !excluded ? "bg-success text-success-foreground" : ""}`}
                    title={manualOnly ? "Aggiunto manualmente" : "Da adepromo"}
                  >
                    {c}{manualOnly ? " ＋" : ""}
                  </Badge>
                );
              })}
              {filtered.length === 0 && (
                <span className="text-xs text-muted-foreground p-2">Nessun risultato.</span>
              )}
            </div>
          </ScrollArea>
        </div>
      )}
      <p className="text-xs text-muted-foreground">
        La lista live non viene salvata: ad ogni utilizzo della promo (PIM, B2B, Agent Hub) viene riletta da AS400 in tempo reale.
        Puoi <strong>includere</strong> o <strong>escludere</strong> manualmente clienti specifici sotto: includi/escludi sono persistenti e applicati sopra alla lista live.
      </p>
    </Card>
  );
}

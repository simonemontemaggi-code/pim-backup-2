/**
 * Mappatura campi AS400 → label italiane per le tabelle promo_strutturate_*.
 * Tipo campo: text | number | date (yyyymmdd) | flag (S/N) | select.
 */

export type FieldKind = "text" | "number" | "date" | "flag" | "select";

export interface PromoFieldDef {
  key: string;
  label: string;
  kind: FieldKind;
  options?: { value: string; label: string }[];
  readOnly?: boolean;
  required?: boolean;
  group?: "main" | "advanced";
  hint?: string;
  width?: number; // suggested input width (cols)
}

// ─────────── TESTATE ───────────
// Date: ci sono 2 intervalli distinti (Sell-in = ingrosso compra dal fornitore;
// Sell-out = ingrosso vende al cliente). wpdvali/wpdvalf rappresentano la
// validità "globale" e vengono mantenute in automatico = unione dei due intervalli.
// Stato calcolato dall'unione (vedi computePromoStato).
export const TESTATE_FIELDS: PromoFieldDef[] = [
  { key: "wptpbd",  label: "Descrizione",       kind: "text",   group: "main", width: 2, required: true },
  { key: "wptpbs",  label: "Sottotitolo",       kind: "text",   group: "main", width: 2,
    hint: "Mostrato sotto la descrizione nei contesti B2B (es. Offerte del momento)." },
  { key: "wpcca",   label: "Codice campagna",   kind: "text",   group: "main", required: true },
  { key: "wptpca",  label: "Tipo",              kind: "select", group: "main", required: true,
    options: [
      { value: "O", label: "Offerta" },
      { value: "P", label: "Promo" },
      { value: "S", label: "Sconto" },
    ] },
  { key: "wpstato", label: "Stato (auto)",      kind: "select", group: "main", readOnly: true,
    hint: "Calcolato dalle date di validità",
    options: [
      { value: "V", label: "Valida" },
      { value: "A", label: "Annullata" },
      { value: "S", label: "Sospesa" },
    ] },
  // Sell-in: ingrosso acquista dal fornitore
  { key: "wpindii", label: "Sell-in inizio",    kind: "date",   group: "main", required: true,
    hint: "Periodo in cui l'ingrosso acquista dal fornitore" },
  { key: "wpindif", label: "Sell-in fine",      kind: "date",   group: "main", required: true },
  // Sell-out: ingrosso vende al cliente
  { key: "wpindoi", label: "Sell-out inizio",   kind: "date",   group: "main", required: true,
    hint: "Periodo in cui l'ingrosso vende al cliente" },
  { key: "wpindof", label: "Sell-out fine",     kind: "date",   group: "main", required: true },
  { key: "wpinls",  label: "Listini ingrosso",  kind: "select", group: "main", required: true,
    hint: "T = applica a tutti i listini base. E = scegli quali escludere.",
    options: [
      { value: "T", label: "Tutti" },
      { value: "E", label: "Esclusi" },
    ] },
  { key: "visible_b2b", label: "Mostra su B2B / Agent Hub", kind: "flag", group: "main",
    hint: "Se disattivo, la promo non viene mostrata nei portali B2B Mockup e Agent Hub. Gli sconti restano comunque applicati a carrello/ordine." },
  { key: "show_expiry_b2b", label: "Mostra scadenza su B2B", kind: "flag", group: "main",
    hint: "Se attivo, sul portale B2B viene mostrata la data di fine validità della promo." },
  { key: "show_on_customer_view", label: "Mostra su scheda cliente (Agent Hub)", kind: "flag", group: "main",
    hint: "Se attivo, su Agent Hub questa promo viene evidenziata nella scheda cliente indicando se il cliente vi aderisce o meno. Utile per promo importanti che l'agente deve vedere a colpo d'occhio." },
  { key: "offerta_sconto_fattura", label: "Offerta Sconto Fattura", kind: "flag", group: "main",
    hint: "Flag informativo PIM: indica che la promo prevede sconto in fattura. Non influisce su B2B/Agent Hub." },
];

/**
 * Valori di sistema sempre forzati sulla testata promo.
 * Non visibili in UI, ma sempre persistiti e inviati ad AS400.
 */
export const TESTATA_FORCED_VALUES = {
  wpcadt: "N", // Promozione dettaglio: sempre No
  wpdtls: "T", // Listini dettaglio: sempre Tutti (a livello testata)
  wpcain: "S", // Cumulabile inizio: sempre Sì
  wpliadi: "S", // Lista aderenti ingrosso: sempre Sì
  wpliadd: "N", // Lista aderenti dettaglio: sempre No
} as const;

/**
 * Campi della testata che vivono SOLO nel PIM.
 * Vengono persistiti su Supabase ma esclusi dal JSON di export AS400.
 */
export const TESTATA_PIM_ONLY_FIELDS = [
  "cover_image_url",
  "unlock_enabled",
  "unlock_mode",
  "unlock_threshold",
  "show_expiry_b2b",
  "visible_b2b",
  "show_on_customer_view",
  "b2b_sort_order",
  "b2b_banner_visibility",
  "offerta_sconto_fattura",
] as const;

const _toNum = (v: any) => {
  if (v === null || v === undefined || v === "") return 0;
  const n = typeof v === "number" ? v : parseInt(String(v), 10);
  return isNaN(n) ? 0 : n;
};

/**
 * Calcola la validità "globale" come unione degli intervalli sell-in e sell-out.
 * Restituisce { wpdvali, wpdvalf } in formato YYYYMMDD numerico (0 se non determinabile).
 */
export function computePromoValidita(values: Record<string, any>): {
  wpdvali: number;
  wpdvalf: number;
} {
  const inIni = _toNum(values.wpindii);
  const inFin = _toNum(values.wpindif);
  const ouIni = _toNum(values.wpindoi);
  const ouFin = _toNum(values.wpindof);
  const inizi = [inIni, ouIni].filter((n) => n > 0);
  const fini = [inFin, ouFin].filter((n) => n > 0);
  return {
    wpdvali: inizi.length ? Math.min(...inizi) : 0,
    wpdvalf: fini.length ? Math.max(...fini) : 0,
  };
}

/**
 * Stato della promo in base all'unione degli intervalli sell-in/sell-out.
 * - "S" Sospesa: oggi < inizio
 * - "V" Valida: inizio <= oggi <= fine
 * - "A" Annullata/scaduta: oggi > fine
 */
export function computePromoStato(
  values: Record<string, any>,
  current?: string | null,
): string {
  const { wpdvali, wpdvalf } = computePromoValidita(values);
  if (!wpdvali && !wpdvalf) return current || "V";
  const today = new Date();
  const oggi =
    today.getFullYear() * 10000 +
    (today.getMonth() + 1) * 100 +
    today.getDate();
  if (wpdvalf && oggi > wpdvalf) return "A";
  if (wpdvali && oggi < wpdvali) return "S";
  return "V";
}


// ─────────── ELEMENTI ───────────
export const ELEMENTI_FIELDS: PromoFieldDef[] = [
  { key: "wpdesce", label: "Descrizione",       kind: "text",   group: "main", width: 2 },
  { key: "wpccae",  label: "Codice campagna",   kind: "text",   group: "main" },
  { key: "wpstate", label: "Stato (auto)",      kind: "select", group: "main", readOnly: true,
    hint: "Calcolato dalle date di validità della testata",
    options: [
      { value: "V", label: "Valido" },
      { value: "A", label: "Annullato" },
      { value: "S", label: "Sospeso" },
    ] },
];

/**
 * Valori di sistema sempre forzati su ogni elemento promo.
 * Non visibili in UI, ma sempre persistiti e inviati ad AS400.
 */
export const ELEMENTO_FORCED_VALUES = {
  wpcaine: "S", // Cumulabile: sempre Sì
  wpcadte: "N", // Cumulabile date: sempre No
  wppreoe: "N", // Preordine S/N: sempre No
} as const;

// ─────────── CAMPAGNE (associazione cliente/scaglione) ───────────
export const CAMPAGNE_FIELDS: PromoFieldDef[] = [
  { key: "wpprga",  label: "N° campagna",       kind: "number", readOnly: true, group: "main" },
  { key: "wpcdcla", label: "Codice cliente",    kind: "text",   group: "main" },
  { key: "wpcdcva", label: "Var. cliente",      kind: "text",   group: "main" },
  { key: "wpcdlsa", label: "Codice listino",    kind: "number", group: "main" },
  { key: "wpcdpaa", label: "Cod. pagamento",    kind: "number", group: "main" },
  { key: "wpdtvia", label: "Validità dal",      kind: "date",   group: "main" },
  { key: "wpdtvfa", label: "Validità al",       kind: "date",   group: "main" },
  { key: "wpnrsca", label: "N° scaglione",      kind: "number", group: "main" },
  { key: "wpqtmsa", label: "Q.tà minima",       kind: "number", group: "main" },
  { key: "wpumqta", label: "UM quantità",       kind: "text",   group: "main" },
  { key: "wptpbla", label: "Tipo blocco",       kind: "text",   group: "main" },
  // Advanced
  { key: "wpricoa", label: "Ricorrenza",        kind: "text",   group: "advanced" },
  { key: "wpfldval1", label: "Campo val. 1",    kind: "text",   group: "advanced" },
  { key: "wpfldval2", label: "Campo val. 2",    kind: "text",   group: "advanced" },
  { key: "wpimpcpam", label: "Imp. campagna",   kind: "text",   group: "advanced" },
  { key: "wpdatval1", label: "Data val. 1",     kind: "date",   group: "advanced" },
  { key: "wpdatval2", label: "Data val. 2",     kind: "date",   group: "advanced" },
  { key: "wpritaca", label: "Rit. acq.",        kind: "text",   group: "advanced" },
  { key: "wpriatca", label: "Rit. att.",        kind: "number", group: "advanced" },
  { key: "wpwutimm", label: "Utente immissione",kind: "text",   group: "advanced", readOnly: true },
  { key: "wpwdtimm", label: "Data immissione",  kind: "date",   group: "advanced", readOnly: true },
  { key: "wpwhhimm", label: "Ora immissione",   kind: "number", group: "advanced", readOnly: true },
  { key: "wpwutagg", label: "Utente aggiorn.",  kind: "text",   group: "advanced", readOnly: true },
  { key: "wpwdtagg", label: "Data aggiorn.",    kind: "date",   group: "advanced", readOnly: true },
  { key: "wpwhhagg", label: "Ora aggiorn.",     kind: "number", group: "advanced", readOnly: true },
];

// ─────────── CONDIZIONI (sconti/regole) ───────────
export const CONDIZIONI_FIELDS: PromoFieldDef[] = [
  { key: "wpseqc",  label: "Sequenza",          kind: "number", group: "main" },
  { key: "wpstatc", label: "Stato",             kind: "select", group: "main",
    options: [{ value: "V", label: "Valida" }, { value: "A", label: "Annullata" }] },
  { key: "wptpvc",  label: "Tipo valore",       kind: "select", group: "main",
    options: [
      { value: "P", label: "% Percentuale" },
      { value: "I", label: "Importo" },
      { value: "N", label: "Netto" },
    ] },
  { key: "wpsegvc", label: "Segno",             kind: "select", group: "main",
    options: [{ value: "+", label: "+" }, { value: "-", label: "-" }] },
  { key: "wpval1c", label: "Valore 1",          kind: "number", group: "main" },
  { key: "wpval2c", label: "Valore 2",          kind: "number", group: "main" },
  { key: "wpunmc",  label: "UM",                kind: "text",   group: "main" },
  { key: "wpincc",  label: "Inclusione",        kind: "flag",   group: "main" },
  { key: "wpindc",  label: "Indicatore",        kind: "flag",   group: "main" },
  { key: "wpdocic", label: "Documento",         kind: "text",   group: "main" },
  { key: "wpmixdes", label: "Descrizione mix",  kind: "text",   group: "main", width: 2 },
  { key: "wprifc",  label: "Riferimento",       kind: "text",   group: "main" },
  { key: "wpumcc",  label: "UM condizione",     kind: "text",   group: "main" },
  { key: "wppapc",  label: "Pagamento",         kind: "text",   group: "main" },
  // Advanced
  { key: "wpaltc",  label: "Altro",             kind: "text",   group: "advanced" },
  { key: "wpsm1c",  label: "Scaglione mis. 1",  kind: "text",   group: "advanced" },
  { key: "wpsm2c",  label: "Scaglione mis. 2",  kind: "text",   group: "advanced" },
  { key: "wpsm5c",  label: "Scaglione mis. 5",  kind: "text",   group: "advanced" },
  { key: "wpsm5dac",label: "Sm5 da",            kind: "number", group: "advanced" },
  { key: "wpsm5ac", label: "Sm5 a",             kind: "number", group: "advanced" },
  { key: "wpsm5mpc",label: "Sm5 misura",        kind: "text",   group: "advanced" },
  { key: "wprartc", label: "Articolo",          kind: "text",   group: "advanced" },
  { key: "wpdapc",  label: "Data inserimento AS400",  kind: "date",   group: "advanced", readOnly: true },
  { key: "wputac",  label: "Utente inserim.",   kind: "text",   group: "advanced", readOnly: true },
  { key: "wpdmac",  label: "Data ultima modifica",    kind: "date",   group: "advanced", readOnly: true },
  { key: "wputmc",  label: "Utente ultima modif.",    kind: "text",   group: "advanced", readOnly: true },
  { key: "wporvc",  label: "Ora rev.",          kind: "number", group: "advanced", readOnly: true },
];

export function getFieldDef(list: PromoFieldDef[], key: string): PromoFieldDef | undefined {
  return list.find((f) => f.key === key);
}

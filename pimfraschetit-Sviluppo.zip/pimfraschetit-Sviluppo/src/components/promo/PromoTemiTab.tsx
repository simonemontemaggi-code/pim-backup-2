import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import * as XLSX from "xlsx";
import {
  Plus, Trash2, Loader2, Image as ImageIcon, Upload, Save, Search, X, Layers, Gift, Filter, FileDown, ChevronDown, CalendarIcon,
} from "lucide-react";
import { format, parseISO } from "date-fns";
import { it } from "date-fns/locale";
import { Calendar } from "@/components/ui/calendar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { BundleImportDialog } from "./BundleImportDialog";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandInput, CommandList, CommandEmpty, CommandItem, CommandGroup } from "@/components/ui/command";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { cn } from "@/lib/utils";
import { usePromoMediaUpload } from "@/hooks/usePromoMediaUpload";
import { yyyymmddToInputValue } from "@/lib/as400DateUtils";
import { useVisibleAssortments } from "@/hooks/useVisibleAssortments";
import { useDistinctValues } from "@/hooks/useArticles";
import { useLookupValues } from "@/hooks/useLookupValues";
import type { TestataRow } from "./PromoTestateList";

type TipoOfferta =
  | "sconto_base" | "bundle" | "referenza"
  | "scaglioni_qty" | "scaglioni_valore" | "righe_ordine" | "omaggio"
  | "piu_economico" | "bancale" | "sconto_catalogo";

type OmaggioModalita = "fisso" | "scelta" | "scaglioni";
type OmaggioSogliaTipo = "valore" | "pezzi";
type CatalogoStacking = "sostitutivo" | "aggiuntivo";

const TIPO_LABELS: Record<TipoOfferta, string> = {
  sconto_base: "Sconto base",
  bundle: "Bundle (n° confezioni)",
  referenza: "Sconto a referenza",
  scaglioni_qty: "Scaglioni a quantità",
  scaglioni_valore: "Scaglioni a valore",
  righe_ordine: "Sconto a righe d'ordine",
  omaggio: "Omaggio",
  piu_economico: "Più Economico (es. 6+1)",
  bancale: "Bancale (soglia = master pack)",
  sconto_catalogo: "Sconto Catalogo (tutto tranne esclusi)",
};

const TIPO_BADGE: Record<TipoOfferta, string> = {
  sconto_base: "Base",
  bundle: "Bundle",
  referenza: "Referenza",
  scaglioni_qty: "Sc. Q",
  scaglioni_valore: "Sc. €",
  righe_ordine: "Righe",
  omaggio: "Omaggio",
  piu_economico: "+1 Gratis",
  bancale: "Bancale",
  sconto_catalogo: "Catalogo",
};




interface Tema {
  id: string;
  wpprgf: number;
  nome: string;
  descrizione: string | null;
  image_url: string | null;
  sort_order: number;
  tipo: TipoOfferta;
  dal: string | null;
  al: string | null;
  sconto_pct: number | null;
  qty_min: number | null;
  bundle_confezioni: number | null;
  referenze_min: number | null;
  pezzi_min_referenza: number | null;
  righe_valore_min: number | null;
  omaggio_modalita: OmaggioModalita | null;
  omaggio_soglia_tipo: OmaggioSogliaTipo | null;
  omaggio_soglia_valore: number | null;
  omaggio_collegato_a: string | null;
  requires_tema_id: string | null;
  pe_qty_paganti: number | null;
  pe_qty_omaggio: number | null;
  scaglioni_qty_unit: "pezzi" | "confezioni" | null;
  note: string | null;
  catalogo_sconto_pct: number | null;
  catalogo_stacking: CatalogoStacking | null;
}



interface Scaglione {
  id: string;
  tema_id: string;
  soglia_qty: number | null;
  soglia_eur: number | null;
  soglia_righe: number | null;
  sconto_pct: number;
  sort_order: number;
  omaggio_modalita?: "tutti" | "scelta";
}

interface Props {
  testata: TestataRow;
  canEdit?: boolean;
}

import { pad6Cdpar } from "@/lib/csvTemplates";

// normCdpar = chiave logica zero-paddata a 6 cifre. padCdpar = versione space-padded a 15 (per query AS400).
const normCdpar = (value: string | null | undefined) => pad6Cdpar(value ?? "");
const padCdpar = (value: string) => normCdpar(value).padEnd(15, " ");

export function PromoTemiTab({ testata, canEdit = true }: Props) {
  const wpprgf = testata.wpprgf!;
  const qc = useQueryClient();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [listTab, setListTab] = useState<"attive" | "future" | "passate">("attive");
  const [importBundleOpen, setImportBundleOpen] = useState(false);
  const [bulkCreateOpen, setBulkCreateOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const rightPaneRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (rightPaneRef.current) rightPaneRef.current.scrollTop = 0;
  }, [selectedId]);

  const { data: temi = [], isLoading } = useQuery({
    queryKey: ["promo_temi", wpprgf],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("promo_strutturate_temi")
        .select("*")
        .eq("wpprgf", wpprgf)
        .order("sort_order", { ascending: true })
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as Tema[];
    },
  });

  // Map tema_id → set of cdpar (per ricerca offerta tramite codice articolo)
  const { data: temaArticoliMap } = useQuery({
    queryKey: ["promo_temi_articoli_index", wpprgf],
    queryFn: async () => {
      const temiIds = (temi ?? []).map((t) => t.id);
      if (temiIds.length === 0) return new Map<string, Set<string>>();
      const { data, error } = await supabase
        .from("promo_strutturate_tema_articoli")
        .select("tema_id, cdpar")
        .in("tema_id", temiIds);
      if (error) throw error;
      const m = new Map<string, Set<string>>();
      for (const r of data ?? []) {
        const tid = (r as any).tema_id as string;
        const c = String((r as any).cdpar ?? "").trim();
        if (!tid || !c) continue;
        if (!m.has(tid)) m.set(tid, new Set());
        m.get(tid)!.add(c);
      }
      return m;
    },
    enabled: temi.length > 0,
  });

  const todayStr = useMemo(() => format(new Date(), "yyyy-MM-dd"), []);
  const classifyTema = (t: Tema): "attive" | "future" | "passate" => {
    if (t.al && t.al < todayStr) return "passate";
    if (t.dal && t.dal > todayStr) return "future";
    return "attive";
  };
  const filteredTemi = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return temi;
    // Match per cdpar: normalizza a 6 cifre se è numerico
    const qDigits = q.replace(/\D/g, "");
    const qPadded = qDigits ? qDigits.padStart(6, "0").slice(-6) : "";
    return temi.filter((t) => {
      if (t.nome?.toLowerCase().includes(q)) return true;
      if (t.descrizione?.toLowerCase().includes(q)) return true;
      const codes = temaArticoliMap?.get(t.id);
      if (codes && qDigits) {
        for (const c of codes) {
          if (c.includes(qDigits) || (qPadded && c === qPadded)) return true;
        }
      }
      return false;
    });
  }, [temi, searchQuery, temaArticoliMap]);
  const temiAttive = useMemo(() => filteredTemi.filter((t) => classifyTema(t) === "attive"), [filteredTemi, todayStr]);
  const temiFuture = useMemo(() => filteredTemi.filter((t) => classifyTema(t) === "future"), [filteredTemi, todayStr]);
  const temiPassate = useMemo(() => filteredTemi.filter((t) => classifyTema(t) === "passate"), [filteredTemi, todayStr]);
  const currentList =
    listTab === "attive" ? temiAttive : listTab === "future" ? temiFuture : temiPassate;

  // Se l'offerta selezionata cade in un'altra tab, segui la tab.
  useEffect(() => {
    if (!selectedId) return;
    const sel = temi.find((t) => t.id === selectedId);
    if (!sel) return;
    const cat = classifyTema(sel);
    if (cat !== listTab) setListTab(cat);
  }, [selectedId, temi, todayStr]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (selectedId && !temi.find((t) => t.id === selectedId)) {
      setSelectedId(currentList[0]?.id ?? null);
      return;
    }
    if (!selectedId && currentList.length > 0) setSelectedId(currentList[0].id);
  }, [currentList, selectedId, temi]);

  const createTema = async () => {
    const defaultDal = yyyymmddToInputValue(testata.wpdvali) || null;
    const defaultAl = yyyymmddToInputValue(testata.wpdvalf) || null;
    const { data, error } = await supabase
      .from("promo_strutturate_temi")
      .insert({
        wpprgf,
        nome: "Nuova offerta",
        sort_order: temi.length,
        tipo: "sconto_base",
        dal: defaultDal,
        al: defaultAl,
      } as any)
      .select("id")
      .single();
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      return;
    }
    qc.invalidateQueries({ queryKey: ["promo_temi", wpprgf] });
    setSelectedId(data.id);
  };

  if (!wpprgf) {
    return <div className="text-sm text-muted-foreground p-4">Salva prima la testata.</div>;
  }

  const selected = temi.find((t) => t.id === selectedId) ?? null;

  return (
    <div className="grid h-full min-h-0 flex-1 grid-cols-[280px_minmax(0,1fr)] gap-6 overflow-hidden">
      <Card className="flex h-full min-h-0 flex-col overflow-hidden">
        <div className="p-2 border-b flex gap-1">
          <Button
            size="sm"
            className="flex-1"
            onClick={createTema}
            disabled={!canEdit || listTab !== "attive"}
            title={listTab !== "attive" ? "Passa ad Attive per creare" : undefined}
          >
            <Plus className="h-4 w-4 mr-1" /> Nuova offerta
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="outline" title="Importa offerte da file" disabled={!canEdit || listTab !== "attive"}>
                <FileDown className="h-4 w-4" />
                <ChevronDown className="h-3 w-3 ml-0.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setBulkCreateOpen(true)}>
                <Plus className="h-4 w-4 mr-2" /> Crea offerte in blocco
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setImportBundleOpen(true)}>
                <Layers className="h-4 w-4 mr-2" /> Bundle (n° confezioni)
              </DropdownMenuItem>
              <DropdownMenuItem disabled>Sconto base (presto)</DropdownMenuItem>
              <DropdownMenuItem disabled>Scaglioni (presto)</DropdownMenuItem>
              <DropdownMenuItem disabled>Omaggio (presto)</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <div className="p-2 border-b">
          <div className="relative">
            <Search className="h-3.5 w-3.5 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cerca offerta o codice articolo…"
              className="h-8 text-xs pl-7 pr-7"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                title="Pulisci"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>
        <div className="flex border-b text-xs">
          {(
            [
              { key: "attive" as const, label: "Attive", count: temiAttive.length },
              { key: "future" as const, label: "Future", count: temiFuture.length },
              { key: "passate" as const, label: "Passate", count: temiPassate.length },
            ]
          ).map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => setListTab(t.key)}
              className={cn(
                "flex-1 px-2 py-1.5 font-medium transition-colors",
                listTab === t.key
                  ? "border-b-2 border-primary text-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              {t.label} <span className="ml-1 opacity-70">({t.count})</span>
            </button>
          ))}
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden [scrollbar-gutter:stable]">
          {isLoading ? (
            <div className="p-3 text-sm text-muted-foreground flex items-center gap-2">
              <Loader2 className="h-3 w-3 animate-spin" /> Caricamento…
            </div>
          ) : currentList.length === 0 ? (
            <div className="p-3 text-xs text-muted-foreground text-center">
              {listTab === "attive"
                ? "Nessuna offerta attiva. Crea la prima."
                : listTab === "future"
                ? "Nessuna offerta futura."
                : "Nessuna offerta scaduta."}
            </div>
          ) : (
            <TemiSortableList
              temi={currentList}
              selectedId={selectedId}
              onSelect={setSelectedId}
              onReordered={() => qc.invalidateQueries({ queryKey: ["promo_temi", wpprgf] })}
            />
          )}
        </div>
      </Card>

      <div
        ref={rightPaneRef}
        className="h-full min-h-0 overflow-y-auto overflow-x-hidden rounded-lg border border-l-4 border-l-primary/60 bg-muted/40 p-4 pr-2 shadow-inner [scrollbar-gutter:stable]"
      >
        {selected ? (
          <>
            <div className="sticky top-0 -mx-4 -mt-4 mb-4 px-4 py-2 bg-background/95 backdrop-blur border-b z-10 flex items-center gap-2">
              <Badge variant="outline" className="uppercase text-[10px]">Configurazione offerta</Badge>
              <span className="text-sm font-medium truncate">{selected.nome}</span>
              {!canEdit && (
                <span className="ml-auto text-xs text-muted-foreground">Sola lettura</span>
              )}
            </div>
            <fieldset disabled={!canEdit} className={!canEdit ? "opacity-90" : undefined}>
              <TemaEditor
                key={selected.id}
                tema={selected}
                testata={testata}
                otherTemi={temi.filter((t) => t.id !== selected.id)}
                onChanged={() => { qc.invalidateQueries({ queryKey: ["promo_temi", wpprgf] }); }}
              />
            </fieldset>
          </>
        ) : (
          <Card className="p-8 text-sm text-muted-foreground text-center">
            Seleziona o crea un'offerta per iniziare.
          </Card>
        )}
      </div>

      <BundleImportDialog
        open={importBundleOpen}
        onOpenChange={setImportBundleOpen}
        testata={testata}
        existingSortOrder={temi.length}
        onDone={() => qc.invalidateQueries({ queryKey: ["promo_temi", wpprgf] })}
      />

      <BulkCreateTemiDialog
        open={bulkCreateOpen}
        onOpenChange={setBulkCreateOpen}
        testata={testata}
        existingCount={temi.length}
        onDone={(firstId) => {
          qc.invalidateQueries({ queryKey: ["promo_temi", wpprgf] });
          if (firstId) setSelectedId(firstId);
        }}
      />
    </div>
  );
}

// ─────────── Bulk create dialog ───────────

function BulkCreateTemiDialog({
  open, onOpenChange, testata, existingCount, onDone,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  testata: TestataRow;
  existingCount: number;
  onDone: (firstId: string | null) => void;
}) {
  const wpprgf = testata.wpprgf!;
  const defaultDal = yyyymmddToInputValue(testata.wpdvali) || "";
  const defaultAl = yyyymmddToInputValue(testata.wpdvalf) || "";
  const [text, setText] = useState("");
  const [dal, setDal] = useState(defaultDal);
  const [al, setAl] = useState(defaultAl);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) {
      setText("");
      setDal(defaultDal);
      setAl(defaultAl);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const parsed = useMemo(() => {
    return text
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean)
      .map((line) => {
        // Formato: Descrizione | dal | al   (dal/al opzionali, yyyy-mm-dd)
        const parts = line.split("|").map((p) => p.trim());
        const nome = parts[0] || "";
        const lineDal = parts[1] || dal || null;
        const lineAl = parts[2] || al || null;
        return { nome, dal: lineDal, al: lineAl };
      })
      .filter((r) => r.nome.length > 0);
  }, [text, dal, al]);

  const submit = async () => {
    if (parsed.length === 0) {
      toast({ title: "Nessuna offerta", description: "Inserisci almeno una descrizione.", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      const rows = parsed.map((r, i) => ({
        wpprgf,
        nome: r.nome.slice(0, 200),
        sort_order: existingCount + i,
        tipo: "sconto_base" as TipoOfferta,
        dal: r.dal || null,
        al: r.al || null,
      }));
      const { data, error } = await supabase
        .from("promo_strutturate_temi")
        .insert(rows as any)
        .select("id");
      if (error) throw error;
      toast({ title: "Offerte create", description: `${rows.length} nuove offerte` });
      onDone(data?.[0]?.id ?? null);
      onOpenChange(false);
    } catch (e: any) {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Crea offerte in blocco</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Validità dal (default)</Label>
              <Input type="date" value={dal} onChange={(e) => setDal(e.target.value)} />
            </div>
            <div>
              <Label className="text-xs">Validità al (default)</Label>
              <Input type="date" value={al} onChange={(e) => setAl(e.target.value)} />
            </div>
          </div>
          <div>
            <Label className="text-xs">Descrizioni (una per riga)</Label>
            <Textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={10}
              placeholder={"Sconto Greenworks 20%\nPromo barbecue\nOfferta speciale | 2026-06-01 | 2026-06-30"}
              className="font-mono text-xs"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Una offerta per riga. Per date diverse dal default usa il formato:{" "}
              <code>Descrizione | yyyy-mm-dd | yyyy-mm-dd</code>. Tipo iniziale: sconto base (modificabile dopo).
            </p>
          </div>
          <div className="text-xs text-muted-foreground">
            {parsed.length > 0 ? <>Verranno create <b>{parsed.length}</b> offerte.</> : "Nessuna offerta valida."}
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={busy}>
            Annulla
          </Button>
          <Button onClick={submit} disabled={busy || parsed.length === 0}>
            {busy && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
            Crea {parsed.length > 0 ? `(${parsed.length})` : ""}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─────────── EDITOR di un tema ───────────

function TemaEditor({ tema, testata, otherTemi, onChanged }: { tema: Tema; testata: TestataRow; otherTemi: Tema[]; onChanged: () => void }) {
  const confirm = useConfirm();
  const qc = useQueryClient();
  const [nome, setNome] = useState(tema.nome);
  const [descrizione, setDescrizione] = useState(tema.descrizione ?? "");
  const [note, setNote] = useState(tema.note ?? "");
  const [tipo, setTipo] = useState<TipoOfferta>(tema.tipo ?? "sconto_base");
  const [dal, setDal] = useState(tema.dal ?? "");
  const [al, setAl] = useState(tema.al ?? "");
  const [scontoPct, setScontoPct] = useState<string>(tema.sconto_pct != null ? String(tema.sconto_pct) : "");
  const [qtyMin, setQtyMin] = useState<string>(tema.qty_min != null ? String(tema.qty_min) : "");
  const [bundleConf, setBundleConf] = useState<string>(tema.bundle_confezioni != null ? String(tema.bundle_confezioni) : "");
  const [refMin, setRefMin] = useState<string>(tema.referenze_min != null ? String(tema.referenze_min) : "");
  const [pzMinRef, setPzMinRef] = useState<string>(tema.pezzi_min_referenza != null ? String(tema.pezzi_min_referenza) : "");
  const [rigaMin, setRigaMin] = useState<string>(tema.righe_valore_min != null ? String(tema.righe_valore_min) : "");
  const [omModalita, setOmModalita] = useState<OmaggioModalita>(tema.omaggio_modalita ?? "fisso");
  const [omSoglia, setOmSoglia] = useState<OmaggioSogliaTipo>(tema.omaggio_soglia_tipo ?? "valore");
  const [omSogliaVal, setOmSogliaVal] = useState<string>(tema.omaggio_soglia_valore != null ? String(tema.omaggio_soglia_valore) : "");
  const [omCollegato, setOmCollegato] = useState<string>(tema.omaggio_collegato_a ?? "");
  const [requiresTemaId, setRequiresTemaId] = useState<string>(tema.requires_tema_id ?? "");
  const [pePaganti, setPePaganti] = useState<string>(tema.pe_qty_paganti != null ? String(tema.pe_qty_paganti) : "");
  const [peOmaggio, setPeOmaggio] = useState<string>(tema.pe_qty_omaggio != null ? String(tema.pe_qty_omaggio) : "");
  const [qtyUnit, setQtyUnit] = useState<"pezzi" | "confezioni">(tema.scaglioni_qty_unit ?? "pezzi");
  const [catPct, setCatPct] = useState<string>(tema.catalogo_sconto_pct != null ? String(tema.catalogo_sconto_pct) : "");
  const [catStacking, setCatStacking] = useState<CatalogoStacking>(tema.catalogo_stacking ?? "sostitutivo");
  const [saving, setSaving] = useState(false);


  const inputRef = useRef<HTMLInputElement>(null);
  const { upload, remove, uploading } = usePromoMediaUpload();

  useEffect(() => {
    setNome(tema.nome);
    setDescrizione(tema.descrizione ?? "");
    setNote(tema.note ?? "");
    setTipo(tema.tipo ?? "sconto_base");
    setDal(tema.dal ?? "");
    setAl(tema.al ?? "");
    setScontoPct(tema.sconto_pct != null ? String(tema.sconto_pct) : "");
    setQtyMin(tema.qty_min != null ? String(tema.qty_min) : "");
    setBundleConf(tema.bundle_confezioni != null ? String(tema.bundle_confezioni) : "");
    setRefMin(tema.referenze_min != null ? String(tema.referenze_min) : "");
    setPzMinRef(tema.pezzi_min_referenza != null ? String(tema.pezzi_min_referenza) : "");
    setRigaMin(tema.righe_valore_min != null ? String(tema.righe_valore_min) : "");
    setOmModalita(tema.omaggio_modalita ?? "fisso");
    setOmSoglia(tema.omaggio_soglia_tipo ?? "valore");
    setOmSogliaVal(tema.omaggio_soglia_valore != null ? String(tema.omaggio_soglia_valore) : "");
    setOmCollegato(tema.omaggio_collegato_a ?? "");
    setRequiresTemaId(tema.requires_tema_id ?? "");
    setPePaganti(tema.pe_qty_paganti != null ? String(tema.pe_qty_paganti) : "");
    setPeOmaggio(tema.pe_qty_omaggio != null ? String(tema.pe_qty_omaggio) : "");
    setQtyUnit(tema.scaglioni_qty_unit ?? "pezzi");
    setCatPct(tema.catalogo_sconto_pct != null ? String(tema.catalogo_sconto_pct) : "");
    setCatStacking(tema.catalogo_stacking ?? "sostitutivo");
  }, [tema.id]);



  const numOrNull = (s: string) => (s.trim() === "" ? null : Number(s));

  const buildPatch = () => ({
    nome: nome.trim() || "Senza nome",
    descrizione: descrizione.trim() || null,
    note: note.trim() || null,
    tipo,
    dal: dal || null,
    al: al || null,
    sconto_pct: numOrNull(scontoPct),
    qty_min: numOrNull(qtyMin),
    bundle_confezioni: numOrNull(bundleConf),
    referenze_min: numOrNull(refMin),
    pezzi_min_referenza: numOrNull(pzMinRef),
    righe_valore_min: numOrNull(rigaMin),
    omaggio_modalita: tipo === "omaggio" ? omModalita : null,
    omaggio_soglia_tipo: tipo === "omaggio" && !omCollegato ? omSoglia : null,
    omaggio_soglia_valore: tipo === "omaggio" && !omCollegato && omModalita !== "scaglioni" ? numOrNull(omSogliaVal) : null,
    omaggio_collegato_a: tipo === "omaggio" && omCollegato ? omCollegato : null,
    requires_tema_id: requiresTemaId || null,
    pe_qty_paganti: tipo === "piu_economico" ? numOrNull(pePaganti) : null,
    pe_qty_omaggio: tipo === "piu_economico" ? numOrNull(peOmaggio) : null,
    scaglioni_qty_unit: tipo === "scaglioni_qty" ? qtyUnit : "pezzi",
    catalogo_sconto_pct: tipo === "sconto_catalogo" ? numOrNull(catPct) : null,
    catalogo_stacking: tipo === "sconto_catalogo" ? catStacking : null,
  });



  const save = async (opts?: { silent?: boolean }) => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from("promo_strutturate_temi")
        .update(buildPatch() as any)
        .eq("id", tema.id);
      if (error) throw error;
      if (!opts?.silent) toast({ title: "Offerta salvata" });
      onChanged();
    } catch (e: any) {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  // Autosave: salva silenziosamente se ci sono modifiche rispetto al record DB.
  const isDirty = () => {
    const patch = buildPatch();
    return Object.entries(patch).some(([k, v]) => {
      const orig = (tema as any)[k];
      const a = v === "" ? null : v;
      const b = orig === "" || orig === undefined ? null : orig;
      return JSON.stringify(a) !== JSON.stringify(b);
    });
  };
  const autoSave = () => {
    if (saving) return;
    if (!isDirty()) return;
    save({ silent: true });
  };
  // Autosave debounced su qualsiasi modifica (testo, numeri, select, date).
  useEffect(() => {
    const t = setTimeout(() => { autoSave(); }, 700);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    nome, descrizione, note, tipo, dal, al,
    scontoPct, qtyMin, bundleConf, refMin, pzMinRef, rigaMin,
    omModalita, omSoglia, omSogliaVal, omCollegato, requiresTemaId,
    pePaganti, peOmaggio, catPct, catStacking,
  ]);



  const del = async () => {
    if (!(await confirm({ title: `Eliminare l'offerta "${tema.nome}"?`, destructive: true, confirmText: "Elimina" }))) return;
    const { error } = await supabase.from("promo_strutturate_temi").delete().eq("id", tema.id);
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      return;
    }
    await remove(tema.image_url);
    toast({ title: "Offerta eliminata" });
    onChanged();
  };

  const onPickImg = async (f: File | null) => {
    if (!f) return;
    const url = await upload(f, `promos/${tema.wpprgf}/temi/${tema.id}`);
    if (!url) return;
    const { error } = await supabase
      .from("promo_strutturate_temi")
      .update({ image_url: url })
      .eq("id", tema.id);
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      return;
    }
    onChanged();
  };

  const clearImg = async () => {
    if (!(await confirm({ title: "Rimuovere l'immagine?", destructive: true, confirmText: "Rimuovi" }))) return;
    await remove(tema.image_url);
    await supabase.from("promo_strutturate_temi").update({ image_url: null }).eq("id", tema.id);
    onChanged();
  };

  const isAbbinato = tipo === "omaggio" && !!omCollegato;
  const usesScaglioni = tipo === "scaglioni_qty" || tipo === "scaglioni_valore" || tipo === "righe_ordine"
    || (tipo === "omaggio" && !isAbbinato && omModalita === "scaglioni");

  return (
    <div className="space-y-4">
      {/* Card identità */}
      <Card className="p-4 space-y-3">
        <div className="flex items-start gap-4">
          <div className="w-32 h-24 rounded-md border bg-muted/30 overflow-hidden flex items-center justify-center shrink-0">
            {tema.image_url ? (
              <img src={tema.image_url} alt="" className="w-full h-full object-cover" />
            ) : (
              <ImageIcon className="h-6 w-6 text-muted-foreground/50" />
            )}
          </div>
          <div className="flex-1 space-y-2">
            <div className="flex gap-2">
              <Input value={nome} onChange={(e) => setNome(e.target.value)} onBlur={autoSave} placeholder="Nome offerta" />
              <Button size="sm" onClick={() => save()} disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Save className="h-4 w-4 mr-1" />}
                Salva
              </Button>
              <Button size="sm" variant="ghost" className="text-destructive" onClick={del}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
            <Textarea
              value={descrizione}
              onChange={(e) => setDescrizione(e.target.value)}
              onBlur={autoSave}
              placeholder="Breve descrizione (visibile nel B2B)"
              maxLength={280}
              rows={2}
            />
            <div className="flex items-center gap-2">
              <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={(e) => onPickImg(e.target.files?.[0] ?? null)} />
              <Button size="sm" variant="outline" disabled={uploading} onClick={() => inputRef.current?.click()}>
                {uploading ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Upload className="h-4 w-4 mr-1" />}
                {tema.image_url ? "Sostituisci immagine" : "Carica immagine"}
              </Button>
              {tema.image_url && (
                <Button size="sm" variant="ghost" className="text-destructive" onClick={clearImg}>
                  <Trash2 className="h-4 w-4 mr-1" /> Rimuovi
                </Button>
              )}
            </div>
          </div>
        </div>
      </Card>

      {/* Card tipo + validità */}
      <Card className="p-4 space-y-3">
        <div className="grid grid-cols-3 gap-3">
          <div>
            <Label className="text-xs">Tipo offerta</Label>
            <Select value={tipo} onValueChange={(v) => setTipo(v as TipoOfferta)}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                {(Object.keys(TIPO_LABELS) as TipoOfferta[]).map((k) => (
                  <SelectItem key={k} value={k}>{TIPO_LABELS[k]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Valida dal</Label>
            <TemaDatePicker value={dal} onChange={setDal} />
          </div>
          <div>
            <Label className="text-xs">Valida al</Label>
            <TemaDatePicker value={al} onChange={setAl} />
          </div>
        </div>
        <div>
          <Label className="text-xs">Prerequisito · richiede un'altra offerta nello stesso ordine</Label>
          <Select value={requiresTemaId || "__none__"} onValueChange={(v) => setRequiresTemaId(v === "__none__" ? "" : v)}>
            <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="__none__">Nessuno — sempre attiva</SelectItem>
              {otherTemi.map((t) => (
                <SelectItem key={t.id} value={t.id}>{t.nome} — {TIPO_BADGE[t.tipo]}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {requiresTemaId && (
            <div className="text-[11px] text-muted-foreground mt-1">
              Questa offerta verrà applicata solo se anche l'offerta selezionata risulta raggiunta nello stesso ordine.
            </div>
          )}
        </div>
      </Card>


      {/* Card parametri */}
      <Card className="p-4 space-y-3">
        <div className="text-sm font-medium">Parametri</div>
        {tipo === "sconto_base" && (
          <div className="grid grid-cols-3 gap-3">
            <NumField label="Quantità minima (pz)" value={qtyMin} onChange={setQtyMin} onBlur={autoSave} />
            <NumField label="Sconto %" value={scontoPct} onChange={setScontoPct} step="0.01" onBlur={autoSave} />
          </div>
        )}
        {tipo === "bundle" && (
          <div className="grid grid-cols-3 gap-3">
            <NumField label="N° confezioni richieste" value={bundleConf} onChange={setBundleConf} onBlur={autoSave} />
            <NumField label="Sconto %" value={scontoPct} onChange={setScontoPct} step="0.01" onBlur={autoSave} />
            <div className="col-span-3 text-xs text-muted-foreground">
              Il minimo pezzi/confezione si imposta articolo per articolo nella card sotto.
            </div>
          </div>
        )}
        {tipo === "referenza" && (
          <div className="grid grid-cols-3 gap-3">
            <NumField label="Referenze diverse min" value={refMin} onChange={setRefMin} onBlur={autoSave} />
            <NumField label="Pezzi min per referenza" value={pzMinRef} onChange={setPzMinRef} onBlur={autoSave} />
            <NumField label="Sconto %" value={scontoPct} onChange={setScontoPct} step="0.01" onBlur={autoSave} />
          </div>
        )}
        {tipo === "scaglioni_qty" && (
          <div className="grid grid-cols-3 gap-3 items-end">
            <div>
              <Label className="text-xs">Le soglie si riferiscono a</Label>
              <Select value={qtyUnit} onValueChange={(v) => { setQtyUnit(v as "pezzi" | "confezioni"); setTimeout(autoSave, 0); }}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pezzi">Pezzi</SelectItem>
                  <SelectItem value="confezioni">Confezioni (master pack)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2 text-xs text-muted-foreground pb-2">
              {qtyUnit === "confezioni"
                ? "Le quantità sono contate in confezioni: qty ordinata ÷ master pack (arrotondato per difetto). Articoli senza master pack non contribuiscono."
                : "Definisci gli scaglioni nella tabella sotto. Vince lo scaglione più alto raggiunto."}
            </div>
          </div>
        )}
        {tipo === "scaglioni_valore" && (
          <div className="text-xs text-muted-foreground">
            Definisci gli scaglioni nella tabella sotto. Vince lo scaglione più alto raggiunto.
          </div>
        )}
        {tipo === "righe_ordine" && (
          <div className="grid grid-cols-3 gap-3">
            <NumField label="Valore minimo per riga € (opz.)" value={rigaMin} onChange={setRigaMin} step="0.01" onBlur={autoSave} />
            <div className="col-span-2 text-xs text-muted-foreground self-end pb-2">
              Una riga viene contata solo se il suo importo supera questa soglia. Definisci gli scaglioni sotto.
            </div>
          </div>
        )}
        {tipo === "piu_economico" && (
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-3">
              <NumField label="Pezzi paganti" value={pePaganti} onChange={setPePaganti} onBlur={autoSave} />
              <NumField label="Pezzi in omaggio" value={peOmaggio} onChange={setPeOmaggio} onBlur={autoSave} />
              <div className="text-xs text-muted-foreground self-end pb-2">
                Esempio: 6 paganti + 1 omaggio = 6+1
              </div>
            </div>
            <div className="text-xs text-muted-foreground">
              Quando il cliente raggiunge il totale di pezzi richiesto (paganti + omaggio) tra gli articoli
              della promo, i pezzi col prezzo più basso vengono regalati. Esempio 6+1: ordinando 7 pz, quello
              meno caro è gratis.
            </div>
          </div>
        )}

        {tipo === "bancale" && (
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-3">
              <NumField label="Sconto %" value={scontoPct} onChange={setScontoPct} step="0.01" onBlur={autoSave} />
            </div>
            <div className="text-xs text-muted-foreground">
              La soglia di acquisto per applicare lo sconto è il <strong>Confezionamento master (pz/cartone)</strong> di ciascun articolo
              (scheda articolo → Logistica B2B). Ogni riga d'ordine viene valutata indipendentemente: lo sconto si applica
              solo alle referenze che raggiungono la propria soglia. Gli articoli senza master pack sono evidenziati in rosso.
            </div>
          </div>
        )}

        {tipo === "sconto_catalogo" && (
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-3">
              <NumField label="Sconto %" value={catPct} onChange={setCatPct} step="0.01" onBlur={autoSave} />
              <div>
                <Label className="text-xs">Modalità</Label>
                <Select value={catStacking} onValueChange={(v) => setCatStacking(v as CatalogoStacking)}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sostitutivo">Sostitutivo (esclude altre promo sull'articolo)</SelectItem>
                    <SelectItem value="aggiuntivo">Aggiuntivo (si applica sul netto già scontato)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="text-xs text-muted-foreground">
              Lo sconto si applica a <strong>tutto il catalogo</strong>. Nella sezione sotto puoi elencare
              i codici articolo da <strong>escludere</strong>. In modalità <em>Sostitutivo</em> sostituisce
              qualsiasi altra promo sullo stesso articolo; in modalità <em>Aggiuntivo</em> viene calcolato
              sul netto già scontato da altre offerte.
            </div>
          </div>
        )}




        {tipo === "omaggio" && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Abbinato a un'altra offerta?</Label>
                <Select value={omCollegato || "__none__"} onValueChange={(v) => setOmCollegato(v === "__none__" ? "" : v)}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">Standalone (soglia propria)</SelectItem>
                    {otherTemi.map((t) => (
                      <SelectItem key={t.id} value={t.id}>{t.nome} — {TIPO_BADGE[t.tipo]}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Modalità omaggio</Label>
                <Select value={omModalita} onValueChange={(v) => setOmModalita(v as OmaggioModalita)}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fisso">Fisso (un solo articolo)</SelectItem>
                    <SelectItem value="scelta">A scelta del cliente</SelectItem>
                    <SelectItem value="scaglioni">A scaglioni</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            {!isAbbinato && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Tipo soglia (standalone)</Label>
                  <Select value={omSoglia} onValueChange={(v) => setOmSoglia(v as OmaggioSogliaTipo)}>
                    <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="valore">Valore € totale</SelectItem>
                      <SelectItem value="pezzi">N° pezzi totale</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {omModalita !== "scaglioni" && (
                  <NumField
                    label={omSoglia === "pezzi" ? "Soglia minima (pz)" : "Soglia minima (€)"}
                    value={omSogliaVal}
                    onChange={setOmSogliaVal}
                    step={omSoglia === "pezzi" ? "1" : "0.01"}
                    onBlur={autoSave}
                  />
                )}
                {omModalita === "scaglioni" && (
                  <div className="text-xs text-muted-foreground self-end pb-2">
                    Le soglie si definiscono nella tabella scaglioni sotto.
                  </div>
                )}
              </div>
            )}
            {isAbbinato && (
              <div className="text-xs text-muted-foreground">
                L'omaggio scatta automaticamente quando le condizioni dell'offerta abbinata sono soddisfatte.
              </div>
            )}
          </div>
        )}
        <div>
          <Label className="text-xs">Note interne</Label>
          <Textarea value={note} onChange={(e) => setNote(e.target.value)} onBlur={autoSave} rows={2} placeholder="Note ad uso interno" />
        </div>
      </Card>

      {tipo === "sconto_catalogo" ? (
        <TemaCatalogoEsclusioniInline temaId={tema.id} />
      ) : (
        <TemaArticoliInline temaId={tema.id} wpprgf={tema.wpprgf} testata={testata} tipo={tipo} qtyUnit={qtyUnit} />
      )}


      {usesScaglioni && (
        <TemaScaglioniInline temaId={tema.id} tipo={tipo} omaggioSogliaTipo={omSoglia} qtyUnit={qtyUnit} />
      )}

      {tipo === "omaggio" && (
        <TemaOmaggioInline
          temaId={tema.id}
          modalita={omModalita}
          isAbbinato={isAbbinato}
          wpprgf={tema.wpprgf}
        />
      )}
    </div>
  );
}

function NumField({ label, value, onChange, step, onBlur }: { label: string; value: string; onChange: (s: string) => void; step?: string; onBlur?: () => void }) {
  return (
    <div>
      <Label className="text-xs">{label}</Label>
      <Input type="number" min={0} step={step ?? "1"} value={value} onChange={(e) => onChange(e.target.value)} onBlur={onBlur} className="h-9" />
    </div>
  );
}


// ─────────── ESCLUSIONI del tema "Sconto Catalogo" ───────────

function TemaCatalogoEsclusioniInline({ temaId }: { temaId: string }) {
  const qc = useQueryClient();
  const [manualCode, setManualCode] = useState("");

  const { data: rows = [] } = useQuery({
    queryKey: ["tema_catalogo_esc", temaId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("promo_strutturate_tema_catalogo_esclusioni")
        .select("cdpar")
        .eq("tema_id", temaId)
        .order("cdpar", { ascending: true });
      if (error) throw error;
      const codes = Array.from(new Set(((data ?? []) as any[]).map((r) => normCdpar(r.cdpar)).filter(Boolean)));
      if (codes.length === 0) return [] as { cdpar: string; depar: string | null }[];
      const lookup = Array.from(new Set(codes.flatMap((c) => [c, padCdpar(c)])));
      const { data: arts } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar, depar")
        .in("cdpar", lookup);
      const descMap = new Map<string, string | null>(((arts ?? []) as any[]).map((a) => [normCdpar(a.cdpar), a.depar ?? null]));
      return codes.map((c) => ({ cdpar: c, depar: descMap.get(c) ?? null }));
    },
  });

  const invalidate = () => qc.invalidateQueries({ queryKey: ["tema_catalogo_esc", temaId] });

  const addCodes = async (codes: string[]) => {
    const normalized = Array.from(new Set(codes.map(normCdpar).filter((c) => /^\d{6}$/.test(c))));
    if (normalized.length === 0) return;
    const payload = normalized.map((c) => ({ tema_id: temaId, cdpar: c }));
    const { error } = await supabase
      .from("promo_strutturate_tema_catalogo_esclusioni")
      .upsert(payload as any, { onConflict: "tema_id,cdpar", ignoreDuplicates: true });
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      return;
    }
    invalidate();
  };

  const removeCode = async (cdpar: string) => {
    const { error } = await supabase
      .from("promo_strutturate_tema_catalogo_esclusioni")
      .delete()
      .eq("tema_id", temaId)
      .eq("cdpar", cdpar);
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      return;
    }
    invalidate();
  };

  const addManual = async () => {
    const code = normCdpar(manualCode);
    if (!/^\d{6}$/.test(code)) {
      toast({ title: "Codice non valido", description: "Deve essere numerico (6 cifre).", variant: "destructive" });
      return;
    }
    await addCodes([code]);
    setManualCode("");
  };

  return (
    <Card className="overflow-hidden">
      <div className="px-3 py-2 border-b flex items-center justify-between gap-2">
        <div className="text-sm font-medium">
          Codici esclusi dallo Sconto Catalogo ({rows.length})
        </div>
        <div className="flex items-center gap-2">
          <BulkImportArticoli onImport={addCodes} skipVerify title="Importa codici da escludere" confirmLabel="Escludi" />
          <Input
            value={manualCode}
            onChange={(e) => setManualCode(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addManual(); } }}
            placeholder="Codice (6 cifre)"
            className="h-8 w-40 font-mono text-xs"
          />
          <Button size="sm" variant="outline" onClick={addManual}>
            <Plus className="h-4 w-4 mr-1" /> Aggiungi
          </Button>
        </div>
      </div>
      {rows.length === 0 ? (
        <div className="p-4 text-sm text-muted-foreground text-center">
          Nessun codice escluso. Lo sconto si applica a tutto il catalogo.
        </div>
      ) : (
        <ul className="divide-y max-h-72 overflow-auto">
          {rows.map((r) => (
            <li key={r.cdpar} className="px-3 py-1.5 flex items-center gap-3 text-sm">
              <span className="font-mono text-xs w-24">{r.cdpar}</span>
              <span className="flex-1 truncate text-muted-foreground">{r.depar?.trim() || "—"}</span>
              <Button size="sm" variant="ghost" className="text-destructive h-7" onClick={() => removeCode(r.cdpar)}>
                <X className="h-4 w-4" />
              </Button>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

// ─────────── ARTICOLI del tema ───────────



function useOccupiedByOtherTemi(wpprgf: number, currentTemaId: string, currentTipo?: TipoOfferta | null) {
  return useQuery({
    queryKey: ["tema_articoli_occupied", wpprgf, currentTemaId, currentTipo ?? null],
    enabled: !!wpprgf && !!currentTemaId,
    queryFn: async () => {
      const today = new Date().toISOString().slice(0, 10);
      const { data: temi } = await supabase
        .from("promo_strutturate_temi")
        .select("id, nome, al, tipo")
        .eq("wpprgf", wpprgf);
      // Escludi le offerte scadute (al < oggi): i loro articoli possono essere riassegnati liberamente.
      // Bancale è valutata riga-per-riga: non blocca nessuno e non è bloccata da nessuno.
      // Conflitto solo quando NÉ il tema corrente NÉ l'altro sono Bancale.
      const others = (temi ?? []).filter((t) => {
        if (t.id === currentTemaId) return false;
        if (t.al && t.al < today) return false;
        if ((t as any).tipo === "bancale") return false;
        if (currentTipo === "bancale") return false;
        return true;
      });
      const map = new Map<string, string>();
      if (others.length === 0) return map;
      const ids = others.map((t) => t.id);
      const { data: links } = await supabase
        .from("promo_strutturate_tema_articoli")
        .select("tema_id, cdpar")
        .in("tema_id", ids);
      const nameById = new Map(others.map((t) => [t.id, t.nome]));
      for (const l of links ?? []) {
        const k = normCdpar(l.cdpar);
        if (!map.has(k)) map.set(k, nameById.get(l.tema_id) ?? "altra offerta");
      }
      return map;
    },
  });
}

function reportConflicts(conflicts: { code: string; tema: string }[]) {
  if (conflicts.length === 0) return;
  const preview = conflicts.slice(0, 5).map((c) => `${c.code} → ${c.tema}`).join(", ");
  toast({
    title: `${conflicts.length} codici presenti anche in altre offerte`,
    description: `${preview}${conflicts.length > 5 ? "…" : ""}`,
  });
}


function TemaArticoliInline({ temaId, wpprgf, testata, tipo, qtyUnit }: { temaId: string; wpprgf: number; testata: TestataRow; tipo: TipoOfferta; qtyUnit?: "pezzi" | "confezioni" }) {
  const qc = useQueryClient();
  const { data: occupied = new Map<string, string>() } = useOccupiedByOtherTemi(wpprgf, temaId, tipo);

  const [searchOpen, setSearchOpen] = useState(false);


  const { data: rows = [] } = useQuery({
    queryKey: ["tema_articoli", temaId],
    queryFn: async () => {
      const { data: links, error } = await supabase
        .from("promo_strutturate_tema_articoli")
        .select("cdpar, pezzi_min_confezione")
        .eq("tema_id", temaId);
      if (error) throw error;
      const list = (links ?? []) as any[];
      const codes = Array.from(new Set(list.map((l) => normCdpar(l.cdpar)).filter(Boolean)));
      if (codes.length === 0) return [] as { cdpar: string; depar: string | null; source: string | null; pezzi_min_confezione: number | null; master_pack: number | null; imballo_vendita: number | null; variabile: boolean }[];
      const lookupCodes = Array.from(new Set(codes.flatMap((code) => [code, padCdpar(code)])));
      const [artsRes, srcRes] = await Promise.all([
        supabase.from("archivio_articoli_fraschetti").select("cdpar, depar, master_pack, wimba, wfcvr").in("cdpar", lookupCodes),
        supabase.from("promo_strutturate_articoli" as any).select("cdpar, source").eq("wpprgf", wpprgf).in("cdpar", lookupCodes),
      ]);
      const srcMap = new Map<string, string | null>(((srcRes.data ?? []) as any[]).map((r) => [normCdpar(r.cdpar), r.source ?? null]));
      const descMap = new Map<string, string | null>(((artsRes.data ?? []) as any[]).map((a) => [normCdpar(a.cdpar), a.depar ?? null]));
      const mpMap = new Map<string, number | null>(((artsRes.data ?? []) as any[]).map((a) => [normCdpar(a.cdpar), a.master_pack ?? null]));
      const ivMap = new Map<string, number | null>(((artsRes.data ?? []) as any[]).map((a) => [normCdpar(a.cdpar), a.wimba ?? null]));
      const varMap = new Map<string, boolean>(((artsRes.data ?? []) as any[]).map((a) => [normCdpar(a.cdpar), String(a.wfcvr ?? "").trim().toUpperCase() === "S"]));
      const pmcMap = new Map<string, number | null>(list.map((l) => [normCdpar(l.cdpar), l.pezzi_min_confezione ?? null]));
      return codes.map((code) => ({
        cdpar: code,
        depar: descMap.get(code) ?? null,
        source: srcMap.get(code) ?? null,
        pezzi_min_confezione: pmcMap.get(code) ?? null,
        master_pack: mpMap.get(code) ?? null,
        imballo_vendita: ivMap.get(code) ?? null,
        variabile: varMap.get(code) ?? false,
      }));
    },
  });


  const remove = async (cdpar: string) => {
    const padded = padCdpar(cdpar);
    const { error } = await supabase
      .from("promo_strutturate_tema_articoli")
      .delete()
      .eq("tema_id", temaId)
      .in("cdpar", [cdpar, padded]);
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      return;
    }
    qc.invalidateQueries({ queryKey: ["tema_articoli", temaId] });
    qc.invalidateQueries({ queryKey: ["promo_articoli_temi_map"] });
    qc.invalidateQueries({ queryKey: ["tema_articoli_occupied", wpprgf] });
  };


  const updatePmc = async (cdpar: string, val: string) => {
    const n = val.trim() === "" ? null : Number(val);
    const padded = padCdpar(cdpar);
    const { error } = await supabase
      .from("promo_strutturate_tema_articoli")
      .update({ pezzi_min_confezione: n } as any)
      .eq("tema_id", temaId)
      .in("cdpar", [cdpar, padded]);
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      return;
    }
    qc.invalidateQueries({ queryKey: ["tema_articoli", temaId] });
  };

  const yyyymmddOrNull = (v: any): string | null => {
    if (v == null || v === "") return null;
    const s = String(v).trim();
    return /^\d{8}$/.test(s) ? s : null;
  };

  const bulkImport = async (codes: string[]) => {
    try {
      const allowed: string[] = [...codes];
      const conflicts: { code: string; tema: string }[] = [];
      for (const c of codes) {
        const k = normCdpar(c);
        const t = occupied.get(k);
        if (t) conflicts.push({ code: k, tema: t });
      }
      reportConflicts(conflicts);
      if (allowed.length === 0) return;


      const wdtvi = yyyymmddOrNull((testata as any).wpindoi);
      const wdtvf = yyyymmddOrNull((testata as any).wpindof);
      const poolPayload = allowed.map((c) => ({
        wpprgf, wpprge: null, cdpar: c, source: "manual", wdtvi, wdtvf,
      }));
      const { error: poolErr } = await supabase
        .from("promo_strutturate_articoli" as any)
        .upsert(poolPayload as any, { onConflict: "wpprgf,wpprge,cdpar", ignoreDuplicates: true });
      if (poolErr) throw poolErr;
      const linkPayload = allowed.map((c) => ({ tema_id: temaId, cdpar: padCdpar(c) }));
      const { error: linkErr } = await supabase
        .from("promo_strutturate_tema_articoli")
        .upsert(linkPayload as any, { onConflict: "tema_id,cdpar", ignoreDuplicates: true });
      if (linkErr) throw linkErr;
      qc.invalidateQueries({ queryKey: ["tema_articoli", temaId] });
      qc.invalidateQueries({ queryKey: ["promo_articoli_temi_map"] });
      qc.invalidateQueries({ queryKey: ["promo_articoli", wpprgf] });
      qc.invalidateQueries({ queryKey: ["promo_articoli_pool", wpprgf] });
      qc.invalidateQueries({ queryKey: ["tema_articoli_occupied", wpprgf] });
    } catch (e: any) {
      toast({ title: "Errore import", description: e.message, variant: "destructive" });
    }
  };


  const isBancale = tipo === "bancale";
  const isScagConf = tipo === "scaglioni_qty" && qtyUnit === "confezioni";
  const rowMissing = (r: any) => {
    if (isBancale) return !r.master_pack || r.master_pack <= 0;
    if (isScagConf) return !r.variabile && (!r.imballo_vendita || r.imballo_vendita <= 0);
    return false;
  };
  const missingCount = (isBancale || isScagConf) ? rows.filter(rowMissing).length : 0;
  const missingLabel = isBancale ? "senza qtà bancale" : "senza imballo di vendita";

  return (
    <Card className="overflow-hidden">
      <div className="px-3 py-2 border-b flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-sm font-medium">
          <span>Articoli dell'offerta ({rows.length})</span>
          {(isBancale || isScagConf) && missingCount > 0 && (
            <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-destructive/10 text-destructive text-[10px] font-semibold uppercase tracking-wide border border-destructive/30">
              {missingCount} {missingLabel}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <BulkImportArticoli onImport={bulkImport} />
          <Button size="sm" variant="outline" onClick={() => setSearchOpen(true)}>
            <Plus className="h-4 w-4 mr-1" /> Aggiungi articolo
          </Button>
        </div>
      </div>
      {rows.length === 0 ? (
        <div className="p-4 text-sm text-muted-foreground text-center">
          Nessun articolo. Aggiungi articoli per definire l'offerta.
        </div>
      ) : (
        <ul className="divide-y max-h-72 overflow-auto">
          {rows.map((r) => {
            const isManual = (r.source ?? "") === "manual";
            const missing = rowMissing(r);
            return (
              <li key={r.cdpar} className="px-3 py-1.5 flex items-center gap-3 text-sm">
                <span className="font-mono text-xs w-32">{normCdpar(r.cdpar)}</span>
                {isManual ? (
                  <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-primary/10 text-primary text-[10px] font-semibold uppercase tracking-wide">PIM</span>
                ) : (
                  <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-muted text-muted-foreground text-[10px] font-semibold uppercase tracking-wide border">AS400</span>
                )}
                <span className="flex-1 truncate text-muted-foreground">{r.depar?.trim() || "—"}</span>
                {tipo === "bundle" && (
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] text-muted-foreground">Min pz/conf</span>
                    <Input
                      type="number"
                      min={0}
                      defaultValue={r.pezzi_min_confezione ?? ""}
                      onBlur={(e) => updatePmc(r.cdpar, e.target.value)}
                      className="h-7 w-20 text-right text-xs"
                    />
                  </div>
                )}
                {isBancale && (
                  <div className="flex items-center gap-1" title="Confezionamento master (pz/cartone) dalla scheda articolo → Logistica B2B">
                    <span className="text-[10px] text-muted-foreground">Qtà bancale</span>
                    {missing ? (
                      <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-destructive/10 text-destructive text-[11px] font-semibold border border-destructive/30">
                        — mancante
                      </span>
                    ) : (
                      <span className="font-mono text-xs px-1.5 py-0.5 rounded bg-muted border">{r.master_pack}</span>
                    )}
                  </div>
                )}
                {isScagConf && (
                  <div className="flex items-center gap-1" title="Imballo di vendita (wimba). Se 'Variabile = SI' la confezione conta 1 pezzo.">
                    <span className="text-[10px] text-muted-foreground">Imballo</span>
                    {r.variabile ? (
                      <span className="font-mono text-xs px-1.5 py-0.5 rounded bg-primary/10 text-primary border border-primary/30">1 (variabile)</span>
                    ) : missing ? (
                      <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-destructive/10 text-destructive text-[11px] font-semibold border border-destructive/30">
                        — mancante
                      </span>
                    ) : (
                      <span className="font-mono text-xs px-1.5 py-0.5 rounded bg-muted border">{r.imballo_vendita}</span>
                    )}
                  </div>
                )}
                <Button size="sm" variant="ghost" className="text-destructive h-7 px-2" onClick={() => remove(r.cdpar)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </li>
            );
          })}
        </ul>
      )}


      <AddArticoloToTemaDialog
        open={searchOpen}
        onOpenChange={setSearchOpen}
        temaId={temaId}
        wpprgf={wpprgf}
        testata={testata}
        existing={new Set(rows.map((r) => r.cdpar))}
        occupied={occupied}
        onAdded={() => {
          qc.invalidateQueries({ queryKey: ["tema_articoli", temaId] });
          qc.invalidateQueries({ queryKey: ["promo_articoli_temi_map"] });
          qc.invalidateQueries({ queryKey: ["promo_articoli", wpprgf] });
          qc.invalidateQueries({ queryKey: ["promo_articoli_pool", wpprgf] });
          qc.invalidateQueries({ queryKey: ["tema_articoli_occupied", wpprgf] });
        }}
      />

    </Card>
  );
}

// ───────── Bulk import articoli (XLSX/CSV/paste) — codici 6 cifre ─────────
function BulkImportArticoli({ onImport, skipVerify = false, title = "Importa articoli da elenco", confirmLabel = "Aggiungi" }: { onImport: (codes: string[]) => Promise<void> | void; skipVerify?: boolean; title?: string; confirmLabel?: string; }) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [checking, setChecking] = useState(false);
  const [importing, setImporting] = useState(false);
  const [valid, setValid] = useState<string[]>([]);
  const [missing, setMissing] = useState<string[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);

  const reset = () => { setText(""); setValid([]); setMissing([]); };

  const parseCodes = (raw: string): string[] => {
    return Array.from(new Set(
      raw.split(/[\s,;]+/)
        .map((s) => s.trim())
        .filter(Boolean)
        .map((s) => normCdpar(s))
        .filter((s) => /^\d{6}$/.test(s)),
    ));
  };

  const handleFile = async (file: File) => {
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: "array" });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<any>(sheet, { header: 1, blankrows: false });
    const codes: string[] = [];
    for (const r of rows) {
      const cell = (r as any[])[0];
      if (cell == null) continue;
      const s = String(cell).trim();
      if (!s) continue;
      if (codes.length === 0 && /^(codice|cdpar|articolo|cod|code)/i.test(s)) continue;
      codes.push(s);
    }
    setText(codes.join("\n"));
  };

  const verify = async () => {
    setChecking(true);
    try {
      const codes = parseCodes(text);
      if (codes.length === 0) { setValid([]); setMissing([]); return; }
      const lookup = Array.from(new Set(codes.flatMap((c) => [c, padCdpar(c)])));
      const { data, error } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar")
        .in("cdpar", lookup);
      if (error) throw error;
      const found = new Set(((data ?? []) as any[]).map((r) => normCdpar(r.cdpar)));
      setValid(codes.filter((c) => found.has(c)));
      setMissing(codes.filter((c) => !found.has(c)));
    } catch (e: any) {
      toast({ title: "Errore verifica", description: e.message, variant: "destructive" });
    } finally {
      setChecking(false);
    }
  };

  const confirm = async () => {
    const codes = skipVerify ? parseCodes(text) : valid;
    if (codes.length === 0) {
      toast({ title: "Nessun codice valido", variant: "destructive" });
      return;
    }
    setImporting(true);
    try {
      await onImport(codes);
      toast({ title: `${codes.length} codici aggiunti` });
      setOpen(false);
      reset();
    } finally {
      setImporting(false);
    }
  };

  return (
    <>
      <Button variant="outline" size="sm" onClick={() => setOpen(true)}>
        <Upload className="h-4 w-4 mr-1" /> Importa
      </Button>
      <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) reset(); }}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>{title}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-xs text-muted-foreground">
              Carica un file XLSX/CSV con una sola colonna di codici articolo a <strong>6 cifre</strong> (la prima colonna; eventuale intestazione viene ignorata),
              oppure incolla i codici sotto separati da virgola, spazio o nuova riga.
              Codici più corti vengono zero-paddati a 6.
            </p>
            <div className="flex items-center gap-2">
              <input
                ref={fileRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); e.currentTarget.value = ""; }}
              />
              <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()}>
                <Upload className="h-3 w-3 mr-1" /> Carica file
              </Button>
              <span className="text-xs text-muted-foreground">XLSX, XLS, CSV</span>
            </div>
            <Textarea
              rows={8}
              value={text}
              onChange={(e) => { setText(e.target.value); setValid([]); setMissing([]); }}
              placeholder={"Es:\n100123\n100456\n200789"}
              className="font-mono text-xs"
            />
            {skipVerify ? (
              <div className="text-xs text-muted-foreground">
                <Badge variant="secondary">{parseCodes(text).length} codici riconosciuti</Badge>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="secondary" onClick={verify} disabled={checking || !text.trim()}>
                    {checking ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : null}
                    Verifica codici
                  </Button>
                  {(valid.length > 0 || missing.length > 0) && (
                    <span className="text-xs">
                      <Badge variant="secondary" className="mr-1">{valid.length} validi</Badge>
                      {missing.length > 0 && <Badge variant="destructive">{missing.length} non trovati</Badge>}
                    </span>
                  )}
                </div>
                {missing.length > 0 && (
                  <div className="text-xs text-destructive max-h-24 overflow-auto border rounded p-2">
                    Non trovati: <span className="font-mono">{missing.join(", ")}</span>
                  </div>
                )}
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>Annulla</Button>
            <Button
              size="sm"
              onClick={confirm}
              disabled={importing || (skipVerify ? !text.trim() : valid.length === 0)}
            >
              {importing ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : null}
              {confirmLabel}{skipVerify ? (parseCodes(text).length > 0 ? ` (${parseCodes(text).length})` : "") : (valid.length > 0 ? ` (${valid.length})` : "")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function AddArticoloToTemaDialog({
  open, onOpenChange, temaId, wpprgf, testata, existing, occupied, onAdded,
}: {
  open: boolean; onOpenChange: (b: boolean) => void; temaId: string; wpprgf: number;
  testata: TestataRow;
  existing: Set<string>; occupied: Map<string, string>; onAdded: () => void;
}) {

  const [tab, setTab] = useState<"pool" | "new" | "rules">("pool");
  const [poolQ, setPoolQ] = useState("");
  const [adding, setAdding] = useState<string | null>(null);
  const [creating, setCreating] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [debouncedQ, setDebouncedQ] = useState("");
  const [batchCreating, setBatchCreating] = useState(false);
  const { data: visibleAssortments, isLoading: loadingAssortments } = useVisibleAssortments();

  // Parse incollaggio multi-codice (whitespace, virgola, punto-virgola). Solo numeri 3-15 cifre.
  const parsedBatchCodes = useMemo(() => {
    const tokens = q.split(/[\s,;]+/).map((t) => t.trim()).filter(Boolean);
    const valid = tokens.filter((t) => /^\d{3,15}$/.test(t));
    return Array.from(new Set(valid.map((c) => normCdpar(c))));
  }, [q]);
  const isBatch = parsedBatchCodes.length >= 2;

  useEffect(() => {
    if (!open) { setQ(""); setDebouncedQ(""); setPoolQ(""); setTab("pool"); }
  }, [open]);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQ(q.trim()), 300);
    return () => clearTimeout(t);
  }, [q]);

  const { data: poolRows = [], isLoading: loadingPool } = useQuery({
    queryKey: ["promo_articoli_pool", wpprgf],
    enabled: open,
    queryFn: async () => {
      const { data: arts, error } = await supabase
        .from("promo_strutturate_articoli" as any)
        .select("cdpar, source")
        .eq("wpprgf", wpprgf)
        .order("cdpar", { ascending: true });
      if (error) throw error;
      const list = (arts ?? []) as any[];
      const codes = Array.from(new Set(list.map((r) => normCdpar(r.cdpar)).filter(Boolean)));
      if (codes.length === 0) return [] as { cdpar: string; depar: string | null; source: string | null }[];
      const lookupCodes = Array.from(new Set(codes.flatMap((code) => [code, padCdpar(code)])));
      const { data: descs } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar, depar")
        .in("cdpar", lookupCodes);
      const dmap = new Map<string, string | null>(((descs ?? []) as any[]).map((d) => [normCdpar(d.cdpar), d.depar ?? null]));
      return list.map((r) => ({
        cdpar: normCdpar(r.cdpar),
        source: r.source ?? null,
        depar: dmap.get(normCdpar(r.cdpar)) ?? null,
      }));
    },
  });

  const filteredPool = useMemo(() => {
    const term = poolQ.trim().toLowerCase();
    if (!term) return poolRows;
    return poolRows.filter((r) =>
      r.cdpar.toLowerCase().includes(term) || (r.depar ?? "").toLowerCase().includes(term),
    );
  }, [poolRows, poolQ]);

  const existingCdpar = useMemo(
    () => new Set(Array.from(existing).map((code) => normCdpar(code))),
    [existing],
  );

  const { data: results = [], isLoading } = useQuery({
    queryKey: ["archivio_articoli_search", debouncedQ, visibleAssortments],
    enabled: open && tab === "new" && !isBatch && debouncedQ.length >= 2 && !loadingAssortments,
    queryFn: async () => {
      const term = debouncedQ.replace(/[%_]/g, "");
      let query = supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar, depar, wfuas")
        .or(`cdpar.ilike.%${term}%,depar.ilike.%${term}%`)
        .limit(50);
      if (visibleAssortments && visibleAssortments.length > 0) {
        query = query.in("wfuas", visibleAssortments);
      }
      const { data, error } = await query;
      if (error) throw error;
      return ((data ?? []) as any[]).map((a) => ({ cdpar: normCdpar(a.cdpar), depar: a.depar }));
    },
  });

  // Batch resolve: per più codici incollati, verifica esistenza in archivio (ignora assortimento — l'utente ha incollato codici espliciti).
  const { data: batchResolved, isLoading: batchLoading } = useQuery({
    queryKey: ["temi_batch_resolve", parsedBatchCodes],
    enabled: open && tab === "new" && isBatch,
    queryFn: async () => {
      const lookup = Array.from(new Set(parsedBatchCodes.flatMap((c) => [c, padCdpar(c)])));
      // Chunked: PostgREST URL limit ~8KB. 500 cdpar × ~16 char ≈ safe.
      const CHUNK = 500;
      const map = new Map<string, string | null>();
      for (let i = 0; i < lookup.length; i += CHUNK) {
        const slice = lookup.slice(i, i + CHUNK);
        const { data, error } = await supabase
          .from("archivio_articoli_fraschetti")
          .select("cdpar, depar")
          .in("cdpar", slice);
        if (error) throw error;
        for (const r of (data ?? []) as any[]) {
          map.set(normCdpar(r.cdpar), r.depar ?? null);
        }
      }
      const found: { cdpar: string; depar: string | null }[] = [];
      const missing: string[] = [];
      for (const c of parsedBatchCodes) {
        if (map.has(c)) found.push({ cdpar: c, depar: map.get(c) ?? null });
        else missing.push(c);
      }
      return { found, missing };
    },
  });
  const batchFound = batchResolved?.found ?? [];
  const batchMissing = batchResolved?.missing ?? [];
  const batchAlready = batchFound.filter((r) => existingCdpar.has(r.cdpar));
  const batchInOther = batchFound.filter((r) => !existingCdpar.has(r.cdpar) && occupied.has(r.cdpar));
  const batchToAdd = batchFound.filter((r) => !existingCdpar.has(r.cdpar));


  const existingPoolCdpar = useMemo(() => new Set(poolRows.map((r) => normCdpar(r.cdpar))), [poolRows]);

  const linkOnly = async (cdpar: string) => {
    const trimmed = normCdpar(cdpar);

    const padded = padCdpar(trimmed);
    setAdding(trimmed);
    const { error } = await supabase
      .from("promo_strutturate_tema_articoli")
      .upsert({ tema_id: temaId, cdpar: padded }, { onConflict: "tema_id,cdpar", ignoreDuplicates: true });
    setAdding(null);
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Articolo aggiunto all'offerta" });
    onAdded();
    onOpenChange(false);
  };

  const yyyymmddOrNull = (v: any): string | null => {
    if (v == null || v === "") return null;
    const s = String(v).trim();
    return /^\d{8}$/.test(s) ? s : null;
  };

  const createPimAndLink = async (cdpar: string) => {
    const trimmed = normCdpar(cdpar);
    setCreating(trimmed);

    try {
      if (!existingPoolCdpar.has(trimmed)) {
        const wdtvi = yyyymmddOrNull((testata as any).wpindoi);
        const wdtvf = yyyymmddOrNull((testata as any).wpindof);
        const { error: insErr } = await supabase
          .from("promo_strutturate_articoli" as any)
          .upsert({ wpprgf, wpprge: null, cdpar: trimmed, source: "manual", wdtvi, wdtvf } as any, { onConflict: "wpprgf,wpprge,cdpar", ignoreDuplicates: true });
        if (insErr) throw insErr;
      }
      if (!existingCdpar.has(trimmed)) {
        const padded = padCdpar(trimmed);
        const { error: linkErr } = await supabase
          .from("promo_strutturate_tema_articoli")
          .upsert({ tema_id: temaId, cdpar: padded }, { onConflict: "tema_id,cdpar", ignoreDuplicates: true });
        if (linkErr) throw linkErr;
      }
      toast({ title: "Articolo PIM creato e aggiunto", description: "Verrà inviato ad AS400 al prossimo salvataggio." });
      onAdded();
      onOpenChange(false);
    } catch (e: any) {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    } finally {
      setCreating(null);
    }
  };

  const createBatchPimAndLink = async () => {
    if (batchToAdd.length === 0) return;
    const allowed = batchToAdd;
    const conflicts = batchToAdd
      .filter((r) => occupied.has(r.cdpar))
      .map((r) => ({ code: r.cdpar, tema: occupied.get(r.cdpar)! }));
    reportConflicts(conflicts);
    if (allowed.length === 0) return;

    setBatchCreating(true);
    try {
      const wdtvi = yyyymmddOrNull((testata as any).wpindoi);
      const wdtvf = yyyymmddOrNull((testata as any).wpindof);
      const toInsertPool = allowed.filter((r) => !existingPoolCdpar.has(r.cdpar));
      if (toInsertPool.length > 0) {
        const rows = toInsertPool.map((r) => ({
          wpprgf, wpprge: null, cdpar: r.cdpar, source: "manual", wdtvi, wdtvf,
        }));
        const { error: insErr } = await supabase
          .from("promo_strutturate_articoli" as any)
          .upsert(rows as any, { onConflict: "wpprgf,wpprge,cdpar", ignoreDuplicates: true });
        if (insErr) throw insErr;
      }
      const linkRows = allowed.map((r) => ({ tema_id: temaId, cdpar: padCdpar(r.cdpar) }));
      const { error: linkErr } = await supabase
        .from("promo_strutturate_tema_articoli")
        .upsert(linkRows, { onConflict: "tema_id,cdpar", ignoreDuplicates: true });
      if (linkErr) throw linkErr;
      toast({
        title: `${allowed.length} articoli aggiunti all'offerta`,
        description: batchMissing.length > 0 ? `${batchMissing.length} codici non trovati e ignorati.` : undefined,
      });
      onAdded();
      onOpenChange(false);
    } catch (e: any) {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    } finally {
      setBatchCreating(false);
    }
  };


  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Aggiungi articolo all'offerta</DialogTitle>
        </DialogHeader>

        <div className="flex border-b text-sm">
          <button
            className={cn("px-3 py-2 -mb-px border-b-2", tab === "pool" ? "border-primary text-primary font-medium" : "border-transparent text-muted-foreground hover:text-foreground")}
            onClick={() => setTab("pool")}
          >
            Da articoli della promo ({poolRows.length})
          </button>
          <button
            className={cn("px-3 py-2 -mb-px border-b-2", tab === "new" ? "border-primary text-primary font-medium" : "border-transparent text-muted-foreground hover:text-foreground")}
            onClick={() => setTab("new")}
          >
            Crea nuovo (PIM)
          </button>
          <button
            className={cn("px-3 py-2 -mb-px border-b-2", tab === "rules" ? "border-primary text-primary font-medium" : "border-transparent text-muted-foreground hover:text-foreground")}
            onClick={() => setTab("rules")}
          >
            Per regole (Settore / Reparto / Gamma)
          </button>
        </div>

        {tab === "pool" && (
          <>
            <div className="relative">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input autoFocus value={poolQ} onChange={(e) => setPoolQ(e.target.value)} placeholder="Filtra per codice o descrizione…" className="pl-9" />
            </div>
            <ScrollArea className="h-80 border rounded-md">
              {loadingPool ? (
                <div className="p-3 text-sm text-muted-foreground flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" /> Caricamento…
                </div>
              ) : filteredPool.length === 0 ? (
                <div className="p-4 text-sm text-muted-foreground text-center">
                  {poolRows.length === 0 ? "Nessun articolo nella promo. Crea un articolo PIM dalla tab accanto." : "Nessun risultato."}
                </div>
              ) : (
                <ul className="divide-y">
                  {filteredPool.map((r) => {
                    const trimmed = normCdpar(r.cdpar);
                    const exists = existingCdpar.has(trimmed);
                    const otherTema = occupied.get(trimmed);
                    const isManual = (r.source ?? "") === "manual";
                    return (
                      <li key={r.cdpar} className="px-3 py-2 flex items-center gap-3 hover:bg-muted/40">
                        <span className="font-mono text-xs w-24 shrink-0">{trimmed}</span>
                        {isManual ? (
                          <span className="shrink-0 inline-flex items-center px-1.5 py-0.5 rounded bg-primary/10 text-primary text-[10px] font-semibold uppercase tracking-wide">PIM</span>
                        ) : (
                          <span className="shrink-0 inline-flex items-center px-1.5 py-0.5 rounded bg-muted text-muted-foreground text-[10px] font-semibold uppercase tracking-wide border">AS400</span>
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="text-sm truncate">{r.depar?.trim() || "—"}</div>
                          {otherTema && !exists && (
                            <div className="text-[11px] text-muted-foreground truncate" title={`Anche in "${otherTema}"`}>
                              anche in "{otherTema}"
                            </div>
                          )}
                        </div>
                        <div className="shrink-0">
                          <Button size="sm" variant={exists ? "ghost" : "default"} disabled={exists || adding === trimmed} onClick={() => linkOnly(trimmed)}>
                            {adding === trimmed
                              ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                              : exists
                                ? "Già nell'offerta"
                                : (<><Plus className="h-3.5 w-3.5 mr-1" />Aggiungi</>)}
                          </Button>
                        </div>
                      </li>

                    );
                  })}

                </ul>
              )}
            </ScrollArea>
          </>
        )}

        {tab === "new" && (
          <>
            <p className="text-xs text-muted-foreground">
              Cerca un articolo in archivio, oppure <b>incolla una lista di codici</b> (separati da spazi, virgole o a capo) per aggiungerne molti in blocco.
            </p>
            <div className="relative">
              <Search className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
              <Textarea
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Codice o descrizione (min 2 caratteri), oppure incolla più codici…"
                className="pl-9 min-h-[44px] max-h-32"
                rows={1}
                disabled={loadingAssortments}
              />
            </div>

            {isBatch ? (
              <div className="border rounded-md p-3 space-y-2">
                <div className="text-sm font-medium">
                  Modalità batch — {parsedBatchCodes.length} codici riconosciuti
                </div>
                {batchLoading ? (
                  <div className="text-sm text-muted-foreground flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" /> Verifica in archivio…
                  </div>
                ) : (
                  <>
                    <div className="flex flex-wrap gap-2 text-xs">
                      <Badge variant="default">{batchToAdd.length} da aggiungere</Badge>
                      {batchAlready.length > 0 && (
                        <Badge variant="secondary">{batchAlready.length} già nell'offerta</Badge>
                      )}
                      {batchInOther.length > 0 && (
                        <Badge variant="secondary">{batchInOther.length} anche in altre offerte</Badge>
                      )}
                      {batchMissing.length > 0 && (
                        <Badge variant="destructive">{batchMissing.length} non trovati</Badge>
                      )}
                    </div>
                    {batchInOther.length > 0 && (
                      <div className="text-xs text-muted-foreground max-h-20 overflow-auto border rounded p-2 font-mono">
                        Presenti anche in altre offerte: {batchInOther.map((r) => `${r.cdpar} (${occupied.get(r.cdpar)})`).join(", ")}
                      </div>
                    )}

                    {batchMissing.length > 0 && (
                      <div className="text-xs text-destructive max-h-20 overflow-auto border rounded p-2 font-mono">
                        {batchMissing.join(", ")}
                      </div>
                    )}

                    <Button
                      size="sm"
                      disabled={batchToAdd.length === 0 || batchCreating}
                      onClick={createBatchPimAndLink}
                    >
                      {batchCreating ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Plus className="h-3.5 w-3.5 mr-1" />}
                      Aggiungi {batchToAdd.length} articoli all'offerta
                    </Button>
                  </>
                )}
              </div>
            ) : (
              <ScrollArea className="h-72 border rounded-md">
                {loadingAssortments && (
                  <div className="p-3 text-sm text-muted-foreground flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" /> Caricamento…
                  </div>
                )}
                {!loadingAssortments && debouncedQ.length < 2 && (
                  <div className="p-4 text-sm text-muted-foreground text-center">
                    Digita codice o descrizione per cercare in archivio.
                  </div>
                )}
                {!loadingAssortments && debouncedQ.length >= 2 && isLoading && (
                  <div className="p-3 text-sm text-muted-foreground flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" /> Caricamento…
                  </div>
                )}
                {!loadingAssortments && debouncedQ.length >= 2 && !isLoading && results.length === 0 && (
                  <div className="p-3 text-sm text-muted-foreground">Nessun risultato attivo.</div>
                )}
                <ul className="divide-y">
                  {results.map((r) => {
                    const trimmed = normCdpar(r.cdpar);
                    const inPool = existingPoolCdpar.has(trimmed);
                    const inTema = existingCdpar.has(trimmed);
                    const otherTema = occupied.get(trimmed);
                    return (
                      <li key={r.cdpar} className="px-3 py-2 flex items-center gap-3 hover:bg-muted/40">
                        <span className="font-mono text-xs w-24 shrink-0">{trimmed}</span>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm truncate">{r.depar?.trim() || "—"}</div>
                          {otherTema && !inTema && (
                            <div className="text-[11px] text-muted-foreground truncate" title={`Anche in "${otherTema}"`}>
                              anche in "{otherTema}"
                            </div>
                          )}
                        </div>
                        <div className="shrink-0">
                          {inTema ? (
                            <Button size="sm" variant="ghost" disabled>Già nell'offerta</Button>
                          ) : inPool ? (
                            <Button size="sm" variant="outline" disabled={adding === trimmed} onClick={() => linkOnly(trimmed)}>
                              {adding === trimmed ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Aggiungi (già in promo)"}
                            </Button>
                          ) : (
                            <Button size="sm" disabled={creating === trimmed} onClick={() => createPimAndLink(trimmed)}>
                              {creating === trimmed ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : (<><Plus className="h-3.5 w-3.5 mr-1" />Crea e aggiungi</>)}
                            </Button>
                          )}
                        </div>
                      </li>
                    );
                  })}


                </ul>
              </ScrollArea>
            )}
          </>
        )}

        {tab === "rules" && (
          <RulesImportPanel
            temaId={temaId}
            wpprgf={wpprgf}
            testata={testata}
            existingCdpar={existingCdpar}
            existingPoolCdpar={existingPoolCdpar}
            occupied={occupied}

            visibleAssortments={visibleAssortments ?? []}
            loadingAssortments={loadingAssortments}
            onDone={() => { onAdded(); onOpenChange(false); }}
          />
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Chiudi</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─────────── SCAGLIONI del tema ───────────

function TemaScaglioniInline({ temaId, tipo, omaggioSogliaTipo, qtyUnit }: { temaId: string; tipo: TipoOfferta; omaggioSogliaTipo: OmaggioSogliaTipo; qtyUnit?: "pezzi" | "confezioni" }) {
  const qc = useQueryClient();
  const { data: rows = [] } = useQuery({
    queryKey: ["tema_scaglioni", temaId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("promo_strutturate_tema_scaglioni")
        .select("*")
        .eq("tema_id", temaId)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return (data ?? []) as Scaglione[];
    },
  });

  const refresh = () => qc.invalidateQueries({ queryKey: ["tema_scaglioni", temaId] });

  const add = async () => {
    const { error } = await supabase
      .from("promo_strutturate_tema_scaglioni")
      .insert({ tema_id: temaId, sconto_pct: 0, sort_order: rows.length });
    if (error) toast({ title: "Errore", description: error.message, variant: "destructive" });
    else refresh();
  };

  const update = async (id: string, patch: Partial<Scaglione>) => {
    const { error } = await supabase.from("promo_strutturate_tema_scaglioni").update(patch as any).eq("id", id);
    if (error) toast({ title: "Errore", description: error.message, variant: "destructive" });
    else refresh();
  };

  const del = async (id: string) => {
    const { error } = await supabase.from("promo_strutturate_tema_scaglioni").delete().eq("id", id);
    if (error) toast({ title: "Errore", description: error.message, variant: "destructive" });
    else refresh();
  };

  // Determina quale colonna soglia mostrare
  const sogliaCol: "qty" | "eur" | "righe" = useMemo(() => {
    if (tipo === "scaglioni_qty") return "qty";
    if (tipo === "scaglioni_valore") return "eur";
    if (tipo === "righe_ordine") return "righe";
    if (tipo === "omaggio") return omaggioSogliaTipo === "pezzi" ? "qty" : "eur";
    return "qty";
  }, [tipo, omaggioSogliaTipo]);

  const sogliaLabel = sogliaCol === "qty"
    ? (tipo === "scaglioni_qty" && qtyUnit === "confezioni" ? "Da quantità (conf.)" : "Da quantità (pz)")
    : sogliaCol === "eur" ? "Da importo €" : "Da n° righe";
  const showPct = tipo !== "omaggio";

  return (
    <Card className="overflow-hidden">
      <div className="px-3 py-2 border-b flex items-center justify-between">
        <div className="text-sm font-medium">
          Scaglioni {tipo === "omaggio" ? "omaggio" : ""}
          <span className="text-xs text-muted-foreground font-normal ml-2">vince lo scaglione più alto raggiunto</span>
        </div>
        <Button size="sm" variant="outline" onClick={add}><Plus className="h-4 w-4 mr-1" /> Scaglione</Button>
      </div>
      {rows.length === 0 ? (
        <div className="p-4 text-sm text-muted-foreground text-center">Nessuno scaglione.</div>
      ) : (
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase">
            <tr>
              <th className="text-right px-3 py-2 w-40">{sogliaLabel}</th>
              {showPct && <th className="text-right px-3 py-2 w-28">Sconto %</th>}
              <th className="px-2 w-16"></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((s) => (
              <ScaglioneRow key={s.id} row={s} sogliaCol={sogliaCol} showPct={showPct} onUpdate={update} onDelete={del} />
            ))}
          </tbody>
        </table>
      )}
    </Card>
  );
}

function ScaglioneRow({
  row, sogliaCol, showPct, onUpdate, onDelete,
}: {
  row: Scaglione;
  sogliaCol: "qty" | "eur" | "righe";
  showPct: boolean;
  onUpdate: (id: string, p: Partial<Scaglione>) => void;
  onDelete: (id: string) => void;
}) {
  const [v, setV] = useState(row);
  useEffect(() => setV(row), [row.id]);
  const dirty = JSON.stringify(v) !== JSON.stringify(row);

  const num = (n: number | null) => (n == null ? "" : String(n));
  const setN = (k: keyof Scaglione) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const n = e.target.value === "" ? null : Number(e.target.value);
    setV((s) => ({ ...s, [k]: n as any }));
  };

  const sogliaKey: keyof Scaglione = sogliaCol === "qty" ? "soglia_qty" : sogliaCol === "eur" ? "soglia_eur" : "soglia_righe";
  const step = sogliaCol === "eur" ? "0.01" : "1";

  const persist = () => {
    const patch: Partial<Scaglione> = { [sogliaKey]: v[sogliaKey] } as any;
    if (showPct) patch.sconto_pct = v.sconto_pct ?? 0;
    onUpdate(row.id, patch);
  };

  return (
    <tr className="border-t">
      <td className="px-2 py-1">
        <Input value={num(v[sogliaKey] as any)} onChange={setN(sogliaKey)} type="number" min={0} step={step} className="h-7 text-right" />
      </td>
      {showPct && (
        <td className="px-2 py-1">
          <Input value={num(v.sconto_pct)} onChange={setN("sconto_pct")} type="number" min={0} max={100} step="0.01" className="h-7 text-right" />
        </td>
      )}
      <td className="px-2 py-1 text-right whitespace-nowrap">
        <Button size="sm" variant="ghost" className="h-7 px-2" disabled={!dirty} onClick={persist}>
          <Save className="h-3.5 w-3.5" />
        </Button>
        <Button size="sm" variant="ghost" className="h-7 px-2 text-destructive" onClick={() => onDelete(row.id)}>
          <X className="h-3.5 w-3.5" />
        </Button>
      </td>
    </tr>
  );
}

// ─────────── OMAGGIO articoli ───────────

function TemaOmaggioInline({
  temaId, modalita, isAbbinato, wpprgf,
}: { temaId: string; modalita: OmaggioModalita; isAbbinato: boolean; wpprgf: number }) {
  const qc = useQueryClient();

  const { data: scaglioni = [] } = useQuery({
    queryKey: ["tema_scaglioni", temaId],
    queryFn: async () => {
      const { data } = await supabase
        .from("promo_strutturate_tema_scaglioni")
        .select("*")
        .eq("tema_id", temaId)
        .order("sort_order", { ascending: true });
      return (data ?? []) as Scaglione[];
    },
  });

  const { data: rows = [] } = useQuery({
    queryKey: ["tema_omaggio_articoli", temaId],
    queryFn: async () => {
      const { data: links } = await supabase
        .from("promo_strutturate_tema_omaggio_articoli")
        .select("*")
        .eq("tema_id", temaId)
        .order("sort_order", { ascending: true });
      const list = (links ?? []) as any[];
      const codes = Array.from(new Set(list.map((l) => normCdpar(l.cdpar))));
      let dmap = new Map<string, string | null>();
      if (codes.length) {
        const lookup = Array.from(new Set(codes.flatMap((c) => [c, padCdpar(c)])));
        const { data: descs } = await supabase
          .from("archivio_articoli_fraschetti")
          .select("cdpar, depar")
          .in("cdpar", lookup);
        dmap = new Map(((descs ?? []) as any[]).map((d) => [normCdpar(d.cdpar), d.depar ?? null]));
      }
      return list.map((l) => ({
        id: l.id as string,
        scaglione_id: l.scaglione_id as string | null,
        cdpar: normCdpar(l.cdpar),
        qty: l.qty as number,
        depar: dmap.get(normCdpar(l.cdpar)) ?? null,
      }));
    },
  });

  const refresh = () => qc.invalidateQueries({ queryKey: ["tema_omaggio_articoli", temaId] });

  const [pickerOpen, setPickerOpen] = useState<{ scaglione_id: string | null } | null>(null);

  const addOmaggio = async (cdpar: string, scaglione_id: string | null) => {
    const padded = padCdpar(cdpar);
    const { error } = await supabase
      .from("promo_strutturate_tema_omaggio_articoli")
      .insert({ tema_id: temaId, scaglione_id, cdpar: padded, qty: 1, sort_order: rows.length } as any);
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      return;
    }
    refresh();
  };

  const removeOmaggio = async (id: string) => {
    const { error } = await supabase.from("promo_strutturate_tema_omaggio_articoli").delete().eq("id", id);
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      return;
    }
    refresh();
  };

  const updateQty = async (id: string, qty: number) => {
    const { error } = await supabase.from("promo_strutturate_tema_omaggio_articoli").update({ qty }).eq("id", id);
    if (error) toast({ title: "Errore", description: error.message, variant: "destructive" });
    else refresh();
  };

  const renderList = (filtered: typeof rows, scaglione_id: string | null, title: string) => (
    <div className="border rounded-md overflow-hidden">
      <div className="px-3 py-2 bg-muted/30 flex items-center justify-between">
        <div className="text-xs font-medium">{title}</div>
        <Button size="sm" variant="outline" className="h-7" onClick={() => setPickerOpen({ scaglione_id })}>
          <Plus className="h-3.5 w-3.5 mr-1" /> Articolo
        </Button>
      </div>
      {filtered.length === 0 ? (
        <div className="p-3 text-xs text-muted-foreground text-center">Nessun articolo omaggio.</div>
      ) : (
        <ul className="divide-y text-sm">
          {filtered.map((r) => (
            <li key={r.id} className="px-3 py-1.5 flex items-center gap-2">
              <span className="font-mono text-xs w-28">{normCdpar(r.cdpar)}</span>
              <span className="flex-1 truncate text-muted-foreground">{r.depar?.trim() || "—"}</span>
              <span className="text-[10px] text-muted-foreground">Qty</span>
              <Input type="number" min={1} defaultValue={r.qty} onBlur={(e) => updateQty(r.id, Number(e.target.value) || 1)} className="h-7 w-16 text-right" />
              <Button size="sm" variant="ghost" className="text-destructive h-7 px-2" onClick={() => removeOmaggio(r.id)}>
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );

  return (
    <Card className="p-4 space-y-3">
      <div className="flex items-center gap-2">
        <Gift className="h-4 w-4 text-primary" />
        <div className="text-sm font-medium">Articoli omaggio</div>
        <span className="text-xs text-muted-foreground">
          {modalita === "fisso" && "1 solo articolo, assegnato automaticamente."}
          {modalita === "scelta" && "Il cliente sceglie tra gli articoli configurati."}
          {modalita === "scaglioni" && "Per ogni scaglione configura 1 o più articoli."}
        </span>
      </div>

      {modalita !== "scaglioni" && renderList(rows.filter((r) => !r.scaglione_id), null, modalita === "fisso" ? "Articolo omaggio" : "Articoli a scelta")}

      {modalita === "scaglioni" && (
        scaglioni.length === 0 ? (
          <div className="p-3 text-xs text-muted-foreground text-center border rounded-md">
            Definisci prima gli scaglioni nella card sopra.
          </div>
        ) : (
          <div className="space-y-3">
            {scaglioni.map((s, idx) => {
              const filtered = rows.filter((r) => r.scaglione_id === s.id);
              const sMode = (s.omaggio_modalita ?? "tutti") as "tutti" | "scelta";
              const lbl = `Scaglione ${idx + 1}` + (s.soglia_qty ? ` · ≥ ${s.soglia_qty} pz` : s.soglia_eur ? ` · ≥ €${s.soglia_eur}` : "");
              const setMode = async (m: "tutti" | "scelta") => {
                const { error } = await supabase
                  .from("promo_strutturate_tema_scaglioni")
                  .update({ omaggio_modalita: m } as any)
                  .eq("id", s.id);
                if (error) toast({ title: "Errore", description: error.message, variant: "destructive" });
                else qc.invalidateQueries({ queryKey: ["tema_scaglioni", temaId] });
              };
              return (
                <div key={s.id} className="space-y-1">
                  <div className="flex items-center justify-between gap-2 px-1">
                    <div className="text-xs font-medium">{lbl}</div>
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-muted-foreground mr-1">Cliente riceve:</span>
                      <Button
                        size="sm"
                        variant={sMode === "tutti" ? "default" : "outline"}
                        className="h-6 px-2 text-xs"
                        onClick={() => setMode("tutti")}
                      >Tutti</Button>
                      <Button
                        size="sm"
                        variant={sMode === "scelta" ? "default" : "outline"}
                        className="h-6 px-2 text-xs"
                        onClick={() => setMode("scelta")}
                      >A scelta (1)</Button>
                    </div>
                  </div>
                  {renderList(filtered, s.id, sMode === "scelta" ? "Articoli — il cliente ne sceglie 1" : "Articoli — assegnati tutti")}
                </div>
              );
            })}
          </div>
        )
      )}

      <OmaggioPickerDialog
        open={!!pickerOpen}
        onOpenChange={(o) => !o && setPickerOpen(null)}
        onPick={(c) => {
          if (pickerOpen) addOmaggio(c, pickerOpen.scaglione_id);
          setPickerOpen(null);
        }}
      />
    </Card>
  );
}

function OmaggioPickerDialog({ open, onOpenChange, onPick }: { open: boolean; onOpenChange: (b: boolean) => void; onPick: (cdpar: string) => void }) {
  const [q, setQ] = useState("");
  const [debouncedQ, setDebouncedQ] = useState("");
  const { data: visibleAssortments, isLoading: loadingAssortments } = useVisibleAssortments();

  useEffect(() => { if (!open) { setQ(""); setDebouncedQ(""); } }, [open]);
  useEffect(() => {
    const t = setTimeout(() => setDebouncedQ(q.trim()), 300);
    return () => clearTimeout(t);
  }, [q]);

  const { data: results = [], isLoading } = useQuery({
    queryKey: ["omaggio_search", debouncedQ, visibleAssortments],
    enabled: open && debouncedQ.length >= 2 && !loadingAssortments,
    queryFn: async () => {
      const term = debouncedQ.replace(/[%_]/g, "");
      let query = supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar, depar")
        .or(`cdpar.ilike.%${term}%,depar.ilike.%${term}%`)
        .limit(50);
      if (visibleAssortments && visibleAssortments.length > 0) {
        query = query.in("wfuas", visibleAssortments);
      }
      const { data } = await query;
      return ((data ?? []) as any[]).map((a) => ({ cdpar: a.cdpar, depar: a.depar }));
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader><DialogTitle>Scegli articolo omaggio</DialogTitle></DialogHeader>
        <div className="relative">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Codice o descrizione (min 2 caratteri)…" className="pl-9" />
        </div>
        <ScrollArea className="h-72 border rounded-md">
          {debouncedQ.length < 2 && <div className="p-3 text-sm text-muted-foreground">Digita per cercare.</div>}
          {debouncedQ.length >= 2 && isLoading && <div className="p-3 text-sm text-muted-foreground flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Caricamento…</div>}
          {debouncedQ.length >= 2 && !isLoading && results.length === 0 && <div className="p-3 text-sm text-muted-foreground">Nessun risultato.</div>}
          <ul className="divide-y">
            {results.map((r) => (
              <li key={r.cdpar} className="px-3 py-2 flex items-center gap-3 hover:bg-muted/40">
                <span className="font-mono text-xs w-32">{normCdpar(r.cdpar)}</span>
                <span className="flex-1 text-sm truncate">{r.depar?.trim() || "—"}</span>
                <Button size="sm" onClick={() => onPick(normCdpar(r.cdpar))}><Plus className="h-3.5 w-3.5 mr-1" />Aggiungi</Button>
              </li>
            ))}
          </ul>
        </ScrollArea>
        <DialogFooter><Button variant="outline" onClick={() => onOpenChange(false)}>Chiudi</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─────────── Importa per regole (Settore / Reparto / Gamma / Fornitore) ───────────

function MiniMultiPicker({
  label, values, onChange, options, loading, placeholder = "Tutti",
}: {
  label: string;
  values: string[];
  onChange: (v: string[]) => void;
  options: { value: string; label: string }[];
  loading?: boolean;
  placeholder?: string;
}) {
  const [open, setOpen] = useState(false);
  const toggle = (v: string) =>
    onChange(values.includes(v) ? values.filter((x) => x !== v) : [...values, v]);
  return (
    <div className="space-y-1">
      <Label className="text-xs">{label}</Label>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="w-full justify-start font-normal h-8">
            {values.length === 0 ? (
              <span className="text-muted-foreground">{placeholder}</span>
            ) : (
              <span>{values.length} selezionati</span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="p-0 w-80" align="start">
          <Command>
            <CommandInput placeholder={`Cerca ${label.toLowerCase()}...`} />
            <CommandList>
              {loading ? (
                <div className="p-3 text-xs text-muted-foreground flex items-center gap-2">
                  <Loader2 className="h-3 w-3 animate-spin" /> Carico…
                </div>
              ) : (
                <>
                  <CommandEmpty>Nessun risultato.</CommandEmpty>
                  <CommandGroup>
                    {options.map((o) => (
                      <CommandItem key={o.value} onSelect={() => toggle(o.value)}>
                        <input type="checkbox" checked={values.includes(o.value)} readOnly className="mr-2" />
                        <span className="text-xs">{o.label}</span>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </>
              )}
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
      {values.length > 0 && (
        <div className="flex flex-wrap gap-1 pt-1">
          {values.map((v) => {
            const opt = options.find((o) => o.value === v);
            return (
              <Badge key={v} variant="outline" className="text-xs gap-1">
                {opt?.label ?? v}
                <button onClick={() => toggle(v)}><X className="h-3 w-3" /></button>
              </Badge>
            );
          })}
        </div>
      )}
    </div>
  );
}

function RulesImportPanel({
  temaId, wpprgf, testata, existingCdpar, existingPoolCdpar, occupied, visibleAssortments, loadingAssortments, onDone,
}: {
  temaId: string;
  wpprgf: number;
  testata: TestataRow;
  existingCdpar: Set<string>;
  existingPoolCdpar: Set<string>;
  occupied: Map<string, string>;
  visibleAssortments: string[];
  loadingAssortments: boolean;
  onDone: () => void;
}) {

  const [clmer, setClmer] = useState<string[]>([]);
  const [reparto, setReparto] = useState<string[]>([]);
  const [gamma, setGamma] = useState<string[]>([]);
  const [pcfor, setPcfor] = useState<string[]>([]);
  const [importing, setImporting] = useState(false);

  const clmerDistinct = useDistinctValues("clmer");
  const pcforDistinct = useDistinctValues("pcfor");
  const { data: clmerLookup } = useLookupValues("clmer");
  const { data: repartoLookup } = useLookupValues("reparto");
  const { data: gammaLookup } = useLookupValues("gamma");

  const { data: supplierMap } = useQuery({
    queryKey: ["promo_rules_suppliers_map"],
    queryFn: async () => {
      const map: Record<string, string> = {};
      let from = 0;
      const PAGE = 1000;
      // eslint-disable-next-line no-constant-condition
      while (true) {
        const { data, error } = await supabase
          .from("archivio_fornitori_fraschetti")
          .select("cdfor,rasfo")
          .range(from, from + PAGE - 1);
        if (error) throw error;
        const rows = data ?? [];
        rows.forEach((s: any) => {
          const k = String(s.cdfor ?? "").trim();
          if (k) map[k] = String(s.rasfo ?? "").trim();
        });
        if (rows.length < PAGE) break;
        from += PAGE;
      }
      return map;
    },
  });

  const clmerLabelMap = useMemo(() => {
    const m: Record<string, string> = {};
    (clmerLookup ?? []).forEach((l) => { m[l.code] = l.label || l.code; });
    return m;
  }, [clmerLookup]);

  const settoreOptions = useMemo(
    () => (clmerDistinct.data ?? []).map((v) => ({ value: v, label: clmerLabelMap[v] ? `${v} - ${clmerLabelMap[v]}` : v })),
    [clmerDistinct.data, clmerLabelMap],
  );
  const repartoOptions = useMemo(() => {
    const lookups = repartoLookup ?? [];
    const filtered = clmer.length > 0
      ? lookups.filter((l) => l.parent_code && clmer.includes(l.parent_code))
      : lookups;
    return filtered.map((l) => ({ value: l.code, label: l.label || l.code }));
  }, [repartoLookup, clmer]);
  const gammaOptions = useMemo(() => {
    const lookups = gammaLookup ?? [];
    const filtered = reparto.length > 0
      ? lookups.filter((l) => l.parent_code && reparto.includes(l.parent_code))
      : lookups;
    return filtered.map((l) => ({ value: l.code, label: l.label || l.code }));
  }, [gammaLookup, reparto]);
  const pcforOptions = useMemo(
    () => (pcforDistinct.data ?? []).map((v) => ({
      value: v,
      label: supplierMap?.[v] ? `${v} - ${supplierMap[v]}` : v,
    })),
    [pcforDistinct.data, supplierMap],
  );

  const hasAnyFilter = clmer.length + reparto.length + gamma.length + pcfor.length > 0;

  const { data: matched, isFetching: previewing, refetch: runPreview } = useQuery({
    queryKey: ["rules_import_preview", clmer, reparto, gamma, pcfor, visibleAssortments],
    enabled: false,
    queryFn: async () => {
      let query = supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar, depar")
        .limit(5000);
      if (clmer.length > 0) query = query.in("clmer", clmer);
      if (pcfor.length > 0) query = query.in("pcfor", pcfor);
      if (visibleAssortments.length > 0) query = query.in("wfuas", visibleAssortments);
      // attributes->>'reparto' / 'gamma' filter via .or with eq
      if (reparto.length > 0) {
        const or = reparto.map((r) => `attributes->>reparto.eq.${r}`).join(",");
        query = query.or(or);
      }
      if (gamma.length > 0) {
        const or = gamma.map((g) => `attributes->>gamma.eq.${g}`).join(",");
        query = query.or(or);
      }
      const { data, error } = await query;
      if (error) throw error;
      return ((data ?? []) as any[]).map((a) => ({ cdpar: normCdpar(a.cdpar), depar: a.depar }));
    },
  });

  const yyyymmddOrNull = (v: any): string | null => {
    if (v == null || v === "") return null;
    const s = String(v).trim();
    return /^\d{8}$/.test(s) ? s : null;
  };

  const importAll = async () => {
    if (!matched || matched.length === 0) return;
    const allowed = matched;
    const conflicts = matched
      .filter((r) => occupied.has(r.cdpar))
      .map((r) => ({ code: r.cdpar, tema: occupied.get(r.cdpar)! }));
    reportConflicts(conflicts);
    if (allowed.length === 0) return;
    setImporting(true);
    try {
      const wdtvi = yyyymmddOrNull((testata as any).wpindoi);
      const wdtvf = yyyymmddOrNull((testata as any).wpindof);
      const toCreatePool = allowed.filter((r) => !existingPoolCdpar.has(r.cdpar));
      if (toCreatePool.length > 0) {
        const rows = toCreatePool.map((r) => ({
          wpprgf, wpprge: null, cdpar: r.cdpar, source: "manual" as const, wdtvi, wdtvf,
        }));
        const CHUNK = 500;
        for (let i = 0; i < rows.length; i += CHUNK) {
          const slice = rows.slice(i, i + CHUNK);
          const { error } = await supabase
            .from("promo_strutturate_articoli" as any)
            .upsert(slice as any, { onConflict: "wpprgf,wpprge,cdpar", ignoreDuplicates: true });
          if (error) throw error;
        }
      }
      const toLink = allowed.filter((r) => !existingCdpar.has(r.cdpar));
      if (toLink.length > 0) {
        const rows = toLink.map((r) => ({ tema_id: temaId, cdpar: padCdpar(r.cdpar) }));
        const CHUNK = 500;
        for (let i = 0; i < rows.length; i += CHUNK) {
          const slice = rows.slice(i, i + CHUNK);
          const { error } = await supabase
            .from("promo_strutturate_tema_articoli")
            .upsert(slice as any, { onConflict: "tema_id,cdpar", ignoreDuplicates: true });
          if (error) throw error;
        }
      }
      toast({ title: `Importati ${allowed.length} articoli nell'offerta` });
      onDone();
    } catch (e: any) {
      toast({ title: "Errore import", description: e.message, variant: "destructive" });
    } finally {
      setImporting(false);
    }
  };


  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground">
        Seleziona Settore / Reparto / Gamma / Fornitore. Tutti gli articoli che soddisfano i filtri (negli assortimenti attivi) vengono aggiunti all'offerta come articoli PIM.
      </p>
      <div className="grid grid-cols-2 gap-2">
        <MiniMultiPicker
          label="Settore"
          values={clmer}
          onChange={(v) => { setClmer(v); setReparto([]); setGamma([]); }}
          options={settoreOptions}
          loading={clmerDistinct.isLoading}
        />
        <MiniMultiPicker
          label="Reparto"
          values={reparto}
          onChange={(v) => { setReparto(v); setGamma([]); }}
          options={repartoOptions}
        />
        <MiniMultiPicker
          label="Gamma"
          values={gamma}
          onChange={setGamma}
          options={gammaOptions}
        />
        <MiniMultiPicker
          label="Fornitore"
          values={pcfor}
          onChange={setPcfor}
          options={pcforOptions}
          loading={pcforDistinct.isLoading}
        />
      </div>

      <div className="flex items-center gap-2">
        <Button size="sm" variant="outline" onClick={() => runPreview()} disabled={!hasAnyFilter || previewing || loadingAssortments}>
          {previewing ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Filter className="h-3.5 w-3.5 mr-1" />}
          Anteprima
        </Button>
        {matched && (
          <span className="text-xs text-muted-foreground">{matched.length} articoli trovati</span>
        )}
        <div className="flex-1" />
        <Button size="sm" onClick={importAll} disabled={!matched || matched.length === 0 || importing}>
          {importing ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Plus className="h-3.5 w-3.5 mr-1" />}
          Importa tutti
        </Button>
      </div>

      <ScrollArea className="h-60 border rounded-md">
        {!matched ? (
          <div className="p-4 text-xs text-muted-foreground text-center">
            Imposta i filtri e clicca "Anteprima".
          </div>
        ) : matched.length === 0 ? (
          <div className="p-4 text-xs text-muted-foreground text-center">Nessun articolo corrisponde ai filtri.</div>
        ) : (
          <ul className="divide-y">
            {matched.slice(0, 200).map((r) => (
              <li key={r.cdpar} className="px-3 py-1.5 flex items-center gap-2 text-xs">
                <span className="font-mono w-32">{r.cdpar}</span>
                <span className="flex-1 truncate text-muted-foreground">{r.depar?.trim() || "—"}</span>
                {existingCdpar.has(r.cdpar) && (
                  <span className="text-[10px] text-muted-foreground">già nell'offerta</span>
                )}
              </li>
            ))}
            {matched.length > 200 && (
              <li className="px-3 py-2 text-[10px] text-muted-foreground text-center">
                …e altri {matched.length - 200} non mostrati. Saranno tutti importati.
              </li>
            )}
          </ul>
        )}
      </ScrollArea>
    </div>
  );
}

// ─────────── Lista temi (ordinamento gestito in Marketing B2B → Ordine promo B2B) ───────────

function TemiSortableList({
  temi, selectedId, onSelect,
}: {
  temi: Tema[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onReordered?: () => void;
}) {
  return (
    <ul className="divide-y">
      {temi.map((t) => {
        const linkedTo = t.omaggio_collegato_a ? temi.find((x) => x.id === t.omaggio_collegato_a) : null;
        const requiresTema = t.requires_tema_id ? temi.find((x) => x.id === t.requires_tema_id) : null;
        const selected = selectedId === t.id;
        return (
          <li key={t.id}>
            <button
              onClick={() => onSelect(t.id)}
              className={cn("w-full flex items-center gap-2 px-2 py-2 hover:bg-muted/50 text-left", selected && "bg-primary/10")}
            >
              <div className="w-8 h-8 rounded bg-muted overflow-hidden shrink-0 flex items-center justify-center">
                {t.image_url ? (
                  <img src={t.image_url} alt="" className="w-full h-full object-cover" />
                ) : t.tipo === "omaggio" ? (
                  <Gift className="h-4 w-4 text-muted-foreground/50" />
                ) : (
                  <Layers className="h-4 w-4 text-muted-foreground/50" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">{t.nome}</div>
                <div className="flex items-center gap-1 mt-0.5">
                  <span className="inline-flex items-center px-1 py-0 rounded bg-muted text-[9px] font-semibold uppercase text-muted-foreground border">
                    {TIPO_BADGE[t.tipo ?? "sconto_base"]}
                  </span>
                  {linkedTo && (
                    <span className="text-[9px] text-muted-foreground truncate">→ {linkedTo.nome}</span>
                  )}
                  {requiresTema && (
                    <span className="text-[9px] text-amber-700 dark:text-amber-400 truncate" title={`Si attiva solo se "${requiresTema.nome}" è raggiunta nello stesso ordine`}>
                      ↳ richiede {requiresTema.nome}
                    </span>
                  )}
                </div>
              </div>
            </button>
          </li>
        );
      })}
    </ul>
  );
}

function TemaDatePicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const selected = value ? parseISO(value) : undefined;
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className={cn(
            "h-9 w-full justify-start text-left font-normal",
            !selected && "text-muted-foreground",
          )}
        >
          <CalendarIcon className="mr-2 h-4 w-4 opacity-60" />
          {selected ? format(selected, "dd/MM/yyyy", { locale: it }) : <span>—</span>}
          {selected && (
            <span
              role="button"
              tabIndex={0}
              onClick={(e) => { e.preventDefault(); e.stopPropagation(); onChange(""); }}
              className="ml-auto opacity-60 hover:opacity-100"
              aria-label="Cancella data"
            >
              <X className="h-4 w-4" />
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar
          mode="single"
          selected={selected}
          onSelect={(d) => onChange(d ? format(d, "yyyy-MM-dd") : "")}
          defaultMonth={selected ?? new Date()}
          locale={it}
          initialFocus
          className={cn("p-3 pointer-events-auto")}
        />
      </PopoverContent>
    </Popover>
  );
}

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, Save, ChevronDown, ChevronRight as ChevR, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { PromoField } from "./PromoField";
import { CAMPAGNE_FIELDS } from "./fields";
import { usePromoSave } from "@/hooks/usePromoSave";
import { toast } from "@/hooks/use-toast";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { formatYyyymmddDisplay } from "@/lib/as400DateUtils";

interface Props {
  elementoWprogre: number;
  testataWprogr: number | null;
  elementoWpprge: number | null;
  testataWpprgf: number | null;
}

interface CampRow {
  id: string;
  wpprga: number | null;
  wpprgta: number | null;
  wpprgea: number | null;
  wpcdcla: string | null;
  wpcdlsa: string | null;
  wpdtvia: number | null;
  wpdtvfa: number | null;
  wpnrsca: number | null;
  [k: string]: any;
}

export function PromoCampagneInline({
  elementoWprogre,
  testataWprogr,
  elementoWpprge,
  testataWpprgf,
}: Props) {
  const qc = useQueryClient();
  const [openId, setOpenId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["promo_campagne", elementoWprogre],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("promo_strutturate_campagne")
        .select("*")
        .eq("wpprgea", elementoWprogre)
        .order("wpprga", { ascending: true });
      if (error) throw error;
      return data as CampRow[];
    },
  });

  const handleCreate = async () => {
    setCreating(true);
    try {
      const { data: maxRow } = await supabase
        .from("promo_strutturate_campagne")
        .select("wpprga")
        .order("wpprga", { ascending: false })
        .limit(1)
        .single();
      const nextWpprga = Number(maxRow?.wpprga ?? 0) + 1;
      const { error } = await supabase.from("promo_strutturate_campagne").insert({
        wpprga: nextWpprga,
        wpprgta: testataWprogr,
        wpprgea: elementoWprogre,
        wpnrsca: 1,
      } as any);
      if (error) throw error;
      toast({ title: "Campagna creata" });
      qc.invalidateQueries({ queryKey: ["promo_campagne", elementoWprogre] });
    } catch (e: any) {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="border-t pt-3 mt-3">
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-sm font-semibold">Campagne associate</h4>
        <Button size="sm" variant="outline" onClick={handleCreate} disabled={creating}>
          <Plus className="h-3 w-3 mr-1" />
          Aggiungi
        </Button>
      </div>

      {isLoading ? (
        <div className="text-xs text-muted-foreground flex items-center gap-1 p-2">
          <Loader2 className="h-3 w-3 animate-spin" /> Caricamento…
        </div>
      ) : (
        <div className="space-y-1">
          {(data ?? []).map((c) => (
            <CampagnaRow
              key={c.id}
              row={c}
              testataWpprgf={testataWpprgf}
              elementoWpprge={elementoWpprge}
              open={openId === c.id}
              onToggle={() => setOpenId(openId === c.id ? null : c.id)}
              onChanged={() => refetch()}
            />
          ))}
          {data && data.length === 0 && (
            <div className="text-xs text-muted-foreground p-2">Nessuna campagna associata.</div>
          )}
        </div>
      )}
    </div>
  );
}

function CampagnaRow({
  row,
  testataWpprgf,
  elementoWpprge,
  open,
  onToggle,
  onChanged,
}: {
  row: CampRow;
  testataWpprgf: number | null;
  elementoWpprge: number | null;
  open: boolean;
  onToggle: () => void;
  onChanged: () => void;
}) {
  const confirm = useConfirm();
  const [values, setValues] = useState<Record<string, any>>({ ...row });
  const [advOpen, setAdvOpen] = useState(false);

  const save = usePromoSave({
    table: "promo_strutturate_campagne",
    keyColumns: { wpprga: row.wpprga },
    recordId: `${testataWpprgf ?? "?"}/${elementoWpprge ?? "?"}/${row.wpprga ?? "?"}`,
    oldValues: row,
    filenamePrefix: "as400_promo_campagna",
    invalidate: [["promo_campagne"]],
  });

  const del = usePromoSave({
    table: "promo_strutturate_campagne",
    keyColumns: { wpprga: row.wpprga },
    recordId: `${testataWpprgf ?? "?"}/${elementoWpprge ?? "?"}/${row.wpprga ?? "?"}`,
    filenamePrefix: "as400_promo_campagna",
    invalidate: [["promo_campagne"]],
  });

  const main = CAMPAGNE_FIELDS.filter((f) => f.group !== "advanced");
  const adv = CAMPAGNE_FIELDS.filter((f) => f.group === "advanced");

  return (
    <Card className="bg-muted/30">
      <button
        onClick={onToggle}
        className="w-full flex items-center gap-2 px-2 py-1.5 hover:bg-muted/50 text-left text-sm"
      >
        {open ? <ChevronDown className="h-3 w-3" /> : <ChevR className="h-3 w-3" />}
        <span className="font-mono text-xs text-muted-foreground w-16">#{row.wpprga ?? "—"}</span>
        <span className="flex-1 truncate">
          Cliente: <span className="font-mono">{row.wpcdcla?.trim() || "—"}</span>
          {row.wpcdlsa != null && (
            <span className="ml-2 text-muted-foreground">listino {row.wpcdlsa}</span>
          )}
        </span>
        <span className="text-xs text-muted-foreground">
          {formatYyyymmddDisplay(row.wpdtvia)} → {formatYyyymmddDisplay(row.wpdtvfa)}
        </span>
        {row.wpnrsca != null && (
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-background border">scag. {row.wpnrsca}</span>
        )}
      </button>

      {open && (
        <div className="p-3 border-t bg-background space-y-3">
          <div className="flex items-center justify-end gap-2">
            <Button
              size="sm"
              variant="destructive"
              onClick={async () => {
                if (await confirm({ title: "Eliminare questa campagna?", destructive: true, confirmText: "Elimina" })) {
                  del.mutate({ newValues: {}, operation: "delete" }, { onSuccess: onChanged });
                }
              }}
              disabled={del.isPending}
            >
              <Trash2 className="h-4 w-4 mr-1" />
              Elimina
            </Button>
            <Button
              size="sm"
              onClick={() => save.mutate({ newValues: values, operation: "update" }, { onSuccess: onChanged })}
              disabled={save.isPending}
            >
              <Save className="h-4 w-4 mr-1" />
              Salva
            </Button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {main.map((def) => (
              <PromoField
                key={def.key}
                def={def}
                value={values[def.key]}
                onChange={(v) => setValues((s) => ({ ...s, [def.key]: v }))}
              />
            ))}
          </div>
          <div>
            <button
              type="button"
              onClick={() => setAdvOpen((s) => !s)}
              className="flex items-center gap-2 text-xs font-medium px-2 py-1 hover:bg-muted/50 rounded"
            >
              {advOpen ? <ChevronDown className="h-3 w-3" /> : <ChevR className="h-3 w-3" />}
              Avanzati ({adv.length})
            </button>
            {advOpen && (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 mt-2">
                {adv.map((def) => (
                  <PromoField
                    key={def.key}
                    def={def}
                    value={values[def.key]}
                    onChange={(v) => setValues((s) => ({ ...s, [def.key]: v }))}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </Card>
  );
}

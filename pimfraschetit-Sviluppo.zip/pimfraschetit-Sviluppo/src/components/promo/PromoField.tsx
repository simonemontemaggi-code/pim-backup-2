import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, X } from "lucide-react";
import { yyyymmddToDate, dateToYyyymmdd, formatYyyymmddDisplay } from "@/lib/as400DateUtils";
import type { PromoFieldDef } from "./fields";
import { cn } from "@/lib/utils";

interface Props {
  def: PromoFieldDef;
  value: any;
  onChange: (v: any) => void;
  disabled?: boolean;
  className?: string;
}

export function PromoField({ def, value, onChange, disabled, className }: Props) {
  const ro = def.readOnly || disabled;

  const renderControl = () => {
    if (def.kind === "date") {
      const selected = yyyymmddToDate(value) ?? undefined;
      const currentYear = new Date().getFullYear();
      return (
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              disabled={ro}
              className={cn(
                "h-9 w-full justify-start text-left font-normal",
                !selected && "text-muted-foreground",
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4 opacity-60" />
              {selected ? formatYyyymmddDisplay(value) : <span>—</span>}
              {selected && !ro && (
                <X
                  className="ml-auto h-4 w-4 opacity-50 hover:opacity-100"
                  onClick={(e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    onChange(null);
                  }}
                />
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={selected}
              onSelect={(d) => onChange(dateToYyyymmdd(d ?? null))}
              defaultMonth={selected ?? new Date()}
              captionLayout="dropdown-buttons"
              fromYear={2000}
              toYear={currentYear + 5}
              initialFocus
              className={cn("p-3 pointer-events-auto")}
            />
          </PopoverContent>
        </Popover>
      );
    }
    if (def.kind === "number") {
      return (
        <Input
          type="number"
          value={value ?? ""}
          onChange={(e) => onChange(e.target.value === "" ? null : Number(e.target.value))}
          disabled={ro}
          className="h-9"
        />
      );
    }
    if (def.kind === "flag") {
      const isBool = typeof value === "boolean";
      const checked = value === "S" || value === true;
      return (
        <div className="flex items-center h-9">
          <Switch
            checked={checked}
            onCheckedChange={(c) => onChange(isBool ? c : c ? "S" : "N")}
            disabled={ro}
          />
          <span className="ml-2 text-xs text-muted-foreground">{checked ? "Sì" : "No"}</span>
        </div>
      );
    }
    if (def.kind === "select" && def.options) {
      return (
        <Select value={value ?? ""} onValueChange={(v) => onChange(v || null)} disabled={ro}>
          <SelectTrigger className="h-9">
            <SelectValue placeholder="—" />
          </SelectTrigger>
          <SelectContent>
            {def.options.map((o) => (
              <SelectItem key={o.value} value={o.value}>
                {o.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      );
    }
    return (
      <Input
        type="text"
        value={value ?? ""}
        onChange={(e) => onChange(e.target.value === "" ? null : e.target.value)}
        disabled={ro}
        className="h-9"
      />
    );
  };

  const isEmpty = value === null || value === undefined || value === "" || value === 0;
  const showError = def.required && !def.readOnly && isEmpty;
  return (
    <div className={cn("flex flex-col gap-1", className)}>
      <Label className={cn("text-xs", showError ? "text-destructive" : "text-muted-foreground")}>
        {def.label}
        {def.required && <span className="ml-0.5 text-destructive">*</span>}
        <span className="ml-1 opacity-40 font-mono">({def.key})</span>
      </Label>
      <div className={cn(showError && "[&_button]:border-destructive [&_input]:border-destructive [&_[role=combobox]]:border-destructive")}>
        {renderControl()}
      </div>
    </div>
  );
}

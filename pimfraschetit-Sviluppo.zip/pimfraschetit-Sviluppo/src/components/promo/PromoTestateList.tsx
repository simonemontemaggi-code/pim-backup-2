import { useEffect, useMemo, useState } from "react";
import { Loader2, Plus, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatYyyymmddDisplay } from "@/lib/as400DateUtils";
import { cn } from "@/lib/utils";
import type { Tables } from "@/integrations/supabase/types";

type StatusFilter = "all" | "active" | "future" | "past";

function todayYyyymmdd(): number {
  const d = new Date();
  return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
}

type TestataDbRow = Tables<"promo_strutturate_testate">;

export interface TestataRow extends Partial<TestataDbRow> {
  id: string;
  wpprgf: number | null;
  wprogr: number | null;
  wptpbd: string | null;
  wpcca: string | null;
  wpstato: string | null;
  wptpca: string | null;
  wpdvali: number | null;
  wpdvalf: number | null;
}

interface Props {
  selectedId: string | null;
  onSelect: (row: TestataRow) => void;
  onNew?: () => void;
  refreshKey?: number;
}

export function PromoTestateList({ selectedId, onSelect, onNew, refreshKey }: Props) {
  const [rows, setRows] = useState<TestataRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<StatusFilter>("all");

  useEffect(() => {
    let alive = true;
    setLoading(true);
    supabase
      .from("promo_strutturate_testate")
      .select("*")
      .order("wpprgf", { ascending: false, nullsFirst: false })
      .limit(500)
      .then(({ data, error }) => {
        if (!alive) return;
        if (!error && data) setRows(data as TestataRow[]);
        setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [refreshKey]);

  const counts = useMemo(() => {
    const today = todayYyyymmdd();
    const c = { all: rows.length, active: 0, future: 0, past: 0 };
    for (const r of rows) {
      const di = r.wpdvali ?? 0;
      const df = r.wpdvalf ?? 0;
      if (di && di > today) c.future++;
      else if (df && df < today) c.past++;
      else c.active++;
    }
    return c;
  }, [rows]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const today = todayYyyymmdd();
    const classify = (r: TestataRow) => {
      const di = r.wpdvali ?? 0;
      const df = r.wpdvalf ?? 0;
      if (di && di > today) return "future" as const;
      if (df && df < today) return "past" as const;
      return "active" as const;
    };
    const list = rows.filter((r) => {
      if (status !== "all") {
        const cls = classify(r);
        if (status === "active" && cls !== "active") return false;
        if (status === "future" && cls !== "future") return false;
        if (status === "past" && cls !== "past") return false;
      }
      if (!q) return true;
      return (
        String(r.wpprgf ?? "").includes(q) ||
        (r.wptpbd ?? "").toLowerCase().includes(q) ||
        (r.wpcca ?? "").toLowerCase().includes(q)
      );
    });
    if (status === "all") {
      // Mostra prima le attive, poi future, poi passate; dentro ogni gruppo wpprgf desc.
      const rank = { active: 0, future: 1, past: 2 } as const;
      list.sort((a, b) => {
        const ra = rank[classify(a)] - rank[classify(b)];
        if (ra !== 0) return ra;
        return (b.wpprgf ?? 0) - (a.wpprgf ?? 0);
      });
    }
    return list;
  }, [rows, search, status]);

  return (
    <div className="flex h-full min-h-0 flex-col border-r bg-card">
      <div className="p-3 border-b space-y-2">
        {onNew && (
        <Button onClick={onNew} size="sm" className="w-full">
          <Plus className="h-4 w-4 mr-1" />
          Nuova
        </Button>
        )}
        <div className="relative">
          <Search className="h-4 w-4 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Cerca n°, descrizione, campagna…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 h-9"
          />
        </div>
        <Tabs value={status} onValueChange={(v) => setStatus(v as StatusFilter)}>
          <TabsList className="grid grid-cols-4 h-8 w-full">
            <TabsTrigger value="all" className="text-[11px] px-1">Tutte ({counts.all})</TabsTrigger>
            <TabsTrigger value="active" className="text-[11px] px-1">In corso ({counts.active})</TabsTrigger>
            <TabsTrigger value="future" className="text-[11px] px-1">Future ({counts.future})</TabsTrigger>
            <TabsTrigger value="past" className="text-[11px] px-1">Passate ({counts.past})</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="text-xs text-muted-foreground">
          {loading ? "…" : `${filtered.length} promo`}
        </div>
      </div>



      <div className="flex-1 min-h-0 overflow-y-auto [scrollbar-gutter:stable]">
        {loading ? (
          <div className="p-4 flex items-center gap-2 text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Caricamento…
          </div>
        ) : (
          <div className="divide-y">
            {filtered.map((r) => {
              const active = r.id === selectedId;
              return (
                <button
                  key={r.id}
                  onClick={() => onSelect(r)}
                  className={cn(
                    "w-full text-left px-3 py-2 hover:bg-muted/50 transition-colors",
                    active && "bg-primary/10 hover:bg-primary/15",
                  )}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs text-muted-foreground">#{r.wpprgf ?? "—"}</span>
                    {(() => {
                      const todayYmd = Number(new Date().toISOString().slice(0,10).replace(/-/g,""));
                      const expired = r.wpdvalf != null && Number(r.wpdvalf) > 0 && Number(r.wpdvalf) < todayYmd;
                      const displayStato = expired ? "A" : r.wpstato;
                      if (!displayStato) return null;
                      return (
                        <Badge variant={displayStato === "V" ? "default" : "secondary"} className="text-[10px] h-4" title={expired && r.wpstato !== "A" ? `AS400: ${r.wpstato} · scaduta` : undefined}>
                          {displayStato}
                        </Badge>
                      );
                    })()}
                  </div>
                  <div className="text-sm font-medium truncate">{r.wptpbd?.trim() || "(senza descrizione)"}</div>
                  <div className="text-[11px] text-muted-foreground flex items-center gap-2">
                    {r.wpcca && <span className="font-mono">{r.wpcca.trim()}</span>}
                    <span>
                      {formatYyyymmddDisplay(r.wpdvali)} → {formatYyyymmddDisplay(r.wpdvalf)}
                    </span>
                  </div>
                </button>
              );
            })}
            {filtered.length === 0 && (
              <div className="p-4 text-sm text-muted-foreground text-center">Nessuna promo</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

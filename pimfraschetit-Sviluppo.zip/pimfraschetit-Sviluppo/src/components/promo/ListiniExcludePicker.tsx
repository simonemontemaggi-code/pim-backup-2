import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useListiniBase, padCdlst } from "@/lib/promoListini";

interface Props {
  value: string[];
  onChange: (next: string[]) => void;
  className?: string;
}

/**
 * Multi-select a chip dei listini base. Cliccare un chip lo aggiunge/toglie
 * dalla lista dei listini esclusi.
 */
export function ListiniExcludePicker({ value, onChange, className }: Props) {
  const { data: listini, isLoading } = useListiniBase();
  const excluded = new Set((value ?? []).map(padCdlst));

  const toggle = (cdlst: string) => {
    const k = padCdlst(cdlst);
    const next = new Set(excluded);
    if (next.has(k)) next.delete(k);
    else next.add(k);
    onChange([...next].sort());
  };

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Loader2 className="h-3 w-3 animate-spin" /> Caricamento listini…
      </div>
    );
  }

  return (
    <div className={cn("space-y-1.5", className)}>
      <div className="text-[11px] uppercase tracking-wide text-muted-foreground">
        Listini esclusi ({excluded.size}/{listini?.length ?? 0})
      </div>
      <div className="flex flex-wrap gap-1.5">
        {(listini ?? []).map((l) => {
          const isExcluded = excluded.has(l.cdlst);
          return (
            <button
              key={l.cdlst}
              type="button"
              onClick={() => toggle(l.cdlst)}
              className={cn(
                "px-2 py-1 rounded-md border text-xs font-medium transition-colors",
                "min-w-0 max-w-[180px] truncate",
                isExcluded
                  ? "bg-destructive/10 border-destructive/40 text-destructive line-through"
                  : "bg-background hover:bg-muted border-border",
              )}
              title={isExcluded ? "Click per includere" : "Click per escludere"}
            >
              <span className="font-mono">{l.cdlst}</span>
              <span className="text-muted-foreground"> · </span>
              <span>{l.dslst}</span>
            </button>
          );
        })}
      </div>
      <div className="text-[11px] text-muted-foreground">
        Click su un listino per escluderlo/includerlo. La promo sarà generata sui listini <b>non</b> esclusi.
      </div>
    </div>
  );
}

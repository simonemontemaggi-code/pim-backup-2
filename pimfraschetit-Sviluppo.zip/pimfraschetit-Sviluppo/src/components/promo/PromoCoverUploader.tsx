import { useRef } from "react";
import { Image as ImageIcon, Upload, Trash2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { usePromoMediaUpload } from "@/hooks/usePromoMediaUpload";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useConfirm } from "@/components/ui/confirm-dialog";

interface Props {
  wpprgf: number | null;
  value: string | null;
  onChange: (url: string | null) => void;
  canEdit?: boolean;
}

/** Cover image della promo (PIM-only, mai esportata in AS400). */
export function PromoCoverUploader({ wpprgf, value, onChange, canEdit = true }: Props) {
  const confirm = useConfirm();
  const inputRef = useRef<HTMLInputElement>(null);
  const { upload, remove, uploading } = usePromoMediaUpload();

  const persist = async (url: string | null) => {
    if (!wpprgf) {
      onChange(url);
      return;
    }
    const { error } = await supabase
      .from("promo_strutturate_testate")
      .update({ cover_image_url: url })
      .eq("wpprgf", wpprgf);
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      return;
    }
    onChange(url);
  };

  const onPick = async (f: File | null) => {
    if (!f || !wpprgf) return;
    const url = await upload(f, `promos/${wpprgf}/cover`);
    if (url) {
      await persist(url);
      toast({ title: "Cover aggiornata" });
    }
  };

  const onClear = async () => {
    if (!(await confirm({ title: "Rimuovere l'immagine della promo?", destructive: true, confirmText: "Rimuovi" }))) return;
    await remove(value);
    await persist(null);
  };

  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-3 text-sm font-medium">
        <ImageIcon className="h-4 w-4 text-muted-foreground" />
        Immagine promo (B2B)
        <span className="text-xs text-muted-foreground font-normal ml-auto">
          PIM-only — non inviata ad AS400
        </span>
      </div>
      <div className="flex items-start gap-4">
        <div className="w-40 h-28 rounded-md border bg-muted/30 overflow-hidden flex items-center justify-center shrink-0">
          {value ? (
            <img src={value} alt="cover promo" className="w-full h-full object-cover" />
          ) : (
            <ImageIcon className="h-8 w-8 text-muted-foreground/50" />
          )}
        </div>
        <div className="flex flex-col gap-2">
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => onPick(e.target.files?.[0] ?? null)}
          />
          <Button
            size="sm"
            variant="outline"
            disabled={uploading || !wpprgf || !canEdit}
            onClick={() => inputRef.current?.click()}
          >
            {uploading ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Upload className="h-4 w-4 mr-1" />}
            {value ? "Sostituisci" : "Carica immagine"}
          </Button>
          {value && canEdit && (
            <Button size="sm" variant="ghost" className="text-destructive" onClick={onClear}>
              <Trash2 className="h-4 w-4 mr-1" /> Rimuovi
            </Button>
          )}
          {!wpprgf && (
            <p className="text-xs text-muted-foreground">Salva la testata prima di caricare.</p>
          )}
          {wpprgf && !canEdit && (
            <p className="text-xs text-muted-foreground">Non hai permessi per modificare questa immagine.</p>
          )}
        </div>
      </div>
    </Card>
  );
}

import { Loader2, Plus, Minus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { ReconcilePreviewItem } from "@/lib/promoListini";

interface Props {
  open: boolean;
  loading?: boolean;
  preview: {
    items: ReconcilePreviewItem[];
    totalAdd: number;
    totalRemove: number;
    affectedElements: number;
  } | null;
  onCancel: () => void;
  onConfirm: () => void;
}

export function ReconcileListiniDialog({ open, loading, preview, onCancel, onConfirm }: Props) {
  const hasChanges = !!preview && (preview.totalAdd > 0 || preview.totalRemove > 0);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onCancel()}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Aggiornare le campagne dei listini?</DialogTitle>
          <DialogDescription>
            Hai modificato la copertura listini della promo. Vediamo l'impatto sugli elementi esistenti.
          </DialogDescription>
        </DialogHeader>

        {!preview ? (
          <div className="py-8 flex items-center justify-center text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin mr-2" /> Calcolo impatto…
          </div>
        ) : !hasChanges ? (
          <div className="py-6 text-sm text-muted-foreground text-center">
            Nessun cambiamento da applicare alle campagne esistenti.
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex gap-3 text-sm">
              <div className="flex-1 rounded border border-emerald-500/30 bg-emerald-500/10 px-3 py-2">
                <div className="flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400 font-medium">
                  <Plus className="h-3.5 w-3.5" /> {preview.totalAdd} righe da aggiungere
                </div>
              </div>
              <div className="flex-1 rounded border border-destructive/30 bg-destructive/10 px-3 py-2">
                <div className="flex items-center gap-1.5 text-destructive font-medium">
                  <Minus className="h-3.5 w-3.5" /> {preview.totalRemove} righe da rimuovere
                </div>
              </div>
            </div>

            <div className="text-xs text-muted-foreground">
              Su {preview.affectedElements} element{preview.affectedElements === 1 ? "o" : "i"} interessat{preview.affectedElements === 1 ? "o" : "i"}.
            </div>

            <ScrollArea className="h-56 rounded border">
              <div className="divide-y text-xs">
                {preview.items.map((item) => (
                  <div key={item.wpprge} className="px-3 py-2">
                    <div className="font-mono font-medium mb-1">Elemento #{item.wpprge}</div>
                    {item.toAdd.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-1">
                        <span className="text-emerald-700 dark:text-emerald-400">+</span>
                        {item.toAdd.map((c) => (
                          <span key={c} className="font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30">
                            {c}
                          </span>
                        ))}
                      </div>
                    )}
                    {item.toRemove.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        <span className="text-destructive">−</span>
                        {item.toRemove.map((c) => (
                          <span key={c} className="font-mono px-1.5 py-0.5 rounded bg-destructive/10 border border-destructive/30 line-through">
                            {c}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </ScrollArea>

            <div className="text-[11px] text-muted-foreground">
              Verrà generato un export AS400 aggregato per la promo.
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onCancel} disabled={loading}>
            Annulla
          </Button>
          <Button onClick={onConfirm} disabled={loading || !hasChanges}>
            {loading ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : null}
            Applica modifiche
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

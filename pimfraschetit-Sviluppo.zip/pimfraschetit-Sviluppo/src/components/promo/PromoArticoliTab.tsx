import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, Save, Loader2, Search, Download, CalendarIcon, X, ArrowUp, ArrowDown, ArrowUpDown, Clipboard } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "@/hooks/use-toast";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { it } from "date-fns/locale";
import { yyyymmddToDate, dateToYyyymmdd } from "@/lib/as400DateUtils";
import { exportAs400Change } from "@/lib/as400Export";
import { pad6Cdpar } from "@/lib/csvTemplates";
import type { TestataRow } from "./PromoTestateList";

interface Props {
  testata: TestataRow;
}

interface ArtRow {
  id: string;
  wpprgf: number;
  wpprge: number | null;
  cdpar: string;
  wsconto1: number | null;   // = wscon (Sconto)
  wqtmax: number | null;     // = wqtxm (Qtà max)
  wqtmin: number | null;     // = wqtxn (Qtà min)
  wdtvi: string | null;      // Data validità inizio (yyyymmdd)
  wdtvf: string | null;      // Data validità fine (yyyymmdd)
  source: string | null;
  source_ref: string | null;
}

export function PromoArticoliTab({ testata }: Props) {
  const qc = useQueryClient();
  const wpprgf = testata.wpprgf;
  
  const [importing, setImporting] = useState(false);

  // Default ereditati dalla testata (Generale): Sell-out inizio/fine.
  const yyyymmddOrNull = (v: any): string | null => {
    if (v == null || v === "") return null;
    const s = String(v).trim();
    return /^\d{8}$/.test(s) ? s : null;
  };
  const defaultWdtvi = yyyymmddOrNull((testata as any).wpindoi);
  const defaultWdtvf = yyyymmddOrNull((testata as any).wpindof);

  const { data: rows, isLoading, refetch } = useQuery({
    queryKey: ["promo_articoli", wpprgf],
    enabled: !!wpprgf,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("promo_strutturate_articoli" as any)
        .select("*")
        .eq("wpprgf", wpprgf!)
        .order("cdpar", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as ArtRow[];
    },
  });

  // Mappa cdpar -> nome tema (per la colonna "Tema").
  const { data: temaMap } = useQuery({
    queryKey: ["promo_articoli_temi_map", wpprgf],
    enabled: !!wpprgf,
    queryFn: async () => {
      const { data: temi } = await supabase
        .from("promo_strutturate_temi")
        .select("id, nome")
        .eq("wpprgf", wpprgf!);
      const ids = (temi ?? []).map((t) => t.id);
      if (ids.length === 0) return {} as Record<string, string>;
      const { data: links } = await supabase
        .from("promo_strutturate_tema_articoli")
        .select("tema_id, cdpar")
        .in("tema_id", ids);
      const nameById = new Map((temi ?? []).map((t) => [t.id, t.nome]));
      const map: Record<string, string> = {};
      for (const l of links ?? []) {
        const n = nameById.get(l.tema_id);
        if (!n) continue;
        const k = pad6Cdpar(l.cdpar);
        // se l'articolo è in più temi, mostra il primo trovato
        if (!map[k]) map[k] = n;
      }
      return map;
    },
  });

  const tipoBlocco = (testata as any).wpcca ? String((testata as any).wpcca).trim() : "";

  const handleImportFromDettagli = async (silent = false) => {
    if (!wpprgf) return;
    if (!tipoBlocco) {
      if (!silent) {
        toast({
          title: "Tipo blocco mancante",
          description: "Imposta il campo 'Codice campagna' (wpcca) sulla testata: identifica il tipo blocco (es. GIARVE26).",
          variant: "destructive",
        });
      }
      return;
    }
    setImporting(true);
    try {
      // === VLOOKUP ===
      // 1) Una sola scansione di listini_vendita_campagne (paginata) filtrata per wtpbl.
      //    Costruiamo una mappa cdpar (trim) → miglior riga (sconto/qty/date).
      const PAGE = 1000;
      type CampRow = { wscon: number | null; wqtxm: number | null; wqtxn: number | null; wdtvi: string | null; wdtvf: string | null };
      const byCode = new Map<string, CampRow>();
      const score = (x: CampRow) => (x.wscon ? 4 : 0) + (x.wdtvi ? 2 : 0) + (x.wdtvf ? 1 : 0);

      let from = 0;
      for (let i = 0; i < 200; i++) {
        const { data, error } = await supabase
          .from("listini_vendita_campagne")
          .select("wcdpa, wscon, wqtxm, wqtxn, wdtvi, wdtvf")
          .eq("wtpbl", tipoBlocco)
          .not("wcdpa", "is", null)
          .range(from, from + PAGE - 1);
        if (error) throw error;
        const page = data ?? [];
        for (const r of page as any[]) {
          const code = r.wcdpa ? pad6Cdpar(String(r.wcdpa)) : "";
          if (!code) continue;
          const cand: CampRow = {
            wscon: r.wscon ?? null,
            wqtxm: r.wqtxm ?? null,
            wqtxn: r.wqtxn ?? null,
            wdtvi: r.wdtvi ?? null,
            wdtvf: r.wdtvf ?? null,
          };
          const prev = byCode.get(code);
          if (!prev || score(cand) > score(prev)) byCode.set(code, cand);
        }
        if (page.length < PAGE) break;
        from += PAGE;
      }

      if (byCode.size === 0) {
        if (!silent) toast({ title: "Nessun articolo", description: `Nessuna campagna con tipo blocco ${tipoBlocco}.` });
        return;
      }

      // 2) Insert per i codici nuovi (non ancora in promo_strutturate_articoli).
      const existingMap = new Map((rows ?? []).map((r) => [pad6Cdpar(r.cdpar), r]));
      const toInsert: any[] = [];
      const toUpdate: { id: string; patch: Record<string, any> }[] = [];

      for (const [cdpar, c] of byCode.entries()) {
        const existing = existingMap.get(cdpar);
        if (!existing) {
          toInsert.push({
            wpprgf,
            cdpar,
            wsconto1: c.wscon,
            wqtmax: c.wqtxm,
            wqtmin: c.wqtxn,
            wdtvi: c.wdtvi,
            wdtvf: c.wdtvf,
            source: "imported_from_dettagli",
            source_ref: `tpbl=${tipoBlocco}`,
          });
        } else {
          // VLOOKUP: sovrascrivi sempre i valori "vuoti" con quelli da campagne
          const patch: Record<string, any> = {};
          if (existing.wsconto1 == null && c.wscon != null) patch.wsconto1 = c.wscon;
          if (existing.wqtmax == null && c.wqtxm != null) patch.wqtmax = c.wqtxm;
          if (existing.wqtmin == null && c.wqtxn != null) patch.wqtmin = c.wqtxn;
          if (!existing.wdtvi && c.wdtvi) patch.wdtvi = c.wdtvi;
          if (!existing.wdtvf && c.wdtvf) patch.wdtvf = c.wdtvf;
          if (Object.keys(patch).length > 0) toUpdate.push({ id: existing.id, patch });
        }
      }

      // 3) Esegui update in parallelo (batch di 25 query concorrenti).
      let updated = 0;
      const CONC = 25;
      for (let i = 0; i < toUpdate.length; i += CONC) {
        const slice = toUpdate.slice(i, i + CONC);
        const results = await Promise.all(
          slice.map((u) =>
            supabase.from("promo_strutturate_articoli" as any).update(u.patch).eq("id", u.id),
          ),
        );
        updated += results.filter((r) => !r.error).length;
      }

      // 4) Insert in batch da 500.
      let inserted = 0;
      const BATCH = 500;
      for (let i = 0; i < toInsert.length; i += BATCH) {
        const slice = toInsert.slice(i, i + BATCH);
        const { error: insErr } = await supabase
          .from("promo_strutturate_articoli" as any)
          .insert(slice as any);
        if (insErr) throw insErr;
        inserted += slice.length;
      }

      // Invalida sempre la cache: anche se inserted/updated = 0, righe pre-esistenti
      // potrebbero essere state aggiornate da una sessione precedente.
      await qc.invalidateQueries({ queryKey: ["promo_articoli", wpprgf] });
      await refetch();

      if (inserted === 0 && updated === 0) {
        if (!silent) {
          toast({
            title: "Nessuna modifica",
            description: `Tipo blocco ${tipoBlocco}: ${byCode.size} match, tutti già aggiornati.`,
          });
        }
        return;
      }

      toast({
        title: "Articoli sincronizzati",
        description: `${inserted} nuovi, ${updated} aggiornati (tipo blocco ${tipoBlocco}).`,
      });
    } catch (e: any) {
      if (!silent) toast({ title: "Errore import", description: e.message, variant: "destructive" });
      else console.warn("auto-import promo articoli fallito:", e);
    } finally {
      setImporting(false);
    }
  };

  // Auto-import al primo accesso: se la promo ha un tipo blocco ma nessun articolo, carica.
  const autoTriedRef = useRef<string | null>(null);
  useEffect(() => {
    if (isLoading || !wpprgf || !tipoBlocco) return;
    const key = `${wpprgf}:${tipoBlocco}`;
    if (autoTriedRef.current === key) return;
    autoTriedRef.current = key;
    const list = rows ?? [];
    const needsBackfill = list.some(
      (r) => r.wsconto1 == null && r.wqtmax == null && r.wqtmin == null && !r.wdtvi && !r.wdtvf,
    );
    if (list.length === 0 || needsBackfill) {
      handleImportFromDettagli(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLoading, wpprgf, tipoBlocco, rows?.length]);

  type SortKey = "cdpar" | "source" | "wsconto1" | "wqtmax" | "wqtmin" | "wdtvi" | "wdtvf" | "tema";
  const [sortKey, setSortKey] = useState<SortKey>("cdpar");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");


  const toggleSort = (k: SortKey) => {
    if (sortKey === k) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(k); setSortDir("asc"); }
  };

  const sortedRows = useMemo(() => {
    const list = [...(rows ?? [])];
    const dir = sortDir === "asc" ? 1 : -1;
    const val = (r: ArtRow): any => {
      switch (sortKey) {
        case "cdpar": return pad6Cdpar(r.cdpar);
        case "source": return (r.source ?? "") === "manual" ? "PIM" : "AS400";
        case "tema": return temaMap?.[pad6Cdpar(r.cdpar)] ?? "";
        default: return (r as any)[sortKey];
      }
    };
    list.sort((a, b) => {
      const va = val(a), vb = val(b);
      if (va == null && vb == null) return 0;
      if (va == null) return 1;
      if (vb == null) return -1;
      if (typeof va === "number" && typeof vb === "number") return (va - vb) * dir;
      return String(va).localeCompare(String(vb)) * dir;
    });
    return list;
  }, [rows, sortKey, sortDir, temaMap]);

  const copyToClipboard = async () => {
    const header = ["Articolo", "Origine", "Sconto", "Q.tà max", "Q.tà min", "Dal", "Al", "Offerta"];
    const fmtDate = (s: string | null) => {
      if (!s) return "";
      const d = yyyymmddToDate(s);
      return d ? format(d, "dd/MM/yyyy") : s;
    };
    const lines = [header.join("\t")];
    for (const r of sortedRows) {
      lines.push([
        pad6Cdpar(r.cdpar),
        (r.source ?? "") === "manual" ? "PIM" : "AS400",
        r.wsconto1 ?? "",
        r.wqtmax ?? "",
        r.wqtmin ?? "",
        fmtDate(r.wdtvi ?? defaultWdtvi),
        fmtDate(r.wdtvf ?? defaultWdtvf),
        temaMap?.[pad6Cdpar(r.cdpar)] ?? "",
      ].join("\t"));
    }
    try {
      await navigator.clipboard.writeText(lines.join("\n"));
      toast({ title: "Copiato", description: `${sortedRows.length} righe negli appunti (incolla su Excel).` });
    } catch (e: any) {
      toast({ title: "Errore copia", description: e.message, variant: "destructive" });
    }
  };

  const SortBtn = ({ k, label, align = "center" }: { k: SortKey; label: string; align?: "left" | "center" }) => (
    <button
      onClick={() => toggleSort(k)}
      className={cn("inline-flex items-center gap-1 hover:text-foreground", align === "left" ? "" : "mx-auto")}
    >
      {label}
      {sortKey === k ? (
        sortDir === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />
      ) : (
        <ArrowUpDown className="h-3 w-3 opacity-40" />
      )}
    </button>
  );

  if (!wpprgf) {
    return <div className="text-sm text-muted-foreground p-4">Salva prima la testata per gestire gli articoli.</div>;
  }


  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="text-sm text-muted-foreground">
          {isLoading ? "Caricamento…" : `${rows?.length ?? 0} articoli associati`}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={copyToClipboard} disabled={isLoading || (rows ?? []).length === 0}>
            <Clipboard className="h-3.5 w-3.5 mr-1.5" /> Copia per Excel
          </Button>
          <div className="text-xs text-muted-foreground italic">
            Articoli AS400 (auto-importati) e PIM-native{tipoBlocco ? ` · tipo blocco ${tipoBlocco}` : ""}
          </div>
        </div>
      </div>

      {isLoading ? (
        <Card className="p-6 flex items-center gap-2 text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Caricamento…
        </Card>
      ) : (rows ?? []).length === 0 ? (
        <Card className="p-6 text-sm text-muted-foreground text-center">
          Nessun articolo. Gli articoli AS400 vengono importati automaticamente; quelli PIM-native si creano dalla sezione Offerte.
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-xs uppercase">
                <tr>
                  <th className="text-left px-3 py-2"><SortBtn k="cdpar" label="Articolo" align="left" /></th>
                  <th className="text-center px-3 py-2"><SortBtn k="source" label="Origine" /></th>
                  <th className="text-center px-3 py-2"><SortBtn k="wsconto1" label="Sconto" /></th>
                  <th className="text-center px-3 py-2"><SortBtn k="wqtmax" label="Q.tà max" /></th>
                  <th className="text-center px-3 py-2"><SortBtn k="wqtmin" label="Q.tà min" /></th>
                  <th className="text-center px-3 py-2"><SortBtn k="wdtvi" label="Dal" /></th>
                  <th className="text-center px-3 py-2"><SortBtn k="wdtvf" label="Al" /></th>
                  <th className="text-center px-3 py-2"><SortBtn k="tema" label="Offerta" /></th>
                  <th className="px-3 py-2"></th>
                </tr>
              </thead>
              <tbody>
                {sortedRows.map((r) => (
                  <ArticoloRow
                    key={r.id}
                    row={r}
                    tema={temaMap?.[pad6Cdpar(r.cdpar)] ?? null}
                    onChanged={refetch}
                    defaultWdtvi={defaultWdtvi}
                    defaultWdtvf={defaultWdtvf}
                  />
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}

function ArticoloRow({ row, tema, onChanged, defaultWdtvi, defaultWdtvf }: { row: ArtRow; tema: string | null; onChanged: () => void; defaultWdtvi: string | null; defaultWdtvf: string | null }) {
  const confirm = useConfirm();
  const { user, profile } = useAuth();
  const [v, setV] = useState<ArtRow>(row);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => setV(row), [row.id]);

  const dirty = useMemo(() => JSON.stringify(v) !== JSON.stringify(row), [v, row]);

  const save = async () => {
    setSaving(true);
    try {
      const changed: Record<string, any> = {};
      const fields: (keyof ArtRow)[] = ["wsconto1","wqtmax","wqtmin","wdtvi","wdtvf"];
      for (const f of fields) {
        if ((v as any)[f] !== (row as any)[f]) changed[f as string] = (v as any)[f];
      }
      if (Object.keys(changed).length === 0) return;
      const { error } = await supabase
        .from("promo_strutturate_articoli" as any)
        .update(changed)
        .eq("id", row.id);
      if (error) throw error;

      await supabase.from("audit_log" as any).insert({
        table_name: "promo_strutturate_articoli",
        record_id: `${row.wpprgf}/${pad6Cdpar(row.cdpar)}`,
        operation: "update",
        old_values: Object.fromEntries(Object.keys(changed).map((k) => [k, (row as any)[k]])),
        new_values: changed,
        changed_fields: Object.keys(changed),
        user_id: user?.id,
        user_email: profile?.email,
      });
      exportAs400Change({
        user: profile?.email ?? user?.email,
        record: `${row.wpprgf}/${pad6Cdpar(row.cdpar)}`,
        table: "promo_strutturate_articoli",
        change: { operation: "update", key: { id: row.id, wpprgf: row.wpprgf, cdpar: row.cdpar }, fields: changed },
        filenamePrefix: "as400_promo_articolo",
      });
      toast({ title: "Salvato", description: "JSON AS400 scaricato." });
      onChanged();
    } catch (e: any) {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const del = async () => {
    if (!(await confirm({ title: `Eliminare l'articolo ${pad6Cdpar(row.cdpar)} dalla promo?`, destructive: true, confirmText: "Elimina" }))) return;
    setDeleting(true);
    try {
      const { error } = await supabase
        .from("promo_strutturate_articoli" as any)
        .delete()
        .eq("id", row.id);
      if (error) throw error;
      await supabase.from("audit_log" as any).insert({
        table_name: "promo_strutturate_articoli",
        record_id: `${row.wpprgf}/${pad6Cdpar(row.cdpar)}`,
        operation: "delete",
        old_values: row as any,
        user_id: user?.id,
        user_email: profile?.email,
      });
      exportAs400Change({
        user: profile?.email ?? user?.email,
        record: `${row.wpprgf}/${pad6Cdpar(row.cdpar)}`,
        table: "promo_strutturate_articoli",
        change: { operation: "delete", key: { id: row.id, wpprgf: row.wpprgf, cdpar: row.cdpar } },
        filenamePrefix: "as400_promo_articolo",
      });
      toast({ title: "Eliminato", description: "JSON AS400 scaricato." });
      onChanged();
    } catch (e: any) {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    } finally {
      setDeleting(false);
    }
  };

  const num = (val: number | null) => (val == null ? "" : String(val));
  const setNum = (k: keyof ArtRow) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const n = e.target.value === "" ? null : Number(e.target.value);
    setV((s) => ({ ...s, [k]: n as any }));
  };
  const setStr = (k: keyof ArtRow) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setV((s) => ({ ...s, [k]: (e.target.value || null) as any }));
  };

  const isManual = (row.source ?? "") === "manual";

  return (
    <tr className="border-t hover:bg-muted/30">
      <td className="px-3 py-1.5 font-mono text-xs">{pad6Cdpar(row.cdpar)}</td>
      <td className="px-2 py-1 text-center">
        {isManual ? (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-primary/10 text-primary text-[10px] font-semibold uppercase tracking-wide">PIM</span>
        ) : (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-muted text-muted-foreground text-[10px] font-semibold uppercase tracking-wide border">AS400</span>
        )}
      </td>
      <td className="px-2 py-1 text-center"><Input value={num(v.wsconto1)} onChange={setNum("wsconto1")} type="number" step="0.01" className="h-7 text-center w-20 mx-auto" /></td>
      <td className="px-2 py-1 text-center"><Input value={num(v.wqtmax)} onChange={setNum("wqtmax")} type="number" step="1" className="h-7 text-center w-20 mx-auto" /></td>
      <td className="px-2 py-1 text-center"><Input value={num(v.wqtmin)} onChange={setNum("wqtmin")} type="number" step="1" className="h-7 text-center w-20 mx-auto" /></td>
      <td className="px-2 py-1 text-center">
        <DateCell
          value={v.wdtvi}
          fallback={defaultWdtvi}
          onChange={(s) => setV((p) => ({ ...p, wdtvi: s }))}
        />
      </td>
      <td className="px-2 py-1 text-center">
        <DateCell
          value={v.wdtvf}
          fallback={defaultWdtvf}
          onChange={(s) => setV((p) => ({ ...p, wdtvf: s }))}
        />
      </td>
      <td className="px-3 py-1.5 text-xs text-center">
        {tema ? (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-primary/10 text-primary text-[11px] font-medium">
            {tema}
          </span>
        ) : (
          <span className="text-muted-foreground">—</span>
        )}
      </td>
      <td className="px-2 py-1 text-right whitespace-nowrap">
        <Button size="sm" variant="ghost" onClick={save} disabled={!dirty || saving} className="h-7 px-2">
          {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
        </Button>
        <Button size="sm" variant="ghost" onClick={del} disabled={deleting} className="h-7 px-2 text-destructive">
          {deleting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
        </Button>
      </td>
    </tr>
  );
}

function AddArticoloDialog({
  open,
  onOpenChange,
  wpprgf,
  existingCdpar,
  onAdded,
}: {
  open: boolean;
  onOpenChange: (b: boolean) => void;
  wpprgf: number;
  existingCdpar: Set<string>;
  onAdded: () => void;
}) {
  const { user, profile } = useAuth();
  const [q, setQ] = useState("");
  const [results, setResults] = useState<{ cdpar: string; depar: string | null }[]>([]);
  const [searching, setSearching] = useState(false);
  const [adding, setAdding] = useState<string | null>(null);

  useEffect(() => {
    if (!open) {
      setQ("");
      setResults([]);
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const term = q.trim();
    if (term.length < 2) { setResults([]); return; }
    let alive = true;
    setSearching(true);
    const t = setTimeout(async () => {
      const { data } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar, depar")
        .or(`cdpar.ilike.%${term}%,depar.ilike.%${term}%`)
        .limit(30);
      if (alive) {
        setResults((data ?? []) as any);
        setSearching(false);
      }
    }, 250);
    return () => { alive = false; clearTimeout(t); };
  }, [q, open]);

  const add = async (cdparRaw: string) => {
    const cdpar = pad6Cdpar(cdparRaw);
    setAdding(cdpar);
    try {
      const { error } = await supabase
        .from("promo_strutturate_articoli" as any)
        .insert({ wpprgf, cdpar, source: "manual", wstate: "V" } as any);
      if (error) throw error;
      await supabase.from("audit_log" as any).insert({
        table_name: "promo_strutturate_articoli",
        record_id: `${wpprgf}/${cdpar}`,
        operation: "insert",
        new_values: { wpprgf, cdpar, source: "manual", wstate: "V" },
        user_id: user?.id,
        user_email: profile?.email,
      });
      exportAs400Change({
        user: profile?.email ?? user?.email,
        record: `${wpprgf}/${cdpar}`,
        table: "promo_strutturate_articoli",
        change: { operation: "insert", key: { wpprgf, cdpar }, fields: { wpprgf, cdpar, source: "manual", wstate: "V" } },
        filenamePrefix: "as400_promo_articolo",
      });
      toast({ title: "Articolo aggiunto", description: cdpar });
      onAdded();
    } catch (e: any) {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    } finally {
      setAdding(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Aggiungi articolo alla promo</DialogTitle>
        </DialogHeader>
        <div className="relative">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            autoFocus
            placeholder="Cerca per codice o descrizione (min 2 caratteri)…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="pl-9"
          />
        </div>
        <ScrollArea className="h-80 border rounded-md">
          {searching && <div className="p-3 text-sm text-muted-foreground flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Ricerca…</div>}
          {!searching && results.length === 0 && q.trim().length >= 2 && (
            <div className="p-3 text-sm text-muted-foreground">Nessun risultato.</div>
          )}
          {!searching && results.length === 0 && q.trim().length < 2 && (
            <div className="p-3 text-sm text-muted-foreground">Digita almeno 2 caratteri.</div>
          )}
          <ul className="divide-y">
            {results.map((r) => {
              const code = pad6Cdpar(r.cdpar);
              const exists = existingCdpar.has(code);
              return (
                <li key={r.cdpar} className="px-3 py-2 flex items-center gap-3 hover:bg-muted/40">
                  <span className="font-mono text-xs w-32">{code}</span>
                  <span className="flex-1 text-sm truncate">{r.depar?.trim() || "—"}</span>
                  <Button
                    size="sm"
                    variant={exists ? "ghost" : "default"}
                    disabled={exists || adding === code}
                    onClick={() => add(r.cdpar)}
                  >
                    {adding === code ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : exists ? "Già presente" : (<><Plus className="h-3.5 w-3.5 mr-1" /> Aggiungi</>)}
                  </Button>
                </li>
              );
            })}
          </ul>
        </ScrollArea>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Chiudi</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function DateCell({
  value,
  onChange,
  fallback,
}: {
  value: string | null;
  onChange: (yyyymmdd: string | null) => void;
  fallback?: string | null;
}) {
  const ownDate = yyyymmddToDate(value) ?? undefined;
  const fallbackDate = yyyymmddToDate(fallback ?? null) ?? undefined;
  const selected = ownDate ?? fallbackDate;
  const isInherited = !ownDate && !!fallbackDate;
  const currentYear = new Date().getFullYear();
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className={cn(
            "h-7 w-32 justify-start text-left font-normal text-xs px-2",
            !selected && "text-muted-foreground",
            isInherited && "italic text-muted-foreground",
          )}
          title={isInherited ? "Ereditato dalla testata" : undefined}
        >
          <CalendarIcon className="h-3 w-3 mr-1 shrink-0" />
          {selected ? format(selected, "dd/MM/yyyy", { locale: it }) : "—"}
          {ownDate && (
            <span
              role="button"
              tabIndex={0}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onChange(null);
              }}
              className="ml-auto opacity-60 hover:opacity-100"
              aria-label="Cancella data"
            >
              <X className="h-3 w-3" />
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar
          mode="single"
          selected={selected}
          onSelect={(d) => {
            const n = dateToYyyymmdd(d ?? null);
            onChange(n != null ? String(n) : null);
          }}
          defaultMonth={selected ?? new Date()}
          locale={it}
          initialFocus
          className={cn("p-3 pointer-events-auto")}
        />
        <div className="flex items-center justify-between border-t px-3 py-2 text-xs">
          <button
            type="button"
            className="text-primary hover:underline"
            onClick={() => onChange(null)}
          >
            Cancella
          </button>
          <button
            type="button"
            className="text-primary hover:underline"
            onClick={() => {
              const n = dateToYyyymmdd(new Date());
              onChange(n != null ? String(n) : null);
            }}
          >
            Oggi
          </button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

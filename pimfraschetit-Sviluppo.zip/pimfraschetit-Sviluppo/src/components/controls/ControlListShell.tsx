import { ReactNode } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Props {
  title: string;
  icon: LucideIcon;
  description?: ReactNode;
  children: ReactNode;
  totalLabel?: string;
  total?: number;
}

export function ControlListShell({ title, icon: Icon, description, children, totalLabel, total }: Props) {
  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center gap-2">
        <Button asChild variant="ghost" size="icon" className="h-8 w-8">
          <Link to="/pim/controls">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-2xl font-semibold flex items-center gap-2">
          <Icon className="h-6 w-6 text-primary" />
          {title}
        </h1>
        {total != null && (
          <span className="ml-2 text-sm text-muted-foreground">
            {totalLabel ?? "Totale"}: <strong className="text-foreground">{total.toLocaleString("it-IT")}</strong>
          </span>
        )}
      </div>
      {description && <p className="text-sm text-muted-foreground">{description}</p>}
      {children}
    </div>
  );
}

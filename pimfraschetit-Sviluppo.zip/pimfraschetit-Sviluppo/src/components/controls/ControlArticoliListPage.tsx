import { useMemo, useState } from "react";
import { downloadXlsxAoa } from "@/lib/xlsxExport";
import { Link } from "react-router-dom";
import { ExternalLink, LucideIcon, Search, Download } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useVisibleAssortments } from "@/hooks/useVisibleAssortments";
import { useOnlineAssortments, computeIsB2bOnline } from "@/hooks/useOnlineAssortments";
import { useControlsFilter } from "@/hooks/useControlsFilter";
import { getMediaCdparCandidates, normalizeMediaCdpar } from "@/lib/mediaUtils";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ControlListShell } from "@/components/controls/ControlListShell";

interface Row {
  cdpar: string;
  depar: string | null;
  pcfor: string | null;
  clmer: string | null;
  lipro?: string | null;
  wfuas: string | null;
  total_count: number;
  [k: string]: any;
}

interface Props {
  title: string;
  icon: LucideIcon;
  description?: React.ReactNode;
  rpcName: string;
  extraArgs?: Record<string, any>;
  searchParam?: string;
  /** colonne extra dopo le standard */
  extraColumns?: { header: string; cell: (r: Row) => React.ReactNode; className?: string }[];
  /** se true, pre-attiva il filtro "Solo online B2B" */
  defaultOnlyB2bOnline?: boolean;
}


const PAGE = 100;
const EXPORT_CHUNK = 1000;
const CANDIDATE_CHUNK = 200;

const chunkArray = <T,>(items: T[], size: number): T[][] => {
  const chunks: T[][] = [];
  for (let i = 0; i < items.length; i += size) chunks.push(items.slice(i, i + size));
  return chunks;
};

export function ControlArticoliListPage({
  title,
  icon,
  description,
  rpcName,
  extraArgs = {},
  searchParam,
  extraColumns = [],
  defaultOnlyB2bOnline = false,
}: Props) {
  const { data: assortments } = useVisibleAssortments();
  const { data: onlineAssortments = [] } = useOnlineAssortments();
  const { selected: chipFilters } = useControlsFilter();
  const effective = (assortments && assortments.length > 0)
    ? assortments.filter((c) => chipFilters.includes(c))
    : chipFilters;
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState("");
  const [onlyB2bOnline, setOnlyB2bOnline] = useState(defaultOnlyB2bOnline);

  const computeFilterList = (): string[] | null => effective.length > 0 ? effective : null;

  const buildRpcArgs = (filterList: string[] | null, lim: number, off: number) => {
    const args: any = {
      visible_assortments: filterList,
      lim,
      off,
      ...extraArgs,
    };
    if (searchParam) args[searchParam] = search.trim() || null;
    return args;
  };

  const fetchRpcRows = async (filterList: string[] | null, lim: number, off: number) => {
    const { data, error } = await supabase.rpc(rpcName as any, buildRpcArgs(filterList, lim, off));
    if (error) throw error;
    return (data ?? []) as Row[];
  };

  const fetchAllRpcRows = async (filterList: string[] | null) => {
    const all: Row[] = [];
    for (let off = 0; ; off += EXPORT_CHUNK) {
      const rows = await fetchRpcRows(filterList, EXPORT_CHUNK, off);
      all.push(...rows);
      if (rows.length < EXPORT_CHUNK) break;
    }
    return all;
  };

  const fetchOnlineCdparsForRows = async (rows: Row[]) => {
    const cdpars = Array.from(new Set(rows.map((row) => normalizeMediaCdpar(row.cdpar)).filter(Boolean)));
    const online = new Set<string>();
    for (const chunk of chunkArray(cdpars, CANDIDATE_CHUNK)) {
      const candidates = Array.from(new Set(chunk.flatMap((cdpar) => getMediaCdparCandidates(cdpar))));
      const { data, error } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar, wfuas, b2b_online_active")
        .in("cdpar", candidates);
      if (error) throw error;
      ((data ?? []) as { cdpar: string; wfuas: string | null; b2b_online_active: boolean | null }[]).forEach((row) => {
        if (computeIsB2bOnline(row.b2b_online_active, row.wfuas, onlineAssortments)) {
          online.add(normalizeMediaCdpar(row.cdpar));
        }
      });
    }
    return online;
  };

  const filterRowsForOnlineB2b = async (rows: Row[]) => {
    const onlineCdpars = await fetchOnlineCdparsForRows(rows);
    let result = rows.filter((row) => onlineCdpars.has(normalizeMediaCdpar(row.cdpar)));
    if (!searchParam) {
      const q = search.trim().toLowerCase();
      if (q) {
        result = result.filter(
          (r) =>
            r.cdpar.toLowerCase().includes(q) ||
            (r.depar ?? "").toLowerCase().includes(q) ||
            (r.pcfor ?? "").toLowerCase().includes(q),
        );
      }
    }
    return result;
  };

  const { data, isLoading, error } = useQuery({
    queryKey: ["controls_detail", rpcName, effective, page, extraArgs, searchParam || onlyB2bOnline ? search.trim() : "", onlyB2bOnline, onlineAssortments],
    queryFn: async () => {
      const filterList = computeFilterList();
      if (!onlyB2bOnline) return fetchRpcRows(filterList, PAGE, page * PAGE);

      const allRows = await fetchAllRpcRows(filterList);
      const onlineRows = await filterRowsForOnlineB2b(allRows);
      const pageRows = onlineRows.slice(page * PAGE, (page + 1) * PAGE);
      return pageRows.map((row) => ({ ...row, total_count: onlineRows.length }));
    },
    staleTime: 60_000,
    placeholderData: (prev) => prev,
  });


  const total = data?.[0]?.total_count ?? 0;
  const pages = Math.max(1, Math.ceil(Number(total) / PAGE));

  const filtered = useMemo(() => {
    if (!data) return [];
    if (searchParam) return data;
    const q = search.trim().toLowerCase();
    if (!q) return data;
    return data.filter(
      (r) =>
        r.cdpar.toLowerCase().includes(q) ||
        (r.depar ?? "").toLowerCase().includes(q) ||
        (r.pcfor ?? "").toLowerCase().includes(q),
    );
  }, [data, search]);

  const [exporting, setExporting] = useState(false);
  const handleExportCSV = async () => {
    if (Number(total) === 0) return;
    setExporting(true);
    try {
      const CHUNK = 1000;
      const all: Row[] = [];
      const totalRows = Number(total);
      const filterList = computeFilterList();
      if (onlyB2bOnline) {
        all.push(...await filterRowsForOnlineB2b(await fetchAllRpcRows(filterList)));
      } else {
        for (let off = 0; off < totalRows; off += CHUNK) {
          const rows = await fetchRpcRows(filterList, CHUNK, off);
          all.push(...rows);
          if (rows.length < CHUNK) break;
        }
      }
      const headers = ["cdpar", "depar", "pcfor", "clmer", "wfuas"];
      const aoa: any[][] = [headers];
      all.forEach((r) => {
        aoa.push([r.cdpar, r.depar ?? "", r.pcfor ?? "", r.clmer ?? "", r.wfuas ?? ""]);
      });
      downloadXlsxAoa(`${rpcName}-completo.xlsx`, aoa, { sheetName: "Articoli" });
    } finally {
      setExporting(false);
    }
  };

  return (
    <ControlListShell title={title} icon={icon} description={description} total={Number(total)}>
      <div className="flex items-center justify-between gap-2">
        <div className="relative max-w-sm flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Filtra nella pagina corrente..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(0);
            }}
            className="pl-8"
          />
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant={onlyB2bOnline ? "default" : "outline"}
            size="sm"
            onClick={() => { setOnlyB2bOnline((v) => !v); setPage(0); }}
          >
            Solo online B2B
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportCSV} disabled={!Number(total) || exporting} className="gap-2">
            <Download className="h-4 w-4" /> {exporting ? "Esporto..." : `Esporta XLSX (${Number(total)})`}
          </Button>
        </div>
      </div>




      {isLoading && <Skeleton className="h-64 w-full" />}
      {error && <div className="text-sm text-destructive">Errore: {(error as Error).message}</div>}

      {!isLoading && (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[140px]">Codice</TableHead>
                  <TableHead>Descrizione</TableHead>
                  <TableHead className="w-[90px]">Forn.</TableHead>
                  <TableHead className="w-[80px]">Categ.</TableHead>
                  <TableHead className="w-[80px]">Assort.</TableHead>
                  {extraColumns.map((c) => (
                    <TableHead key={c.header} className={c.className}>
                      {c.header}
                    </TableHead>
                  ))}
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6 + extraColumns.length} className="text-center text-muted-foreground py-8">
                      {data?.length ? "Nessun risultato per il filtro." : "Nessun articolo da sistemare ✓"}
                    </TableCell>
                  </TableRow>
                )}
                {filtered.map((r) => (
                  <TableRow key={r.cdpar}>
                    <TableCell className="font-mono text-xs">{r.cdpar.trim()}</TableCell>
                    <TableCell className="text-sm">{r.depar ?? "—"}</TableCell>
                    <TableCell className="font-mono text-xs">{r.pcfor ?? "—"}</TableCell>
                    <TableCell className="font-mono text-xs">{r.clmer ?? "—"}</TableCell>
                    <TableCell className="font-mono text-xs">
                      {r.wfuas ? <Badge variant="secondary" className="text-[10px]">{r.wfuas}</Badge> : "—"}
                    </TableCell>
                    {extraColumns.map((c) => (
                      <TableCell key={c.header} className={c.className}>
                        {c.cell(r)}
                      </TableCell>
                    ))}
                    <TableCell>
                      <Button asChild size="icon" variant="ghost" className="h-7 w-7">
                        <Link to={`/pim/articles/${encodeURIComponent(r.cdpar.trim())}`}>
                          <ExternalLink className="h-3.5 w-3.5" />
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {Number(total) > PAGE && (
        <div className="flex items-center justify-end gap-2 text-sm">
          <span className="text-muted-foreground">
            Pagina {page + 1} di {pages}
          </span>
          <Button variant="outline" size="sm" disabled={page === 0} onClick={() => setPage((p) => Math.max(0, p - 1))}>
            Indietro
          </Button>
          <Button variant="outline" size="sm" disabled={page + 1 >= pages} onClick={() => setPage((p) => p + 1)}>
            Avanti
          </Button>
        </div>
      )}
    </ControlListShell>
  );
}

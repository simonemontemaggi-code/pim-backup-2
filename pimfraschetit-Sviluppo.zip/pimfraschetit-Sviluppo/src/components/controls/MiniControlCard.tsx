import { Link } from "react-router-dom";
import { LucideIcon, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

interface Props {
  title: string;
  count: number | null | undefined;
  total?: number;
  icon: LucideIcon;
  href: string;
  loading?: boolean;
  /** se true: 0 = ok (verde), >0 = warning. Se false: nessuna semantica */
  invertGood?: boolean;
  subtitle?: string;
}

export function MiniControlCard({
  title,
  count,
  total,
  icon: Icon,
  href,
  loading,
  invertGood = true,
  subtitle,
}: Props) {
  const isOk = invertGood && count === 0;
  const isWarn = invertGood && (count ?? 0) > 0;
  return (
    <Link
      to={href}
      className={cn(
        "group block rounded-md border bg-card p-3 transition hover:border-primary/60 hover:shadow-sm",
        isWarn && "border-warning/40",
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Icon
            className={cn(
              "h-4 w-4 shrink-0",
              isOk ? "text-success" : isWarn ? "text-warning" : "text-primary",
            )}
          />
          <span className="text-xs font-medium leading-tight truncate">{title}</span>
        </div>
        {isOk && <CheckCircle2 className="h-3.5 w-3.5 text-success" />}
      </div>
      <div className="mt-2 flex items-baseline gap-2">
        {loading ? (
          <Skeleton className="h-7 w-16" />
        ) : (
          <span
            className={cn(
              "text-2xl font-bold tabular-nums leading-none",
              isOk ? "text-success" : isWarn ? "text-warning" : "text-foreground",
            )}
          >
            {(count ?? 0).toLocaleString("it-IT")}
          </span>
        )}
        {total != null && !loading && (
          <span className="text-[10px] text-muted-foreground">/ {total.toLocaleString("it-IT")}</span>
        )}
      </div>
      {subtitle && (
        <div className="mt-1 text-[10px] text-muted-foreground truncate">{subtitle}</div>
      )}
    </Link>
  );
}

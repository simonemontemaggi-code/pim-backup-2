import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Trash2, Save, AlertCircle } from "lucide-react";

interface Props {
  open: boolean;
  onClose: () => void;
  supplier: { id: string; cdfor: string; rasfo: string | null } | null;
}

// AS400 codes for cdfor are right-padded to 6 chars (es: "0001  ")
// In DB il wcdfo è memorizzato come 4 caratteri (es "8843"). Padding a 6 era sbagliato.
const normalizeCdfor = (c: string) => c.trim();

export default function SupplierDifferentialDialog({ open, onClose, supplier }: Props) {
  const queryClient = useQueryClient();
  const wcdfo = supplier ? normalizeCdfor(supplier.cdfor) : "";

  const [active, setActive] = useState(false);
  const [wscfa, setWscfa] = useState<string>("0");
  const [wdacq, setWdacq] = useState("");
  const [autoDesc, setAutoDesc] = useState(true);

  // Carica record differenziale
  const { data: diff, isLoading: loadingDiff } = useQuery({
    queryKey: ["supplier-differential", wcdfo],
    queryFn: async () => {
      if (!wcdfo) return null;
      // Match tollerante: in DB il valore può avere padding/spazi
      const { data } = await supabase
        .from("differenziale_cambio")
        .select("*")
        .or(`wcdfo.eq.${wcdfo},wcdfo.ilike.${wcdfo}%`);
      const rows = data ?? [];
      // Solo il record §DC è un vero differenziale. Il "GENERICO" va ignorato.
      const dcRow = rows.find((r: any) => {
        const v = String(r.wcacq ?? "").trim();
        return v.includes("§DC") || v.includes("Â§DC");
      });
      return dcRow ?? null;
    },
    enabled: open && !!wcdfo,
  });

  // Valuta standard fornitore: priorità al wcdva del differenziale, poi calcolo dagli articoli
  const { data: wcdvaCalc } = useQuery({
    queryKey: ["supplier-currency", supplier?.cdfor],
    queryFn: async () => {
      if (!supplier?.cdfor) return null;
      const { data } = await supabase
        .from("article_purchases")
        .select("cdval")
        .eq("cdfor", supplier.cdfor)
        .not("cdval", "is", null)
        .limit(500);
      const counts: Record<string, number> = {};
      (data ?? []).forEach((r: any) => {
        const v = String(r.cdval || "").trim();
        if (v) counts[v] = (counts[v] || 0) + 1;
      });
      const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
      return sorted[0]?.[0] ?? "EURO";
    },
    enabled: open && !!supplier?.cdfor,
  });
  const wcdva = String(diff?.wcdva ?? "").trim() || wcdvaCalc || "EURO";

  // Reset stato quando cambia fornitore o si caricano dati
  useEffect(() => {
    if (!open) return;
    if (diff) {
      const wcacqStr = String(diff.wcacq ?? "").trim();
      const wan02Str = String(diff.wan02 ?? "").trim().toUpperCase();
      const hasDC = wcacqStr.includes("§DC") || wcacqStr.includes("Â§DC");
      const isActive = hasDC && wan02Str !== "A";
      setActive(isActive);
      setWscfa(String(diff.wscfa ?? 0));
      const existingDesc = diff.wdacq?.trim() ?? "";
      setWdacq(existingDesc);
      // Se esiste già una descrizione nel DB la teniamo (auto OFF), altrimenti auto-genera.
      setAutoDesc(!existingDesc);
    } else {
      setActive(false);
      setWscfa("0");
      setWdacq("");
      setAutoDesc(true);
    }
  }, [diff, open, supplier?.id]);

  // Auto-genera descrizione se in modalità auto
  useEffect(() => {
    if (!autoDesc) return;
    const n = parseInt(wscfa || "0", 10);
    const sign = n >= 0 ? "" : "-";
    setWdacq(`Differenziale cambio ${sign}${Math.abs(n).toFixed(0)},00 %`);
  }, [wscfa, autoDesc]);

  const saveMutation = useMutation({
    mutationFn: async ({ deleting }: { deleting: boolean }) => {
      if (!supplier) throw new Error("Nessun fornitore");
      const wscfaNum = parseInt(wscfa || "0", 10);
      if (Number.isNaN(wscfaNum)) throw new Error("Sconto/magg. deve essere intero");

      const wan02 = deleting ? "A" : "";
      const wcacq = deleting ? "" : "Â§DC";

      // Upsert/delete record locale
      if (deleting) {
        if (diff?.id) {
          const { error } = await supabase.from("differenziale_cambio").delete().eq("id", diff.id);
          if (error) throw error;
        }
      } else {
        const payload: any = {
          wcdfo, wan02, wcacq, wscfa: wscfaNum, wdacq: wdacq.slice(0, 40), wcdva: wcdva ?? "EURO",
        };
        if (diff?.id) {
          const { error } = await supabase.from("differenziale_cambio").update(payload).eq("id", diff.id);
          if (error) throw error;
        } else {
          const { error } = await supabase.from("differenziale_cambio").insert(payload);
          if (error) throw error;
        }
      }

      // Trasmetti ad AS400 (NO wcdva)
      const { data: { session } } = await supabase.auth.getSession();
      const { error: fnErr } = await supabase.functions.invoke("sync-supplier-differential", {
        body: { wcdfo, wan02, wcacq, wscfa: wscfaNum, wdacq: wdacq.slice(0, 40) },
        headers: session ? { Authorization: `Bearer ${session.access_token}` } : undefined,
      });
      if (fnErr) throw fnErr;
    },
    onSuccess: (_d, vars) => {
      toast({ title: vars.deleting ? "Differenziale cancellato" : "Differenziale salvato" });
      queryClient.invalidateQueries({ queryKey: ["supplier-differential", wcdfo] });
      onClose();
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  if (!supplier) return null;
  const wscfaNum = parseInt(wscfa || "0", 10);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            Differenziale Cambio
            {active && <Badge variant="default" className="text-xs">Attivo</Badge>}
            {diff && !active && <Badge variant="outline" className="text-xs">Cancellato</Badge>}
          </DialogTitle>
          <p className="text-xs text-muted-foreground font-mono">
            {supplier.cdfor} — {supplier.rasfo}
          </p>
        </DialogHeader>

        {loadingDiff ? (
          <div className="py-8 text-center text-sm text-muted-foreground">Caricamento...</div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between rounded-md border p-3">
              <div>
                <Label className="text-sm font-medium">Differenziale attivo</Label>
                <p className="text-xs text-muted-foreground">
                  {active ? "Trasmette Â§DC ad AS400" : "Disattivato → invia annullamento (A) ad AS400"}
                </p>
              </div>
              <Switch checked={active} onCheckedChange={setActive} />
            </div>

            <div>
              <Label className="text-xs text-muted-foreground">Codice valuta (standard fornitore — non trasmesso)</Label>
              <div className="mt-1 h-9 px-3 flex items-center rounded-md border bg-muted/40 text-sm font-mono text-foreground">
                {wcdva ?? "—"}
              </div>
            </div>

            <div>
              <Label className="text-xs text-muted-foreground">Sconto / Maggiorazione (wscfa)</Label>
              <Input
                type="number"
                step="1"
                value={wscfa}
                onChange={(e) => setWscfa(e.target.value.replace(/[^\d-]/g, ""))}
                className="h-9 text-sm mt-1"
              />
              <p className="text-[11px] text-muted-foreground mt-1">
                Intero. Negativo = aumento prezzo · Positivo = diminuzione.
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <Label className="text-xs text-muted-foreground">Descrizione (wdacq, max 40)</Label>
                <label className="flex items-center gap-1.5 text-[11px] text-muted-foreground cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={autoDesc}
                    onChange={(e) => setAutoDesc(e.target.checked)}
                    className="h-3 w-3 accent-primary"
                  />
                  Crea Testo Automatico
                </label>
              </div>
              <Input
                value={wdacq}
                onChange={(e) => { setAutoDesc(false); setWdacq(e.target.value.slice(0, 40)); }}
                className="h-9 text-sm"
                maxLength={40}
              />
            </div>

            {!active && diff && (
              <div className="flex items-start gap-2 rounded-md border border-destructive/30 bg-destructive/5 p-2 text-xs">
                <AlertCircle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />
                <span>Salvando con differenziale disattivo verrà trasmesso il carattere di annullamento (wan02 = "A") ad AS400 e il record locale sarà eliminato.</span>
              </div>
            )}
          </div>
        )}

        <DialogFooter className="flex-col sm:flex-row gap-2 sm:gap-2 sm:justify-end">
          <DialogClose asChild>
            <Button variant="outline" size="sm" className="w-full sm:w-auto">Annulla</Button>
          </DialogClose>
          {diff && (
            <Button
              variant="destructive"
              size="sm"
              onClick={() => saveMutation.mutate({ deleting: true })}
              disabled={saveMutation.isPending}
              className="w-full sm:w-auto"
            >
              <Trash2 className="h-3 w-3 mr-1" /> Elimina
            </Button>
          )}
          <Button
            size="sm"
            onClick={() => saveMutation.mutate({ deleting: !active })}
            disabled={saveMutation.isPending}
            className="w-full sm:w-auto"
          >
            <Save className="h-3 w-3 mr-1" /> Salva e trasmetti
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

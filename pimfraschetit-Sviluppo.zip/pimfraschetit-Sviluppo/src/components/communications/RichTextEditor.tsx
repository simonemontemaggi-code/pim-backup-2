import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Image from "@tiptap/extension-image";
import Link from "@tiptap/extension-link";
import TextAlign from "@tiptap/extension-text-align";
import Underline from "@tiptap/extension-underline";
import { Color } from "@tiptap/extension-color";
import { TextStyle } from "@tiptap/extension-text-style";
import { Table } from "@tiptap/extension-table";
import { TableRow } from "@tiptap/extension-table-row";
import { TableCell } from "@tiptap/extension-table-cell";
import { TableHeader } from "@tiptap/extension-table-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useRef, useState, useCallback } from "react";
import { usePrompt, useConfirm } from "@/components/ui/confirm-dialog";
import mammoth from "mammoth";

const TEXT_COLORS = [
  "#000000", "#374151", "#6b7280", "#9ca3af",
  "#dc2626", "#ea580c", "#d97706", "#ca8a04",
  "#16a34a", "#059669", "#0891b2", "#2563eb",
  "#4f46e5", "#7c3aed", "#c026d3", "#db2777",
];
import {
  Bold, Italic, UnderlineIcon, Strikethrough, List, ListOrdered,
  AlignLeft, AlignCenter, AlignRight, Link as LinkIcon, Image as ImageIcon,
  Heading1, Heading2, Undo, Redo, Palette, FileUp, Loader2,
} from "lucide-react";

interface Props {
  value: string;
  onChange: (html: string) => void;
}

export function RichTextEditor({ value, onChange }: Props) {
  const promptDialog = usePrompt();
  const confirmDialog = useConfirm();
  const fileRef = useRef<HTMLInputElement>(null);
  const docxRef = useRef<HTMLInputElement>(null);
  const [importing, setImporting] = useState(false);
  const [importStatus, setImportStatus] = useState<string>("");
  const [dragActive, setDragActive] = useState(false);
  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: {
          levels: [1, 2, 3],
          HTMLAttributes: {
            class: "tiptap-heading",
          },
        },
        bulletList: { HTMLAttributes: { class: "list-disc pl-6" } },
        orderedList: { HTMLAttributes: { class: "list-decimal pl-6" } },
      }),
      Underline,
      TextStyle,
      Color,
      Image.configure({ inline: false, HTMLAttributes: { class: "max-w-full rounded my-2" } }),
      Link.configure({ openOnClick: false, HTMLAttributes: { class: "text-primary underline" } }),
      TextAlign.configure({ types: ["heading", "paragraph"] }),
      Table.configure({
        resizable: true,
        HTMLAttributes: { class: "tiptap-table border-collapse my-3 w-full" },
      }),
      TableRow,
      TableHeader.configure({
        HTMLAttributes: { class: "border border-border bg-muted px-2 py-1 font-semibold text-left" },
      }),
      TableCell.configure({
        HTMLAttributes: { class: "border border-border px-2 py-1 align-top" },
      }),
    ],
    content: value || "",
    onUpdate: ({ editor }) => onChange(editor.getHTML()),
    editorProps: {
      attributes: {
        class: "prose prose-sm max-w-none min-h-[280px] p-4 focus:outline-none",
      },
      handlePaste: (view, event) => {
        const items = event.clipboardData?.items;
        if (!items) return false;
        const imageFiles: File[] = [];
        for (let i = 0; i < items.length; i++) {
          const it = items[i];
          if (it.kind === "file" && it.type.startsWith("image/")) {
            const f = it.getAsFile();
            if (f) imageFiles.push(f);
          }
        }
        if (imageFiles.length === 0) return false;
        event.preventDefault();
        (async () => {
          for (const file of imageFiles) {
            try {
              const ext = (file.name.split(".").pop() || file.type.split("/")[1] || "png").toLowerCase();
              const path = `inline/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
              const { error } = await supabase.storage
                .from("b2b-communications")
                .upload(path, file, { contentType: file.type || "image/png", upsert: false });
              if (error) throw error;
              const { data } = supabase.storage.from("b2b-communications").getPublicUrl(path);
              (view as any).dispatch(
                view.state.tr.replaceSelectionWith(
                  view.state.schema.nodes.image.create({ src: data.publicUrl })
                )
              );
            } catch (e: any) {
              toast.error(`Upload immagine fallito: ${e.message}`);
            }
          }
        })();
        return true;
      },
      transformPastedHTML: (html) => {
        try {
          const doc = new DOMParser().parseFromString(html, "text/html");
          const imgs = Array.from(doc.querySelectorAll("img"));
          let removed = 0;
          imgs.forEach((img) => {
            const src = (img.getAttribute("src") || "").trim();
            const isValid =
              src.startsWith("http://") ||
              src.startsWith("https://") ||
              src.startsWith("data:image/");
            if (!isValid) {
              img.remove();
              removed++;
            }
          });
          if (removed > 0) {
            setTimeout(() => {
              toast.warning(
                `${removed} ${removed === 1 ? "immagine rimossa" : "immagini rimosse"} dal contenuto incollato`,
                {
                  description:
                    "Le immagini da Word non possono essere incollate insieme al testo. Copia e incolla ogni immagine separatamente per caricarla automaticamente.",
                  duration: 6000,
                }
              );
            }, 0);
          }
          return doc.body.innerHTML;
        } catch {
          return html;
        }
      },
    },
  });

  if (!editor) return null;

  const uploadImage = async (file: File) => {
    try {
      const ext = file.name.split(".").pop()?.toLowerCase() || "png";
      const path = `inline/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
      const { error } = await supabase.storage
        .from("b2b-communications")
        .upload(path, file, { contentType: file.type, upsert: false });
      if (error) throw error;
      const { data } = supabase.storage.from("b2b-communications").getPublicUrl(path);
      editor.chain().focus().setImage({ src: data.publicUrl }).run();
    } catch (e: any) {
      toast.error(`Upload immagine fallito: ${e.message}`);
    }
  };

  const importDocx = useCallback(async (file: File) => {
    if (!file.name.toLowerCase().endsWith(".docx")) {
      toast.error("Formato non supportato. Usa un file .docx (non .doc)");
      return;
    }
    const hasContent = editor.getText().trim().length > 0;
    if (hasContent) {
      const ok = await confirmDialog({
        title: "Sovrascrivere il contenuto?",
        description: "Importando il Word verrà sostituito il contenuto attuale dell'editor.",
        confirmText: "Sovrascrivi",
        cancelText: "Annulla",
      });
      if (!ok) return;
    }
    setImporting(true);
    setImportStatus("Lettura file…");
    let imageCount = 0;
    let imageFailed = 0;
    const failures: string[] = [];
    try {
      const arrayBuffer = await file.arrayBuffer();
      const result = await mammoth.convertToHtml(
        { arrayBuffer },
        {
          convertImage: mammoth.images.imgElement(async (img: any) => {
            const idx = ++imageCount;
            setImportStatus(`Caricamento immagine ${idx}…`);
            try {
              const buffer = await img.read();
              const contentType = img.contentType || "image/png";
              const ext = (contentType.split("/")[1]?.split("+")[0] || "png").toLowerCase();
              const safeExt = ["png", "jpg", "jpeg", "gif", "webp", "svg", "bmp"].includes(ext) ? ext : "png";
              const path = `inline/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${safeExt}`;
              const blob = new Blob([buffer], { type: contentType });
              const { error } = await supabase.storage
                .from("b2b-communications")
                .upload(path, blob, { contentType, upsert: false });
              if (error) throw error;
              const { data } = supabase.storage.from("b2b-communications").getPublicUrl(path);
              return { src: data.publicUrl };
            } catch (e: any) {
              imageFailed++;
              const msg = `Immagine ${idx} (${img.contentType || "tipo sconosciuto"}): ${e.message || e}`;
              failures.push(msg);
              console.error("[docx import] image upload failed", msg, e);
              // Return empty src so mammoth keeps the document flow
              return { src: "" };
            }
          }),
        }
      );
      setImportStatus("Inserimento nell'editor…");
      // Strip any <img src=""> that resulted from failed uploads so the editor doesn't render broken images
      const cleaned = (result.value || "<p></p>").replace(/<img[^>]*src=""[^>]*>/g, "");
      editor.commands.setContent(cleaned);
      onChange(editor.getHTML());
      const mammothImgWarnings = (result.messages || []).filter((m: any) =>
        /image|picture|wmf|emf/i.test(m.message || "")
      );
      if (mammothImgWarnings.length) {
        console.warn("[docx import] mammoth image warnings", mammothImgWarnings);
      }
      const okImages = imageCount - imageFailed;
      const parts: string[] = [];
      if (okImages > 0) parts.push(`${okImages} ${okImages === 1 ? "immagine caricata" : "immagini caricate"}`);
      if (imageFailed > 0) parts.push(`${imageFailed} non importate`);
      if (mammothImgWarnings.length && imageCount === 0) {
        parts.push(`${mammothImgWarnings.length} immagini in formato non supportato (es. WMF/EMF)`);
      }
      toast.success(`Word importato${parts.length ? `: ${parts.join(", ")}` : ""}`, {
        description: failures.length
          ? failures.slice(0, 3).join(" • ")
          : mammothImgWarnings.length
            ? "Alcune immagini in formato Office legacy (WMF/EMF) non sono state convertite. Salvale come PNG/JPG nel Word e reimporta."
            : undefined,
        duration: failures.length || mammothImgWarnings.length ? 9000 : 4000,
      });
    } catch (e: any) {
      toast.error(`Import Word fallito: ${e.message || e}`);
    } finally {
      setImporting(false);
      setImportStatus("");
    }
  }, [editor, confirmDialog, onChange]);



  const setLink = async () => {
    const url = await promptDialog({
      title: "Inserisci link",
      description: "URL del link (lascia vuoto per rimuovere)",
      defaultValue: editor.getAttributes("link").href || "https://",
      placeholder: "https://…",
    });
    if (url === null) return;
    if (url === "") {
      editor.chain().focus().unsetLink().run();
      return;
    }
    editor.chain().focus().extendMarkRange("link").setLink({ href: url }).run();
  };

  const currentColor = editor.getAttributes("textStyle").color || "#000000";

  const Btn = ({ active, onClick, children, title }: any) => (
    <Button
      type="button"
      size="sm"
      variant={active ? "default" : "ghost"}
      onClick={onClick}
      title={title}
      className="h-8 w-8 p-0"
    >
      {children}
    </Button>
  );

  return (
    <div className="border rounded-md bg-background">
      <div className="flex flex-wrap items-center gap-1 border-b p-2 bg-muted/30">
        <Btn title="Grassetto" active={editor.isActive("bold")} onClick={() => editor.chain().focus().toggleBold().run()}><Bold className="h-4 w-4" /></Btn>
        <Btn title="Corsivo" active={editor.isActive("italic")} onClick={() => editor.chain().focus().toggleItalic().run()}><Italic className="h-4 w-4" /></Btn>
        <Btn title="Sottolineato" active={editor.isActive("underline")} onClick={() => editor.chain().focus().toggleUnderline().run()}><UnderlineIcon className="h-4 w-4" /></Btn>
        <Btn title="Barrato" active={editor.isActive("strike")} onClick={() => editor.chain().focus().toggleStrike().run()}><Strikethrough className="h-4 w-4" /></Btn>
        <div className="w-px h-6 bg-border mx-1" />
        <Btn title="Titolo 1" active={editor.isActive("heading", { level: 1 })} onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}><Heading1 className="h-4 w-4" /></Btn>
        <Btn title="Titolo 2" active={editor.isActive("heading", { level: 2 })} onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}><Heading2 className="h-4 w-4" /></Btn>
        <div className="w-px h-6 bg-border mx-1" />
        <Btn title="Lista puntata" active={editor.isActive("bulletList")} onClick={() => editor.chain().focus().toggleBulletList().run()}><List className="h-4 w-4" /></Btn>
        <Btn title="Lista numerata" active={editor.isActive("orderedList")} onClick={() => editor.chain().focus().toggleOrderedList().run()}><ListOrdered className="h-4 w-4" /></Btn>
        <div className="w-px h-6 bg-border mx-1" />
        <Btn title="Allinea a sinistra" active={editor.isActive({ textAlign: "left" })} onClick={() => editor.chain().focus().setTextAlign("left").run()}><AlignLeft className="h-4 w-4" /></Btn>
        <Btn title="Centra" active={editor.isActive({ textAlign: "center" })} onClick={() => editor.chain().focus().setTextAlign("center").run()}><AlignCenter className="h-4 w-4" /></Btn>
        <Btn title="Allinea a destra" active={editor.isActive({ textAlign: "right" })} onClick={() => editor.chain().focus().setTextAlign("right").run()}><AlignRight className="h-4 w-4" /></Btn>
        <div className="w-px h-6 bg-border mx-1" />
        <Popover>
          <PopoverTrigger asChild>
            <Button type="button" size="sm" variant="ghost" title="Colore testo" className="h-8 w-8 p-0 relative">
              <Palette className="h-4 w-4" />
              <span className="absolute bottom-1 left-1 right-1 h-0.5 rounded" style={{ backgroundColor: currentColor }} />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-2" align="start">
            <div className="grid grid-cols-8 gap-1">
              {TEXT_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => editor.chain().focus().setColor(c).run()}
                  className="h-6 w-6 rounded border border-border hover:scale-110 transition-transform"
                  style={{ backgroundColor: c }}
                  title={c}
                />
              ))}
            </div>
            <div className="flex items-center gap-2 mt-2 pt-2 border-t">
              <input
                type="color"
                value={currentColor}
                onChange={(e) => editor.chain().focus().setColor(e.target.value).run()}
                className="h-7 w-10 cursor-pointer rounded border"
              />
              <button
                type="button"
                onClick={() => editor.chain().focus().unsetColor().run()}
                className="text-xs text-muted-foreground hover:text-foreground"
              >
                Rimuovi colore
              </button>
            </div>
          </PopoverContent>
        </Popover>
        <Btn title="Inserisci link" active={editor.isActive("link")} onClick={setLink}><LinkIcon className="h-4 w-4" /></Btn>
        <Btn title="Inserisci immagine" onClick={() => fileRef.current?.click()}><ImageIcon className="h-4 w-4" /></Btn>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) uploadImage(f);
            e.target.value = "";
          }}
        />
        <div className="w-px h-6 bg-border mx-1" />
        <Btn title="Importa da Word (.docx)" onClick={() => docxRef.current?.click()}><FileUp className="h-4 w-4" /></Btn>
        <input
          ref={docxRef}
          type="file"
          accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) importDocx(f);
            e.target.value = "";
          }}
        />
        <div className="w-px h-6 bg-border mx-1" />
        <Btn title="Annulla" onClick={() => editor.chain().focus().undo().run()}><Undo className="h-4 w-4" /></Btn>
        <Btn title="Ripristina" onClick={() => editor.chain().focus().redo().run()}><Redo className="h-4 w-4" /></Btn>
      </div>
      <div
        className="relative"
        onDragOver={(e) => {
          if (Array.from(e.dataTransfer.items || []).some((it) => it.kind === "file")) {
            e.preventDefault();
            setDragActive(true);
          }
        }}
        onDragLeave={(e) => {
          if (e.currentTarget === e.target) setDragActive(false);
        }}
        onDrop={(e) => {
          const file = Array.from(e.dataTransfer.files || []).find((f) =>
            f.name.toLowerCase().endsWith(".docx")
          );
          if (file) {
            e.preventDefault();
            setDragActive(false);
            importDocx(file);
          } else {
            setDragActive(false);
          }
        }}
      >
        <EditorContent editor={editor} />
        {dragActive && (
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center bg-primary/10 border-2 border-dashed border-primary rounded">
            <div className="text-sm font-medium text-primary flex items-center gap-2">
              <FileUp className="h-5 w-5" />
              Rilascia il file .docx per importarlo
            </div>
          </div>
        )}
        {importing && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm rounded">
            <div className="text-sm font-medium flex items-center gap-2">
              <Loader2 className="h-5 w-5 animate-spin" />
              {importStatus || "Importazione in corso…"}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

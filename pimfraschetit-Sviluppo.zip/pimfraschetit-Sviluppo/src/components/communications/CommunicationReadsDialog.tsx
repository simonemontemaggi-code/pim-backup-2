import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FileSpreadsheet, FileText } from "lucide-react";
import { downloadXlsx } from "@/lib/xlsxExport";
import { jsPDF } from "jspdf";
import { toast } from "sonner";

interface ReadRow {
  app: string;
  user_identifier: string;
  read_at: string;
  code: string;
  name: string;
  tag: "" | "Staff" | "Utente sconosciuto";
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;


const fmt = (iso: string) =>
  new Date(iso).toLocaleString("it-IT", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });

export function CommunicationReadsDialog({
  communicationId,
  title,
  open,
  onOpenChange,
}: {
  communicationId: string;
  title: string;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [rows, setRows] = useState<ReadRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [q, setQ] = useState("");

  useEffect(() => {
    if (!open) return;
    (async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from("b2b_communication_reads")
        .select("app, user_identifier, read_at")
        .eq("communication_id", communicationId)
        .order("read_at", { ascending: false });
      if (error) {
        toast.error(error.message);
        setLoading(false);
        return;
      }
      const list = data || [];
      const uuids = Array.from(new Set(list.map((r) => r.user_identifier).filter((v) => v && UUID_RE.test(v))));
      const agentCodes = Array.from(
        new Set(list.filter((r) => r.app === "agent_hub" && !UUID_RE.test(r.user_identifier || "")).map((r) => r.user_identifier).filter(Boolean)),
      );
      const customerCodes = Array.from(
        new Set(list.filter((r) => r.app !== "agent_hub" && !UUID_RE.test(r.user_identifier || "")).map((r) => r.user_identifier).filter(Boolean)),
      );

      const nameByAgent = new Map<string, string>();
      const nameByCustomer = new Map<string, string>();
      const byUuid = new Map<string, { code: string; name: string; tag: ReadRow["tag"] }>();

      if (agentCodes.length) {
        const { data: ags } = await supabase
          .from("profiles")
          .select("agent_code, full_name")
          .in("agent_code", agentCodes);
        (ags || []).forEach((a: any) => {
          if (a.agent_code) nameByAgent.set(a.agent_code, a.full_name || "");
        });
      }
      if (customerCodes.length) {
        const { data: cs } = await supabase
          .from("customers")
          .select("customer_code, company_full_name, company_name")
          .in("customer_code", customerCodes);
        (cs || []).forEach((c: any) => {
          if (c.customer_code) nameByCustomer.set(c.customer_code, c.company_full_name || c.company_name || "");
        });
      }

      if (uuids.length) {
        const [profRes, custRes, roleRes] = await Promise.all([
          supabase.from("profiles").select("user_id, full_name, email, agent_code").in("user_id", uuids),
          supabase.from("customers").select("auth_user_id, customer_code, company_full_name, company_name").in("auth_user_id", uuids),
          supabase.from("user_roles").select("user_id, role").in("user_id", uuids),
        ]);
        const custByUser = new Map<string, any>();
        (custRes.data || []).forEach((c: any) => {
          if (c.auth_user_id) custByUser.set(c.auth_user_id, c);
        });
        const rolesByUser = new Map<string, string[]>();
        (roleRes.data || []).forEach((r: any) => {
          rolesByUser.set(r.user_id, [...(rolesByUser.get(r.user_id) || []), r.role]);
        });
        (profRes.data || []).forEach((p: any) => {
          const cust = custByUser.get(p.user_id);
          const roles = rolesByUser.get(p.user_id) || [];
          const isCustomer = !!cust || roles.includes("customer");
          byUuid.set(p.user_id, {
            code: cust?.customer_code || p.agent_code || "",
            name: cust ? cust.company_full_name || cust.company_name || "" : p.full_name || p.email || "",
            tag: isCustomer ? "" : "Staff",
          });
        });
      }

      setRows(
        list.map((r) => {
          const id = r.user_identifier || "";
          if (UUID_RE.test(id)) {
            const info = byUuid.get(id);
            return {
              app: r.app,
              user_identifier: id,
              read_at: r.read_at,
              code: info?.code || "—",
              name: info?.name || `${id.slice(0, 8)}…`,
              tag: info ? info.tag : ("Utente sconosciuto" as const),
            };
          }
          return {
            app: r.app,
            user_identifier: id,
            read_at: r.read_at,
            code: id,
            name: (r.app === "agent_hub" ? nameByAgent.get(id) : nameByCustomer.get(id)) || "",
            tag: "" as const,
          };
        }),
      );
      setLoading(false);
    })();
  }, [open, communicationId]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return rows;
    return rows.filter(
      (r) => r.code.toLowerCase().includes(s) || r.name.toLowerCase().includes(s) || r.user_identifier?.toLowerCase().includes(s),
    );
  }, [rows, q]);


  const exportRows = () =>
    filtered.map((r) => ({
      Origine: r.app === "agent_hub" ? "Agent Hub" : "B2B",
      Codice: r.code,
      Nome: r.tag ? `${r.name} (${r.tag})` : r.name,

      "Data lettura": fmt(r.read_at),
    }));

  const exportXlsx = () => {
    if (!filtered.length) return;
    downloadXlsx(`letture-comunicazione-${new Date().toISOString().slice(0, 10)}.xlsx`, exportRows(), { sheetName: "Letture" });
  };

  const exportPdf = () => {
    if (!filtered.length) return;
    const doc = new jsPDF({ unit: "mm", format: "a4" });
    const startX = 12;
    const widths = [30, 28, 90, 40];
    const headers = ["Origine", "Codice", "Nome", "Data lettura"];
    let y = 26;
    doc.setFontSize(14);
    doc.text("Letture comunicazione", startX, 14);
    doc.setFontSize(9);
    doc.setTextColor(110);
    doc.text(`${title} · ${filtered.length} letture · ${new Date().toLocaleDateString("it-IT")}`, startX, 20);
    doc.setTextColor(0);

    const drawHeader = () => {
      doc.setFillColor(15, 23, 42);
      doc.rect(startX, y - 5, widths.reduce((a, b) => a + b, 0), 7, "F");
      doc.setTextColor(255);
      doc.setFontSize(8);
      let x = startX + 1.5;
      headers.forEach((h, i) => {
        doc.text(h, x, y);
        x += widths[i];
      });
      doc.setTextColor(0);
      y += 6;
      doc.setFontSize(8);
    };
    drawHeader();

    exportRows().forEach((row, idx) => {
      if (y > 280) {
        doc.addPage();
        y = 20;
        drawHeader();
      }
      if (idx % 2 === 1) {
        doc.setFillColor(244, 246, 250);
        doc.rect(startX, y - 4, widths.reduce((a, b) => a + b, 0), 5.5, "F");
      }
      let x = startX + 1.5;
      headers.forEach((h, i) => {
        const txt = String((row as any)[h] ?? "");
        doc.text(doc.splitTextToSize(txt, widths[i] - 3)[0] ?? "", x, y);
        x += widths[i];
      });
      y += 5.5;
    });

    doc.save(`letture-comunicazione-${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Chi ha letto — {title}</DialogTitle>
        </DialogHeader>
        <div className="flex items-center gap-2">
          <Input placeholder="Cerca per codice o nome…" value={q} onChange={(e) => setQ(e.target.value)} className="max-w-xs" />
          <span className="text-sm text-muted-foreground">{filtered.length} letture</span>
          <div className="ml-auto flex gap-2">
            <Button variant="outline" size="sm" onClick={exportXlsx} disabled={!filtered.length}>
              <FileSpreadsheet className="h-4 w-4 mr-1" /> Excel
            </Button>
            <Button variant="outline" size="sm" onClick={exportPdf} disabled={!filtered.length}>
              <FileText className="h-4 w-4 mr-1" /> PDF
            </Button>
          </div>
        </div>
        <div className="max-h-[55vh] overflow-auto border rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-28">Origine</TableHead>
                <TableHead className="w-24">Codice</TableHead>
                <TableHead>Nome</TableHead>
                <TableHead className="w-40">Data lettura</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground py-6">Caricamento…</TableCell>
                </TableRow>
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground py-6">Nessuna lettura</TableCell>
                </TableRow>
              ) : (
                filtered.map((r, i) => (
                  <TableRow key={`${r.app}-${r.user_identifier}-${i}`}>
                    <TableCell>
                      <Badge variant={r.app === "agent_hub" ? "default" : "secondary"}>
                        {r.app === "agent_hub" ? "Agent Hub" : "B2B"}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{r.code}</TableCell>
                    <TableCell className="text-sm">
                      {r.name || <span className="text-muted-foreground">—</span>}
                      {r.tag && (
                        <Badge variant="outline" className="ml-2 text-[10px] font-normal">
                          {r.tag}
                        </Badge>
                      )}
                    </TableCell>

                    <TableCell className="text-sm tabular-nums">{fmt(r.read_at)}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </DialogContent>
    </Dialog>
  );
}

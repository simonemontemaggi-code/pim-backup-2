import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/lib/permissions";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { Search, Pencil, Check, X, Users, Info } from "lucide-react";

const PAGE_SIZE = 1000;

async function fetchAllPaginated<T>(
  build: (from: number, to: number) => any,
): Promise<T[]> {
  const out: T[] = [];
  let from = 0;
  while (true) {
    const to = from + PAGE_SIZE - 1;
    const { data, error } = await build(from, to);
    if (error) throw error;
    const chunk = (data ?? []) as T[];
    out.push(...chunk);
    if (chunk.length < PAGE_SIZE) break;
    from += PAGE_SIZE;
  }
  return out;
}

interface Agent {
  id: string;
  user_id: string;
  full_name: string | null;
  email: string | null;
  agent_code: string | null;
}

interface CustomerRow {
  id: string;
  customer_code: string | null;
  company_name: string | null;
  city: string | null;
  original_agent_code: string | null;
  assigned_agent_id: string | null;
}

export default function AgentCustomerManager() {
  const { can, sectionVisible } = usePermissions();
  const qc = useQueryClient();

  const allowed = sectionVisible("users_admin") && can("write", "users_admin");

  const [agentSearch, setAgentSearch] = useState("");
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingCode, setEditingCode] = useState("");
  const [custSearch, setCustSearch] = useState("");

  const agentsQ = useQuery({
    queryKey: ["agents-list"],
    enabled: allowed,
    queryFn: async () => {
      const rows = await fetchAllPaginated<Agent>((from, to) =>
        supabase
          .from("profiles")
          .select("id, user_id, full_name, email, agent_code")
          .not("agent_code", "is", null)
          .order("agent_code", { ascending: true })
          .range(from, to),
      );
      return rows;
    },
  });

  const countsQ = useQuery({
    queryKey: ["agents-customer-counts", (agentsQ.data ?? []).length],
    enabled: allowed && !!agentsQ.data,
    queryFn: async () => {
      const rows = await fetchAllPaginated<{ assigned_agent_id: string | null }>(
        (from, to) =>
          supabase
            .from("customers")
            .select("assigned_agent_id")
            .not("assigned_agent_id", "is", null)
            .range(from, to),
      );
      const map = new Map<string, number>();
      rows.forEach((r) => {
        if (r.assigned_agent_id) {
          map.set(r.assigned_agent_id, (map.get(r.assigned_agent_id) ?? 0) + 1);
        }
      });
      return map;
    },
  });

  const selectedAgentEarly = (agentsQ.data ?? []).find((a) => a.id === selectedAgentId) ?? null;

  const custQ = useQuery({
    queryKey: ["agent-customers", selectedAgentId],
    enabled: allowed && !!selectedAgentId,
    queryFn: async () => {
      // L'assegnazione è derivata dal trigger fn_customers_normalize_assigned_agent:
      // basta filtrare per assigned_agent_id, non serve più il fallback su original_agent_code.
      const rows = await fetchAllPaginated<CustomerRow>((from, to) =>
        supabase
          .from("customers")
          .select("id, customer_code, company_name, city, original_agent_code, assigned_agent_id")
          .eq("assigned_agent_id", selectedAgentId!)
          .order("company_name", { ascending: true })
          .range(from, to),
      );
      return rows;
    },
  });

  const agents = agentsQ.data ?? [];
  const counts = countsQ.data ?? new Map<string, number>();
  const filteredAgents = useMemo(() => {
    if (!agentSearch.trim()) return agents;
    const s = agentSearch.toLowerCase();
    return agents.filter(
      (a) =>
        a.agent_code?.toLowerCase().includes(s) ||
        a.full_name?.toLowerCase().includes(s) ||
        a.email?.toLowerCase().includes(s),
    );
  }, [agents, agentSearch]);

  const customers = custQ.data ?? [];
  const filteredCustomers = useMemo(() => {
    if (!custSearch.trim()) return customers;
    const s = custSearch.toLowerCase();
    return customers.filter(
      (c) =>
        c.customer_code?.toLowerCase().includes(s) ||
        c.company_name?.toLowerCase().includes(s) ||
        c.city?.toLowerCase().includes(s),
    );
  }, [customers, custSearch]);

  const selectedAgent = agents.find((a) => a.id === selectedAgentId) ?? null;

  const handleSelectAgent = (id: string) => {
    setSelectedAgentId(id);
    setCustSearch("");
  };

  const startEdit = (a: Agent) => {
    setEditingId(a.id);
    setEditingCode(a.agent_code ?? "");
  };

  const saveEdit = async (a: Agent) => {
    const next = editingCode.trim();
    if (!next) {
      toast.error("Codice agente non può essere vuoto");
      return;
    }
    const { error } = await supabase
      .from("profiles")
      .update({ agent_code: next })
      .eq("id", a.id);
    if (error) {
      toast.error("Errore aggiornamento", { description: error.message });
      return;
    }
    toast.success("Codice agente aggiornato", {
      description:
        "I clienti verranno riassegnati automaticamente al prossimo aggiornamento anagrafica AS400.",
    });
    setEditingId(null);
    qc.invalidateQueries({ queryKey: ["agents-list"] });
    qc.invalidateQueries({ queryKey: ["agents-customer-counts"] });
    qc.invalidateQueries({ queryKey: ["agent-customers"] });
    qc.invalidateQueries({ queryKey: ["admin_users"] });
  };

  if (!allowed) {
    return (
      <div className="p-6 text-sm text-muted-foreground">
        Accesso non consentito.
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-start gap-2 rounded-md border bg-muted/30 p-3 text-xs text-muted-foreground">
        <Info className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
        <div>
          <strong className="text-foreground">Assegnazione automatica.</strong>{" "}
          Ogni cliente è assegnato all'agente il cui <em>codice agente</em>{" "}
          coincide con il codice agente originale del cliente (campo AS400).
          La riassegnazione manuale per singolo cliente è disabilitata: per
          spostare clienti, modifica il <em>codice agente</em> sul profilo
          dell'agente (icona <Pencil className="inline h-3 w-3" />).
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-[380px_1fr]">
        {/* SX — Agenti */}
        <div className="border rounded-md flex flex-col min-h-[500px]">
          <div className="p-3 border-b">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                className="pl-8"
                placeholder="Cerca agente…"
                value={agentSearch}
                onChange={(e) => setAgentSearch(e.target.value)}
              />
            </div>
          </div>
          <div className="overflow-auto flex-1">
            {agentsQ.isLoading ? (
              <div className="p-3 space-y-2">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : filteredAgents.length === 0 ? (
              <div className="p-8 text-center text-sm text-muted-foreground">
                <Users className="mx-auto h-8 w-8 text-muted-foreground/30 mb-2" />
                Nessun agente trovato
              </div>
            ) : (
              <ul className="divide-y">
                {filteredAgents.map((a) => {
                  const isSel = a.id === selectedAgentId;
                  const isEditing = editingId === a.id;
                  const n = counts.get(a.id) ?? 0;
                  return (
                    <li
                      key={a.id}
                      className={`p-3 cursor-pointer hover:bg-accent/50 ${
                        isSel ? "bg-accent" : ""
                      }`}
                      onClick={() => !isEditing && handleSelectAgent(a.id)}
                    >
                      <div className="flex items-center gap-2">
                        {isEditing ? (
                          <div className="flex items-center gap-1 flex-1">
                            <Input
                              autoFocus
                              value={editingCode}
                              onChange={(e) => setEditingCode(e.target.value)}
                              onClick={(e) => e.stopPropagation()}
                              className="h-7 w-24"
                            />
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-7 w-7"
                              onClick={(e) => {
                                e.stopPropagation();
                                saveEdit(a);
                              }}
                            >
                              <Check className="h-4 w-4" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-7 w-7"
                              onClick={(e) => {
                                e.stopPropagation();
                                setEditingId(null);
                              }}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : (
                          <>
                            <Badge variant="outline" className="font-mono">
                              {a.agent_code}
                            </Badge>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-6 w-6"
                              onClick={(e) => {
                                e.stopPropagation();
                                startEdit(a);
                              }}
                            >
                              <Pencil className="h-3 w-3" />
                            </Button>
                            <Badge variant="secondary" className="ml-auto">
                              {n}
                            </Badge>
                          </>
                        )}
                      </div>
                      <div className="mt-1 text-sm font-medium truncate">
                        {a.full_name ?? "—"}
                      </div>
                      <div className="text-xs text-muted-foreground truncate">
                        {a.email ?? "—"}
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>

        {/* DX — Clienti (read-only) */}
        <div className="border rounded-md flex flex-col min-h-[500px]">
          {!selectedAgent ? (
            <div className="flex-1 flex items-center justify-center text-sm text-muted-foreground p-8 text-center">
              Seleziona un agente per vedere i suoi clienti.
            </div>
          ) : (
            <>
              <div className="p-3 border-b space-y-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant="outline" className="font-mono">
                    {selectedAgent.agent_code}
                  </Badge>
                  <span className="font-semibold">{selectedAgent.full_name}</span>
                  <Badge variant="secondary" className="ml-auto">
                    {custQ.isLoading ? "…" : `${customers.length} clienti`}
                  </Badge>
                </div>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    className="pl-8"
                    placeholder="Cerca per codice, ragione sociale o città…"
                    value={custSearch}
                    onChange={(e) => setCustSearch(e.target.value)}
                  />
                </div>
              </div>

              <div className="overflow-auto flex-1">
                {custQ.isLoading ? (
                  <div className="p-3 space-y-2">
                    {Array.from({ length: 8 }).map((_, i) => (
                      <Skeleton key={i} className="h-8 w-full" />
                    ))}
                  </div>
                ) : filteredCustomers.length === 0 ? (
                  <div className="p-8 text-center text-sm text-muted-foreground">
                    Nessun cliente trovato.
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Codice</TableHead>
                        <TableHead>Ragione sociale</TableHead>
                        <TableHead>Città</TableHead>
                        <TableHead>Agente AS400</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredCustomers.map((c) => (
                        <TableRow key={c.id}>
                          <TableCell className="font-mono text-xs">
                            {c.customer_code ?? "—"}
                          </TableCell>
                          <TableCell className="font-medium">
                            {c.company_name ?? "—"}
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {c.city ?? "—"}
                          </TableCell>
                          <TableCell>
                            {c.original_agent_code ? (
                              <Badge variant="outline" className="text-muted-foreground">
                                {c.original_agent_code}
                              </Badge>
                            ) : (
                              "—"
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

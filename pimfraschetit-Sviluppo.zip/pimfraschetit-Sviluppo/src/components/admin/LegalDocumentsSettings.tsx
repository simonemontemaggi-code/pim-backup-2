import { useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Upload, ExternalLink, Trash2, FileText, Loader2 } from "lucide-react";
import { maybeOptimizePdf } from "@/lib/maybeOptimizePdf";
import { useConfirm } from "@/components/ui/confirm-dialog";

interface LegalDoc {
  id: string;
  slug: string;
  title: string;
  file_url: string | null;
  file_name: string | null;
  file_size: number | null;
  version: number;
  updated_at: string;
}

const BUCKET = "b2b-communications";
const SLUGS: { slug: string; title: string; description: string }[] = [
  { slug: "condizioni_vendita", title: "Condizioni di Vendita", description: "Condizioni generali di vendita per il portale B2B." },
  { slug: "codice_etico", title: "Codice Etico", description: "Codice etico aziendale." },
  { slug: "privacy_policy", title: "Privacy Policy", description: "Informativa sul trattamento dei dati personali." },
];

const fmtSize = (n: number | null) => {
  if (!n) return "";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
};

function DocRow({ doc, meta }: { doc: LegalDoc | undefined; meta: (typeof SLUGS)[number] }) {
  const qc = useQueryClient();
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const confirm = useConfirm();

  const upload = async (file: File) => {
    if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) {
      toast({ title: "Solo PDF", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const optimized = await maybeOptimizePdf(file);
      const path = `legal/${meta.slug}_${Date.now()}.pdf`;
      const { error: upErr } = await supabase.storage
        .from(BUCKET)
        .upload(path, optimized, { upsert: false, contentType: "application/pdf" });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(path);

      // remove previous file (best effort)
      if (doc?.file_url) {
        const m = doc.file_url.match(new RegExp(`/${BUCKET}/(.+?)(\\?.*)?$`));
        if (m) await supabase.storage.from(BUCKET).remove([m[1]]).catch(() => {});
      }

      const { error: updErr } = await supabase
        .from("b2b_legal_documents")
        .update({
          file_url: pub.publicUrl,
          file_name: file.name,
          file_size: optimized.size,
          version: (doc?.version ?? 0) + 1,
          updated_by: user?.id ?? null,
          updated_at: new Date().toISOString(),
        })
        .eq("slug", meta.slug);
      if (updErr) throw updErr;

      toast({ title: "Documento aggiornato", description: meta.title });
      qc.invalidateQueries({ queryKey: ["b2b_legal_documents"] });
    } catch (e: any) {
      toast({ title: "Errore upload", description: e.message, variant: "destructive" });
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const remove = async () => {
    if (!doc?.file_url) return;
    if (!(await confirm({ title: `Rimuovere "${meta.title}"?`, destructive: true, confirmText: "Rimuovi" }))) return;
    setBusy(true);
    try {
      const m = doc.file_url.match(new RegExp(`/${BUCKET}/(.+?)(\\?.*)?$`));
      if (m) await supabase.storage.from(BUCKET).remove([m[1]]).catch(() => {});
      await supabase
        .from("b2b_legal_documents")
        .update({
          file_url: null,
          file_name: null,
          file_size: null,
          updated_at: new Date().toISOString(),
        })
        .eq("slug", meta.slug);
      toast({ title: "Documento rimosso" });
      qc.invalidateQueries({ queryKey: ["b2b_legal_documents"] });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex items-start gap-3 border rounded-md p-3 bg-background">
      <FileText className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">{meta.title}</span>
          {doc?.file_url ? (
            <Badge variant="secondary" className="text-[10px]">v{doc.version}</Badge>
          ) : (
            <Badge variant="outline" className="text-[10px] text-muted-foreground">Non caricato</Badge>
          )}
        </div>
        <p className="text-xs text-muted-foreground mt-0.5">{meta.description}</p>
        {doc?.file_url && (
          <div className="text-[11px] text-muted-foreground mt-1">
            {doc.file_name} · {fmtSize(doc.file_size)} · aggiornato{" "}
            {new Date(doc.updated_at).toLocaleDateString("it-IT")}
          </div>
        )}
      </div>
      <div className="flex items-center gap-1 shrink-0">
        {doc?.file_url && (
          <Button variant="ghost" size="icon" asChild>
            <a href={doc.file_url} target="_blank" rel="noreferrer" title="Apri PDF">
              <ExternalLink className="h-4 w-4" />
            </a>
          </Button>
        )}
        <Button size="sm" variant="outline" onClick={() => inputRef.current?.click()} disabled={busy}>
          {busy ? <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Upload className="h-3.5 w-3.5 mr-1.5" />}
          {doc?.file_url ? "Sostituisci" : "Carica PDF"}
        </Button>
        {doc?.file_url && (
          <Button variant="ghost" size="icon" onClick={remove} disabled={busy} title="Rimuovi">
            <Trash2 className="h-4 w-4 text-destructive" />
          </Button>
        )}
        <input
          ref={inputRef}
          type="file"
          accept="application/pdf"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])}
        />
      </div>
    </div>
  );
}

export function LegalDocumentsSettings() {
  const { data: docs = [], isLoading } = useQuery({
    queryKey: ["b2b_legal_documents"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("b2b_legal_documents")
        .select("id, slug, title, file_url, file_name, file_size, version, updated_at");
      if (error) throw error;
      return (data ?? []) as LegalDoc[];
    },
  });

  const bySlug = new Map(docs.map((d) => [d.slug, d]));

  return (
    <section className="rounded-lg border bg-card shadow-sm">
      <div className="bg-muted/50 px-4 py-3 border-b rounded-t-lg">
        <h2 className="text-sm font-semibold text-foreground">Documenti Legali B2B</h2>
        <p className="text-xs text-muted-foreground mt-0.5">
          PDF mostrati nel portale B2B (Privacy Policy, Cookie Policy, Termini e Condizioni).
          Ogni sostituzione incrementa la versione. Solo admin possono modificarli.
        </p>
      </div>
      <div className="p-4 space-y-2">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Caricamento...</p>
        ) : (
          SLUGS.map((meta) => <DocRow key={meta.slug} doc={bySlug.get(meta.slug)} meta={meta} />)
        )}
      </div>
    </section>
  );
}

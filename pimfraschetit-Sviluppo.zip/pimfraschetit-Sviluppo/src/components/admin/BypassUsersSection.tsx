import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Trash2, Plus, ShieldCheck } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

type ProfileMatch = {
  user_id: string;
  full_name: string | null;
  email: string | null;
  role?: string | null;
};

export function BypassUsersSection() {
  const qc = useQueryClient();
  const [email, setEmail] = useState("");
  const [note, setNote] = useState("");
  const [pickerMatches, setPickerMatches] = useState<ProfileMatch[] | null>(null);

  const { data: list = [], isLoading } = useQuery({
    queryKey: ["b2b_bypass_users"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("b2b_maintenance_bypass_users")
        .select("id,user_id,email,note,created_at")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const insertBypass = async (user_id: string, target: string) => {
    const { error } = await supabase
      .from("b2b_maintenance_bypass_users")
      .insert({ user_id, email: target, note: note.trim() || null });
    if (error) throw error;
  };

  const addMut = useMutation({
    mutationFn: async () => {
      const target = email.trim().toLowerCase();
      if (!target) throw new Error("Inserisci una email.");

      // 1. Cerca tra i profili staff. Più sotto-utenti possono condividere
      //    la stessa email reparto (es. dispo@fraschetti.com): se >1 → picker.
      const { data: profs, error: pErr } = await supabase
        .from("profiles")
        .select("user_id, full_name, email")
        .eq("email", target);
      if (pErr) throw pErr;

      if ((profs ?? []).length > 1) {
        setPickerMatches(profs as ProfileMatch[]);
        return { picker: true as const };
      }

      let user_id = profs?.[0]?.user_id;

      if (!user_id) {
        // 2. Fallback: cliente B2B (mai sub-user, sempre 1 utente per email).
        const { data: cust } = await supabase
          .from("customers")
          .select("auth_user_id")
          .eq("mail_accesso_cliente", target)
          .maybeSingle();
        user_id = cust?.auth_user_id ?? undefined;
      }

      if (!user_id) throw new Error("Utente non trovato con questa email.");

      await insertBypass(user_id, target);
      return { picker: false as const };
    },
    onSuccess: (res) => {
      if (res?.picker) return; // attende selezione dal dialog
      toast({
        title: "Aggiunto",
        description: `${email} può ora accedere al B2B in manutenzione.`,
      });
      setEmail("");
      setNote("");
      qc.invalidateQueries({ queryKey: ["b2b_bypass_users"] });
    },
    onError: (e: Error) =>
      toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const pickMut = useMutation({
    mutationFn: async (user_id: string) => {
      await insertBypass(user_id, email.trim().toLowerCase());
    },
    onSuccess: () => {
      toast({ title: "Aggiunto", description: `${email} → sotto-utente autorizzato.` });
      setEmail("");
      setNote("");
      setPickerMatches(null);
      qc.invalidateQueries({ queryKey: ["b2b_bypass_users"] });
    },
    onError: (e: Error) =>
      toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const delMut = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("b2b_maintenance_bypass_users")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["b2b_bypass_users"] }),
    onError: (e: Error) =>
      toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  return (
    <section className="rounded-lg border bg-card shadow-sm">
      <div className="bg-muted/50 px-4 py-3 border-b rounded-t-lg">
        <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <ShieldCheck className="h-4 w-4" />
          Accesso B2B durante manutenzione
        </h2>
        <p className="text-xs text-muted-foreground mt-0.5">
          Utenti (inclusi account test cliente) autorizzati a entrare nel portale B2B
          tramite la porta nascosta anche quando è in "Work in Progress". Gli admin sono
          sempre abilitati e non vanno aggiunti qui.
        </p>
      </div>

      <div className="p-4 space-y-4">
        <div className="flex flex-col sm:flex-row gap-2">
          <Input
            placeholder="email@cliente.it"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="sm:flex-1"
          />
          <Input
            placeholder="Nota (opzionale)"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            className="sm:flex-1"
          />
          <Button
            onClick={() => addMut.mutate()}
            disabled={!email || addMut.isPending}
          >
            <Plus className="h-4 w-4 mr-1" />
            Aggiungi
          </Button>
        </div>

        {isLoading ? (
          <p className="text-xs text-muted-foreground">Caricamento…</p>
        ) : list.length === 0 ? (
          <p className="text-xs text-muted-foreground">Nessun utente in whitelist.</p>
        ) : (
          <ul className="divide-y rounded-md border">
            {list.map((u: any) => (
              <li
                key={u.id}
                className="flex items-center justify-between px-3 py-2 text-sm"
              >
                <div className="flex flex-col">
                  <span className="font-medium">{u.email ?? u.user_id}</span>
                  {u.note && (
                    <span className="text-xs text-muted-foreground">{u.note}</span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="text-xs">
                    autorizzato
                  </Badge>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => delMut.mutate(u.id)}
                    disabled={delMut.isPending}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <Dialog
        open={!!pickerMatches}
        onOpenChange={(o) => !o && setPickerMatches(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Più utenti con questa email</DialogTitle>
          </DialogHeader>
          <p className="text-xs text-muted-foreground">
            L'email <span className="font-mono">{email}</span> è condivisa da più
            sotto-utenti reparto. Seleziona quello da autorizzare.
          </p>
          <ul className="divide-y rounded-md border">
            {(pickerMatches ?? []).map((m) => (
              <li
                key={m.user_id}
                className="flex items-center justify-between px-3 py-2 text-sm"
              >
                <div className="flex flex-col">
                  <span className="font-medium">{m.full_name ?? "(senza nome)"}</span>
                  <span className="text-[10px] font-mono text-muted-foreground">
                    {m.user_id}
                  </span>
                </div>
                <Button
                  size="sm"
                  onClick={() => pickMut.mutate(m.user_id)}
                  disabled={pickMut.isPending}
                >
                  Autorizza
                </Button>
              </li>
            ))}
          </ul>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPickerMatches(null)}>
              Annulla
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}

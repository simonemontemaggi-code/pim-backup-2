import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";
import { Search, KeyRound, Users } from "lucide-react";

type Row = {
  id: string;
  sub_user_id: string;
  parent_email: string;
  tech_email: string;
  display_name: string | null;
  is_active: boolean;
  must_change_password: boolean;
  created_at: string;
};

export default function DepartmentSubUsersTab() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [pwdTarget, setPwdTarget] = useState<Row | null>(null);
  const [pwd, setPwd] = useState("");
  const [busy, setBusy] = useState(false);

  const { data: subUsers = [], isLoading } = useQuery({
    queryKey: ["department_sub_users"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("department_sub_users")
        .select("id, sub_user_id, parent_email, tech_email, display_name, is_active, must_change_password, created_at")
        .order("parent_email")
        .order("display_name");
      if (error) throw error;
      return (data ?? []) as Row[];
    },
  });

  const filtered = subUsers.filter((u) => {
    if (!search) return true;
    const s = search.toLowerCase();
    return (
      u.display_name?.toLowerCase().includes(s) ||
      u.parent_email?.toLowerCase().includes(s) ||
      u.tech_email?.toLowerCase().includes(s)
    );
  });

  const toggleActive = async (row: Row) => {
    const { error } = await supabase
      .from("department_sub_users")
      .update({ is_active: !row.is_active } as any)
      .eq("id", row.id);
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      return;
    }
    queryClient.invalidateQueries({ queryKey: ["department_sub_users"] });
  };

  const resetPassword = async () => {
    if (!pwdTarget) return;
    if (pwd.length < 6) {
      toast({ title: "Password troppo corta (min 6)", variant: "destructive" });
      return;
    }
    setBusy(true);
    const { error } = await supabase.functions.invoke("admin-set-user-password", {
      body: { user_id: pwdTarget.sub_user_id, password: pwd },
    });
    if (error) {
      setBusy(false);
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      return;
    }
    // Forza cambio password al prossimo login
    await supabase
      .from("department_sub_users")
      .update({ must_change_password: true } as any)
      .eq("id", pwdTarget.id);
    setBusy(false);
    toast({ title: "Password aggiornata ✅", description: `Comunica: ${pwd}` });
    setPwdTarget(null);
    setPwd("");
    queryClient.invalidateQueries({ queryKey: ["department_sub_users"] });
  };

  if (isLoading) return <Skeleton className="h-64 w-full" />;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            className="pl-8 w-72"
            placeholder="Cerca nome o email…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <p className="text-xs text-muted-foreground">
          Sotto-utenti reparto: condividono l'email reparto ma hanno password personale (gestiti dall'Hub).
        </p>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>Email reparto</TableHead>
            <TableHead>Email tecnica</TableHead>
            <TableHead>Stato</TableHead>
            <TableHead>Azioni</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filtered.length === 0 ? (
            <TableRow>
              <TableCell colSpan={5} className="text-center py-8">
                <Users className="mx-auto h-8 w-8 text-muted-foreground/30 mb-2" />
                <p className="text-sm text-muted-foreground">Nessun sotto-utente trovato</p>
              </TableCell>
            </TableRow>
          ) : (
            filtered.map((u) => (
              <TableRow key={u.id}>
                <TableCell className="font-medium">{u.display_name || "—"}</TableCell>
                <TableCell className="text-sm">{u.parent_email}</TableCell>
                <TableCell className="text-xs text-muted-foreground">{u.tech_email}</TableCell>
                <TableCell>
                  <div className="flex gap-1.5 flex-wrap">
                    <Badge variant={u.is_active ? "default" : "outline"}>
                      {u.is_active ? "Attivo" : "Disattivo"}
                    </Badge>
                    {u.must_change_password && (
                      <Badge variant="secondary">Deve cambiare pwd</Badge>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7"
                      onClick={() => setPwdTarget(u)}
                    >
                      <KeyRound className="h-3 w-3 mr-1" /> Password
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7" onClick={() => toggleActive(u)}>
                      {u.is_active ? "Disattiva" : "Attiva"}
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>

      <Dialog open={!!pwdTarget} onOpenChange={(o) => { if (!o) { setPwdTarget(null); setPwd(""); } }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Imposta password — {pwdTarget?.display_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Nuova password</Label>
              <Input
                type="text"
                placeholder="Min 6 caratteri"
                value={pwd}
                onChange={(e) => setPwd(e.target.value)}
              />
            </div>
            <p className="text-xs text-muted-foreground">
              Il sotto-utente sarà costretto a cambiarla al prossimo login.
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setPwdTarget(null); setPwd(""); }}>Annulla</Button>
            <Button onClick={resetPassword} disabled={busy}>{busy ? "Applico…" : "Applica"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

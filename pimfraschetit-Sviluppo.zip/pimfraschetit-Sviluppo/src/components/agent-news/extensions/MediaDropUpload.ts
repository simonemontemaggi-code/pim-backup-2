import { Extension } from "@tiptap/core";
import { Plugin, PluginKey } from "@tiptap/pm/state";
import { supabase } from "@/integrations/supabase/client";
import { normalizeImageToBlob } from "@/lib/imageNormalize";
import { toast } from "sonner";

export interface MediaDropOptions {
  newsId: string;
}

async function uploadImageFile(file: File, newsId: string): Promise<string> {
  const blob = await normalizeImageToBlob(file, 1600, 900, 0.88);
  const path = `inline/${newsId}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}.jpg`;
  const { error } = await supabase.storage
    .from("news-media")
    .upload(path, blob, { contentType: "image/jpeg", upsert: false });
  if (error) throw error;
  return supabase.storage.from("news-media").getPublicUrl(path).data.publicUrl;
}

async function uploadVideoFile(file: File, newsId: string): Promise<string> {
  const ext = file.name.split(".").pop()?.toLowerCase() || "mp4";
  const path = `inline/${newsId}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}.${ext}`;
  const { error } = await supabase.storage
    .from("news-media")
    .upload(path, file, { contentType: file.type || "video/mp4", upsert: false });
  if (error) throw error;
  return supabase.storage.from("news-media").getPublicUrl(path).data.publicUrl;
}

async function handleFiles(files: File[], newsId: string, insertAt: ((url: string, kind: "image" | "video") => void)) {
  for (const f of files) {
    try {
      if (f.type.startsWith("image/")) {
        const url = await uploadImageFile(f, newsId);
        insertAt(url, "image");
      } else if (f.type.startsWith("video/")) {
        const url = await uploadVideoFile(f, newsId);
        insertAt(url, "video");
      } else {
        toast.error(`File non supportato: ${f.name}`);
      }
    } catch (e: any) {
      toast.error(`Upload fallito: ${e.message}`);
    }
  }
}

export const MediaDropUpload = Extension.create<MediaDropOptions>({
  name: "mediaDropUpload",

  addOptions() {
    return { newsId: "" };
  },

  addProseMirrorPlugins() {
    const newsId = this.options.newsId;
    const editor = this.editor;
    const insertAt = (pos: number) => (url: string, kind: "image" | "video") => {
      const attrs: any = { kind, src: url, wrap: "full", width: 100 };
      if (kind === "video") attrs.provider = "mp4";
      editor
        .chain()
        .focus()
        .insertContentAt(pos, { type: "mediaFigure", attrs })
        .run();
    };

    return [
      new Plugin({
        key: new PluginKey("mediaDropUpload"),
        props: {
          handleDOMEvents: {
            drop: (view, event) => {
              const dt = (event as DragEvent).dataTransfer;
              if (!dt || !dt.files || dt.files.length === 0) return false;
              const files = Array.from(dt.files);
              if (!files.some((f) => f.type.startsWith("image/") || f.type.startsWith("video/"))) return false;
              event.preventDefault();
              const coords = view.posAtCoords({ left: (event as DragEvent).clientX, top: (event as DragEvent).clientY });
              const pos = coords?.pos ?? view.state.selection.from;
              toast.info(`Caricamento ${files.length} file…`);
              handleFiles(files, newsId, insertAt(pos)).then(() => toast.success("Upload completato"));
              return true;
            },
            paste: (view, event) => {
              const cd = (event as ClipboardEvent).clipboardData;
              if (!cd) return false;
              // Se il paste contiene testo/HTML (es. da Word, browser), lascia gestire a TipTap
              // così non perdiamo il contenuto incollato.
              const types = Array.from(cd.types || []);
              const hasText = types.some((t) => t === "text/html" || t === "text/plain" || t === "text/rtf");
              if (hasText) return false;
              const items = cd.items;
              if (!items) return false;
              const files: File[] = [];
              for (const it of Array.from(items)) {
                if (it.kind === "file") {
                  const f = it.getAsFile();
                  if (f && (f.type.startsWith("image/") || f.type.startsWith("video/"))) files.push(f);
                }
              }
              if (files.length === 0) return false;
              event.preventDefault();
              const pos = view.state.selection.from;
              handleFiles(files, newsId, insertAt(pos));
              return true;
            },
          },
        },
      }),
    ];
  },
});

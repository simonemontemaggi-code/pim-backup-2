import { Node, mergeAttributes, type NodeViewProps } from "@tiptap/core";
import { ReactNodeViewRenderer, NodeViewWrapper } from "@tiptap/react";
import { useRef, useState } from "react";
import { AlignLeft, AlignRight, Maximize2, AlignCenter, Trash2, MoveHorizontal } from "lucide-react";
import { toEmbedUrl, detectVideoKind } from "@/lib/imageNormalize";

export type MediaWrap = "left" | "right" | "full" | "inline";
export type MediaKind = "image" | "video";

export interface MediaFigureAttrs {
  kind: MediaKind;
  src: string;
  provider: "mp4" | "youtube" | "vimeo" | null;
  wrap: MediaWrap;
  width: number; // percent 10-100
  caption: string;
  alt: string;
}

declare module "@tiptap/core" {
  interface Commands<ReturnType> {
    mediaFigure: {
      insertMediaFigure: (attrs: Partial<MediaFigureAttrs>) => ReturnType;
    };
  }
}

function MediaFigureView({ node, updateAttributes, deleteNode, selected }: NodeViewProps) {
  const attrs = node.attrs as MediaFigureAttrs;
  const ref = useRef<HTMLDivElement>(null);
  const [resizing, setResizing] = useState(false);

  const onResizeStart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const parent = ref.current?.parentElement;
    const parentW = parent?.getBoundingClientRect().width || 800;
    const startW = (attrs.width / 100) * parentW;
    setResizing(true);
    const onMove = (ev: MouseEvent) => {
      const newW = startW + (ev.clientX - startX);
      const pct = Math.max(10, Math.min(100, Math.round((newW / parentW) * 100)));
      updateAttributes({ width: pct });
    };
    const onUp = () => {
      setResizing(false);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };

  const wrap = attrs.wrap || "full";
  const widthPct = wrap === "full" ? 100 : attrs.width || 50;

  return (
    <NodeViewWrapper
      as="figure"
      data-drag-handle
      className={`news-media news-media--${wrap} ${selected ? "ring-2 ring-primary" : ""} relative group`}
      style={{ width: `${widthPct}%` }}
    >
      <div ref={ref} className="relative">
        {attrs.kind === "image" ? (
          <img src={attrs.src} alt={attrs.alt || ""} className="w-full block rounded" draggable={false} />
        ) : (
          <div className="news-video" data-provider={attrs.provider || ""} data-src={attrs.src}>
            {attrs.provider === "mp4" ? (
              <video src={attrs.src} controls className="w-full" />
            ) : (
              <iframe
                src={toEmbedUrl(attrs.src) || attrs.src}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                title="video"
              />
            )}
          </div>
        )}

        {/* Toolbar contestuale */}
        {selected && (
          <div
            className="absolute -top-9 left-1/2 -translate-x-1/2 flex items-center gap-0.5 bg-background border rounded-md shadow-md px-1 py-1 z-10"
            contentEditable={false}
          >
            <ToolBtn active={wrap === "left"} onClick={() => updateAttributes({ wrap: "left" })} title="Testo a destra (float left)">
              <AlignLeft className="h-3.5 w-3.5" />
            </ToolBtn>
            <ToolBtn active={wrap === "right"} onClick={() => updateAttributes({ wrap: "right" })} title="Testo a sinistra (float right)">
              <AlignRight className="h-3.5 w-3.5" />
            </ToolBtn>
            <ToolBtn active={wrap === "full"} onClick={() => updateAttributes({ wrap: "full" })} title="A tutta riga, va a capo">
              <Maximize2 className="h-3.5 w-3.5" />
            </ToolBtn>
            <ToolBtn active={wrap === "inline"} onClick={() => updateAttributes({ wrap: "inline" })} title="Inline">
              <AlignCenter className="h-3.5 w-3.5" />
            </ToolBtn>
            <span className="w-px h-5 bg-border mx-0.5" />
            {[25, 50, 75, 100].map((w) => (
              <button
                key={w}
                type="button"
                onClick={() => updateAttributes({ width: w })}
                className={`text-[10px] px-1.5 py-0.5 rounded ${attrs.width === w ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}
                title={`${w}%`}
              >
                {w}%
              </button>
            ))}
            <span className="w-px h-5 bg-border mx-0.5" />
            <ToolBtn onClick={() => deleteNode()} title="Rimuovi">
              <Trash2 className="h-3.5 w-3.5 text-destructive" />
            </ToolBtn>
          </div>
        )}

        {/* Resize handle */}
        {selected && wrap !== "full" && (
          <div
            onMouseDown={onResizeStart}
            contentEditable={false}
            className={`absolute bottom-1 right-1 w-4 h-4 bg-primary border-2 border-background rounded cursor-se-resize z-10 ${resizing ? "scale-110" : ""}`}
            title="Trascina per ridimensionare"
          >
            <MoveHorizontal className="h-3 w-3 text-primary-foreground" />
          </div>
        )}
      </div>

      {/* Caption editabile */}
      <figcaption
        contentEditable={false}
        className="text-xs text-muted-foreground italic text-center mt-1"
      >
        <input
          type="text"
          value={attrs.caption || ""}
          onChange={(e) => updateAttributes({ caption: e.target.value })}
          placeholder="Aggiungi didascalia (opzionale)…"
          className="w-full bg-transparent text-center outline-none border-b border-dashed border-transparent focus:border-border placeholder:text-muted-foreground/60"
        />
      </figcaption>
    </NodeViewWrapper>
  );
}

function ToolBtn({ active, onClick, children, title }: any) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      className={`h-7 w-7 rounded inline-flex items-center justify-center ${active ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}
    >
      {children}
    </button>
  );
}

export const MediaFigure = Node.create({
  name: "mediaFigure",
  group: "block",
  atom: true,
  draggable: true,
  selectable: true,

  addAttributes() {
    return {
      kind: { default: "image" },
      src: { default: "" },
      provider: { default: null },
      wrap: { default: "full" },
      width: { default: 100 },
      caption: { default: "" },
      alt: { default: "" },
    };
  },

  parseHTML() {
    return [
      {
        tag: "figure.news-media",
        getAttrs: (el) => {
          const node = el as HTMLElement;
          const img = node.querySelector("img");
          const video = node.querySelector(".news-video") as HTMLElement | null;
          const cap = node.querySelector("figcaption");
          const classList = node.className.split(/\s+/);
          let wrap: MediaWrap = "full";
          if (classList.includes("news-media--left")) wrap = "left";
          else if (classList.includes("news-media--right")) wrap = "right";
          else if (classList.includes("news-media--inline")) wrap = "inline";
          const widthStr = (node.style.width || "").replace("%", "");
          const width = Number(widthStr) || 100;
          if (img) {
            return {
              kind: "image",
              src: img.getAttribute("src") || "",
              alt: img.getAttribute("alt") || "",
              provider: null,
              wrap,
              width,
              caption: cap?.textContent?.trim() || "",
            };
          }
          if (video) {
            const provider = (video.getAttribute("data-provider") as any) || null;
            const src = video.getAttribute("data-src") || video.querySelector("iframe,video")?.getAttribute("src") || "";
            return {
              kind: "video",
              src,
              provider,
              wrap,
              width,
              caption: cap?.textContent?.trim() || "",
              alt: "",
            };
          }
          return false;
        },
      },
    ];
  },

  renderHTML({ node }) {
    const a = node.attrs as MediaFigureAttrs;
    const wrap = a.wrap || "full";
    const widthPct = wrap === "full" ? 100 : a.width || 100;
    const figureAttrs = mergeAttributes(
      {
        class: `news-media news-media--${wrap}`,
        style: `width:${widthPct}%`,
      },
    );
    const children: any[] = [];
    if (a.kind === "image") {
      children.push(["img", { src: a.src, alt: a.alt || "" }]);
    } else {
      const provider = a.provider || detectVideoKind(a.src) || "";
      const videoAttrs = { class: "news-video", "data-provider": provider, "data-src": a.src };
      if (provider === "mp4") {
        children.push(["div", videoAttrs, ["video", { src: a.src, controls: "true" }]]);
      } else {
        const embed = toEmbedUrl(a.src) || a.src;
        children.push([
          "div",
          videoAttrs,
          ["iframe", { src: embed, allowfullscreen: "true", frameborder: "0", allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" }],
        ]);
      }
    }
    if (a.caption) children.push(["figcaption", {}, a.caption]);
    return ["figure", figureAttrs, ...children];
  },

  addNodeView() {
    return ReactNodeViewRenderer(MediaFigureView);
  },

  addCommands() {
    return {
      insertMediaFigure:
        (attrs) =>
        ({ commands }) =>
          commands.insertContent({
            type: this.name,
            attrs: {
              kind: "image",
              wrap: "full",
              width: 100,
              caption: "",
              alt: "",
              provider: null,
              src: "",
              ...attrs,
            },
          }),
    };
  },
});

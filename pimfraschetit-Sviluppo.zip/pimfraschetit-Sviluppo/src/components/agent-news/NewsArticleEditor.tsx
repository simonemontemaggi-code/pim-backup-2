import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Image from "@tiptap/extension-image";
import Link from "@tiptap/extension-link";
import TextAlign from "@tiptap/extension-text-align";
import Underline from "@tiptap/extension-underline";
import { Color } from "@tiptap/extension-color";
import { TextStyle } from "@tiptap/extension-text-style";
import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Bold, Italic, UnderlineIcon, Strikethrough, List, ListOrdered,
  AlignLeft, AlignCenter, AlignRight, Link as LinkIcon, Image as ImageIcon,
  Heading1, Heading2, Undo, Redo, Palette, Video, Upload,
} from "lucide-react";
import { usePrompt } from "@/components/ui/confirm-dialog";
import { MediaFigure } from "./extensions/MediaFigure";
import { MediaDropUpload } from "./extensions/MediaDropUpload";
import { supabase } from "@/integrations/supabase/client";
import { normalizeImageToBlob, detectVideoKind } from "@/lib/imageNormalize";

const TEXT_COLORS = [
  "#000000", "#374151", "#6b7280", "#9ca3af",
  "#dc2626", "#ea580c", "#d97706", "#ca8a04",
  "#16a34a", "#059669", "#0891b2", "#2563eb",
  "#4f46e5", "#7c3aed", "#c026d3", "#db2777",
];

interface Props {
  value: string;
  onChange: (html: string) => void;
  newsId: string;
}

export function NewsArticleEditor({ value, onChange, newsId }: Props) {
  const promptDialog = usePrompt();
  const fileRef = useRef<HTMLInputElement>(null);
  const [videoOpen, setVideoOpen] = useState(false);
  const [videoUrl, setVideoUrl] = useState("");

  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: { levels: [1, 2, 3], HTMLAttributes: { class: "tiptap-heading" } },
        bulletList: { HTMLAttributes: { class: "list-disc pl-6" } },
        orderedList: { HTMLAttributes: { class: "list-decimal pl-6" } },
      }),
      Underline,
      TextStyle,
      Color,
      Image.configure({ inline: false, HTMLAttributes: { class: "max-w-full rounded my-2" } }),
      Link.configure({ openOnClick: false, HTMLAttributes: { class: "text-primary underline" } }),
      TextAlign.configure({ types: ["heading", "paragraph"] }),
      MediaFigure,
      MediaDropUpload.configure({ newsId }),
    ],
    content: value || "",
    onUpdate: ({ editor }) => onChange(editor.getHTML()),
    editorProps: {
      attributes: {
        class: "news-article prose prose-sm max-w-none min-h-[400px] p-4 focus:outline-none",
      },
    },
  });

  if (!editor) return null;

  const uploadAndInsertImage = async (file: File) => {
    try {
      const blob = await normalizeImageToBlob(file, 1600, 900, 0.88);
      const path = `inline/${newsId}-${Date.now()}.jpg`;
      const { error } = await supabase.storage
        .from("news-media")
        .upload(path, blob, { contentType: "image/jpeg", upsert: false });
      if (error) throw error;
      const url = supabase.storage.from("news-media").getPublicUrl(path).data.publicUrl;
      editor.chain().focus().insertMediaFigure({ kind: "image", src: url, wrap: "full", width: 100 }).run();
    } catch (e: any) {
      toast.error(`Upload immagine fallito: ${e.message}`);
    }
  };

  const insertVideoFromUrl = () => {
    const url = videoUrl.trim();
    if (!url) return;
    const kind = detectVideoKind(url);
    if (!kind) {
      toast.error("URL non riconosciuto (YouTube / Vimeo / .mp4)");
      return;
    }
    editor.chain().focus().insertMediaFigure({
      kind: "video",
      src: url,
      provider: kind,
      wrap: "full",
      width: 100,
    }).run();
    setVideoUrl("");
    setVideoOpen(false);
  };

  const setLink = async () => {
    const url = await promptDialog({
      title: "Inserisci link",
      description: "URL del link (lascia vuoto per rimuovere)",
      defaultValue: editor.getAttributes("link").href || "https://",
      placeholder: "https://…",
    });
    if (url === null) return;
    if (url === "") {
      editor.chain().focus().unsetLink().run();
      return;
    }
    editor.chain().focus().extendMarkRange("link").setLink({ href: url }).run();
  };

  const currentColor = editor.getAttributes("textStyle").color || "#000000";

  const Btn = ({ active, onClick, children, title }: any) => (
    <Button
      type="button"
      size="sm"
      variant={active ? "default" : "ghost"}
      onClick={onClick}
      title={title}
      className="h-8 w-8 p-0"
    >
      {children}
    </Button>
  );

  return (
    <div className="border rounded-md bg-background">
      <div className="flex flex-wrap items-center gap-1 border-b p-2 bg-muted/30 sticky top-0 z-20">
        <Btn title="Grassetto" active={editor.isActive("bold")} onClick={() => editor.chain().focus().toggleBold().run()}><Bold className="h-4 w-4" /></Btn>
        <Btn title="Corsivo" active={editor.isActive("italic")} onClick={() => editor.chain().focus().toggleItalic().run()}><Italic className="h-4 w-4" /></Btn>
        <Btn title="Sottolineato" active={editor.isActive("underline")} onClick={() => editor.chain().focus().toggleUnderline().run()}><UnderlineIcon className="h-4 w-4" /></Btn>
        <Btn title="Barrato" active={editor.isActive("strike")} onClick={() => editor.chain().focus().toggleStrike().run()}><Strikethrough className="h-4 w-4" /></Btn>
        <div className="w-px h-6 bg-border mx-1" />
        <Btn title="Titolo 1" active={editor.isActive("heading", { level: 1 })} onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}><Heading1 className="h-4 w-4" /></Btn>
        <Btn title="Titolo 2" active={editor.isActive("heading", { level: 2 })} onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}><Heading2 className="h-4 w-4" /></Btn>
        <div className="w-px h-6 bg-border mx-1" />
        <Btn title="Lista puntata" active={editor.isActive("bulletList")} onClick={() => editor.chain().focus().toggleBulletList().run()}><List className="h-4 w-4" /></Btn>
        <Btn title="Lista numerata" active={editor.isActive("orderedList")} onClick={() => editor.chain().focus().toggleOrderedList().run()}><ListOrdered className="h-4 w-4" /></Btn>
        <div className="w-px h-6 bg-border mx-1" />
        <Btn title="Allinea a sinistra" active={editor.isActive({ textAlign: "left" })} onClick={() => editor.chain().focus().setTextAlign("left").run()}><AlignLeft className="h-4 w-4" /></Btn>
        <Btn title="Centra" active={editor.isActive({ textAlign: "center" })} onClick={() => editor.chain().focus().setTextAlign("center").run()}><AlignCenter className="h-4 w-4" /></Btn>
        <Btn title="Allinea a destra" active={editor.isActive({ textAlign: "right" })} onClick={() => editor.chain().focus().setTextAlign("right").run()}><AlignRight className="h-4 w-4" /></Btn>
        <div className="w-px h-6 bg-border mx-1" />
        <Popover>
          <PopoverTrigger asChild>
            <Button type="button" size="sm" variant="ghost" title="Colore testo" className="h-8 w-8 p-0 relative">
              <Palette className="h-4 w-4" />
              <span className="absolute bottom-1 left-1 right-1 h-0.5 rounded" style={{ backgroundColor: currentColor }} />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-2" align="start">
            <div className="grid grid-cols-8 gap-1">
              {TEXT_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => editor.chain().focus().setColor(c).run()}
                  className="h-6 w-6 rounded border border-border hover:scale-110 transition-transform"
                  style={{ backgroundColor: c }}
                  title={c}
                />
              ))}
            </div>
            <div className="flex items-center gap-2 mt-2 pt-2 border-t">
              <input
                type="color"
                value={currentColor}
                onChange={(e) => editor.chain().focus().setColor(e.target.value).run()}
                className="h-7 w-10 cursor-pointer rounded border"
              />
              <button
                type="button"
                onClick={() => editor.chain().focus().unsetColor().run()}
                className="text-xs text-muted-foreground hover:text-foreground"
              >
                Rimuovi colore
              </button>
            </div>
          </PopoverContent>
        </Popover>
        <Btn title="Inserisci link" active={editor.isActive("link")} onClick={setLink}><LinkIcon className="h-4 w-4" /></Btn>
        <div className="w-px h-6 bg-border mx-1" />
        <Btn title="Carica immagine" onClick={() => fileRef.current?.click()}>
          <ImageIcon className="h-4 w-4" />
        </Btn>
        <Popover open={videoOpen} onOpenChange={setVideoOpen}>
          <PopoverTrigger asChild>
            <Button type="button" size="sm" variant="ghost" title="Inserisci video" className="h-8 w-8 p-0">
              <Video className="h-4 w-4" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80" align="start">
            <div className="space-y-2">
              <Label className="text-xs">URL video (YouTube, Vimeo, .mp4)</Label>
              <Input
                value={videoUrl}
                onChange={(e) => setVideoUrl(e.target.value)}
                placeholder="https://www.youtube.com/watch?v=…"
                onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); insertVideoFromUrl(); } }}
              />
              <Button size="sm" onClick={insertVideoFromUrl} className="w-full">Inserisci</Button>
              <p className="text-[11px] text-muted-foreground">
                Per video locali, trascina il file .mp4 direttamente nell'editor.
              </p>
            </div>
          </PopoverContent>
        </Popover>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) uploadAndInsertImage(f);
            e.target.value = "";
          }}
        />
        <div className="w-px h-6 bg-border mx-1" />
        <Btn title="Annulla" onClick={() => editor.chain().focus().undo().run()}><Undo className="h-4 w-4" /></Btn>
        <Btn title="Ripristina" onClick={() => editor.chain().focus().redo().run()}><Redo className="h-4 w-4" /></Btn>
      </div>
      <div className="px-2 py-1 bg-muted/10 border-b text-[11px] text-muted-foreground flex items-center gap-2">
        <Upload className="h-3 w-3" />
        Trascina immagini o video direttamente nel testo. Clicca su un media per ridimensionarlo o cambiarne l'allineamento.
      </div>
      <EditorContent editor={editor} />
    </div>
  );
}

import {
  LayoutDashboard, Package, Truck,
  Image, RefreshCw, ArrowUpDown, Shield, HelpCircle, Activity,
  Sparkles, Layers, GalleryHorizontal, Megaphone, ShieldAlert, Boxes, Star, BookOpen, Tags, Users2, UserCheck, ShoppingCart, BarChart3, Bell, Receipt, PackageX, LineChart, MessageSquare, FileBarChart,
} from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { usePermissions } from "@/lib/permissions";
import { useSidebarNotifications } from "@/hooks/useSidebarNotifications";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent,
  SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem,
  SidebarFooter, useSidebar,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import type { SectionKey } from "@/contexts/AuthContext";

type NavItem = { title: string; url: string; icon: any; section?: SectionKey };
type NavGroup = { label: string | null; items: NavItem[] };

const navGroups: NavGroup[] = [
  {
    label: null,
    items: [
      { title: "Dashboard", url: "/pim", icon: LayoutDashboard, section: "pim_dashboard" },
    ],
  },
  {
    label: "Catalogo",
    items: [
      { title: "Articoli", url: "/pim/articles", icon: Package, section: "articles_registry" },
      { title: "Fornitori", url: "/pim/suppliers", icon: Truck, section: "suppliers" },
      { title: "Promo Strutturate", url: "/pim/promo-strutturate", icon: Tags, section: "promo_strutturate" },
      { title: "Media", url: "/pim/media", icon: Image, section: "media_library" },
    ],
  },
  {
    label: "Anagrafiche",
    items: [
      { title: "Clienti", url: "/pim/customers", icon: Users2, section: "customers" },
      { title: "Agenti", url: "/pim/agents", icon: UserCheck, section: "agents" },
    ],
  },
  {
    label: "Vendite",
    items: [
      { title: "Dashboard", url: "/pim/sales", icon: BarChart3, section: "sales_dashboard" },
      { title: "Ordini", url: "/pim/sales/orders", icon: ShoppingCart, section: "sales_orders" },
      { title: "Ordini non Trattati", url: "/pim/sales/untreated", icon: PackageX, section: "sales_untreated" },
      { title: "Controllo Ordini Promo", url: "/pim/sales/promo-control", icon: Tags, section: "sales_promo_control" },
    ],
  },
  {
    label: "Marketing B2B",
    items: [
      { title: "Brand", url: "/pim/b2b/brands", icon: Sparkles, section: "b2b_brands" },
      { title: "Settori / Reparti / Gamme", url: "/pim/b2b/taxonomy", icon: Layers, section: "b2b_taxonomy" },
      { title: "Slider Homepage", url: "/pim/b2b/hero-slider", icon: GalleryHorizontal, section: "b2b_hero_slider" },
      { title: "Promo Settori", url: "/pim/b2b/promos", icon: Megaphone, section: "b2b_promo_settori" },
      { title: "Assortimenti", url: "/pim/b2b/assortments", icon: Boxes, section: "b2b_assortments" },
      { title: "Novità", url: "/pim/b2b/novita", icon: Star, section: "b2b_novita" },
      { title: "Cataloghi", url: "/pim/b2b/catalogs", icon: BookOpen, section: "b2b_catalogs" },
      { title: "Ordine Promo B2B", url: "/pim/b2b/promo-order", icon: Tags, section: "b2b_promo_order" },
      { title: "Comunicazioni Portale", url: "/pim/b2b/communications", icon: Bell, section: "b2b_communications" },
      { title: "News", url: "/pim/agent-news", icon: Bell, section: "agent_news" },
      { title: "Ticket", url: "/pim/b2b/tickets", icon: MessageSquare, section: "b2b_tickets_ordini" },
    ],
  },
  {
    label: "Analytics",
    items: [
      { title: "Navigation Analysis", url: "/pim/navigation-analysis", icon: LineChart, section: "navigation_analysis" },
      { title: "Adozione Portale", url: "/pim/analytics/adozione-portale", icon: LineChart, section: "portal_adoption" },
    ],
  },
  {
    label: "Operazioni",
    items: [
      { title: "Sync AS400", url: "/pim/sync", icon: RefreshCw, section: "as400_sync" },
      { title: "Import/Export", url: "/pim/import", icon: ArrowUpDown, section: "import_export" },
      { title: "Controlli", url: "/pim/controls", icon: Activity, section: "operations_controls" },
    ],
  },
  {
    label: "Amministrazione",
    items: [
      { title: "Scadenziario Agenti", url: "/pim/scadenziario", icon: Receipt, section: "scadenziario" },
      { title: "Report", url: "/pim/reports", icon: FileBarChart, section: "admin_reports" },
    ],
  },
  {
    label: "Impostazioni",
    items: [
      { title: "Impostazioni", url: "/pim/admin/users", icon: Shield, section: "users_admin" },
    ],
  },
];

interface Props {
  onOpenShortcuts?: () => void;
}

export function PimSidebar({ onOpenShortcuts }: Props) {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const { sectionVisible } = usePermissions();
  const { data: notif } = useSidebarNotifications();

  const notifCountFor = (section?: SectionKey): number => {
    if (!section || !notif) return 0;
    if (section === "customers") return notif.customer_requests;
    if (section === "sales_untreated") return notif.sales_untreated;
    if (section === "sales_orders") return notif.sales_orders;
    if (section === "scadenziario") return notif.scadenziario_incassi;
    if (section === "b2b_tickets_ordini") return (notif as any).b2b_tickets ?? 0;
    return 0;
  };

  const TICKET_SECTIONS: SectionKey[] = [
    "b2b_tickets_ordini", "b2b_tickets_contabile", "b2b_tickets_tecnico",
    "b2b_tickets_commerciale", "b2b_tickets_annullamento",
    "b2b_tickets_post_vendita", "b2b_tickets_portale", "b2b_tickets_altro",
  ];

  const isItemVisible = (section?: SectionKey) => {
    if (!section) return true;
    if (section === "sales_untreated") {
      return sectionVisible("sales_untreated") || sectionVisible("purchases_untreated");
    }
    if (section === "b2b_tickets_ordini") {
      return TICKET_SECTIONS.some((s) => sectionVisible(s));
    }
    return sectionVisible(section);
  };

  const visibleGroups = navGroups
    .map((g) => ({
      ...g,
      items: g.items.filter((it) => isItemVisible(it.section)),
    }))
    .filter((g) => g.items.length > 0);

  return (
    <Sidebar collapsible="icon">
      <SidebarContent>
        {visibleGroups.map((group, idx) => (
          <SidebarGroup key={group.label ?? `group-${idx}`}>
            {!collapsed && group.label && (
              <SidebarGroupLabel className="text-sidebar-foreground/60 text-xs uppercase tracking-wider px-3 mb-2">
                {group.label}
              </SidebarGroupLabel>
            )}
            <SidebarGroupContent>
              <SidebarMenu>
                {group.items.map((item) => {
                  const count = notifCountFor(item.section);
                  return (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton asChild>
                      <NavLink
                        to={item.url}
                        end={item.url === "/pim" || item.url === "/pim/sales"}
                        className="hover:bg-sidebar-accent/50"
                        activeClassName="bg-sidebar-accent text-sidebar-primary font-medium"
                      >
                        <span className="relative inline-flex shrink-0">
                          <item.icon className="mr-2 h-4 w-4" />
                          {count > 0 && collapsed && (
                            <span className="absolute -top-1 -right-0 h-2 w-2 rounded-full bg-destructive ring-2 ring-sidebar" />
                          )}
                        </span>
                        {!collapsed && <span className="flex-1">{item.title}</span>}
                        {!collapsed && count > 0 && (
                          <span
                            className="ml-auto inline-flex items-center gap-1 text-[10px] font-semibold text-destructive"
                            title={`${count} nuovi`}
                          >
                            <span className="h-2 w-2 rounded-full bg-destructive" />
                            {count > 99 ? "99+" : count}
                          </span>
                        )}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>
      <SidebarFooter>
        <Button
          variant="ghost"
          size={collapsed ? "icon" : "sm"}
          className="w-full justify-start text-muted-foreground hover:text-foreground"
          onClick={onOpenShortcuts}
        >
          <HelpCircle className="h-4 w-4 shrink-0" />
          {!collapsed && <span className="ml-2 text-xs">Scorciatoie (?)</span>}
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}

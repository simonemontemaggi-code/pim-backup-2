import { useState, KeyboardEvent } from "react";
import { useNavigate } from "react-router-dom";
import { LogOut, Search } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { SidebarTrigger } from "@/components/ui/sidebar";

export function PimHeader() {
  const { profile, role, departmentName, signOut } = useAuth();
  const navigate = useNavigate();
  const [search, setSearch] = useState("");

  const handleSearchKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && search.trim()) {
      navigate(`/pim/articles?search=${encodeURIComponent(search.trim())}`);
    }
  };

  return (
    <header className="h-12 flex items-center justify-between border-b px-4 bg-card">
      <div className="flex items-center gap-2">
        <SidebarTrigger className="mr-1" />
        <div className="relative w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            className="pl-8 h-8 text-sm"
            placeholder="Cerca articolo... (Invio)"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={handleSearchKeyDown}
          />
        </div>
      </div>
      <div className="flex items-center gap-3">
        {departmentName && (
          <Badge variant="secondary" className="text-xs font-normal">{departmentName}</Badge>
        )}
        {role && (
          <Badge variant="outline" className="text-xs font-normal capitalize">{role}</Badge>
        )}
        <span className="text-sm text-muted-foreground">{profile?.full_name}</span>
        <Button variant="ghost" size="icon" onClick={signOut} title="Esci">
          <LogOut className="h-4 w-4" />
        </Button>
      </div>
    </header>
  );
}

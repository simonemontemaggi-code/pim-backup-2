import { Outlet } from "react-router-dom";
import { SidebarProvider } from "@/components/ui/sidebar";
import { PimSidebar } from "./PimSidebar";
import { PimHeader } from "./PimHeader";
import { ShortcutsHelp } from "./ShortcutsHelp";
import { useHotkeys } from "@/hooks/useHotkeys";

export function AppShell() {
  const { shortcutsHelpOpen, setShortcutsHelpOpen } = useHotkeys();

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <PimSidebar onOpenShortcuts={() => setShortcutsHelpOpen(true)} />
        <div className="flex-1 flex flex-col min-w-0">
          <PimHeader />
          <main className="flex-1 overflow-auto">
            <Outlet />
          </main>
        </div>
      </div>
      <ShortcutsHelp open={shortcutsHelpOpen} onOpenChange={setShortcutsHelpOpen} />
    </SidebarProvider>
  );
}

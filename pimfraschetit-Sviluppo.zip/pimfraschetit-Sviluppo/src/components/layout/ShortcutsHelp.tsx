import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const SHORTCUTS = [
  { keys: "Ctrl + N", action: "Nuovo articolo" },
  { keys: "Ctrl + F", action: "Cerca articoli" },
  { keys: "Ctrl + S", action: "Salva form corrente" },
  { keys: "Ctrl + Shift + S", action: "Coda sincronizzazione AS400" },
  { keys: "Ctrl + Shift + I", action: "Import CSV" },
  { keys: "Ctrl + Shift + M", action: "Media library" },
  { keys: "Escape", action: "Chiudi pannello / modal" },
  { keys: "?", action: "Mostra questa guida" },
];

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ShortcutsHelp({ open, onOpenChange }: Props) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Scorciatoie da tastiera</DialogTitle>
        </DialogHeader>
        <div className="space-y-1">
          {SHORTCUTS.map((s) => (
            <div
              key={s.keys}
              className="flex items-center justify-between py-2 px-1 border-b last:border-0"
            >
              <span className="text-sm text-muted-foreground">{s.action}</span>
              <kbd className="inline-flex items-center rounded border bg-muted px-2 py-0.5 text-xs font-mono font-medium text-muted-foreground">
                {s.keys}
              </kbd>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}

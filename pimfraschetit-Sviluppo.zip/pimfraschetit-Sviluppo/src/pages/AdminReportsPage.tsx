import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/lib/permissions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { Plus, Search, FileBarChart, GripVertical, Trash2 } from "lucide-react";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

interface ReportRow {
  id: string;
  ref_id: number;
  title: string;
  description: string | null;
  date_start: string | null;
  date_end: string | null;
  sort_order: number;
  audience: string;
  hidden: boolean;
}

function statusOf(r: ReportRow): { label: string; variant: "default" | "secondary" | "outline" } {
  if (r.hidden) return { label: "Sospeso", variant: "secondary" };
  const today = new Date().toISOString().slice(0, 10);
  if (r.date_start && r.date_start > today) return { label: "Programmato", variant: "outline" };
  if (r.date_end && r.date_end < today) return { label: "Scaduto", variant: "outline" };
  return { label: "Attivo", variant: "default" };
}

function SortableReportRow({
  r,
  draggable,
  canWrite,
  onOpen,
  onDelete,
}: {
  r: ReportRow;
  draggable: boolean;
  canWrite: boolean;
  onOpen: () => void;
  onDelete: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: r.id,
    disabled: !draggable,
  });
  const st = statusOf(r);

  return (
    <TableRow
      ref={setNodeRef}
      style={{
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.6 : 1,
      }}
      className="cursor-pointer"
      onClick={onOpen}
    >
      <TableCell className="w-10" onClick={(e) => e.stopPropagation()}>
        {draggable && (
          <button
            {...attributes}
            {...listeners}
            className="cursor-grab active:cursor-grabbing touch-none text-muted-foreground"
            aria-label="Riordina"
          >
            <GripVertical className="h-4 w-4" />
          </button>
        )}
      </TableCell>
      <TableCell className="font-mono text-xs">{r.ref_id}</TableCell>
      <TableCell className="font-medium">{r.title}</TableCell>
      <TableCell>{r.audience === "customer" ? "Clienti" : "Agenti"}</TableCell>
      <TableCell className="text-xs text-muted-foreground">
        {r.date_start ?? "—"} → {r.date_end ?? "—"}
      </TableCell>
      <TableCell><Badge variant={st.variant}>{st.label}</Badge></TableCell>
      <TableCell className="w-12 text-right" onClick={(e) => e.stopPropagation()}>
        {canWrite && (
          <Button variant="ghost" size="icon" onClick={onDelete} aria-label="Elimina report">
            <Trash2 className="h-4 w-4 text-destructive" />
          </Button>
        )}
      </TableCell>
    </TableRow>
  );
}

export default function AdminReportsPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const confirm = useConfirm();
  const { can } = usePermissions();
  const canWrite = can("write", "admin_reports");
  const [search, setSearch] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [draft, setDraft] = useState({ title: "", audience: "agent" });
  const [items, setItems] = useState<ReportRow[]>([]);

  const { data: reports = [], isLoading } = useQuery({
    queryKey: ["admin_reports"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("reports")
        .select("id,ref_id,title,description,date_start,date_end,sort_order,audience,hidden")
        .order("sort_order", { ascending: false })
        .order("ref_id", { ascending: false });
      if (error) throw error;
      return (data ?? []) as ReportRow[];
    },
  });

  useEffect(() => {
    setItems(reports);
  }, [reports]);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  const create = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase
        .from("reports")
        .insert({ title: draft.title.trim(), audience: draft.audience })
        .select("id")
        .single();
      if (error) throw error;
      return data.id as string;
    },
    onSuccess: (id) => {
      qc.invalidateQueries({ queryKey: ["admin_reports"] });
      setCreateOpen(false);
      setDraft({ title: "", audience: "agent" });
      navigate(`/pim/reports/${id}`);
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const persistOrder = useMutation({
    mutationFn: async (ordered: ReportRow[]) => {
      const total = ordered.length;
      const updates = ordered
        .map((r, i) => ({ id: r.id, sort_order: total - 1 - i, prev: r.sort_order }))
        .filter((u) => u.sort_order !== u.prev);
      for (const u of updates) {
        const { error } = await supabase.from("reports").update({ sort_order: u.sort_order }).eq("id", u.id);
        if (error) throw error;
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin_reports"] }),
    onError: (e: Error) => {
      setItems(reports);
      toast({ title: "Ordine non salvato", description: e.message, variant: "destructive" });
    },
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("reports").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Report eliminato" });
      qc.invalidateQueries({ queryKey: ["admin_reports"] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const q = search.trim().toLowerCase();
  const filtered = q
    ? items.filter((r) => r.title.toLowerCase().includes(q) || String(r.ref_id).includes(q))
    : items;
  const draggable = canWrite && !q;

  const handleDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const oldIdx = items.findIndex((r) => r.id === active.id);
    const newIdx = items.findIndex((r) => r.id === over.id);
    if (oldIdx < 0 || newIdx < 0) return;
    const next = arrayMove(items, oldIdx, newIdx);
    setItems(next);
    persistOrder.mutate(next);
  };

  const handleDelete = async (r: ReportRow) => {
    const ok = await confirm({
      title: "Eliminare il report?",
      description: `"${r.title}" verrà eliminato insieme alle sue colonne e a tutte le righe dati. L'operazione non è reversibile.`,
      confirmText: "Elimina",
      destructive: true,
    });
    if (ok) remove.mutate(r.id);
  };

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold flex items-center gap-2">
            <FileBarChart className="h-5 w-5" /> Report
          </h1>
          <p className="text-sm text-muted-foreground">
            Tabelle pubblicate ad agenti e clienti, con periodo di validità e regole di visibilità.
          </p>
        </div>
        {canWrite && (
          <Button onClick={() => setCreateOpen(true)}>
            <Plus className="h-4 w-4 mr-2" /> Nuovo report
          </Button>
        )}
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Cerca per titolo o ID..."
          className="pl-8"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {canWrite && (
        <p className="text-xs text-muted-foreground">
          {q
            ? "Azzera la ricerca per riordinare i report."
            : "Trascina le righe per cambiare l'ordine di pubblicazione (il primo in alto viene mostrato per primo)."}
        </p>
      )}

      <Card>
        <CardContent className="p-0">
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10" />
                  <TableHead className="w-20">ID</TableHead>
                  <TableHead>Titolo</TableHead>
                  <TableHead className="w-32">Destinatari</TableHead>
                  <TableHead className="w-48">Periodo</TableHead>
                  <TableHead className="w-28">Stato</TableHead>
                  <TableHead className="w-12" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading && (
                  <TableRow><TableCell colSpan={7} className="text-muted-foreground">Caricamento...</TableCell></TableRow>
                )}
                {!isLoading && filtered.length === 0 && (
                  <TableRow><TableCell colSpan={7} className="text-muted-foreground">Nessun report</TableCell></TableRow>
                )}
                <SortableContext items={filtered.map((r) => r.id)} strategy={verticalListSortingStrategy}>
                  {filtered.map((r) => (
                    <SortableReportRow
                      key={r.id}
                      r={r}
                      draggable={draggable}
                      canWrite={canWrite}
                      onOpen={() => navigate(`/pim/reports/${r.id}`)}
                      onDelete={() => handleDelete(r)}
                    />
                  ))}
                </SortableContext>
              </TableBody>
            </Table>
          </DndContext>
        </CardContent>
      </Card>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Nuovo report</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Titolo</Label>
              <Input value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Destinatari</Label>
              <Select value={draft.audience} onValueChange={(v) => setDraft({ ...draft, audience: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="agent">Agenti</SelectItem>
                  <SelectItem value="customer">Clienti</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>Annulla</Button>
            <Button disabled={!draft.title.trim() || create.isPending} onClick={() => create.mutate()}>
              Crea
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

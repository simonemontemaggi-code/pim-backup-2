import { useMemo, useRef, useState } from "react";
import { BadgePercent, Upload, Trash2, X, Download, ArrowUp, ArrowDown, ArrowUpDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { OrderDetailDialog } from "@/components/sales/promo-control/OrderDetailDialog";
import {
  useScontoFatturaPromos,
  usePromoTemi,
  usePromoTemaArticoli,
  usePromoTemaScaglioni,
} from "@/hooks/usePromoScontoFattura";

import { parseOrderTxt, type ParsedOrder as ParsedOrderT, type ParsedOrderLine, type ParsedOrderNote } from "@/lib/orderTxtParser";

export type OrderLine = ParsedOrderLine;
export type OrderNote = ParsedOrderNote;
export type ParsedOrder = ParsedOrderT;

type Origine = "PIM" | "VDC";

type ParsedFile = {
  id: string;
  fileName: string;
  origine: Origine;
  scaricoLabel: string;
  scaricoSortKey: string;
  orders: ParsedOrder[];
  customers: Map<string, { company_name: string | null; zone_code: string | null }>;
  warnings: string[];
};

type FlatRow = {
  fileId: string;
  fileName: string;
  origine: Origine;
  scaricoLabel: string;
  scaricoSortKey: string;
  order: ParsedOrder;
  customer: { company_name: string | null; zone_code: string | null } | undefined;
  effectiveTotal: number;
};

type GroupedRow = {
  custCode: string;
  customer: { company_name: string | null; zone_code: string | null } | undefined;
  rows: FlatRow[];
  totalValue: number;
  scaricoLabel: string;
  scaricoSortKey: string;
  origineLabel: string; // "PIM" | "VDC" | "MISTA"
  origineMixed: boolean;
  firstOrderNumber: string;
};

const currency = new Intl.NumberFormat("it-IT", {
  style: "currency",
  currency: "EUR",
});

function parseScaricoFromName(name: string) {
  const m = name.match(/(\d{2})-(\d{2})-(\d{4}).*ORE[_ ]?(\d{1,2})/i);
  if (!m) return { label: name, sortKey: "0" };
  const [, dd, mm, yyyy, hh] = m;
  return {
    label: `${hh.padStart(2, "0")}:00 - ${dd}/${mm}/${yyyy}`,
    sortKey: `${yyyy}${mm}${dd}${hh.padStart(2, "0")}`,
  };
}

function detectOrigine(name: string): Origine {
  return /pim/i.test(name) ? "PIM" : "VDC";
}


export default function SalesPromoControlPage() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<ParsedFile[]>([]);
  const [articleMap, setArticleMap] = useState<Map<string, { descrizione: string | null }>>(new Map());
  // Prezzo listino fallback (chiave: `${cdls}|${cdpar}`) → prezzo lordo listino
  const [priceMap, setPriceMap] = useState<Map<string, number>>(new Map());
  // Cliente → cdls (price_list_code)
  const [custCdlsMap, setCustCdlsMap] = useState<Map<string, string | null>>(new Map());
  const [loading, setLoading] = useState(false);
  const [pendingFiles, setPendingFiles] = useState<File[] | null>(null);
  type SortKey = "scarico" | "origine" | "order" | "value" | "cust" | "zone" | "code" | "offer" | "scaglioneNum";
  const [sortBy, setSortBy] = useState<{ key: SortKey; dir: "asc" | "desc" } | null>(null);
  const [openOrder, setOpenOrder] = useState<{
    order: ParsedOrder;
    scaricoLabel: string;
    customer?: { company_name: string | null; zone_code: string | null };
    fromPicker?: GroupedRow;
  } | null>(null);
  const [pickerGroup, setPickerGroup] = useState<GroupedRow | null>(null);

  // Promo selection
  const [selectedPromoId, setSelectedPromoId] = useState<string | null>(null);
  const [selectedTemaIds, setSelectedTemaIds] = useState<string[]>([]);

  const { data: promos = [] } = useScontoFatturaPromos();
  const selectedPromo = useMemo(() => promos.find((p) => p.id === selectedPromoId) ?? null, [promos, selectedPromoId]);
  const { data: temi = [] } = usePromoTemi(selectedPromo?.wpprgf ?? null);
  const { data: temaArticoli = [] } = usePromoTemaArticoli(selectedTemaIds);
  const { data: temaScaglioni = [] } = usePromoTemaScaglioni(selectedTemaIds);

  const promoCdparSet = useMemo(() => {
    const s = new Set<string>();
    for (const ta of temaArticoli) s.add(ta.cdpar);
    return s;
  }, [temaArticoli]);

  // Map (tema_id → Map<cdpar, {master_pack, imballo_vendita, variabile}>)
  const artInfoByTema = useMemo(() => {
    const m = new Map<string, Map<string, { mp: number | null; iv: number | null; var_: boolean }>>();
    for (const ta of temaArticoli) {
      if (!m.has(ta.tema_id)) m.set(ta.tema_id, new Map());
      m.get(ta.tema_id)!.set(ta.cdpar, {
        mp: ta.master_pack ?? null,
        iv: ta.imballo_vendita ?? null,
        var_: !!ta.variabile,
      });
    }
    return m;
  }, [temaArticoli]);

  const hasPromoFilter = selectedPromoId !== null && selectedTemaIds.length > 0;

  function computePromoLines(lines: OrderLine[], custCode: string): { value: number; scaglione: string; pct: number } {
    if (!hasPromoFilter) return { value: 0, scaglione: "—", pct: -1 };
    const cdls = custCdlsMap.get(custCode) ?? null;
    const effLine = (l: OrderLine) => {
      let effPrice = l.price;
      if ((!l.price || l.price === 0) && cdls) {
        const lp = priceMap.get(`${cdls}|${l.cdpar}`);
        if (lp && lp > 0) effPrice = lp / 2;
      }
      const effValue = (effPrice && effPrice > 0) ? l.qty * effPrice : l.value;
      return { effPrice, effValue };
    };

    let totalValue = 0;
    let totalQty = 0;
    let totalRighe = 0;
    for (const l of lines) {
      if (promoCdparSet.has(l.cdpar)) {
        const { effValue } = effLine(l);
        totalValue += effValue;
        totalQty += l.qty;
        totalRighe += 1;
      }
    }

    let bestLabel = "—";
    let bestPct = -1;

    // --- BANCALE: valutazione per riga (indipendente), soglia = master_pack ---
    for (const t of temi as any[]) {
      if (!selectedTemaIds.includes(t.id)) continue;
      if (t.tipo !== "bancale") continue;
      const pct = Number(t.sconto_pct ?? 0);
      if (!(pct > 0)) continue;
      const infoMap = artInfoByTema.get(t.id);
      if (!infoMap) continue;
      let bancaleValue = 0;
      let bancaleLines = 0;
      for (const l of lines) {
        const info = infoMap.get(l.cdpar);
        if (!info) continue;
        const mp = info.mp;
        if (!mp || mp <= 0) continue; // articolo senza master pack → non applicabile
        if (l.qty < mp) continue;
        const { effValue } = effLine(l);
        bancaleValue += effValue;
        bancaleLines += 1;
      }
      if (bancaleLines > 0 && pct > bestPct) {
        bestPct = pct;
        bestLabel = `Bancale (−${pct}%) · ${bancaleLines} rig${bancaleLines === 1 ? "a" : "he"}`;
      }
    }

    // --- Scaglioni classici (qty / eur / righe) ---
    for (const t of temi) {
      if (!selectedTemaIds.includes(t.id)) continue;
      if ((t as any).tipo === "bancale") continue;
      const scs = temaScaglioni.filter((s) => s.tema_id === t.id);
      if (scs.length === 0) continue;

      // qty riferita a questo tema: se scaglioni_qty in "confezioni",
      // divisore per riga = imballo_vendita (wimba); se variabile=SI il divisore è 1.
      let qtyForTema = totalQty;
      if ((t as any).tipo === "scaglioni_qty" && (t as any).scaglioni_qty_unit === "confezioni") {
        const infoMap = artInfoByTema.get(t.id);
        qtyForTema = 0;
        if (infoMap) {
          for (const l of lines) {
            const info = infoMap.get(l.cdpar);
            if (!info) continue;
            const div = info.var_ ? 1 : (info.iv && info.iv > 0 ? info.iv : null);
            if (!div) continue;
            qtyForTema += Math.floor(l.qty / div);
          }
        }
      }

      let localBest: { pct: number; idx: number } | null = null;
      scs.forEach((sc, idx) => {
        const okQty = sc.soglia_qty == null || qtyForTema >= sc.soglia_qty;
        const okEur = sc.soglia_eur == null || totalValue >= Number(sc.soglia_eur);
        const okRighe = sc.soglia_righe == null || totalRighe >= sc.soglia_righe;
        if (okQty && okEur && okRighe) {
          if (!localBest || (sc.sconto_pct ?? 0) > localBest.pct) {
            localBest = { pct: Number(sc.sconto_pct ?? 0), idx: idx + 1 };
          }
        }
      });
      if (localBest && localBest.pct > bestPct) {
        bestPct = localBest.pct;
        bestLabel = `Scaglione ${localBest.idx} (−${localBest.pct}%)`;
      }
    }
    return { value: totalValue, scaglione: bestLabel, pct: bestPct };
  }

  const computePromo = (order: ParsedOrder) => computePromoLines(order.lines, order.custCode);
  function computePromoForGroup(g: GroupedRow) {
    const merged: OrderLine[] = [];
    for (const r of g.rows) merged.push(...r.order.lines);
    return computePromoLines(merged, g.custCode);
  }


  function onInputChange(fileList: FileList | null) {
    if (!fileList || fileList.length === 0) return;
    const arr = Array.from(fileList);
    if (files.length === 0) {
      void handleFiles(arr, "append");
    } else {
      setPendingFiles(arr);
    }
  }

  function cancelPending() {
    setPendingFiles(null);
    if (inputRef.current) inputRef.current.value = "";
  }

  async function handleFiles(fileArr: File[], mode: "append" | "replace") {
    if (!fileArr || fileArr.length === 0) return;
    setLoading(true);
    try {
      const parsed: ParsedFile[] = [];
      const allCustCodes = new Set<string>();
      const perFile: { file: File; parsed: ReturnType<typeof parseOrderTxt> }[] = [];

      for (const file of fileArr) {
        const content = await file.text();
        const p = parseOrderTxt(content);
        p.custCodes.forEach((c) => allCustCodes.add(c));
        perFile.push({ file, parsed: p });
      }

      const custMap = new Map<string, { company_name: string | null; zone_code: string | null; price_list_code: string | null }>();
      if (allCustCodes.size > 0) {
        const { data, error } = await supabase
          .from("customers")
          .select("customer_code, company_name, zone_code, price_list_code")
          .in("customer_code", Array.from(allCustCodes));
        if (error) {
          toast.error(`Errore lookup clienti: ${error.message}`);
        } else {
          for (const row of data ?? []) {
            custMap.set(row.customer_code, {
              company_name: row.company_name ?? null,
              zone_code: row.zone_code ?? null,
              price_list_code: (row as any).price_list_code ?? null,
            });
          }
        }
      }

      // Fetch descrizioni articolo AS400 (colonna `depar`; cdpar è CHAR(15) padded)
      const allCdpars = new Set<string>();
      for (const { parsed: p } of perFile) {
        for (const o of p.orders) for (const l of o.lines) if (l.cdpar) allCdpars.add(l.cdpar);
      }
      const artMap = new Map<string, { descrizione: string | null }>();
      if (allCdpars.size > 0) {
        const cdparArr = Array.from(allCdpars);
        const paddedToRaw = new Map<string, string>();
        const paddedArr = cdparArr.map((c) => {
          const padded = c.padEnd(15, " ");
          paddedToRaw.set(padded, c);
          return padded;
        });
        const CHUNK = 500;
        for (let i = 0; i < paddedArr.length; i += CHUNK) {
          const chunk = paddedArr.slice(i, i + CHUNK);
          const { data, error } = await supabase
            .from("archivio_articoli_fraschetti")
            .select("cdpar, depar")
            .in("cdpar", chunk);
          if (error) {
            toast.error(`Errore lookup articoli: ${error.message}`);
            break;
          }
          for (const row of data ?? []) {
            const rawKey = paddedToRaw.get((row as any).cdpar) ?? String((row as any).cdpar).trim();
            const depar = (row as any).depar;
            artMap.set(rawKey, {
              descrizione: depar ? String(depar).trim() : null,
            });
          }
        }
      }

      // Fetch prezzi di listino per cliente (fallback quando riga ordine ha prezzo 0)
      // Raggruppa cdpar per cdls (price_list_code)
      const cdparsPerCdls = new Map<string, Set<string>>();
      for (const { parsed: p } of perFile) {
        for (const o of p.orders) {
          const cust = custMap.get(o.custCode);
          const cdls = cust?.price_list_code;
          if (!cdls) continue;
          let set = cdparsPerCdls.get(cdls);
          if (!set) {
            set = new Set<string>();
            cdparsPerCdls.set(cdls, set);
          }
          for (const l of o.lines) if (l.cdpar) set.add(l.cdpar);
        }
      }
      const priceMapLocal = new Map<string, number>();
      for (const [cdls, cdparSet] of cdparsPerCdls) {
        const cdparArr = Array.from(cdparSet);
        const CHUNK = 500;
        for (let i = 0; i < cdparArr.length; i += CHUNK) {
          const chunk = cdparArr.slice(i, i + CHUNK);
          const { data, error } = await supabase.rpc("pim_prezzo_listino_batch", {
            _cdpars: chunk,
            _cdls: cdls,
          });
          if (error) {
            toast.error(`Errore lookup prezzi listino (${cdls}): ${error.message}`);
            break;
          }
          for (const row of (data ?? []) as { cdpar: string; prezzo: number | null }[]) {
            if (row.prezzo != null) {
              priceMapLocal.set(`${cdls}|${String(row.cdpar).trim()}`, Number(row.prezzo));
            }
          }
        }
      }
      const custCdlsLocal = new Map<string, string | null>();
      for (const [code, c] of custMap) custCdlsLocal.set(code, c.price_list_code);


      let totOrders = 0;
      let totSkipped = 0;
      const emptyFiles: string[] = [];
      for (const { file, parsed: p } of perFile) {
        const { label, sortKey } = parseScaricoFromName(file.name);
        totOrders += p.orders.length;
        totSkipped += p.stats.skipped;
        if (p.orders.length === 0) emptyFiles.push(file.name);
        parsed.push({
          id: `${file.name}-${Date.now()}-${Math.random()}`,
          fileName: file.name,
          origine: detectOrigine(file.name),
          scaricoLabel: label,
          scaricoSortKey: sortKey,
          orders: p.orders,
          customers: new Map(
            p.custCodes.map((c) => [c, custMap.get(c) ?? { company_name: null, zone_code: null }]),
          ),
          warnings: p.warnings,
        });
      }

      if (mode === "replace") {
        setFiles(parsed);
        setArticleMap(artMap);
        setPriceMap(priceMapLocal);
        setCustCdlsMap(custCdlsLocal);
      } else {
        setFiles((prev) => [...prev, ...parsed]);
        setArticleMap((prev) => {
          const merged = new Map(prev);
          for (const [k, v] of artMap) merged.set(k, v);
          return merged;
        });
        setPriceMap((prev) => {
          const merged = new Map(prev);
          for (const [k, v] of priceMapLocal) merged.set(k, v);
          return merged;
        });
        setCustCdlsMap((prev) => {
          const merged = new Map(prev);
          for (const [k, v] of custCdlsLocal) merged.set(k, v);
          return merged;
        });
      }

      const skipMsg = totSkipped > 0 ? ` • ${totSkipped} righe scartate` : "";
      toast.success(
        `${parsed.length} file • ${totOrders} ordini${skipMsg}`,
      );
      for (const name of emptyFiles) {
        toast.warning(`Nessun ordine valido in "${name}" — controlla il formato`);
      }

    } catch (e: any) {
      toast.error(`Errore parsing: ${e?.message ?? e}`);
    } finally {
      setLoading(false);
      setPendingFiles(null);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  function removeFile(id: string) {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  }

  function clearAll() {
    setFiles([]);
  }

  // Flatten all files into a single list of rows
  const allRows: FlatRow[] = useMemo(() => {
    const rows: FlatRow[] = [];
    for (const f of files) {
      for (const o of f.orders) {
        const customer = f.customers.get(o.custCode);
        const cdls = custCdlsMap.get(o.custCode) ?? null;
        let effectiveTotal = 0;
        for (const l of o.lines) {
          let effPrice = l.price;
          if ((!l.price || l.price === 0) && cdls) {
            const lp = priceMap.get(`${cdls}|${l.cdpar}`);
            if (lp && lp > 0) effPrice = lp / 2;
          }
          effectiveTotal += (effPrice && effPrice > 0) ? l.qty * effPrice : l.value;
        }
        rows.push({
          fileId: f.id,
          fileName: f.fileName,
          origine: f.origine,
          scaricoLabel: f.scaricoLabel,
          scaricoSortKey: f.scaricoSortKey,
          order: o,
          customer,
          effectiveTotal,
        });
      }
    }
    return rows;
  }, [files, custCdlsMap, priceMap]);


  // Group rows by customer code
  const groupedRows: GroupedRow[] = useMemo(() => {
    const map = new Map<string, GroupedRow>();
    for (const r of allRows) {
      let g = map.get(r.order.custCode);
      if (!g) {
        g = {
          custCode: r.order.custCode,
          customer: r.customer,
          rows: [],
          totalValue: 0,
          scaricoLabel: r.scaricoLabel,
          scaricoSortKey: r.scaricoSortKey,
          origineLabel: r.origine,
          origineMixed: false,
          firstOrderNumber: r.order.orderNumber,
        };
        map.set(r.order.custCode, g);
      }
      g.rows.push(r);
      g.totalValue += r.effectiveTotal;
      if (r.scaricoSortKey !== g.scaricoSortKey) {
        g.scaricoLabel = "Vari";
        // keep the max sort key so "Vari" groups sort near their latest scarico
        if (r.scaricoSortKey > g.scaricoSortKey) g.scaricoSortKey = r.scaricoSortKey;
      }
      if (r.origine !== g.origineLabel && !g.origineMixed) {
        g.origineLabel = "MISTA";
        g.origineMixed = true;
      }
      if (r.order.orderNumber < g.firstOrderNumber) g.firstOrderNumber = r.order.orderNumber;
    }
    return Array.from(map.values());
  }, [allRows]);

  const sortedRows = useMemo(() => {
    if (!sortBy) return groupedRows;
    const arr = [...groupedRows];
    arr.sort((a, b) => {
      let cmp = 0;
      switch (sortBy.key) {
        case "scarico":
          cmp = a.scaricoSortKey.localeCompare(b.scaricoSortKey);
          break;
        case "origine":
          cmp = a.origineLabel.localeCompare(b.origineLabel);
          break;
        case "order":
          cmp = a.firstOrderNumber.localeCompare(b.firstOrderNumber);
          break;
        case "value":
          cmp = a.totalValue - b.totalValue;
          break;
        case "cust":
          cmp = (a.customer?.company_name ?? "").localeCompare(b.customer?.company_name ?? "", "it", { sensitivity: "base" });
          break;
        case "zone":
          cmp = (a.customer?.zone_code ?? "").localeCompare(b.customer?.zone_code ?? "");
          break;
        case "code":
          cmp = a.custCode.localeCompare(b.custCode);
          break;
        case "offer":
          cmp = computePromoForGroup(a).value - computePromoForGroup(b).value;
          break;
        case "scaglioneNum":
          cmp = computePromoForGroup(a).pct - computePromoForGroup(b).pct;
          break;
      }
      return sortBy.dir === "asc" ? cmp : -cmp;
    });
    return arr;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [groupedRows, sortBy, hasPromoFilter, promoCdparSet, temi, temaScaglioni, selectedTemaIds]);

  function toggleSort(key: SortKey) {
    setSortBy((prev) => {
      if (!prev || prev.key !== key) return { key, dir: "asc" };
      if (prev.dir === "asc") return { key, dir: "desc" };
      return null;
    });
  }

  function SortIcon({ k }: { k: SortKey }) {
    if (!sortBy || sortBy.key !== k) return <ArrowUpDown className="h-3 w-3 inline ml-1 opacity-40" />;
    return sortBy.dir === "asc"
      ? <ArrowUp className="h-3 w-3 inline ml-1" />
      : <ArrowDown className="h-3 w-3 inline ml-1" />;
  }

  const totalGlobal = useMemo(
    () => allRows.reduce((sum, r) => sum + r.effectiveTotal, 0),
    [allRows],
  );


  function openGroup(g: GroupedRow) {
    if (g.rows.length === 1) {
      const r = g.rows[0];
      setOpenOrder({ order: r.order, scaricoLabel: r.scaricoLabel, customer: r.customer });
    } else {
      setPickerGroup(g);
    }
  }

  function exportCsv() {
    const header = ["Scarico ore", "Origine", "Cod zona", "Cod cli", "Ragione sociale", "# ordini", "Numeri ordine", "Valore ordine"];
    if (hasPromoFilter) header.push("Valore offerta", "Scaglione");
    const rows = [
      header,
      ...sortedRows.map((g) => {
        const nums = g.rows.map((r) => r.order.orderNumber).join("|");
        const base = [
          g.scaricoLabel,
          g.origineLabel,
          g.customer?.zone_code ?? "",
          g.custCode,
          g.customer?.company_name ?? "",
          String(g.rows.length),
          nums,
          g.totalValue.toFixed(2).replace(".", ","),
        ];
        if (hasPromoFilter) {
          const p = computePromoForGroup(g);
          base.push(p.value.toFixed(2).replace(".", ","), p.scaglione);
        }
        return base;
      }),
    ];
    const csv = rows.map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(";")).join("\n");
    const blob = new Blob([`\ufeff${csv}`], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ordini_controllo_promo.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function toggleTema(id: string) {
    setSelectedTemaIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  const temiLabel =
    selectedTemaIds.length === 0
      ? "Seleziona offerte…"
      : `${selectedTemaIds.length} offert${selectedTemaIds.length === 1 ? "a" : "e"} selezionat${selectedTemaIds.length === 1 ? "a" : "e"}`;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <BadgePercent className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-semibold">Controllo Ordini Promo</h1>
      </div>

      {/* Upload */}
      <div className="rounded-lg border bg-card p-4 space-y-3">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <h2 className="font-medium">Carica file TXT ordini</h2>
            <p className="text-sm text-muted-foreground">
              Puoi caricare più file (PIM o VDC) insieme. Il tag Origine è dedotto dal nome del file.
            </p>
          </div>
          <div className="flex gap-2">
            <input
              ref={inputRef}
              type="file"
              accept=".txt,text/plain"
              multiple
              className="hidden"
              onChange={(e) => onInputChange(e.target.files)}
            />
            <Button onClick={() => inputRef.current?.click()} disabled={loading}>
              <Upload className="h-4 w-4 mr-2" />
              {loading ? "Caricamento…" : "Carica TXT"}
            </Button>
            {files.length > 0 && (
              <Button variant="outline" onClick={clearAll}>
                <Trash2 className="h-4 w-4 mr-2" />
                Svuota tutto
              </Button>
            )}
          </div>
        </div>

        {files.length > 0 && (
          <div className="flex flex-wrap gap-2 pt-2 border-t">
            {files
              .slice()
              .sort((a, b) => b.scaricoSortKey.localeCompare(a.scaricoSortKey))
              .map((f) => (
                <div key={f.id} className="flex items-center gap-2 rounded border bg-muted/30 px-2 py-1 text-xs">
                  <Badge variant={f.origine === "PIM" ? "default" : "secondary"}>{f.origine}</Badge>
                  <span className="font-medium">{f.scaricoLabel}</span>
                  <span className="text-muted-foreground">({f.orders.length} ord.)</span>
                  <button
                    onClick={() => removeFile(f.id)}
                    className="text-muted-foreground hover:text-destructive"
                    aria-label="Rimuovi file"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
          </div>
        )}
      </div>

      {/* Promo filter */}
      <div className="rounded-lg border bg-card p-4 space-y-3">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex-1 min-w-[280px]">
            <label className="text-xs font-medium text-muted-foreground uppercase mb-1 block">
              Promo con "Offerta Sconto Fattura"
            </label>
            <Select
              value={selectedPromoId ?? ""}
              onValueChange={(v) => {
                setSelectedPromoId(v || null);
                setSelectedTemaIds([]);
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder={promos.length === 0 ? "Nessuna promo flaggata" : "Seleziona promo…"} />
              </SelectTrigger>
              <SelectContent>
                {promos.map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.wptpbd?.trim() || p.wpcca?.trim() || `#${p.wpprgf}`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex-1 min-w-[280px]">
            <label className="text-xs font-medium text-muted-foreground uppercase mb-1 block">
              Offerte della promo
            </label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-between"
                  disabled={!selectedPromoId || temi.length === 0}
                >
                  <span className="truncate">{temiLabel}</span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[360px] p-2 max-h-[320px] overflow-y-auto" align="start">
                {temi.length === 0 ? (
                  <div className="text-sm text-muted-foreground p-2">Questa promo non ha offerte configurate.</div>
                ) : (
                  <div className="space-y-1">
                    {temi.map((t) => {
                      const checked = selectedTemaIds.includes(t.id);
                      return (
                        <label
                          key={t.id}
                          className="flex items-start gap-2 p-2 rounded hover:bg-muted cursor-pointer"
                        >
                          <Checkbox checked={checked} onCheckedChange={() => toggleTema(t.id)} />
                          <div className="flex-1">
                            <div className="text-sm font-medium">{t.nome ?? "(senza nome)"}</div>
                            {t.descrizione && (
                              <div className="text-xs text-muted-foreground">{t.descrizione}</div>
                            )}
                            {t.tipo && (
                              <div className="text-[10px] uppercase text-muted-foreground mt-0.5">{t.tipo}</div>
                            )}
                          </div>
                        </label>
                      );
                    })}
                  </div>
                )}
              </PopoverContent>
            </Popover>
          </div>

          {hasPromoFilter && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setSelectedPromoId(null);
                setSelectedTemaIds([]);
              }}
            >
              <X className="h-4 w-4 mr-1" /> Reset
            </Button>
          )}
        </div>
      </div>

      {files.length === 0 ? (
        <div className="rounded-lg border border-dashed p-12 text-center text-muted-foreground">
          Nessun file caricato. Usa "Carica TXT" per iniziare.
        </div>
      ) : (
        <div className="rounded-lg border bg-card">
          <div className="flex items-center justify-between gap-3 p-4 border-b flex-wrap">
            <div className="text-sm text-muted-foreground">
              {files.length} file • {allRows.length} ordini • {groupedRows.length} clienti • Totale{" "}
              <span className="font-semibold text-foreground">{currency.format(totalGlobal)}</span>
            </div>
            <Button size="sm" variant="outline" onClick={exportCsv}>
              <Download className="h-4 w-4 mr-2" />
              Esporta CSV
            </Button>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="cursor-pointer select-none" onClick={() => toggleSort("scarico")}>
                  Scarico ore<SortIcon k="scarico" />
                </TableHead>
                <TableHead className="cursor-pointer select-none" onClick={() => toggleSort("origine")}>
                  Origine<SortIcon k="origine" />
                </TableHead>
                <TableHead className="cursor-pointer select-none" onClick={() => toggleSort("zone")}>
                  Cod zona<SortIcon k="zone" />
                </TableHead>
                <TableHead className="cursor-pointer select-none" onClick={() => toggleSort("code")}>
                  Cod cli<SortIcon k="code" />
                </TableHead>
                <TableHead className="cursor-pointer select-none" onClick={() => toggleSort("cust")}>
                  Ragione sociale<SortIcon k="cust" />
                </TableHead>
                <TableHead className="cursor-pointer select-none" onClick={() => toggleSort("order")}>
                  Numero ordine<SortIcon k="order" />
                </TableHead>
                <TableHead
                  className="text-right cursor-pointer select-none"
                  onClick={() => toggleSort("value")}
                >
                  Valore ordine<SortIcon k="value" />
                </TableHead>
                {hasPromoFilter && (
                  <>
                    <TableHead
                      className="text-right cursor-pointer select-none"
                      onClick={() => toggleSort("offer")}
                    >
                      Valore offerta<SortIcon k="offer" />
                    </TableHead>
                    <TableHead className="cursor-pointer select-none" onClick={() => toggleSort("scaglioneNum")}>
                      Scaglione<SortIcon k="scaglioneNum" />
                    </TableHead>
                  </>
                )}
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedRows.map((g) => {
                const promo = hasPromoFilter ? computePromoForGroup(g) : null;
                const count = g.rows.length;
                return (
                  <TableRow
                    key={g.custCode}
                    className="cursor-pointer hover:bg-muted/50"
                    onClick={() => openGroup(g)}
                  >
                    <TableCell className="whitespace-nowrap">
                      {g.scaricoLabel === "Vari" ? (
                        <span className="italic text-muted-foreground">Vari</span>
                      ) : (
                        g.scaricoLabel
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant={g.origineMixed ? "outline" : g.origineLabel === "PIM" ? "default" : "secondary"}>
                        {g.origineLabel}
                      </Badge>
                    </TableCell>
                    <TableCell>{g.customer?.zone_code ?? "—"}</TableCell>
                    <TableCell className="font-mono">{g.custCode}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span>
                          {g.customer?.company_name ?? (
                            <span className="text-muted-foreground">— non trovato —</span>
                          )}
                        </span>
                        {count > 1 && (
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-5 font-semibold border-primary/40 text-primary">
                            ×{count}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-muted-foreground">
                      {count === 1 ? g.rows[0].order.orderNumber : (
                        <span>{g.firstOrderNumber} <span className="text-xs">+{count - 1}</span></span>
                      )}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {currency.format(g.totalValue)}
                    </TableCell>
                    {hasPromoFilter && promo && (
                      <>
                        <TableCell className="text-right font-medium">
                          {promo.value > 0 ? (
                            currency.format(promo.value)
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </TableCell>
                        <TableCell className="text-sm">{promo.scaglione}</TableCell>
                      </>
                    )}
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}

      <AlertDialog open={pendingFiles !== null} onOpenChange={(o) => !o && cancelPending()}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cosa vuoi fare con {pendingFiles?.length ?? 0} file?</AlertDialogTitle>
            <AlertDialogDescription>
              Hai già {files.length} file in lista. Vuoi aggiungere i nuovi a quelli esistenti o
              sovrascrivere completamente la lista?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={cancelPending}>Annulla</AlertDialogCancel>
            <Button
              variant="outline"
              onClick={() => {
                const p = pendingFiles;
                setPendingFiles(null);
                if (p) void handleFiles(p, "append");
              }}
            >
              Aggiungi alla lista
            </Button>
            <AlertDialogAction
              onClick={() => {
                const p = pendingFiles;
                setPendingFiles(null);
                if (p) void handleFiles(p, "replace");
              }}
            >
              Sovrascrivi lista
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={pickerGroup !== null} onOpenChange={(o) => !o && setPickerGroup(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              Ordini di {pickerGroup?.customer?.company_name ?? pickerGroup?.custCode}
              {pickerGroup && (
                <span className="ml-2 text-sm font-normal text-muted-foreground">
                  {pickerGroup.rows.length} ordini · Totale {currency.format(pickerGroup.totalValue)}
                </span>
              )}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-1 max-h-[420px] overflow-y-auto">
            {pickerGroup?.rows.map((r) => (
              <button
                key={`${r.fileId}-${r.order.orderNumber}`}
                onClick={() => {
                  const g = pickerGroup;
                  setPickerGroup(null);
                  setOpenOrder({
                    order: r.order,
                    scaricoLabel: r.scaricoLabel,
                    customer: r.customer,
                    fromPicker: g ?? undefined,
                  });
                }}
                className="w-full flex items-center gap-3 p-2 rounded border hover:bg-muted text-left text-sm"
              >
                <span className="whitespace-nowrap text-xs text-muted-foreground w-32">{r.scaricoLabel}</span>
                <Badge variant={r.origine === "PIM" ? "default" : "secondary"}>{r.origine}</Badge>
                <span className="font-mono text-xs text-muted-foreground flex-1">{r.order.orderNumber}</span>
                <span className="font-medium">{currency.format(r.effectiveTotal)}</span>
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      <OrderDetailDialog
        open={openOrder !== null}
        onOpenChange={(o) => {
          if (!o) {
            const back = openOrder?.fromPicker;
            setOpenOrder(null);
            if (back) setPickerGroup(back);
          }
        }}
        order={openOrder?.order ?? null}
        scaricoLabel={openOrder?.scaricoLabel ?? ""}
        customer={openOrder?.customer}
        promoCdparSet={hasPromoFilter ? promoCdparSet : null}
        articleMap={articleMap}
        priceMap={priceMap}
        custCdls={openOrder ? custCdlsMap.get(openOrder.order.custCode) ?? null : null}
      />
    </div>
  );
}

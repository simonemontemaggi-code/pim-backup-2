import { useState, useCallback, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ChevronLeft, ChevronRight, Save, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ArticleDetail } from "@/components/articles/ArticleDetail";
import { useAdjacentArticles } from "@/hooks/useAdjacentArticles";
import { useArticle } from "@/hooks/useArticles";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useOnlineAssortments, computeIsB2bOnline } from "@/hooks/useOnlineAssortments";
import { toast } from "@/hooks/use-toast";

export default function ArticleDetailPage() {
  const { cdpar } = useParams<{ cdpar: string }>();
  const navigate = useNavigate();
  const decoded = cdpar ? decodeURIComponent(cdpar) : "";
  const { data: adjacent } = useAdjacentArticles(decoded || undefined);
  const { data: article } = useArticle(decoded);
  const { data: onlineAssortments = [] } = useOnlineAssortments();
  const [isDirty, setIsDirty] = useState(false);
  const [isPending, setIsPending] = useState(false);
  const [hasErrors, setHasErrors] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [justSaved, setJustSaved] = useState(false);
  const prevDirty = useRef(isDirty);

  const handleDirtyChange = useCallback((dirty: boolean, pending: boolean, errs?: boolean, errMap?: Record<string, string>) => {
    setIsDirty(dirty);
    setIsPending(pending);
    setHasErrors(!!errs);
    setErrors(errMap ?? {});
  }, []);

  // Detect transition from dirty to clean (= save completed)
  useEffect(() => {
    if (prevDirty.current && !isDirty && !isPending) {
      setJustSaved(true);
      const t = setTimeout(() => setJustSaved(false), 2000);
      return () => clearTimeout(t);
    }
    prevDirty.current = isDirty;
  }, [isDirty, isPending]);

  const triggerSave = () => document.dispatchEvent(new Event("pim:save"));

  const scrollToField = (name: string) => {
    const el = document.querySelector<HTMLElement>(`[name="${CSS.escape(name)}"]`);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      (el as HTMLInputElement).focus?.();
    } else {
      toast({ title: "Campo non trovato in vista", description: name, variant: "destructive" });
    }
  };

  if (!cdpar) return null;

  const goTo = (code: string) => navigate(`/pim/articles/${encodeURIComponent(code)}`);

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2 min-w-0">
          <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" onClick={() => navigate(-1)}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-xl font-bold font-mono shrink-0">{decoded}</h1>
          {(article?.depar || article?.wdeag) && (
            <span className="text-sm text-muted-foreground truncate">
              {[article.depar, article.wdeag].filter(Boolean).join("")}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {article && (
            ((article as any).b2b_online_effective ?? computeIsB2bOnline((article as any).b2b_online_active, (article as any).wfuas, onlineAssortments)) ? (
              <Badge className="text-xs bg-green-600 hover:bg-green-600">🛒 Online B2B</Badge>
            ) : (
              <Badge className="text-xs bg-red-600 hover:bg-red-600 text-white">⊘ Offline B2B</Badge>
            )
          )}
          {justSaved && (
            <Badge variant="outline" className="text-xs text-green-600 border-green-500 animate-in fade-in">
              ✓ Salvato
            </Badge>
          )}
          {isDirty && (
            <Badge variant="outline" className="text-xs text-destructive border-destructive">
              Modificato
            </Badge>
          )}
          {hasErrors && (
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="h-8 text-destructive border-destructive hover:bg-destructive/10">
                  <AlertCircle className="h-3.5 w-3.5 mr-1" />
                  {Object.keys(errors).length} error{Object.keys(errors).length === 1 ? "e" : "i"}
                </Button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-96 p-0">
                <div className="px-3 py-2 border-b text-xs font-semibold">Campi da correggere</div>
                <ul className="max-h-72 overflow-y-auto divide-y">
                  {Object.entries(errors).map(([name, msg]) => (
                    <li key={name}>
                      <button
                        type="button"
                        onClick={() => scrollToField(name)}
                        className="w-full text-left px-3 py-2 hover:bg-muted text-xs"
                      >
                        <div className="font-mono font-semibold">{name}</div>
                        <div className="text-destructive">{msg}</div>
                      </button>
                    </li>
                  ))}
                </ul>
              </PopoverContent>
            </Popover>
          )}
          <Tooltip>
            <TooltipTrigger asChild>
              <span>
                <Button
                  size="sm"
                  disabled={!isDirty || isPending || hasErrors}
                  onClick={triggerSave}
                >
                  <Save className="h-3.5 w-3.5 mr-1" />
                  {isPending ? "Salvataggio..." : "Salva"}
                </Button>
              </span>
            </TooltipTrigger>
            {hasErrors && (
              <TooltipContent side="bottom">
                <span className="text-xs">Clicca sul badge rosso per vedere gli errori</span>
              </TooltipContent>
            )}
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                disabled={!adjacent?.prev}
                onClick={() => adjacent?.prev && goTo(adjacent.prev.cdpar)}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            {adjacent?.prev && (
              <TooltipContent side="bottom">
                <span className="font-mono text-xs">{adjacent.prev.cdpar}</span>
                {adjacent.prev.depar && <span className="ml-1 text-xs">— {adjacent.prev.depar}</span>}
              </TooltipContent>
            )}
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                disabled={!adjacent?.next}
                onClick={() => adjacent?.next && goTo(adjacent.next.cdpar)}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            {adjacent?.next && (
              <TooltipContent side="bottom">
                <span className="font-mono text-xs">{adjacent.next.cdpar}</span>
                {adjacent.next.depar && <span className="ml-1 text-xs">— {adjacent.next.depar}</span>}
              </TooltipContent>
            )}
          </Tooltip>
        </div>
      </div>
      <ArticleDetail cdpar={decoded} onDirtyChange={handleDirtyChange} />
    </div>
  );
}

import { useMemo, useState } from "react";
import { Loader2, Users, AtSign, ShieldCheck, Mail, Tv, ShoppingCart, TrendingUp, LogIn, UserCheck, ArrowUp, ArrowDown, ArrowUpDown, FileSpreadsheet, FileText } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from "recharts";
import { usePortalAdoption, type TimeseriesPoint, type AdoptionCustomerRow } from "@/hooks/usePortalAdoption";
import { CustomerDrilldownDialog } from "@/components/analytics/CustomerDrilldownDialog";
import { downloadCustomersExcel, downloadCustomersPdf } from "@/lib/adoptionExport";


function Kpi({
  icon: Icon,
  label,
  value,
  hint,
  tone = "default",
  weekDelta,
  weekDeltaKind = "increment",
}: {
  icon: any;
  label: string;
  value: string | number;
  hint?: string;
  tone?: "default" | "success" | "warning";
  weekDelta?: number;
  weekDeltaKind?: "increment" | "subset";
}) {
  const toneClass =
    tone === "success"
      ? "text-green-600"
      : tone === "warning"
        ? "text-orange-500"
        : "text-primary";
  const deltaPrefix = weekDeltaKind === "increment" ? "+" : "di cui ";
  const deltaSuffix = weekDeltaKind === "increment" ? " questa sett." : " attivi questa sett.";
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Icon className={`h-3.5 w-3.5 ${toneClass}`} />
          {label}
        </div>
        <div className="flex items-baseline gap-2 mt-1">
          <div className="text-2xl font-bold tabular-nums">
            {typeof value === "number" ? value.toLocaleString("it-IT") : value}
          </div>
          {typeof weekDelta === "number" && (
            <div className="text-[11px] font-semibold text-green-600 tabular-nums">
              {deltaPrefix}{weekDelta.toLocaleString("it-IT")}{deltaSuffix}
            </div>
          )}
        </div>
        {hint && <div className="text-[11px] text-muted-foreground mt-0.5">{hint.replace(" già su Videocatalogo · ", " già su VdC · ").replace(" nuovi", " non attivi")}</div>}
      </CardContent>
    </Card>
  );
}


function mergeSeries(a: TimeseriesPoint[], b: TimeseriesPoint[], keyA: string, keyB: string) {
  const map = new Map<string, any>();
  a.forEach((p) => map.set(p.ym, { ym: p.ym, label: p.label, [keyA]: p.value }));
  b.forEach((p) => {
    const cur = map.get(p.ym) ?? { ym: p.ym, label: p.label };
    cur[keyB] = p.value;
    if (p.label && !cur.label) cur.label = p.label;
    map.set(p.ym, cur);
  });
  return Array.from(map.values()).sort((x, y) => (x.ym < y.ym ? -1 : 1));
}

function SortableTh({
  label,
  active,
  dir,
  align = "left",
  onClick,
}: {
  label: string;
  active: boolean;
  dir: "asc" | "desc";
  align?: "left" | "right";
  onClick: () => void;
}) {
  const Icon = !active ? ArrowUpDown : dir === "asc" ? ArrowUp : ArrowDown;
  return (
    <th className={`px-3 py-2 ${align === "right" ? "text-right" : "text-left"}`}>
      <button
        type="button"
        onClick={onClick}
        className={`inline-flex items-center gap-1 uppercase text-xs hover:text-foreground transition-colors ${active ? "text-foreground" : ""}`}
      >
        <span>{label}</span>
        <Icon className="h-3 w-3 opacity-70" />
      </button>
    </th>
  );
}

function DrillNum({
  children,
  onClick,
  className = "",
}: {
  children: React.ReactNode;
  onClick: () => void;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`underline decoration-dotted underline-offset-2 hover:decoration-solid hover:text-primary transition-colors ${className}`}
    >
      {children}
    </button>
  );
}



export default function PortalAdoptionPage() {
  const { data, isLoading, error } = usePortalAdoption();
  const [agentSort, setAgentSort] = useState<{
    key:
      | "agent"
      | "agentName"
      | "attivati"
      | "totali"
      | "adozione"
      | "clientiOrdAgente"
      | "clientiOrdCliente"
      | "clientiOrdAgenteNonIscritti"
      | "clientiVdc";
    dir: "asc" | "desc";
  }>({ key: "attivati", dir: "desc" });


  const sortedAgents = useMemo(() => {
    if (!data?.perAgent) return [];
    const rows = [...data.perAgent];
    const { key, dir } = agentSort;
    const mul = dir === "asc" ? 1 : -1;
    rows.sort((a, b) => {
      let av: any, bv: any;
      if (key === "adozione") { av = a.totali ? a.attivati / a.totali : 0; bv = b.totali ? b.attivati / b.totali : 0; }
      else { av = (a as any)[key]; bv = (b as any)[key]; }
      if (typeof av === "string" || typeof bv === "string") return String(av ?? "").localeCompare(String(bv ?? "")) * mul;
      return ((av ?? 0) - (bv ?? 0)) * mul;
    });
    return rows;
  }, [data?.perAgent, agentSort]);


  const activityData = useMemo(
    () => mergeSeries(data?.loginsWeekly ?? [], data?.ordersWeekly ?? [], "login", "ordini"),
    [data],
  );
  const activationsData = useMemo(() => {
    const merged = mergeSeries(
      data?.activationsMigratiWeeklyAll ?? [],
      data?.activationsNuoviWeeklyAll ?? [],
      "migrati",
      "nuovi",
    );
    let cumM = 0;
    let cumN = 0;
    return merged.map((r: any) => {
      cumM += r.migrati ?? 0;
      cumN += r.nuovi ?? 0;
      return { ym: r.ym, label: r.label, migrati: r.migrati ?? 0, nuovi: r.nuovi ?? 0, cumMigrati: cumM, cumNuovi: cumN };
    });
  }, [data]);

  const activationsWeeklyData = useMemo(
    () =>
      mergeSeries(
        data?.activationsMigratiWeekly ?? [],
        data?.activationsNuoviWeekly ?? [],
        "migrati",
        "nuovi",
      ),
    [data],
  );


  const [drill, setDrill] = useState<{
    title: string;
    subtitle?: string;
    rows: AdoptionCustomerRow[];
  } | null>(null);

  const openDrill = (
    title: string,
    filter: (r: AdoptionCustomerRow) => boolean,
    subtitle?: string,
  ) => {
    const rows = (data?.customerRows ?? []).filter(filter);
    setDrill({ title, subtitle, rows });
  };

  const pct = (n: number, d: number) => (d > 0 ? Math.round((n / d) * 100) : 0);

  const allAgentCustomerRows = useMemo(() => {
    const rows = [...(data?.customerRows ?? [])];
    return rows.sort(
      (a, b) =>
        String(a.agent ?? "").localeCompare(String(b.agent ?? ""), "it") ||
        String(a.name ?? "").localeCompare(String(b.name ?? ""), "it"),
    );
  }, [data]);

  const today = new Date().toISOString().slice(0, 10);

  const exportAllAgentsExcel = () =>
    downloadCustomersExcel(`clienti_tutti_agenti_${today}.xlsx`, allAgentCustomerRows, {
      name: "Riepilogo agenti",
      rows: (data?.perAgent ?? []).map((r) => ({
        Codice: r.agent,
        "Nome agente": r.agentName ?? "",
        Attivati: r.attivati,
        Totali: r.totali,
        "Adozione %": pct(r.attivati, r.totali),
        "Clienti ord. da agente": r.clientiOrdAgente,
        "Clienti ord. da cliente": r.clientiOrdCliente,
        "Ord. agente non iscritti": r.clientiOrdAgenteNonIscritti,
        "Clienti VdC": r.clientiVdc,
      })),
    });

  const exportAllAgentsPdf = () =>
    downloadCustomersPdf({
      filename: `clienti_tutti_agenti_${today}.pdf`,
      title: "Clienti per agente — tutti gli agenti",
      subtitle: "Adozione Portale B2B",
      rows: allAgentCustomerRows,
      groupByAgent: true,
    });



  return (
    <div className="p-6 space-y-4">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Adozione Portale B2B</h1>
        <p className="text-sm text-muted-foreground">
          Metriche di adozione del portale B2B da parte dei clienti. Dati reali dal database.
        </p>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-24 text-muted-foreground">
          <Loader2 className="h-6 w-6 animate-spin" />
        </div>
      ) : error ? (
        <Card>
          <CardContent className="p-6 text-sm text-destructive">
            Errore nel caricamento: {(error as Error).message}
          </CardContent>
        </Card>
      ) : data ? (
        <Tabs defaultValue="overview">
          <TabsList>
            <TabsTrigger value="overview">Panoramica</TabsTrigger>
            <TabsTrigger value="trend">Trend</TabsTrigger>
            <TabsTrigger value="funnel">Funnel</TabsTrigger>
            <TabsTrigger value="breakdown">Zone & Agenti</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Kpi
                icon={Users}
                label="Anagrafica clienti"
                value={data.kpi.tot_customers}
                hint={`${(data.kpi.videocat_attivi ?? 0).toLocaleString("it-IT")} già su Videocatalogo · ${(((data.kpi.tot_customers ?? 0) - (data.kpi.videocat_attivi ?? 0)) || 0).toLocaleString("it-IT")} nuovi`}
              />
              <Kpi
                icon={AtSign}
                tone="success"
                label="Attivati su B2B"
                value={data.kpi.attivati}
                hint={`${pct(data.kpi.attivati, data.kpi.tot_customers)}% adozione`}
                weekDelta={data.kpi.attivati_week ?? 0}
              />
              <Kpi
                icon={UserCheck}
                tone="warning"
                label="Primo accesso in attesa"
                value={data.kpi.first_login_pending}
              />
              <Kpi
                icon={ShieldCheck}
                tone="success"
                label="Contratti accettati"
                value={data.kpi.terms_accepted}
                weekDelta={data.kpi.terms_accepted_week ?? 0}
              />
              <Kpi
                icon={Mail}
                tone="success"
                label="Iscritti newsletter"
                value={data.kpi.newsletter}
              />
              <Kpi
                icon={TrendingUp}
                label="Attivi ultimi 30gg"
                value={data.kpi.attivi_30d}
                hint="clienti con eventi articolo su B2B (finestra mobile 30gg)"
                weekDelta={data.kpi.attivi_week ?? 0}
                weekDeltaKind="subset"
              />
              <Kpi
                icon={LogIn}
                label="Login ultimi 30gg"
                value={data.kpi.login_30d}
                hint="clienti unici che hanno effettuato accesso (finestra mobile 30gg)"
                weekDelta={data.kpi.login_week ?? 0}
                weekDeltaKind="subset"
              />
              <Kpi
                icon={ShoppingCart}
                tone="success"
                label="Clienti con ordine online"
                value={data.kpi.clienti_con_ordine}
                hint={`${pct(data.kpi.clienti_con_ordine, data.kpi.attivati)}% degli attivati B2B · ${(data.kpi.ordini_totali ?? 0).toLocaleString("it-IT")} ordini totali · ${data.kpi.ordini_30d} ultimi 30gg · ${(data.kpi.ordini_week ?? 0).toLocaleString("it-IT")} ordini questa sett.`}
                weekDelta={data.kpi.clienti_con_ordine_week ?? 0}
                weekDeltaKind="subset"
              />

            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <Card className="md:col-span-1">
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Tv className="h-4 w-4 text-primary" />
                    Migrazione VdC → B2B
                  </div>
                  <div className="space-y-3">
                    {/* Header colonne */}
                    <div className="grid grid-cols-[1fr_90px_110px] gap-2 items-baseline pb-1 border-b">
                      <span className="text-[10px] uppercase tracking-wide text-muted-foreground"></span>
                      <span className="text-[10px] uppercase tracking-wide text-muted-foreground text-right">Settimana</span>
                      <span className="text-[10px] uppercase tracking-wide text-muted-foreground text-right">Cumulato</span>
                    </div>

                    {/* Attivi su Videocatalogo (totale, senza settimana) */}
                    <div className="grid grid-cols-[1fr_90px_110px] gap-2 items-baseline">
                      <span className="text-sm font-bold text-foreground">Attivi su VdC</span>
                      <span className="text-right text-xs text-muted-foreground">—</span>
                      <span className="text-right text-base font-bold tabular-nums">
                        <DrillNum onClick={() => openDrill("Attivi su VdC", (r) => r.vdcAttivo)}>
                          {(data.kpi.videocat_attivi ?? 0).toLocaleString("it-IT")}
                        </DrillNum>
                      </span>
                    </div>
                    <div>
                      <div className="grid grid-cols-[1fr_90px_110px] gap-2 items-baseline mb-1">
                        <span className="text-sm font-bold text-muted-foreground">…di cui migrati al B2B</span>
                        <span className="text-right text-xs font-semibold text-green-600 tabular-nums">
                          +{(data.kpi.migrati_videocat_b2b_week ?? 0).toLocaleString("it-IT")}
                        </span>
                        <span className="text-right text-base font-bold tabular-nums text-green-600">
                          <DrillNum
                            onClick={() =>
                              openDrill("VdC migrati al B2B", (r) => r.vdcAttivo && !!r.activatedAt)
                            }
                          >
                            {(data.kpi.migrati_videocat_b2b ?? 0).toLocaleString("it-IT")}
                          </DrillNum>{" "}
                          ({pct(data.kpi.migrati_videocat_b2b, data.kpi.videocat_attivi)}%)
                        </span>
                      </div>
                      <Progress value={pct(data.kpi.migrati_videocat_b2b, data.kpi.videocat_attivi)} />
                    </div>

                    {/* Segmento: attivi VC SENZA ordini VC */}
                    <div className="pt-3 border-t space-y-1.5">
                      <div className="grid grid-cols-[1fr_90px_110px] gap-2 items-baseline">
                        <span className="text-xs font-medium">Attivi VdC senza ordini</span>
                        <span className="text-right text-xs text-muted-foreground">—</span>
                        <div className="text-right">
                          <Badge variant="outline" className="tabular-nums">
                            <DrillNum
                              onClick={() =>
                                openDrill("Attivi VdC senza ordini", (r) => r.vdcAttivo && !r.vdcOrdini)
                              }
                            >
                              {(data.kpi.vc_no_ord_totali ?? 0).toLocaleString("it-IT")}
                            </DrillNum>
                          </Badge>
                        </div>
                      </div>
                      <div className="grid grid-cols-[1fr_90px_110px] gap-2 items-baseline pl-2">
                        <span className="text-xs text-muted-foreground">…migrati al B2B</span>
                        <span className="text-right text-xs font-semibold text-green-600 tabular-nums">
                          +{(data.kpi.vc_no_ord_migrati_week ?? 0).toLocaleString("it-IT")}
                        </span>
                        <span className="text-right text-xs tabular-nums text-green-600">
                          <DrillNum
                            onClick={() =>
                              openDrill(
                                "Attivi VdC senza ordini · migrati al B2B",
                                (r) => r.vdcAttivo && !r.vdcOrdini && !!r.activatedAt,
                              )
                            }
                          >
                            {(data.kpi.vc_no_ord_migrati ?? 0).toLocaleString("it-IT")}
                          </DrillNum>{" "}
                          ({pct(data.kpi.vc_no_ord_migrati, data.kpi.vc_no_ord_totali)}%)
                        </span>
                      </div>
                      <div className="grid grid-cols-[1fr_90px_110px] gap-2 items-baseline pl-2">
                        <span className="text-xs text-muted-foreground">…ora ordinano su B2B</span>
                        <span className="text-right text-xs font-semibold text-green-600 tabular-nums">
                          +{(data.kpi.vc_no_ord_hanno_ordinato_week ?? 0).toLocaleString("it-IT")}
                        </span>
                        <span className="text-right text-xs tabular-nums text-green-600">
                          <DrillNum
                            onClick={() =>
                              openDrill(
                                "Attivi VdC senza ordini · ora ordinano su B2B",
                                (r) => r.vdcAttivo && !r.vdcOrdini && r.ordiniCliente > 0,
                              )
                            }
                          >
                            {(data.kpi.vc_no_ord_hanno_ordinato ?? 0).toLocaleString("it-IT")}
                          </DrillNum>{" "}
                          ({pct(data.kpi.vc_no_ord_hanno_ordinato, data.kpi.vc_no_ord_totali)}%)
                        </span>
                      </div>
                    </div>

                    {/* Segmento: attivi VC CON ordini VC */}
                    <div className="pt-3 border-t space-y-1.5">
                      <div className="grid grid-cols-[1fr_90px_110px] gap-2 items-baseline">
                        <span className="text-xs font-medium">Clienti VdC con ordini (2026)</span>
                        <span className="text-right text-xs text-muted-foreground">—</span>
                        <div className="text-right">
                          <Badge variant="outline" className="tabular-nums">
                            <DrillNum
                              onClick={() =>
                                openDrill("Clienti VdC con ordini (2026)", (r) => r.vdcAttivo && r.vdcOrdini)
                              }
                            >
                              {(data.kpi.vc_con_ord_totali ?? 0).toLocaleString("it-IT")}
                            </DrillNum>
                          </Badge>
                        </div>
                      </div>
                      <div className="grid grid-cols-[1fr_90px_110px] gap-2 items-baseline pl-2">
                        <span className="text-xs text-muted-foreground">…migrati al B2B</span>
                        <span className="text-right text-xs font-semibold text-green-600 tabular-nums">
                          +{(data.kpi.vc_con_ord_migrati_week ?? 0).toLocaleString("it-IT")}
                        </span>
                        <span className="text-right text-xs tabular-nums text-green-600">
                          <DrillNum
                            onClick={() =>
                              openDrill(
                                "Clienti VdC con ordini · migrati al B2B",
                                (r) => r.vdcAttivo && r.vdcOrdini && !!r.activatedAt,
                              )
                            }
                          >
                            {(data.kpi.vc_con_ord_migrati ?? 0).toLocaleString("it-IT")}
                          </DrillNum>{" "}
                          ({pct(data.kpi.vc_con_ord_migrati, data.kpi.vc_con_ord_totali)}%)
                        </span>
                      </div>
                      <div className="grid grid-cols-[1fr_90px_110px] gap-2 items-baseline pl-2">
                        <span className="text-xs text-muted-foreground">…ora ordinano su B2B</span>
                        <span className="text-right text-xs font-semibold text-green-600 tabular-nums">
                          +{(data.kpi.vc_con_ord_hanno_ordinato_week ?? 0).toLocaleString("it-IT")}
                        </span>
                        <span className="text-right text-xs tabular-nums text-green-600">
                          <DrillNum
                            onClick={() =>
                              openDrill(
                                "Clienti VdC con ordini · ora ordinano su B2B",
                                (r) => r.vdcAttivo && r.vdcOrdini && r.ordiniCliente > 0,
                              )
                            }
                          >
                            {(data.kpi.vc_con_ord_hanno_ordinato ?? 0).toLocaleString("it-IT")}
                          </DrillNum>{" "}
                          ({pct(data.kpi.vc_con_ord_hanno_ordinato, data.kpi.vc_con_ord_totali)}%)
                        </span>
                      </div>
                    </div>

                    {/* Segmento: clienti SENZA storico Videocatalogo */}
                    <div className="pt-3 border-t space-y-1.5">
                      <div className="grid grid-cols-[1fr_90px_110px] gap-2 items-baseline">
                        <span className="text-xs font-medium">Senza VdC attivo</span>
                        <span className="text-right text-xs text-muted-foreground">—</span>
                        <div className="text-right">
                          <Badge variant="outline" className="tabular-nums">
                            <DrillNum onClick={() => openDrill("Senza VdC attivo", (r) => !r.vdcAttivo)}>
                              {(data.kpi.no_vc_totali ?? 0).toLocaleString("it-IT")}
                            </DrillNum>
                          </Badge>
                        </div>
                      </div>
                      <div className="grid grid-cols-[1fr_90px_110px] gap-2 items-baseline pl-2">
                        <span className="text-xs text-muted-foreground">…attivati su B2B</span>
                        <span className="text-right text-xs font-semibold text-green-600 tabular-nums">
                          +{(data.kpi.no_vc_attivati_week ?? 0).toLocaleString("it-IT")}
                        </span>
                        <span className="text-right text-xs tabular-nums text-green-600">
                          <DrillNum
                            onClick={() =>
                              openDrill(
                                "Senza VdC · attivati su B2B",
                                (r) => !r.vdcAttivo && !!r.activatedAt,
                              )
                            }
                          >
                            {(data.kpi.no_vc_attivati ?? 0).toLocaleString("it-IT")}
                          </DrillNum>{" "}
                          ({pct(data.kpi.no_vc_attivati, data.kpi.no_vc_totali)}%)
                        </span>
                      </div>
                      <div className="grid grid-cols-[1fr_90px_110px] gap-2 items-baseline pl-2">
                        <span className="text-xs text-muted-foreground">…ora ordinano su B2B</span>
                        <span className="text-right text-xs font-semibold text-green-600 tabular-nums">
                          +{(data.kpi.no_vc_hanno_ordinato_week ?? 0).toLocaleString("it-IT")}
                        </span>
                        <span className="text-right text-xs tabular-nums text-green-600">
                          <DrillNum
                            onClick={() =>
                              openDrill(
                                "Senza VdC · ora ordinano su B2B",
                                (r) => !r.vdcAttivo && r.ordiniCliente > 0,
                              )
                            }
                          >
                            {(data.kpi.no_vc_hanno_ordinato ?? 0).toLocaleString("it-IT")}
                          </DrillNum>{" "}
                          ({pct(data.kpi.no_vc_hanno_ordinato, data.kpi.no_vc_totali)}%)
                        </span>
                      </div>
                    </div>
                  </div>



                </CardContent>
              </Card>


              <Card className="md:col-span-2">
                <CardContent className="p-4 space-y-2">
                  <div className="text-sm font-medium">Attivazioni ultime 8 settimane</div>
                  <div className="h-56">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={activationsWeeklyData}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                        <XAxis
                          dataKey="ym"
                          tick={{ fontSize: 11 }}
                          tickFormatter={(v) => {
                            const d = new Date(v + "T00:00:00Z");
                            return `${String(d.getUTCDate()).padStart(2, "0")}/${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
                          }}
                        />
                        <YAxis tick={{ fontSize: 11 }} />
                        <Tooltip
                          labelFormatter={(v) => {
                            const d = new Date(v + "T00:00:00Z");
                            return `Sett. dal ${String(d.getUTCDate()).padStart(2, "0")}/${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
                          }}
                        />
                        <Legend />
                        <Bar dataKey="migrati" stackId="a" name="Migrati da VC" fill="hsl(var(--primary))" />
                        <Bar dataKey="nuovi" stackId="a" name="Nuovi clienti" fill="hsl(142 71% 45%)" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="trend" className="space-y-4">
            <Card>
              <CardContent className="p-4 space-y-2">
                <div className="text-sm font-medium">Attività portale (login vs ordini per settimana)</div>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={activityData}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                      <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="login"
                        stroke="hsl(var(--primary))"
                        strokeWidth={2}
                        dot={false}
                        name="Login"
                      />
                      <Line
                        type="monotone"
                        dataKey="ordini"
                        stroke="hsl(142 71% 45%)"
                        strokeWidth={2}
                        dot={false}
                        name="Ordini"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 space-y-2">
                <div className="text-sm font-medium">Attivazioni cumulate settimanali (migrati da Videocatalogo vs nuovi)</div>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={activationsData}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                      <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="cumMigrati"
                        stroke="hsl(var(--primary))"
                        strokeWidth={2}
                        dot={false}
                        name="Migrati da VC (cum.)"
                      />
                      <Line
                        type="monotone"
                        dataKey="cumNuovi"
                        stroke="hsl(142 71% 45%)"
                        strokeWidth={2}
                        dot={false}
                        name="Nuovi clienti (cum.)"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="funnel" className="space-y-4">
            <Card>
              <CardContent className="p-4 space-y-3">
                <div className="text-sm font-medium">Funnel di adozione</div>
                {data.funnel.map((step, i) => {
                  const top = data.funnel[0].value || 1;
                  const p = Math.round((step.value / top) * 100);
                  const prev = i > 0 ? data.funnel[i - 1].value : null;
                  const conv = prev ? Math.round((step.value / (prev || 1)) * 100) : null;
                  return (
                    <div key={step.label} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="font-medium">{step.label}</span>
                        <span className="tabular-nums text-muted-foreground">
                          {(step.value ?? 0).toLocaleString("it-IT")} · {p}% del totale
                          {conv != null && (
                            <span className="ml-2 text-primary">→ {conv}% step precedente</span>
                          )}
                        </span>
                      </div>
                      <Progress value={p} />
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="breakdown" className="space-y-4">
            <Card>
              <CardContent className="p-4 space-y-2">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <div className="text-sm font-medium">Agenti per attivazioni</div>
                    <div className="text-xs text-muted-foreground">
                      I conteggi "clienti" sono clienti distinti, non numero di ordini.
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={exportAllAgentsExcel}>
                      <FileSpreadsheet className="mr-1.5 h-3.5 w-3.5" /> Excel (tutti)
                    </Button>
                    <Button size="sm" variant="outline" onClick={exportAllAgentsPdf}>
                      <FileText className="mr-1.5 h-3.5 w-3.5" /> PDF (tutti)
                    </Button>
                  </div>
                </div>

                <div className="rounded border overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
                      <tr>
                        <SortableTh label="Codice" active={agentSort.key === "agent"} dir={agentSort.dir} onClick={() => setAgentSort((s) => ({ key: "agent", dir: s.key === "agent" && s.dir === "asc" ? "desc" : "asc" }))} />
                        <SortableTh label="Nome agente" active={agentSort.key === "agentName"} dir={agentSort.dir} onClick={() => setAgentSort((s) => ({ key: "agentName", dir: s.key === "agentName" && s.dir === "asc" ? "desc" : "asc" }))} />
                        <SortableTh label="Attivati" align="right" active={agentSort.key === "attivati"} dir={agentSort.dir} onClick={() => setAgentSort((s) => ({ key: "attivati", dir: s.key === "attivati" && s.dir === "desc" ? "asc" : "desc" }))} />
                        <SortableTh label="Totali" align="right" active={agentSort.key === "totali"} dir={agentSort.dir} onClick={() => setAgentSort((s) => ({ key: "totali", dir: s.key === "totali" && s.dir === "desc" ? "asc" : "desc" }))} />
                        <SortableTh label="Adozione" align="right" active={agentSort.key === "adozione"} dir={agentSort.dir} onClick={() => setAgentSort((s) => ({ key: "adozione", dir: s.key === "adozione" && s.dir === "desc" ? "asc" : "desc" }))} />
                        <SortableTh label="Clienti ord. da agente" align="right" active={agentSort.key === "clientiOrdAgente"} dir={agentSort.dir} onClick={() => setAgentSort((s) => ({ key: "clientiOrdAgente", dir: s.key === "clientiOrdAgente" && s.dir === "desc" ? "asc" : "desc" }))} />
                        <SortableTh label="Clienti ord. da cliente" align="right" active={agentSort.key === "clientiOrdCliente"} dir={agentSort.dir} onClick={() => setAgentSort((s) => ({ key: "clientiOrdCliente", dir: s.key === "clientiOrdCliente" && s.dir === "desc" ? "asc" : "desc" }))} />
                        <SortableTh label="Ord. agente non iscritti" align="right" active={agentSort.key === "clientiOrdAgenteNonIscritti"} dir={agentSort.dir} onClick={() => setAgentSort((s) => ({ key: "clientiOrdAgenteNonIscritti", dir: s.key === "clientiOrdAgenteNonIscritti" && s.dir === "desc" ? "asc" : "desc" }))} />
                        <SortableTh label="Clienti VdC" align="right" active={agentSort.key === "clientiVdc"} dir={agentSort.dir} onClick={() => setAgentSort((s) => ({ key: "clientiVdc", dir: s.key === "clientiVdc" && s.dir === "desc" ? "asc" : "desc" }))} />
                      </tr>
                    </thead>
                    <tbody>
                      {sortedAgents.map((r) => (
                        <tr
                          key={r.agent}
                          className="border-t cursor-pointer hover:bg-muted/40"
                          onClick={() =>
                            openDrill(
                              `Clienti agente ${r.agent}${r.agentName ? " · " + r.agentName : ""}`,
                              (c) => c.agent === r.agent,
                            )
                          }
                        >
                          <td className="px-3 py-1.5 font-mono text-xs underline decoration-dotted underline-offset-2">
                            {r.agent}
                          </td>
                          <td className="px-3 py-1.5 text-xs whitespace-nowrap">
                            {r.agentName ?? <span className="text-muted-foreground">—</span>}
                          </td>
                          <td className="px-3 py-1.5 text-right tabular-nums">{r.attivati}</td>
                          <td className="px-3 py-1.5 text-right tabular-nums text-muted-foreground">
                            {r.totali}
                          </td>
                          <td className="px-3 py-1.5 text-right tabular-nums">
                            {pct(r.attivati, r.totali)}%
                          </td>
                          <td className="px-3 py-1.5 text-right tabular-nums">{r.clientiOrdAgente}</td>
                          <td className="px-3 py-1.5 text-right tabular-nums">{r.clientiOrdCliente}</td>
                          <td className="px-3 py-1.5 text-right tabular-nums text-muted-foreground">
                            {r.clientiOrdAgenteNonIscritti}
                          </td>
                          <td className="px-3 py-1.5 text-right tabular-nums">{r.clientiVdc}</td>
                        </tr>
                      ))}
                      {data.perAgent.length === 0 && (
                        <tr>
                          <td colSpan={9} className="text-center py-6 text-muted-foreground text-xs">
                            Nessun dato
                          </td>
                        </tr>
                      )}
                    </tbody>
                    {data.perAgent.length > 0 && (() => {
                      const sum = (f: (r: (typeof data.perAgent)[number]) => number) =>
                        data.perAgent.reduce((s, r) => s + f(r), 0);
                      const tA = sum((r) => r.attivati);
                      const tT = sum((r) => r.totali);
                      return (
                        <tfoot className="bg-muted/30 font-semibold border-t">
                          <tr>
                            <td className="px-3 py-2 text-xs uppercase" colSpan={2}>Totale</td>
                            <td className="px-3 py-2 text-right tabular-nums">{tA}</td>
                            <td className="px-3 py-2 text-right tabular-nums">{tT}</td>
                            <td className="px-3 py-2 text-right tabular-nums">{pct(tA, tT)}%</td>
                            <td className="px-3 py-2 text-right tabular-nums">{sum((r) => r.clientiOrdAgente)}</td>
                            <td className="px-3 py-2 text-right tabular-nums">{sum((r) => r.clientiOrdCliente)}</td>
                            <td className="px-3 py-2 text-right tabular-nums">{sum((r) => r.clientiOrdAgenteNonIscritti)}</td>
                            <td className="px-3 py-2 text-right tabular-nums">{sum((r) => r.clientiVdc)}</td>
                          </tr>
                        </tfoot>
                      );
                    })()}
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

        </Tabs>
      ) : null}

      <CustomerDrilldownDialog
        open={!!drill}
        onOpenChange={(v) => !v && setDrill(null)}
        title={drill?.title ?? ""}
        subtitle={drill?.subtitle}
        rows={drill?.rows ?? []}
      />
    </div>
  );
}

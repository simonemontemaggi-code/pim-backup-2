import { useMemo, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ArrowLeft, ImageIcon, X, Search, ExternalLink, ArrowUp, ArrowDown, ArrowUpDown, Download } from "lucide-react";
import * as XLSX from "xlsx";

type Assortment = {
  id: string;
  name: string;
  slug: string;
  tags: string[];
  match_mode: "or" | "and";
};

type Article = {
  cdpar: string;
  depar: string | null;
  tags: string[] | null;
  wfuas: string | null;
};

export default function B2bAssortmentArticlesPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [confirmRemove, setConfirmRemove] = useState<{ cdpar: string; tag: string } | null>(null);
  type SortKey = "cdpar" | "depar" | "wfuas" | "tags";
  const [sortKey, setSortKey] = useState<SortKey>("cdpar");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
  const toggleSort = (k: SortKey) => {
    if (sortKey === k) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(k); setSortDir("asc"); }
  };

  const { data: assortment } = useQuery({
    queryKey: ["b2b_assortment", id],
    enabled: !!id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("b2b_assortments").select("id,name,slug,tags,match_mode")
        .eq("id", id!).maybeSingle();
      if (error) throw error;
      return data as Assortment | null;
    },
  });

  const { data: articles = [], isLoading } = useQuery({
    queryKey: ["b2b_assortment_articles", id, assortment?.tags, assortment?.match_mode],
    enabled: !!assortment && (assortment.tags?.length ?? 0) > 0,
    queryFn: async () => {
      const q = supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar,depar,tags,wfuas")
        .limit(2000);
      const { data, error } = assortment!.match_mode === "and"
        ? await q.contains("tags", assortment!.tags)
        : await q.overlaps("tags", assortment!.tags);
      if (error) throw error;
      return (data ?? []).map((a: any) => ({ ...a, cdpar: (a.cdpar ?? "").trim() })) as Article[];
    },
  });

  const cdpars = useMemo(() => articles.map((a) => a.cdpar), [articles]);

  const { data: mediaMap = {} } = useQuery({
    queryKey: ["b2b_assortment_media", cdpars.join(",")],
    enabled: cdpars.length > 0,
    queryFn: async () => {
      // article_media.cdpar è salvato senza padding (6 char), articoli con padding (15)
      const { data, error } = await supabase
        .from("article_media")
        .select("cdpar,public_url,is_primary")
        .in("cdpar", cdpars)
        .eq("media_type", "image");
      if (error) throw error;
      const out: Record<string, string> = {};
      for (const m of (data ?? [])) {
        const key = (m.cdpar ?? "").trim();
        if (!out[key] || m.is_primary) out[key] = m.public_url;
      }
      return out;
    },
  });

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    const base = !s ? articles : articles.filter((a) =>
      a.cdpar.toLowerCase().includes(s) ||
      (a.depar ?? "").toLowerCase().includes(s) ||
      (a.tags ?? []).some((t) => t.toLowerCase().includes(s))
    );
    const sorted = [...base].sort((a, b) => {
      const getVal = (x: Article) => {
        if (sortKey === "tags") return (x.tags ?? []).length;
        const v = (x as any)[sortKey];
        return (v ?? "").toString().toLowerCase().trim();
      };
      const va = getVal(a); const vb = getVal(b);
      if (va < vb) return sortDir === "asc" ? -1 : 1;
      if (va > vb) return sortDir === "asc" ? 1 : -1;
      return 0;
    });
    return sorted;
  }, [articles, search, sortKey, sortDir]);

  const SortIcon = ({ k }: { k: SortKey }) =>
    sortKey !== k ? <ArrowUpDown className="h-3 w-3 opacity-40" /> :
    sortDir === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />;

  const removeTag = useMutation({
    mutationFn: async ({ cdpar, tag }: { cdpar: string; tag: string }) => {
      const article = articles.find((a) => a.cdpar === cdpar);
      const newTags = (article?.tags ?? []).filter((t) => t !== tag);
      // cdpar in tabella articoli è paddato a 15 char
      const padded = cdpar.padEnd(15, " ");
      const { error } = await supabase
        .from("archivio_articoli_fraschetti")
        .update({ tags: newTags })
        .eq("cdpar", padded);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Tag rimosso" });
      qc.invalidateQueries({ queryKey: ["b2b_assortment_articles"] });
      qc.invalidateQueries({ queryKey: ["b2b_assortments_counts"] });
      setConfirmRemove(null);
    },
    onError: (e: Error) =>
      toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  return (
    <div className="p-6 space-y-4 max-w-7xl">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={() => navigate("/pim/b2b/assortments")}>
          <ArrowLeft className="h-4 w-4 mr-1" /> Assortimenti
        </Button>
        <div className="flex-1">
          <h1 className="text-xl font-semibold">{assortment?.name ?? "..."}</h1>
          <div className="text-xs text-muted-foreground flex flex-wrap items-center gap-1 mt-0.5">
            {assortment && (
              <>
                <span>Match</span>
                <Badge variant="outline" className="text-[10px] uppercase">{assortment.match_mode}</Badge>
                <span>su tag:</span>
                {assortment.tags.map((t) => (
                  <Badge key={t} variant="secondary" className="text-[10px]">{t}</Badge>
                ))}
                <span>— <strong>{filtered.length}</strong> articoli</span>
              </>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative w-72">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Filtra per cdpar, descrizione, tag..."
              className="pl-8 h-9"
            />
          </div>
          <Button
            variant="outline"
            size="sm"
            className="h-9"
            disabled={filtered.length === 0}
            onClick={() => {
              const rows = filtered.map((a) => ({
                CDPAR: a.cdpar.trim(),
                Descrizione: a.depar ?? "",
                Assortimento: a.wfuas ?? "",
                Tag: (a.tags ?? []).join(", "),
              }));
              const ws = XLSX.utils.json_to_sheet(rows, { header: ["CDPAR", "Descrizione", "Assortimento", "Tag"] });
              const range = XLSX.utils.decode_range(ws["!ref"] || "A1");
              for (let R = range.s.r + 1; R <= range.e.r; R++) {
                const cell = ws[XLSX.utils.encode_cell({ r: R, c: 0 })];
                if (cell) { cell.t = "s"; cell.z = "@"; }
              }
              ws["!cols"] = [{ wch: 12 }, { wch: 50 }, { wch: 14 }, { wch: 30 }];
              const wb = XLSX.utils.book_new();
              XLSX.utils.book_append_sheet(wb, ws, "Articoli");
              const buf = XLSX.write(wb, { type: "array", bookType: "xlsx" });
              const blob = new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              const slug = (assortment?.slug || assortment?.name || "assortimento").replace(/[^a-z0-9_-]+/gi, "_");
              const ts = new Date().toISOString().replace(/[:-]/g, "").slice(0, 15);
              a.download = `assortimento_${slug}_${ts}.xlsx`;
              a.click();
              URL.revokeObjectURL(url);
              toast({ title: `Esportati ${rows.length} articoli ✅` });
            }}
          >
            <Download className="h-4 w-4 mr-2" /> Esporta
          </Button>
        </div>
      </div>

      <div className="rounded-lg border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 border-b text-left">
            <tr>
              <th className="px-3 py-2 w-16"></th>
              <th className="px-3 py-2 w-32">
                <button onClick={() => toggleSort("cdpar")} className="inline-flex items-center gap-1 hover:text-foreground">
                  CDPAR <SortIcon k="cdpar" />
                </button>
              </th>
              <th className="px-3 py-2">
                <button onClick={() => toggleSort("depar")} className="inline-flex items-center gap-1 hover:text-foreground">
                  Descrizione <SortIcon k="depar" />
                </button>
              </th>
              <th className="px-3 py-2 w-28">
                <button onClick={() => toggleSort("wfuas")} className="inline-flex items-center gap-1 hover:text-foreground">
                  Stato <SortIcon k="wfuas" />
                </button>
              </th>
              <th className="px-3 py-2">
                <button onClick={() => toggleSort("tags")} className="inline-flex items-center gap-1 hover:text-foreground">
                  Tag <SortIcon k="tags" />
                </button>
              </th>
              <th className="px-3 py-2 w-10"></th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={6} className="px-3 py-8 text-center text-muted-foreground">Caricamento...</td></tr>
            ) : filtered.length === 0 ? (
              <tr><td colSpan={6} className="px-3 py-8 text-center text-muted-foreground">
                Nessun articolo trovato per questi tag.
              </td></tr>
            ) : filtered.map((a) => {
              const img = mediaMap[a.cdpar];
              return (
                <tr key={a.cdpar} className="border-b last:border-b-0 hover:bg-muted/20">
                  <td className="px-3 py-2">
                    <div className="h-12 w-12 rounded border bg-muted/30 flex items-center justify-center overflow-hidden">
                      {img ? (
                        <img src={img} alt={a.cdpar} className="w-full h-full object-contain" />
                      ) : (
                        <ImageIcon className="h-5 w-5 text-muted-foreground/40" />
                      )}
                    </div>
                  </td>
                  <td className="px-3 py-2 font-mono text-xs">{a.cdpar.trim()}</td>
                  <td className="px-3 py-2">{a.depar ?? "—"}</td>
                  <td className="px-3 py-2">
                    {a.wfuas ? (
                      <Badge variant="outline" className="text-xs font-mono">{a.wfuas}</Badge>
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex flex-wrap gap-1 max-w-2xl">
                      {(a.tags ?? []).length === 0 && (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                      {(a.tags ?? []).map((t) => {
                        const isMatch = assortment?.tags.includes(t);
                        return (
                          <Badge
                            key={t}
                            variant={isMatch ? "default" : "secondary"}
                            className="text-xs gap-1 pr-1"
                          >
                            {t}
                            <button
                              onClick={() => setConfirmRemove({ cdpar: a.cdpar, tag: t })}
                              className="hover:text-destructive ml-0.5"
                              title="Rimuovi tag dall'articolo"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </Badge>
                        );
                      })}
                    </div>
                  </td>
                  <td className="px-3 py-2">
                    <Button asChild variant="ghost" size="icon" className="h-7 w-7">
                      <Link to={`/pim/articles/${a.cdpar.trim()}`} title="Apri articolo">
                        <ExternalLink className="h-3.5 w-3.5" />
                      </Link>
                    </Button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <AlertDialog open={!!confirmRemove} onOpenChange={(o) => !o && setConfirmRemove(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Rimuovere il tag dall'articolo?</AlertDialogTitle>
            <AlertDialogDescription>
              {confirmRemove && (
                <>
                  Stai per rimuovere il tag <strong>{confirmRemove.tag}</strong> dall'articolo{" "}
                  <code>{confirmRemove.cdpar.trim()}</code>. Verrà eliminato anche dalla tabella articoli.
                  Se è uno dei tag di questo assortimento (modalità OR), l'articolo potrebbe uscire dalla lista.
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => confirmRemove && removeTag.mutate(confirmRemove)}
            >
              Rimuovi
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

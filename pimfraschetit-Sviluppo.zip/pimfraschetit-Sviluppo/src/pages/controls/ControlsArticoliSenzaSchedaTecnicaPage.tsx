import { FileBadge } from "lucide-react";
import { ControlArticoliListPage } from "@/components/controls/ControlArticoliListPage";

export default function ControlsArticoliSenzaSchedaTecnicaPage() {
  return (
    <ControlArticoliListPage
      title="Articoli senza scheda tecnica"
      icon={FileBadge}
      description="Articoli che non hanno alcun PDF di tipo scheda tecnica (pdf_datasheet) caricato."
      rpcName="controls_articoli_senza_scheda_tecnica"
    />
  );
}

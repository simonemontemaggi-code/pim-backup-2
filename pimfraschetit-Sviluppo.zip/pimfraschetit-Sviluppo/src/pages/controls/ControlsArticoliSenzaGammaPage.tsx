import { Layers } from "lucide-react";
import { ControlArticoliListPage } from "@/components/controls/ControlArticoliListPage";

export default function ControlsArticoliSenzaGammaPage() {
  return (
    <ControlArticoliListPage
      title="Articoli senza gamma"
      icon={Layers}
      description="Articoli senza gamma valorizzata (attributes.gamma vuoto)."
      rpcName="controls_articoli_senza_gamma"
    />
  );
}

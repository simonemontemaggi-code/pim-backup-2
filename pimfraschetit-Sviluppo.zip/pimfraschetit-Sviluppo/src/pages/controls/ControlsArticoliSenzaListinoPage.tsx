import { Euro } from "lucide-react";
import { ControlArticoliListPage } from "@/components/controls/ControlArticoliListPage";

export default function ControlsArticoliSenzaListinoPage() {
  return (
    <ControlArticoliListPage
      title="Articoli senza listino"
      icon={Euro}
      description="Articoli senza criterio prezzo configurato per il listino 01 (listini_vendita_criteri_prezzo.wcdls = '01'). Include anche articoli con righe residue su listini_vendita_dettagli ma nessun criterio attivo."
      rpcName="controls_articoli_senza_listino"
    />
  );
}

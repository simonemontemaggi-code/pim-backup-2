import { useQuery } from "@tanstack/react-query";
import { Users, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { ControlListShell } from "@/components/controls/ControlListShell";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface Props {
  title: string;
  description: string;
  field: "buyer" | "demand_planner";
}

function FornitoriList({ title, description, field }: Props) {
  const { data, isLoading } = useQuery({
    queryKey: ["controls_forn_missing", field],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("archivio_fornitori_fraschetti")
        .select("cdfor,rasfo,rasf2,buyer,demand_planner,is_active")
        .eq("is_active", true)
        .or(`${field}.is.null,${field}.eq.`)
        .order("cdfor")
        .limit(1000);
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 60_000,
  });
  return (
    <ControlListShell title={title} icon={Users} description={description} total={data?.length ?? 0}>
      {isLoading ? (
        <Skeleton className="h-64 w-full" />
      ) : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[100px]">Codice</TableHead>
                  <TableHead>Ragione sociale</TableHead>
                  <TableHead>Ragione 2</TableHead>
                  <TableHead className="w-[140px]">Buyer</TableHead>
                  <TableHead className="w-[140px]">Demand Planner</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(!data || data.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                      Tutti i fornitori attivi hanno il campo valorizzato ✓
                    </TableCell>
                  </TableRow>
                )}
                {data?.map((r: any) => (
                  <TableRow key={r.cdfor}>
                    <TableCell className="font-mono text-xs">{r.cdfor}</TableCell>
                    <TableCell className="text-sm">{r.rasfo ?? "—"}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{r.rasf2 ?? "—"}</TableCell>
                    <TableCell className="text-sm">{r.buyer || <span className="text-destructive">manca</span>}</TableCell>
                    <TableCell className="text-sm">{r.demand_planner || <span className="text-destructive">manca</span>}</TableCell>
                    <TableCell>
                      <Button asChild size="icon" variant="ghost" className="h-7 w-7">
                        <Link to={`/pim/suppliers?cdfor=${encodeURIComponent(r.cdfor)}`}>
                          <ExternalLink className="h-3.5 w-3.5" />
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </ControlListShell>
  );
}

export function ControlsFornitoriSenzaBuyerPage() {
  return (
    <FornitoriList
      title="Fornitori senza buyer"
      description="Fornitori attivi per i quali il buyer non è ancora stato assegnato."
      field="buyer"
    />
  );
}

export function ControlsFornitoriSenzaDemandPlannerPage() {
  return (
    <FornitoriList
      title="Fornitori senza demand planner"
      description="Fornitori attivi per i quali il demand planner non è ancora stato assegnato."
      field="demand_planner"
    />
  );
}

import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Award, ExternalLink, X, ArrowUpDown, ArrowUp, ArrowDown } from "lucide-react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { ControlListShell } from "@/components/controls/ControlListShell";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";

type SortKey = "clas2" | "display_name" | "logo_url" | "hero_image_url" | "is_published_b2b";

const STORAGE_KEY = "controls_brand_no_img_state_v1";

type PersistedState = {
  sortKey: SortKey;
  sortDir: "asc" | "desc";
  filterLogo: string;
  filterHero: string;
  filterB2B: string;
};

function loadState(): PersistedState | null {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export default function ControlsBrandSenzaImmaginiPage() {
  const initial = loadState();
  const [sortKey, setSortKey] = useState<SortKey>(initial?.sortKey ?? "display_name");
  const [sortDir, setSortDir] = useState<"asc" | "desc">(initial?.sortDir ?? "asc");
  const [filterLogo, setFilterLogo] = useState<string>(initial?.filterLogo ?? "all");
  const [filterHero, setFilterHero] = useState<string>(initial?.filterHero ?? "all");
  const [filterB2B, setFilterB2B] = useState<string>(initial?.filterB2B ?? "all");

  useEffect(() => {
    try {
      sessionStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ sortKey, sortDir, filterLogo, filterHero, filterB2B }),
      );
    } catch {}
  }, [sortKey, sortDir, filterLogo, filterHero, filterB2B]);

  const { data: rawData, isLoading } = useQuery({
    queryKey: ["controls_brand_no_img"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("archivio_brand_fraschetti")
        .select("clas2,nome_as400_brand,display_name,logo_url,hero_image_url,is_published_b2b")
        .or("logo_url.is.null,hero_image_url.is.null")
        .limit(1000);
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 60_000,
  });

  const data = useMemo(() => {
    let rows = rawData ? [...rawData] : [];
    // filters
    if (filterLogo === "missing") rows = rows.filter(r => !r.logo_url);
    if (filterLogo === "ok") rows = rows.filter(r => !!r.logo_url);
    if (filterHero === "missing") rows = rows.filter(r => !r.hero_image_url);
    if (filterHero === "ok") rows = rows.filter(r => !!r.hero_image_url);
    if (filterB2B === "missing") rows = rows.filter(r => !r.is_published_b2b);
    if (filterB2B === "ok") rows = rows.filter(r => !!r.is_published_b2b);
    // sort
    rows.sort((a, b) => {
      let av: any, bv: any;
      if (sortKey === "display_name") {
        av = (a.display_name || a.nome_as400_brand || "").toLowerCase();
        bv = (b.display_name || b.nome_as400_brand || "").toLowerCase();
      } else {
        av = a[sortKey];
        bv = b[sortKey];
        if (typeof av === "string") av = av.toLowerCase();
        if (typeof bv === "string") bv = bv.toLowerCase();
      }
      if (av === bv) return 0;
      if (av == null) return sortDir === "asc" ? -1 : 1;
      if (bv == null) return sortDir === "asc" ? 1 : -1;
      return sortDir === "asc" ? (av < bv ? -1 : 1) : (av > bv ? -1 : 1);
    });
    return rows;
  }, [rawData, sortKey, sortDir, filterLogo, filterHero, filterB2B]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir(prev => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  const SortIcon = ({ k }: { k: SortKey }) => {
    if (sortKey !== k) return <ArrowUpDown className="h-3 w-3 text-muted-foreground" />;
    return sortDir === "asc" ? <ArrowUp className="h-3 w-3 text-primary" /> : <ArrowDown className="h-3 w-3 text-primary" />;
  };

  return (
    <ControlListShell
      title="Brand senza immagini"
      icon={Award}
      description="Brand a cui manca il logo o l'immagine hero (necessari per la presentazione B2B)."
      total={data?.length ?? 0}
    >
      {/* Filters */}
      <div className="flex flex-wrap gap-4 mb-4">
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Logo:</span>
          <ToggleGroup type="single" value={filterLogo} onValueChange={(v) => v && setFilterLogo(v)} size="sm">
            <ToggleGroupItem value="all" className="text-xs">Tutti</ToggleGroupItem>
            <ToggleGroupItem value="missing" className="text-xs text-destructive">Manca</ToggleGroupItem>
            <ToggleGroupItem value="ok" className="text-xs text-success">OK</ToggleGroupItem>
          </ToggleGroup>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Hero:</span>
          <ToggleGroup type="single" value={filterHero} onValueChange={(v) => v && setFilterHero(v)} size="sm">
            <ToggleGroupItem value="all" className="text-xs">Tutti</ToggleGroupItem>
            <ToggleGroupItem value="missing" className="text-xs text-destructive">Manca</ToggleGroupItem>
            <ToggleGroupItem value="ok" className="text-xs text-success">OK</ToggleGroupItem>
          </ToggleGroup>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">B2B:</span>
          <ToggleGroup type="single" value={filterB2B} onValueChange={(v) => v && setFilterB2B(v)} size="sm">
            <ToggleGroupItem value="all" className="text-xs">Tutti</ToggleGroupItem>
            <ToggleGroupItem value="missing" className="text-xs text-destructive">No</ToggleGroupItem>
            <ToggleGroupItem value="ok" className="text-xs text-success">Pubblicato</ToggleGroupItem>
          </ToggleGroup>
        </div>
      </div>

      {isLoading ? (
        <Skeleton className="h-64 w-full" />
      ) : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[80px] cursor-pointer" onClick={() => toggleSort("clas2")}>
                    <span className="flex items-center gap-1">Cod. <SortIcon k="clas2" /></span>
                  </TableHead>
                  <TableHead className="cursor-pointer" onClick={() => toggleSort("display_name")}>
                    <span className="flex items-center gap-1">Nome <SortIcon k="display_name" /></span>
                  </TableHead>
                  <TableHead className="w-[100px] text-center cursor-pointer" onClick={() => toggleSort("logo_url")}>
                    <span className="flex items-center justify-center gap-1">Logo <SortIcon k="logo_url" /></span>
                  </TableHead>
                  <TableHead className="w-[100px] text-center cursor-pointer" onClick={() => toggleSort("hero_image_url")}>
                    <span className="flex items-center justify-center gap-1">Hero <SortIcon k="hero_image_url" /></span>
                  </TableHead>
                  <TableHead className="w-[100px] text-center cursor-pointer" onClick={() => toggleSort("is_published_b2b")}>
                    <span className="flex items-center justify-center gap-1">B2B <SortIcon k="is_published_b2b" /></span>
                  </TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(!data || data.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                      Nessun brand corrisponde ai filtri ✓
                    </TableCell>
                  </TableRow>
                )}
                {data?.map((r: any) => (
                  <TableRow key={r.clas2}>
                    <TableCell className="font-mono text-xs">{r.clas2}</TableCell>
                    <TableCell className="text-sm font-medium">{r.display_name || r.nome_as400_brand || "—"}</TableCell>
                    <TableCell className="text-center">
                      {r.logo_url ? (
                        <Badge variant="outline" className="text-success border-success">✓</Badge>
                      ) : (
                        <Badge variant="outline" className="text-destructive border-destructive"><X className="h-3.5 w-3.5" /></Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-center">
                      {r.hero_image_url ? (
                        <Badge variant="outline" className="text-success border-success">✓</Badge>
                      ) : (
                        <Badge variant="outline" className="text-destructive border-destructive"><X className="h-3.5 w-3.5" /></Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-center">
                      {r.is_published_b2b ? (
                        <Badge variant="secondary" className="text-[10px]">pubblicato</Badge>
                      ) : (
                        <span className="text-[10px] text-muted-foreground">no</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Button asChild size="icon" variant="ghost" className="h-7 w-7">
                        <Link to={`/pim/b2b/brands/${encodeURIComponent(r.clas2)}`}>
                          <ExternalLink className="h-3.5 w-3.5" />
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </ControlListShell>
  );
}

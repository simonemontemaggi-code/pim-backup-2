import { Image as ImageIcon } from "lucide-react";
import { useSearchParams } from "react-router-dom";
import { ControlArticoliListPage } from "@/components/controls/ControlArticoliListPage";

export default function ControlsArticoliSenzaImmaginePage() {
  const [params] = useSearchParams();
  const onlyOnline = params.get("online") === "1";
  return (
    <ControlArticoliListPage
      title="Articoli senza immagine"
      icon={ImageIcon}
      description="Articoli che non hanno alcuna immagine in libreria media."
      rpcName="controls_articoli_senza_immagine"
      defaultOnlyB2bOnline={onlyOnline}
    />
  );
}

import { ListChecks } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ControlArticoliListPage } from "@/components/controls/ControlArticoliListPage";

export default function ControlsArticoliSenzaAttributiObbligatoriPage() {
  return (
    <ControlArticoliListPage
      title="Articoli senza attributi obbligatori"
      icon={ListChecks}
      description="Articoli con almeno un attributo obbligatorio (definito nel set della propria gamma) non valorizzato."
      rpcName="controls_articoli_senza_attributi"
      extraColumns={[
        {
          header: "Attributi mancanti",
          cell: (r) => (
            <div className="flex flex-wrap gap-1">
              {(r.missing_attrs as string[] | undefined)?.slice(0, 6).map((a) => (
                <Badge key={a} variant="outline" className="text-[10px] text-warning border-warning/40">
                  {a}
                </Badge>
              ))}
              {(r.missing_attrs?.length ?? 0) > 6 && (
                <span className="text-[10px] text-muted-foreground">+{r.missing_attrs.length - 6}</span>
              )}
            </div>
          ),
        },
      ]}
    />
  );
}

import { ListChecks } from "lucide-react";
import { ControlArticoliListPage } from "@/components/controls/ControlArticoliListPage";

export default function ControlsArticoliSenzaAttributiPage() {
  return (
    <ControlArticoliListPage
      title="Articoli senza attributi"
      icon={ListChecks}
      description="Articoli che non hanno NESSUN attributo valorizzato (campo attributes vuoto o nullo), indipendentemente dalla gamma."
      rpcName="controls_articoli_senza_attributi_any"
      searchParam="search_text"
    />
  );
}

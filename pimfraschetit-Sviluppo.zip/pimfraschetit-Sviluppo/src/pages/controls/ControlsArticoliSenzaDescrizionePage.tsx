import { FileText } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ControlArticoliListPage } from "@/components/controls/ControlArticoliListPage";

export default function ControlsArticoliSenzaDescrizionePage() {
  return (
    <ControlArticoliListPage
      title="Articoli senza titolo prodotto"
      icon={FileText}
      description="Articoli senza Titolo Prodotto (b2b_product_title). Sono inclusi anche i codici che hanno solo il vecchio campo titolo_b2b da migrare."
      rpcName="controls_articoli_senza_descrizione"
      extraColumns={[
        {
          header: "Legacy titolo_b2b",
          className: "w-[140px] text-center",
          cell: (r) =>
            r.has_title_legacy ? (
              <Badge variant="outline" className="text-amber-600 border-amber-600">solo legacy</Badge>
            ) : (
              <Badge variant="outline" className="text-destructive border-destructive">—</Badge>
            ),
        },
      ]}
    />
  );
}

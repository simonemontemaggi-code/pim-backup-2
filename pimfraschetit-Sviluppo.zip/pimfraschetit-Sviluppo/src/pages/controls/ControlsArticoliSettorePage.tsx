import { useParams } from "react-router-dom";
import { Layers } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ControlArticoliListPage } from "@/components/controls/ControlArticoliListPage";

export default function ControlsArticoliSettorePage() {
  const { settore = "" } = useParams<{ settore: string }>();
  const code = settore;

  const { data: label } = useQuery({
    queryKey: ["lookup_label", "clmer", code],
    queryFn: async () => {
      const { data } = await supabase
        .from("lookup_values")
        .select("label")
        .eq("category", "clmer")
        .eq("code", code)
        .maybeSingle();
      return data?.label ?? code;
    },
    staleTime: 5 * 60 * 1000,
  });

  return (
    <ControlArticoliListPage
      title={`Settore ${code} — ${label ?? ""}`}
      icon={Layers}
      description={`Articoli con clmer = "${code}" (${label ?? "—"}).`}
      rpcName="controls_articoli_per_clmer"
      extraArgs={{ p_clmer: code }}
    />
  );
}

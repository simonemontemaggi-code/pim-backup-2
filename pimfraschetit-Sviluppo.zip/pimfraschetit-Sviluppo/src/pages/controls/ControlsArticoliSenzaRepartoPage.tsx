import { FolderTree } from "lucide-react";
import { ControlArticoliListPage } from "@/components/controls/ControlArticoliListPage";

export default function ControlsArticoliSenzaRepartoPage() {
  return (
    <ControlArticoliListPage
      title="Articoli senza reparto"
      icon={FolderTree}
      description="Articoli senza reparto valorizzato (attributes.reparto vuoto)."
      rpcName="controls_articoli_senza_reparto"
    />
  );
}

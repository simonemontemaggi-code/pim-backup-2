import { AlertTriangle } from "lucide-react";
import { ControlArticoliListPage } from "@/components/controls/ControlArticoliListPage";

export default function ControlsArticoliClmerLegacyPage() {
  return (
    <ControlArticoliListPage
      title="Articoli da riclassificare (clmer 1-9 / non valido)"
      icon={AlertTriangle}
      description="Articoli con un codice merceologico legacy (1-9) o non numerico: vanno spostati in uno dei settori validi (codici da 11 in su)."
      rpcName="controls_articoli_legacy_clmer"
    />
  );
}

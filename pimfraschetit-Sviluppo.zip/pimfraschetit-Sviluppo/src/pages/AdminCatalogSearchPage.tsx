import { useState } from "react";
import { Search, RefreshCw, Plus, Trash2, Save, HelpCircle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  useCatalogSearchConfig, useSaveCatalogSearchConfig,
  useCatalogSearchSynonyms, useSynonymMutations,
  useCatalogSearchExclusions, useExclusionMutations,
  useCatalogSearchOverrides, useOverrideMutations,
  useCatalogSearchStatus, useRebuildIndex, useCatalogSearchTest,
  type CatalogSearchWeights,
} from "@/hooks/useCatalogSearch";

const WEIGHT_LABELS: Partial<Record<keyof CatalogSearchWeights, string>> = {
  exact_code: "Codice / barcode esatto",
  prefix_code: "Codice parziale",
  title_word: "Parole del titolo",
  title_lexeme: "Titolo (singolare/plurale, sinonimi)",
  prefix_last_word: "Ultima parola digitata (prefisso)",
  taxonomy: "Reparto / categoria / gamma",
  brand_tag: "Brand",
  description: "Descrizione lunga",
  fuzzy: "Somiglianza (errori di battitura)",
};

function TestBench() {
  const [q, setQ] = useState("");
  const [term, setTerm] = useState("");
  const [channel, setChannel] = useState("b2b");
  const { data, isFetching } = useCatalogSearchTest(term, channel);

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Banco di prova</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <form
          className="flex flex-wrap items-center gap-2"
          onSubmit={(e) => { e.preventDefault(); setTerm(q); }}
        >
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Cerca come farebbe il cliente: chiave brugola, guanti, 490050…"
            className="max-w-md"
          />
          <Select value={channel} onValueChange={setChannel}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="b2b">Portale B2B</SelectItem>
              <SelectItem value="agent">Portale Agenti</SelectItem>
              <SelectItem value="pim">Tutto il catalogo</SelectItem>
            </SelectContent>
          </Select>
          <Button type="submit" size="sm"><Search className="h-4 w-4 mr-1" />Prova</Button>
          {data && (
            <span className="text-xs text-muted-foreground">
              {data.hits[0]?.total_count ?? 0} risultati · {data.ms} ms · config v{data.hits[0]?.config_version ?? "-"}
            </span>
          )}
        </form>

        {isFetching && <p className="text-xs text-muted-foreground">Ricerca in corso…</p>}

        {data && data.hits.length > 0 && (
          <div className="border rounded-md max-h-[420px] overflow-auto">
            <Table>
              <TableHeader className="sticky top-0 bg-background">
                <TableRow>
                  <TableHead className="w-10">#</TableHead>
                  <TableHead className="w-24">Codice</TableHead>
                  <TableHead>Titolo</TableHead>
                  <TableHead className="w-32">Brand</TableHead>
                  <TableHead className="w-20 text-right">Score</TableHead>
                  <TableHead className="w-64">Perché</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.hits.map((h, i) => (
                  <TableRow key={h.visible_cdpar}>
                    <TableCell className="text-muted-foreground text-xs">{i + 1}</TableCell>
                    <TableCell className="font-mono text-xs">{h.visible_cdpar}</TableCell>
                    <TableCell className="text-xs">{h.title}</TableCell>
                    <TableCell className="text-xs">{h.brand_name}</TableCell>
                    <TableCell className="text-right text-xs tabular-nums">{h.score}</TableCell>
                    <TableCell className="space-x-1">
                      {(h.match_fields ?? []).map((f) => (
                        <Badge key={f} variant="secondary" className="text-[10px]">{f}</Badge>
                      ))}
                      {h.match_reasons?.["kind"] && (
                        <Badge variant="outline" className="text-[10px]">{String(h.match_reasons["kind"])}</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
        {data && data.hits.length === 0 && (
          <p className="text-xs text-muted-foreground">Nessun risultato: valuta un sinonimo o una priorità prodotto.</p>
        )}
      </CardContent>
    </Card>
  );
}

function SynonymsTab() {
  const { data = [] } = useCatalogSearchSynonyms();
  const { upsert, remove } = useSynonymMutations();
  const [filter, setFilter] = useState("");
  const [term, setTerm] = useState("");
  const [syn, setSyn] = useState("");
  const [bi, setBi] = useState(true);

  const rows = data.filter((r) =>
    !filter || r.term.toLowerCase().includes(filter.toLowerCase()) || r.synonym.toLowerCase().includes(filter.toLowerCase()));

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end gap-2">
        <div><Label className="text-xs">Parola cercata</Label><Input className="w-44" value={term} onChange={(e) => setTerm(e.target.value)} placeholder="brugola" /></div>
        <div><Label className="text-xs">Equivale a</Label><Input className="w-44" value={syn} onChange={(e) => setSyn(e.target.value)} placeholder="esagonale" /></div>
        <div className="flex items-center gap-2 pb-2"><Switch checked={bi} onCheckedChange={setBi} /><span className="text-xs">Vale nei due sensi</span></div>
        <Button
          size="sm"
          disabled={!term.trim() || !syn.trim()}
          onClick={() => { upsert.mutate({ term: term.trim(), synonym: syn.trim(), bidirectional: bi, active: true }); setTerm(""); setSyn(""); }}
        ><Plus className="h-4 w-4 mr-1" />Aggiungi</Button>
        <Input className="ml-auto w-56" placeholder="Filtra…" value={filter} onChange={(e) => setFilter(e.target.value)} />
      </div>
      <div className="border rounded-md max-h-[460px] overflow-auto">
        <Table>
          <TableHeader className="sticky top-0 bg-background">
            <TableRow><TableHead>Parola</TableHead><TableHead>Equivale a</TableHead><TableHead className="w-32">Due sensi</TableHead><TableHead className="w-24">Attivo</TableHead><TableHead className="w-16" /></TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((r) => (
              <TableRow key={r.id}>
                <TableCell className="text-xs">{r.term}</TableCell>
                <TableCell className="text-xs">{r.synonym}</TableCell>
                <TableCell><Switch checked={r.bidirectional} onCheckedChange={(v) => upsert.mutate({ id: r.id, bidirectional: v })} /></TableCell>
                <TableCell><Switch checked={r.active} onCheckedChange={(v) => upsert.mutate({ id: r.id, active: v })} /></TableCell>
                <TableCell><Button variant="ghost" size="icon" onClick={() => remove.mutate(r.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function ExclusionsTab() {
  const { data = [] } = useCatalogSearchExclusions();
  const { upsert, remove } = useExclusionMutations();
  const [term, setTerm] = useState("");

  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground">
        Parole senza valore di ricerca (articoli, preposizioni, unità generiche): vengono ignorate quando il cliente le digita.
      </p>
      <div className="flex items-end gap-2">
        <div><Label className="text-xs">Parola da ignorare</Label><Input className="w-56" value={term} onChange={(e) => setTerm(e.target.value)} placeholder="della" /></div>
        <Button size="sm" disabled={!term.trim()} onClick={() => { upsert.mutate({ term: term.trim(), exclusion_type: "ignored", active: true }); setTerm(""); }}>
          <Plus className="h-4 w-4 mr-1" />Aggiungi
        </Button>
      </div>
      <div className="border rounded-md max-h-[460px] overflow-auto">
        <Table>
          <TableHeader className="sticky top-0 bg-background">
            <TableRow><TableHead>Parola</TableHead><TableHead className="w-24">Attiva</TableHead><TableHead className="w-16" /></TableRow>
          </TableHeader>
          <TableBody>
            {data.map((r) => (
              <TableRow key={r.id}>
                <TableCell className="text-xs">{r.term}</TableCell>
                <TableCell><Switch checked={r.active} onCheckedChange={(v) => upsert.mutate({ id: r.id, active: v })} /></TableCell>
                <TableCell><Button variant="ghost" size="icon" onClick={() => remove.mutate(r.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function OverridesTab() {
  const { data = [] } = useCatalogSearchOverrides();
  const { upsert, remove } = useOverrideMutations();
  const [cdpar, setCdpar] = useState("");
  const [boost, setBoost] = useState("1000");

  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground">
        Spinta o esclusione di un singolo articolo dai risultati. Valore positivo lo fa salire, negativo lo fa scendere.
      </p>
      <div className="flex items-end gap-2">
        <div><Label className="text-xs">Codice articolo</Label><Input className="w-40 font-mono" value={cdpar} onChange={(e) => setCdpar(e.target.value)} placeholder="490050" /></div>
        <div><Label className="text-xs">Spinta</Label><Input className="w-28" type="number" value={boost} onChange={(e) => setBoost(e.target.value)} /></div>
        <Button size="sm" disabled={!cdpar.trim()} onClick={() => { upsert.mutate({ cdpar, boost: Number(boost) || 0, excluded_from_search: false, notes: null }); setCdpar(""); }}>
          <Plus className="h-4 w-4 mr-1" />Aggiungi
        </Button>
      </div>
      <div className="border rounded-md max-h-[460px] overflow-auto">
        <Table>
          <TableHeader className="sticky top-0 bg-background">
            <TableRow><TableHead className="w-32">Codice</TableHead><TableHead className="w-32">Spinta</TableHead><TableHead className="w-40">Escluso</TableHead><TableHead>Note</TableHead><TableHead className="w-16" /></TableRow>
          </TableHeader>
          <TableBody>
            {data.map((r) => (
              <TableRow key={r.cdpar}>
                <TableCell className="font-mono text-xs">{r.cdpar}</TableCell>
                <TableCell>
                  <Input
                    className="h-8 w-24"
                    type="number"
                    defaultValue={r.boost}
                    onBlur={(e) => { const v = Number(e.target.value) || 0; if (v !== r.boost) upsert.mutate({ ...r, boost: v }); }}
                  />
                </TableCell>
                <TableCell><Switch checked={r.excluded_from_search} onCheckedChange={(v) => upsert.mutate({ ...r, excluded_from_search: v })} /></TableCell>
                <TableCell className="text-xs text-muted-foreground">{r.notes}</TableCell>
                <TableCell><Button variant="ghost" size="icon" onClick={() => remove.mutate(r.cdpar)}><Trash2 className="h-4 w-4 text-destructive" /></Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function SettingsTab() {
  const { data: cfg } = useCatalogSearchConfig();
  const save = useSaveCatalogSearchConfig();
  const [draft, setDraft] = useState<any>(null);
  const v = draft ?? cfg;
  if (!v) return <p className="text-sm text-muted-foreground">Caricamento…</p>;

  const set = (patch: any) => setDraft({ ...v, ...patch });
  const setW = (k: string, val: number) => set({ weights: { ...v.weights, [k]: val } });

  return (
    <div className="space-y-4">
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm">Comportamento</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between gap-4">
              <Label className="text-xs">Caratteri minimi per cercare</Label>
              <Input className="h-8 w-20" type="number" value={v.min_chars} onChange={(e) => set({ min_chars: Number(e.target.value) })} />
            </div>
            <div className="flex items-center justify-between gap-4">
              <Label className="text-xs">Attesa prima di cercare (ms)</Label>
              <Input className="h-8 w-20" type="number" value={v.debounce_ms} onChange={(e) => set({ debounce_ms: Number(e.target.value) })} />
            </div>
            <div className="flex items-center justify-between gap-4">
              <Label className="text-xs">Cerca anche nella descrizione lunga</Label>
              <Switch checked={v.description_search_enabled} onCheckedChange={(c) => set({ description_search_enabled: c })} />
            </div>
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-1.5">
                <Label className="text-xs">Tolleranza errori di battitura</Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button type="button" className="text-muted-foreground hover:text-foreground">
                        <HelpCircle className="h-3.5 w-3.5" />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs text-xs">
                      Se attiva, la ricerca trova risultati anche quando la parola è scritta con piccoli errori (es. "martelo" → "martello"). Viene usata solo come rete di sicurezza quando la ricerca esatta restituisce pochi risultati.
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Switch checked={v.fuzzy_enabled} onCheckedChange={(c) => set({ fuzzy_enabled: c })} />
            </div>
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-1.5">
                <Label className="text-xs">Soglia somiglianza (0-1)</Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button type="button" className="text-muted-foreground hover:text-foreground">
                        <HelpCircle className="h-3.5 w-3.5" />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs text-xs">
                      Quanto una parola deve assomigliare al termine cercato per essere accettata. Valori alti (0,7-0,9) = pochi risultati ma molto pertinenti; valori bassi (0,3-0,4) = più risultati ma con rischio di errori. Consigliato: 0,55.
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Input className="h-8 w-20" type="number" step="0.05" value={v.fuzzy_threshold} onChange={(e) => set({ fuzzy_threshold: Number(e.target.value) })} />
            </div>

            <div className="flex items-center justify-between gap-4">
              <Label className="text-xs">Attiva la tolleranza sotto N risultati</Label>
              <Input className="h-8 w-20" type="number" value={v.fuzzy_fallback_count} onChange={(e) => set({ fuzzy_fallback_count: Number(e.target.value) })} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm">Pesi di ordinamento</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {Object.keys(WEIGHT_LABELS).map((k) => (
              <div key={k} className="flex items-center justify-between gap-4">
                <Label className="text-xs">{WEIGHT_LABELS[k as keyof CatalogSearchWeights]}</Label>
                <Input className="h-8 w-28" type="number" value={v.weights?.[k] ?? 0} onChange={(e) => setW(k, Number(e.target.value))} />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
      <Button size="sm" disabled={!draft || save.isPending} onClick={() => save.mutate({
        min_chars: v.min_chars, debounce_ms: v.debounce_ms, fuzzy_enabled: v.fuzzy_enabled,
        fuzzy_threshold: v.fuzzy_threshold, fuzzy_fallback_count: v.fuzzy_fallback_count,
        description_search_enabled: v.description_search_enabled, weights: v.weights,
      }, { onSuccess: () => setDraft(null) })}>
        <Save className="h-4 w-4 mr-1" />Salva parametri
      </Button>
    </div>
  );
}

function MaintenanceTab() {
  const { data } = useCatalogSearchStatus();
  const rebuild = useRebuildIndex();

  return (
    <div className="space-y-4">
      <div className="grid gap-3 md:grid-cols-3">
        <Card><CardContent className="pt-4"><p className="text-xs text-muted-foreground">Articoli indicizzati</p><p className="text-2xl font-semibold">{data?.total ?? "—"}</p></CardContent></Card>
        <Card><CardContent className="pt-4"><p className="text-xs text-muted-foreground">Visibili su B2B</p><p className="text-2xl font-semibold">{data?.b2b ?? "—"}</p></CardContent></Card>
        <Card><CardContent className="pt-4"><p className="text-xs text-muted-foreground">Visibili su Agenti</p><p className="text-2xl font-semibold">{data?.agent ?? "—"}</p></CardContent></Card>
      </div>
      <div className="flex items-center gap-3">
        <Button size="sm" variant="outline" disabled={rebuild.isPending} onClick={() => rebuild.mutate()}>
          <RefreshCw className={`h-4 w-4 mr-1 ${rebuild.isPending ? "animate-spin" : ""}`} />Ricostruisci indice
        </Button>
        <span className="text-xs text-muted-foreground">L'indice si aggiorna da solo a ogni modifica articolo; usa questo comando solo dopo un import massivo.</span>
      </div>
      <div className="border rounded-md">
        <Table>
          <TableHeader><TableRow><TableHead>Inizio</TableHead><TableHead className="w-28">Durata</TableHead><TableHead className="w-28">Articoli</TableHead><TableHead className="w-28">Esito</TableHead></TableRow></TableHeader>
          <TableBody>
            {(data?.log ?? []).map((l) => (
              <TableRow key={l.id}>
                <TableCell className="text-xs">{new Date(l.started_at).toLocaleString("it-IT")}</TableCell>
                <TableCell className="text-xs">{l.duration_ms ? `${Math.round(l.duration_ms / 1000)}s` : "—"}</TableCell>
                <TableCell className="text-xs">{l.items_processed ?? "—"}</TableCell>
                <TableCell><Badge variant={l.status === "success" ? "secondary" : "destructive"} className="text-[10px]">{l.status}</Badge></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

export default function AdminCatalogSearchPage() {
  return (
    <div className="p-6 space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Ricerca catalogo</h1>
        <p className="text-sm text-muted-foreground">
          Configurazione unica del motore di ricerca usato dal Portale B2B e dal Portale Agenti.
        </p>
      </div>

      <TestBench />

      <Tabs defaultValue="synonyms">
        <TabsList>
          <TabsTrigger value="synonyms">Sinonimi</TabsTrigger>
          <TabsTrigger value="exclusions">Parole ignorate</TabsTrigger>
          <TabsTrigger value="overrides">Priorità prodotti</TabsTrigger>
          <TabsTrigger value="settings">Parametri</TabsTrigger>
          <TabsTrigger value="maintenance">Indice</TabsTrigger>
        </TabsList>
        <TabsContent value="synonyms" className="mt-4"><SynonymsTab /></TabsContent>
        <TabsContent value="exclusions" className="mt-4"><ExclusionsTab /></TabsContent>
        <TabsContent value="overrides" className="mt-4"><OverridesTab /></TabsContent>
        <TabsContent value="settings" className="mt-4"><SettingsTab /></TabsContent>
        <TabsContent value="maintenance" className="mt-4"><MaintenanceTab /></TabsContent>
      </Tabs>
    </div>
  );
}

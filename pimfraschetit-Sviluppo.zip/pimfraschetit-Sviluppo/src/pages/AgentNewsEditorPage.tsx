import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList,
} from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ArrowLeft, Save, Upload, Trash2, FileText, Eye, Plus, X, Image as ImageIcon, Search, Tag } from "lucide-react";
import { toast } from "sonner";
import { NewsArticleEditor } from "@/components/agent-news/NewsArticleEditor";
import { maybeOptimizePdf } from "@/lib/maybeOptimizePdf";
import { normalizeImageToBlob } from "@/lib/imageNormalize";

type LinkType = "product" | "category" | "brand" | "catalog";

interface NewsLink {
  id?: string;
  news_id?: string;
  link_type: LinkType;
  target_ref: string;
  label: string | null;
  _isNew?: boolean;
}

interface News {
  id: string;
  title: string;
  body_html: string | null;
  cover_image_url: string | null;
  pdf_url: string | null;
  pdf_filename: string | null;
  status: "draft" | "published";
  published_at: string | null;
  display_mode: "popup" | "notification";
  video_url: string | null;
  photos: string[];
  brand_id: string | null;
  brand_name: string | null;
  brand_logo_url: string | null;
}

export default function AgentNewsEditorPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [data, setData] = useState<News | null>(null);
  const [links, setLinks] = useState<NewsLink[]>([]);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState<"cover" | "pdf" | "brand_logo" | null>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);
  const pdfInputRef = useRef<HTMLInputElement>(null);
  const brandLogoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    (async () => {
      if (!id) return;
      const { data: row, error } = await supabase.from("news" as any).select("*").eq("id", id).single();
      if (error) return toast.error(error.message);
      const r: any = row;
      setData({
        ...r,
        photos: Array.isArray(r.photos) ? r.photos : [],
        video_url: r.video_url ?? null,
        brand_id: r.brand_id ?? null,
        brand_name: r.brand_name ?? null,
        brand_logo_url: r.brand_logo_url ?? null,
      });
      const { data: ls } = await supabase
        .from("news_links" as any)
        .select("id,news_id,link_type,target_ref,label")
        .eq("news_id", id)
        .order("created_at", { ascending: true });
      setLinks((ls as any[]) || []);
    })();
  }, [id]);

  if (!data) return <div className="p-6 text-muted-foreground">Caricamento…</div>;

  const update = (patch: Partial<News>) => setData({ ...data, ...patch });

  const upload = async (file: File, kind: "cover" | "pdf" | "brand_logo") => {
    setUploading(kind);
    try {
      let blob: Blob = file;
      let path: string;
      let contentType: string;
      if (kind === "cover") {
        if (!file.type.startsWith("image/")) throw new Error("Carica un'immagine");
        blob = await normalizeImageToBlob(file, 800, 450, 0.9);
        path = `cover/${id}-${Date.now()}.jpg`;
        contentType = "image/jpeg";
      } else if (kind === "brand_logo") {
        if (!file.type.startsWith("image/")) throw new Error("Carica un'immagine");
        const ext = file.name.split(".").pop() || "png";
        path = `brand-logo/${id}-${Date.now()}.${ext}`;
        contentType = file.type;
      } else {
        if (file.type !== "application/pdf") throw new Error("Carica solo PDF");
        blob = await maybeOptimizePdf(file);
        path = `pdf/${id}-${Date.now()}.pdf`;
        contentType = "application/pdf";
      }
      const { error } = await supabase.storage
        .from("news-media")
        .upload(path, blob, { contentType, upsert: true });
      if (error) throw error;
      const { data: urlData } = supabase.storage.from("news-media").getPublicUrl(path);
      const publicUrl = urlData.publicUrl;
      if (kind === "cover") update({ cover_image_url: publicUrl });
      else if (kind === "brand_logo") update({ brand_logo_url: publicUrl });
      else update({ pdf_url: publicUrl, pdf_filename: file.name });
      toast.success(
        kind === "cover" ? "Cover caricata"
        : kind === "brand_logo" ? "Logo brand caricato"
        : "PDF caricato"
      );
    } catch (e: any) {
      toast.error(`Errore: ${e.message}`);
    } finally {
      setUploading(null);
    }
  };


  const addLink = () => {
    setLinks((p) => [...p, { link_type: "product", target_ref: "", label: "", _isNew: true }]);
  };

  const updateLink = (idx: number, patch: Partial<NewsLink>) => {
    setLinks((p) => p.map((l, i) => (i === idx ? { ...l, ...patch } : l)));
  };

  const removeLink = (idx: number) => {
    setLinks((p) => p.filter((_, i) => i !== idx));
  };

  const validate = (): string | null => {
    if (!data.title.trim()) return "Il titolo è obbligatorio";
    const hasContent = !!(data.body_html?.trim()) || !!data.cover_image_url || !!data.pdf_url;
    if (!hasContent) return "Inserisci almeno un contenuto (testo, cover o PDF)";
    for (const l of links) {
      if (!l.target_ref?.trim()) return "Ogni articolo collegato deve avere un riferimento";
    }
    return null;
  };

  const save = async () => {
    const err = validate();
    if (err) return toast.error(err);
    setSaving(true);
    const payload: any = {
      title: data.title,
      body_html: data.body_html,
      cover_image_url: data.cover_image_url,
      pdf_url: data.pdf_url,
      pdf_filename: data.pdf_filename,
      status: data.status,
      display_mode: data.display_mode,
      video_url: null,
      photos: [],
      brand_id: data.brand_id,
      brand_name: data.brand_name,
      brand_logo_url: data.brand_logo_url,
    };
    if (data.status === "published" && !data.published_at) {
      payload.published_at = new Date().toISOString();
    }
    const { error } = await supabase.from("news" as any).update(payload).eq("id", id);
    if (error) {
      setSaving(false);
      return toast.error(error.message);
    }

    // Replace links: delete existing then insert all
    const { error: delErr } = await supabase.from("news_links" as any).delete().eq("news_id", id);
    if (delErr) {
      setSaving(false);
      return toast.error(delErr.message);
    }
    if (links.length > 0) {
      const insertPayload = links.map((l) => ({
        news_id: id,
        link_type: l.link_type,
        target_ref: l.target_ref.trim(),
        label: l.label || null,
      }));
      const { error: insErr } = await supabase.from("news_links" as any).insert(insertPayload);
      if (insErr) {
        setSaving(false);
        return toast.error(insErr.message);
      }
    }

    if (payload.published_at) update({ published_at: payload.published_at });
    setSaving(false);
    toast.success("News salvata");
  };

  return (
    <div className="p-6 space-y-4 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" asChild><Link to="/pim/agent-news"><ArrowLeft className="h-4 w-4" /></Link></Button>
          <h1 className="text-xl font-semibold">News</h1>
          {data.status === "published" ? <Badge>Pubblicata</Badge> : <Badge variant="secondary">Bozza</Badge>}
        </div>
        <Button onClick={save} disabled={saving}>
          <Save className="h-4 w-4 mr-2" />{saving ? "Salvataggio…" : "Salva"}
        </Button>
      </div>

      <Card className="p-4 space-y-4">
        <div>
          <Label>Titolo *</Label>
          <Input value={data.title} onChange={(e) => update({ title: e.target.value })} className="text-base font-medium" />
        </div>
        <div>
          <Label>Corpo della news</Label>
          <NewsArticleEditor newsId={id!} value={data.body_html || ""} onChange={(html) => update({ body_html: html })} />
        </div>
      </Card>

      <div className="grid md:grid-cols-2 gap-4">
        <Card className="p-4 space-y-3">
          <div>
            <Label className="text-base">Cover image</Label>
            <p className="text-xs text-muted-foreground">Verrà normalizzata a 800×450 (16:9), come mostrata nel Portale Agenti.</p>
          </div>
          {data.cover_image_url ? (
            <div className="space-y-2">
              <div className="relative w-full aspect-[16/9] rounded border overflow-hidden bg-muted">
                <img src={data.cover_image_url} alt="cover" className="absolute inset-0 w-full h-full object-cover" />
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => coverInputRef.current?.click()} disabled={uploading !== null}>
                  <Upload className="h-3 w-3 mr-1" />Sostituisci
                </Button>
                <Button size="sm" variant="ghost" onClick={() => update({ cover_image_url: null })}>
                  <Trash2 className="h-3 w-3 mr-1 text-destructive" />Rimuovi
                </Button>
              </div>
            </div>
          ) : (
            <Button variant="outline" onClick={() => coverInputRef.current?.click()} disabled={uploading !== null}>
              <ImageIcon className="h-4 w-4 mr-2" />{uploading === "cover" ? "Caricamento…" : "Carica cover"}
            </Button>
          )}
          <input
            ref={coverInputRef} type="file" accept="image/*" className="hidden"
            onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f, "cover"); e.target.value = ""; }}
          />
        </Card>

        <Card className="p-4 space-y-3">
          <Label className="text-base">Allegato PDF</Label>
          {data.pdf_url ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between border rounded p-3 bg-muted/30">
                <div className="flex items-center gap-2 truncate">
                  <FileText className="h-5 w-5 text-primary shrink-0" />
                  <a href={data.pdf_url} target="_blank" rel="noreferrer" className="text-sm hover:underline truncate">
                    {data.pdf_filename || "Visualizza PDF"}
                  </a>
                </div>
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" asChild><a href={data.pdf_url} target="_blank" rel="noreferrer"><Eye className="h-4 w-4" /></a></Button>
                  <Button size="sm" variant="ghost" onClick={() => update({ pdf_url: null, pdf_filename: null })}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
              <div>
                <Label className="text-xs">Nome visualizzato PDF</Label>
                <Input
                  value={data.pdf_filename || ""}
                  onChange={(e) => update({ pdf_filename: e.target.value })}
                  placeholder="Es. Catalogo promo autunno 2026"
                />
                <p className="text-[11px] text-muted-foreground mt-1">Alias mostrato all'agente, non il filename reale.</p>
              </div>
            </div>
          ) : (
            <Button variant="outline" onClick={() => pdfInputRef.current?.click()} disabled={uploading !== null}>
              <Upload className="h-4 w-4 mr-2" />{uploading === "pdf" ? "Caricamento…" : "Carica PDF"}
            </Button>
          )}
          <input
            ref={pdfInputRef} type="file" accept="application/pdf" className="hidden"
            onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f, "pdf"); e.target.value = ""; }}
          />
        </Card>
      </div>

      {/* Brand */}
      <BrandSection
        data={data}
        update={update}
        uploading={uploading}
        brandLogoInputRef={brandLogoInputRef}
        onUploadLogo={(f) => upload(f, "brand_logo")}
      />




      <Card className="p-4 space-y-3">
        <Label className="text-base">Modalità di visualizzazione</Label>
        <RadioGroup
          value={data.display_mode || "notification"}
          onValueChange={(v) => update({ display_mode: v as "popup" | "notification" })}
        >
          <div className="flex items-start gap-2 p-2 rounded hover:bg-muted/30">
            <RadioGroupItem value="popup" id="news-popup" className="mt-1" />
            <div>
              <Label htmlFor="news-popup" className="font-medium">Popup importante</Label>
              <p className="text-xs text-muted-foreground">Mostrato a schermo intero al login. Una volta chiuso non riappare.</p>
            </div>
          </div>
          <div className="flex items-start gap-2 p-2 rounded hover:bg-muted/30">
            <RadioGroupItem value="notification" id="news-notif" className="mt-1" />
            <div>
              <Label htmlFor="news-notif" className="font-medium">Notifica</Label>
              <p className="text-xs text-muted-foreground">Compare nell'icona delle notifiche, l'utente la apre quando vuole.</p>
            </div>
          </div>
        </RadioGroup>
      </Card>

      <Card className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <Label className="text-base">Articoli / Categorie / Brand collegati</Label>
            <p className="text-xs text-muted-foreground">I chip mostrati nel Portale Agenti che navigano alla pagina dedicata.</p>
          </div>
          <Button size="sm" variant="outline" onClick={addLink}><Plus className="h-4 w-4 mr-1" />Aggiungi</Button>
        </div>
        {links.length === 0 ? (
          <div className="text-sm text-muted-foreground italic py-4 text-center border border-dashed rounded">Nessun collegamento</div>
        ) : (
          <div className="space-y-2">
            {links.map((l, idx) => (
              <LinkRow key={idx} link={l} onChange={(p) => updateLink(idx, p)} onRemove={() => removeLink(idx)} />
            ))}
          </div>
        )}
      </Card>

      <Card className="p-4 flex items-center justify-between">
        <div>
          <Label className="text-base">Pubblicazione</Label>
          <p className="text-xs text-muted-foreground">
            Quando pubblicata, la news è visibile agli agenti.
            {data.published_at && ` Prima pubblicazione: ${new Date(data.published_at).toLocaleString("it-IT")}.`}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">{data.status === "published" ? "Pubblicata" : "Bozza"}</span>
          <Switch
            checked={data.status === "published"}
            onCheckedChange={(v) => update({ status: v ? "published" : "draft" })}
          />
        </div>
      </Card>
    </div>
  );
}

// ─────────── Link row con picker per tipo ───────────

function LinkRow({ link, onChange, onRemove }: {
  link: NewsLink;
  onChange: (p: Partial<NewsLink>) => void;
  onRemove: () => void;
}) {
  return (
    <div className="flex items-start gap-2 border rounded p-2 bg-muted/20">
      <Select value={link.link_type} onValueChange={(v) => onChange({ link_type: v as LinkType, target_ref: "", label: "" })}>
        <SelectTrigger className="w-36 shrink-0"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="product">Prodotto</SelectItem>
          <SelectItem value="category">Categoria</SelectItem>
          <SelectItem value="brand">Brand</SelectItem>
          <SelectItem value="catalog">Catalogo</SelectItem>
        </SelectContent>
      </Select>

      <div className="flex-1">
        {link.link_type === "product" && (
          <ProductPicker
            value={link.target_ref}
            label={link.label}
            onSelect={(ref, lbl) => onChange({ target_ref: ref, label: lbl })}
          />
        )}
        {link.link_type === "category" && (
          <CategoryPicker
            value={link.target_ref}
            label={link.label}
            onSelect={(ref, lbl) => onChange({ target_ref: ref, label: lbl })}
          />
        )}
        {link.link_type === "brand" && (
          <BrandPicker
            value={link.target_ref}
            label={link.label}
            onSelect={(ref, lbl) => onChange({ target_ref: ref, label: lbl })}
          />
        )}
        {link.link_type === "catalog" && (
          <CatalogPicker
            value={link.target_ref}
            label={link.label}
            onSelect={(ref, lbl) => onChange({ target_ref: ref, label: lbl })}
          />
        )}
      </div>

      <Button size="sm" variant="ghost" onClick={onRemove}><X className="h-4 w-4 text-destructive" /></Button>
    </div>
  );
}

function ProductPicker({ value, label, onSelect }: { value: string; label: string | null; onSelect: (ref: string, label: string) => void }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [items, setItems] = useState<{ cdpar: string; depar: string }[]>([]);

  useEffect(() => {
    if (!open) return;
    const t = setTimeout(async () => {
      const term = q.trim();
      let query = supabase.from("archivio_articoli_fraschetti").select("cdpar,depar").limit(30);
      if (term) {
        query = query.or(`cdpar.ilike.%${term}%,depar.ilike.%${term}%`);
      }
      const { data } = await query;
      setItems(((data as any[]) || []).map((r) => ({ cdpar: r.cdpar, depar: r.depar || "" })));
    }, 200);
    return () => clearTimeout(t);
  }, [q, open]);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" className="w-full justify-start font-normal">
          <Search className="h-3 w-3 mr-2 shrink-0 text-muted-foreground" />
          {value ? <span className="truncate">{label || value}</span> : <span className="text-muted-foreground">Cerca articolo per codice o descrizione…</span>}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="p-0 w-[400px]" align="start">
        <Command shouldFilter={false}>
          <CommandInput placeholder="Cerca…" value={q} onValueChange={setQ} />
          <CommandList>
            <CommandEmpty>Nessun risultato</CommandEmpty>
            <CommandGroup>
              {items.map((it) => (
                <CommandItem
                  key={it.cdpar}
                  onSelect={() => { onSelect(it.cdpar, `${it.cdpar} — ${it.depar}`); setOpen(false); }}
                >
                  <span className="font-mono text-xs mr-2">{it.cdpar}</span>
                  <span className="truncate">{it.depar}</span>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

function CategoryPicker({ value, label, onSelect }: { value: string; label: string | null; onSelect: (ref: string, label: string) => void }) {
  const [items, setItems] = useState<{ code: string; name: string }[]>([]);
  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("lookup_values" as any)
        .select("code,label")
        .eq("category", "clmer")
        .eq("is_active", true)
        .order("code");
      setItems(((data as any[]) || []).map((r) => ({ code: r.code, name: r.label || r.code })));
    })();
  }, []);
  return (
    <Select value={value || undefined} onValueChange={(v) => {
      const it = items.find((x) => x.code === v);
      onSelect(v, it?.name || v);
    }}>
      <SelectTrigger><SelectValue placeholder="Seleziona settore (clmer)…" /></SelectTrigger>
      <SelectContent>
        {items.map((it) => (
          <SelectItem key={it.code} value={it.code}>
            <span className="font-mono text-xs mr-2">{it.code}</span>{it.name}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

function BrandPicker({ value, label, onSelect }: { value: string; label: string | null; onSelect: (ref: string, label: string) => void }) {
  const [items, setItems] = useState<{ clas2: string; name: string }[]>([]);
  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("archivio_brand_fraschetti")
        .select("clas2,display_name,nome_as400_brand")
        .order("clas2");
      setItems(((data as any[]) || []).map((r) => ({ clas2: r.clas2, name: r.display_name || r.nome_as400_brand || r.clas2 })));
    })();
  }, []);
  return (
    <Select value={value || undefined} onValueChange={(v) => {
      const it = items.find((x) => x.clas2 === v);
      onSelect(v, it?.name || v);
    }}>
      <SelectTrigger><SelectValue placeholder="Seleziona brand…" /></SelectTrigger>
      <SelectContent className="max-h-80">
        {items.map((it) => (
          <SelectItem key={it.clas2} value={it.clas2}>
            <span className="font-mono text-xs mr-2">{it.clas2}</span>{it.name}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

function CatalogPicker({ value, label, onSelect }: { value: string; label: string | null; onSelect: (ref: string, label: string) => void }) {
  const [items, setItems] = useState<{ id: string; name: string }[]>([]);
  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("b2b_catalogs")
        .select("id,name")
        .order("sort_order", { ascending: true });
      setItems(((data as any[]) || []).map((r) => ({ id: r.id, name: r.name || r.id })));
    })();
  }, []);
  return (
    <Select value={value || undefined} onValueChange={(v) => {
      const it = items.find((x) => x.id === v);
      onSelect(v, it?.name || v);
    }}>
      <SelectTrigger><SelectValue placeholder="Seleziona catalogo…" /></SelectTrigger>
      <SelectContent className="max-h-80">
        {items.map((it) => (
          <SelectItem key={it.id} value={it.id}>{it.name}</SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

// ─────────── Brand section (selettore + override manuale) ───────────

function BrandSection({
  data,
  update,
  uploading,
  brandLogoInputRef,
  onUploadLogo,
}: {
  data: News;
  update: (p: Partial<News>) => void;
  uploading: string | null;
  brandLogoInputRef: React.RefObject<HTMLInputElement>;
  onUploadLogo: (f: File) => void;
}) {
  const [items, setItems] = useState<{ clas2: string; name: string; logo: string | null }[]>([]);

  useEffect(() => {
    (async () => {
      const { data: rows } = await supabase
        .from("archivio_brand_fraschetti")
        .select("clas2,display_name,nome_as400_brand")
        .order("clas2");
      const list = ((rows as any[]) || []).map((r) => ({
        clas2: r.clas2,
        name: r.display_name || r.nome_as400_brand || r.clas2,
        logo: null as string | null,
      }));
      // arricchisci con logo da b2b_brands
      const { data: logos } = await supabase
        .from("b2b_brands")
        .select("clas2,logo_url");
      const logoMap = new Map<string, string>();
      ((logos as any[]) || []).forEach((b) => { if (b.clas2 && b.logo_url) logoMap.set(b.clas2, b.logo_url); });
      list.forEach((it) => { it.logo = logoMap.get(it.clas2) || null; });
      setItems(list);
    })();
  }, []);

  const selectFromCatalog = (clas2: string) => {
    const it = items.find((x) => x.clas2 === clas2);
    if (!it) return;
    update({ brand_name: it.name, brand_logo_url: it.logo });
  };

  return (
    <Card className="p-4 space-y-3">
      <div>
        <Label className="text-base">Brand</Label>
        <p className="text-xs text-muted-foreground">
          Mostrato nel Portale Agenti accanto al titolo. Se è presente il logo viene usato, altrimenti il nome testuale.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-3">
        <div>
          <Label className="text-xs">Seleziona dall'archivio brand</Label>
          <Select value={undefined} onValueChange={selectFromCatalog}>
            <SelectTrigger><SelectValue placeholder="Cerca brand…" /></SelectTrigger>
            <SelectContent className="max-h-80">
              {items.map((it) => (
                <SelectItem key={it.clas2} value={it.clas2}>
                  <span className="font-mono text-xs mr-2">{it.clas2}</span>{it.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-[11px] text-muted-foreground mt-1">Compila automaticamente nome e logo (se disponibili).</p>
        </div>

        <div>
          <Label className="text-xs">Nome brand</Label>
          <Input
            value={data.brand_name || ""}
            onChange={(e) => update({ brand_name: e.target.value || null })}
            placeholder="Es. Bosch"
          />
        </div>
      </div>

      <div className="grid md:grid-cols-[140px,1fr,auto] gap-3 items-center">
        <div className="aspect-square bg-muted rounded border flex items-center justify-center overflow-hidden">
          {data.brand_logo_url ? (
            <img src={data.brand_logo_url} alt="brand-logo" className="max-w-full max-h-full object-contain p-2" />
          ) : (
            <Tag className="h-8 w-8 text-muted-foreground" />
          )}
        </div>
        <div className="space-y-1">
          <Label className="text-xs">URL logo brand</Label>
          <Input
            value={data.brand_logo_url || ""}
            onChange={(e) => update({ brand_logo_url: e.target.value || null })}
            placeholder="https://…"
          />
        </div>
        <div className="flex flex-col gap-1">
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={() => brandLogoInputRef.current?.click()}
            disabled={uploading !== null}
          >
            <Upload className="h-3 w-3 mr-1" />{uploading === "brand_logo" ? "…" : "Carica"}
          </Button>
          {data.brand_logo_url && (
            <Button type="button" size="sm" variant="ghost" onClick={() => update({ brand_logo_url: null })}>
              <Trash2 className="h-3 w-3 mr-1 text-destructive" />Rimuovi
            </Button>
          )}
        </div>
        <input
          ref={brandLogoInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => { const f = e.target.files?.[0]; if (f) onUploadLogo(f); e.target.value = ""; }}
        />
      </div>
    </Card>
  );
}


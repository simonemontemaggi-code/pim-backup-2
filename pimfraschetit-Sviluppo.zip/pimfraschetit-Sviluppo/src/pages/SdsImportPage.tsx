import { useMemo, useState } from "react";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CheckCircle2, AlertTriangle, XCircle, FileText, Download, Trash2, Loader2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import {
  parseDocFilename,
  validateCdpars,
  uploadDocForFile,
  formatBytes,
  DOC_KINDS,
  type DocKind,
} from "@/lib/sdsImport";
import { optimizePdf } from "@/lib/pdfOptimizer";
import { runWithConcurrency } from "@/lib/mediaUpload";
import { downloadXlsx } from "@/lib/xlsxExport";

type RowStatus = "pending" | "processing" | "ok" | "warning" | "error";

interface Row {
  id: string;
  file: File;
  parsedCdpars: string[];
  parseError?: string;
  validCdpars: string[];
  invalidCdpars: string[];
  status: RowStatus;
  message?: string;
  sizeOriginal?: number;
  sizeStep1?: number;
  sizeStep2?: number;
  sizeFinal?: number;
  reused?: boolean;
}

const newId = () => Math.random().toString(36).slice(2, 10);

interface Props {
  kind?: DocKind;
}

export default function SdsImportPage({ kind = "sds" }: Props) {
  const cfg = DOC_KINDS[kind];
  const [rows, setRows] = useState<Row[]>([]);
  const [running, setRunning] = useState(false);
  const [validating, setValidating] = useState(false);
  const [progress, setProgress] = useState(0);

  const stats = useMemo(() => {
    const ok = rows.filter((r) => r.status === "ok").length;
    const warn = rows.filter((r) => r.status === "warning").length;
    const err = rows.filter((r) => r.status === "error").length;
    const articlesTouched = rows
      .filter((r) => r.status === "ok" || r.status === "warning")
      .reduce((acc, r) => acc + r.validCdpars.length, 0);
    return { ok, warn, err, articlesTouched, total: rows.length };
  }, [rows]);

  const onFiles = async (files: File[]) => {
    // Initial parsing (sync)
    const initial: Row[] = files.map((f) => {
      const parsed = parseDocFilename(f.name, kind);
      return {
        id: newId(),
        file: f,
        parsedCdpars: parsed.cdpars,
        parseError: parsed.error,
        validCdpars: [],
        invalidCdpars: [],
        status: parsed.error ? "error" : "pending",
        message: parsed.error,
      };
    });

    setRows((prev) => [...prev, ...initial]);

    // Validate cdpars in DB (batched across all newly added files)
    setValidating(true);
    try {
      const allCdpars = Array.from(
        new Set(initial.filter((r) => !r.parseError).flatMap((r) => r.parsedCdpars)),
      );
      const { valid } = await validateCdpars(allCdpars);

      setRows((prev) =>
        prev.map((r) => {
          if (!initial.find((i) => i.id === r.id)) return r;
          if (r.parseError) return r;
          const v = r.parsedCdpars.filter((c) => valid.has(c.trim()));
          const inv = r.parsedCdpars.filter((c) => !valid.has(c.trim()));
          if (v.length === 0) {
            return {
              ...r,
              validCdpars: v,
              invalidCdpars: inv,
              status: "error",
              message: `Nessun cdpar valido (mancanti: ${inv.join(", ")})`,
            };
          }
          if (inv.length > 0) {
            return {
              ...r,
              validCdpars: v,
              invalidCdpars: inv,
              status: "error",
              message: `Cdpar inesistenti: ${inv.join(", ")}`,
            };
          }
          return { ...r, validCdpars: v, invalidCdpars: [] };
        }),
      );
    } catch (e: any) {
      toast({ title: "Errore validazione", description: e.message, variant: "destructive" });
    } finally {
      setValidating(false);
    }
  };

  const removeRow = (id: string) => setRows((prev) => prev.filter((r) => r.id !== id));
  const clearAll = () => setRows([]);

  const importable = rows.filter((r) => r.status === "pending");

  const runImport = async () => {
    if (importable.length === 0) return;
    setRunning(true);
    setProgress(0);

    let done = 0;
    await runWithConcurrency(importable, 4, async (row) => {
      setRows((prev) =>
        prev.map((r) => (r.id === row.id ? { ...r, status: "processing" } : r)),
      );
      try {
        const opt = await optimizePdf(row.file);
        if (opt.status === "rejected") {
          setRows((prev) =>
            prev.map((r) =>
              r.id === row.id
                ? {
                    ...r,
                    status: "error",
                    message: `File troppo grande dopo ottimizzazione (${formatBytes(opt.blob.size)} > 5 MB). Ottimizzalo a mano con Acrobat.`,
                    sizeOriginal: opt.sizeOriginal,
                    sizeStep1: opt.sizeStep1,
                    sizeStep2: opt.sizeStep2,
                    sizeFinal: opt.blob.size,
                  }
                : r,
            ),
          );
          return;
        }

        const { uploaded, reused } = await uploadDocForFile({
          kind,
          optimized: opt.blob,
          cdpars: row.validCdpars,
          originalFilename: row.file.name,
        });

        setRows((prev) =>
          prev.map((r) =>
            r.id === row.id
              ? {
                  ...r,
                  status: opt.status === "warning" ? "warning" : "ok",
                  message:
                    opt.status === "warning"
                      ? `Caricato (${formatBytes(opt.blob.size)} — non scendibile sotto 1 MB)`
                      : `Caricato su ${uploaded} articoli${reused ? " (file riusato dal pool condiviso)" : ""}`,
                  sizeOriginal: opt.sizeOriginal,
                  sizeStep1: opt.sizeStep1,
                  sizeStep2: opt.sizeStep2,
                  sizeFinal: opt.blob.size,
                  reused,
                }
              : r,
          ),
        );
      } catch (e: any) {
        setRows((prev) =>
          prev.map((r) =>
            r.id === row.id ? { ...r, status: "error", message: e.message ?? String(e) } : r,
          ),
        );
      } finally {
        done++;
        setProgress((done / importable.length) * 100);
      }
    });

    setRunning(false);
    toast({ title: "Import completato", description: `${done} file processati.` });
  };

  const exportReport = () => {
    const data = rows.map((r) => ({
      file: r.file.name,
      stato: r.status,
      messaggio: r.message ?? "",
      cdpar_validi: r.validCdpars.join("|"),
      cdpar_invalidi: r.invalidCdpars.join("|"),
      size_originale: r.sizeOriginal != null ? formatBytes(r.sizeOriginal) : "",
      size_step1: r.sizeStep1 != null ? formatBytes(r.sizeStep1) : "",
      size_step2: r.sizeStep2 != null ? formatBytes(r.sizeStep2) : "",
      size_finale: r.sizeFinal != null ? formatBytes(r.sizeFinal) : "",
      file_riusato: r.reused ? "sì" : "",
    }));
    downloadXlsx(`${kind}_import_${new Date().toISOString().slice(0, 10)}.xlsx`, data, { sheetName: "Import" });
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold">Import massivo {cfg.label}</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Trascina i PDF nominati <code className="bg-muted px-1 rounded">CODART_{cfg.marker}.pdf</code> oppure{" "}
          <code className="bg-muted px-1 rounded">CODART_CODART_{cfg.marker}.pdf</code> per allegarli a uno o più articoli.
          File condivisi tra più articoli vengono salvati una sola volta nello storage (deduplica via hash).
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">1. Carica i file</CardTitle>
          <CardDescription>
            PDF only. Limite 5 MB per file dopo ottimizzazione automatica (target 1 MB).
          </CardDescription>
        </CardHeader>
        <CardContent>
          <FileDropZone
            accept="application/pdf,.pdf"
            multiple
            disabled={running}
            label="Clicca o trascina i PDF qui"
            onFiles={onFiles}
          />
        </CardContent>
      </Card>

      {rows.length > 0 && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base">2. Anteprima e import</CardTitle>
              <CardDescription>
                {rows.length} file • {importable.length} pronti • {stats.err} errori
                {validating && (
                  <span className="ml-2 inline-flex items-center gap-1 text-xs">
                    <Loader2 className="h-3 w-3 animate-spin" /> validazione cdpar...
                  </span>
                )}
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={clearAll} disabled={running}>
                <Trash2 className="h-4 w-4 mr-1" /> Svuota
              </Button>
              <Button
                size="sm"
                onClick={runImport}
                disabled={running || validating || importable.length === 0}
              >
                {running ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-1 animate-spin" /> Importazione...
                  </>
                ) : (
                  <>Avvia import ({importable.length})</>
                )}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {running && <Progress value={progress} />}

            <ScrollArea className="h-[400px] border rounded-md">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-muted/50 text-xs">
                  <tr>
                    <th className="text-left p-2 w-8"></th>
                    <th className="text-left p-2">File</th>
                    <th className="text-left p-2">Articoli</th>
                    <th className="text-right p-2">Size</th>
                    <th className="text-left p-2">Note</th>
                    <th className="p-2 w-8"></th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.id} className="border-t">
                      <td className="p-2">
                        <StatusIcon status={r.status} />
                      </td>
                      <td className="p-2 font-mono text-xs">
                        <FileText className="inline h-3 w-3 mr-1 text-muted-foreground" />
                        {r.file.name}
                      </td>
                      <td className="p-2">
                        {r.validCdpars.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {r.validCdpars.map((c) => (
                              <Badge key={c} variant="secondary" className="font-mono text-xs">
                                {c.trim()}
                              </Badge>
                            ))}
                          </div>
                        )}
                        {r.invalidCdpars.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {r.invalidCdpars.map((c) => (
                              <Badge key={c} variant="destructive" className="font-mono text-xs">
                                {c.trim()}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="p-2 text-right text-xs text-muted-foreground tabular-nums">
                        {r.sizeFinal != null
                          ? r.sizeFinal !== r.sizeOriginal
                            ? `${formatBytes(r.sizeOriginal!)} → ${formatBytes(r.sizeFinal)}`
                            : formatBytes(r.sizeFinal)
                          : formatBytes(r.file.size)}
                      </td>
                      <td className="p-2 text-xs text-muted-foreground max-w-[280px]">
                        {r.message}
                      </td>
                      <td className="p-2">
                        {!running && (
                          <button
                            onClick={() => removeRow(r.id)}
                            className="text-muted-foreground hover:text-destructive"
                            aria-label="Rimuovi"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </ScrollArea>

            {(stats.ok > 0 || stats.warn > 0 || stats.err > 0) && (
              <div className="flex flex-wrap gap-2 items-center pt-2 border-t">
                <Badge className="bg-green-600 hover:bg-green-600">{stats.ok} OK</Badge>
                <Badge className="bg-amber-500 hover:bg-amber-500">{stats.warn} warning</Badge>
                <Badge variant="destructive">{stats.err} errori</Badge>
                <Badge variant="outline">{stats.articlesTouched} articoli aggiornati</Badge>
                <div className="ml-auto">
                  <Button variant="outline" size="sm" onClick={exportReport}>
                    <Download className="h-4 w-4 mr-1" /> Scarica report CSV
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function StatusIcon({ status }: { status: RowStatus }) {
  switch (status) {
    case "ok":
      return <CheckCircle2 className="h-4 w-4 text-green-600" />;
    case "warning":
      return <AlertTriangle className="h-4 w-4 text-amber-500" />;
    case "error":
      return <XCircle className="h-4 w-4 text-destructive" />;
    case "processing":
      return <Loader2 className="h-4 w-4 animate-spin text-primary" />;
    default:
      return <FileText className="h-4 w-4 text-muted-foreground" />;
  }
}

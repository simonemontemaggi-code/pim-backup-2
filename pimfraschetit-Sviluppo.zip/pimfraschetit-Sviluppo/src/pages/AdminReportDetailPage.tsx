import { useMemo, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/lib/permissions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft, Save, Upload, Trash2, ArrowUp, ArrowDown, Eye } from "lucide-react";
import { parseReportFile, parseDelimitedText, toColumnKey, formatReportValue, type ParsedGrid } from "@/lib/reportRowsParser";

interface Report {
  id: string;
  ref_id: number;
  title: string;
  description: string | null;
  date_start: string | null;
  date_end: string | null;
  sort_order: number;
  audience: string;
  show_only_if_present: boolean;
  show_only_own: boolean;
  hidden: boolean;
  hide_recipient_name: boolean;
}

interface ReportColumn {
  id: string;
  report_id: string;
  col_key: string;
  label: string;
  suffix: string | null;
  group_label: string | null;
  align: string;
  visible: boolean;
  sort_order: number;
}

interface ReportDataRow {
  id: string;
  recipient_code: string;
  recipient_name: string | null;
  values: Record<string, unknown>;
  sort_order: number;
}

export default function AdminReportDetailPage() {
  const { id = "" } = useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { can } = usePermissions();
  const canWrite = can("write", "admin_reports");

  const [head, setHead] = useState<Report | null>(null);
  const [importOpen, setImportOpen] = useState(false);
  const [previewCode, setPreviewCode] = useState("");

  const { data: report } = useQuery({
    queryKey: ["admin_report", id],
    enabled: !!id,
    queryFn: async () => {
      const { data, error } = await supabase.from("reports").select("*").eq("id", id).single();
      if (error) throw error;
      setHead(data as Report);
      return data as Report;
    },
  });

  const { data: columns = [] } = useQuery({
    queryKey: ["admin_report_columns", id],
    enabled: !!id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("report_columns")
        .select("*")
        .eq("report_id", id)
        .order("sort_order");
      if (error) throw error;
      return (data ?? []) as ReportColumn[];
    },
  });

  const { data: rows = [] } = useQuery({
    queryKey: ["admin_report_rows", id],
    enabled: !!id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("report_rows")
        .select("id,recipient_code,recipient_name,values,sort_order")
        .eq("report_id", id)
        .order("sort_order")
        .limit(5000);
      if (error) throw error;
      return (data ?? []) as ReportDataRow[];
    },
  });

  const saveHead = useMutation({
    mutationFn: async () => {
      if (!head) return;
      const { error } = await supabase
        .from("reports")
        .update({
          title: head.title,
          description: head.description,
          date_start: head.date_start || null,
          date_end: head.date_end || null,
          
          audience: head.audience,
          show_only_if_present: head.show_only_if_present,
          show_only_own: head.show_only_own,
          hidden: head.hidden,
          hide_recipient_name: head.hide_recipient_name,
        })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Report salvato" });
      qc.invalidateQueries({ queryKey: ["admin_report", id] });
      qc.invalidateQueries({ queryKey: ["admin_reports"] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const saveColumn = useMutation({
    mutationFn: async (col: Partial<ReportColumn> & { id: string }) => {
      const { id: colId, ...patch } = col;
      const { error } = await supabase.from("report_columns").update(patch).eq("id", colId);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin_report_columns", id] }),
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const bulkAlign = useMutation({
    mutationFn: async (align: string) => {
      const { error } = await supabase.from("report_columns").update({ align }).eq("report_id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin_report_columns", id] });
      toast({ title: "Allineamento applicato a tutte le colonne" });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });



  const moveColumn = async (index: number, dir: -1 | 1) => {
    const target = columns[index + dir];
    const current = columns[index];
    if (!target || !current) return;
    await supabase.from("report_columns").update({ sort_order: target.sort_order }).eq("id", current.id);
    await supabase.from("report_columns").update({ sort_order: current.sort_order }).eq("id", target.id);
    qc.invalidateQueries({ queryKey: ["admin_report_columns", id] });
  };

  const deleteReport = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("reports").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin_reports"] });
      navigate("/pim/reports");
    },
  });

  const clearRows = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("report_rows").delete().eq("report_id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin_report_rows", id] }),
  });

  const visibleColumns = useMemo(() => columns.filter((c) => c.visible), [columns]);

  // Nominativo risolto automaticamente dall'anagrafica in base al codice
  const codes = useMemo(
    () => Array.from(new Set(rows.map((r) => r.recipient_code.trim()).filter(Boolean))),
    [rows],
  );

  const { data: nameMap = {} } = useQuery({
    queryKey: ["admin_report_names", report?.audience, codes],
    enabled: codes.length > 0 && !!report,
    queryFn: async () => {
      const map: Record<string, string> = {};
      if (report?.audience === "customer") {
        const { data, error } = await supabase
          .from("customers")
          .select("customer_code,company_name,company_full_name")
          .in("customer_code", codes);
        if (error) throw error;
        (data ?? []).forEach((c) => {
          const n = (c.company_name || c.company_full_name || "").trim();
          if (n) map[(c.customer_code ?? "").trim()] = n;
        });
      } else {
        const { data, error } = await supabase
          .from("profiles")
          .select("agent_code,full_name")
          .in("agent_code", codes);
        if (error) throw error;
        (data ?? []).forEach((p) => {
          const n = (p.full_name ?? "").trim();
          if (n && p.agent_code) map[p.agent_code.trim()] = n;
        });
      }
      return map;
    },
  });

  const nameFor = (code: string) => nameMap[code.trim()] ?? null;

  const previewRows = useMemo(() => {
    if (!report) return [];
    const code = previewCode.trim();
    const present = rows.some((r) => r.recipient_code.trim() === code);
    if (report.hidden) return [];
    if (report.show_only_if_present && !present) return [];
    return report.show_only_own ? rows.filter((r) => r.recipient_code.trim() === code) : rows;
  }, [report, rows, previewCode]);

  if (!report || !head) {
    return <div className="p-6 text-muted-foreground">Caricamento...</div>;
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/pim/reports")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-xl font-semibold">{head.title}</h1>
            <p className="text-xs text-muted-foreground font-mono">ID {report.ref_id}</p>
          </div>
        </div>
        {canWrite && (
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => deleteReport.mutate()}>
              <Trash2 className="h-4 w-4 mr-2" /> Elimina
            </Button>
            <Button onClick={() => saveHead.mutate()} disabled={saveHead.isPending}>
              <Save className="h-4 w-4 mr-2" /> Salva
            </Button>
          </div>
        )}
      </div>

      <Tabs defaultValue="head">
        <TabsList>
          <TabsTrigger value="head">Testata</TabsTrigger>
          <TabsTrigger value="columns">Colonne ({columns.length})</TabsTrigger>
          <TabsTrigger value="rows">Righe ({rows.length})</TabsTrigger>
          <TabsTrigger value="preview">Anteprima</TabsTrigger>
        </TabsList>

        <TabsContent value="head" className="space-y-4 pt-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Dati report</CardTitle></CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2 md:col-span-2">
                <Label>Titolo</Label>
                <Input disabled={!canWrite} value={head.title} onChange={(e) => setHead({ ...head, title: e.target.value })} />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>Descrizione</Label>
                <Textarea disabled={!canWrite} value={head.description ?? ""} onChange={(e) => setHead({ ...head, description: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Data inizio</Label>
                <Input type="date" disabled={!canWrite} value={head.date_start ?? ""} onChange={(e) => setHead({ ...head, date_start: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Data fine</Label>
                <Input type="date" disabled={!canWrite} value={head.date_end ?? ""} onChange={(e) => setHead({ ...head, date_end: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Destinatari</Label>
                <Select disabled={!canWrite} value={head.audience} onValueChange={(v) => setHead({ ...head, audience: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="agent">Agenti</SelectItem>
                    <SelectItem value="customer">Clienti</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Regole di visibilità</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              {([
                ["show_only_if_present", "Mostra dati solo se il destinatario è in lista", "Se il codice non compare tra le righe, non vede nulla."],
                ["show_only_own", "Mostra solo i dati del singolo utente", "Ogni destinatario vede solo le proprie righe."],
                ["hidden", "Non mostrare", "Report sospeso: nascosto a tutti."],
                ["hide_recipient_name", "Non mostrare il nominativo", "Nasconde la colonna con il nome del destinatario."],
              ] as const).map(([key, label, hint]) => (
                <div key={key} className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-sm font-medium">{label}</p>
                    <p className="text-xs text-muted-foreground">{hint}</p>
                  </div>
                  <Switch
                    disabled={!canWrite}
                    checked={head[key]}
                    onCheckedChange={(v) => setHead({ ...head, [key]: v })}
                  />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="columns" className="pt-4 space-y-3">
          {canWrite && columns.length > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Allinea tutte a:</span>
              <Button variant="outline" size="sm" disabled={bulkAlign.isPending} onClick={() => bulkAlign.mutate("left")}>Sinistra</Button>
              <Button variant="outline" size="sm" disabled={bulkAlign.isPending} onClick={() => bulkAlign.mutate("center")}>Centro</Button>
              <Button variant="outline" size="sm" disabled={bulkAlign.isPending} onClick={() => bulkAlign.mutate("right")}>Destra</Button>
            </div>
          )}
          <Card>

            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-24">Ordine</TableHead>
                    <TableHead>Etichetta</TableHead>
                    <TableHead className="w-28">Suffisso</TableHead>
                    <TableHead className="w-36">Gruppo</TableHead>
                    <TableHead className="w-36">Allineamento</TableHead>
                    <TableHead className="w-24">In lista</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {columns.length === 0 && (
                    <TableRow><TableCell colSpan={6} className="text-muted-foreground">Nessuna colonna: importa un file nella scheda Righe.</TableCell></TableRow>
                  )}
                  {columns.map((c, i) => (
                    <TableRow key={c.id}>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7" disabled={!canWrite || i === 0} onClick={() => moveColumn(i, -1)}>
                            <ArrowUp className="h-3.5 w-3.5" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7" disabled={!canWrite || i === columns.length - 1} onClick={() => moveColumn(i, 1)}>
                            <ArrowDown className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Input
                          disabled={!canWrite}
                          defaultValue={c.label}
                          onBlur={(e) => e.target.value !== c.label && saveColumn.mutate({ id: c.id, label: e.target.value })}
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          disabled={!canWrite}
                          defaultValue={c.suffix ?? ""}
                          placeholder="€ / %"
                          onBlur={(e) => e.target.value !== (c.suffix ?? "") && saveColumn.mutate({ id: c.id, suffix: e.target.value || null })}
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          disabled={!canWrite}
                          defaultValue={c.group_label ?? ""}
                          onBlur={(e) => e.target.value !== (c.group_label ?? "") && saveColumn.mutate({ id: c.id, group_label: e.target.value || null })}
                        />
                      </TableCell>
                      <TableCell>
                        <Select disabled={!canWrite} value={c.align} onValueChange={(v) => saveColumn.mutate({ id: c.id, align: v })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="left">Sinistra</SelectItem>
                            <SelectItem value="center">Centro</SelectItem>
                            <SelectItem value="right">Destra</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Switch disabled={!canWrite} checked={c.visible} onCheckedChange={(v) => saveColumn.mutate({ id: c.id, visible: v })} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rows" className="space-y-4 pt-4">
          {canWrite && (
            <div className="flex gap-2">
              <Button onClick={() => setImportOpen(true)}>
                <Upload className="h-4 w-4 mr-2" /> Importa dati
              </Button>
              <Button variant="outline" disabled={rows.length === 0} onClick={() => clearRows.mutate()}>
                <Trash2 className="h-4 w-4 mr-2" /> Svuota righe
              </Button>
            </div>
          )}
          <Card>
            <CardContent className="p-0 overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-28">{head.audience === "customer" ? "Cod. cliente" : "Cod. agente"}</TableHead>
                    <TableHead className="w-56">Nominativo</TableHead>
                    {visibleColumns.map((c) => (
                      <TableHead key={c.id} className={c.align === "right" ? "text-right" : c.align === "center" ? "text-center" : ""}>
                        {c.group_label ? `${c.group_label} · ` : ""}{c.label}
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.length === 0 && (
                    <TableRow><TableCell colSpan={2 + visibleColumns.length} className="text-muted-foreground">Nessuna riga caricata</TableCell></TableRow>
                  )}
                  {rows.map((r) => (
                    <TableRow key={r.id}>
                      <TableCell className="font-mono text-xs">{r.recipient_code}</TableCell>
                      <TableCell>
                        {nameFor(r.recipient_code) ?? (
                          <span className="text-xs text-amber-600">nominativo non trovato</span>
                        )}
                      </TableCell>
                      {visibleColumns.map((c) => (
                        <TableCell key={c.id} className={c.align === "right" ? "text-right" : c.align === "center" ? "text-center" : ""}>
                          {formatReportValue(r.values?.[c.col_key], c.suffix)}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preview" className="space-y-4 pt-4">
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Eye className="h-4 w-4" /> Vedi come</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-end gap-3">
                <div className="space-y-2 max-w-xs">
                  <Label>{head.audience === "customer" ? "Codice cliente" : "Codice agente"}</Label>
                  <Input value={previewCode} onChange={(e) => setPreviewCode(e.target.value)} placeholder="es. 04" />
                </div>
                <Badge variant={previewRows.length ? "default" : "secondary"}>
                  {previewRows.length ? `${previewRows.length} righe visibili` : "Non vede nulla"}
                </Badge>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    {!head.hide_recipient_name && <TableHead className="w-56">Nominativo</TableHead>}
                    {visibleColumns.map((c) => (
                      <TableHead key={c.id} className={c.align === "right" ? "text-right" : c.align === "center" ? "text-center" : ""}>
                        {c.label}
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {previewRows.map((r) => (
                    <TableRow key={r.id}>
                      {!head.hide_recipient_name && <TableCell>{nameFor(r.recipient_code) ?? "—"}</TableCell>}
                      {visibleColumns.map((c) => (
                        <TableCell key={c.id} className={c.align === "right" ? "text-right" : c.align === "center" ? "text-center" : ""}>
                          {formatReportValue(r.values?.[c.col_key], c.suffix)}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <ImportDialog
        open={importOpen}
        onClose={() => setImportOpen(false)}
        reportId={id}
        audience={head.audience}
        existingColumns={columns}
        onDone={() => {
          qc.invalidateQueries({ queryKey: ["admin_report_columns", id] });
          qc.invalidateQueries({ queryKey: ["admin_report_rows", id] });
        }}
      />
    </div>
  );
}

function ImportDialog({
  open,
  onClose,
  reportId,
  audience,
  existingColumns,
  onDone,
}: {
  open: boolean;
  onClose: () => void;
  reportId: string;
  audience: string;
  existingColumns: ReportColumn[];
  onDone: () => void;
}) {
  const [grid, setGrid] = useState<ParsedGrid | null>(null);
  const [pasted, setPasted] = useState("");
  const [codeIdx, setCodeIdx] = useState<string>("0");
  const [mode, setMode] = useState<"replace" | "append">("replace");
  const [busy, setBusy] = useState(false);

  const reset = () => {
    setGrid(null);
    setPasted("");
    setCodeIdx("0");
  };

  const handleFile = async (file: File) => {
    try {
      const parsed = await parseReportFile(file);
      setGrid(parsed);
      const guess = parsed.headers.findIndex((h) => /^(ag|agente|cod|codice|cliente)/i.test(h));
      if (guess >= 0) setCodeIdx(String(guess));
    } catch (e) {
      toast({ title: "Errore lettura file", description: (e as Error).message, variant: "destructive" });
    }
  };

  const previewCodes = useMemo(() => {
    if (!grid) return [];
    const ci = Number(codeIdx);
    return Array.from(new Set(grid.rows.map((r) => (r[ci] ?? "").trim()).filter(Boolean))).slice(0, 200);
  }, [grid, codeIdx]);

  const { data: previewNames = {} } = useQuery({
    queryKey: ["report_import_names", audience, previewCodes],
    enabled: previewCodes.length > 0,
    queryFn: async () => {
      const map: Record<string, string> = {};
      if (audience === "customer") {
        const { data } = await supabase
          .from("customers")
          .select("customer_code,company_name,company_full_name")
          .in("customer_code", previewCodes);
        (data ?? []).forEach((c) => {
          const n = (c.company_name || c.company_full_name || "").trim();
          if (n) map[(c.customer_code ?? "").trim()] = n;
        });
      } else {
        const { data } = await supabase
          .from("profiles")
          .select("agent_code,full_name")
          .in("agent_code", previewCodes);
        (data ?? []).forEach((p) => {
          const n = (p.full_name ?? "").trim();
          if (n && p.agent_code) map[p.agent_code.trim()] = n;
        });
      }
      return map;
    },
  });

  const unresolved = previewCodes.filter((c) => !previewNames[c]).length;

  const run = async () => {
    if (!grid) return;
    setBusy(true);
    try {
      const ci = Number(codeIdx);
      const ni = -1;
      const dataIdx = grid.headers.map((_, i) => i).filter((i) => i !== ci && i !== ni);

      // colonne: crea quelle mancanti
      const byKey = new Map(existingColumns.map((c) => [c.col_key, c]));
      let nextOrder = existingColumns.length ? Math.max(...existingColumns.map((c) => c.sort_order)) + 1 : 0;
      const newCols = dataIdx
        .map((i) => ({ i, key: toColumnKey(grid.headers[i], i) }))
        .filter(({ key }) => !byKey.has(key))
        .map(({ i, key }) => ({
          report_id: reportId,
          col_key: key,
          label: grid.headers[i],
          align: "right",
          visible: true,
          sort_order: nextOrder++,
        }));
      if (newCols.length) {
        const { error } = await supabase.from("report_columns").insert(newCols);
        if (error) throw error;
      }

      if (mode === "replace") {
        const { error } = await supabase.from("report_rows").delete().eq("report_id", reportId);
        if (error) throw error;
      }

      const payload = grid.rows
        .filter((r) => (r[ci] ?? "").trim() !== "")
        .map((r, idx) => {
          const values: Record<string, string> = {};
          dataIdx.forEach((i) => {
            values[toColumnKey(grid.headers[i], i)] = r[i] ?? "";
          });
          return {
            report_id: reportId,
            recipient_code: (r[ci] ?? "").trim(),
            recipient_name: ni >= 0 ? (r[ni] ?? "").trim() || null : null,
            values,
            sort_order: idx,
          };
        });

      for (let i = 0; i < payload.length; i += 500) {
        const { error } = await supabase.from("report_rows").insert(payload.slice(i, i + 500));
        if (error) throw error;
      }

      toast({ title: "Import completato", description: `${payload.length} righe caricate` });
      onDone();
      reset();
      onClose();
    } catch (e) {
      toast({ title: "Errore import", description: (e as Error).message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const MAX_PREVIEW_COLS = 12;
  const shownHeaders = grid ? grid.headers.slice(0, MAX_PREVIEW_COLS) : [];
  const hiddenCols = grid ? Math.max(0, grid.headers.length - MAX_PREVIEW_COLS) : 0;

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) { reset(); onClose(); } }}>
      <DialogContent className="max-w-[1100px] w-[95vw] max-h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>Importa dati report</DialogTitle>
          <DialogDescription>
            Carica un file XLSX/TXT oppure incolla le celle copiate da Excel: la prima riga sono le intestazioni.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 min-w-0 overflow-y-auto space-y-4 pr-1">
          <Tabs defaultValue="file">
            <TabsList>
              <TabsTrigger value="file">File XLSX / TXT</TabsTrigger>
              <TabsTrigger value="paste">Incolla da Excel</TabsTrigger>
            </TabsList>
            <TabsContent value="file" className="pt-4">
              <Input
                type="file"
                accept=".xlsx,.xls,.txt,.csv"
                onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
              />
              <p className="text-xs text-muted-foreground mt-2">
                Prima riga = intestazioni. Il TXT deve essere delimitato da tabulazione.
              </p>
            </TabsContent>
            <TabsContent value="paste" className="pt-4 space-y-2">
              <Textarea
                placeholder="Incolla qui le celle copiate da Excel (intestazioni incluse)"
                value={pasted}
                onChange={(e) => setPasted(e.target.value)}
                className="w-full h-40 resize-none font-mono text-xs whitespace-pre overflow-auto"
              />
              <Button variant="outline" size="sm" disabled={!pasted.trim()} onClick={() => setGrid(parseDelimitedText(pasted))}>
                Analizza testo
              </Button>
            </TabsContent>
          </Tabs>

          {grid && grid.headers.length > 0 && (
            <div className="space-y-4 min-w-0">
              <div className="grid gap-3 md:grid-cols-3">
                <div className="space-y-2 min-w-0">
                  <Label>{audience === "customer" ? "Colonna codice cliente" : "Colonna codice agente"}</Label>
                  <Select value={codeIdx} onValueChange={setCodeIdx}>
                    <SelectTrigger className="max-w-xs"><SelectValue /></SelectTrigger>
                    <SelectContent className="max-h-72">
                      {grid.headers.map((h, i) => <SelectItem key={i} value={String(i)}>{h}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 min-w-0">
                  <Label>Nominativo</Label>
                  <div className="h-10 flex items-center text-xs text-muted-foreground border rounded-md px-3 max-w-xs truncate">
                    {unresolved > 0
                      ? `${previewCodes.length - unresolved}/${previewCodes.length} codici riconosciuti`
                      : "Risolto automaticamente dall'anagrafica"}
                  </div>
                </div>
                <div className="space-y-2 min-w-0">
                  <Label>Modalità</Label>
                  <Select value={mode} onValueChange={(v) => setMode(v as "replace" | "append")}>
                    <SelectTrigger className="max-w-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="replace">Sostituisci righe</SelectItem>
                      <SelectItem value="append">Aggiungi righe</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="border rounded-md w-full max-w-full overflow-x-auto overflow-y-auto max-h-64">
                <Table className="min-w-max">
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-48 sticky left-0 bg-background z-10">Nominativo (auto)</TableHead>
                      {shownHeaders.map((h, i) => <TableHead key={i} className="whitespace-nowrap">{h}</TableHead>)}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {grid.rows.slice(0, 5).map((r, i) => {
                      const code = (r[Number(codeIdx)] ?? "").trim();
                      const nm = previewNames[code];
                      return (
                        <TableRow key={i}>
                          <TableCell className="text-xs sticky left-0 bg-background z-10">
                            {nm ?? <span className="text-amber-600">non trovato</span>}
                          </TableCell>
                          {r.slice(0, MAX_PREVIEW_COLS).map((c, j) => (
                            <TableCell key={j} className="text-xs whitespace-nowrap">{c}</TableCell>
                          ))}
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
              <p className="text-xs text-muted-foreground">
                {grid.rows.length} righe rilevate.
                {hiddenCols > 0 && ` Anteprima limitata alle prime ${MAX_PREVIEW_COLS} colonne (e altre ${hiddenCols} colonne verranno importate).`}
                {grid.warnings.length > 0 && ` ${grid.warnings.join(" ")}`}
                {unresolved > 0 && ` ${unresolved} codici senza corrispondenza in anagrafica: le righe verranno comunque importate.`}
              </p>
            </div>
          )}
        </div>

        <DialogFooter className="shrink-0 border-t pt-3">
          <Button variant="outline" onClick={() => { reset(); onClose(); }}>Annulla</Button>
          <Button disabled={!grid || grid.rows.length === 0 || busy} onClick={run}>Importa</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}


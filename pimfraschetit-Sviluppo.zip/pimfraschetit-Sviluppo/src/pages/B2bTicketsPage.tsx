import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { toast } from "sonner";
import {
  MessageSquare,
  Search,
  Inbox,
  Send,
  Trash2,
  Loader2,
  CheckCircle2,
  Clock,
  CircleDot,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { usePermissions } from "@/lib/permissions";
import {
  useB2bTickets,
  useDeleteTicket,
  useUpdateTicketStatus,
  type B2bTicket,
  type TicketStatus,
} from "@/hooks/useB2bTickets";
import { useTicketThread, useSendTicketReply } from "@/hooks/useTicketThread";
import { Textarea } from "@/components/ui/textarea";
import { parseCancellationMessage } from "@/lib/cancellationMessage";

import type { SectionKey } from "@/contexts/AuthContext";
import { Navigate } from "react-router-dom";

const CATEGORIES: { key: string; label: string; tone: string; section: SectionKey }[] = [
  { key: "ordini", label: "Ordini", tone: "blue", section: "b2b_tickets_ordini" },
  { key: "contabile", label: "Amministrazione", tone: "emerald", section: "b2b_tickets_contabile" },
  { key: "tecnico", label: "Supporto tecnico", tone: "violet", section: "b2b_tickets_tecnico" },
  { key: "commerciale", label: "Commerciale", tone: "amber", section: "b2b_tickets_commerciale" },
  { key: "annullamento_ordine", label: "Annullamento ordine", tone: "rose", section: "b2b_tickets_annullamento" },
  { key: "post_vendita", label: "Assistenza Post Vendita", tone: "cyan", section: "b2b_tickets_post_vendita" },
  { key: "portale", label: "Assistenza Portale", tone: "indigo", section: "b2b_tickets_portale" },
  { key: "altro", label: "Altro", tone: "slate", section: "b2b_tickets_altro" },
];

function sectionForCategory(cat: string): SectionKey {
  return (CATEGORIES.find((c) => c.key === cat)?.section ?? "b2b_tickets_altro") as SectionKey;
}

type StatusFilterKey = "active" | "closed" | "all";
const STATUS_FILTERS: { key: StatusFilterKey; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { key: "active", label: "Attivi", icon: CircleDot },
  { key: "closed", label: "Chiusi", icon: CheckCircle2 },
  { key: "all", label: "Tutti", icon: Inbox },
];

function toneClasses(tone: string) {
  const map: Record<string, string> = {
    slate: "bg-slate-100 text-slate-800 border-slate-200",
    blue: "bg-blue-100 text-blue-800 border-blue-200",
    emerald: "bg-emerald-100 text-emerald-800 border-emerald-200",
    violet: "bg-violet-100 text-violet-800 border-violet-200",
    amber: "bg-amber-100 text-amber-800 border-amber-200",
    rose: "bg-rose-100 text-rose-800 border-rose-200",
    cyan: "bg-cyan-100 text-cyan-800 border-cyan-200",
    indigo: "bg-indigo-100 text-indigo-800 border-indigo-200",
  };
  return map[tone] ?? map.slate;
}

function statusBadge(status: string) {
  if (status === "open")
    return { label: "Aperto", cls: "bg-blue-100 text-blue-800 border-blue-200" };
  if (status === "in_progress")
    return { label: "In lavorazione", cls: "bg-amber-100 text-amber-800 border-amber-200" };
  if (status === "closed")
    return { label: "Chiuso", cls: "bg-emerald-100 text-emerald-800 border-emerald-200" };
  return { label: status, cls: "bg-slate-100 text-slate-800 border-slate-200" };
}

function fmt(iso: string) {
  try {
    return new Date(iso).toLocaleString("it-IT", { dateStyle: "short", timeStyle: "short" });
  } catch {
    return iso;
  }
}

export default function B2bTicketsPage() {
  const { can, sectionVisible } = usePermissions();
  const { user } = useAuth();
  const qc = useQueryClient();
  const { data, isLoading } = useB2bTickets();
  const updateStatus = useUpdateTicketStatus();
  const deleteTicket = useDeleteTicket();
  const confirm = useConfirm();

  // Visits map (ticket_id → last_visit_at ms)
  const { data: visitsData } = useQuery({
    queryKey: ["b2b-ticket-visits"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("b2b_ticket_visits_global" as never)
        .select("ticket_id,last_visit_at");
      if (error) throw error;
      return (data ?? []) as unknown as { ticket_id: string; last_visit_at: string }[];
    },
    staleTime: 30_000,
  });
  const visitMap = useMemo(() => {
    const m = new Map<string, number>();
    for (const v of visitsData ?? []) m.set(v.ticket_id, new Date(v.last_visit_at).getTime());
    return m;
  }, [visitsData]);

  useEffect(() => {
    const ch = supabase
      .channel("b2b-ticket-visits-changes")
      .on(
        "postgres_changes" as never,
        { event: "*", schema: "public", table: "b2b_ticket_visits_global" },
        () => qc.invalidateQueries({ queryKey: ["b2b-ticket-visits"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  const isRowNew = (r: B2bTicket) => {
    if (r.status === "closed") return false;
    const t = new Date(r.updated_at ?? r.created_at).getTime();
    const seen = visitMap.get(r.id) ?? 0;
    return t > seen;
  };

  const markVisited = async (ticketId: string) => {
    await supabase
      .from("b2b_ticket_visits_global" as never)
      .upsert(
        { ticket_id: ticketId, last_visit_at: new Date().toISOString(), last_visit_by: user?.id ?? null } as never,
        { onConflict: "ticket_id" } as never,
      );
    qc.invalidateQueries({ queryKey: ["b2b-ticket-visits"] });
    qc.invalidateQueries({ queryKey: ["sidebar-notif"] });
  };

  // Categories the current user can at least read
  const visibleCategories = useMemo(
    () => CATEGORIES.filter((c) => sectionVisible(c.section)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [CATEGORIES.map((c) => sectionVisible(c.section)).join(",")],
  );
  const visibleCatKeys = useMemo(() => new Set(visibleCategories.map((c) => c.key)), [visibleCategories]);

  const canWriteCategory = (cat: string) => can("write", sectionForCategory(cat));

  const [tab, setTab] = useState<string>(() => visibleCategories[0]?.key ?? "all");
  const [statusFilter, setStatusFilter] = useState<StatusFilterKey>("active");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<B2bTicket | null>(null);
  const [pendingStatus, setPendingStatus] = useState<string>("open");

  useEffect(() => {
    if (!selected) return;
    if (selected.category === "annullamento_ordine" && selected.status !== "closed") {
      setPendingStatus("closed");
    } else {
      setPendingStatus(selected.status);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected?.id]);

  const rows = useMemo(
    () => (data ?? []).filter((r) => visibleCatKeys.has(r.category)),
    [data, visibleCatKeys],
  );

  const openCounts = useMemo(() => {
    const c: Record<string, number> = { all: 0 };
    for (const r of rows) {
      if (r.status === "closed") continue;
      c.all = (c.all ?? 0) + 1;
      c[r.category] = (c[r.category] ?? 0) + 1;
    }
    return c;
  }, [rows]);

  const newCounts = useMemo(() => {
    const c: Record<string, number> = { all: 0 };
    for (const r of rows) {
      if (!isRowNew(r)) continue;
      c.all = (c.all ?? 0) + 1;
      c[r.category] = (c[r.category] ?? 0) + 1;
    }
    return c;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows, visitMap]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((r) => {
      if (tab !== "all" && r.category !== tab) return false;
      if (statusFilter === "active" && r.status === "closed") return false;
      if (statusFilter === "closed" && r.status !== "closed") return false;
      if (!q) return true;
      return [
        r.subject,
        r.message,
        r.company_name ?? "",
        r.customer_code ?? "",
        r.contact_email ?? "",
      ]
        .join(" ")
        .toLowerCase()
        .includes(q);
    });
  }, [rows, tab, statusFilter, search]);

  const tabs = useMemo(
    () => [{ key: "all", label: "Tutti", tone: "slate" as const }, ...visibleCategories],
    [visibleCategories],
  );

  const selectedCanWrite = selected ? canWriteCategory(selected.category) : false;

  if (visibleCategories.length === 0) {
    return <Navigate to="/pim" replace />;
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center gap-2">
        <MessageSquare className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-semibold">Ticket Support B2B</h1>
        <Badge variant="secondary" className="ml-2">
          {isLoading ? "…" : rows.length.toLocaleString("it-IT")}
        </Badge>
      </div>
      <p className="text-sm text-muted-foreground">
        Richieste inviate dai clienti dal Portale B2B ("Comunica con noi" e "Richiesta annullamento riga ordine").
      </p>

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            className="pl-8 h-9"
            placeholder="Cerca per oggetto, cliente, email…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-1 rounded-md border bg-background p-0.5">
          {STATUS_FILTERS.map((s) => {
            const Icon = s.icon;
            const active = statusFilter === s.key;
            return (
              <button
                key={s.key}
                onClick={() => setStatusFilter(s.key)}
                className={cn(
                  "flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors",
                  active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted",
                )}
              >
                <Icon className="h-3.5 w-3.5" />
                {s.label}
              </button>
            );
          })}
        </div>
      </div>

      <Card className="p-0 overflow-hidden">
        <div className="border-b px-2 pt-2 overflow-x-auto">
          <div className="flex items-center gap-1 -mb-px">
            {tabs.map((c) => {
              const nOpen = openCounts[c.key] ?? 0;
              const nNew = newCounts[c.key] ?? 0;
              const isActive = tab === c.key;
              return (
                <button
                  key={c.key}
                  onClick={() => setTab(c.key)}
                  className={cn(
                    "relative px-3 py-2 text-sm font-medium whitespace-nowrap rounded-t-md border-b-2 transition-colors flex items-center gap-2",
                    isActive
                      ? "border-primary text-primary bg-primary/5"
                      : "border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/40",
                  )}
                >
                  <span>{c.label}</span>
                  {nNew > 0 && (
                    <span
                      className="inline-flex items-center gap-1 rounded-full bg-destructive/10 text-destructive px-1.5 h-5 text-[11px] font-semibold tabular-nums"
                      title={`${nNew} nuovi`}
                    >
                      <span className="h-1.5 w-1.5 rounded-full bg-destructive" />
                      {nNew}
                    </span>
                  )}
                  {nOpen > 0 && (
                    <span
                      className={cn(
                        "inline-flex items-center justify-center rounded-full min-w-[20px] h-5 px-1.5 text-[11px] font-semibold tabular-nums",
                        isActive ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground",
                      )}
                      title={`${nOpen} aperti`}
                    >
                      {nOpen}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/60 text-xs uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="text-left px-3 py-2 font-medium w-[130px]">Data</th>
                <th className="text-left px-3 py-2 font-medium w-[240px]">Cliente</th>
                <th className="text-left px-3 py-2 font-medium w-[170px]">Categoria</th>
                <th className="text-left px-3 py-2 font-medium">Oggetto</th>
                <th className="text-left px-3 py-2 font-medium w-[140px]">Stato</th>
              </tr>
            </thead>
            <tbody>
              {isLoading &&
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i} className="border-t">
                    <td colSpan={5} className="px-3 py-2">
                      <Skeleton className="h-5 w-full" />
                    </td>
                  </tr>
                ))}
              {!isLoading && filtered.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-16 text-center">
                    <div className="flex flex-col items-center gap-2 text-muted-foreground">
                      <Inbox className="h-10 w-10 opacity-30" />
                      <span className="text-sm">Nessun ticket in questa vista</span>
                    </div>
                  </td>
                </tr>
              )}
              {!isLoading &&
                filtered.map((r) => {
                  const cat = CATEGORIES.find((c) => c.key === r.category) ?? {
                    key: r.category,
                    label: r.category,
                    tone: "slate",
                  };
                  const st = statusBadge(r.status);
                  const isNew = isRowNew(r);
                  return (
                    <tr
                      key={r.id}
                      className={cn(
                        "border-t hover:bg-muted/40 cursor-pointer transition-colors",
                        isNew && "bg-destructive/5",
                      )}
                      onClick={() => {
                        setSelected(r);
                        void markVisited(r.id);
                      }}
                    >
                      <td className="px-3 py-2 text-xs text-muted-foreground tabular-nums whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          {isNew && (
                            <span className="h-1.5 w-1.5 rounded-full bg-destructive shrink-0" title="Nuovo o aggiornato" />
                          )}
                          <span className={cn(isNew && "text-foreground font-medium")}>{fmt(r.created_at)}</span>
                        </div>
                      </td>
                      <td className="px-3 py-2 min-w-0">
                        <div className="font-mono text-[11px] text-muted-foreground leading-tight">
                          {r.customer_code ?? "—"}
                        </div>
                        <div className="font-medium truncate leading-tight" title={r.company_name ?? ""}>
                          {r.company_name ?? "—"}
                        </div>
                      </td>
                      <td className="px-3 py-2">
                        <span
                          className={cn(
                            "inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium",
                            toneClasses(cat.tone),
                          )}
                        >
                          {cat.label}
                        </span>
                      </td>
                      <td className="px-3 py-2 truncate max-w-0" title={r.subject}>
                        {r.subject}
                      </td>
                      <td className="px-3 py-2">
                        <span
                          className={cn(
                            "inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium",
                            st.cls,
                          )}
                        >
                          {st.label}
                        </span>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Detail dialog */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="sm:max-w-2xl max-h-[85vh] overflow-y-auto">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2 flex-wrap">
                  {selected.subject}
                  {(() => {
                    const cat = CATEGORIES.find((c) => c.key === selected.category);
                    const st = statusBadge(selected.status);
                    return (
                      <>
                        {cat && (
                          <span
                            className={cn(
                              "inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium",
                              toneClasses(cat.tone),
                            )}
                          >
                            {cat.label}
                          </span>
                        )}
                        <span
                          className={cn(
                            "inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium",
                            st.cls,
                          )}
                        >
                          {st.label}
                        </span>
                      </>
                    );
                  })()}
                </DialogTitle>
                <DialogDescription>
                  {selected.customer_code} — {selected.company_name} · {fmt(selected.created_at)}
                  {selected.contact_email && (
                    <>
                      {" · "}
                      <a
                        href={`mailto:${selected.contact_email}`}
                        className="underline hover:text-primary"
                      >
                        {selected.contact_email}
                      </a>
                    </>
                  )}
                </DialogDescription>
              </DialogHeader>

              <TicketThreadBody
                ticket={selected}
                canWrite={selectedCanWrite}
                finalStatus={pendingStatus as TicketStatus}
                onAfterSend={(status) => setSelected((s) => (s ? { ...s, status } : s))}
              />

              {selectedCanWrite && (
                <DialogFooter className="flex-col sm:flex-row sm:justify-between sm:items-center gap-2 mt-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">Stato:</span>
                    <Select
                      value={pendingStatus}
                      onValueChange={(v) => {
                        const prev = pendingStatus;
                        setPendingStatus(v);
                        updateStatus.mutate(
                          { id: selected.id, status: v as TicketStatus },
                          {
                            onSuccess: () =>
                              setSelected((s) => (s ? { ...s, status: v } : s)),
                            onError: () => setPendingStatus(prev),
                          },
                        );
                      }}
                    >
                      <SelectTrigger className="h-8 w-[170px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="open">Aperto</SelectItem>
                        <SelectItem value="in_progress">In lavorazione</SelectItem>
                        <SelectItem value="closed">Chiuso</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <TooltipProvider delayDuration={150}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10 border-destructive/30"
                          disabled={deleteTicket.isPending}
                          onClick={async () => {
                            if (await confirm({ title: `Eliminare definitivamente il ticket "${selected.subject}"?`, destructive: true, confirmText: "Elimina" })) {
                              deleteTicket.mutate(selected.id, {
                                onSuccess: () => setSelected(null),
                              });
                            }
                          }}
                        >
                          {deleteTicket.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Trash2 className="h-4 w-4" />
                          )}
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Elimina ticket</TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </DialogFooter>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function TicketThreadBody({
  ticket,
  canWrite,
  finalStatus,
  onAfterSend,
}: {
  ticket: B2bTicket;
  canWrite: boolean;
  finalStatus: TicketStatus;
  onAfterSend?: (status: TicketStatus) => void;
}) {
  const { data: messages = [], isLoading } = useTicketThread(ticket.id);
  const sendReply = useSendTicketReply();
  const [draft, setDraft] = useState("");

  useEffect(() => {
    if (ticket.category === "annullamento_ordine") {
      setDraft(
        "Gentile Cliente\nLa sua richiesta di annullamento dell'ordine è andata a buon fine.\nGrazie per averci contattato.",
      );
    } else {
      setDraft("");
    }
  }, [ticket.id, ticket.category]);
  const listRef = useRef<HTMLDivElement>(null);
  const isClosed = ticket.status === "closed";

  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight;
    }
  }, [messages.length]);

  const submit = () => {
    if (!draft.trim() || sendReply.isPending) return;
    sendReply.mutate(
      { ticketId: ticket.id, body: draft, finalStatus },
      {
        onSuccess: (res) => {
          setDraft("");
          const newStatus = (res?.status as TicketStatus) ?? finalStatus;
          onAfterSend?.(newStatus);
          toast.success(
            newStatus === "closed"
              ? "Risposta inviata — ticket chiuso"
              : "Risposta inviata",
          );
        },
        onError: (e: Error) => toast.error(e.message || "Invio risposta fallito"),
      },
    );
  };


  const initialAuthor = ticket.company_name || ticket.contact_email || "Cliente";
  const cancellation =
    ticket.category === "annullamento_ordine"
      ? parseCancellationMessage(ticket.message)
      : null;

  return (
    <div className="space-y-3">
      <div
        ref={listRef}
        className="rounded-md border bg-muted/20 p-3 space-y-3 max-h-[45vh] overflow-y-auto"
      >
        {isLoading && (
          <div className="text-xs text-muted-foreground">Caricamento thread…</div>
        )}
        {ticket.message && (
          <div className="flex justify-start">
            <div className="max-w-[85%] rounded-lg px-3 py-2 text-sm shadow-sm border bg-background border-border">
              <div className="flex items-center gap-2 mb-1 text-[11px] text-muted-foreground">
                <span className="font-medium">{initialAuthor}</span>
                <span>·</span>
                <span>{fmt(ticket.created_at)}</span>
              </div>
              {cancellation ? (
                <div className="space-y-2">
                  {cancellation.header && (
                    <div className="whitespace-pre-wrap break-words">{cancellation.header}</div>
                  )}
                  {cancellation.items.length > 0 && (
                    <div>
                      <div className="font-medium mb-1">Righe da annullare:</div>
                      <ul className="space-y-1 pl-4 list-disc">
                        {cancellation.items.map((it, i) => (
                          <li key={i} className="leading-snug">
                            <span className="font-mono font-semibold">{it.cdpar}</span> — {it.descrizione} — <em>Qtà:</em> {it.qty} — <em>Prezzo:</em> {it.prezzo} €
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {cancellation.raw && (
                    <div className="whitespace-pre-wrap break-words text-xs text-muted-foreground">{cancellation.raw}</div>
                  )}
                  {cancellation.trailers.length > 0 && (
                    <div className="pt-2 mt-2 border-t space-y-0.5">
                      {cancellation.trailers.map((t, i) => (
                        <div key={i}>
                          <span className="font-medium">{t.key}:</span> {t.value}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="whitespace-pre-wrap break-words">{ticket.message}</div>
              )}
            </div>
          </div>
        )}
        {!isLoading && messages.length === 0 && !ticket.message && (
          <div className="text-xs text-muted-foreground">Nessun messaggio.</div>
        )}
        {messages.map((m) => {
          const isStaff = m.author_type === "staff";
          return (
            <div
              key={m.id}
              className={cn("flex", isStaff ? "justify-end" : "justify-start")}
            >
              <div
                className={cn(
                  "max-w-[85%] rounded-lg px-3 py-2 text-sm shadow-sm border",
                  isStaff
                    ? "bg-primary/10 border-primary/20"
                    : "bg-background border-border",
                )}
              >
                <div className="flex items-center gap-2 mb-1 text-[11px] text-muted-foreground">
                  <span className="font-medium">
                    {m.author_name ?? (isStaff ? "Staff" : "Cliente")}
                  </span>
                  <span>·</span>
                  <span>{fmt(m.created_at)}</span>
                </div>
                <div className="whitespace-pre-wrap break-words">{m.body}</div>
              </div>
            </div>
          );
        })}
      </div>

      {canWrite && (
        <div className="space-y-2">
          <Textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder={
              ticket.contact_email
                ? `Rispondi al cliente (verrà inviata anche via email a ${ticket.contact_email})`
                : "Rispondi al cliente (nessun contact_email — solo visibile nel Portale B2B)"
            }
            className="min-h-[90px] text-sm"
            onKeyDown={(e) => {
              if ((e.metaKey || e.ctrlKey) && e.key === "Enter") submit();
            }}
          />
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-muted-foreground">
              {isClosed
                ? "Ticket chiuso — la risposta verrà comunque inviata"
                : "Cmd/Ctrl + Invio per inviare"}
            </span>
            <Button
              size="sm"
              onClick={submit}
              disabled={!draft.trim() || sendReply.isPending}
            >
              {sendReply.isPending ? (
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
              ) : (
                <Send className="h-4 w-4 mr-1" />
              )}
              Invia risposta
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

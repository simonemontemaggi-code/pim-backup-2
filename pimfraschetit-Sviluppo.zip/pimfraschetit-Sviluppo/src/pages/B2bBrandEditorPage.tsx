import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Save, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { BrandPreview } from "@/components/b2b/BrandPreview";
import { MediaUploader } from "@/components/b2b/MediaUploader";
import { BrandLineeManager } from "@/components/b2b/BrandLineeManager";
import { BrandDocumentsManager } from "@/components/b2b/BrandDocumentsManager";

interface BrandEdit {
  clas2: string;
  nome_as400_brand: string | null;
  display_name: string | null;
  tagline: string | null;
  description: string | null;
  logo_url: string | null;
  hero_image_url: string | null;
  gradient_from: string | null;
  gradient_to: string | null;
  website_url: string | null;
  is_published_b2b: boolean;
}

export default function B2bBrandEditorPage() {
  const { clas2 } = useParams<{ clas2: string }>();
  const { user } = useAuth();
  const [brand, setBrand] = useState<BrandEdit | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!clas2) return;
    (async () => {
      setLoading(true);
      const { data } = await supabase
        .from("archivio_brand_fraschetti")
        .select("clas2, nome_as400_brand, display_name, tagline, description, logo_url, hero_image_url, gradient_from, gradient_to, website_url, is_published_b2b")
        .eq("clas2", clas2)
        .maybeSingle();
      if (data) {
        const b = data as BrandEdit;
        if (!b.display_name) b.display_name = b.nome_as400_brand;
        if (!b.gradient_from) b.gradient_from = "#1e40af";
        b.gradient_to = "transparent";
        setBrand(b);
      }
      setLoading(false);
    })();
  }, [clas2]);

  const update = <K extends keyof BrandEdit>(k: K, v: BrandEdit[K]) =>
    setBrand((b) => (b ? { ...b, [k]: v } : b));

  const save = async () => {
    if (!brand) return;
    setSaving(true);
    const { error } = await supabase
      .from("archivio_brand_fraschetti")
      .update({
        display_name: brand.display_name,
        tagline: brand.tagline,
        description: brand.description,
        logo_url: brand.logo_url,
        hero_image_url: brand.hero_image_url,
        gradient_from: brand.gradient_from,
        gradient_to: "transparent",
        is_published_b2b: brand.is_published_b2b,
        updated_by: user?.id,
      })
      .eq("clas2", brand.clas2);
    setSaving(false);
    if (error) toast.error(`Errore: ${error.message}`);
    else toast.success("Brand salvato");
  };

  if (loading) return <div className="p-6"><Loader2 className="animate-spin" /></div>;
  if (!brand) return <div className="p-6">Brand non trovato</div>;

  return (
    <div className="p-6 space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/pim/b2b/brands"><ArrowLeft className="h-4 w-4 mr-1" /> Brand</Link>
          </Button>
          <div>
            <h1 className="text-2xl font-bold">{brand.display_name || brand.nome_as400_brand}</h1>
            <p className="text-xs text-muted-foreground font-mono">{brand.clas2}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-md border bg-card">
            <Switch
              id="is_published_b2b"
              checked={brand.is_published_b2b}
              onCheckedChange={(v) => update("is_published_b2b", v)}
            />
            <Label htmlFor="is_published_b2b" className="cursor-pointer text-sm">
              {brand.is_published_b2b ? (
                <span className="text-green-600 font-medium">🛒 Online B2B</span>
              ) : (
                <span className="text-red-600 font-medium">⊘ Offline B2B</span>
              )}
            </Label>
          </div>
          <Button onClick={save} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
            Salva
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Anteprima live */}
        <div className="space-y-3">
          <Label className="text-xs uppercase tracking-wider text-muted-foreground">
            Anteprima live (come apparirà sul B2B)
          </Label>
          <BrandPreview
            displayName={brand.display_name}
            fallbackName={brand.nome_as400_brand || brand.clas2}
            tagline={brand.tagline}
            description={brand.description}
            logoUrl={brand.logo_url}
            heroImageUrl={brand.hero_image_url}
            gradientFrom={brand.gradient_from}
          />

          <div className="grid grid-cols-2 gap-3">
            <MediaUploader
              label="Logo"
              hint="Consigliato 400×400, PNG trasparente"
              currentUrl={brand.logo_url}
              storagePath={`brands/${brand.clas2}/logo`}
              onUploaded={(url) => update("logo_url", url)}
            />
            <MediaUploader
              label="Banner / Hero"
              hint="Consigliato 1920×600"
              currentUrl={brand.hero_image_url}
              storagePath={`brands/${brand.clas2}/hero`}
              aspect="wide"
              onUploaded={(url) => update("hero_image_url", url)}
            />
          </div>
        </div>

        {/* Form */}
        <Card className="p-5 space-y-4">


          <div className="space-y-2">
            <Label htmlFor="display_name">Nome visualizzato</Label>
            <Input
              id="display_name"
              value={brand.display_name ?? ""}
              onChange={(e) => update("display_name", e.target.value)}
              placeholder={brand.nome_as400_brand || "Nome del brand"}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tagline">Sottotitolo</Label>
            <Input
              id="tagline"
              value={brand.tagline ?? ""}
              onChange={(e) => update("tagline", e.target.value)}
              placeholder='Es. "Invented for life"'
              maxLength={120}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descrizione</Label>
            <Textarea
              id="description"
              rows={5}
              value={brand.description ?? ""}
              onChange={(e) => update("description", e.target.value)}
              placeholder="Descrizione editoriale del brand..."
              maxLength={2000}
            />
            <div className="text-xs text-muted-foreground text-right">
              {(brand.description ?? "").length} / 2000
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="gf">Gradiente — colore iniziale</Label>
            <div className="flex gap-2">
              <Input
                id="gf"
                type="color"
                className="w-14 p-1 h-10"
                value={brand.gradient_from ?? "#1e40af"}
                onChange={(e) => update("gradient_from", e.target.value)}
              />
              <Input
                value={brand.gradient_from ?? ""}
                onChange={(e) => update("gradient_from", e.target.value)}
                placeholder="#1e40af"
              />
            </div>
            <p className="text-xs text-muted-foreground">
              Il gradiente sfuma automaticamente verso trasparente per mostrare il banner sulla destra.
            </p>
          </div>

        </Card>
      </div>

      <BrandLineeManager clas2={brand.clas2} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <BrandDocumentsManager
          clas2={brand.clas2}
          category="centri_assistenza"
          title="Centri Assistenza"
          description="Documenti PDF con i centri di assistenza autorizzati."
        />
        <BrandDocumentsManager
          clas2={brand.clas2}
          category="piu_info"
          title="Più Info"
          description="Documenti PDF aggiuntivi (cataloghi, schede, manuali...)."
        />
      </div>
    </div>
  );
}

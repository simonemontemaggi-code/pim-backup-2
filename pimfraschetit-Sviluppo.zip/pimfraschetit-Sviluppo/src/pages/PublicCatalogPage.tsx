import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { FlipbookViewer } from "@/components/b2b/flipbook/FlipbookViewer";
import { B2bProductOverlay } from "@/components/b2b/flipbook/B2bProductOverlay";
import { Loader2 } from "lucide-react";

type PublicCatalog = {
  id: string;
  name: string;
  pdf_url: string | null;
  cover_url: string | null;
  og_image_url: string | null;
  hotspots: any[] | null;
  public_slug: string;
};

export default function PublicCatalogPage() {
  const { slug } = useParams<{ slug: string }>();
  const [catalog, setCatalog] = useState<PublicCatalog | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [overlayCdpar, setOverlayCdpar] = useState<string | null>(null);

  useEffect(() => {
    if (!slug) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from("b2b_catalogs")
        .select("id, name, pdf_url, cover_url, og_image_url, hotspots, public_slug")
        .eq("public_slug", slug)
        .eq("is_public", true)
        .maybeSingle();
      if (cancelled) return;
      if (error || !data) {
        setNotFound(true);
      } else {
        setCatalog(data as PublicCatalog);
        // increment views (fire-and-forget)
        supabase.rpc("increment_catalog_views", { p_slug: slug });
      }
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [slug]);

  // Set <title> + Open Graph meta dynamically
  const ogImage = catalog?.og_image_url || catalog?.cover_url || "";
  const pageUrl = typeof window !== "undefined" ? window.location.href : "";
  useEffect(() => {
    if (!catalog) return;
    document.title = `${catalog.name} — Catalogo Fraschetti`;
    const setMeta = (selector: string, attr: string, name: string, content: string) => {
      let el = document.head.querySelector(`meta[${selector}]`) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr, name);
        document.head.appendChild(el);
      }
      el.setAttribute("content", content);
    };
    setMeta(`property="og:title"`, "property", "og:title", catalog.name);
    setMeta(`property="og:description"`, "property", "og:description", `Sfoglia il catalogo ${catalog.name}`);
    setMeta(`property="og:type"`, "property", "og:type", "website");
    setMeta(`property="og:url"`, "property", "og:url", pageUrl);
    if (ogImage) setMeta(`property="og:image"`, "property", "og:image", ogImage);
    setMeta(`name="twitter:card"`, "name", "twitter:card", ogImage ? "summary_large_image" : "summary");
    setMeta(`name="description"`, "name", "description", `Sfoglia il catalogo ${catalog.name}`);
  }, [catalog, ogImage, pageUrl]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }
  if (notFound || !catalog) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-6">
        <div className="text-center space-y-2">
          <h1 className="text-2xl font-semibold">Catalogo non disponibile</h1>
          <p className="text-muted-foreground">Il link potrebbe non essere più attivo.</p>
        </div>
      </div>
    );
  }
  if (!catalog.pdf_url) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-6">
        <p className="text-muted-foreground">Catalogo non ancora disponibile.</p>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-background">
      <FlipbookViewer
        pdfUrl={catalog.pdf_url}
        hotspots={(catalog.hotspots ?? []) as any}
        onHotspotClick={(h: any) => {
          if (h.cdpar) setOverlayCdpar(h.cdpar.trim());
          else if (h.url) window.open(h.url, "_blank");
        }}
      />
      <B2bProductOverlay cdpar={overlayCdpar} onClose={() => setOverlayCdpar(null)} />
    </div>
  );
}

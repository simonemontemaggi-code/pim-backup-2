import { useEffect, useMemo, useState } from "react";
import { Plus, Trash2, Save, Loader2, Pencil, X, ChevronRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { PromoSlidePreview } from "@/components/b2b/PromoSlidePreview";
import { MediaUploader } from "@/components/b2b/MediaUploader";
import { utcToLocalDateTimeInput, localDateTimeInputToUtcIso } from "@/lib/datetimeHelpers";

type NodeType = "clmer" | "reparto" | "gamma";

interface Lookup {
  category: string;
  code: string;
  label: string;
  parent_code?: string | null;
  sort_order?: number | null;
}

interface Promo {
  id: string;
  node_type: string;
  node_code: string;
  title: string;
  subtitle: string | null;
  cta_label: string | null;
  link_url: string | null;
  image_url: string | null;
  sort_order: number;
  is_active: boolean;
  starts_at: string | null;
  ends_at: string | null;
}

const empty = (node_type: NodeType, node_code: string, sort_order: number): Promo => ({
  id: "",
  node_type,
  node_code,
  title: "Nuova promo",
  subtitle: "",
  cta_label: "Scopri",
  link_url: "",
  image_url: null,
  sort_order,
  is_active: true,
  starts_at: null,
  ends_at: null,
});

const sortNumeric = (a: Lookup, b: Lookup) => {
  const aN = parseInt(a.code, 10);
  const bN = parseInt(b.code, 10);
  if (!isNaN(aN) && !isNaN(bN)) return aN - bN;
  return a.code.localeCompare(b.code);
};

export default function B2bPromosPage() {
  const confirm = useConfirm();
  const { user } = useAuth();
  const [lookups, setLookups] = useState<{ clmer: Lookup[]; reparto: Lookup[]; gamma: Lookup[] }>({
    clmer: [], reparto: [], gamma: [],
  });
  const [selected, setSelected] = useState<{ type: NodeType; code: string } | null>(null);
  const [promos, setPromos] = useState<Promo[]>([]);
  const [editing, setEditing] = useState<Promo | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [allClmerPromos, setAllClmerPromos] = useState<Pick<Promo, "node_code" | "is_active" | "starts_at" | "ends_at">[]>([]);

  // Carica tutte le promo clmer per i counter
  const loadAllClmerPromos = async () => {
    const { data } = await supabase
      .from("taxonomy_promos")
      .select("node_code, is_active, starts_at, ends_at")
      .eq("node_type", "clmer");
    setAllClmerPromos((data as any) || []);
  };
  useEffect(() => { loadAllClmerPromos(); }, []);

  // Classifica una promo: active | scheduled | expired | inactive
  const classify = (p: { is_active: boolean; starts_at: string | null; ends_at: string | null }) => {
    if (!p.is_active) return "inactive" as const;
    const now = Date.now();
    const start = p.starts_at ? new Date(p.starts_at).getTime() : null;
    const end = p.ends_at ? new Date(p.ends_at).getTime() : null;
    if (end !== null && end < now) return "expired" as const;
    if (start !== null && start > now) return "scheduled" as const;
    return "active" as const;
  };

  const stats = useMemo(() => {
    const s = { total: allClmerPromos.length, active: 0, scheduled: 0, expired: 0, inactive: 0 };
    allClmerPromos.forEach((p) => { s[classify(p)]++; });
    return s;
  }, [allClmerPromos]);

  const countsBySettore = useMemo(() => {
    const m: Record<string, number> = {};
    allClmerPromos.forEach((p) => { m[p.node_code] = (m[p.node_code] || 0) + 1; });
    return m;
  }, [allClmerPromos]);

  // Carica gerarchia
  useEffect(() => {
    (async () => {
      setLoading(true);
      const { data } = await supabase
        .from("lookup_values")
        .select("category, code, label, parent_code, sort_order")
        .in("category", ["clmer", "reparto", "gamma"])
        .eq("is_active", true)
        .limit(2000);
      const all = (data as Lookup[]) || [];
      setLookups({
        clmer: all.filter((x) => x.category === "clmer").sort(sortNumeric),
        reparto: all.filter((x) => x.category === "reparto").sort(sortNumeric),
        gamma: all.filter((x) => x.category === "gamma").sort(sortNumeric),
      });
      setLoading(false);
    })();
  }, []);

  const repartiBy = useMemo(() => {
    const m: Record<string, Lookup[]> = {};
    lookups.reparto.forEach((r) => {
      if (r.parent_code) (m[r.parent_code] ||= []).push(r);
    });
    return m;
  }, [lookups.reparto]);

  const gammeBy = useMemo(() => {
    const m: Record<string, Lookup[]> = {};
    lookups.gamma.forEach((g) => {
      if (g.parent_code) (m[g.parent_code] ||= []).push(g);
    });
    return m;
  }, [lookups.gamma]);

  const visibleSettori = useMemo(
    () => lookups.clmer.filter((s) => (repartiBy[s.code] || []).length > 0),
    [lookups.clmer, repartiBy],
  );

  // Carica promos del nodo selezionato
  useEffect(() => {
    if (!selected) { setPromos([]); return; }
    (async () => {
      const { data, error } = await supabase
        .from("taxonomy_promos")
        .select("*")
        .eq("node_type", selected.type)
        .eq("node_code", selected.code)
        .order("sort_order", { ascending: true });
      if (error) toast.error(error.message);
      setPromos((data as Promo[]) || []);
    })();
  }, [selected]);

  const labelOf = (type: NodeType, code: string) => {
    const arr = type === "clmer" ? lookups.clmer : type === "reparto" ? lookups.reparto : lookups.gamma;
    return arr.find((x) => x.code === code)?.label || code;
  };

  const refresh = async () => {
    if (!selected) return;
    const { data } = await supabase
      .from("taxonomy_promos")
      .select("*")
      .eq("node_type", selected.type)
      .eq("node_code", selected.code)
      .order("sort_order", { ascending: true });
    setPromos((data as Promo[]) || []);
  };

  const save = async () => {
    if (!editing) return;
    setSaving(true);
    const payload = {
      node_type: editing.node_type,
      node_code: editing.node_code,
      title: editing.title,
      subtitle: editing.subtitle,
      cta_label: editing.cta_label,
      link_url: editing.link_url,
      image_url: editing.image_url,
      sort_order: editing.sort_order,
      is_active: editing.is_active,
      starts_at: editing.starts_at,
      ends_at: editing.ends_at,
      updated_by: user?.id,
    };
    const { error } = editing.id
      ? await supabase.from("taxonomy_promos").update(payload).eq("id", editing.id)
      : await supabase.from("taxonomy_promos").insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Promo salvata");
    setEditing(null);
    refresh();
    loadAllClmerPromos();
  };

  const remove = async (id: string) => {
    if (!(await confirm({ title: "Eliminare?", destructive: true, confirmText: "Elimina" }))) return;
    const { error } = await supabase.from("taxonomy_promos").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Eliminata"); refresh(); loadAllClmerPromos(); }
  };

  const upd = <K extends keyof Promo>(k: K, v: Promo[K]) =>
    setEditing((e) => (e ? { ...e, [k]: v } : e));

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-4">
        <h1 className="text-2xl font-bold">Promo Settori B2B</h1>
        <p className="text-sm text-muted-foreground">
          Banner promozionali mostrati nelle pagine di settore del B2B.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
        <Card className="p-3">
          <div className="text-xs text-muted-foreground uppercase">Totali</div>
          <div className="text-2xl font-bold">{stats.total}</div>
        </Card>
        <Card className="p-3">
          <div className="text-xs uppercase text-[hsl(var(--success))]">Attive</div>
          <div className="text-2xl font-bold text-[hsl(var(--success))]">{stats.active}</div>
        </Card>
        <Card className="p-3">
          <div className="text-xs uppercase text-primary">Pianificate</div>
          <div className="text-2xl font-bold text-primary">{stats.scheduled}</div>
        </Card>
        <Card className="p-3">
          <div className="text-xs uppercase text-destructive">Scadute</div>
          <div className="text-2xl font-bold text-destructive">{stats.expired}</div>
        </Card>
        <Card className="p-3">
          <div className="text-xs uppercase text-muted-foreground">Non attive</div>
          <div className="text-2xl font-bold text-muted-foreground">{stats.inactive}</div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-4">
        <Card className="p-3 max-h-[75vh] overflow-auto">
          {loading ? (
            <Loader2 className="animate-spin mx-auto my-10" />
          ) : (
            <ul className="space-y-1 text-sm">
              {visibleSettori.map((s) => (
                <li key={s.code}>
                  <button
                    className={`w-full text-left px-2 py-1 rounded hover:bg-muted flex items-center gap-1 ${
                      selected?.type === "clmer" && selected.code === s.code ? "bg-muted font-medium" : ""
                    }`}
                    onClick={() => setSelected({ type: "clmer", code: s.code })}
                  >
                    <ChevronRight className="h-3 w-3" />
                    <span className="font-mono text-xs text-muted-foreground mr-1">{s.code}</span>
                    <span className="flex-1 truncate">{s.label}</span>
                    {countsBySettore[s.code] ? (
                      <span className="ml-auto text-xs px-1.5 py-0.5 rounded bg-primary/10 text-primary font-medium">
                        {countsBySettore[s.code]}
                      </span>
                    ) : null}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <div className="space-y-3">
          {!selected ? (
            <Card className="p-10 text-center text-muted-foreground">
              Seleziona un nodo dall'albero per gestire le sue promo
            </Card>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs text-muted-foreground uppercase">{selected.type}</span>
                  <h2 className="text-lg font-semibold">{labelOf(selected.type, selected.code)}</h2>
                </div>
                <Button onClick={() => setEditing(empty(selected.type, selected.code, promos.length))}>
                  <Plus className="h-4 w-4 mr-1" /> Nuova promo
                </Button>
              </div>

              {promos.length === 0 ? (
                <Card className="p-8 text-center text-muted-foreground">Nessuna promo per questo nodo</Card>
              ) : (
                <div className="space-y-2">
                  {promos.map((p) => (
                    <Card key={p.id} className="p-3 flex gap-3 items-center">
                      <div className="w-32 shrink-0 rounded overflow-hidden bg-muted" style={{ aspectRatio: "16/6" }}>
                        {p.image_url && <img src={p.image_url} alt="" className="w-full h-full object-cover" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold truncate">{p.title}</span>
                          {!p.is_active && <span className="text-xs px-2 py-0.5 rounded bg-muted text-muted-foreground">non attiva</span>}
                        </div>
                        <p className="text-xs text-muted-foreground truncate">{p.subtitle}</p>
                      </div>
                      <Button variant="outline" size="sm" onClick={() => setEditing(p)}>
                        <Pencil className="h-3 w-3 mr-1" /> Modifica
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => remove(p.id)}>
                        <Trash2 className="h-3 w-3 text-destructive" />
                      </Button>
                    </Card>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {editing && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 overflow-auto p-6">
          <div className="max-w-5xl mx-auto space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold">{editing.id ? "Modifica promo" : "Nuova promo"}</h2>
              <div className="flex gap-2">
                <Button variant="ghost" onClick={() => setEditing(null)}><X className="h-4 w-4 mr-1" />Annulla</Button>
                <Button onClick={save} disabled={saving}>
                  {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                  Salva
                </Button>
              </div>
            </div>

            <Card className="p-4 space-y-3">
              <Label className="text-xs uppercase text-muted-foreground">Anteprima live</Label>
              <PromoSlidePreview
                image={editing.image_url}
                title={editing.title}
                subtitle={editing.subtitle}
                cta={editing.cta_label}
                link={editing.link_url}
              />
            </Card>

            <Card className="p-5 space-y-4">
              <MediaUploader
                label="Immagine promo"
                hint="Consigliato 1600×600"
                currentUrl={editing.image_url}
                storagePath={`b2b/promos/${editing.node_type}-${editing.node_code}/${editing.id || `new-${Date.now()}`}`}
                aspect="wide"
                onUploaded={(url) => upd("image_url", url)}
              />

              <div className="space-y-2">
                <Label>Titolo</Label>
                <Input value={editing.title} onChange={(e) => upd("title", e.target.value)} maxLength={120} />
              </div>

              <div className="space-y-2">
                <Label>Sottotitolo</Label>
                <Textarea
                  rows={2}
                  value={editing.subtitle ?? ""}
                  onChange={(e) => upd("subtitle", e.target.value)}
                  maxLength={200}
                />
              </div>

              <div className="grid grid-cols-[auto_1fr_1fr] gap-3 items-end">
                <div className="space-y-2">
                  <Label>Mostra CTA</Label>
                  <div className="h-10 flex items-center">
                    <Switch
                      checked={!!editing.cta_label}
                      onCheckedChange={(v) => upd("cta_label", v ? "Scopri" : "")}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Testo pulsante (CTA)</Label>
                  <Input
                    value={editing.cta_label ?? ""}
                    onChange={(e) => upd("cta_label", e.target.value)}
                    maxLength={40}
                    disabled={!editing.cta_label}
                    placeholder="Disattivata"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Link destinazione</Label>
                  <Input
                    value={editing.link_url ?? ""}
                    onChange={(e) => upd("link_url", e.target.value)}
                    placeholder="/offers/..."
                  />
                  {!editing.cta_label && editing.link_url && (
                    <p className="text-[11px] text-muted-foreground">
                      Senza pulsante: tutta l'immagine sarà cliccabile.
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2">
                  <Label>Attiva</Label>
                  <div className="h-10 flex items-center">
                    <Switch checked={editing.is_active} onCheckedChange={(v) => upd("is_active", v)} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Inizio (opz.)</Label>
                  <Input
                    type="datetime-local"
                    value={utcToLocalDateTimeInput(editing.starts_at)}
                    onChange={(e) => upd("starts_at", localDateTimeInputToUtcIso(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Fine (opz.)</Label>
                  <Input
                    type="datetime-local"
                    value={utcToLocalDateTimeInput(editing.ends_at)}
                    onChange={(e) => upd("ends_at", localDateTimeInputToUtcIso(e.target.value))}
                  />
                </div>
              </div>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}

import { Fragment, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { BarChart3, ShoppingCart, Users2, Euro, Store, UserCheck, Rows3, MapPin, ArrowUpDown, ArrowUp, ArrowDown, Filter, ChevronRight, ChevronDown } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const fmtEuro = (n: number) =>
  new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" }).format(n);

type OrderLite = {
  id: string;
  total: number;
  codice_cliente: string | null;
  ragione_sociale: string | null;
  origine: string | null;
  zone_code: string | null;
  righe: number;
};

type ZoneAgg = { zone: string; orders: number; customers: number; righe: number; value: number };
type SortKey = "zone" | "orders" | "customers" | "righe" | "value";

export default function SalesDashboardPage() {
  const { data, isLoading } = useQuery({
    queryKey: ["sales-dashboard-kpis-v2"],
    queryFn: async () => {
      // Fetch all transmitted orders
      const { data: allOrders, error } = await supabase
        .from("customer_orders")
        .select("id, total, codice_cliente, origine, status")
        .eq("status", "trasmesso");
      if (error) throw error;

      // Downloaded items: order_id + batch_id (to know which were downloaded today)
      const { data: dlItems, error: dlErr } = await supabase
        .from("order_download_batch_items")
        .select("order_id, batch_id");
      if (dlErr) throw dlErr;

      const downloadedOrderIds = new Set((dlItems ?? []).map((r: any) => r.order_id));

      // Today's batches (from midnight local)
      const startOfDay = new Date();
      startOfDay.setHours(0, 0, 0, 0);
      const { data: todayBatches, error: tbErr } = await supabase
        .from("order_download_batches")
        .select("id")
        .gte("created_at", startOfDay.toISOString());
      if (tbErr) throw tbErr;
      const todayBatchIds = new Set((todayBatches ?? []).map((b: any) => b.id));
      const todayDownloadedOrderIds = new Set(
        (dlItems ?? []).filter((r: any) => todayBatchIds.has(r.batch_id)).map((r: any) => r.order_id)
      );

      const toDownload = (allOrders ?? []).filter((o: any) => !downloadedOrderIds.has(o.id));
      const downloadedToday = (allOrders ?? []).filter((o: any) => todayDownloadedOrderIds.has(o.id));

      // Customer zones for involved customer codes
      const codes = Array.from(
        new Set([...toDownload, ...downloadedToday].map((o: any) => o.codice_cliente).filter(Boolean))
      );
      const { data: customers } = codes.length
        ? await supabase.from("customers").select("customer_code, zone_code, company_name").in("customer_code", codes)
        : { data: [] as any[] };
      const zoneMap = new Map((customers ?? []).map((c: any) => [c.customer_code, c.zone_code as string | null]));
      const nameMap = new Map((customers ?? []).map((c: any) => [c.customer_code, c.company_name as string | null]));

      // Row counts per order
      const allIds = Array.from(new Set([...toDownload, ...downloadedToday].map((o: any) => o.id)));
      const righeMap = new Map<string, number>();
      if (allIds.length) {
        // chunk to avoid IN limits
        const chunkSize = 500;
        for (let i = 0; i < allIds.length; i += chunkSize) {
          const chunk = allIds.slice(i, i + chunkSize);
          const { data: items } = await supabase
            .from("customer_order_items")
            .select("order_id")
            .in("order_id", chunk);
          for (const it of (items ?? []) as any[]) {
            righeMap.set(it.order_id, (righeMap.get(it.order_id) ?? 0) + 1);
          }
        }
      }

      const enrich = (o: any): OrderLite => ({
        id: o.id,
        total: Number(o.total ?? 0),
        codice_cliente: o.codice_cliente,
        ragione_sociale: o.codice_cliente ? nameMap.get(o.codice_cliente) ?? null : null,
        origine: o.origine,
        zone_code: o.codice_cliente ? zoneMap.get(o.codice_cliente) ?? null : null,
        righe: righeMap.get(o.id) ?? 0,
      });

      const toDownloadEn = toDownload.map(enrich);
      const downloadedTodayEn = downloadedToday.map(enrich);

      // KPI totals (to-download)
      const split = {
        cc: { count: 0, value: 0, customers: new Set<string>(), righe: 0 },
        ca: { count: 0, value: 0, customers: new Set<string>(), righe: 0 },
      };
      let totalValue = 0;
      let totalRighe = 0;
      const customersSet = new Set<string>();
      for (const o of toDownloadEn) {
        totalValue += o.total;
        totalRighe += o.righe;
        if (o.codice_cliente) customersSet.add(o.codice_cliente);
        const b = o.origine === "NE" ? split.cc : split.ca;
        b.count += 1;
        b.value += o.total;
        b.righe += o.righe;
        if (o.codice_cliente) b.customers.add(o.codice_cliente);
      }

      // Ultimo scarico effettuato (qualsiasi batch)
      const { data: lastBatch } = await supabase
        .from("order_download_batches")
        .select("created_at")
        .order("created_at", { ascending: false })
        .limit(1)
        .single();

      return {
        ordersCount: toDownloadEn.length,
        totalValue,
        totalRighe,
        customersCount: customersSet.size,
        cc: { count: split.cc.count, value: split.cc.value, customers: split.cc.customers.size, righe: split.cc.righe },
        ca: { count: split.ca.count, value: split.ca.value, customers: split.ca.customers.size, righe: split.ca.righe },
        toDownload: toDownloadEn,
        downloadedToday: downloadedTodayEn,
        lastDownloadAt: lastBatch?.created_at ? new Date(lastBatch.created_at) : null,
      };
    },
  });

  // Zone prospect state
  const [includeToDownload, setIncludeToDownload] = useState(false);
  const [selectedZones, setSelectedZones] = useState<Set<string>>(new Set());
  const [zonesInitialized, setZonesInitialized] = useState(false);
  const [sortBy, setSortBy] = useState<SortKey>("zone");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
  const [expandedZones, setExpandedZones] = useState<Set<string>>(new Set());

  const zoneOrdersMap = useMemo(() => {
    const m = new Map<string, OrderLite[]>();
    if (!data) return m;
    const source: OrderLite[] = [
      ...data.downloadedToday,
      ...(includeToDownload ? data.toDownload : []),
    ];
    for (const o of source) {
      const z = o.zone_code ?? "—";
      if (!m.has(z)) m.set(z, []);
      m.get(z)!.push(o);
    }
    return m;
  }, [data, includeToDownload]);

  const toggleExpand = (z: string) => {
    setExpandedZones((prev) => {
      const next = new Set(prev);
      if (next.has(z)) next.delete(z);
      else next.add(z);
      return next;
    });
  };

  const zoneRows = useMemo<ZoneAgg[]>(() => {
    if (!data) return [];
    const source: OrderLite[] = [
      ...data.downloadedToday,
      ...(includeToDownload ? data.toDownload : []),
    ];
    const m = new Map<string, { orders: number; customers: Set<string>; righe: number; value: number }>();
    for (const o of source) {
      const z = o.zone_code ?? "—";
      let agg = m.get(z);
      if (!agg) {
        agg = { orders: 0, customers: new Set(), righe: 0, value: 0 };
        m.set(z, agg);
      }
      agg.orders += 1;
      agg.righe += o.righe;
      agg.value += o.total;
      if (o.codice_cliente) agg.customers.add(o.codice_cliente);
    }
    return Array.from(m.entries()).map(([zone, v]) => ({
      zone,
      orders: v.orders,
      customers: v.customers.size,
      righe: v.righe,
      value: v.value,
    }));
  }, [data, includeToDownload]);

  const allZones = useMemo(() => {
    const s = new Set<string>();
    if (data) {
      for (const o of data.downloadedToday) s.add(o.zone_code ?? "—");
      for (const o of data.toDownload) s.add(o.zone_code ?? "—");
    }
    return Array.from(s).sort();
  }, [data]);

  // Initialize selectedZones once
  if (data && !zonesInitialized && allZones.length) {
    setSelectedZones(new Set(allZones));
    setZonesInitialized(true);
  }

  const visibleRows = useMemo(() => {
    const filtered = zoneRows.filter((r) => selectedZones.size === 0 || selectedZones.has(r.zone));
    const dir = sortDir === "asc" ? 1 : -1;
    return [...filtered].sort((a, b) => {
      if (sortBy === "zone") return a.zone.localeCompare(b.zone) * dir;
      return ((a[sortBy] as number) - (b[sortBy] as number)) * dir;
    });
  }, [zoneRows, selectedZones, sortBy, sortDir]);

  const totals = useMemo(() => {
    return visibleRows.reduce(
      (acc, r) => ({
        orders: acc.orders + r.orders,
        customers: acc.customers + r.customers,
        righe: acc.righe + r.righe,
        value: acc.value + r.value,
      }),
      { orders: 0, customers: 0, righe: 0, value: 0 }
    );
  }, [visibleRows]);

  const handleSort = (k: SortKey) => {
    if (sortBy === k) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortBy(k);
      setSortDir(k === "zone" ? "asc" : "desc");
    }
  };

  const SortHead = ({ k, label, align }: { k: SortKey; label: string; align?: "right" }) => {
    const Icon = sortBy !== k ? ArrowUpDown : sortDir === "asc" ? ArrowUp : ArrowDown;
    return (
      <TableHead className={align === "right" ? "text-right" : ""}>
        <button
          className={`inline-flex items-center gap-1 hover:text-foreground ${align === "right" ? "ml-auto" : ""}`}
          onClick={() => handleSort(k)}
        >
          {label}
          <Icon className="h-3 w-3" />
        </button>
      </TableHead>
    );
  };

  const toggleZone = (z: string) => {
    setSelectedZones((prev) => {
      const next = new Set(prev);
      if (next.has(z)) next.delete(z);
      else next.add(z);
      return next;
    });
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-2">
        <BarChart3 className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-semibold">Dashboard Vendite</h1>
      </div>

      {/* Prima fila: Ordini · Clienti · Righe */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card style={{ backgroundColor: "#1f4a36" }} className="text-white border-transparent">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-white/80">Ordini da scaricare</CardTitle>
            <ShoppingCart className="h-4 w-4 text-white/80" />
          </CardHeader>
          <CardContent>
            {isLoading ? <Skeleton className="h-10 w-24 bg-white/20" /> : (
              <div className="text-4xl font-bold tracking-tight text-white">{data?.ordersCount ?? 0}</div>
            )}
          </CardContent>
        </Card>
        <Card style={{ backgroundColor: "#1f4a36" }} className="text-white border-transparent">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-white/80">Clienti coinvolti</CardTitle>
            <Users2 className="h-4 w-4 text-white/80" />
          </CardHeader>
          <CardContent>
            {isLoading ? <Skeleton className="h-10 w-16 bg-white/20" /> : (
              <div className="text-4xl font-bold tracking-tight text-white">{data?.customersCount ?? 0}</div>
            )}
          </CardContent>
        </Card>
        <Card style={{ backgroundColor: "#1f4a36" }} className="text-white border-transparent">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-white/80">Righe totali da scaricare</CardTitle>
            <Rows3 className="h-4 w-4 text-white/80" />
          </CardHeader>
          <CardContent>
            {isLoading ? <Skeleton className="h-10 w-20 bg-white/20" /> : (
              <div className="text-4xl font-bold tracking-tight text-white">{data?.totalRighe ?? 0}</div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Seconda fila: Valore · CC · CA */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Valore totale</CardTitle>
            <Euro className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? <Skeleton className="h-8 w-32" /> : (
              <div className="text-2xl font-bold">{fmtEuro(data?.totalValue ?? 0)}</div>
            )}
          </CardContent>
        </Card>

        <Card className="border-blue-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div className="flex items-center gap-2">
              <Store className="h-4 w-4 text-blue-600" />
              <CardTitle className="text-sm font-medium">Cliente CC</CardTitle>
              <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 border-blue-200">origine NE</Badge>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? <Skeleton className="h-16 w-full" /> : (
              <div className="space-y-1">
                <div className="text-2xl font-bold text-blue-700">{fmtEuro(data?.cc?.value ?? 0)}</div>
                <div className="text-xs text-muted-foreground">
                  {data?.cc?.count ?? 0} ordini · {data?.cc?.customers ?? 0} clienti · {data?.cc?.righe ?? 0} righe
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-amber-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div className="flex items-center gap-2">
              <UserCheck className="h-4 w-4 text-amber-600" />
              <CardTitle className="text-sm font-medium">Agente CA</CardTitle>
              <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100 border-amber-200">origine vuota</Badge>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? <Skeleton className="h-16 w-full" /> : (
              <div className="space-y-1">
                <div className="text-2xl font-bold text-amber-700">{fmtEuro(data?.ca?.value ?? 0)}</div>
                <div className="text-xs text-muted-foreground">
                  {data?.ca?.count ?? 0} ordini · {data?.ca?.customers ?? 0} clienti · {data?.ca?.righe ?? 0} righe
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Prospetto zone */}
      <Card>
        <CardHeader className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-primary" />
            <CardTitle className="text-base">Ordini scaricati oggi per zona</CardTitle>
            <TooltipProvider delayDuration={200}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Badge variant="outline" className="text-[10px] cursor-default">{new Date().toLocaleDateString("it-IT")}</Badge>
                </TooltipTrigger>
                <TooltipContent side="bottom">
                  <p className="text-xs">
                    {data?.lastDownloadAt
                      ? `Ult. scarico ${data.lastDownloadAt.toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" })}`
                      : "Nessuno scarico registrato"}
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <Switch
                id="include-todownload"
                checked={includeToDownload}
                onCheckedChange={setIncludeToDownload}
              />
              <Label htmlFor="include-todownload" className="text-xs cursor-pointer">
                Includi ordini da scaricare
              </Label>
            </div>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="h-8">
                  <Filter className="h-3 w-3 mr-1" />
                  Zone ({selectedZones.size}/{allZones.length})
                </Button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-56 p-2">
                <div className="flex items-center justify-between mb-2 pb-2 border-b">
                  <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => setSelectedZones(new Set(allZones))}>
                    Tutte
                  </Button>
                  <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => setSelectedZones(new Set())}>
                    Nessuna
                  </Button>
                </div>
                <ScrollArea className="h-56">
                  <div className="space-y-1">
                    {allZones.map((z) => (
                      <label key={z} className="flex items-center gap-2 text-sm cursor-pointer px-1 py-0.5 hover:bg-accent rounded">
                        <Checkbox
                          checked={selectedZones.has(z)}
                          onCheckedChange={() => toggleZone(z)}
                        />
                        <span>{z}</span>
                      </label>
                    ))}
                  </div>
                </ScrollArea>
              </PopoverContent>
            </Popover>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-40 w-full" />
          ) : visibleRows.length === 0 ? (
            <div className="text-sm text-muted-foreground py-8 text-center">
              Nessun ordine {includeToDownload ? "" : "scaricato "}per le zone selezionate.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <SortHead k="zone" label="Zona" />
                  <SortHead k="orders" label="N° ordini" align="right" />
                  <SortHead k="customers" label="N° clienti" align="right" />
                  <SortHead k="righe" label="N° righe" align="right" />
                  <SortHead k="value" label="Valore" align="right" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {visibleRows.map((r) => {
                  const isExpanded = expandedZones.has(r.zone);
                  const orders = zoneOrdersMap.get(r.zone) ?? [];
                  return (
                    <Fragment key={r.zone}>
                      <TableRow
                        className="cursor-pointer hover:bg-muted/40"
                        onClick={() => toggleExpand(r.zone)}
                      >
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-1">
                            {isExpanded ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
                            {r.zone}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">{r.orders}</TableCell>
                        <TableCell className="text-right">{r.customers}</TableCell>
                        <TableCell className="text-right">{r.righe}</TableCell>
                        <TableCell className="text-right">{fmtEuro(r.value)}</TableCell>
                      </TableRow>
                      {isExpanded && (
                        <TableRow key={`${r.zone}-detail`} className="bg-muted/20 hover:bg-muted/20">
                          <TableCell colSpan={5} className="p-0">
                            <div className="px-6 py-2">
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead className="h-8 text-xs">Cod. Cliente</TableHead>
                                    <TableHead className="h-8 text-xs">Rag. Sociale</TableHead>
                                    <TableHead className="h-8 text-xs text-right">Righe</TableHead>
                                    <TableHead className="h-8 text-xs text-right">Valore</TableHead>
                                    <TableHead className="h-8 text-xs text-center">CA/CC</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {orders.map((o) => (
                                    <TableRow key={o.id}>
                                      <TableCell className="py-1.5 text-xs font-mono">{o.codice_cliente ?? "—"}</TableCell>
                                      <TableCell className="py-1.5 text-xs">{o.ragione_sociale ?? "—"}</TableCell>
                                      <TableCell className="py-1.5 text-xs text-right">{o.righe}</TableCell>
                                      <TableCell className="py-1.5 text-xs text-right">{fmtEuro(o.total)}</TableCell>
                                      <TableCell className="py-1.5 text-xs text-center">
                                        {o.origine === "NE" ? (
                                          <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 border-blue-200 text-[10px]">CC</Badge>
                                        ) : (
                                          <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100 border-amber-200 text-[10px]">CA</Badge>
                                        )}
                                      </TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            </div>
                          </TableCell>
                        </TableRow>
                      )}
                    </Fragment>
                  );
                })}
                <TableRow className="font-semibold bg-muted/50">
                  <TableCell>Totale</TableCell>
                  <TableCell className="text-right">{totals.orders}</TableCell>
                  <TableCell className="text-right">{totals.customers}</TableCell>
                  <TableCell className="text-right">{totals.righe}</TableCell>
                  <TableCell className="text-right">{fmtEuro(totals.value)}</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Search, Plus, Loader2, CheckSquare } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/lib/permissions";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

interface BrandRow {
  clas2: string;
  nome_as400_brand: string | null;
  display_name: string | null;
  logo_url: string | null;
  hero_image_url: string | null;
  description: string | null;
  tagline: string | null;
  is_published_b2b: boolean;
  updated_at: string | null;
}

const completenessFields: (keyof BrandRow)[] = [
  "display_name", "tagline", "description", "logo_url", "hero_image_url",
];

function calcCompleteness(b: BrandRow) {
  const filled = completenessFields.filter((k) => !!b[k]).length;
  return Math.round((filled / completenessFields.length) * 100);
}

export default function B2bBrandsListPage() {
  const navigate = useNavigate();
  const [brands, setBrands] = useState<BrandRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [online, setOnline] = useState(false);
  const [offline, setOffline] = useState(false);
  const [noLogo, setNoLogo] = useState(false);
  const [noArticles, setNoArticles] = useState(false);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [countsLoading, setCountsLoading] = useState(true);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [bulkBusy, setBulkBusy] = useState(false);

  // Dialog "Nuovo brand"
  const [openNew, setOpenNew] = useState(false);
  const [creating, setCreating] = useState(false);
  const [newClas2, setNewClas2] = useState("");
  const [newName, setNewName] = useState("");
  const { canAction } = usePermissions();
  const canCreateBrand = canAction("b2b_brands", "create");
  const canEditBrand = canAction("b2b_brands", "publish");

  const toggleSel = (k: string) => {
    setSelected((s) => {
      const n = new Set(s);
      n.has(k) ? n.delete(k) : n.add(k);
      return n;
    });
  };

  const bulkSetPublished = async (value: boolean) => {
    const codes = Array.from(selected);
    if (codes.length === 0) return;
    setBulkBusy(true);
    const { error } = await supabase
      .from("archivio_brand_fraschetti")
      .update({ is_published_b2b: value })
      .in("clas2", codes);
    setBulkBusy(false);
    if (error) { toast.error(`Errore: ${error.message}`); return; }
    toast.success(`${codes.length} brand ${value ? "pubblicati" : "depubblicati"}`);
    setBrands((bs) => bs.map((b) => selected.has(b.clas2) ? { ...b, is_published_b2b: value } : b));
    setSelected(new Set());
  };

  const reload = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("archivio_brand_fraschetti")
      .select("clas2, nome_as400_brand, display_name, logo_url, hero_image_url, description, tagline, is_published_b2b, updated_at")
      .order("nome_as400_brand", { ascending: true })
      .limit(1000);
    if (!error && data) setBrands(data as BrandRow[]);
    setLoading(false);
  };

  useEffect(() => { reload(); }, []);

  // Conteggio articoli visibili su B2B per brand (clas2): paginazione su 'clas2' filtrato per b2b_online_effective
  useEffect(() => {
    (async () => {
      setCountsLoading(true);
      const map: Record<string, number> = {};
      const PAGE = 1000;
      let from = 0;
      while (true) {
        const { data, error } = await supabase
          .from("archivio_articoli_fraschetti")
          .select("clas2")
          .eq("b2b_online_effective", true)
          .not("clas2", "is", null)
          .range(from, from + PAGE - 1);
        if (error || !data) break;
        for (const r of data as { clas2: string | null }[]) {
          if (!r.clas2) continue;
          map[r.clas2] = (map[r.clas2] ?? 0) + 1;
        }
        if (data.length < PAGE) break;
        from += PAGE;
        if (from > 200000) break; // safety
      }
      setCounts(map);
      setCountsLoading(false);
    })();
  }, []);

  const handleCreate = async () => {
    const clas2 = newClas2.trim().toUpperCase();
    const nome = newName.trim();
    if (!clas2 || !nome) {
      toast.error("Codice e nome sono obbligatori");
      return;
    }
    setCreating(true);
    // Check duplicate
    const { data: existing } = await supabase
      .from("archivio_brand_fraschetti")
      .select("clas2")
      .eq("clas2", clas2)
      .maybeSingle();
    if (existing) {
      setCreating(false);
      toast.error(`Il codice "${clas2}" esiste già`);
      return;
    }
    const { error } = await supabase
      .from("archivio_brand_fraschetti")
      .insert({
        clas2,
        nome_as400_brand: nome,
        display_name: nome,
        synced_as400: false,
        is_published_b2b: false,
      });
    setCreating(false);
    if (error) {
      toast.error(`Errore: ${error.message}`);
      return;
    }
    toast.success("Brand creato");
    setOpenNew(false);
    setNewClas2("");
    setNewName("");
    navigate(`/pim/b2b/brands/${encodeURIComponent(clas2)}`);
  };

  const filtered = useMemo(() => {
    return brands.filter((b) => {
      const name = (b.display_name || b.nome_as400_brand || "").toLowerCase();
      if (q && !name.includes(q.toLowerCase()) && !b.clas2.toLowerCase().includes(q.toLowerCase())) return false;
      // Status: se entrambi attivi o entrambi inattivi → mostra tutti; altrimenti filtra
      if (online && !offline && !b.is_published_b2b) return false;
      if (offline && !online && b.is_published_b2b) return false;
      if (noLogo && b.logo_url) return false;
      if (noArticles && (counts[b.clas2] ?? 0) !== 0) return false;
      return true;
    });
  }, [brands, q, online, offline, noLogo, noArticles, counts]);

  const stats = useMemo(() => ({
    total: brands.length,
    withLogo: brands.filter((b) => b.logo_url).length,
    online: brands.filter((b) => b.is_published_b2b).length,
    articlesOnline: Object.values(counts).reduce((a, b) => a + b, 0),
  }), [brands, counts]);

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Brand B2B</h1>
          <p className="text-sm text-muted-foreground">
            Gestione editoriale dei {brands.length} brand — {stats.online} online sul B2B
          </p>
        </div>
        {canCreateBrand && (
        <Button onClick={() => setOpenNew(true)}>
          <Plus className="h-4 w-4 mr-2" /> Nuovo brand
        </Button>
        )}
      </div>

      <Dialog open={openNew} onOpenChange={setOpenNew}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nuovo brand (PIM-only)</DialogTitle>
            <DialogDescription>
              Questo brand verrà creato solo nel PIM e non sarà sincronizzato con AS400.
              Usa un codice univoco (es. <span className="font-mono">PIM_NIKE</span>).
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="new_clas2">Codice (clas2) *</Label>
              <Input
                id="new_clas2"
                value={newClas2}
                onChange={(e) => setNewClas2(e.target.value.toUpperCase())}
                placeholder="PIM_BRAND01"
                maxLength={20}
                autoFocus
              />
              <p className="text-xs text-muted-foreground">
                Identificatore univoco. Convenzione consigliata: prefisso <span className="font-mono">PIM_</span>.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="new_name">Nome brand *</Label>
              <Input
                id="new_name"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="Nome del brand"
                maxLength={120}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpenNew(false)} disabled={creating}>
              Annulla
            </Button>
            <Button onClick={handleCreate} disabled={creating}>
              {creating && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Crea e modifica
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="grid grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="text-xs text-muted-foreground">Totale brand</div>
          <div className="text-2xl font-bold">{stats.total}</div>
        </Card>
        <Card className="p-4">
          <div className="text-xs text-muted-foreground">Online B2B</div>
          <div className="text-2xl font-bold text-green-600">{stats.online}</div>
        </Card>
        <Card className="p-4">
          <div className="text-xs text-muted-foreground">Con logo</div>
          <div className="text-2xl font-bold">{stats.withLogo}</div>
        </Card>
        <Card className="p-4">
          <div className="text-xs text-muted-foreground">Articoli online B2B</div>
          <div className="text-2xl font-bold tabular-nums">
            {countsLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : stats.articlesOnline.toLocaleString("it-IT")}
          </div>
        </Card>
      </div>

      <div className="flex gap-2 items-center">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cerca brand..."
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="pl-8"
          />
        </div>
        <div className="flex gap-1 flex-wrap items-center">
          {(["all","online","offline","no_logo","no_articles"] as const).map((f) => {
            const anyActive = online || offline || noLogo || noArticles;
            const active =
              (f === "all" && !anyActive) ||
              (f === "online" && online) ||
              (f === "offline" && offline) ||
              (f === "no_logo" && noLogo) ||
              (f === "no_articles" && noArticles);
            return (
              <Badge
                key={f}
                variant={active ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => {
                  if (f === "all") { setOnline(false); setOffline(false); setNoLogo(false); setNoArticles(false); return; }
                  if (f === "online") setOnline((v) => !v);
                  else if (f === "offline") setOffline((v) => !v);
                  else if (f === "no_logo") setNoLogo((v) => !v);
                  else if (f === "no_articles") setNoArticles((v) => !v);
                }}
              >
                {f === "all" && "Tutti"}
                {f === "online" && "Online B2B"}
                {f === "offline" && "Offline B2B"}
                {f === "no_logo" && "Senza logo"}
                {f === "no_articles" && "Senza articoli B2B"}
              </Badge>
            );
          })}
          <span className="text-xs text-muted-foreground ml-2">{filtered.length} brand</span>
        </div>
      </div>

      {selected.size > 0 && (
        <div className="flex items-center gap-3 px-3 py-2 rounded-md border bg-primary/5">
          <CheckSquare className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium">{selected.size} selezionati</span>
          <Button size="sm" variant="ghost" onClick={() => setSelected(new Set(filtered.map((b) => b.clas2)))}>
            Seleziona tutti i filtrati ({filtered.length})
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setSelected(new Set())}>
            Deseleziona
          </Button>
          <div className="flex-1" />
          {canEditBrand && (
            <>
              <Button size="sm" disabled={bulkBusy} onClick={() => bulkSetPublished(true)} className="bg-green-600 hover:bg-green-700">
                {bulkBusy && <Loader2 className="h-3 w-3 mr-1 animate-spin" />}
                🛒 Pubblica online
              </Button>
              <Button size="sm" variant="destructive" disabled={bulkBusy} onClick={() => bulkSetPublished(false)}>
                ⊘ Metti offline
              </Button>
            </>
          )}
        </div>
      )}

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-10">
                <Checkbox
                  checked={filtered.length > 0 && filtered.every((b) => selected.has(b.clas2))}
                  onCheckedChange={(v) => {
                    if (v) setSelected(new Set(filtered.map((b) => b.clas2)));
                    else setSelected(new Set());
                  }}
                />
              </TableHead>
              <TableHead className="w-16">Logo</TableHead>
              <TableHead>Nome</TableHead>
              <TableHead className="w-24">Codice</TableHead>
              <TableHead className="w-28">Stato B2B</TableHead>
              <TableHead className="w-32 text-right">Articoli online</TableHead>
              <TableHead className="w-32">Completezza</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading && (
              <TableRow><TableCell colSpan={7} className="text-center py-8">Caricamento…</TableCell></TableRow>
            )}
            {!loading && filtered.map((b) => {
              const comp = calcCompleteness(b);
              return (
                <TableRow key={b.clas2} data-state={selected.has(b.clas2) ? "selected" : undefined} className="hover:bg-muted/50">
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <Checkbox checked={selected.has(b.clas2)} onCheckedChange={() => toggleSel(b.clas2)} />
                  </TableCell>
                  <TableCell>
                    <Link to={`/pim/b2b/brands/${encodeURIComponent(b.clas2)}`}>
                      {b.logo_url ? (
                        <img src={b.logo_url} alt="" className="h-10 w-10 object-contain rounded border bg-white p-1" />
                      ) : (
                        <div className="h-10 w-10 rounded border bg-muted" />
                      )}
                    </Link>
                  </TableCell>
                  <TableCell>
                    <Link to={`/pim/b2b/brands/${encodeURIComponent(b.clas2)}`} className="font-medium hover:underline">
                      {b.display_name || b.nome_as400_brand || "(senza nome)"}
                    </Link>
                  </TableCell>
                  <TableCell className="font-mono text-xs">{b.clas2}</TableCell>
                  <TableCell>
                    {b.is_published_b2b ? (
                      <Badge className="text-xs bg-green-600 hover:bg-green-600">🛒 Online</Badge>
                    ) : (
                      <Badge className="text-xs bg-red-600 hover:bg-red-600 text-white">⊘ Offline</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {countsLoading ? (
                      <Loader2 className="h-3 w-3 animate-spin inline" />
                    ) : (counts[b.clas2] ?? 0) > 0 ? (
                      <span className="font-medium">{counts[b.clas2].toLocaleString("it-IT")}</span>
                    ) : (
                      <span className="text-muted-foreground">0</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className="h-2 w-20 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary" style={{ width: `${comp}%` }} />
                      </div>
                      <span className="text-xs text-muted-foreground">{comp}%</span>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}

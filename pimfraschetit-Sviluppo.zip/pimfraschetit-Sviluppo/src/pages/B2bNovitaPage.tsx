import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  ImageIcon, Search, ExternalLink, ArrowUp, ArrowDown, ArrowUpDown,
  Plus, Star, Trash2, CalendarClock,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useOnlineAssortments, buildOnlineB2bOrFilter } from "@/hooks/useOnlineAssortments";

const NOVITA_WINDOW_DAYS = 90;

type Article = {
  cdpar: string;
  depar: string | null;
  tags: string[] | null;
  wfuas: string | null;
  b2b_first_published_at: string | null;
  b2b_online_active: boolean | null;
};

type Override = {
  id: string;
  cdpar: string;
  valid_from: string;
  valid_to: string | null;
  note: string | null;
};

type Row = Article & {
  source: "auto" | "manual";
  novitaUntil: string | null; // ISO
  overrideId?: string;
  note?: string | null;
};

type SortKey = "cdpar" | "depar" | "wfuas" | "source" | "published" | "until";

const padCdpar = (s: string) => s.trim().padEnd(15, " ");
const trimCdpar = (s: string) => (s ?? "").trim();
const fmt = (iso: string | null | undefined) =>
  iso ? new Date(iso).toLocaleDateString("it-IT") : "—";
const toDateInput = (iso: string | null | undefined) => {
  if (!iso) return "";
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};
const defaultUntil = () => {
  const d = new Date();
  d.setDate(d.getDate() + NOVITA_WINDOW_DAYS);
  return toDateInput(d.toISOString());
};

const PAGE_SIZE = 50;

export default function B2bNovitaPage() {
  const qc = useQueryClient();
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("published");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [page, setPage] = useState(1);
  const [addOpen, setAddOpen] = useState(false);
  const [removeId, setRemoveId] = useState<string | null>(null);
  const { data: onlineAssortments = [] } = useOnlineAssortments();
  const onlineOrFilter = buildOnlineB2bOrFilter(onlineAssortments);


  // Debounce search
  useState(() => undefined);
  useMemo(() => {
    const t = setTimeout(() => setDebouncedSearch(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);
  // Reset page on filters change
  useMemo(() => { setPage(1); }, [debouncedSearch, sortKey, sortDir]);

  const toggleSort = (k: SortKey) => {
    if (sortKey === k) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(k); setSortDir(k === "published" || k === "until" ? "desc" : "asc"); }
  };

  // Map sort key to DB column (server-side ordering). For "until" usiamo published.
  const dbSortColumn = (k: SortKey): string => {
    switch (k) {
      case "cdpar": return "cdpar";
      case "depar": return "depar";
      case "wfuas": return "wfuas";
      case "until":
      case "published": return "b2b_first_published_at";
      default: return "b2b_first_published_at";
    }
  };

  // Override manuali validi (sempre tutti in memoria - sono pochi)
  const { data: overrides = [], isLoading: loadingOv } = useQuery({
    queryKey: ["b2b_novita_overrides"],
    queryFn: async () => {
      const nowIso = new Date().toISOString();
      const { data, error } = await supabase
        .from("b2b_novita_overrides")
        .select("*")
        .or(`valid_to.is.null,valid_to.gt.${nowIso}`);
      if (error) throw error;
      return (data ?? []).map((o: any) => ({ ...o, cdpar: trimCdpar(o.cdpar) })) as Override[];
    },
  });

  // Articoli per i cdpar negli override
  const overrideCdpars = useMemo(() => overrides.map((o) => o.cdpar), [overrides]);
  const { data: overrideArticles = [] } = useQuery({
    queryKey: ["b2b_novita_override_articles", overrideCdpars.join(",")],
    enabled: overrideCdpars.length > 0,
    queryFn: async () => {
      const padded = overrideCdpars.map(padCdpar);
      const { data, error } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar,depar,tags,wfuas,b2b_first_published_at,b2b_online_active")
        .in("cdpar", padded);
      if (error) throw error;
      return (data ?? []).map((a: any) => ({ ...a, cdpar: trimCdpar(a.cdpar) })) as Article[];
    },
  });

  // Auto novità paginati server-side
  const { data: autoData, isLoading: loadingAuto, isFetching: fetchingAuto } = useQuery({
    queryKey: ["b2b_novita_auto", page, debouncedSearch, sortKey, sortDir, overrideCdpars.length, onlineAssortments.join(",")],
    queryFn: async () => {
      const since = new Date();
      since.setDate(since.getDate() - NOVITA_WINDOW_DAYS);
      const from = (page - 1) * PAGE_SIZE;
      const to = from + PAGE_SIZE - 1;
      let q = supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar,depar,tags,wfuas,b2b_first_published_at,b2b_online_active", { count: "exact" })
        .or(onlineOrFilter)
        .gte("b2b_first_published_at", since.toISOString());

      // Escludi i cdpar già presenti come manuali (verranno mostrati separatamente)
      if (overrideCdpars.length > 0) {
        const padded = overrideCdpars.map(padCdpar);
        q = q.not("cdpar", "in", `(${padded.map((p) => `"${p}"`).join(",")})`);
      }

      // Ricerca
      if (debouncedSearch) {
        const s = debouncedSearch.replace(/[%,]/g, " ");
        q = q.or(`cdpar.ilike.%${s}%,depar.ilike.%${s}%`);
      }

      const { data, error, count } = await q
        .order(dbSortColumn(sortKey), { ascending: sortDir === "asc", nullsFirst: false })
        .range(from, to);
      if (error) throw error;
      return {
        rows: (data ?? []).map((a: any) => ({ ...a, cdpar: trimCdpar(a.cdpar) })) as Article[],
        total: count ?? 0,
      };
    },
  });
  const autoArticles = autoData?.rows ?? [];
  const autoTotal = autoData?.total ?? 0;

  // Costruisco le righe della pagina corrente.
  // Pagina 1: prima i manuali (filtrati da search), poi gli auto della pagina.
  // Pagine successive: solo auto.
  const manualRows: Row[] = useMemo(() => {
    const ovById = new Map(overrides.map((o) => [o.cdpar, o]));
    const list: Row[] = overrideArticles
      .map((a) => {
        const ov = ovById.get(a.cdpar);
        if (!ov) return null;
        return {
          ...a,
          source: "manual" as const,
          novitaUntil: ov.valid_to,
          overrideId: ov.id,
          note: ov.note,
        };
      })
      .filter((x): x is NonNullable<typeof x> => !!x) as Row[];
    if (!debouncedSearch) return list;
    const s = debouncedSearch.toLowerCase();
    return list.filter((r) =>
      r.cdpar.toLowerCase().includes(s) ||
      (r.depar ?? "").toLowerCase().includes(s) ||
      (r.tags ?? []).some((t) => t.toLowerCase().includes(s))
    );
  }, [overrides, overrideArticles, debouncedSearch]);

  const autoRows: Row[] = useMemo(() =>
    autoArticles.map((a) => {
      const until = a.b2b_first_published_at
        ? new Date(new Date(a.b2b_first_published_at).getTime() + NOVITA_WINDOW_DAYS * 86400000).toISOString()
        : null;
      return { ...a, source: "auto", novitaUntil: until };
    }),
  [autoArticles]);

  const visibleRows: Row[] = useMemo(() =>
    page === 1 ? [...manualRows, ...autoRows] : autoRows,
  [page, manualRows, autoRows]);

  // Media per le righe visibili
  const cdpars = useMemo(() => visibleRows.map((r) => r.cdpar), [visibleRows]);
  const { data: mediaMap = {} } = useQuery({
    queryKey: ["b2b_novita_media", cdpars.join(",")],
    enabled: cdpars.length > 0,
    queryFn: async () => {
      console.log("[novita] fetching media for", cdpars.length, "cdpars; sample:", cdpars.slice(0, 3));
      const { data, error } = await supabase
        .from("article_media")
        .select("cdpar,public_url,is_primary")
        .in("cdpar", cdpars)
        .eq("media_type", "image");
      if (error) {
        console.error("[novita] media error", error);
        throw error;
      }
      console.log("[novita] media rows received:", data?.length ?? 0, "sample:", data?.slice(0, 2));
      const out: Record<string, string> = {};
      for (const m of (data ?? [])) {
        const key = trimCdpar(m.cdpar ?? "");
        if (!out[key] || m.is_primary) out[key] = m.public_url;
      }
      console.log("[novita] mediaMap entries:", Object.keys(out).length);
      return out;
    },
  });

  const totalPages = Math.max(1, Math.ceil(autoTotal / PAGE_SIZE));
  const counts = { manual: manualRows.length };

  const SortIcon = ({ k }: { k: SortKey }) =>
    sortKey !== k ? <ArrowUpDown className="h-3 w-3 opacity-40" /> :
    sortDir === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />;

  const removeOverride = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("b2b_novita_overrides").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Rimosso dalle Novità" });
      qc.invalidateQueries({ queryKey: ["b2b_novita_overrides"] });
      setRemoveId(null);
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const isLoading = loadingAuto || loadingOv;

  return (
    <div className="p-6 space-y-4 max-w-7xl">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold flex items-center gap-2">
            <Star className="h-5 w-5 text-amber-500" /> Novità B2B
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Articoli pubblicati per la prima volta sul B2B negli ultimi {NOVITA_WINDOW_DAYS} giorni,
            più gli articoli forzati manualmente con data di scadenza.
          </p>
          <div className="flex items-center gap-2 mt-2 text-xs flex-wrap">
            <Badge variant="outline" className="bg-green-600/10 text-green-700 border-green-600/30">
              Auto: {autoTotal}
            </Badge>
            <Badge variant="outline" className="bg-blue-600/10 text-blue-700 border-blue-600/30">
              Manuale: {counts.manual}
            </Badge>
            <Badge variant="secondary">Totale: {autoTotal + counts.manual}</Badge>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative w-64">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Filtra cdpar, descrizione, tag..."
              className="pl-8 h-9"
            />
          </div>
          <Button onClick={() => setAddOpen(true)}>
            <Plus className="h-4 w-4 mr-1" /> Aggiungi
          </Button>
        </div>
      </div>

      <div className="rounded-lg border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 border-b text-left">
            <tr>
              <th className="px-3 py-2 w-16"></th>
              <th className="px-3 py-2 w-32">
                <button onClick={() => toggleSort("cdpar")} className="inline-flex items-center gap-1 hover:text-foreground">
                  CDPAR <SortIcon k="cdpar" />
                </button>
              </th>
              <th className="px-3 py-2">
                <button onClick={() => toggleSort("depar")} className="inline-flex items-center gap-1 hover:text-foreground">
                  Descrizione <SortIcon k="depar" />
                </button>
              </th>
              <th className="px-3 py-2 w-24">
                <button onClick={() => toggleSort("wfuas")} className="inline-flex items-center gap-1 hover:text-foreground">
                  Stato <SortIcon k="wfuas" />
                </button>
              </th>
              <th className="px-3 py-2 w-24">
                <button onClick={() => toggleSort("source")} className="inline-flex items-center gap-1 hover:text-foreground">
                  Origine <SortIcon k="source" />
                </button>
              </th>
              <th className="px-3 py-2 w-32">
                <button onClick={() => toggleSort("published")} className="inline-flex items-center gap-1 hover:text-foreground">
                  Pubblicato <SortIcon k="published" />
                </button>
              </th>
              <th className="px-3 py-2 w-32">
                <button onClick={() => toggleSort("until")} className="inline-flex items-center gap-1 hover:text-foreground">
                  Novità fino al <SortIcon k="until" />
                </button>
              </th>
              <th className="px-3 py-2 w-20"></th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={8} className="px-3 py-8 text-center text-muted-foreground">Caricamento...</td></tr>
            ) : visibleRows.length === 0 ? (
              <tr><td colSpan={8} className="px-3 py-8 text-center text-muted-foreground">
                Nessun articolo in Novità. Usa "Aggiungi" per inserirne manualmente.
              </td></tr>
            ) : visibleRows.map((a) => {
              const img = mediaMap[a.cdpar];
              return (
                <tr key={a.cdpar} className="border-b last:border-b-0 hover:bg-muted/20">
                  <td className="px-3 py-2">
                    <div className="h-12 w-12 rounded border bg-muted/30 flex items-center justify-center overflow-hidden">
                      {img ? (
                        <img src={img} alt={a.cdpar} className="w-full h-full object-contain" />
                      ) : (
                        <ImageIcon className="h-5 w-5 text-muted-foreground/40" />
                      )}
                    </div>
                  </td>
                  <td className="px-3 py-2 font-mono text-xs">{a.cdpar}</td>
                  <td className="px-3 py-2">
                    <div>{a.depar ?? "—"}</div>
                    {a.note && (
                      <div className="text-[11px] text-muted-foreground italic mt-0.5">📝 {a.note}</div>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    {a.wfuas ? (
                      <Badge variant="outline" className="text-xs font-mono">{a.wfuas}</Badge>
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    {a.source === "auto" ? (
                      <Badge variant="outline" className="bg-green-600/10 text-green-700 border-green-600/30 text-[10px]">
                        Auto
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-blue-600/10 text-blue-700 border-blue-600/30 text-[10px]">
                        Manuale
                      </Badge>
                    )}
                  </td>
                  <td className="px-3 py-2 text-xs">{fmt(a.b2b_first_published_at)}</td>
                  <td className="px-3 py-2 text-xs">
                    {a.novitaUntil ? (
                      <span className="inline-flex items-center gap-1">
                        <CalendarClock className="h-3 w-3 text-muted-foreground" />
                        {fmt(a.novitaUntil)}
                      </span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex items-center justify-end gap-1">
                      <Button asChild variant="ghost" size="icon" className="h-7 w-7">
                        <Link to={`/pim/articles/${a.cdpar}`} title="Apri articolo">
                          <ExternalLink className="h-3.5 w-3.5" />
                        </Link>
                      </Button>
                      {a.source === "manual" && a.overrideId && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive"
                          title="Rimuovi dalle Novità"
                          onClick={() => setRemoveId(a.overrideId!)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Paginazione */}
      <div className="flex items-center justify-between text-sm">
        <div className="text-muted-foreground">
          {fetchingAuto ? "Caricamento..." : (
            <>
              Pagina <strong>{page}</strong> di <strong>{totalPages}</strong>
              {" · "}
              Auto: {Math.min((page - 1) * PAGE_SIZE + 1, autoTotal)}–{Math.min(page * PAGE_SIZE, autoTotal)} di {autoTotal}
              {page === 1 && counts.manual > 0 && <> · + {counts.manual} manuali</>}
            </>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button variant="outline" size="sm" disabled={page === 1 || fetchingAuto} onClick={() => setPage(1)}>
            «
          </Button>
          <Button variant="outline" size="sm" disabled={page === 1 || fetchingAuto} onClick={() => setPage((p) => Math.max(1, p - 1))}>
            ‹ Prec
          </Button>
          <span className="px-2 text-xs text-muted-foreground">{page} / {totalPages}</span>
          <Button variant="outline" size="sm" disabled={page >= totalPages || fetchingAuto} onClick={() => setPage((p) => Math.min(totalPages, p + 1))}>
            Succ ›
          </Button>
          <Button variant="outline" size="sm" disabled={page >= totalPages || fetchingAuto} onClick={() => setPage(totalPages)}>
            »
          </Button>
        </div>
      </div>

      <AddNovitaDialog
        open={addOpen}
        onClose={() => setAddOpen(false)}
        userId={user?.id}
        existingOverrides={overrides}
        onSaved={() => {
          qc.invalidateQueries({ queryKey: ["b2b_novita_overrides"] });
        }}
      />

      <AlertDialog open={!!removeId} onOpenChange={(o) => !o && setRemoveId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Rimuovere dalle Novità?</AlertDialogTitle>
            <AlertDialogDescription>
              L'articolo non sarà più mostrato come Novità nel B2B. Puoi sempre riaggiungerlo manualmente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction onClick={() => removeId && removeOverride.mutate(removeId)}>
              Rimuovi
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ============================================================
// Add dialog
// ============================================================

type SearchHit = {
  cdpar: string;
  depar: string | null;
  wfuas: string | null;
};

function parseBatchCodes(input: string): string[] {
  const tokens = input.split(/[\s,;]+/).map((t) => t.trim()).filter(Boolean);
  const codes = tokens.filter((t) => /^\d{3,15}$/.test(t));
  // dedup preserving order
  return Array.from(new Set(codes));
}

function AddNovitaDialog({
  open, onClose, userId, existingOverrides, onSaved,
}: {
  open: boolean;
  onClose: () => void;
  userId: string | undefined;
  existingOverrides: Override[];
  onSaved: () => void;
}) {
  const [q, setQ] = useState("");
  const [pickedCdpar, setPickedCdpar] = useState<string | null>(null);
  const [pickedDepar, setPickedDepar] = useState<string>("");
  const [until, setUntil] = useState<string>(defaultUntil());
  const [note, setNote] = useState<string>("");

  const parsedCodes = useMemo(() => parseBatchCodes(q), [q]);
  const isBatch = parsedCodes.length >= 2 && !pickedCdpar;

  const { data: hits = [], isFetching } = useQuery({
    queryKey: ["b2b_novita_search", q],
    enabled: open && q.trim().length >= 2 && !pickedCdpar && !isBatch,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("search_articles", {
        query: q.trim(), lim: 20, off: 0,
      });
      if (error) throw error;
      return ((data ?? []) as any[]).map((r) => ({
        cdpar: trimCdpar(r.cdpar),
        depar: r.depar,
        wfuas: r.wfuas,
      })) as SearchHit[];
    },
  });

  const { data: batchResolved, isFetching: isResolving } = useQuery({
    queryKey: ["b2b_novita_batch_resolve", parsedCodes],
    enabled: open && isBatch,
    queryFn: async () => {
      const padded = parsedCodes.map(padCdpar);
      const { data, error } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar,depar")
        .in("cdpar", padded);
      if (error) throw error;
      const foundMap = new Map(
        (data ?? []).map((r: any) => [trimCdpar(r.cdpar), r.depar as string | null])
      );
      const found = parsedCodes.filter((c) => foundMap.has(c));
      const missing = parsedCodes.filter((c) => !foundMap.has(c));
      return { found, missing, foundMap };
    },
  });

  const existingMap = useMemo(
    () => new Map(existingOverrides.map((o) => [o.cdpar, o])),
    [existingOverrides]
  );

  const reset = () => {
    setQ(""); setPickedCdpar(null); setPickedDepar("");
    setUntil(defaultUntil()); setNote("");
  };

  const handleClose = () => { reset(); onClose(); };

  const save = useMutation({
    mutationFn: async () => {
      const validTo = until ? new Date(until + "T23:59:59").toISOString() : null;

      // Batch path
      if (isBatch && batchResolved) {
        const { found } = batchResolved;
        if (found.length === 0) throw new Error("Nessun codice valido da aggiungere");
        const toInsert = found
          .filter((c) => !existingMap.has(c))
          .map((cdpar) => ({
            cdpar,
            valid_to: validTo,
            note: note || null,
            created_by: userId ?? null,
          }));
        const toUpdate = found.filter((c) => existingMap.has(c));

        if (toInsert.length > 0) {
          const { error } = await supabase
            .from("b2b_novita_overrides")
            .insert(toInsert);
          if (error) throw error;
        }
        for (const c of toUpdate) {
          const ex = existingMap.get(c)!;
          const { error } = await supabase
            .from("b2b_novita_overrides")
            .update({ valid_to: validTo, note: note || null })
            .eq("id", ex.id);
          if (error) throw error;
        }
        return {
          batch: true as const,
          inserted: toInsert.length,
          updated: toUpdate.length,
          missing: batchResolved.missing.length,
        };
      }

      // Single path
      if (!pickedCdpar) throw new Error("Seleziona un articolo");
      const existing = existingMap.get(pickedCdpar);
      if (existing) {
        const { error } = await supabase
          .from("b2b_novita_overrides")
          .update({ valid_to: validTo, note: note || null })
          .eq("id", existing.id);
        if (error) throw error;
        return { batch: false as const, updated: true };
      }
      const { error } = await supabase
        .from("b2b_novita_overrides")
        .insert({
          cdpar: pickedCdpar,
          valid_to: validTo,
          note: note || null,
          created_by: userId ?? null,
        });
      if (error) throw error;
      return { batch: false as const, updated: false };
    },
    onSuccess: (r) => {
      if (r.batch) {
        toast({
          title: "Novità aggiornate",
          description: `Aggiunti ${r.inserted} · Aggiornati ${r.updated}${r.missing > 0 ? ` · Non trovati ${r.missing}` : ""}`,
        });
      } else {
        toast({ title: r.updated ? "Scadenza aggiornata" : "Aggiunto alle Novità" });
      }
      onSaved();
      handleClose();
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const batchFoundCount = batchResolved?.found.length ?? 0;
  const batchMissingCount = batchResolved?.missing.length ?? 0;
  const batchAlreadyCount = batchResolved
    ? batchResolved.found.filter((c) => existingMap.has(c)).length
    : 0;

  return (
    <Dialog open={open} onOpenChange={(o) => !o && handleClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Aggiungi articolo alle Novità</DialogTitle>
        </DialogHeader>

        {!pickedCdpar ? (
          <div className="space-y-3">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                autoFocus
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Cerca per cdpar, descrizione, EAN... oppure incolla più codici"
                className="pl-8"
              />
              <p className="text-[11px] text-muted-foreground mt-1">
                Suggerimento: incolla una lista di codici separati da spazi, virgole o newline (es. da Excel) per aggiungerli in blocco.
              </p>
            </div>

            {isBatch ? (
              <div className="space-y-3">
                <div className="rounded border p-3 bg-muted/20 space-y-2">
                  <div className="text-sm font-medium">
                    {parsedCodes.length} codici riconosciuti
                  </div>
                  {isResolving ? (
                    <div className="text-sm text-muted-foreground">Verifica in corso...</div>
                  ) : batchResolved ? (
                    <div className="flex flex-wrap gap-2 text-xs">
                      <Badge variant="default">✓ Trovati {batchFoundCount}</Badge>
                      {batchAlreadyCount > 0 && (
                        <Badge variant="secondary">Già novità {batchAlreadyCount}</Badge>
                      )}
                      {batchMissingCount > 0 && (
                        <Badge variant="destructive">✗ Non trovati {batchMissingCount}</Badge>
                      )}
                    </div>
                  ) : null}
                  {batchResolved && batchResolved.missing.length > 0 && (
                    <div className="text-[11px] text-muted-foreground">
                      Non trovati: <span className="font-mono">{batchResolved.missing.join(", ")}</span>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-medium">Novità fino al</label>
                    <Input
                      type="date"
                      value={until}
                      onChange={(e) => setUntil(e.target.value)}
                    />
                    <p className="text-[11px] text-muted-foreground">Applicato a tutti. Lascia vuoto per nessuna scadenza.</p>
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-medium">Nota (opzionale)</label>
                    <Input
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder="es. Lancio campagna autunnale"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="rounded border max-h-80 overflow-auto divide-y">
                {q.trim().length < 2 ? (
                  <div className="p-6 text-center text-sm text-muted-foreground">
                    Digita almeno 2 caratteri per cercare.
                  </div>
                ) : isFetching ? (
                  <div className="p-6 text-center text-sm text-muted-foreground">Ricerca...</div>
                ) : hits.length === 0 ? (
                  <div className="p-6 text-center text-sm text-muted-foreground">Nessun risultato.</div>
                ) : hits.map((h) => {
                  const already = existingMap.has(h.cdpar);
                  return (
                    <div key={h.cdpar} className="flex items-center gap-2 p-2 hover:bg-muted/30">
                      <div className="flex-1 min-w-0">
                        <div className="font-mono text-xs text-muted-foreground">{h.cdpar}</div>
                        <div className="text-sm truncate">{h.depar ?? "—"}</div>
                      </div>
                      {already && (
                        <Badge variant="outline" className="text-[10px]">Già presente</Badge>
                      )}
                      <Button
                        size="icon"
                        variant="outline"
                        className="h-7 w-7"
                        onClick={() => {
                          setPickedCdpar(h.cdpar);
                          setPickedDepar(h.depar ?? "");
                          const ex = existingMap.get(h.cdpar);
                          if (ex?.valid_to) setUntil(toDateInput(ex.valid_to));
                          if (ex?.note) setNote(ex.note);
                        }}
                        title={already ? "Aggiorna scadenza" : "Aggiungi"}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="rounded border p-3 bg-muted/20">
              <div className="font-mono text-xs text-muted-foreground">{pickedCdpar}</div>
              <div className="text-sm">{pickedDepar || "—"}</div>
              {existingMap.has(pickedCdpar) && (
                <Badge variant="outline" className="text-[10px] mt-1">
                  Aggiornamento di un override esistente
                </Badge>
              )}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-medium">Novità fino al</label>
                <Input
                  type="date"
                  value={until}
                  onChange={(e) => setUntil(e.target.value)}
                />
                <p className="text-[11px] text-muted-foreground">Lascia vuoto per nessuna scadenza.</p>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-medium">Nota (opzionale)</label>
                <Input
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="es. Lancio campagna autunnale"
                />
              </div>
            </div>
          </div>
        )}

        <DialogFooter>
          {pickedCdpar && (
            <Button variant="ghost" onClick={() => setPickedCdpar(null)}>
              ← Cambia articolo
            </Button>
          )}
          <Button variant="outline" onClick={handleClose}>Annulla</Button>
          <Button
            disabled={
              save.isPending ||
              (isBatch ? batchFoundCount === 0 || isResolving : !pickedCdpar)
            }
            onClick={() => save.mutate()}
          >
            {save.isPending
              ? "Salvo..."
              : isBatch
                ? `Aggiungi ${batchFoundCount} articol${batchFoundCount === 1 ? "o" : "i"}`
                : existingMap.has(pickedCdpar ?? "") ? "Aggiorna" : "Aggiungi"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Plus, Pencil, Trash2, Copy } from "lucide-react";
import { toast } from "sonner";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { format } from "date-fns";

interface NewsRow {
  id: string;
  title: string;
  status: "draft" | "published";
  published_at: string | null;
  cover_image_url: string | null;
  pdf_url: string | null;
  body_html: string | null;
  updated_at: string;
  links_count: number;
  reads_count: number;
}

export default function AgentNewsPage() {
  const navigate = useNavigate();
  const confirm = useConfirm();
  const [items, setItems] = useState<NewsRow[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("news" as any)
      .select("id,title,status,published_at,cover_image_url,pdf_url,body_html,updated_at,news_links(count),news_reads(count)")
      .order("created_at", { ascending: false });
    if (error) {
      toast.error(error.message);
      setItems([]);
      setLoading(false);
      return;
    }
    setItems(
      ((data as any[]) || []).map((r) => ({
        ...r,
        links_count: r.news_links?.[0]?.count ?? 0,
        reads_count: r.news_reads?.[0]?.count ?? 0,
      }))
    );
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const togglePublish = async (n: NewsRow, publish: boolean) => {
    const patch: any = { status: publish ? "published" : "draft" };
    if (publish && !n.published_at) patch.published_at = new Date().toISOString();
    const { error } = await supabase.from("news" as any).update(patch).eq("id", n.id);
    if (error) return toast.error(error.message);
    setItems((p) => p.map((i) => (i.id === n.id ? { ...i, status: patch.status, published_at: patch.published_at ?? i.published_at } : i)));
  };

  const remove = async (n: NewsRow) => {
    if (!(await confirm({ title: "Eliminare la news?", description: "Verranno rimossi anche i link agli articoli e i tracking di lettura.", destructive: true, confirmText: "Elimina" }))) return;
    const { error } = await supabase.from("news" as any).delete().eq("id", n.id);
    if (error) return toast.error(error.message);
    toast.success("Eliminata");
    setItems((p) => p.filter((i) => i.id !== n.id));
  };

  const duplicate = async (n: NewsRow) => {
    const { data: full, error: e1 } = await supabase
      .from("news" as any)
      .select("title,body_html,cover_image_url,pdf_url,pdf_filename")
      .eq("id", n.id)
      .single();
    if (e1) return toast.error(e1.message);
    const { data: newRow, error: e2 } = await supabase
      .from("news" as any)
      .insert({ ...(full as any), title: `${(full as any).title} (copia)`, status: "draft", published_at: null })
      .select("id")
      .single();
    if (e2) return toast.error(e2.message);
    const { data: links } = await supabase
      .from("news_links" as any)
      .select("link_type,target_ref,label")
      .eq("news_id", n.id);
    if (links && links.length > 0) {
      await supabase.from("news_links" as any).insert(
        (links as any[]).map((l) => ({ ...l, news_id: (newRow as any).id }))
      );
    }
    toast.success("Duplicata");
    navigate(`/pim/agent-news/${(newRow as any).id}`);
  };

  const create = async () => {
    const { data, error } = await supabase
      .from("news" as any)
      .insert({ title: "Nuova news", body_html: "", status: "draft" })
      .select("id")
      .single();
    if (error) return toast.error(error.message);
    navigate(`/pim/agent-news/${(data as any).id}`);
  };

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">News</h1>
          <p className="text-sm text-muted-foreground">Articoli editoriali tecnico-commerciali consumati dagli agenti nel Portale dedicato.</p>
        </div>
        <Button onClick={create}><Plus className="h-4 w-4 mr-2" />Nuova news</Button>
      </div>

      <Card className="p-0 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="text-left px-4 py-2">Titolo</th>
              <th className="text-left px-4 py-2">Stato</th>
              <th className="text-left px-4 py-2">Pubblicata il</th>
              <th className="text-left px-4 py-2">Link</th>
              <th className="text-left px-4 py-2">Letture</th>
              <th className="text-left px-4 py-2">Aggiornata</th>
              <th className="text-left px-4 py-2">Pubblica</th>
              <th className="px-4 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={8} className="p-6 text-center text-muted-foreground">Caricamento…</td></tr>
            )}
            {!loading && items.length === 0 && (
              <tr><td colSpan={8} className="p-6 text-center text-muted-foreground">Nessuna news</td></tr>
            )}
            {items.map((n) => (
              <tr key={n.id} className="border-t hover:bg-muted/30">
                <td className="px-4 py-2 font-medium">
                  <Link to={`/pim/agent-news/${n.id}`} className="hover:underline">{n.title}</Link>
                </td>
                <td className="px-4 py-2">
                  {n.status === "published" ? <Badge>Pubblicata</Badge> : <Badge variant="secondary">Bozza</Badge>}
                </td>
                <td className="px-4 py-2 text-muted-foreground">
                  {n.published_at ? format(new Date(n.published_at), "dd/MM/yyyy HH:mm") : "—"}
                </td>
                <td className="px-4 py-2">{n.links_count}</td>
                <td className="px-4 py-2">{n.reads_count}</td>
                <td className="px-4 py-2 text-muted-foreground">{format(new Date(n.updated_at), "dd/MM/yyyy HH:mm")}</td>
                <td className="px-4 py-2">
                  <Switch checked={n.status === "published"} onCheckedChange={(v) => togglePublish(n, v)} />
                </td>
                <td className="px-4 py-2">
                  <div className="flex justify-end gap-1">
                    <Button size="sm" variant="ghost" asChild><Link to={`/pim/agent-news/${n.id}`}><Pencil className="h-4 w-4" /></Link></Button>
                    <Button size="sm" variant="ghost" onClick={() => duplicate(n)}><Copy className="h-4 w-4" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => remove(n)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Search, Barcode } from "lucide-react";

export default function BarcodesPage() {
  const [search, setSearch] = useState("");

  const { data: barcodes = [], isLoading } = useQuery({
    queryKey: ["barcodes", search],
    queryFn: async () => {
      let query = supabase
        .from("archivio_codici_barre_fraschetti")
        .select("*")
        .order("wcdpa", { ascending: true })
        .limit(200);

      if (search.trim()) {
        query = query.or(`wcdpa.ilike.%${search}%,wcbda.ilike.%${search}%,wcbds.ilike.%${search}%`);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Codici a Barre</h1>
          <p className="text-muted-foreground text-sm">Gestione codici a barre articoli</p>
        </div>
        <Badge variant="secondary">{barcodes.length} risultati</Badge>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Cerca per codice articolo o barcode..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      <div className="border rounded-lg overflow-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Codice Articolo</TableHead>
              <TableHead>Codice a Barre</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Data</TableHead>
              <TableHead>Imballo</TableHead>
              <TableHead>Prezzo</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                 <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  Caricamento...
                </TableCell>
              </TableRow>
            ) : barcodes.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  <Barcode className="mx-auto h-8 w-8 mb-2 opacity-40" />
                  Nessun codice a barre trovato
                </TableCell>
              </TableRow>
            ) : (
              barcodes.map((b) => (
                <TableRow key={b.id}>
                  <TableCell className="font-mono font-medium">{b.wcdpa}</TableCell>
                  <TableCell className="font-mono">{b.wcpba || "—"}</TableCell>
                  <TableCell>
                    {b.wtpco ? <Badge variant="outline">{b.wtpco}</Badge> : "—"}
                  </TableCell>
                  <TableCell>{b.wcbda || "—"}</TableCell>
                  <TableCell>{b.wimbc ?? "—"}</TableCell>
                  <TableCell>{b.wprim != null ? `€ ${Number(b.wprim).toFixed(2)}` : "—"}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

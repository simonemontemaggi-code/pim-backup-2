import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { CalendarIcon, Download } from "lucide-react";
import { format } from "date-fns";
import { downloadXlsx } from "@/lib/xlsxExport";
import {
  useSearchMissesAgg, useSearchMissesTimeseries, useArticlePerfTop,
  type SourceFilter,
} from "@/hooks/useNavigationAnalysis";
import { SearchMissesTable } from "@/components/navigation-analysis/SearchMissesTable";
import { SearchMissesTrendChart } from "@/components/navigation-analysis/SearchMissesTrendChart";
import { ArticlePerformanceTable } from "@/components/navigation-analysis/ArticlePerformanceTable";
import { ArticleDetailDrawer } from "@/components/navigation-analysis/ArticleDetailDrawer";

function daysAgo(n: number) {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - n);
  return d;
}

export default function NavigationAnalysisPage() {
  const [sp, setSp] = useSearchParams();
  const [from, setFrom] = useState<Date>(() =>
    sp.get("from") ? new Date(sp.get("from")!) : daysAgo(30),
  );
  const [to, setTo] = useState<Date>(() =>
    sp.get("to") ? new Date(sp.get("to")!) : new Date(),
  );
  const [source, setSource] = useState<SourceFilter>((sp.get("src") as SourceFilter) || "all");
  const [minCount, setMinCount] = useState<number>(Number(sp.get("min") ?? 1));
  const [hideResolved, setHideResolved] = useState<boolean>(sp.get("hr") === "1");
  const [orderBy, setOrderBy] = useState<string>(sp.get("ord") ?? "views");
  const [limit, setLimit] = useState<number>(Number(sp.get("lim") ?? 50));
  const [selected, setSelected] = useState<string | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const updateParams = (patch: Record<string, string | undefined>) => {
    const n = new URLSearchParams(sp);
    Object.entries(patch).forEach(([k, v]) => {
      if (v == null || v === "") n.delete(k); else n.set(k, v);
    });
    setSp(n, { replace: true });
  };

  const { data: rawAggRows = [] } = useSearchMissesAgg(from, to, source, minCount);
  const { data: tsRows = [] } = useSearchMissesTimeseries(from, to);
  const { data: topRows = [] } = useArticlePerfTop(from, to, source, orderBy, limit);

  // Escludi query puramente numeriche e testuali sotto i 3 caratteri
  const aggRows = useMemo(
    () => rawAggRows.filter((r) => {
      const t = (r.query ?? "").trim();
      return !/^[0-9]+$/.test(t) && t.length >= 3;
    }),
    [rawAggRows],
  );

  const kpi = useMemo(() => {
    const total = aggRows.reduce((s, r) => s + Number(r.n), 0);
    const top5 = aggRows.slice(0, 5);
    return { total, unique: aggRows.length, top5 };
  }, [aggRows]);

  const exportSearchCsv = () => {
    const data = aggRows.map((r) => ({
      query: r.query, occorrenze: r.n, utenti: r.n_users, clienti: r.n_customers,
      ultima: r.last_seen, b2b: r.n_b2b, agent_hub: r.n_agent,
      gestita: r.resolved_at ? "sì" : "no",
    }));
    downloadXlsx(`ricerche-fallite_${format(new Date(), "yyyy-MM-dd")}.xlsx`, data, { sheetName: "Ricerche" });
  };

  const exportPerfCsv = () => {
    downloadXlsx(`articoli-performance_${format(new Date(), "yyyy-MM-dd")}.xlsx`, topRows as any[], { sheetName: "Performance" });
  };

  const DateRangePicker = (
    <div className="flex items-center gap-2">
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2">
            <CalendarIcon className="h-3.5 w-3.5" /> {format(from, "dd/MM/yy")}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={from} onSelect={(d) => d && (setFrom(d), updateParams({ from: d.toISOString() }))} /></PopoverContent>
      </Popover>
      <span className="text-muted-foreground text-sm">→</span>
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2">
            <CalendarIcon className="h-3.5 w-3.5" /> {format(to, "dd/MM/yy")}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={to} onSelect={(d) => d && (setTo(d), updateParams({ to: d.toISOString() }))} /></PopoverContent>
      </Popover>
      <Select value={source} onValueChange={(v) => { setSource(v as SourceFilter); updateParams({ src: v }); }}>
        <SelectTrigger className="w-36 h-8"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Tutte le sorgenti</SelectItem>
          <SelectItem value="b2b">B2B</SelectItem>
          <SelectItem value="agent_hub">Agent Hub</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );

  return (
    <div className="p-6 space-y-4">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Navigation Analysis</h1>
        <p className="text-sm text-muted-foreground">
          Dati di navigazione utenti da B2B Mockup e Agent Hub. Retention 12 mesi.
        </p>
      </div>

      <Tabs defaultValue="searches">
        <TabsList>
          <TabsTrigger value="searches">Ricerche senza risultati</TabsTrigger>
          <TabsTrigger value="products">Performance prodotti</TabsTrigger>
        </TabsList>

        <TabsContent value="searches" className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Card><CardContent className="p-4">
              <div className="text-xs text-muted-foreground">Totale ricerche fallite</div>
              <div className="text-2xl font-bold tabular-nums">{kpi.total}</div>
            </CardContent></Card>
            <Card><CardContent className="p-4">
              <div className="text-xs text-muted-foreground">Query uniche</div>
              <div className="text-2xl font-bold tabular-nums">{kpi.unique}</div>
            </CardContent></Card>
            <Card className="col-span-2"><CardContent className="p-4">
              <div className="text-xs text-muted-foreground mb-1">Top 5 query</div>
              <div className="flex flex-wrap gap-1.5">
                {kpi.top5.map((r) => (
                  <span key={r.query} className="text-xs bg-muted px-2 py-0.5 rounded font-mono">
                    {r.query} · {r.n}
                  </span>
                ))}
                {kpi.top5.length === 0 && <span className="text-xs text-muted-foreground">—</span>}
              </div>
            </CardContent></Card>
          </div>

          <Card><CardContent className="p-4 space-y-3">
            <div className="flex flex-wrap items-center gap-3">
              {DateRangePicker}
              <div className="flex items-center gap-2">
                <Label className="text-xs">Soglia min.</Label>
                <div className="w-32"><Slider min={1} max={50} step={1} value={[minCount]} onValueChange={(v) => { setMinCount(v[0]); updateParams({ min: String(v[0]) }); }} /></div>
                <span className="text-xs tabular-nums w-6">{minCount}</span>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={hideResolved} onCheckedChange={(v) => { setHideResolved(v); updateParams({ hr: v ? "1" : undefined }); }} />
                <Label className="text-xs">Nascondi gestite</Label>
              </div>
              <Button size="sm" variant="outline" onClick={exportSearchCsv} className="ml-auto gap-2">
                <Download className="h-3.5 w-3.5" /> CSV
              </Button>
            </div>
            <SearchMissesTrendChart data={tsRows} />
          </CardContent></Card>

          <SearchMissesTable rows={aggRows} hideResolved={hideResolved} />
        </TabsContent>

        <TabsContent value="products" className="space-y-4">
          <Card><CardContent className="p-4">
            <div className="flex flex-wrap items-center gap-3">
              {DateRangePicker}
              <Select value={orderBy} onValueChange={(v) => { setOrderBy(v); updateParams({ ord: v }); }}>
                <SelectTrigger className="w-40 h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="views">Più viste</SelectItem>
                  <SelectItem value="cart">Più carrello</SelectItem>
                  <SelectItem value="orders">Più ordinati</SelectItem>
                  <SelectItem value="conversion">Miglior conversione</SelectItem>
                </SelectContent>
              </Select>
              <Select value={String(limit)} onValueChange={(v) => { setLimit(Number(v)); updateParams({ lim: v }); }}>
                <SelectTrigger className="w-24 h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {[20, 50, 100, 200].map((n) => <SelectItem key={n} value={String(n)}>Top {n}</SelectItem>)}
                </SelectContent>
              </Select>
              <Button size="sm" variant="outline" onClick={exportPerfCsv} className="ml-auto gap-2">
                <Download className="h-3.5 w-3.5" /> CSV
              </Button>
            </div>
          </CardContent></Card>

          <ArticlePerformanceTable
            rows={topRows}
            onSelect={(c) => { setSelected(c); setDrawerOpen(true); }}
          />
        </TabsContent>
      </Tabs>

      <ArticleDetailDrawer
        cdpar={selected} from={from} to={to}
        open={drawerOpen} onOpenChange={setDrawerOpen}
      />
    </div>
  );
}

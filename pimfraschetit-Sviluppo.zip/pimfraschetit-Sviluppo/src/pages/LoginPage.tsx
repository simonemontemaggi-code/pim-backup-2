import { useState } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package } from "lucide-react";

export default function LoginPage() {
  const { session, loading, signIn } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (!loading && session) return <Navigate to="/pim" replace />;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);

    // 1) Login standard (admin / utente nominativo)
    const { error: signInErr } = await signIn(email, password);
    if (!signInErr) {
      setSubmitting(false);
      return;
    }

    // 2) Fallback: sotto-utente reparto via edge function dell'hub
    if (signInErr.message?.includes("Invalid login credentials")) {
      const { data, error: deptErr } = await supabase.functions.invoke(
        "auth-department-login",
        { body: { email, password } },
      );

      if (!deptErr && data?.access_token && data?.refresh_token) {
        const { error: setErr } = await supabase.auth.setSession({
          access_token: data.access_token,
          refresh_token: data.refresh_token,
        });
        if (setErr) {
          setError("Errore creazione sessione");
          setSubmitting(false);
          return;
        }
        // Upsert difensivo del profilo PIM
        try {
          const { data: { user } } = await supabase.auth.getUser();
          if (user) {
            await supabase.from("profiles").upsert(
              {
                user_id: user.id,
                email,
                full_name: data.display_name ?? user.email ?? email,
              } as any,
              { onConflict: "user_id" },
            );
          }
        } catch {
          /* non bloccante */
        }
        setSubmitting(false);
        return;
      }

      setError("Credenziali non valide");
      setSubmitting(false);
      return;
    }

    setError(signInErr.message);
    setSubmitting(false);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-sidebar">
      <Card className="w-full max-w-sm mx-4">
        <CardHeader className="text-center space-y-2">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-lg bg-primary">
            <Package className="h-6 w-6 text-primary-foreground" />
          </div>
          <CardTitle className="text-xl">PIM</CardTitle>
          <p className="text-sm text-muted-foreground">Accedi al sistema di gestione prodotti</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="nome@azienda.it" />
              <p className="text-xs text-muted-foreground">Usa la tua email personale o l'email del reparto.</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <Button type="submit" className="w-full" disabled={submitting}>
              {submitting ? "Accesso in corso..." : "Accedi"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

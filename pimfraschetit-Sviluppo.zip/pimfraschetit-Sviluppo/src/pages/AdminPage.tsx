import { Outlet, NavLink } from "react-router-dom";
import { Users, Shield, FileSearch, Settings, DollarSign, Sparkles, Mail, Search } from "lucide-react";

const baseTabs = [
  { to: "/pim/admin/users", label: "Utenti", icon: Users },
  { to: "/pim/admin/permissions", label: "Permessi", icon: Shield },
  { to: "/pim/admin/audit", label: "Audit Log", icon: FileSearch },
  { to: "/pim/admin/currencies", label: "Valute", icon: DollarSign },
  { to: "/pim/admin/ai-prompts", label: "AI Prompts", icon: Sparkles },
  { to: "/pim/admin/email-templates", label: "Email", icon: Mail },
  { to: "/pim/admin/catalog-search", label: "Ricerca catalogo", icon: Search },
  { to: "/pim/admin/settings", label: "Impostazioni", icon: Settings },
];

export default function AdminPage() {
  return (
    <div>
      <div className="border-b px-6">
        <nav className="flex gap-4">
          {baseTabs.map((tab) => (

            <NavLink
              key={tab.to}
              to={tab.to}
              className={({ isActive }) =>
                `flex items-center gap-2 py-3 px-1 text-sm border-b-2 transition-colors ${
                  isActive ? "border-primary text-primary font-medium" : "border-transparent text-muted-foreground hover:text-foreground"
                }`
              }
            >
              <tab.icon className="h-4 w-4" />
              {tab.label}
            </NavLink>
          ))}
        </nav>
      </div>
      <Outlet />
    </div>
  );
}

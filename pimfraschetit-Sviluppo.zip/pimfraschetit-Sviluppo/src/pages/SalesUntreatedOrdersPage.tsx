import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { PackageX, Search, FileText, Pencil, Trash2, XCircle, ArrowRight, RefreshCw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { usePermissions } from "@/lib/permissions";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import EditUntreatedRequestDialog from "@/components/sales/EditUntreatedRequestDialog";
import UntreatedRequestDetailDialog from "@/components/sales/UntreatedRequestDetailDialog";

type Stato =
  | "in_lavorazione"
  | "inviato_acquisti"
  | "preventivo"
  | "accettato"
  | "rifiutato"
  | "codificato"
  | "ordine_cliente"
  | "ordine_fornitore"
  | "in_arrivo"
  | "arrivato"
  | "nulla"
  | "chiuso";

const TABS: { key: Stato; label: string; tone: string }[] = [
  { key: "in_lavorazione",   label: "In lavorazione",    tone: "amber" },
  { key: "inviato_acquisti", label: "Inviato ad Acquisti", tone: "blue" },
  { key: "preventivo",       label: "Preventivo",         tone: "violet" },
  { key: "accettato",        label: "Accettato",          tone: "emerald" },
  { key: "codificato",       label: "Codificato",         tone: "cyan" },
  { key: "ordine_cliente",   label: "Ordine cliente",     tone: "indigo" },
  { key: "ordine_fornitore", label: "Ordine fornitore",   tone: "sky" },
  { key: "in_arrivo",        label: "In arrivo",          tone: "orange" },
  { key: "arrivato",         label: "Arrivato",           tone: "teal" },
  { key: "chiuso",           label: "Chiuse",             tone: "green" },
  { key: "rifiutato",        label: "Rifiutate",          tone: "rose" },
  { key: "nulla",            label: "Nulle",              tone: "rose" },
];

interface Row {
  id: string;
  fornitore: string;
  codice_articolo_fornitore: string;
  descrizione: string;
  quantita: number;
  nota: string | null;
  cliente_codice: string;
  cliente_nominativo: string;
  agente_codice: string | null;
  agente_cognome: string | null;
  agente_nome: string | null;
  created_at: string;
  status_updated_at: string | null;
  stato: Stato;
  status: string | null;
  confermato: boolean | null;
  preventivo_note: string | null;
  chiuso_da: "vendite" | "acquisti" | null;
  chiusura_motivo: string | null;
  cdpar_codificato: string | null;
  ordine_cliente_ref: string | null;
  ordine_fornitore_ref: string | null;
}

// Permessi richiesti per ciascuna transizione:
// v = write su sales_untreated (Vendite)
// a = write su purchases_untreated (Acquisti)
// - = non consentita (solo agente)
type Role = "v" | "a";
const TRANSITIONS: Record<Stato, { next: Stato; label: string; who: Role; needsMotivo?: boolean; needsPreventivoNote?: boolean; needsCdpar?: boolean; destructive?: boolean }[]> = {
  in_lavorazione: [
    { next: "inviato_acquisti", label: "Invia ad Acquisti", who: "v" },
    { next: "nulla",            label: "Annulla",           who: "v", needsMotivo: true, destructive: true },
  ],
  inviato_acquisti: [
    { next: "preventivo", label: "Fai preventivo", who: "a", needsPreventivoNote: true },
    { next: "nulla",      label: "Annulla",        who: "a", needsMotivo: true, destructive: true },
  ],
  preventivo: [], // decide l'agente da Agent Hub
  accettato: [
    { next: "codificato", label: "Codifica", who: "a" },
    { next: "chiuso",     label: "Chiudi",   who: "a", needsMotivo: true, destructive: true },
  ],
  codificato: [
    { next: "ordine_cliente", label: "Codice pronto per Vendite", who: "a", needsCdpar: true },
    { next: "chiuso",         label: "Chiudi",                    who: "a", needsMotivo: true, destructive: true },
  ],
  ordine_cliente: [
    { next: "ordine_fornitore", label: "Ordine cliente Effettuato", who: "v" },
    { next: "chiuso",           label: "Chiudi",                    who: "a", needsMotivo: true, destructive: true },
  ],
  ordine_fornitore: [
    { next: "in_arrivo", label: "Ordine Fornitore Effettuato", who: "a" },
    { next: "chiuso",    label: "Chiudi",                      who: "a", needsMotivo: true, destructive: true },
  ],
  in_arrivo: [
    { next: "arrivato", label: "Arrivato", who: "a" },
    { next: "chiuso",   label: "Chiudi",   who: "a", needsMotivo: true, destructive: true },
  ],
  arrivato: [],
  rifiutato: [],
  nulla: [],
  chiuso: [],
};


function toneClasses(tone: string) {
  const map: Record<string, string> = {
    amber: "bg-amber-100 text-amber-800 border-amber-200",
    blue: "bg-blue-100 text-blue-800 border-blue-200",
    violet: "bg-violet-100 text-violet-800 border-violet-200",
    emerald: "bg-emerald-100 text-emerald-800 border-emerald-200",
    cyan: "bg-cyan-100 text-cyan-800 border-cyan-200",
    indigo: "bg-indigo-100 text-indigo-800 border-indigo-200",
    sky: "bg-sky-100 text-sky-800 border-sky-200",
    green: "bg-green-100 text-green-800 border-green-200",
    rose: "bg-rose-100 text-rose-800 border-rose-200",
    slate: "bg-slate-100 text-slate-800 border-slate-200",
    orange: "bg-orange-100 text-orange-800 border-orange-200",
    teal: "bg-teal-100 text-teal-800 border-teal-200",
  };
  return map[tone] ?? "";
}

export default function SalesUntreatedOrdersPage() {
  const [search, setSearch] = useState("");
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { can } = usePermissions();
  const canVendite = can("write", "sales_untreated");
  const canAcquisti = can("write", "purchases_untreated");
  const confirm = useConfirm();

  const { data, isLoading } = useQuery({
    queryKey: ["sales-untreated-orders"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("richieste_ordini_non_trattati")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Row[];
    },
  });

  const { data: visitsRows } = useQuery({
    queryKey: ["sales-untreated-row-visits-global"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("untreated_orders_row_visits_global")
        .select("richiesta_id,last_visit_at");
      if (error) throw error;
      return (data ?? []) as { richiesta_id: string; last_visit_at: string }[];
    },
  });
  const visits = useMemo(() => {
    const m = new Map<string, number>();
    for (const v of visitsRows ?? []) m.set(v.richiesta_id, new Date(v.last_visit_at).getTime());
    return m;
  }, [visitsRows]);

  const markRowVisited = useMutation({
    mutationFn: async (richiesta_id: string) => {
      const { error } = await supabase
        .from("untreated_orders_row_visits_global")
        .upsert(
          { richiesta_id, last_visit_at: new Date().toISOString(), last_visit_by: user?.id ?? null },
          { onConflict: "richiesta_id" },
        );
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["sales-untreated-row-visits-global"] });
      queryClient.invalidateQueries({ queryKey: ["sidebar-notif"] });
    },
  });


  const [transitionDialog, setTransitionDialog] = useState<{
    row: Row;
    to: Stato;
    label: string;
    needsMotivo?: boolean;
    needsPreventivoNote?: boolean;
    needsCdpar?: boolean;
    who: Role;
    text: string;
  } | null>(null);

  const [inlineEdit, setInlineEdit] = useState<{ row: Row; field: "cdpar_codificato" | "ordine_cliente_ref" | "ordine_fornitore_ref"; value: string } | null>(null);
  const [editRow, setEditRow] = useState<Row | null>(null);
  const [detailRow, setDetailRow] = useState<Row | null>(null);

  const updateRow = useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: Record<string, unknown> }) => {
      const { error } = await supabase
        .from("richieste_ordini_non_trattati")
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        .update(patch as any)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: async (_data, vars) => {
      toast.success("Aggiornato");
      await queryClient.resetQueries({ queryKey: ["sales-untreated-orders"] });
      await queryClient.refetchQueries({ queryKey: ["sales-untreated-orders"], type: "active" });
      // Trigger email "Approvato" ad Acquisti quando Vendite invia
      if ((vars.patch as any)?.stato === "inviato_acquisti") {
        supabase.functions
          .invoke("send-untreated-order-approved-email", { body: { request_id: vars.id } })
          .then(({ error }) => {
            if (error) toast.error(`Invio mail Acquisti fallito: ${error.message}`);
            else toast.success("Mail 'Approvato' inviata ad Acquisti");
          });
      }
      // Trigger email "Ordine cliente creato" a Vendite quando la richiesta passa a ordine_cliente
      if ((vars.patch as any)?.stato === "ordine_cliente") {
        supabase.functions
          .invoke("send-untreated-order-ordine-cliente-email", { body: { request_id: vars.id } })
          .then(({ error }) => {
            if (error) toast.error(`Invio mail Vendite fallito: ${error.message}`);
            else toast.success("Mail 'Codice pronto' inviata a Vendite");
          });
      }
      // Trigger email "Ordine cliente creato → procedere ordine fornitore" ad Acquisti
      if ((vars.patch as any)?.stato === "ordine_fornitore") {
        supabase.functions
          .invoke("send-untreated-order-ordine-fornitore-email", { body: { request_id: vars.id } })
          .then(({ error }) => {
            if (error) toast.error(`Invio mail Acquisti fallito: ${error.message}`);
            else toast.success("Mail 'Ordine cliente creato' inviata ad Acquisti");
          });
      }
      // Trigger email "Merce arrivata" a Vendite quando la richiesta passa a arrivato
      if ((vars.patch as any)?.stato === "arrivato") {
        supabase.functions
          .invoke("send-untreated-order-arrivato-email", { body: { request_id: vars.id } })
          .then(({ error }) => {
            if (error) toast.error(`Invio mail Vendite fallito: ${error.message}`);
            else toast.success("Mail 'Merce arrivata' inviata a Vendite");
          });
      }
      setTransitionDialog(null);
      setInlineEdit(null);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteRequest = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("richieste_ordini_non_trattati").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Richiesta eliminata");
      queryClient.invalidateQueries({ queryKey: ["sales-untreated-orders"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const applyTransition = () => {
    if (!transitionDialog) return;
    const now = new Date().toISOString();
    const patch: Record<string, unknown> = {
      stato: transitionDialog.to,
      status_updated_at: now,
      status_updated_by: user?.id ?? null,
    };
    if (transitionDialog.needsMotivo) {
      const motivo = transitionDialog.text.trim();
      if (!motivo) { toast.error("Motivazione obbligatoria"); return; }
      patch.chiuso_da = transitionDialog.who === "v" ? "vendite" : "acquisti";
      patch.chiusura_motivo = motivo;
      patch.chiuso_at = now;
      patch.chiuso_by = user?.id ?? null;
    }
    if (transitionDialog.needsPreventivoNote) {
      patch.preventivo_note = transitionDialog.text.trim();
      patch.preventivo_note_at = now;
      patch.preventivo_note_by = user?.id ?? null;
    }
    if (transitionDialog.needsCdpar) {
      const raw = transitionDialog.text.trim().toUpperCase();
      if (!raw) { toast.error("CDPAR obbligatorio"); return; }
      const normalized = /^\d{1,6}$/.test(raw) ? raw.padStart(6, "0") : raw;
      patch.cdpar_codificato = normalized;
    }
    if (transitionDialog.to === "codificato") {
      patch.codificato_at = now;
      patch.codificato_by = user?.id ?? null;
    }
    if (transitionDialog.to === "ordine_cliente") {
      patch.ordine_cliente_at = now;
      patch.ordine_cliente_by = user?.id ?? null;
    }
    if (transitionDialog.to === "ordine_fornitore") {
      patch.ordine_fornitore_at = now;
      patch.ordine_fornitore_by = user?.id ?? null;
    }
    if (transitionDialog.to === "in_arrivo") {
      patch.in_arrivo_at = now;
      patch.in_arrivo_by = user?.id ?? null;
    }
    if (transitionDialog.to === "arrivato") {
      patch.arrivato_at = now;
      patch.arrivato_by = user?.id ?? null;
    }
    updateRow.mutate({ id: transitionDialog.row.id, patch });
  };

  const saveInline = () => {
    if (!inlineEdit) return;
    updateRow.mutate({ id: inlineEdit.row.id, patch: { [inlineEdit.field]: inlineEdit.value.trim() || null } });
  };

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return data ?? [];
    return (data ?? []).filter((r) =>
      [r.fornitore, r.codice_articolo_fornitore, r.descrizione, r.cliente_codice, r.cliente_nominativo, r.agente_codice ?? "", r.agente_cognome ?? "", r.agente_nome ?? "", r.nota ?? "", r.cdpar_codificato ?? ""].join(" ").toLowerCase().includes(q),
    );
  }, [data, search]);

  const [activeTab, setActiveTab] = useState<Stato>("in_lavorazione");
  const counts = useMemo(() => {
    const c = Object.fromEntries(TABS.map((t) => [t.key, 0])) as Record<Stato, number>;
    for (const r of filtered) c[r.stato] = (c[r.stato] ?? 0) + 1;
    return c;
  }, [filtered]);
  const newCounts = useMemo(() => {
    const c = Object.fromEntries(TABS.map((t) => [t.key, 0])) as Record<Stato, number>;
    for (const r of data ?? []) {
      const t = new Date(r.status_updated_at ?? r.created_at).getTime();
      const seen = visits.get(r.id) ?? 0;
      if (t > seen) c[r.stato] = (c[r.stato] ?? 0) + 1;
    }
    return c;
  }, [data, visits]);
  const isRowNew = (r: Row) => {
    const t = new Date(r.status_updated_at ?? r.created_at).getTime();
    const seen = visits.get(r.id) ?? 0;
    return t > seen;
  };
  const tabRows = useMemo(() => filtered.filter((r) => r.stato === activeTab), [filtered, activeTab]);

  // Realtime: invalida lista e visite globali a ogni cambio in DB
  useEffect(() => {
    const channel = supabase
      .channel("richieste-ordini-non-trattati-changes")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "richieste_ordini_non_trattati" },
        () => {
          queryClient.invalidateQueries({ queryKey: ["sales-untreated-orders"] });
        },
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "untreated_orders_row_visits_global" },
        () => {
          queryClient.invalidateQueries({ queryKey: ["sales-untreated-row-visits-global"] });
          queryClient.invalidateQueries({ queryKey: ["sidebar-notif"] });
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [queryClient]);


  const canPerform = (who: Role) => (who === "v" ? canVendite : canAcquisti);
  const availableTransitions = (row: Row) =>
    TRANSITIONS[row.stato].filter((t) => canPerform(t.who));

  const activeTabInfo = TABS.find((t) => t.key === activeTab)!;


  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center gap-2">
        <PackageX className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-semibold">Ordini non Trattati</h1>
        <Badge variant="secondary" className="ml-2">{isLoading ? "…" : (data?.length ?? 0).toLocaleString("it-IT")}</Badge>
        <Button
          variant="outline"
          size="sm"
          className="ml-auto"
          onClick={async () => {
            await queryClient.resetQueries({ queryKey: ["sales-untreated-orders"] });
            await queryClient.refetchQueries({ queryKey: ["sales-untreated-orders"], type: "active" });
          }}
          disabled={isLoading}
        >
          <RefreshCw className={cn("h-4 w-4 mr-2", isLoading && "animate-spin")} />
          Aggiorna
        </Button>
      </div>
      <p className="text-sm text-muted-foreground">
        Flusso: Vendite riceve la richiesta → invia ad Acquisti o chiude. Acquisti fa preventivo o chiude.
        L'agente accetta/rifiuta il preventivo. Se accettato: Acquisti codifica, Vendite fa ordine cliente, Acquisti fa ordine fornitore, poi arrivo merce.
      </p>

      <div className="relative max-w-md">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input className="pl-8 h-9" placeholder="Cerca per fornitore, articolo, cliente, agente, cdpar…" value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>

      <Card className="p-0 overflow-hidden">
        <div className="border-b px-2 pt-2 overflow-x-auto">
          <TooltipProvider delayDuration={150}>
            <div className="flex items-center gap-1 -mb-px">
              {TABS.map((t) => {
                const nNew = newCounts[t.key] ?? 0;
                const total = counts[t.key] ?? 0;
                const isActive = activeTab === t.key;
                return (
                  <Tooltip key={t.key}>
                    <TooltipTrigger asChild>
                      <button
                        onClick={() => setActiveTab(t.key)}
                        className={cn(
                          "relative px-3 py-2 text-sm font-medium whitespace-nowrap rounded-t-md border-b-2 transition-colors flex items-center gap-2",
                          isActive
                            ? "border-primary text-primary bg-primary/5"
                            : "border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/40",
                        )}
                      >
                        <span>{t.label}</span>
                        <span
                          className={cn(
                            "inline-flex items-center justify-center rounded-full min-w-[20px] h-5 px-1.5 text-[11px] font-semibold tabular-nums",
                            nNew > 0
                              ? "bg-destructive text-destructive-foreground ring-2 ring-destructive/30"
                              : isActive
                                ? "bg-primary/15 text-primary"
                                : "bg-muted text-muted-foreground",
                          )}
                        >
                          {total}
                        </span>
                      </button>
                    </TooltipTrigger>
                    {nNew > 0 && (
                      <TooltipContent>{nNew} {nNew === 1 ? "nuovo aggiornamento" : "nuovi aggiornamenti"} da vedere</TooltipContent>
                    )}
                  </Tooltip>
                );
              })}
            </div>
          </TooltipProvider>
        </div>

        {(() => {
          const showNote = ["preventivo","accettato","codificato","ordine_cliente","ordine_fornitore","in_arrivo","arrivato","rifiutato"].includes(activeTab);
          const showCdpar = ["codificato","ordine_cliente","ordine_fornitore","in_arrivo","arrivato"].includes(activeTab);
          const showOrdCli = ["ordine_cliente","ordine_fornitore","in_arrivo","arrivato"].includes(activeTab);
          const showOrdFor = ["ordine_fornitore","in_arrivo","arrivato"].includes(activeTab);
          const showClosure = activeTab === "chiuso" || activeTab === "nulla";
          const totalCols =
            7 + (showNote ? 1 : 0) + (showCdpar ? 1 : 0) + (showOrdCli ? 1 : 0) + (showOrdFor ? 1 : 0) + (showClosure ? 2 : 0) + 1;

          return (
        <div className="overflow-x-auto max-h-[calc(100vh-280px)] overflow-y-auto">
          <table className="w-full text-sm table-fixed">
            <colgroup>
              <col className="w-[92px]" />           {/* Data */}
              <col className="w-[220px]" />          {/* Cliente */}
              <col className="w-[180px]" />          {/* Agente */}
              <col className="w-[140px]" />          {/* Fornitore */}
              <col className="w-[130px]" />          {/* Cod. articolo */}
              <col className="min-w-[240px]" />       {/* Descrizione flex */}
              <col className="w-[64px]" />           {/* Qtà */}
              {showNote && <col className="w-[260px]" />}
              {showCdpar && <col className="w-[110px]" />}
              {showOrdCli && <col className="w-[140px]" />}
              {showOrdFor && <col className="w-[140px]" />}
              {showClosure && <col className="w-[110px]" />}
              {showClosure && <col />}
              <col className="w-[220px]" />          {/* Azioni + trash */}
            </colgroup>
            <thead className="bg-muted/60 text-xs uppercase tracking-wide text-muted-foreground sticky top-0 z-10 backdrop-blur">
              <tr>
                <th className="text-left px-3 py-2 font-medium truncate">Data</th>
                <th className="text-left px-3 py-2 font-medium truncate">Cliente</th>
                <th className="text-left px-3 py-2 font-medium truncate">Agente</th>
                <th className="text-left px-3 py-2 font-medium truncate">Fornitore</th>
                <th className="text-left px-3 py-2 font-medium truncate">Cod. articolo</th>
                <th className="text-left px-3 py-2 font-medium truncate">Descrizione</th>
                <th className="text-right px-3 py-2 font-medium truncate">Qtà</th>
                {showNote && <th className="text-left px-3 py-2 font-medium truncate">Note preventivo</th>}
                {showCdpar && <th className="text-left px-3 py-2 font-medium truncate">Cdpar</th>}
                {showOrdCli && <th className="text-left px-3 py-2 font-medium truncate">Rif. ord. cliente</th>}
                {showOrdFor && <th className="text-left px-3 py-2 font-medium truncate">Rif. ord. fornitore</th>}
                {showClosure && <th className="text-left px-3 py-2 font-medium truncate">{activeTab === "nulla" ? "Annullato da" : "Chiuso da"}</th>}
                {showClosure && <th className="text-left px-3 py-2 font-medium truncate">Motivo</th>}
                <th className="text-right px-3 py-2 font-medium truncate">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {isLoading &&
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i} className="border-t">
                    <td colSpan={totalCols} className="px-3 py-2"><Skeleton className="h-5 w-full" /></td>
                  </tr>
                ))}
              {!isLoading && tabRows.length === 0 && (
                <tr>
                  <td colSpan={totalCols} className="px-4 py-16 text-center">
                    <div className="flex flex-col items-center gap-2 text-muted-foreground">
                      <PackageX className="h-10 w-10 opacity-30" />
                      <span className="text-sm">Nessuna richiesta in "{activeTabInfo.label}"</span>
                    </div>
                  </td>
                </tr>
              )}
              {!isLoading && tabRows.map((r) => {
                const transitions = availableTransitions(r);
                const primary = transitions.find((t) => !t.destructive);
                const destructive = transitions.find((t) => t.destructive);
                const agenteNome = [r.agente_cognome, r.agente_nome].filter(Boolean).join(" ");
                return (
                  <tr
                    key={r.id}
                    className={cn(
                      "border-t transition-colors cursor-pointer even:bg-muted/20 hover:bg-muted/50",
                      isRowNew(r) && "bg-primary/5 hover:bg-primary/10 border-l-2 border-l-primary",
                    )}
                    onClick={(e) => {
                      if ((e.target as HTMLElement).closest("button, a, input, textarea")) return;
                      if (isRowNew(r)) markRowVisited.mutate(r.id);
                      setDetailRow(r);
                    }}
                  >
                    <td className="px-3 py-2 whitespace-nowrap text-xs text-muted-foreground tabular-nums align-middle">
                      {new Date(r.created_at).toLocaleDateString("it-IT")}
                    </td>
                    <td className="px-3 py-2 align-middle min-w-0">
                      <div className="font-mono text-[11px] text-muted-foreground leading-tight">{r.cliente_codice}</div>
                      <div className="font-medium truncate leading-tight" title={r.cliente_nominativo}>{r.cliente_nominativo}</div>
                    </td>
                    <td className="px-3 py-2 align-middle min-w-0">
                      {r.agente_codice ? (
                        <>
                          <div className="font-mono text-[11px] text-muted-foreground leading-tight">{r.agente_codice}</div>
                          <div className="text-xs truncate leading-tight" title={agenteNome}>{agenteNome || "—"}</div>
                        </>
                      ) : <span className="text-muted-foreground text-xs">—</span>}
                    </td>
                    <td className="px-3 py-2 align-middle truncate" title={r.fornitore}>{r.fornitore}</td>
                    <td className="px-3 py-2 align-middle font-mono text-xs truncate" title={r.codice_articolo_fornitore}>{r.codice_articolo_fornitore}</td>
                    <td className="px-3 py-2 align-middle min-w-0">
                      <TooltipProvider delayDuration={200}>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="truncate">{r.descrizione}</div>
                          </TooltipTrigger>
                          <TooltipContent className="max-w-md whitespace-pre-wrap">{r.descrizione}</TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </td>
                    <td className="px-3 py-2 text-right tabular-nums align-middle">{r.quantita}</td>

                    {showNote && (
                      <td className="px-3 py-2 align-middle min-w-0">
                        {r.preventivo_note?.trim() ? (
                          <TooltipProvider delayDuration={150}>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="inline-flex items-center gap-1 text-muted-foreground text-xs w-full">
                                  <FileText className="h-3.5 w-3.5 shrink-0" />
                                  <span className="truncate">{r.preventivo_note}</span>
                                </span>
                              </TooltipTrigger>
                              <TooltipContent className="max-w-sm whitespace-pre-wrap">{r.preventivo_note}</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        ) : <span className="text-muted-foreground">—</span>}
                      </td>
                    )}

                    {showCdpar && (
                      <td className="px-3 py-2 align-middle font-mono text-xs">
                        {r.stato === "codificato" && canAcquisti ? (
                          <button className="hover:underline text-left w-full truncate" onClick={() => setInlineEdit({ row: r, field: "cdpar_codificato", value: r.cdpar_codificato ?? "" })}>
                            {r.cdpar_codificato || <em className="text-muted-foreground opacity-60 not-italic">+ inserisci</em>}
                          </button>
                        ) : (r.cdpar_codificato ?? <span className="text-muted-foreground">—</span>)}
                      </td>
                    )}

                    {showOrdCli && (
                      <td className="px-3 py-2 align-middle text-xs">
                        {r.stato === "ordine_cliente" && canVendite ? (
                          <button className="hover:underline text-left w-full truncate" onClick={() => setInlineEdit({ row: r, field: "ordine_cliente_ref", value: r.ordine_cliente_ref ?? "" })}>
                            {r.ordine_cliente_ref || <em className="text-muted-foreground opacity-60 not-italic">+ rif.</em>}
                          </button>
                        ) : (r.ordine_cliente_ref ?? <span className="text-muted-foreground">—</span>)}
                      </td>
                    )}

                    {showOrdFor && (
                      <td className="px-3 py-2 align-middle text-xs">
                        {r.stato === "ordine_fornitore" && canAcquisti ? (
                          <button className="hover:underline text-left w-full truncate" onClick={() => setInlineEdit({ row: r, field: "ordine_fornitore_ref", value: r.ordine_fornitore_ref ?? "" })}>
                            {r.ordine_fornitore_ref || <em className="text-muted-foreground opacity-60 not-italic">+ rif.</em>}
                          </button>
                        ) : (r.ordine_fornitore_ref ?? <span className="text-muted-foreground">—</span>)}
                      </td>
                    )}

                    {showClosure && (
                      <>
                        <td className="px-3 py-2 align-middle">
                          {r.chiuso_da ? (
                            <Badge variant="outline" className={toneClasses(r.chiuso_da === "vendite" ? "amber" : "blue")}>
                              {r.chiuso_da === "vendite" ? "Vendite" : "Acquisti"}
                            </Badge>
                          ) : "—"}
                        </td>
                        <td className="px-3 py-2 align-middle min-w-0">
                          <TooltipProvider delayDuration={150}>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="truncate text-muted-foreground text-xs block">{r.chiusura_motivo || "—"}</span>
                              </TooltipTrigger>
                              {r.chiusura_motivo && <TooltipContent className="max-w-sm whitespace-pre-wrap">{r.chiusura_motivo}</TooltipContent>}
                            </Tooltip>
                          </TooltipProvider>
                        </td>
                      </>
                    )}

                    <td className="px-3 py-2 align-middle">
                      <div className="flex items-center justify-end gap-1">
                        {transitions.length === 0 ? (
                          r.stato === "preventivo" ? (
                            <span className="text-xs text-muted-foreground italic">In attesa agente</span>
                          ) : (
                            <span className="text-xs text-muted-foreground">—</span>
                          )
                        ) : (
                          <TooltipProvider delayDuration={150}>
                            {primary && (
                              <Button
                                size="sm"
                                className="h-7 text-xs px-2.5"
                                onClick={() => setTransitionDialog({
                                  row: r, to: primary.next, label: primary.label, needsMotivo: primary.needsMotivo,
                                  needsPreventivoNote: primary.needsPreventivoNote, needsCdpar: primary.needsCdpar, who: primary.who,
                                  text: primary.needsPreventivoNote ? (r.preventivo_note ?? "") : primary.needsCdpar ? (r.cdpar_codificato ?? "") : "",
                                })}
                              >
                                <ArrowRight className="h-3.5 w-3.5 mr-1" />
                                {primary.label}
                              </Button>
                            )}
                            {destructive && (
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="icon"
                                    variant="outline"
                                    className="h-7 w-7 text-destructive hover:text-destructive hover:bg-destructive/10 border-destructive/30"
                                    onClick={() => setTransitionDialog({
                                      row: r, to: destructive.next, label: destructive.label, needsMotivo: destructive.needsMotivo,
                                      needsPreventivoNote: destructive.needsPreventivoNote, who: destructive.who, text: "",
                                    })}
                                  >
                                    <XCircle className="h-3.5 w-3.5" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>{destructive.label}</TooltipContent>
                              </Tooltip>
                            )}
                          </TooltipProvider>
                        )}
                        {(canVendite || canAcquisti) && (r.stato === "in_lavorazione" || r.stato === "inviato_acquisti") && (
                          <TooltipProvider delayDuration={150}>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7 text-muted-foreground hover:text-primary"
                                  onClick={() => setEditRow(r)}
                                >
                                  <Pencil className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Modifica richiesta</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                        {(canVendite || canAcquisti) && (
                          <TooltipProvider delayDuration={150}>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7 text-muted-foreground hover:text-destructive"
                                  disabled={deleteRequest.isPending}
                                  onClick={async () => { if (await confirm({ title: `Eliminare definitivamente la richiesta per "${r.descrizione}" (cliente ${r.cliente_codice})?`, destructive: true, confirmText: "Elimina" })) deleteRequest.mutate(r.id); }}
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Elimina richiesta</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
          );
        })()}
      </Card>

      {/* Dialog transizione (chiusura / preventivo / avanzamento) */}
      <Dialog open={!!transitionDialog} onOpenChange={(o) => !o && setTransitionDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{transitionDialog?.label}</DialogTitle>
            <DialogDescription>
              {transitionDialog && (
                <>
                  <span className="font-medium text-foreground">{transitionDialog.row.codice_articolo_fornitore}</span> — {transitionDialog.row.descrizione}
                </>
              )}
            </DialogDescription>
          </DialogHeader>
          {(transitionDialog?.needsMotivo || transitionDialog?.needsPreventivoNote) && (
            <Textarea
              rows={6}
              placeholder={transitionDialog.needsMotivo
                ? (transitionDialog.to === "nulla" ? "Motivazione dell'annullamento (obbligatoria)…" : "Motivazione della chiusura (obbligatoria)…")
                : "Dettagli preventivo (prezzo, condizioni, tempi di consegna, fornitore…)"}
              value={transitionDialog.text}
              onChange={(e) => setTransitionDialog((s) => (s ? { ...s, text: e.target.value } : s))}
            />
          )}
          {transitionDialog?.needsCdpar && (
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">CDPAR codificato (obbligatorio)</label>
              <Input
                autoFocus
                placeholder="es. 001234"
                value={transitionDialog.text}
                onChange={(e) => setTransitionDialog((s) => (s ? { ...s, text: e.target.value } : s))}
              />
            </div>
          )}
          {!transitionDialog?.needsMotivo && !transitionDialog?.needsPreventivoNote && !transitionDialog?.needsCdpar && transitionDialog && (
            <p className="text-sm text-muted-foreground">Confermi l'avanzamento allo stato "{transitionDialog.label}"?</p>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setTransitionDialog(null)}>Annulla</Button>
            <Button
              disabled={updateRow.isPending || (transitionDialog?.needsCdpar && !transitionDialog.text.trim())}
              onClick={applyTransition}
            >
              Conferma
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog modifica richiesta (fornitore / articolo / descrizione / qta / nota) */}
      <EditUntreatedRequestDialog
        open={!!editRow}
        request={editRow}
        onOpenChange={(o) => !o && setEditRow(null)}
      />

      {/* Dialog dettaglio richiesta con timeline */}
      <UntreatedRequestDetailDialog
        open={!!detailRow}
        request={detailRow}
        onOpenChange={(o) => !o && setDetailRow(null)}
      />

      {/* Dialog inline edit cdpar / rif ordini */}
      <Dialog open={!!inlineEdit} onOpenChange={(o) => !o && setInlineEdit(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {inlineEdit?.field === "cdpar_codificato" ? "Codice articolo (cdpar)"
                : inlineEdit?.field === "ordine_cliente_ref" ? "Riferimento ordine cliente"
                : "Riferimento ordine fornitore"}
            </DialogTitle>
            <DialogDescription>
              {inlineEdit && (<><span className="font-medium text-foreground">{inlineEdit.row.codice_articolo_fornitore}</span> — {inlineEdit.row.descrizione}</>)}
            </DialogDescription>
          </DialogHeader>
          <Input
            autoFocus
            value={inlineEdit?.value ?? ""}
            onChange={(e) => setInlineEdit((s) => (s ? { ...s, value: e.target.value } : s))}
            placeholder={inlineEdit?.field === "cdpar_codificato" ? "es. 123456" : "es. 2026/ORD-1234"}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setInlineEdit(null)}>Annulla</Button>
            <Button disabled={updateRow.isPending} onClick={saveInline}><Pencil className="h-3.5 w-3.5 mr-1" />Salva</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

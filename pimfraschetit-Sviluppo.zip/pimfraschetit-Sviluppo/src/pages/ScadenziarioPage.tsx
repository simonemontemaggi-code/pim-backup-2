import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Loader2, Upload, ChevronRight, ChevronDown, FileText, CheckCircle2, Check, ChevronsUpDown, Wallet, X, Download } from "lucide-react";
import * as XLSX from "xlsx";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { usePermissions } from "@/lib/permissions";
import { parseScadenziarioText, type ParsedScadRow } from "@/lib/scadenziarioParser";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";

type ScadRow = ParsedScadRow & {
  id: string;
  payment_confirmed: boolean;
  payment_confirmed_at: string | null;
  payment_confirmed_by_agent: string | null;
  payment_confirmed_amount: number | null;
};

/** Stato d'incasso effettivo di una riga (full / partial / open). */
function rowState(r: ScadRow) {
  const tot = Number(r.totale || 0);
  const amt = r.payment_confirmed_amount != null ? Number(r.payment_confirmed_amount) : null;
  const confirmedAmount = r.payment_confirmed ? (amt ?? tot) : 0;
  const openAmount = Math.max(0, tot - confirmedAmount);
  const isPartial = r.payment_confirmed && amt != null && amt < tot;
  return { tot, confirmedAmount, openAmount, isPartial };
}

function parseAmountIt(v: string): number | null {
  const n = Number(String(v).replace(/\./g, "").replace(",", "."));
  if (!isFinite(n) || n < 0) return null;
  return n;
}

const confermatoFmt = new Intl.DateTimeFormat("it-IT", {
  timeZone: "Europe/Rome",
  day: "2-digit", month: "2-digit", year: "2-digit",
  hour: "2-digit", minute: "2-digit",
});
function fmtConfermato(iso: string | null | undefined): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  return confermatoFmt.format(d).replace(",", "");
}


type ImportRow = {
  id: string;
  filename: string;
  imported_at: string;
  total_rows: number;
  total_amount: number;
  agent_code: string | null;
};

type AgentSummary = {
  agent_code: string;
  agent_name: string;
  customers_count: number;
  rows_count: number;
  total: number;
  confirmed_count: number;
  overdue_count: number;
  total_confirmed: number;
  total_open: number;
};

type CustomerSummary = {
  customer_code: string;
  customer_name: string;
  rows_count: number;
  total: number;
  confirmed_count: number;
  overdue_count: number;
};

const fmtEuro = (n: number) =>
  new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" }).format(n || 0);

const TODAY = new Date(); TODAY.setHours(0, 0, 0, 0);
const isPastDue = (d: string | null) => !!d && new Date(d) < TODAY;

export default function ScadenziarioPage() {
  const { role } = useAuth();
  const { can, canAction } = usePermissions();
  const canImport = role === "admin" || role === "manager" || can("write", "scadenziario");
  const canConfirm = canAction("scadenziario", "confirm_payment");



  const [imports, setImports] = useState<ImportRow[]>([]);
  const [agentsSummary, setAgentsSummary] = useState<AgentSummary[]>([]);
  const [loadingAgents, setLoadingAgents] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<string>("");
  const [search, setSearch] = useState("");
  const [searchMatches, setSearchMatches] = useState<Record<string, CustomerSummary[]>>({});
  const [searching, setSearching] = useState(false);

  // Lazy-loaded data per agent / customer
  const [customersByAgent, setCustomersByAgent] = useState<Record<string, CustomerSummary[]>>({});
  const [loadingAgent, setLoadingAgent] = useState<Record<string, boolean>>({});
  const [rowsByCustomer, setRowsByCustomer] = useState<Record<string, ScadRow[]>>({});
  const [loadingCustomer, setLoadingCustomer] = useState<Record<string, boolean>>({});

  const [dialogRow, setDialogRow] = useState<ScadRow | null>(null);
  const [dialogAmount, setDialogAmount] = useState("");
  const [dialogSaving, setDialogSaving] = useState(false);

  const [openAgents, setOpenAgents] = useState<Set<string>>(new Set());
  const [openCustomers, setOpenCustomers] = useState<Set<string>>(new Set());
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null);
  const [agentPickerOpen, setAgentPickerOpen] = useState(false);
  const [onlyPaid, setOnlyPaid] = useState(false);
  const [paidFrom, setPaidFrom] = useState<string>("");
  const [paidTo, setPaidTo] = useState<string>("");
  const [exporting, setExporting] = useState(false);

  // YYYY-MM-DD nel fuso Europe/Rome
  const romeDayFmt = useMemo(
    () => new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Rome", year: "numeric", month: "2-digit", day: "2-digit" }),
    [],
  );
  const toRomeDay = (iso: string | null | undefined): string | null => {
    if (!iso) return null;
    const d = new Date(iso);
    if (isNaN(d.getTime())) return null;
    return romeDayFmt.format(d);
  };
  const paidDateActive = !!(paidFrom || paidTo);
  const rowInPaidWindow = (r: ScadRow): boolean => {
    if (!paidDateActive) return true;
    if (!r.payment_confirmed || !r.payment_confirmed_at) return false;
    const d = toRomeDay(r.payment_confirmed_at);
    if (!d) return false;
    if (paidFrom && d < paidFrom) return false;
    if (paidTo && d > paidTo) return false;
    return true;
  };
  const fileRef = useRef<HTMLInputElement>(null);

  async function loadImports() {
    const { data } = await supabase
      .from("scadenziario_imports")
      .select("id, filename, imported_at, total_rows, total_amount, agent_code")
      .order("imported_at", { ascending: false })
      .limit(50);
    setImports((data ?? []) as ImportRow[]);
  }

  async function loadAgentsSummary() {
    setLoadingAgents(true);
    const { data, error } = await supabase.rpc("pim_scadenziario_agents_summary");
    if (error) {
      toast({ title: "Errore caricamento agenti", description: error.message, variant: "destructive" });
      setAgentsSummary([]);
    } else {
      setAgentsSummary((data ?? []) as AgentSummary[]);
    }
    setLoadingAgents(false);
  }

  async function loadCustomersForAgent(agentCode: string, force = false) {
    if (!force && customersByAgent[agentCode]) return;
    setLoadingAgent((s) => ({ ...s, [agentCode]: true }));
    const { data, error } = await supabase.rpc("pim_scadenziario_customers_for_agent", {
      p_agent_code: agentCode,
    });
    if (error) {
      toast({ title: "Errore clienti agente", description: error.message, variant: "destructive" });
    } else {
      setCustomersByAgent((s) => ({ ...s, [agentCode]: (data ?? []) as CustomerSummary[] }));
    }
    setLoadingAgent((s) => ({ ...s, [agentCode]: false }));
  }

  async function loadRowsForCustomer(customerCode: string, force = false) {
    if (!force && rowsByCustomer[customerCode]) return;
    setLoadingCustomer((s) => ({ ...s, [customerCode]: true }));
    const { data, error } = await supabase
      .from("scadenziario_rows")
      .select("id, customer_code, customer_name, reg_prot, reg_data, causal, payment_desc, doc_number, doc_date, due_date, currency, contanti, effetti, totale, payment_confirmed, payment_confirmed_at, payment_confirmed_by_agent, payment_confirmed_amount")
      .eq("customer_code", customerCode)
      .order("due_date", { ascending: true, nullsFirst: false });
    if (error) {
      toast({ title: "Errore righe cliente", description: error.message, variant: "destructive" });
    } else {
      setRowsByCustomer((s) => ({ ...s, [customerCode]: (data ?? []) as ScadRow[] }));
    }
    setLoadingCustomer((s) => ({ ...s, [customerCode]: false }));
  }

  useEffect(() => {
    loadImports();
    loadAgentsSummary();
  }, []);

  // ---- Modalità "filtro per data incasso" ----
  // Quando paidFrom/paidTo sono valorizzati ricalcolo riepilogo agenti/clienti/righe
  // SOLO sulle righe con payment_confirmed_at nel range, perché le RPC aggregate
  // server-side non conoscono questo filtro.
  const baselineAgentNamesRef = useRef<Record<string, string>>({});
  useEffect(() => {
    for (const a of agentsSummary) baselineAgentNamesRef.current[a.agent_code] = a.agent_name;
  }, [agentsSummary]);

  const [paidFilterLoading, setPaidFilterLoading] = useState(false);
  const wasPaidFilterActiveRef = useRef(false);

  useEffect(() => {
    let cancelled = false;
    async function run() {
      if (paidDateActive) {
        wasPaidFilterActiveRef.current = true;
        setPaidFilterLoading(true);
        try {
          // Range in UTC ISO: [from 00:00 Rome, to 23:59:59.999 Rome]
          // Approssimazione robusta: includo un giorno extra ai bordi e poi rifiltro per Rome-day.
          const fromIso = paidFrom ? new Date(`${paidFrom}T00:00:00+00:00`).toISOString() : null;
          const toIso = paidTo ? new Date(`${paidTo}T23:59:59.999+00:00`).toISOString() : null;
          // Estendo di ±1 giorno per coprire tutti i fusi, poi rifiltro per Rome-day.
          const fromIsoExt = fromIso ? new Date(new Date(fromIso).getTime() - 24 * 3600 * 1000).toISOString() : null;
          const toIsoExt = toIso ? new Date(new Date(toIso).getTime() + 24 * 3600 * 1000).toISOString() : null;

          const all: any[] = [];
          const pageSize = 1000;
          let from = 0;
          // Pagino fino a esaurire i risultati
          while (true) {
            let q = supabase
              .from("scadenziario_rows")
              .select("id, customer_code, customer_name, reg_prot, reg_data, causal, payment_desc, doc_number, doc_date, due_date, currency, contanti, effetti, totale, payment_confirmed, payment_confirmed_at, payment_confirmed_by_agent, payment_confirmed_amount, last_import_id, scadenziario_imports!last_import_id(agent_code)")
              .eq("payment_confirmed", true)
              .order("payment_confirmed_at", { ascending: false, nullsFirst: false })
              .range(from, from + pageSize - 1);
            if (fromIsoExt) q = q.gte("payment_confirmed_at", fromIsoExt);
            if (toIsoExt) q = q.lte("payment_confirmed_at", toIsoExt);
            const { data, error } = await q;
            if (error) throw error;
            const chunk = data ?? [];
            all.push(...chunk);
            if (chunk.length < pageSize) break;
            from += pageSize;
            if (from > 50000) break; // safety
          }
          if (cancelled) return;

          // Filtro per Rome-day esatto
          const inWindow = (iso: string | null) => {
            if (!iso) return false;
            const d = romeDayFmt.format(new Date(iso));
            if (paidFrom && d < paidFrom) return false;
            if (paidTo && d > paidTo) return false;
            return true;
          };
          const rows = all.filter((r) => inWindow(r.payment_confirmed_at));

          // Aggrego per agente e per cliente
          const byAgent = new Map<string, {
            customers: Map<string, { name: string; rows: ScadRow[]; total: number; confirmed: number; overdue: number; }>;
            rowsCount: number; total: number; confirmed: number; overdue: number;
          }>();
          const allRowsByCustomer: Record<string, ScadRow[]> = {};

          for (const raw of rows) {
            const agentCode = raw.scadenziario_imports?.agent_code ?? "";
            const r: ScadRow = {
              id: raw.id,
              customer_code: raw.customer_code,
              customer_name: raw.customer_name,
              reg_prot: raw.reg_prot,
              reg_data: raw.reg_data,
              causal: raw.causal,
              payment_desc: raw.payment_desc,
              doc_number: raw.doc_number,
              doc_date: raw.doc_date,
              due_date: raw.due_date,
              currency: raw.currency,
              contanti: raw.contanti,
              effetti: raw.effetti,
              totale: raw.totale,
              payment_confirmed: raw.payment_confirmed,
              payment_confirmed_at: raw.payment_confirmed_at,
              payment_confirmed_by_agent: raw.payment_confirmed_by_agent,
              payment_confirmed_amount: raw.payment_confirmed_amount,
            } as ScadRow;

            const st = rowState(r);
            const overdue = isPastDue(r.due_date) && st.openAmount > 0 ? 1 : 0;

            if (!byAgent.has(agentCode)) {
              byAgent.set(agentCode, { customers: new Map(), rowsCount: 0, total: 0, confirmed: 0, overdue: 0 });
            }
            const ag = byAgent.get(agentCode)!;
            ag.rowsCount += 1;
            ag.total += st.tot;
            ag.confirmed += st.confirmedAmount;
            ag.overdue += overdue;

            if (!ag.customers.has(r.customer_code)) {
              ag.customers.set(r.customer_code, { name: r.customer_name || r.customer_code, rows: [], total: 0, confirmed: 0, overdue: 0 });
            }
            const cu = ag.customers.get(r.customer_code)!;
            cu.rows.push(r);
            cu.total += st.tot;
            cu.confirmed += st.confirmedAmount;
            cu.overdue += overdue;

            (allRowsByCustomer[r.customer_code] ||= []).push(r);
          }

          // Trasformo in AgentSummary[] / customersByAgent
          const newAgents: AgentSummary[] = [];
          const newCustomersByAgent: Record<string, CustomerSummary[]> = {};
          for (const [agentCode, ag] of byAgent.entries()) {
            const customers: CustomerSummary[] = [];
            for (const [ccode, cu] of ag.customers.entries()) {
              customers.push({
                customer_code: ccode,
                customer_name: cu.name,
                rows_count: cu.rows.length,
                total: cu.total,
                confirmed_count: cu.rows.length, // tutte confirmed in questa modalità
                overdue_count: cu.overdue,
              });
            }
            customers.sort((a, b) => (a.customer_name || "").localeCompare(b.customer_name || ""));
            newCustomersByAgent[agentCode] = customers;
            newAgents.push({
              agent_code: agentCode,
              agent_name: baselineAgentNamesRef.current[agentCode] || (agentCode ? "" : "(agente non in anagrafica)"),
              customers_count: customers.length,
              rows_count: ag.rowsCount,
              total: ag.total,
              confirmed_count: ag.rowsCount,
              overdue_count: ag.overdue,
              total_confirmed: ag.confirmed,
              total_open: Math.max(0, ag.total - ag.confirmed),
            });
          }
          newAgents.sort((a, b) => a.agent_code.localeCompare(b.agent_code));

          // Ordino le righe dentro ogni cliente per due_date
          for (const k of Object.keys(allRowsByCustomer)) {
            allRowsByCustomer[k].sort((a, b) => (a.due_date || "").localeCompare(b.due_date || ""));
          }

          if (cancelled) return;
          setAgentsSummary(newAgents);
          setCustomersByAgent(newCustomersByAgent);
          setRowsByCustomer(allRowsByCustomer);
        } catch (err: any) {
          if (!cancelled) toast({ title: "Errore filtro data incasso", description: err?.message ?? String(err), variant: "destructive" });
        } finally {
          if (!cancelled) setPaidFilterLoading(false);
        }
      } else if (wasPaidFilterActiveRef.current) {
        // Tornati alla vista non filtrata → ricarico baseline e resetto cache lazy
        wasPaidFilterActiveRef.current = false;
        setCustomersByAgent({});
        setRowsByCustomer({});
        await loadAgentsSummary();
      }
    }
    run();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paidFrom, paidTo]);

  // Nuovi incassi non ancora "visti" — alimentano il banner in cima alla pagina.
  // NB: l'ack non è più automatico al mount; l'utente deve cliccare "Segna come viste"
  // (o la X sulla singola riga) per azzerare il pallino in sidebar.
  type PendingAck = {
    id: string;
    customer_code: string;
    customer_name: string | null;
    doc_number: string | null;
    totale: number | null;
    payment_confirmed_amount: number | null;
    payment_confirmed_at: string | null;
    payment_confirmed_by_agent: string | null;
    agent_code: string | null;
  };
  const [pendingAcks, setPendingAcks] = useState<PendingAck[]>([]);
  const [loadingPending, setLoadingPending] = useState(false);
  const [showAllPending, setShowAllPending] = useState(false);
  const [ackingAll, setAckingAll] = useState(false);

  async function loadPendingAcks() {
    if (!can("read", "scadenziario")) return;
    setLoadingPending(true);
    try {
      const { data: ackRows } = await supabase
        .from("scadenziario_payment_ack")
        .select("row_id");
      const ackedSet = new Set((ackRows ?? []).map((a: any) => a.row_id));
      const { data: confirmed, error } = await supabase
        .from("scadenziario_rows")
        .select("id, customer_code, customer_name, doc_number, totale, payment_confirmed_amount, payment_confirmed_at, payment_confirmed_by_agent, last_import_id, scadenziario_imports!last_import_id(agent_code)")
        .eq("payment_confirmed", true)
        .order("payment_confirmed_at", { ascending: false, nullsFirst: false })
        .limit(500);
      if (error) {
        setPendingAcks([]);
        return;
      }
      const pending: PendingAck[] = (confirmed ?? [])
        .filter((r: any) => !ackedSet.has(r.id))
        .map((r: any) => ({
          id: r.id,
          customer_code: r.customer_code,
          customer_name: r.customer_name,
          doc_number: r.doc_number,
          totale: r.totale,
          payment_confirmed_amount: r.payment_confirmed_amount,
          payment_confirmed_at: r.payment_confirmed_at,
          payment_confirmed_by_agent: r.payment_confirmed_by_agent,
          agent_code: r.scadenziario_imports?.agent_code ?? null,
        }));
      setPendingAcks(pending);
    } finally {
      setLoadingPending(false);
    }
  }

  useEffect(() => {
    loadPendingAcks();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function ackOne(rowId: string) {
    const prev = pendingAcks;
    setPendingAcks((s) => s.filter((r) => r.id !== rowId));
    const { error } = await supabase
      .from("scadenziario_payment_ack")
      .insert({ row_id: rowId });
    if (error) {
      setPendingAcks(prev);
      toast({ title: "Errore", description: error.message, variant: "destructive" });
    }
  }

  async function ackAll() {
    if (pendingAcks.length === 0) return;
    setAckingAll(true);
    const ids = pendingAcks.map((r) => r.id);
    const { error } = await supabase
      .from("scadenziario_payment_ack")
      .insert(ids.map((id) => ({ row_id: id })));
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
    } else {
      setPendingAcks([]);
    }
    setAckingAll(false);
  }

  // Mappa agent_code → nome agente, dal riepilogo già caricato
  const agentNameByCode = useMemo(() => {
    const m: Record<string, string> = {};
    for (const a of agentsSummary) m[a.agent_code] = a.agent_name;
    return m;
  }, [agentsSummary]);

  const [batchResults, setBatchResults] = useState<Array<{
    file: string;
    agentCode?: string;
    inserted?: number;
    updated?: number;
    deleted?: number;
    error?: string;
  }>>([]);

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (files.length === 0) return;
    e.target.value = "";

    setUploading(true);
    setBatchResults([]);
    const results: typeof batchResults = [];
    const seenAgents = new Map<string, number>();
    let totOk = 0, totErr = 0;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        setUploadProgress(`File ${i + 1}/${files.length} — lettura ${file.name}…`);
        const text = await file.text();
        const parsed = parseScadenziarioText(text);
        if (parsed.rows.length === 0) throw new Error("Nessuna riga valida trovata");
        const totalAmount = parsed.rows.reduce((s, r) => s + r.totale, 0);

        const prev = seenAgents.get(parsed.agentCode) ?? 0;
        seenAgents.set(parsed.agentCode, prev + 1);

        setUploadProgress(`File ${i + 1}/${files.length} — agente ${parsed.agentCode} (${parsed.rows.length} righe)…`);
        const { data, error } = await supabase.rpc("import_scadenziario_for_agent", {
          p_agent_code: parsed.agentCode,
          rows: parsed.rows as any,
          p_filename: file.name,
          p_total_amount: totalAmount,
        });
        if (error) throw error;
        const r = data as { agent_code: string; inserted: number; updated: number; deleted: number };
        results.push({ file: file.name, agentCode: r.agent_code, inserted: r.inserted, updated: r.updated, deleted: r.deleted });
        totOk++;
      } catch (err: any) {
        results.push({ file: file.name, error: err?.message ?? String(err) });
        totErr++;
      }
      setBatchResults([...results]);
    }

    const dupAgents = Array.from(seenAgents.entries()).filter(([, n]) => n > 1).map(([a]) => a);
    toast({
      title: `Import completato: ${totOk} ok${totErr ? `, ${totErr} errori` : ""}`,
      description: dupAgents.length
        ? `Attenzione: agente ${dupAgents.join(", ")} importato più volte — vince l'ultimo file.`
        : "Conferme pagamento preservate. Altri agenti non toccati.",
      variant: totErr > 0 ? "destructive" : "default",
    });

    // Refresh aggregato + invalida cache lazy (gli agenti modificati verranno ricaricati on-expand)
    const touchedAgents = Array.from(seenAgents.keys());
    setCustomersByAgent((s) => {
      const n = { ...s };
      touchedAgents.forEach((a) => delete n[a]);
      return n;
    });
    setRowsByCustomer({}); // safe reset (poche righe già aperte)
    await Promise.all([loadImports(), loadAgentsSummary()]);
    setUploading(false);
    setUploadProgress("");
  }

  function openConfirmDialog(row: ScadRow) {
    if (!canImport) return;
    const s = rowState(row);
    setDialogRow(row);
    setDialogAmount(
      row.payment_confirmed
        ? String(s.confirmedAmount).replace(".", ",")
        : String(Number(row.totale || 0)).replace(".", ","),
    );
  }

  function closeDialog() {
    setDialogRow(null);
    setDialogAmount("");
    setDialogSaving(false);
  }

  async function applyPayment(opts: { confirmed: boolean; amount: number | null }) {
    if (!dialogRow) return;
    setDialogSaving(true);
    const row = dialogRow;
    const nowIso = new Date().toISOString();
    const { error } = await supabase
      .from("scadenziario_rows")
      .update({
        payment_confirmed: opts.confirmed,
        payment_confirmed_at: opts.confirmed ? nowIso : null,
        payment_confirmed_by_agent: opts.confirmed ? (row.payment_confirmed_by_agent ?? "PIM") : null,
        payment_confirmed_amount: opts.confirmed ? opts.amount : null,
      })
      .eq("id", row.id);
    if (error) {
      toast({ title: "Errore", description: error.message, variant: "destructive" });
      setDialogSaving(false);
      return;
    }
    setRowsByCustomer((s) => {
      const list = s[row.customer_code];
      if (!list) return s;
      return {
        ...s,
        [row.customer_code]: list.map((x) =>
          x.id === row.id
            ? {
                ...x,
                payment_confirmed: opts.confirmed,
                payment_confirmed_at: opts.confirmed ? nowIso : null,
                payment_confirmed_amount: opts.confirmed ? opts.amount : null,
              }
            : x,
        ),
      };
    });
    closeDialog();
  }

  function submitConfirm() {
    const amt = parseAmountIt(dialogAmount);
    if (amt == null || amt <= 0 || !dialogRow) return;
    const tot = Number(dialogRow.totale || 0);
    // amount == tot → salva null (pagamento pieno)
    applyPayment({ confirmed: true, amount: amt >= tot ? null : amt });
  }

  const grandTotal = useMemo(() => agentsSummary.reduce((s, a) => s + Number(a.total || 0), 0), [agentsSummary]);
  const grandRows = useMemo(() => agentsSummary.reduce((s, a) => s + a.rows_count, 0), [agentsSummary]);
  const grandCustomers = useMemo(() => agentsSummary.reduce((s, a) => s + (a.customers_count || 0), 0), [agentsSummary]);
  const grandConfirmed = useMemo(() => agentsSummary.reduce((s, a) => s + Number(a.total_confirmed || 0), 0), [agentsSummary]);
  const grandOpen = useMemo(() => agentsSummary.reduce((s, a) => s + Number(a.total_open || 0), 0), [agentsSummary]);

  // Debounced server-side search by customer code / company name
  useEffect(() => {
    const q = search.trim();
    if (q.length < 2) {
      setSearchMatches({});
      setSearching(false);
      return;
    }
    setSearching(true);
    const handle = setTimeout(async () => {
      const { data, error } = await supabase.rpc("pim_scadenziario_search_customers", { p_query: q });
      if (!error) {
        const grouped: Record<string, CustomerSummary[]> = {};
        for (const r of (data ?? []) as (CustomerSummary & { agent_code: string })[]) {
          const ac = r.agent_code || "";
          (grouped[ac] ||= []).push({
            customer_code: r.customer_code,
            customer_name: r.customer_name,
            rows_count: r.rows_count,
            total: r.total,
            confirmed_count: r.confirmed_count,
            overdue_count: r.overdue_count,
          });
        }
        setSearchMatches(grouped);
      }
      setSearching(false);
    }, 250);
    return () => clearTimeout(handle);
  }, [search]);

  const isSearching = search.trim().length >= 2;

  const filteredAgents = useMemo(() => {
    let list = agentsSummary;
    if (selectedAgent) list = list.filter((a) => a.agent_code === selectedAgent);
    if (onlyPaid) list = list.filter((a) => a.confirmed_count > 0);
    const q = search.trim().toLowerCase();
    if (!q) return list;
    const agentMatchCodes = new Set(
      list
        .filter((a) => a.agent_code.toLowerCase().includes(q) || a.agent_name.toLowerCase().includes(q))
        .map((a) => a.agent_code),
    );
    const customerMatchCodes = new Set(Object.keys(searchMatches));
    return list.filter(
      (a) => agentMatchCodes.has(a.agent_code) || customerMatchCodes.has(a.agent_code),
    );
  }, [agentsSummary, search, searchMatches, selectedAgent, onlyPaid]);

  // Auto-expand agents that have customer matches
  useEffect(() => {
    if (!isSearching) return;
    const codes = Object.keys(searchMatches);
    if (codes.length === 0) return;
    setOpenAgents((s) => {
      const n = new Set(s);
      for (const c of codes) n.add(c);
      return n;
    });
  }, [searchMatches, isSearching]);

  const toggleAgent = async (code: string) => {
    setOpenAgents((s) => {
      const n = new Set(s);
      if (n.has(code)) n.delete(code); else n.add(code);
      return n;
    });
    if (!openAgents.has(code)) await loadCustomersForAgent(code);
  };

  const toggleCustomer = async (agentCode: string, customerCode: string) => {
    const ck = `${agentCode}::${customerCode}`;
    setOpenCustomers((s) => {
      const n = new Set(s);
      if (n.has(ck)) n.delete(ck); else n.add(ck);
      return n;
    });
    if (!openCustomers.has(ck)) await loadRowsForCustomer(customerCode);
  };

  async function handleExport() {
    setExporting(true);
    try {
      const q = search.trim();
      const { data, error } = await supabase.rpc("pim_scadenziario_export", {
        p_agent_code: selectedAgent,
        p_only_paid: onlyPaid,
        p_query: q.length >= 2 ? q : null,
      });
      if (error) throw error;
      let rows = (data ?? []) as any[];
      if (paidDateActive) {
        rows = rows.filter((r) => {
          if (!r.payment_confirmed || !r.payment_confirmed_at) return false;
          const d = toRomeDay(r.payment_confirmed_at);
          if (!d) return false;
          if (paidFrom && d < paidFrom) return false;
          if (paidTo && d > paidTo) return false;
          return true;
        });
      }
      if (rows.length === 0) {
        toast({ title: "Nessuna riga da esportare", variant: "destructive" });
        setExporting(false);
        return;
      }
      const toDate = (s: string | null) => (s ? new Date(s) : null);
      const out = rows.map((r) => {
        const tot = Number(r.totale || 0);
        const amt = r.payment_confirmed_amount != null ? Number(r.payment_confirmed_amount) : null;
        const confirmed = r.payment_confirmed ? (amt ?? tot) : 0;
        const stato = !r.payment_confirmed ? "Aperta" : amt != null && amt < tot ? "Parziale" : "Saldata";
        return {
          "Agente cod.": r.agent_code,
          "Agente": r.agent_name,
          "Cliente cod.": r.customer_code,
          "Cliente": r.customer_name,
          "Reg/Prot": r.reg_prot,
          "Data reg.": toDate(r.reg_data),
          "Causale": r.causal,
          "Pagamento": r.payment_desc,
          "N. doc.": r.doc_number,
          "Data doc.": toDate(r.doc_date),
          "Scadenza": toDate(r.due_date),
          "Valuta": r.currency,
          "Contanti": Number(r.contanti || 0),
          "Effetti": Number(r.effetti || 0),
          "Totale": tot,
          "Stato": stato,
          "Importo confermato": confirmed,
          "Confermato il": toDate(r.payment_confirmed_at),
          "Confermato da": r.payment_confirmed_by_agent ?? "",
          "Scaduta": r.is_overdue ? "Sì" : "No",
        };
      });
      const ws = XLSX.utils.json_to_sheet(out, { cellDates: true });
      const range = XLSX.utils.decode_range(ws["!ref"]!);
      // Column widths
      ws["!cols"] = [
        { wch: 8 }, { wch: 26 }, { wch: 10 }, { wch: 38 }, { wch: 10 }, { wch: 11 },
        { wch: 8 }, { wch: 28 }, { wch: 12 }, { wch: 11 }, { wch: 11 }, { wch: 6 },
        { wch: 12 }, { wch: 12 }, { wch: 13 }, { wch: 10 }, { wch: 14 }, { wch: 16 },
        { wch: 14 }, { wch: 8 },
      ];
      // Apply formats per column
      const euroCols = [12, 13, 14, 16]; // 0-based
      const dateCols = [5, 9, 10, 17];
      for (let R = 1; R <= range.e.r; R++) {
        for (const C of euroCols) {
          const cell = ws[XLSX.utils.encode_cell({ r: R, c: C })];
          if (cell) cell.z = '€ #,##0.00';
        }
        for (const C of dateCols) {
          const cell = ws[XLSX.utils.encode_cell({ r: R, c: C })];
          if (cell && cell.v) cell.z = C === 17 ? 'dd/mm/yyyy hh:mm' : 'dd/mm/yyyy';
        }
      }
      ws["!autofilter"] = { ref: ws["!ref"]! };
      ws["!freeze"] = { xSplit: 0, ySplit: 1 } as any;
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Scadenze");
      const parts: string[] = ["scadenziario", format(new Date(), "yyyy-MM-dd")];
      if (selectedAgent) parts.push(selectedAgent);
      if (onlyPaid) parts.push("solo-incassati");
      if (q.length >= 2) parts.push("filtrato");
      XLSX.writeFile(wb, `${parts.join("_")}.xlsx`);
      toast({ title: `Esportate ${rows.length} righe` });
    } catch (err: any) {
      toast({ title: "Errore export", description: err?.message ?? String(err), variant: "destructive" });
    } finally {
      setExporting(false);
    }
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Scadenziario Agenti</h1>
          <p className="text-sm text-muted-foreground">
            Riepilogo cumulato per agente. Carico solo gli aggregati: clienti e righe vengono richiesti al click. Le righe scadute appaiono in <span className="text-destructive font-medium">rosso</span>, quelle con pagamento confermato in <span className="text-emerald-600 dark:text-emerald-400 font-medium">verde</span>.
          </p>
        </div>
        <input ref={fileRef} type="file" accept=".txt,text/plain" multiple onChange={handleFile} className="hidden" />
        <TooltipProvider delayDuration={100}>
          <div className="flex items-center gap-2 shrink-0">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleExport}
                  disabled={exporting}
                >
                  {exporting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left" className="max-w-xs">
                <p className="text-xs">
                  Esporta XLSX delle scadenze.{" "}
                  {(selectedAgent || onlyPaid || search.trim().length >= 2)
                    ? "Verranno esportate solo le righe corrispondenti ai filtri attivi."
                    : "Verranno esportate tutte le righe."}
                </p>
              </TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => fileRef.current?.click()}
                  disabled={uploading || !canImport}
                >
                  {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left" className="max-w-xs">
                <p className="text-xs">Carica il TXT "Stampa situazione clienti" esportato dall'AS400 (filtrato per agente). L'import sostituisce solo le scadenze dei clienti dell'agente indicato nell'header del file, lasciando intatte le righe degli altri agenti e preservando le conferme di pagamento. {!canImport && <span className="block mt-1 text-destructive">Solo admin/manager possono importare.</span>}</p>
              </TooltipContent>
            </Tooltip>
          </div>
        </TooltipProvider>
      </div>

      <div className="space-y-4">
        {pendingAcks.length > 0 && (
          <Card className="border-emerald-500/40 bg-emerald-500/5">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <CardTitle className="text-base flex items-center gap-2 text-emerald-700 dark:text-emerald-300">
                  <CheckCircle2 className="h-4 w-4" />
                  Nuovi incassi da rivedere ({pendingAcks.length})
                </CardTitle>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={ackAll}
                  disabled={ackingAll}
                >
                  {ackingAll ? <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Check className="h-3.5 w-3.5 mr-1.5" />}
                  Segna tutte come viste
                </Button>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="divide-y divide-border/60 rounded-md border border-border/60 bg-background">
                {(showAllPending ? pendingAcks : pendingAcks.slice(0, 50)).map((r) => {
                  const tot = Number(r.totale || 0);
                  const amt = r.payment_confirmed_amount != null ? Number(r.payment_confirmed_amount) : null;
                  const incasso = amt ?? tot;
                  const isPartial = amt != null && amt < tot;
                  const ag = r.agent_code ?? "—";
                  const agName = (r.agent_code && agentNameByCode[r.agent_code]) || "";
                  return (
                    <button
                      key={r.id}
                      type="button"
                      onClick={async () => {
                        if (r.agent_code) {
                          setOpenAgents((s) => {
                            const n = new Set(s); n.add(r.agent_code!); return n;
                          });
                          await loadCustomersForAgent(r.agent_code);
                          const ck = `${r.agent_code}::${r.customer_code}`;
                          setOpenCustomers((s) => {
                            const n = new Set(s); n.add(ck); return n;
                          });
                          await loadRowsForCustomer(r.customer_code);
                        }
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2 text-left text-sm hover:bg-muted/40 transition-colors"
                    >
                      <Badge variant="outline" className="font-mono text-[10px] shrink-0 bg-muted/40">
                        {ag}
                      </Badge>
                      <span className="shrink-0 text-foreground/80 truncate max-w-[160px]">{agName || "—"}</span>
                      <span className="text-muted-foreground shrink-0">→</span>
                      <span className="font-medium truncate flex-1">
                        {r.customer_name || r.customer_code}
                      </span>
                      <span className="text-xs text-muted-foreground shrink-0 hidden md:inline">
                        Doc {r.doc_number || "—"}
                      </span>
                      <span className={cn(
                        "tabular-nums font-semibold shrink-0",
                        isPartial ? "text-amber-600 dark:text-amber-400" : "text-emerald-700 dark:text-emerald-400",
                      )}>
                        {fmtEuro(incasso)}{isPartial ? " (parz.)" : ""}
                      </span>
                      <span className="text-xs text-muted-foreground shrink-0 hidden lg:inline">
                        {fmtConfermato(r.payment_confirmed_at)}
                        {r.payment_confirmed_by_agent ? ` · ${r.payment_confirmed_by_agent}` : ""}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); ackOne(r.id); }}
                        className="ml-1 p-1 rounded hover:bg-muted shrink-0"
                        title="Segna come vista"
                      >
                        <X className="h-3.5 w-3.5 text-muted-foreground" />
                      </button>
                    </button>
                  );
                })}
              </div>
              {pendingAcks.length > 50 && (
                <button
                  type="button"
                  onClick={() => setShowAllPending((v) => !v)}
                  className="mt-2 text-xs text-primary hover:underline"
                >
                  {showAllPending ? "Mostra solo le prime 50" : `Mostra tutte (${pendingAcks.length})`}
                </button>
              )}
              {loadingPending && (
                <div className="mt-2 text-xs text-muted-foreground flex items-center gap-1.5">
                  <Loader2 className="h-3 w-3 animate-spin" /> aggiornamento…
                </div>
              )}
            </CardContent>
          </Card>
        )}
        <Card>
          <CardHeader className="pb-3 space-y-3">
            {/* Riga 1 — Titolo e riepilogo (full width) */}
            <div className="flex items-center gap-3 flex-wrap">
              <CardTitle className="text-base shrink-0">
                Riepilogo per agente
                {paidDateActive && (
                  <span className="ml-2 text-xs font-normal text-emerald-700 dark:text-emerald-400">
                    {paidFilterLoading ? "(caricamento filtro incasso…)" : "(filtro incasso attivo)"}
                  </span>
                )}
              </CardTitle>
              <div className="flex flex-wrap items-center gap-1.5 text-xs">
                <Badge variant="outline" className="font-medium border-border/60 bg-muted/30">
                  {agentsSummary.length} agenti
                </Badge>
                <Badge variant="outline" className="font-medium border-border/60 bg-muted/30">
                  {grandCustomers.toLocaleString("it-IT")} clienti
                </Badge>
                <Badge variant="outline" className="font-medium border-border/60 bg-muted/30">
                  {grandRows.toLocaleString("it-IT")} righe
                </Badge>
                <span className="mx-1 h-4 w-px bg-border" aria-hidden />
                <Badge variant="outline" className="font-semibold border-border/60 bg-muted/30 tabular-nums">
                  Totale: {fmtEuro(grandTotal)}
                </Badge>
                <Badge
                  variant="outline"
                  className="font-semibold border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300 tabular-nums"
                >
                  Da incassare: {fmtEuro(grandOpen)}
                </Badge>
                <Badge
                  variant="outline"
                  className="font-semibold border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 tabular-nums"
                >
                  Incassato: {fmtEuro(grandConfirmed)}
                </Badge>
              </div>
            </div>

            {/* Riga 2 — Filtri */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
              <div className="flex items-center gap-2 flex-wrap">
                <Popover open={agentPickerOpen} onOpenChange={setAgentPickerOpen}>
                  <PopoverTrigger asChild>
                    <Button variant="outline" size="sm" className="h-8 justify-between min-w-[180px]">
                      <span className="truncate">
                        {selectedAgent
                          ? `${selectedAgent} — ${agentsSummary.find((a) => a.agent_code === selectedAgent)?.agent_name ?? ""}`
                          : "Agente: tutti"}
                      </span>
                      {selectedAgent ? (
                        <X
                          className="h-3.5 w-3.5 ml-1 opacity-60 hover:opacity-100"
                          onClick={(e) => { e.stopPropagation(); setSelectedAgent(null); }}
                        />
                      ) : (
                        <ChevronsUpDown className="h-3.5 w-3.5 ml-1 opacity-50" />
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="p-0 w-[280px]" align="start">
                    <Command>
                      <CommandInput placeholder="Cerca codice o cognome…" />
                      <CommandList>
                        <CommandEmpty>Nessun agente.</CommandEmpty>
                        <CommandGroup>
                          <CommandItem
                            value="__all__"
                            onSelect={() => { setSelectedAgent(null); setAgentPickerOpen(false); }}
                          >
                            <Check className={cn("mr-2 h-4 w-4", !selectedAgent ? "opacity-100" : "opacity-0")} />
                            Tutti gli agenti
                          </CommandItem>
                          {agentsSummary.map((a) => (
                            <CommandItem
                              key={a.agent_code}
                              value={`${a.agent_code} ${a.agent_name}`}
                              onSelect={() => { setSelectedAgent(a.agent_code); setAgentPickerOpen(false); }}
                            >
                              <Check className={cn("mr-2 h-4 w-4", selectedAgent === a.agent_code ? "opacity-100" : "opacity-0")} />
                              <span className="font-mono text-xs mr-2">{a.agent_code}</span>
                              <span className="truncate">{a.agent_name}</span>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>

                <Button
                  variant={onlyPaid ? "default" : "outline"}
                  size="sm"
                  className="h-8"
                  onClick={() => setOnlyPaid((v) => !v)}
                  title="Mostra solo righe incassate (parziali o totali)"
                >
                  <Wallet className="h-3.5 w-3.5 mr-1.5" />
                  Solo incassati
                </Button>

                <div className="flex items-center gap-1.5 h-8 px-2 rounded-md border bg-background">
                  <span className="text-xs text-muted-foreground whitespace-nowrap">Incasso</span>
                  <Input
                    type="date"
                    value={paidFrom}
                    onChange={(e) => setPaidFrom(e.target.value)}
                    className="h-6 w-[130px] text-xs px-1.5"
                    title="Data incasso — dal"
                  />
                  <span className="text-xs text-muted-foreground">→</span>
                  <Input
                    type="date"
                    value={paidTo}
                    onChange={(e) => setPaidTo(e.target.value)}
                    className="h-6 w-[130px] text-xs px-1.5"
                    title="Data incasso — al"
                  />
                  {paidDateActive && (
                    <button
                      type="button"
                      onClick={() => { setPaidFrom(""); setPaidTo(""); }}
                      className="text-muted-foreground hover:text-foreground"
                      title="Azzera filtro data incasso"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 flex-1 min-w-[240px]">
                <Input
                  placeholder="Cerca agente, codice o ragione sociale cliente…"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="h-8 flex-1"
                />
                {searching && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground shrink-0" />}
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {loadingAgents ? (
              <div className="p-8 text-center text-sm text-muted-foreground">
                <Loader2 className="h-5 w-5 animate-spin mx-auto mb-2" /> Caricamento agenti…
              </div>
            ) : agentsSummary.length === 0 ? (
              <div className="p-8 text-center text-sm text-muted-foreground">
                Nessuna riga. Carica un file TXT a destra.
              </div>
            ) : filteredAgents.length === 0 ? (
              <div className="p-8 text-center text-sm text-muted-foreground">Nessun risultato.</div>
            ) : (
              <div className="divide-y">
                <div className="grid grid-cols-[2fr_1fr_140px] gap-2 px-4 py-2 text-xs font-medium text-muted-foreground bg-muted/30">
                  <div>Agente / Cliente / Documento</div>
                  <div className="text-right">Righe</div>
                  <div className="text-right">Totale</div>
                </div>
                {filteredAgents.map((a) => {
                  const open = openAgents.has(a.agent_code);
                  const matches = isSearching ? searchMatches[a.agent_code] : undefined;
                  const custs = matches ?? customersByAgent[a.agent_code];
                  const isLoadingCusts = !!loadingAgent[a.agent_code] && !matches;
                  return (
                    <div key={a.agent_code}>
                      <button onClick={() => toggleAgent(a.agent_code)} className="w-full grid grid-cols-[2fr_1fr_140px] gap-2 px-4 py-2.5 text-left hover:bg-muted/40 items-center">
                        <div className="flex items-center gap-2 font-medium">
                          {open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                          <Badge variant="outline" className="font-mono">{a.agent_code}</Badge>
                          <span>{a.agent_name}</span>
                        </div>
                        <div className="text-right text-sm tabular-nums">{a.rows_count}</div>
                        <div className="text-right font-semibold tabular-nums">{fmtEuro(Number(a.total))}</div>
                      </button>

                      {open && (
                        <div className="bg-muted/10">
                          {isLoadingCusts && !custs ? (
                            <div className="px-10 py-3 text-xs text-muted-foreground flex items-center gap-2">
                              <Loader2 className="h-3.5 w-3.5 animate-spin" /> Carico clienti…
                            </div>
                          ) : (custs ?? []).filter((c) => !onlyPaid || c.confirmed_count > 0).map((c) => {
                            const ck = `${a.agent_code}::${c.customer_code}`;
                            const copen = openCustomers.has(ck);
                            const custRows = rowsByCustomer[c.customer_code];
                            const isLoadingRows = !!loadingCustomer[c.customer_code];
                            return (
                              <div key={ck} className="border-t">
                                <button onClick={() => toggleCustomer(a.agent_code, c.customer_code)} className="w-full grid grid-cols-[2fr_1fr_140px] gap-2 pl-10 pr-4 py-2 text-left hover:bg-muted/30 items-center">
                                  <div className="flex items-center gap-2 text-sm">
                                    {copen ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
                                    <Badge variant="secondary" className="font-mono text-[10px]">{c.customer_code}</Badge>
                                    <span>{c.customer_name}</span>
                                  </div>
                                  <div className="text-right text-xs text-muted-foreground tabular-nums">{c.rows_count}</div>
                                  <div className="text-right font-medium text-sm tabular-nums">{fmtEuro(Number(c.total))}</div>
                                </button>

                                {copen && (
                                  <div className="pl-16 pr-4 py-2 bg-background border-t">
                                    {isLoadingRows && !custRows ? (
                                      <div className="py-2 text-xs text-muted-foreground flex items-center gap-2">
                                        <Loader2 className="h-3.5 w-3.5 animate-spin" /> Carico righe…
                                      </div>
                                    ) : (
                                      <table className="w-full text-xs">
                                        <thead className="text-muted-foreground">
                                          <tr className="border-b">
                                            <th className="text-center py-1 w-8">OK</th>
                                            <th className="text-left py-1">Doc.</th>
                                            <th className="text-left py-1">Reg/Prot</th>
                                            <th className="text-left py-1">Data</th>
                                            <th className="text-left py-1">Scadenza</th>
                                            <th className="text-left py-1">Causale</th>
                                            <th className="text-left py-1">Pagamento</th>
                                            <th className="text-right py-1">Contanti</th>
                                            <th className="text-right py-1">Effetti</th>
                                            <th className="text-right py-1">Totale</th>
                                            <th className="text-left py-1 pl-6 whitespace-nowrap">Confermato il</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          {(custRows ?? []).filter((r) => !onlyPaid || r.payment_confirmed).filter(rowInPaidWindow).map((r) => {
                                            const st = rowState(r);
                                            const rowCls = cn(
                                              "border-b last:border-0 transition-colors",
                                              r.payment_confirmed && !st.isPartial && "text-emerald-600 dark:text-emerald-400 bg-emerald-50/50 dark:bg-emerald-950/20",
                                              st.isPartial && "text-amber-700 dark:text-amber-400 bg-amber-50/50 dark:bg-amber-950/20",
                                            );
                                            return (
                                              <tr key={r.id} className={rowCls}>
                                                <td className="py-1 text-center">
                                                  <button
                                                    onClick={() => openConfirmDialog(r)}
                                                    disabled={!canConfirm}
                                                    title={r.payment_confirmed
                                                      ? `Confermato${r.payment_confirmed_at ? ' il ' + fmtConfermato(r.payment_confirmed_at) : ''}${r.payment_confirmed_by_agent ? ' da ' + r.payment_confirmed_by_agent : ''}${st.isPartial ? ` — parziale ${fmtEuro(st.confirmedAmount)}` : ''} — clicca per modificare`
                                                      : "Conferma pagamento"}
                                                    className={cn(
                                                      "h-4 w-4 rounded border inline-flex items-center justify-center",
                                                      r.payment_confirmed && !st.isPartial && "bg-emerald-500 border-emerald-500 text-white",
                                                      st.isPartial && "bg-amber-500 border-amber-500 text-white",
                                                      !r.payment_confirmed && "border-muted-foreground/40 hover:border-emerald-500",
                                                      !canConfirm && "opacity-50 cursor-not-allowed",
                                                    )}
                                                  >
                                                    {r.payment_confirmed && <CheckCircle2 className="h-3 w-3" />}
                                                  </button>
                                                </td>
                                                <td className="py-1 font-mono">{r.doc_number}</td>
                                                <td className="py-1">{r.reg_prot}</td>
                                                <td className="py-1">{r.doc_date ? format(new Date(r.doc_date), "dd/MM/yy") : "—"}</td>
                                                <td className="py-1 font-medium">{r.due_date ? format(new Date(r.due_date), "dd/MM/yy") : "—"}</td>
                                                <td className="py-1">{r.causal}</td>
                                                <td className="py-1">{r.payment_desc}</td>
                                                <td className="py-1 text-right tabular-nums">{r.contanti ? fmtEuro(Number(r.contanti)) : "—"}</td>
                                                <td className="py-1 text-right tabular-nums">{r.effetti ? fmtEuro(Number(r.effetti)) : "—"}</td>
                                                <td className="py-1 text-right tabular-nums font-medium">
                                                  {fmtEuro(Number(r.totale))}
                                                  {st.isPartial && (
                                                    <div className="text-[10px] text-amber-700 dark:text-amber-400 font-normal">
                                                      incassato {fmtEuro(st.confirmedAmount)} · resto {fmtEuro(st.openAmount)}
                                                    </div>
                                                  )}
                                                </td>
                                                <td className="py-1 pl-6 whitespace-nowrap text-muted-foreground">
                                                  {r.payment_confirmed && r.payment_confirmed_at ? (
                                                    <span title={r.payment_confirmed_by_agent ? `Agente ${r.payment_confirmed_by_agent}` : undefined}>
                                                      {fmtConfermato(r.payment_confirmed_at)}
                                                      {r.payment_confirmed_by_agent && (
                                                        <span className="ml-1 opacity-70">· {r.payment_confirmed_by_agent}</span>
                                                      )}
                                                    </span>
                                                  ) : "—"}
                                                </td>
                                              </tr>
                                            );
                                          })}
                                        </tbody>
                                      </table>
                                    )}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                          {!isLoadingCusts && custs && custs.length === 0 && (
                            <div className="px-10 py-3 text-xs text-muted-foreground">Nessun cliente.</div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {batchResults.length > 0 && (
          <div className="border rounded divide-y max-h-64 overflow-auto text-[11px] bg-card">
            {batchResults.map((b, i) => (
              <div key={i} className="px-3 py-2">
                <div className="font-medium truncate">{b.file}</div>
                {b.error ? (
                  <div className="text-destructive">{b.error}</div>
                ) : (
                  <div className="text-muted-foreground">
                    Ag. {b.agentCode} · +{b.inserted} ~{b.updated} -{b.deleted}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <FileText className="h-4 w-4" /> Storico import
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {imports.length === 0 ? (
              <div className="px-4 py-3 text-xs text-muted-foreground">Nessun import.</div>
            ) : (
              <div className="divide-y max-h-96 overflow-auto">
                {imports.map((imp) => (
                  <div key={imp.id} className="px-3 py-2 text-xs">
                    <div className="font-medium truncate flex items-center gap-2">
                      {imp.agent_code && <Badge variant="outline" className="font-mono text-[10px] px-1 py-0">{imp.agent_code}</Badge>}
                      <span className="truncate">{imp.filename}</span>
                    </div>
                    <div className="text-muted-foreground">
                      {format(new Date(imp.imported_at), "dd/MM/yy HH:mm")} · {imp.total_rows} righe · {fmtEuro(Number(imp.total_amount))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={!!dialogRow} onOpenChange={(o) => { if (!o) closeDialog(); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Conferma pagamento</DialogTitle>
            <DialogDescription>
              {dialogRow && (
                <>Doc. <span className="font-mono">{dialogRow.doc_number}</span> — totale <strong>{fmtEuro(Number(dialogRow.totale || 0))}</strong></>
              )}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <label className="block">
              <span className="text-xs text-muted-foreground">Importo incassato (€)</span>
              <Input
                type="text"
                inputMode="decimal"
                value={dialogAmount}
                onChange={(e) => setDialogAmount(e.target.value)}
                placeholder="0,00"
                className="mt-1"
                autoFocus
              />
              <span className="text-[11px] text-muted-foreground">
                Lascia uguale al totale per pagamento pieno, oppure inserisci un importo minore per parziale (il resto rimane aperto nella prossima estrazione).
              </span>
            </label>
          </div>
          <DialogFooter className="gap-2 sm:gap-2 flex-col sm:flex-row">
            {dialogRow?.payment_confirmed && (
              <Button variant="outline" onClick={() => applyPayment({ confirmed: false, amount: null })} disabled={dialogSaving} className="sm:mr-auto">
                Rimuovi conferma
              </Button>
            )}
            <Button variant="secondary" onClick={() => applyPayment({ confirmed: true, amount: null })} disabled={dialogSaving}>
              Incasso totale
            </Button>
            <Button onClick={submitConfirm} disabled={dialogSaving || parseAmountIt(dialogAmount) == null || (parseAmountIt(dialogAmount) ?? 0) <= 0}>
              {dialogSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Conferma"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

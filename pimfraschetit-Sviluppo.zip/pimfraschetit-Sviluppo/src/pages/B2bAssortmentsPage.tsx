import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, X, Package, GripVertical, Search, Sparkles, Upload, ImageIcon } from "lucide-react";

type Assortment = {
  id: string;
  name: string;
  slug: string;
  tags: string[];
  match_mode: "or" | "and";
  is_active: boolean;
  sort_order: number;
  description: string | null;
  image_url: string | null;
  valid_from: string | null;
  valid_to: string | null;
  updated_at: string;
};

const isLiveNow = (a: Pick<Assortment, "is_active" | "valid_from" | "valid_to">) => {
  if (!a.is_active) return false;
  const now = Date.now();
  if (a.valid_from && new Date(a.valid_from).getTime() > now) return false;
  if (a.valid_to && new Date(a.valid_to).getTime() < now) return false;
  return true;
};

const toDatetimeLocal = (iso: string | null | undefined) => {
  if (!iso) return "";
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

const slugify = (s: string) =>
  s.toLowerCase().trim()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");

export default function B2bAssortmentsPage() {
  const qc = useQueryClient();
  const [editing, setEditing] = useState<Partial<Assortment> | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const { data: items = [], isLoading } = useQuery({
    queryKey: ["b2b_assortments"],
    queryFn: async () => {
      // Disattiva automaticamente eventuali assortimenti scaduti prima di leggere
      await supabase.rpc("b2b_assortments_deactivate_expired");
      const { data, error } = await supabase
        .from("b2b_assortments")
        .select("*")
        .order("sort_order", { ascending: true })
        .order("name", { ascending: true });
      if (error) throw error;
      return (data ?? []) as Assortment[];
    },
  });

  // Conta articoli per ciascun assortimento
  const { data: counts = {} } = useQuery({
    queryKey: ["b2b_assortments_counts", items.map((i) => i.id).join(",")],
    enabled: items.length > 0,
    queryFn: async () => {
      const out: Record<string, number> = {};
      await Promise.all(items.map(async (it) => {
        const { data } = await supabase.rpc("b2b_assortment_article_count", { _id: it.id });
        out[it.id] = (data as number) ?? 0;
      }));
      return out;
    },
  });

  const upsert = useMutation({
    mutationFn: async (a: Partial<Assortment>) => {
      const desc = (a.description ?? "").trim();
      if (desc.length > 600) throw new Error("La descrizione non può superare 600 caratteri");
      const newValidTo = a.valid_to ? new Date(a.valid_to).toISOString() : null;
      // Se la nuova scadenza è nel futuro (o assente), riattiva automaticamente
      const validToFuture = !newValidTo || new Date(newValidTo).getTime() > Date.now();
      const payload = {
        name: a.name?.trim() ?? "",
        slug: (a.slug?.trim() || slugify(a.name ?? "")),
        tags: (a.tags ?? []).map((t) => t.trim().toLowerCase()).filter(Boolean),
        match_mode: a.match_mode ?? "or",
        is_active: validToFuture ? true : (a.is_active ?? true),
        sort_order: a.sort_order ?? 0,
        description: desc || null,
        image_url: a.image_url || null,
        valid_from: a.valid_from ? new Date(a.valid_from).toISOString() : null,
        valid_to: newValidTo,
      };
      if (!payload.name) throw new Error("Il nome è obbligatorio");
      if (!payload.slug) throw new Error("Lo slug non può essere vuoto");

      if (a.id) {
        const { error } = await supabase.from("b2b_assortments").update(payload).eq("id", a.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("b2b_assortments").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast({ title: "Salvato" });
      qc.invalidateQueries({ queryKey: ["b2b_assortments"] });
      setEditing(null);
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("b2b_assortments").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Eliminato" });
      qc.invalidateQueries({ queryKey: ["b2b_assortments"] });
      setDeleteId(null);
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const toggleActive = useMutation({
    mutationFn: async ({ id, value }: { id: string; value: boolean }) => {
      const { error } = await supabase.from("b2b_assortments").update({ is_active: value }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["b2b_assortments"] }),
  });

  const removeTag = (t: string) => {
    if (!editing) return;
    setEditing({ ...editing, tags: (editing.tags ?? []).filter((x) => x !== t) });
  };

  return (
    <div className="p-6 space-y-4 max-w-6xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">Assortimenti B2B</h1>
          <p className="text-sm text-muted-foreground">
            Crea contenitori basati sui tag degli articoli. Verranno usati come collezioni nel sito B2B.
          </p>
        </div>
        <Button onClick={() => setEditing({ tags: [], match_mode: "or", is_active: true, sort_order: 0 })}>
          <Plus className="h-4 w-4 mr-2" /> Nuovo assortimento
        </Button>
      </div>

      <div className="rounded-lg border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 border-b">
            <tr className="text-left">
              <th className="px-4 py-2 w-10"></th>
              <th className="px-4 py-2">Nome</th>
              <th className="px-4 py-2">Slug</th>
              <th className="px-4 py-2">Tag</th>
              <th className="px-4 py-2 text-center">Match</th>
              <th className="px-4 py-2 text-center">Articoli</th>
              <th className="px-4 py-2 text-center">Attivo</th>
              <th className="px-4 py-2 text-right">Azioni</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={8} className="px-4 py-8 text-center text-muted-foreground">Caricamento...</td></tr>
            ) : items.length === 0 ? (
              <tr><td colSpan={8} className="px-4 py-8 text-center text-muted-foreground">
                Nessun assortimento. Creane uno per iniziare.
              </td></tr>
            ) : items.map((it) => (
              <tr key={it.id} className="border-b last:border-b-0 hover:bg-muted/30">
                <td className="px-4 py-2 text-muted-foreground"><GripVertical className="h-4 w-4" /></td>
                <td className="px-4 py-2 font-medium">{it.name}</td>
                <td className="px-4 py-2 font-mono text-xs text-muted-foreground">{it.slug}</td>
                <td className="px-4 py-2">
                  <div className="flex flex-wrap gap-1 max-w-md">
                    {it.tags.slice(0, 6).map((t) => (
                      <Badge key={t} variant="secondary" className="text-xs">{t}</Badge>
                    ))}
                    {it.tags.length > 6 && (
                      <Badge variant="outline" className="text-xs">+{it.tags.length - 6}</Badge>
                    )}
                  </div>
                </td>
                <td className="px-4 py-2 text-center">
                  <Badge variant={it.match_mode === "and" ? "default" : "outline"} className="text-xs uppercase">
                    {it.match_mode}
                  </Badge>
                </td>
                <td className="px-4 py-2 text-center">
                  <Link
                    to={`/pim/b2b/assortments/${it.id}/articles`}
                    className="inline-flex items-center gap-1 text-xs text-primary hover:underline font-medium"
                    title="Vedi articoli"
                  >
                    <Package className="h-3 w-3" /> {counts[it.id] ?? "…"}
                  </Link>
                </td>
                <td className="px-4 py-2 text-center">
                  {(() => {
                    const live = isLiveNow(it);
                    const now = Date.now();
                    const future = it.valid_from && new Date(it.valid_from).getTime() > now;
                    const expired = it.valid_to && new Date(it.valid_to).getTime() < now;
                    const status = !it.is_active
                      ? { label: "disattivo", cls: "bg-muted text-muted-foreground border-transparent" }
                      : expired
                        ? { label: `scaduto ${new Date(it.valid_to!).toLocaleDateString()}`, cls: "bg-destructive/10 text-destructive border-destructive/30" }
                        : future
                          ? { label: `dal ${new Date(it.valid_from!).toLocaleDateString()}`, cls: "bg-amber-500/10 text-amber-700 border-amber-500/30" }
                          : live
                            ? { label: it.valid_to ? `live · fino ${new Date(it.valid_to).toLocaleDateString()}` : "live", cls: "bg-green-600/10 text-green-700 border-green-600/30" }
                            : { label: "non live", cls: "bg-muted text-muted-foreground border-transparent" };
                    return (
                      <div className="flex flex-col items-center gap-1">
                        <Switch
                          checked={it.is_active}
                          disabled={!!expired}
                          onCheckedChange={(v) => {
                            if (expired) {
                              toast({ title: "Assortimento scaduto", description: "Aggiorna o rimuovi la data di fine validità per riattivarlo.", variant: "destructive" });
                              return;
                            }
                            toggleActive.mutate({ id: it.id, value: v });
                          }}
                        />
                        <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${status.cls}`}>
                          {status.label}
                        </Badge>
                      </div>
                    );
                  })()}
                </td>
                <td className="px-4 py-2 text-right">
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setEditing(it)}>
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => setDeleteId(it.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Editor */}
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editing?.id ? "Modifica assortimento" : "Nuovo assortimento"}</DialogTitle>
          </DialogHeader>

          {editing && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label>Nome *</Label>
                  <Input
                    value={editing.name ?? ""}
                    onChange={(e) => setEditing({
                      ...editing,
                      name: e.target.value,
                      slug: editing.id ? editing.slug : slugify(e.target.value),
                    })}
                    placeholder="es. Zerbini ingresso"
                  />
                </div>
                <div className="space-y-1">
                  <Label>Slug</Label>
                  <Input
                    value={editing.slug ?? ""}
                    onChange={(e) => setEditing({ ...editing, slug: slugify(e.target.value) })}
                    className="font-mono text-xs"
                    placeholder="zerbini-ingresso"
                  />
                </div>
              </div>

              {/* Immagine di copertina + Descrizione */}
              <div className="grid grid-cols-[140px_1fr] gap-4">
                <div className="space-y-1">
                  <Label>Immagine</Label>
                  <ImagePicker
                    value={editing.image_url ?? null}
                    onChange={(url) => setEditing({ ...editing, image_url: url })}
                  />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <Label>Descrizione</Label>
                    <span className="text-xs text-muted-foreground">
                      {(editing.description ?? "").length}/600
                    </span>
                  </div>
                  <Textarea
                    value={editing.description ?? ""}
                    onChange={(e) => {
                      const v = e.target.value.slice(0, 600);
                      setEditing({ ...editing, description: v });
                    }}
                    placeholder="Breve descrizione dell'assortimento, mostrata sulla landing B2B."
                    rows={5}
                    maxLength={600}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Tag associati</Label>
                <TagAutocomplete
                  selected={editing.tags ?? []}
                  onAdd={(t) => {
                    const v = t.trim().toLowerCase();
                    if (!v) return;
                    const cur = editing.tags ?? [];
                    if (cur.includes(v)) return;
                    setEditing({ ...editing, tags: [...cur, v] });
                  }}
                />
                <div className="flex flex-wrap gap-1.5 min-h-[2rem] p-2 rounded border bg-muted/20">
                  {(editing.tags ?? []).length === 0 && (
                    <span className="text-xs text-muted-foreground">Nessun tag selezionato</span>
                  )}
                  {(editing.tags ?? []).map((t) => (
                    <Badge key={t} variant="secondary" className="text-xs gap-1">
                      {t}
                      <button onClick={() => removeTag(t)} className="hover:text-destructive">
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-1">
                  <Label>Modalità match</Label>
                  <Select
                    value={editing.match_mode ?? "or"}
                    onValueChange={(v) => setEditing({ ...editing, match_mode: v as "or" | "and" })}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="or">OR — almeno un tag</SelectItem>
                      <SelectItem value="and">AND — tutti i tag</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label>Ordine</Label>
                  <Input
                    type="number"
                    value={editing.sort_order ?? 0}
                    onChange={(e) => setEditing({ ...editing, sort_order: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div className="space-y-1">
                  <Label>Attivo</Label>
                  <div className="h-10 flex items-center">
                    <Switch
                      checked={editing.is_active ?? true}
                      onCheckedChange={(v) => setEditing({ ...editing, is_active: v })}
                    />
                  </div>
                </div>
              </div>

              {/* Validità temporale */}
              <div className="space-y-2 rounded-md border bg-muted/20 p-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm">Validità (opzionale)</Label>
                  {(editing.valid_from || editing.valid_to) && (
                    <button
                      type="button"
                      className="text-xs text-muted-foreground hover:text-destructive"
                      onClick={() => setEditing({ ...editing, valid_from: null, valid_to: null })}
                    >
                      Rimuovi date
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Inizio</Label>
                    <Input
                      type="datetime-local"
                      value={toDatetimeLocal(editing.valid_from)}
                      onChange={(e) => setEditing({ ...editing, valid_from: e.target.value || null })}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Fine</Label>
                    <Input
                      type="datetime-local"
                      value={toDatetimeLocal(editing.valid_to)}
                      onChange={(e) => setEditing({ ...editing, valid_to: e.target.value || null })}
                    />
                  </div>
                </div>
                <p className="text-[11px] text-muted-foreground">
                  Se compilate, l'assortimento appare sul B2B solo nel periodo indicato (ed è comunque richiesto "Attivo"). Lascia vuoto per validità sempre.
                </p>
              </div>

              <p className="text-xs text-muted-foreground">
                {editing.match_mode === "and"
                  ? "Solo gli articoli che hanno TUTTI i tag elencati entreranno nell'assortimento."
                  : "Tutti gli articoli che hanno ALMENO UNO dei tag elencati entreranno nell'assortimento."}
              </p>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Annulla</Button>
            <Button
              onClick={() => {
                console.log("[assortments] Salva click", { editing, isPending: upsert.isPending });
                if (editing) upsert.mutate(editing);
              }}
              disabled={upsert.isPending}
            >
              {upsert.isPending ? "Salvataggio..." : "Salva"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Conferma delete */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminare l'assortimento?</AlertDialogTitle>
            <AlertDialogDescription>
              L'operazione è irreversibile. Gli articoli e i loro tag non verranno toccati.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteId && remove.mutate(deleteId)}>
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
 * TagAutocomplete — ricerca tag già esistenti negli articoli
 * ───────────────────────────────────────────────────────────────────────── */
function TagAutocomplete({
  selected,
  onAdd,
}: {
  selected: string[];
  onAdd: (tag: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [debounced, setDebounced] = useState("");

  useEffect(() => {
    const t = setTimeout(() => setDebounced(query.trim()), 200);
    return () => clearTimeout(t);
  }, [query]);

  const { data: suggestions = [], isFetching } = useQuery({
    queryKey: ["search_article_tags", debounced],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("search_article_tags", {
        q: debounced || null,
        lim: 30,
      });
      if (error) throw error;
      return (data ?? []) as { tag: string; usage_count: number }[];
    },
    staleTime: 60_000,
  });

  const filtered = useMemo(
    () => suggestions.filter((s) => !selected.includes(s.tag)),
    [suggestions, selected]
  );

  const exactExists = suggestions.some(
    (s) => s.tag === query.trim().toLowerCase()
  );
  const canCreateNew =
    query.trim().length >= 2 &&
    !selected.includes(query.trim().toLowerCase()) &&
    !exactExists;

  const handlePick = (tag: string) => {
    onAdd(tag);
    setQuery("");
  };

  return (
    <div className="relative">
      <div className="relative">
        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              if (filtered[0]) handlePick(filtered[0].tag);
              else if (canCreateNew) handlePick(query);
            }
          }}
          placeholder="Cerca tag esistenti (es. zerbino, cocco, ingresso...)"
          className="pl-8"
        />
      </div>

      {open && (query.length > 0 || filtered.length > 0) && (
        <div className="absolute z-50 mt-1 w-full max-h-64 overflow-y-auto rounded-md border bg-popover shadow-md">
          {isFetching && (
            <div className="px-3 py-2 text-xs text-muted-foreground">Ricerca...</div>
          )}

          {!isFetching && filtered.length === 0 && !canCreateNew && (
            <div className="px-3 py-2 text-xs text-muted-foreground">
              Nessun tag trovato
            </div>
          )}

          {filtered.map((s) => (
            <button
              key={s.tag}
              type="button"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => handlePick(s.tag)}
              className="w-full flex items-center justify-between px-3 py-1.5 text-sm hover:bg-muted text-left"
            >
              <span>{s.tag}</span>
              <Badge variant="outline" className="text-xs">
                {s.usage_count} art.
              </Badge>
            </button>
          ))}

          {canCreateNew && (
            <button
              type="button"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => handlePick(query)}
              className="w-full flex items-center gap-2 px-3 py-1.5 text-sm hover:bg-muted text-left border-t"
            >
              <Sparkles className="h-3.5 w-3.5 text-primary" />
              <span>
                Crea nuovo tag: <strong>{query.trim().toLowerCase()}</strong>
              </span>
            </button>
          )}
        </div>
      )}
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────
 * ImagePicker — upload immagine di copertina su pim-media/b2b/assortments
 * ───────────────────────────────────────────────────────────────────────── */
function ImagePicker({
  value,
  onChange,
}: {
  value: string | null;
  onChange: (url: string | null) => void;
}) {
  const [uploading, setUploading] = useState(false);

  const handleUpload = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast({ title: "File non valido", description: "Carica un'immagine.", variant: "destructive" });
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "File troppo grande", description: "Massimo 5 MB.", variant: "destructive" });
      return;
    }
    setUploading(true);
    try {
      const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
      const path = `b2b/assortments/${crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage
        .from("pim-media")
        .upload(path, file, { cacheControl: "3600", upsert: false });
      if (error) throw error;
      const { data } = supabase.storage.from("pim-media").getPublicUrl(path);
      onChange(data.publicUrl);
    } catch (e: any) {
      toast({ title: "Errore upload", description: e.message, variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-2">
      <div className="relative aspect-square w-full rounded-md border bg-muted/30 overflow-hidden flex items-center justify-center">
        {value ? (
          <>
            <img src={value} alt="Cover" className="w-full h-full object-cover" />
            <button
              type="button"
              onClick={() => onChange(null)}
              className="absolute top-1 right-1 bg-background/80 hover:bg-background rounded p-1 shadow"
              title="Rimuovi"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </>
        ) : (
          <ImageIcon className="h-8 w-8 text-muted-foreground/50" />
        )}
      </div>
      <label className="block">
        <input
          type="file"
          accept="image/*"
          className="hidden"
          disabled={uploading}
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) handleUpload(f);
            e.target.value = "";
          }}
        />
        <span className="cursor-pointer flex items-center justify-center gap-1.5 text-xs h-8 rounded border bg-background hover:bg-muted">
          <Upload className="h-3 w-3" />
          {uploading ? "Caricamento..." : value ? "Cambia" : "Carica"}
        </span>
      </label>
    </div>
  );
}

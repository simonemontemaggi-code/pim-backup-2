import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  Loader2,
  Save,
  Users,
  Lock,
  Pencil,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  useCustomer,
  useUpdateCustomerPim,
  useUpdateCustomerB2bAccess,
  CustomerPimUpdate,
} from "@/hooks/useCustomers";
import { useLookupValues } from "@/hooks/useLookupValues";
import { useAuth } from "@/contexts/AuthContext";
import { CustomerB2bConsentsCard } from "@/components/customers/CustomerB2bConsentsCard";

function ReadOnlyField({
  label,
  value,
}: {
  label: string;
  value?: string | null;
}) {
  return (
    <div className="space-y-1">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground flex items-center gap-1">
        <Lock className="h-3 w-3" />
        {label}
      </Label>
      <Input
        value={value ?? ""}
        readOnly
        disabled
        className="bg-muted/40 font-mono text-xs"
      />
    </div>
  );
}

function EditableField({
  label,
  value,
  onChange,
  disabled,
  type = "text",
  placeholder,
}: {
  label: string;
  value: string | null | undefined;
  onChange: (v: string | null) => void;
  disabled?: boolean;
  type?: string;
  placeholder?: string;
}) {
  return (
    <div className="space-y-1">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground flex items-center gap-1">
        <Pencil className="h-3 w-3 text-primary" />
        {label}
      </Label>
      <Input
        type={type}
        value={value ?? ""}
        placeholder={placeholder}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value === "" ? null : e.target.value)}
      />
    </div>
  );
}

function EditableTextarea({
  label,
  value,
  onChange,
  disabled,
  rows = 3,
}: {
  label: string;
  value: string | null | undefined;
  onChange: (v: string | null) => void;
  disabled?: boolean;
  rows?: number;
}) {
  return (
    <div className="space-y-1 col-span-2">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground flex items-center gap-1">
        <Pencil className="h-3 w-3 text-primary" />
        {label}
      </Label>
      <Textarea
        rows={rows}
        value={value ?? ""}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value === "" ? null : e.target.value)}
      />
    </div>
  );
}

function EditableSelect({
  label,
  value,
  onChange,
  options,
  disabled,
}: {
  label: string;
  value: string | null | undefined;
  onChange: (v: string | null) => void;
  options: { code: string; label: string }[];
  disabled?: boolean;
}) {
  return (
    <div className="space-y-1">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground flex items-center gap-1">
        <Pencil className="h-3 w-3 text-primary" />
        {label}
      </Label>
      <Select
        value={value ?? "__none__"}
        onValueChange={(v) => onChange(v === "__none__" ? null : v)}
        disabled={disabled}
      >
        <SelectTrigger>
          <SelectValue placeholder="—" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="__none__">—</SelectItem>
          {options.map((o) => (
            <SelectItem key={o.code} value={o.code}>
              {o.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

function EditableSwitch({
  label,
  value,
  onChange,
  disabled,
}: {
  label: string;
  value: boolean | null | undefined;
  onChange: (v: boolean | null) => void;
  disabled?: boolean;
}) {
  // tri-state: null / true / false
  const display: "yes" | "no" | "unknown" =
    value === true ? "yes" : value === false ? "no" : "unknown";
  return (
    <div className="space-y-1">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground flex items-center gap-1">
        <Pencil className="h-3 w-3 text-primary" />
        {label}
      </Label>
      <Select
        value={display}
        onValueChange={(v) =>
          onChange(v === "yes" ? true : v === "no" ? false : null)
        }
        disabled={disabled}
      >
        <SelectTrigger>
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="unknown">— (non specificato)</SelectItem>
          <SelectItem value="yes">Sì</SelectItem>
          <SelectItem value="no">No</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}

function Section({
  title,
  children,
  description,
}: {
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-lg border bg-card p-4 space-y-3">
      <div>
        <h3 className="text-sm font-semibold">{title}</h3>
        {description && (
          <p className="text-xs text-muted-foreground">{description}</p>
        )}
      </div>
      <div className="grid grid-cols-2 gap-3">{children}</div>
    </div>
  );
}

export default function CustomerDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { role } = useAuth();
  const canEdit =
    role === "admin" || role === "manager" || role === "collaborator";

  const { data: c, isLoading } = useCustomer(id ?? null);
  const update = useUpdateCustomerPim(id ?? null);

  const { data: importanceOpts = [] } = useLookupValues("customer_importance");
  const { data: dayOpts = [] } = useLookupValues("customer_day");
  const { data: freqOpts = [] } = useLookupValues("customer_visit_frequency");
  const { data: paymentOpts = [] } = useLookupValues("customer_payment_method");

  const [form, setForm] = useState<CustomerPimUpdate>({});
  const [dirty, setDirty] = useState(false);
  const b2bAccess = useUpdateCustomerB2bAccess(id ?? null);
  const [emailOpen, setEmailOpen] = useState(false);
  const [emailValue, setEmailValue] = useState("");
  const [phoneOpen, setPhoneOpen] = useState(false);
  const [phoneValue, setPhoneValue] = useState("");

  useEffect(() => {
    if (!c) return;
    setForm({
      pec: c.pec,
      sdi_code: c.sdi_code,
      closing_day: c.closing_day,
      delivery_notes: c.delivery_notes,
      contact_name: c.contact_name,
      contact_mobile: c.contact_mobile,
      importance: c.importance,
      visit_day: c.visit_day,
      visit_frequency: c.visit_frequency,
      competitors: c.competitors,
      suppliers_present: c.suppliers_present,
      sells_online: c.sells_online,
      has_pc: c.has_pc,
      payment_method: c.payment_method,
      bank_name: c.bank_name,
      bank_branch: c.bank_branch,
      iban: c.iban,
      pim_notes: c.pim_notes,
    });
    setDirty(false);
  }, [c]);

  const set = <K extends keyof CustomerPimUpdate>(
    key: K,
    val: CustomerPimUpdate[K]
  ) => {
    setForm((prev) => ({ ...prev, [key]: val }));
    setDirty(true);
  };

  const opts = useMemo(
    () => ({
      importance: importanceOpts.map((o) => ({
        code: o.code,
        label: o.label ?? o.code,
      })),
      day: dayOpts.map((o) => ({ code: o.code, label: o.label ?? o.code })),
      freq: freqOpts.map((o) => ({ code: o.code, label: o.label ?? o.code })),
      payment: paymentOpts.map((o) => ({
        code: o.code,
        label: o.label ?? o.code,
      })),
    }),
    [importanceOpts, dayOpts, freqOpts, paymentOpts]
  );

  if (isLoading || !c) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const disabled = !canEdit || update.isPending;

  return (
    <div className="p-6 space-y-4 max-w-6xl">
      {/* Header */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate("/pim/customers")}
          >
            <ArrowLeft className="h-4 w-4 mr-1" /> Lista clienti
          </Button>
          <div className="flex items-center gap-3">
            <Users className="h-6 w-6 text-primary" />
            <div>
              <div className="text-xs text-muted-foreground">
                CDCLI {c.customer_code}
              </div>
              <h1 className="text-2xl font-bold leading-tight">
                {c.company_full_name ?? c.company_name}
              </h1>
              <div className="flex flex-wrap gap-2 mt-1">
                {c.last_import_at && (
                  <Badge variant="outline" className="text-xs">
                    Ultimo import: {new Date(c.last_import_at).toLocaleString("it-IT")}
                  </Badge>
                )}
                {c.pim_updated_at && (
                  <Badge variant="secondary" className="text-xs">
                    Modificato in PIM:{" "}
                    {new Date(c.pim_updated_at).toLocaleString("it-IT")}
                  </Badge>
                )}
                {!canEdit && (
                  <Badge variant="outline" className="text-xs">
                    Sola lettura
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>
        <Button
          onClick={() => update.mutate(form)}
          disabled={disabled || !dirty}
        >
          {update.isPending ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Save className="h-4 w-4 mr-2" />
          )}
          Salva modifiche
        </Button>
      </div>

      <p className="text-xs text-muted-foreground">
        I campi con <Lock className="h-3 w-3 inline" /> arrivano dal gestionale
        AS400 (sola lettura, aggiornati dall&apos;import settimanale). I campi
        con <Pencil className="h-3 w-3 inline text-primary" /> sono editabili
        nel PIM e non vengono mai sovrascritti.
      </p>

      <Section title="Anagrafica (da AS400)">
        <ReadOnlyField label="Codice cliente" value={c.customer_code} />
        <ReadOnlyField
          label="Cliente fatturazione"
          value={c.billing_customer_code}
        />
        <ReadOnlyField label="Ragione Sociale" value={c.company_name} />
        <ReadOnlyField
          label="Ragione Sociale agg."
          value={c.company_name_aux}
        />
      </Section>

      <Section title="Dati fiscali">
        <ReadOnlyField label="Partita IVA" value={c.vat_number} />
        <ReadOnlyField label="Codice Fiscale" value={c.tax_code} />
        <ReadOnlyField
          label="Codice ATECO"
          value={
            (c as any).codice_ateco
              ? `${(c as any).codice_ateco}${(c as any).descrizione_ateco ? " — " + (c as any).descrizione_ateco : ""}`
              : null
          }
        />
        <EditableField
          label="PEC"
          value={form.pec}
          onChange={(v) => set("pec", v)}
          disabled={disabled}
          type="email"
          placeholder="cliente@pec.it"
        />
        <EditableField
          label="Codice SDI"
          value={form.sdi_code}
          onChange={(v) => set("sdi_code", v)}
          disabled={disabled}
          placeholder="es. M5UXCR1"
        />
      </Section>

      <Section title="Contatti">
        <ReadOnlyField label="Telefono negozio" value={c.phone} />
        <ReadOnlyField label="Email" value={c.email} />
        <EditableField
          label="Nome e cognome referente"
          value={form.contact_name}
          onChange={(v) => set("contact_name", v)}
          disabled={disabled}
        />
        <EditableField
          label="Cellulare referente"
          value={form.contact_mobile}
          onChange={(v) => set("contact_mobile", v)}
          disabled={disabled}
          type="tel"
        />
      </Section>

      <Section title="Indirizzo fatturazione">
        <ReadOnlyField label="Indirizzo" value={c.address} />
        <ReadOnlyField label="CAP" value={c.postal_code} />
        <ReadOnlyField label="Località" value={c.city} />
        <ReadOnlyField label="Provincia" value={c.province} />
        <ReadOnlyField label="Zona" value={c.zone_code} />
      </Section>

      <Section title="Indirizzo di scarico">
        <ReadOnlyField label="Indirizzo" value={c.delivery_address} />
        <ReadOnlyField label="CAP" value={c.delivery_postal_code} />
        <ReadOnlyField label="Città" value={c.delivery_city} />
        <ReadOnlyField label="Provincia" value={c.delivery_province} />
        <EditableField
          label="Giorno di chiusura"
          value={form.closing_day}
          onChange={(v) => set("closing_day", v)}
          disabled={disabled}
          placeholder="es. domenica, mercoledì pom."
        />
        <EditableTextarea
          label="Note per scarico merce"
          value={form.delivery_notes}
          onChange={(v) => set("delivery_notes", v)}
          disabled={disabled}
          rows={2}
        />
      </Section>

      <Section title="Categoria & visite commerciali">
        <ReadOnlyField label="Categoria merc." value={c.category_merch} />
        <ReadOnlyField label="Categoria vendita" value={c.category_sales} />
        <EditableSelect
          label="Importanza"
          value={form.importance}
          onChange={(v) => set("importance", v)}
          options={opts.importance}
          disabled={disabled}
        />
        <EditableSelect
          label="Giorno abituale visita"
          value={form.visit_day}
          onChange={(v) => set("visit_day", v)}
          options={opts.day}
          disabled={disabled}
        />
        <EditableSelect
          label="Frequenza giro visite"
          value={form.visit_frequency}
          onChange={(v) => set("visit_frequency", v)}
          options={opts.freq}
          disabled={disabled}
        />
      </Section>

      <Section title="Mercato & negozio">
        <EditableTextarea
          label="Grossisti concorrenti presenti"
          value={form.competitors}
          onChange={(v) => set("competitors", v)}
          disabled={disabled}
          rows={2}
        />
        <EditableTextarea
          label="Fornitori/produttori presenti"
          value={form.suppliers_present}
          onChange={(v) => set("suppliers_present", v)}
          disabled={disabled}
          rows={2}
        />
        <EditableSwitch
          label="Effettua vendite online"
          value={form.sells_online}
          onChange={(v) => set("sells_online", v)}
          disabled={disabled}
        />
        <EditableSwitch
          label="Presenza PC in negozio"
          value={form.has_pc}
          onChange={(v) => set("has_pc", v)}
          disabled={disabled}
        />
      </Section>

      <Section title="Pagamento & banca">
        <EditableSelect
          label="Modalità di pagamento"
          value={form.payment_method}
          onChange={(v) => set("payment_method", v)}
          options={opts.payment}
          disabled={disabled}
        />
        <EditableField
          label="Banca"
          value={form.bank_name}
          onChange={(v) => set("bank_name", v)}
          disabled={disabled}
        />
        <EditableField
          label="Filiale / Agenzia"
          value={form.bank_branch}
          onChange={(v) => set("bank_branch", v)}
          disabled={disabled}
        />
        <EditableField
          label="Codice IBAN"
          value={form.iban}
          onChange={(v) => set("iban", v?.toUpperCase().replace(/\s/g, "") ?? null)}
          disabled={disabled}
          placeholder="IT00X0000000000000000000000"
        />
      </Section>

      <Section title="Riferimenti commerciali">
        <ReadOnlyField label="Codice agente" value={c.original_agent_code} />
        <ReadOnlyField label="Cod. Listino" value={c.price_list_code} />
      </Section>

      <Section
        title="Accesso portale B2B"
        description="Dati di accesso al portale B2B. Modificabili solo dagli admin."
      >
        <div className="col-span-2 grid grid-cols-2 gap-3">
          <ReadOnlyField
            label="Email accesso B2B"
            value={c.mail_accesso_cliente}
          />
          <ReadOnlyField
            label="Attivato il"
            value={
              c.activated_at
                ? new Date(c.activated_at).toLocaleString("it-IT")
                : "— non attivato"
            }
          />
          <ReadOnlyField
            label="Cellulare B2B"
            value={c.b2b_access?.phone_number ?? "—"}
          />
          <ReadOnlyField
            label="Cellulare impostato il"
            value={
              c.b2b_access?.phone_set_at
                ? new Date(c.b2b_access.phone_set_at).toLocaleString("it-IT")
                : "—"
            }
          />
        </div>
        {role === "admin" && (
          <div className="col-span-2 flex flex-wrap gap-2">
            {c.auth_user_id ? (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setEmailValue(c.mail_accesso_cliente ?? "");
                    setEmailOpen(true);
                  }}
                >
                  <Pencil className="h-3.5 w-3.5 mr-1" /> Modifica email accesso
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setPhoneValue(c.b2b_access?.phone_number ?? "");
                    setPhoneOpen(true);
                  }}
                >
                  <Pencil className="h-3.5 w-3.5 mr-1" /> Modifica cellulare
                </Button>
              </>
            ) : (
              <p className="text-xs text-muted-foreground">
                Cliente non ancora attivato sul portale B2B: i dati di accesso non
                sono modificabili.
              </p>
            )}
          </div>
        )}
      </Section>

      <Dialog open={emailOpen} onOpenChange={setEmailOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Modifica email accesso B2B</DialogTitle>
            <DialogDescription>
              Aggiorna l&apos;email di login del cliente sul portale B2B. Il
              cliente non riceve alcuna notifica automatica.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">
              Nuova email
            </Label>
            <Input
              type="email"
              value={emailValue}
              onChange={(e) => setEmailValue(e.target.value)}
              placeholder="cliente@dominio.it"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEmailOpen(false)}>
              Annulla
            </Button>
            <Button
              disabled={
                b2bAccess.isPending ||
                !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailValue.trim())
              }
              onClick={() =>
                b2bAccess.mutate(
                  { email: emailValue.trim().toLowerCase() },
                  { onSuccess: () => setEmailOpen(false) }
                )
              }
            >
              {b2bAccess.isPending && (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              )}
              Salva
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={phoneOpen} onOpenChange={setPhoneOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Modifica cellulare B2B</DialogTitle>
            <DialogDescription>
              Numero in formato internazionale, es. +393331234567.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">
              Nuovo cellulare
            </Label>
            <Input
              type="tel"
              value={phoneValue}
              onChange={(e) => setPhoneValue(e.target.value)}
              placeholder="+393331234567"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPhoneOpen(false)}>
              Annulla
            </Button>
            <Button
              disabled={
                b2bAccess.isPending ||
                !/^\+?[0-9 ]{6,20}$/.test(phoneValue.trim())
              }
              onClick={() =>
                b2bAccess.mutate(
                  { phone_number: phoneValue.trim() },
                  { onSuccess: () => setPhoneOpen(false) }
                )
              }
            >
              {b2bAccess.isPending && (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              )}
              Salva
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Section title="Note">
        <EditableTextarea
          label="Note e varie"
          value={form.pim_notes}
          onChange={(v) => set("pim_notes", v)}
          disabled={disabled}
          rows={4}
        />
      </Section>

      <CustomerB2bConsentsCard
        authUserId={c.auth_user_id}
        consents={c.b2b_consents ?? null}
        access={c.b2b_access ?? null}
      />


      {/* Sticky save bar mobile */}
      {dirty && canEdit && (
        <div className="sticky bottom-4 flex justify-end">
          <Button
            onClick={() => update.mutate(form)}
            disabled={update.isPending}
            size="lg"
            className="shadow-lg"
          >
            {update.isPending ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            Salva modifiche
          </Button>
        </div>
      )}
    </div>
  );
}

import { useQuery } from "@tanstack/react-query";
import { useState, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Package, RefreshCw, AlertTriangle, Image, FileText, ShoppingCart, BarChart3, Tags, PenTool, Search, Barcode } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useVisibleAssortments } from "@/hooks/useVisibleAssortments";
import { useOnlineAssortments, computeIsB2bOnline } from "@/hooks/useOnlineAssortments";
import { useAuth } from "@/contexts/AuthContext";
import { useControlCounts } from "@/hooks/useControlCounts";
import { fetchAllPages } from "@/lib/mediaUpload";
import { normalizeMediaCdpar } from "@/lib/mediaUtils";

const FILTER_OPTIONS = ["A", "B", "C", "E", "G", "N", "O"];
const FILTER_DEFAULTS = ["C", "E", "G", "N", "O"];

const SYNC_BADGE: Record<string, string> = {
  new: "bg-primary text-primary-foreground",
  modified: "bg-warning text-warning-foreground",
  synced: "bg-success text-success-foreground",
  error: "bg-destructive text-destructive-foreground",
  pending: "bg-muted text-muted-foreground",
};

function getDashboardType(departmentName: string | null, role: string | null): string {
  if (role === "admin") return "admin";
  const name = (departmentName ?? "").toLowerCase();
  if (name.includes("marketing")) return "marketing";
  if (name.includes("acquist")) return "acquisti";
  if (name.includes("logistic") || name.includes("magazzin")) return "logistica";
  if (name.includes("vendit") || name.includes("commerc") || name.includes("agent")) return "commerciale";
  return "general";
}

export default function PimDashboard() {
  const navigate = useNavigate();
  const { data: visibleAssortments = [] } = useVisibleAssortments();
  const { data: onlineAssortments = [] } = useOnlineAssortments();
  const { role, departmentName } = useAuth();
  const dashType = getDashboardType(departmentName, role);
  const isAdmin = dashType === "admin";

  const [selectedFilters, setSelectedFilters] = useState<string[]>(FILTER_DEFAULTS);
  const toggleFilter = (code: string) =>
    setSelectedFilters((prev) => prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]);

  // Effective assortments: intersect dashboard filter selection with configured visible/online lists.
  const effectiveVisible = useMemo(
    () => visibleAssortments.length > 0 ? visibleAssortments.filter((c) => selectedFilters.includes(c)) : selectedFilters,
    [visibleAssortments, selectedFilters]
  );
  const { data: controlCounts } = useControlCounts(effectiveVisible);

  const { data: stats, isLoading } = useQuery({
    queryKey: ["dashboard_stats", effectiveVisible, onlineAssortments, dashType],
    refetchInterval: 60000,
    queryFn: async () => {
      const hasFilter = effectiveVisible.length > 0;
      const withFilter = (q: any) => hasFilter ? q.in("wfuas", effectiveVisible) : q;

      // All counts via head:true (no data transfer)
      const [
        { count: totalArticles },
        { count: toSync },
        { count: syncErrors },
        { count: noMarketingDesc },
        { count: noEcomDesc },
        { count: noSeoTitle },
        mediaRpc,
        barcodeRpc,
        onlineCandidateRows,
        imageMediaRows,
      ] = await Promise.all([
        withFilter(supabase.from("archivio_articoli_fraschetti").select("*", { count: "exact", head: true })),
        withFilter(supabase.from("archivio_articoli_fraschetti").select("*", { count: "exact", head: true }).in("as400_sync_status", ["new", "modified"])),
        withFilter(supabase.from("archivio_articoli_fraschetti").select("*", { count: "exact", head: true }).eq("as400_sync_status", "error")),
        withFilter(supabase.from("archivio_articoli_fraschetti").select("*", { count: "exact", head: true }).is("description_marketing", null)),
        withFilter(supabase.from("archivio_articoli_fraschetti").select("*", { count: "exact", head: true }).is("description_ecommerce", null)),
        withFilter(supabase.from("archivio_articoli_fraschetti").select("*", { count: "exact", head: true }).is("seo_title", null)),
        supabase.rpc("count_articles_with_media_filtered" as any, hasFilter ? { assortments: effectiveVisible } : {}),
        supabase.rpc("count_articles_with_barcodes" as any, hasFilter ? { assortments: effectiveVisible } : {}),
        fetchAllPages(async (from, to) => {
          let q = supabase
            .from("archivio_articoli_fraschetti")
            .select("cdpar, wfuas, b2b_online_active")
            .range(from, to);
          if (hasFilter) q = q.in("wfuas", effectiveVisible);
          const { data, error } = await q;
          if (error) throw error;
          return (data ?? []) as { cdpar: string; wfuas: string | null; b2b_online_active: boolean | null }[];
        }),
        fetchAllPages(async (from, to) => {
          const { data, error } = await supabase
            .from("article_media")
            .select("cdpar")
            .eq("media_type", "image")
            .range(from, to);
          if (error) throw error;
          return (data ?? []) as { cdpar: string }[];
        }),
      ]);
      const articlesWithMediaCount = (mediaRpc as any)?.data ?? 0;
      const totalBarcodeArticles = (barcodeRpc as any)?.data ?? 0;

      const total = totalArticles ?? 0;

      // Recent articles (lightweight)
      let recentQ = supabase.from("archivio_articoli_fraschetti")
        .select("cdpar, depar, updated_at, created_at, as400_sync_status, updated_by")
        .order("updated_at", { ascending: false })
        .limit(10);
      if (hasFilter) recentQ = recentQ.in("wfuas", effectiveVisible);
      const { data: recentArticles } = await recentQ;

      // Sync queue
      const { data: syncQueue } = await supabase.from("as400_sync_queue")
        .select("*").eq("status", "pending").order("created_at", { ascending: false }).limit(5);

      // Media coverage globale (per KPI principale)
      const mediaCount = articlesWithMediaCount ?? 0;
      const mediaCoverage = total > 0 ? Math.min(100, Math.round((mediaCount / total) * 100)) : 0;

      // Media coverage SOLO online B2B effettivo (stessa logica della Media Library)
      const imageCdpars = new Set((imageMediaRows as { cdpar: string }[]).map((m) => normalizeMediaCdpar(m.cdpar)).filter(Boolean));
      const effectiveOnlineRows = (onlineCandidateRows as { cdpar: string; wfuas: string | null; b2b_online_active: boolean | null }[])
        .filter((row) => computeIsB2bOnline(row.b2b_online_active, row.wfuas, onlineAssortments));
      const onlineTotal = effectiveOnlineRows.length;
      const onlineWithoutImage = effectiveOnlineRows.filter((row) => !imageCdpars.has(normalizeMediaCdpar(row.cdpar))).length;
      const mediaOnlineCount = onlineTotal - onlineWithoutImage;
      const mediaCoverageOnline = onlineTotal > 0 ? Math.min(100, Math.round((mediaOnlineCount / onlineTotal) * 100)) : 0;

      // Barcode coverage (distinct articles with barcodes) sull'archivio visibile
      const barcodeCount = totalBarcodeArticles ?? 0;
      const barcodeCoverage = total > 0 ? Math.min(100, Math.round((barcodeCount / total) * 100)) : 0;

      return {
        totalArticles: total,
        toSync: toSync ?? 0,
        syncErrors: syncErrors ?? 0,
        recentArticles: recentArticles ?? [],
        syncQueue: syncQueue ?? [],
        noMarketingDesc: noMarketingDesc ?? 0,
        noEcomDesc: noEcomDesc ?? 0,
        noSeoTitle: noSeoTitle ?? 0,
        articlesWithMedia: mediaCount,
        articlesWithoutMedia: total - mediaCount,
        mediaCoverage,
        onlineTotal,
        articlesOnlineWithoutMedia: onlineWithoutImage,
        mediaCoverageOnline,
        articlesWithBarcodes: barcodeCount,
        barcodeCoverage,
      };
    },
  });

  if (isLoading) return <div className="p-6 space-y-4">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}</div>;

  const s = stats!;
  const showSection = (sections: string[]) => isAdmin || sections.includes(dashType);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Dashboard PIM</h1>
        {!isAdmin && departmentName && (
          <Badge variant="outline" className="text-xs">{departmentName}</Badge>
        )}
        {isAdmin && (
          <Badge className="bg-primary text-primary-foreground text-xs">Admin — Vista completa</Badge>
        )}
      </div>

      {/* Assortment filter chips */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs font-medium text-muted-foreground mr-1">Assortimenti:</span>
        {FILTER_OPTIONS.map((code) => {
          const active = selectedFilters.includes(code);
          return (
            <button
              key={code}
              type="button"
              onClick={() => toggleFilter(code)}
              className={`h-7 min-w-[2rem] px-2 rounded-md text-xs font-semibold border transition-colors ${
                active
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-background text-muted-foreground border-border hover:bg-accent"
              }`}
            >
              {code}
            </button>
          );
        })}
        <button
          type="button"
          onClick={() => setSelectedFilters(FILTER_DEFAULTS)}
          className="ml-2 text-xs text-muted-foreground hover:text-foreground underline"
        >
          Reset
        </button>
      </div>



      {/* KPI Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Totale Articoli</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent><p className="text-2xl font-bold">{s.totalArticles.toLocaleString("it-IT")}</p></CardContent>
        </Card>

        {showSection(["acquisti", "general"]) && (
          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate("/pim/sync")}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Da Sincronizzare</CardTitle>
              <RefreshCw className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent><p className="text-2xl font-bold">{s.toSync.toLocaleString("it-IT")}</p></CardContent>
          </Card>
        )}

        {showSection(["acquisti", "general"]) && (
          <Card className={s.syncErrors > 0 ? "border-destructive" : ""}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Errori Sync</CardTitle>
              <AlertTriangle className={`h-4 w-4 ${s.syncErrors > 0 ? "text-destructive" : "text-muted-foreground"}`} />
            </CardHeader>
            <CardContent><p className={`text-2xl font-bold ${s.syncErrors > 0 ? "text-destructive" : ""}`}>{s.syncErrors}</p></CardContent>
          </Card>
        )}

        {showSection(["marketing", "general"]) && (
          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate("/pim/media")}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Media Coverage</CardTitle>
              <Image className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{s.mediaCoverage}%</p>
              <p className="text-xs text-muted-foreground">{s.articlesWithMedia.toLocaleString("it-IT")} con media / {s.totalArticles.toLocaleString("it-IT")}</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* MARKETING SECTION */}
      {showSection(["marketing"]) && (
        <>
          <h2 className="text-lg font-semibold flex items-center gap-2 mt-4">
            <PenTool className="h-5 w-5 text-primary" /> Attività Marketing
          </h2>
          <div className="grid gap-4 md:grid-cols-4">
            <Card className="border-amber-500/30 cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate("/pim/controls/articoli/senza-descrizione")}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Senza Descrizione</CardTitle>
                <FileText className="h-4 w-4 text-amber-500" />
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-amber-600">{(controlCounts?.no_desc ?? 0).toLocaleString("it-IT")}</p>
                <p className="text-xs text-muted-foreground">{controlCounts?.total ? Math.round((controlCounts.no_desc / controlCounts.total) * 100) : 0}% da completare</p>
              </CardContent>
            </Card>
            <Card className="border-amber-500/30 cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate("/pim/controls/articoli/senza-scheda-tecnica")}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Senza Scheda Tecnica</CardTitle>
                <ShoppingCart className="h-4 w-4 text-amber-500" />
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-amber-600">{(controlCounts?.no_st ?? 0).toLocaleString("it-IT")}</p>
                <p className="text-xs text-muted-foreground">{controlCounts?.total ? Math.round((controlCounts.no_st / controlCounts.total) * 100) : 0}% da completare</p>
              </CardContent>
            </Card>
            <Card className="border-amber-500/30 cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate("/pim/controls/articoli/senza-attributi-obbligatori")}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Senza Attributi Obbligatori</CardTitle>
                <Search className="h-4 w-4 text-amber-500" />
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-amber-600">{(controlCounts?.no_attr ?? 0).toLocaleString("it-IT")}</p>
                <p className="text-xs text-muted-foreground">{controlCounts?.total ? Math.round((controlCounts.no_attr / controlCounts.total) * 100) : 0}% da completare</p>
              </CardContent>
            </Card>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate("/pim/controls/articoli/senza-immagine?online=1")}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Articoli Online senza Immagini</CardTitle>
                <Image className="h-4 w-4 text-amber-500" />
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-amber-600">{s.articlesOnlineWithoutMedia.toLocaleString("it-IT")}</p>
                <div className="mt-2 h-2 rounded-full bg-muted overflow-hidden">
                  <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${s.mediaCoverageOnline}%` }} />
                </div>
                <p className="text-xs text-muted-foreground mt-1">{s.mediaCoverageOnline}% copertura su {s.onlineTotal.toLocaleString("it-IT")} articoli online B2B</p>
              </CardContent>
            </Card>

          </div>
        </>
      )}

      {/* ACQUISTI SECTION */}
      {showSection(["acquisti"]) && (
        <>
          <h2 className="text-lg font-semibold flex items-center gap-2 mt-4">
            <ShoppingCart className="h-5 w-5 text-primary" /> Attività Acquisti
          </h2>
        </>
      )}

      {/* COMMERCIALE SECTION */}
      {(dashType === "commerciale") && (
        <h2 className="text-lg font-semibold flex items-center gap-2 mt-4">
          <BarChart3 className="h-5 w-5 text-primary" /> Attività Commerciale
        </h2>
      )}

      {/* BARCODE */}
      {showSection(["acquisti"]) && (
        <div className="grid gap-4 md:grid-cols-2">
          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate("/pim/barcodes")}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Copertura Barcode</CardTitle>
              <Barcode className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{s.barcodeCoverage}%</p>
              <p className="text-xs text-muted-foreground">{s.articlesWithBarcodes.toLocaleString("it-IT")} articoli con barcode</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* RECENT ARTICLES */}
      <Card>
        <CardHeader><CardTitle className="text-sm">Articoli Modificati di Recente</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-2">
            {s.recentArticles.map((a: any) => {
              const isNew = a.created_at === a.updated_at;
              return (
                <div
                  key={a.cdpar}
                  className="flex items-center justify-between text-sm border-b pb-2 last:border-0 cursor-pointer hover:bg-accent/30 rounded px-2 py-1 -mx-2 transition-colors"
                  onClick={() => navigate(`/pim/articles/${encodeURIComponent(a.cdpar)}`)}
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs text-muted-foreground w-[100px] truncate">{a.cdpar}</span>
                    <span className="truncate max-w-[300px]">{a.depar}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={isNew ? "default" : "secondary"} className="text-[10px] px-1.5 py-0">
                      {isNew ? "Nuovo" : "Modificato"}
                    </Badge>
                    <span className="text-xs text-muted-foreground">{new Date(a.updated_at).toLocaleDateString("it-IT")}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* SYNC QUEUE */}
      {showSection(["acquisti", "general"]) && s.syncQueue.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-sm">Coda Sincronizzazione</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-2">
              {s.syncQueue.map((q: any) => (
                <div key={q.id} className="flex items-center justify-between text-sm border-b pb-2 last:border-0">
                  <span className="font-mono text-xs">{q.cdpar}</span>
                  <Badge className={`${SYNC_BADGE[q.status] ?? SYNC_BADGE.pending} text-[10px]`}>{q.status}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { UserCheck, Plus, Pencil, Trash2, Loader2, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { usePermissions } from "@/lib/permissions";

interface AgentProfile {
  id: string;
  user_id: string;
  full_name: string | null;
  email: string | null;
  agent_code: string | null;
  order_email: string | null;
  phone_number: string | null;
  price_list_code: string | null;
}

type Draft = {
  id: string;
  user_id: string;
  full_name: string;
  agent_code: string;
  order_email: string;
  phone_number: string;
  price_list_code: string;
};

export default function AgentsPage() {
  const qc = useQueryClient();
  const { can, sectionVisible } = usePermissions();
  const canEdit = can("write", "agents");
  const canRemove = can("write", "agents");
  const visible = sectionVisible("agents");

  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<Draft | null>(null);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickedUserId, setPickedUserId] = useState<string>("");
  const [removeId, setRemoveId] = useState<string | null>(null);

  const { data: agents = [], isLoading } = useQuery({
    queryKey: ["agents_from_profiles"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id,user_id,full_name,email,agent_code,order_email,phone_number,price_list_code")
        .not("agent_code", "is", null)
        .neq("agent_code", "")
        .order("agent_code", { ascending: true });
      if (error) throw error;
      return (data ?? []) as AgentProfile[];
    },
  });

  // Set di auth_user_id che sono ANCHE clienti B2B (per mostrare badge)
  const { data: alsoCustomerIds = new Set<string>() } = useQuery({
    queryKey: ["agents_also_customers", agents.map((a) => a.user_id)],
    enabled: agents.length > 0,
    queryFn: async () => {
      const ids = agents.map((a) => a.user_id).filter(Boolean);
      if (ids.length === 0) return new Set<string>();
      const { data, error } = await supabase
        .from("customers")
        .select("auth_user_id")
        .in("auth_user_id", ids);
      if (error) throw error;
      return new Set((data ?? []).map((r: any) => r.auth_user_id as string));
    },
  });

  // Profili senza codice agente (per il picker "Nuovo agente")
  const { data: nonAgents = [] } = useQuery({
    queryKey: ["non_agents_profiles"],
    enabled: pickerOpen,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id,user_id,full_name,email")
        .or("agent_code.is.null,agent_code.eq.")
        .order("full_name", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });

  const saveMut = useMutation({
    mutationFn: async (draft: Draft) => {
      const code = draft.agent_code.trim();
      if (!code) throw new Error("Codice agente obbligatorio");
      const { data, error } = await supabase
        .from("profiles")
        .update({
          full_name: draft.full_name.trim() || null,
          agent_code: code,
          order_email: draft.order_email.trim() || null,
          phone_number: draft.phone_number.trim() || null,
          price_list_code: draft.price_list_code.trim() || null,
        })
        .eq("id", draft.id)
        .select("id");
      if (error) throw error;
      if (!data || data.length === 0) {
        throw new Error("Permessi insufficienti: nessuna modifica salvata.");
      }
    },
    onSuccess: () => {
      toast({ title: "Agente salvato" });
      qc.invalidateQueries({ queryKey: ["agents_from_profiles"] });
      qc.invalidateQueries({ queryKey: ["non_agents_profiles"] });
      setEditing(null);
    },
    onError: (e: any) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const removeMut = useMutation({
    mutationFn: async (profileId: string) => {
      const { data, error } = await supabase
        .from("profiles")
        .update({ agent_code: null, order_email: null, price_list_code: null })
        .eq("id", profileId)
        .select("id");
      if (error) throw error;
      if (!data || data.length === 0) {
        throw new Error("Permessi insufficienti: nessuna modifica salvata.");
      }
    },
    onSuccess: () => {
      toast({ title: "Codice agente rimosso", description: "L'utente resta in Gestione Utenti." });
      qc.invalidateQueries({ queryKey: ["agents_from_profiles"] });
      setRemoveId(null);
    },
    onError: (e: any) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });


  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return agents;
    return agents.filter((a) =>
      [a.agent_code, a.full_name, a.email, a.order_email, a.phone_number, a.price_list_code]
        .some((v) => v?.toLowerCase().includes(q)),
    );
  }, [agents, search]);

  const startNewAgent = () => {
    const u = nonAgents.find((x: any) => x.id === pickedUserId);
    if (!u) return;
    setPickerOpen(false);
    setPickedUserId("");
    setEditing({
      id: u.id,
      user_id: u.user_id,
      full_name: u.full_name ?? "",
      agent_code: "",
      order_email: u.email ?? "",
      phone_number: "",
      price_list_code: "",
    });
  };

  if (!visible) {
    return (
      <div className="p-6 text-sm text-muted-foreground">
        Non hai i permessi per visualizzare questa sezione.
      </div>
    );
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center gap-3">
        <UserCheck className="h-6 w-6 text-primary" />
        <div className="flex-1">
          <h1 className="text-2xl font-bold">Agenti</h1>
          <p className="text-sm text-muted-foreground">
            Utenti di Gestione Utenti con un codice agente assegnato.
          </p>
        </div>
        {canEdit && (
          <Button onClick={() => setPickerOpen(true)}>
            <Plus className="h-4 w-4 mr-2" /> Assegna codice agente
          </Button>
        )}
      </div>

      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cerca per codice, nome, email…"
            className="pl-9"
          />
        </div>
        <Badge variant="outline" className="ml-auto">
          {filtered.length} agenti
        </Badge>
      </div>

      <div className="rounded-lg border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="text-left px-3 py-2 font-medium w-24">Codice</th>
              <th className="text-left px-3 py-2 font-medium">Nome</th>
              <th className="text-left px-3 py-2 font-medium">Email</th>
              <th className="text-left px-3 py-2 font-medium">Email Ordini</th>
              <th className="text-left px-3 py-2 font-medium">Telefono</th>
              <th className="text-left px-3 py-2 font-medium w-24">Listino</th>
              <th className="text-right px-3 py-2 font-medium w-28">Azioni</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={7} className="text-center py-12 text-muted-foreground">
                <Loader2 className="h-5 w-5 animate-spin inline" />
              </td></tr>
            ) : filtered.length === 0 ? (
              <tr><td colSpan={7} className="text-center py-12 text-muted-foreground">
                Nessun agente.
              </td></tr>
            ) : (
              filtered.map((a) => (
                <tr key={a.id} className="border-t hover:bg-muted/30">
                  <td className="px-3 py-2 font-mono text-xs">{a.agent_code}</td>
                  <td className="px-3 py-2">
                    <div className="flex items-center gap-2">
                      <span>{a.full_name ?? "—"}</span>
                      {alsoCustomerIds.has(a.user_id) && (
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">anche cliente</Badge>
                      )}
                    </div>
                  </td>
                  <td className="px-3 py-2 text-xs">{a.email ?? "—"}</td>
                  <td className="px-3 py-2 text-xs">{a.order_email ?? "—"}</td>
                  <td className="px-3 py-2 text-xs">{a.phone_number ?? "—"}</td>
                  <td className="px-3 py-2 font-mono text-xs">{a.price_list_code ?? "—"}</td>
                  <td className="px-3 py-2 text-right">
                    {canEdit && (
                      <Button size="icon" variant="ghost" onClick={() => setEditing({
                        id: a.id,
                        user_id: a.user_id,
                        full_name: a.full_name ?? "",
                        agent_code: a.agent_code ?? "",
                        order_email: a.order_email ?? "",
                        phone_number: a.phone_number ?? "",
                        price_list_code: a.price_list_code ?? "",
                      })}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                    )}
                    {canRemove && (
                      <Button size="icon" variant="ghost" onClick={() => setRemoveId(a.id)} title="Rimuovi codice agente">
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Picker utente per nuovo agente */}
      <Dialog open={pickerOpen} onOpenChange={setPickerOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Assegna codice agente</DialogTitle>
            <DialogDescription>
              Seleziona un utente esistente. Per creare un nuovo utente vai in <strong>Admin → Gestione Utenti</strong>.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label>Utente</Label>
            <Select value={pickedUserId} onValueChange={setPickedUserId}>
              <SelectTrigger><SelectValue placeholder="Seleziona utente…" /></SelectTrigger>
              <SelectContent>
                {nonAgents.map((u: any) => (
                  <SelectItem key={u.id} value={u.id}>
                    {u.full_name || u.email || u.user_id}
                  </SelectItem>
                ))}
                {nonAgents.length === 0 && (
                  <div className="px-2 py-1.5 text-xs text-muted-foreground">
                    Tutti gli utenti hanno già un codice agente.
                  </div>
                )}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setPickerOpen(false); setPickedUserId(""); }}>Annulla</Button>
            <Button onClick={startNewAgent} disabled={!pickedUserId}>Continua</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Editor dati agente */}
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Dati agente</DialogTitle>
            <DialogDescription>I dati vengono salvati sul profilo dell'utente.</DialogDescription>
          </DialogHeader>
          {editing && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Codice agente *</Label>
                  <Input
                    value={editing.agent_code}
                    onChange={(e) => setEditing({ ...editing, agent_code: e.target.value })}
                    maxLength={20}
                  />
                </div>
                <div>
                  <Label>Cod. Listino</Label>
                  <Input
                    value={editing.price_list_code}
                    onChange={(e) => setEditing({ ...editing, price_list_code: e.target.value })}
                    maxLength={10}
                  />
                </div>
              </div>
              <div>
                <Label>Nome completo</Label>
                <Input
                  value={editing.full_name}
                  onChange={(e) => setEditing({ ...editing, full_name: e.target.value })}
                />
              </div>
              <div>
                <Label>Email invio ordini</Label>
                <Input
                  type="email"
                  value={editing.order_email}
                  onChange={(e) => setEditing({ ...editing, order_email: e.target.value })}
                />
              </div>
              <div>
                <Label>Telefono</Label>
                <Input
                  value={editing.phone_number}
                  onChange={(e) => setEditing({ ...editing, phone_number: e.target.value })}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Annulla</Button>
            <Button
              onClick={() => editing && saveMut.mutate(editing)}
              disabled={saveMut.isPending}
            >
              {saveMut.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Salva
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!removeId} onOpenChange={(o) => !o && setRemoveId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Rimuovere il codice agente?</AlertDialogTitle>
            <AlertDialogDescription>
              L'utente resta in Gestione Utenti, ma non sarà più considerato un agente. Verranno svuotati codice, listino ed email ordini.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => removeId && removeMut.mutate(removeId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Rimuovi
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

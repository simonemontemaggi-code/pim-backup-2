import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";
import { Search, UserPlus, Pencil, Users } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { usePermissions } from "@/lib/permissions";
import AgentCustomerManager from "@/components/admin/AgentCustomerManager";
import DepartmentSubUsersTab from "@/components/admin/DepartmentSubUsersTab";

export default function AdminUsersPage() {
  const { user: currentUser } = useAuth();
  const queryClient = useQueryClient();
  const { can, sectionVisible } = usePermissions();
  const showAgentTab = sectionVisible("users_admin") && can("write", "users_admin");
  const [search, setSearch] = useState("");
  const [filterDept, setFilterDept] = useState("all");
  const [editUser, setEditUser] = useState<any>(null);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [inviteForm, setInviteForm] = useState({ email: "", full_name: "", department_id: "", role: "viewer", password: "" });
  const [inviting, setInviting] = useState(false);

  const { data: departments = [] } = useQuery({
    queryKey: ["departments"],
    queryFn: async () => {
      const { data } = await supabase.from("departments").select("id, name").order("name");
      return data ?? [];
    },
  });

  const { data: allUsers = [], isLoading } = useQuery({
    queryKey: ["admin_users"],
    queryFn: async () => {
      const { data: profiles } = await supabase.from("profiles").select("*").order("full_name");
      const { data: roles } = await supabase.from("user_roles").select("user_id, role");
      const { data: userDepts } = await supabase.from("user_departments").select("user_id, department_id, is_primary");

      const roleMap: Record<string, string> = {};
      (roles ?? []).forEach((r: any) => { roleMap[r.user_id] = r.role; });

      const deptMap: Record<string, string> = {};
      (userDepts ?? []).forEach((d: any) => { if (d.is_primary) deptMap[d.user_id] = d.department_id; });

      return (profiles ?? []).map((p: any) => ({
        ...p,
        role: roleMap[p.user_id] ?? "viewer",
        primary_department_id: deptMap[p.user_id] ?? p.department_id,
      }));
    },
  });

  // Client-side filtering (no re-fetch on every keystroke)
  const users = allUsers.filter((u: any) => {
    if (search) {
      const s = search.toLowerCase();
      if (!u.full_name?.toLowerCase().includes(s) && !u.email?.toLowerCase().includes(s)) return false;
    }
    if (filterDept !== "all" && u.primary_department_id !== filterDept) return false;
    return true;
  });

  const getDeptName = (id: string | null) => departments.find((d: any) => d.id === id)?.name ?? "—";

  const handleSaveUser = async () => {
    if (!editUser) return;
    const isOwnAccount = editUser.user_id === currentUser?.id;
    const nextEmail = String(editUser.email ?? "").trim().toLowerCase();

    if (!nextEmail) {
      toast({ title: "Email login obbligatoria", variant: "destructive" });
      return;
    }

    if (nextEmail !== String(editUser.original_email ?? "").trim().toLowerCase()) {
      if (!editUser.user_id) {
        toast({ title: "Utente senza account di login", description: "Impossibile modificare l'email di accesso.", variant: "destructive" });
        return;
      }

      const { error } = await supabase.functions.invoke("admin-update-user-email", {
        body: { user_id: editUser.user_id, email: nextEmail, new_email: nextEmail },
      });

      if (error) {
        let detail = error.message;
        const ctx = (error as any)?.context;
        try {
          if (ctx && typeof ctx.json === "function") {
            const payload = await ctx.clone().json();
            if (payload?.error) detail = typeof payload.error === "string" ? payload.error : JSON.stringify(payload.error);
          }
        } catch { /* keep default message */ }
        toast({ title: "Errore modifica email login", description: detail, variant: "destructive" });
        return;
      }
    }

    if (!isOwnAccount) {
      await supabase.from("user_roles").update({ role: editUser.role } as any).eq("user_id", editUser.user_id);
    }

    if (editUser.primary_department_id) {
      const { data: existing } = await supabase.from("user_departments").select("id").eq("user_id", editUser.user_id).eq("is_primary", true);
      if (existing && existing.length > 0) {
        await supabase.from("user_departments").update({ department_id: editUser.primary_department_id } as any).eq("id", existing[0].id);
      }
      await supabase.from("profiles").update({ department_id: editUser.primary_department_id } as any).eq("user_id", editUser.user_id);
    }

    if (editUser.full_name) {
      await supabase.from("profiles").update({ full_name: editUser.full_name } as any).eq("user_id", editUser.user_id);
    }

    queryClient.invalidateQueries({ queryKey: ["admin_users"] });
    setEditUser(null);
    toast({ title: "Utente aggiornato ✅" });
  };

  const handleInvite = async () => {
    const email = inviteForm.email.trim().toLowerCase();
    const password = inviteForm.password;
    if (!email) { toast({ title: "Email obbligatoria", variant: "destructive" }); return; }
    if (password.length < 6) { toast({ title: "Password troppo corta (min 6)", variant: "destructive" }); return; }

    setInviting(true);
    const { error } = await supabase.functions.invoke("admin-create-user", {
      body: {
        email,
        password,
        full_name: inviteForm.full_name.trim(),
        department_id: inviteForm.department_id || null,
        role: inviteForm.role,
      },
    });
    setInviting(false);

    if (error) {
      toast({ title: "Errore creazione utente", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Utente creato ✅", description: `${email} — password: ${password}` });
    setInviteOpen(false);
    setInviteForm({ email: "", full_name: "", department_id: "", role: "viewer", password: "" });
    queryClient.invalidateQueries({ queryKey: ["admin_users"] });
  };

  if (isLoading) return <div className="p-6"><Skeleton className="h-64 w-full" /></div>;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Gestione Utenti</h1>
        <Button onClick={() => setInviteOpen(true)}><UserPlus className="mr-2 h-4 w-4" /> Invita Utente</Button>
      </div>

      <Tabs defaultValue="users">
        <TabsList>
          <TabsTrigger value="users">Utenti</TabsTrigger>
          <TabsTrigger value="subusers">Sotto-utenti reparto</TabsTrigger>
          {showAgentTab && <TabsTrigger value="agents">Agenti & Clienti</TabsTrigger>}
        </TabsList>

        <TabsContent value="users" className="space-y-6 mt-4">
          <div className="flex gap-3 flex-wrap items-center">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input className="pl-8 w-64" placeholder="Cerca nome o email..." value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            <Select value={filterDept} onValueChange={setFilterDept}>
              <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tutti i reparti</SelectItem>
                {departments.map((d: any) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Reparto</TableHead>
                <TableHead>Ruolo</TableHead>
                <TableHead>Azioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.length === 0 ? (
                <TableRow><TableCell colSpan={5} className="text-center py-8">
                  <Users className="mx-auto h-8 w-8 text-muted-foreground/30 mb-2" />
                  <p className="text-sm text-muted-foreground">Nessun utente trovato</p>
                </TableCell></TableRow>
              ) : users.map((u: any) => (
                <TableRow key={u.user_id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                        {(u.full_name ?? u.email ?? "?").substring(0, 2).toUpperCase()}
                      </div>
                      {u.full_name || "—"}
                    </div>
                  </TableCell>
                  <TableCell className="text-sm">{u.email}</TableCell>
                  <TableCell><Badge variant="outline">{getDeptName(u.primary_department_id)}</Badge></TableCell>
                  <TableCell><Badge className={u.role === "admin" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}>{u.role}</Badge></TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setEditUser({ ...u, original_email: u.email })}>
                      <Pencil className="h-3 w-3" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>

        <TabsContent value="subusers" className="mt-4">
          <DepartmentSubUsersTab />
        </TabsContent>

        {showAgentTab && (
          <TabsContent value="agents" className="mt-4">
            <AgentCustomerManager />
          </TabsContent>
        )}
      </Tabs>


      {/* Edit Dialog */}
      <Dialog open={!!editUser} onOpenChange={(o) => !o && setEditUser(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Modifica Utente</DialogTitle></DialogHeader>
          {editUser && (
            <div className="space-y-4">
              <div>
                <Label>Nome completo</Label>
                <Input value={editUser.full_name ?? ""} onChange={(e) => setEditUser({ ...editUser, full_name: e.target.value })} />
              </div>
              <div>
                <Label>Email login</Label>
                <Input
                  type="email"
                  value={editUser.email ?? ""}
                  onChange={(e) => setEditUser({ ...editUser, email: e.target.value })}
                />
              </div>
              <div>
                <Label>Reparto</Label>
                <Select value={editUser.primary_department_id ?? ""} onValueChange={(v) => setEditUser({ ...editUser, primary_department_id: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {departments.map((d: any) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              {editUser.user_id !== currentUser?.id && (
                <div>
                  <Label>Ruolo</Label>
                  <Select value={editUser.role} onValueChange={(v) => setEditUser({ ...editUser, role: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">Admin</SelectItem>
                      <SelectItem value="manager">Manager</SelectItem>
                      <SelectItem value="assistant_manager">Assistant Manager</SelectItem>
                      <SelectItem value="collaborator">Collaborator</SelectItem>
                      <SelectItem value="viewer">Viewer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div className="border-t pt-4 space-y-2">
                <Label>Imposta password temporanea</Label>
                <div className="flex gap-2">
                  <Input
                    type="text"
                    placeholder="Min 6 caratteri"
                    value={editUser.temp_password ?? ""}
                    onChange={(e) => setEditUser({ ...editUser, temp_password: e.target.value })}
                  />
                  <Button
                    variant="secondary"
                    onClick={async () => {
                      const pwd = String(editUser.temp_password ?? "");
                      if (pwd.length < 6) {
                        toast({ title: "Password troppo corta (min 6)", variant: "destructive" });
                        return;
                      }
                      const { error } = await supabase.functions.invoke("admin-set-user-password", {
                        body: { user_id: editUser.user_id, password: pwd },
                      });
                      if (error) {
                        toast({ title: "Errore", description: error.message, variant: "destructive" });
                        return;
                      }
                      toast({ title: "Password aggiornata ✅", description: `Comunica: ${pwd}` });
                      setEditUser({ ...editUser, temp_password: "" });
                    }}
                  >
                    Applica
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  L'utente potrà accedere subito con questa password e poi cambiarla dal proprio profilo.
                </p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditUser(null)}>Annulla</Button>
            <Button onClick={handleSaveUser}>Salva</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Invite Dialog */}
      <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Invita Utente</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>Email</Label><Input value={inviteForm.email} onChange={(e) => setInviteForm({ ...inviteForm, email: e.target.value })} /></div>
            <div><Label>Nome completo</Label><Input value={inviteForm.full_name} onChange={(e) => setInviteForm({ ...inviteForm, full_name: e.target.value })} /></div>
            <div>
              <Label>Reparto</Label>
              <Select value={inviteForm.department_id} onValueChange={(v) => setInviteForm({ ...inviteForm, department_id: v })}>
                <SelectTrigger><SelectValue placeholder="Seleziona..." /></SelectTrigger>
                <SelectContent>{departments.map((d: any) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Ruolo</Label>
              <Select value={inviteForm.role} onValueChange={(v) => setInviteForm({ ...inviteForm, role: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="manager">Manager</SelectItem>
                  <SelectItem value="assistant_manager">Assistant Manager</SelectItem>
                  <SelectItem value="collaborator">Collaborator</SelectItem>
                  <SelectItem value="viewer">Viewer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Password iniziale</Label>
              <Input type="text" placeholder="Min 6 caratteri" value={inviteForm.password} onChange={(e) => setInviteForm({ ...inviteForm, password: e.target.value })} />
              <p className="text-xs text-muted-foreground mt-1">L'utente potrà accedere subito e poi cambiarla.</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setInviteOpen(false)}>Annulla</Button>
            <Button onClick={handleInvite} disabled={inviting}>{inviting ? "Creazione…" : "Crea Utente"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

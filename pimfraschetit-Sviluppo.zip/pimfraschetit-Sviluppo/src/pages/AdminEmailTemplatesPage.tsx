import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Eye, Send, Save, Mail, Code2, Info } from "lucide-react";

interface EmailTemplate {
  id: string;
  key: string;
  name: string;
  description: string | null;
  subject: string;
  body_html: string;
  enabled: boolean;
}

const PLACEHOLDERS_BY_KEY: Record<string, { key: string; label: string; sample: string }[]> = {
  order_confirmation_agent: [
    { key: "numero_ordine", label: "Numero ordine", sample: "2000000048" },
    { key: "numero_trasmissione", label: "Numero trasmissione", sample: "2000000048" },
    { key: "data_ordine", label: "Data ordine", sample: "25/05/26, 11:57" },
    { key: "cliente_codice", label: "Codice cliente", sample: "1325" },
    { key: "cliente_ragione_sociale", label: "Ragione sociale cliente", sample: "GULLIFER SRL" },
    { key: "cliente_indirizzo", label: "Indirizzo cliente", sample: "Via Roma 12" },
    { key: "cliente_citta", label: "Città cliente", sample: "Milano MI" },
    { key: "agente_codice", label: "Codice agente", sample: "1325" },
    { key: "agente_nome", label: "Nome agente", sample: "Mauro Casentini" },
    { key: "numero_righe", label: "Numero righe", sample: "8" },
    { key: "totale_ordine", label: "Totale ordine", sample: "172,98 €" },
    { key: "righe_ordine", label: "Tabella righe ordine (HTML)", sample: "[tabella generata automaticamente]" },
    { key: "note", label: "Note ordine", sample: "Consegna mattino" },
    { key: "note_blocco", label: "Blocco note (vuoto se assenti)", sample: "" },
  ],
  untreated_order_request_office: [
    { key: "fornitore", label: "Fornitore", sample: "BOSCH" },
    { key: "codice_articolo_fornitore", label: "Codice articolo fornitore", sample: "AB-1234" },
    { key: "descrizione", label: "Descrizione articolo", sample: "Trapano avvitatore" },
    { key: "quantita", label: "Quantità", sample: "5" },
    { key: "nota", label: "Nota agente", sample: "Cliente lo vuole entro venerdì" },
    { key: "cliente_codice", label: "Codice cliente", sample: "1325" },
    { key: "cliente_nominativo", label: "Nominativo cliente", sample: "GULLIFER SRL" },
    { key: "agente_codice", label: "Codice agente", sample: "1325" },
    { key: "agente_nome_completo", label: "Nome agente", sample: "Casentini Mauro" },
    { key: "data_richiesta", label: "Data richiesta", sample: "17/06/26, 09:30" },
    { key: "link_pim", label: "Link al PIM", sample: "https://pim.fraschetti.com/pim/sales/untreated" },
  ],
  untreated_order_approved_purchases: [
    { key: "fornitore", label: "Fornitore", sample: "BOSCH" },
    { key: "codice_articolo_fornitore", label: "Codice articolo fornitore", sample: "AB-1234" },
    { key: "descrizione", label: "Descrizione articolo", sample: "Trapano avvitatore" },
    { key: "quantita", label: "Quantità", sample: "5" },
    { key: "nota", label: "Nota agente", sample: "Cliente lo vuole entro venerdì" },
    { key: "cliente_codice", label: "Codice cliente", sample: "1325" },
    { key: "cliente_nominativo", label: "Nominativo cliente", sample: "GULLIFER SRL" },
    { key: "agente_codice", label: "Codice agente", sample: "1325" },
    { key: "agente_nome_completo", label: "Nome agente", sample: "Casentini Mauro" },
    { key: "data_richiesta", label: "Data richiesta", sample: "17/06/26, 09:30" },
    { key: "link_pim", label: "Link al PIM", sample: "https://pim.fraschetti.com/pim/sales/untreated" },
  ],
  untreated_order_decision_accettato: [
    { key: "fornitore", label: "Fornitore", sample: "BOSCH" },
    { key: "codice_articolo_fornitore", label: "Codice articolo fornitore", sample: "AB-1234" },
    { key: "descrizione", label: "Descrizione articolo", sample: "Trapano avvitatore" },
    { key: "quantita", label: "Quantità", sample: "5" },
    { key: "nota", label: "Nota agente", sample: "Cliente lo vuole entro venerdì" },
    { key: "preventivo_note", label: "Note preventivo (Acquisti)", sample: "231,07+iva · consegna 20/30 gg" },
    { key: "cliente_codice", label: "Codice cliente", sample: "1325" },
    { key: "cliente_nominativo", label: "Nominativo cliente", sample: "GULLIFER SRL" },
    { key: "agente_codice", label: "Codice agente", sample: "1325" },
    { key: "agente_nome_completo", label: "Nome agente", sample: "Casentini Mauro" },
    { key: "data_richiesta", label: "Data richiesta", sample: "17/06/26, 09:30" },
    { key: "link_pim", label: "Link al PIM", sample: "https://pim.fraschetti.com/pim/sales/untreated" },
  ],
  untreated_order_decision_rifiutato: [
    { key: "fornitore", label: "Fornitore", sample: "BOSCH" },
    { key: "codice_articolo_fornitore", label: "Codice articolo fornitore", sample: "AB-1234" },
    { key: "descrizione", label: "Descrizione articolo", sample: "Trapano avvitatore" },
    { key: "quantita", label: "Quantità", sample: "5" },
    { key: "nota", label: "Nota agente", sample: "Cliente lo vuole entro venerdì" },
    { key: "preventivo_note", label: "Note preventivo (Acquisti)", sample: "231,07+iva · consegna 20/30 gg" },
    { key: "cliente_codice", label: "Codice cliente", sample: "1325" },
    { key: "cliente_nominativo", label: "Nominativo cliente", sample: "GULLIFER SRL" },
    { key: "agente_codice", label: "Codice agente", sample: "1325" },
    { key: "agente_nome_completo", label: "Nome agente", sample: "Casentini Mauro" },
    { key: "data_richiesta", label: "Data richiesta", sample: "17/06/26, 09:30" },
    { key: "link_pim", label: "Link al PIM", sample: "https://pim.fraschetti.com/pim/sales/untreated" },
  ],
  untreated_order_ordine_cliente: [
    { key: "fornitore", label: "Fornitore", sample: "BOSCH" },
    { key: "codice_articolo_fornitore", label: "Codice articolo fornitore", sample: "AB-1234" },
    { key: "descrizione", label: "Descrizione articolo", sample: "Trapano avvitatore" },
    { key: "quantita", label: "Quantità", sample: "5" },
    { key: "nota", label: "Nota agente", sample: "Cliente lo vuole entro venerdì" },
    { key: "preventivo_note", label: "Note preventivo (Acquisti)", sample: "231,07+iva · consegna 20/30 gg" },
    { key: "cdpar_codificato", label: "Cdpar codificato", sample: "123456" },
    { key: "ordine_cliente_ref", label: "Rif. ordine cliente", sample: "2026/ORD-1234" },
    { key: "cliente_codice", label: "Codice cliente", sample: "1325" },
    { key: "cliente_nominativo", label: "Nominativo cliente", sample: "GULLIFER SRL" },
    { key: "agente_codice", label: "Codice agente", sample: "1325" },
    { key: "agente_nome_completo", label: "Nome agente", sample: "Casentini Mauro" },
    { key: "data_richiesta", label: "Data richiesta", sample: "17/06/26, 09:30" },
    { key: "link_pim", label: "Link al PIM", sample: "https://pim.fraschetti.com/pim/sales/untreated" },
  ],
  untreated_order_ordine_fornitore: [
    { key: "fornitore", label: "Fornitore", sample: "BOSCH" },
    { key: "codice_articolo_fornitore", label: "Codice articolo fornitore", sample: "AB-1234" },
    { key: "descrizione", label: "Descrizione articolo", sample: "Trapano avvitatore" },
    { key: "quantita", label: "Quantità", sample: "5" },
    { key: "nota", label: "Nota agente", sample: "Cliente lo vuole entro venerdì" },
    { key: "preventivo_note", label: "Note preventivo (Acquisti)", sample: "231,07+iva · consegna 20/30 gg" },
    { key: "cdpar_codificato", label: "Cdpar codificato", sample: "123456" },
    { key: "ordine_cliente_ref", label: "Rif. ordine cliente", sample: "2026/ORD-1234" },
    { key: "cliente_codice", label: "Codice cliente", sample: "1325" },
    { key: "cliente_nominativo", label: "Nominativo cliente", sample: "GULLIFER SRL" },
    { key: "agente_codice", label: "Codice agente", sample: "1325" },
    { key: "agente_nome_completo", label: "Nome agente", sample: "Casentini Mauro" },
    { key: "data_richiesta", label: "Data richiesta", sample: "17/06/26, 09:30" },
    { key: "link_pim", label: "Link al PIM", sample: "https://pim.fraschetti.com/pim/sales/untreated" },
  ],
  untreated_order_arrivato: [
    { key: "fornitore", label: "Fornitore", sample: "BOSCH" },
    { key: "codice_articolo_fornitore", label: "Codice articolo fornitore", sample: "AB-1234" },
    { key: "descrizione", label: "Descrizione articolo", sample: "Trapano avvitatore" },
    { key: "quantita", label: "Quantità", sample: "5" },
    { key: "nota", label: "Nota agente", sample: "Cliente lo vuole entro venerdì" },
    { key: "preventivo_note", label: "Note preventivo (Acquisti)", sample: "231,07+iva · consegna 20/30 gg" },
    { key: "cdpar_codificato", label: "Cdpar codificato", sample: "123456" },
    { key: "ordine_cliente_ref", label: "Rif. ordine cliente", sample: "2026/ORD-1234" },
    { key: "cliente_codice", label: "Codice cliente", sample: "1325" },
    { key: "cliente_nominativo", label: "Nominativo cliente", sample: "GULLIFER SRL" },
    { key: "agente_codice", label: "Codice agente", sample: "1325" },
    { key: "agente_nome_completo", label: "Nome agente", sample: "Casentini Mauro" },
    { key: "data_richiesta", label: "Data richiesta", sample: "17/06/26, 09:30" },
    { key: "link_pim", label: "Link al PIM", sample: "https://pim.fraschetti.com/pim/sales/untreated" },
  ],
};
const PLACEHOLDERS_DEFAULT = PLACEHOLDERS_BY_KEY.order_confirmation_agent;

const B2B_TICKET_PLACEHOLDERS = [
  { key: "categoria", label: "Categoria ticket", sample: "Amministrazione" },
  { key: "oggetto", label: "Oggetto", sample: "Fattura non ricevuta" },
  { key: "messaggio", label: "Messaggio cliente", sample: "Buongiorno, non ho ricevuto la fattura di aprile..." },
  { key: "codice_cliente", label: "Codice cliente", sample: "1325" },
  { key: "ragione_sociale", label: "Ragione sociale", sample: "GULLIFER SRL" },
  { key: "email_contatto", label: "Email contatto cliente", sample: "info@gullifer.it" },
  { key: "data_invio", label: "Data invio", sample: "08/07/26, 09:30" },
  { key: "link_pim", label: "Link al PIM", sample: "https://pim.fraschetti.com/pim/b2b/tickets" },
];
const B2B_TICKET_CATEGORIES: { key: string; label: string }[] = [
  { key: "ordini", label: "Ordini" },
  { key: "contabile", label: "Amministrazione" },
  { key: "tecnico", label: "Supporto tecnico" },
  { key: "commerciale", label: "Commerciale" },
  { key: "annullamento_ordine", label: "Annullamento ordine" },
  { key: "post_vendita", label: "Assistenza Post Vendita" },
  { key: "portale", label: "Assistenza Portale" },
  { key: "altro", label: "Altro" },
];
for (const c of B2B_TICKET_CATEGORIES) {
  PLACEHOLDERS_BY_KEY[`b2b_ticket_${c.key}`] = B2B_TICKET_PLACEHOLDERS;
}

function renderPreview(template: string, placeholders: { key: string; sample: string }[]) {
  const sample: Record<string, string> = Object.fromEntries(placeholders.map(p => [p.key, p.sample]));
  if ("righe_ordine" in sample) {
    sample.righe_ordine = `<table style="width:100%;border-collapse:collapse;font-size:13px;border:1px solid #e2e8f0;border-radius:6px;overflow:hidden">
      <thead><tr style="background:#f1f5f9;color:#475569">
        <th style="padding:8px;text-align:left">Art.</th><th style="padding:8px;text-align:left">Descrizione</th>
        <th style="padding:8px;text-align:right">Qty</th><th style="padding:8px;text-align:right">Prezzo</th>
        <th style="padding:8px;text-align:center">Sc.</th><th style="padding:8px;text-align:right">Totale</th>
      </tr></thead><tbody>
      <tr><td style="padding:6px 8px;border-bottom:1px solid #e2e8f0;font-family:monospace">123456</td><td style="padding:6px 8px;border-bottom:1px solid #e2e8f0">Articolo dimostrativo</td><td style="padding:6px 8px;border-bottom:1px solid #e2e8f0;text-align:right">10</td><td style="padding:6px 8px;border-bottom:1px solid #e2e8f0;text-align:right">12,50 €</td><td style="padding:6px 8px;border-bottom:1px solid #e2e8f0;text-align:center;color:#64748b">5,00%</td><td style="padding:6px 8px;border-bottom:1px solid #e2e8f0;text-align:right"><strong>118,75 €</strong></td></tr>
      </tbody></table>`;
  }
  if ("note_blocco" in sample) {
    sample.note_blocco = `<div style="margin-top:16px;padding:12px;background:#f8fafc;border-left:3px solid #2563eb;border-radius:4px"><strong>Note:</strong> Consegna mattino</div>`;
  }
  return template.replace(/\{\{(\w+)\}\}/g, (_, k) => sample[k] ?? "");
}

export default function AdminEmailTemplatesPage() {
  const qc = useQueryClient();
  const [selectedKey, setSelectedKey] = useState<string>("order_confirmation_agent");
  const [draft, setDraft] = useState<Partial<EmailTemplate> | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [testOpen, setTestOpen] = useState(false);
  const [testEmail, setTestEmail] = useState("");
  const [testOrderId, setTestOrderId] = useState<string>("");
  const [sending, setSending] = useState(false);

  const { data: templates = [] } = useQuery({
    queryKey: ["email_templates"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("email_templates")
        .select("*")
        .order("name");
      if (error) throw error;
      return data as EmailTemplate[];
    },
  });

  const current = templates.find(t => t.key === selectedKey);
  const placeholders = PLACEHOLDERS_BY_KEY[selectedKey] ?? PLACEHOLDERS_DEFAULT;

  useEffect(() => {
    if (current) setDraft({ ...current });
  }, [current?.id]);

  const isUntreated = selectedKey === "untreated_order_request_office";
  const isApproved = selectedKey === "untreated_order_approved_purchases";
  const isDecision = selectedKey === "untreated_order_decision_accettato" || selectedKey === "untreated_order_decision_rifiutato";
  const isOrdineCliente = selectedKey === "untreated_order_ordine_cliente";
  const isOrdineFornitore = selectedKey === "untreated_order_ordine_fornitore";
  const isArrivato = selectedKey === "untreated_order_arrivato";
  const decisionValue: "accettato" | "rifiutato" | null =
    selectedKey === "untreated_order_decision_accettato" ? "accettato"
    : selectedKey === "untreated_order_decision_rifiutato" ? "rifiutato"
    : null;
  const isUntreatedFlow = isUntreated || isApproved || isDecision || isOrdineCliente || isOrdineFornitore || isArrivato;
  const isB2bTicket = selectedKey.startsWith("b2b_ticket_");
  const b2bTicketCategory = isB2bTicket ? selectedKey.replace("b2b_ticket_", "") : null;
  const hasRecipientsBlock = isUntreatedFlow || isB2bTicket;

  const { data: recentOrders = [] } = useQuery({
    queryKey: ["recent_orders_for_test"],
    queryFn: async () => {
      const { data: orders } = await supabase
        .from("customer_orders")
        .select("id,transmission_id,codice_cliente,codice_agente,total,created_at")
        .order("created_at", { ascending: false })
        .limit(20);
      const list = orders ?? [];
      const custCodes = Array.from(new Set(list.map((o: any) => o.codice_cliente).filter(Boolean)));
      const agentCodes = Array.from(new Set(list.map((o: any) => o.codice_agente).filter(Boolean)));
      const [{ data: customers = [] }, { data: agents = [] }] = await Promise.all([
        custCodes.length
          ? supabase.from("customers").select("customer_code,company_name").in("customer_code", custCodes as string[])
          : Promise.resolve({ data: [] as any[] }),
        agentCodes.length
          ? supabase.from("profiles").select("agent_code,full_name").in("agent_code", agentCodes as string[])
          : Promise.resolve({ data: [] as any[] }),
      ]);
      const cMap = new Map((customers ?? []).map((c: any) => [c.customer_code, c.company_name]));
      const aMap = new Map((agents ?? []).map((a: any) => [a.agent_code, a.full_name]));
      return list.map((o: any) => ({
        ...o,
        company_name: cMap.get(o.codice_cliente) ?? "—",
        agent_name: aMap.get(o.codice_agente) ?? "—",
      }));
    },
    enabled: testOpen && !isUntreatedFlow && !isB2bTicket,
  });

  const { data: recentUntreated = [] } = useQuery({
    queryKey: ["recent_untreated_for_test"],
    queryFn: async () => {
      const { data } = await supabase
        .from("richieste_ordini_non_trattati")
        .select("id,fornitore,codice_articolo_fornitore,descrizione,cliente_nominativo,agente_cognome,agente_nome,created_at")
        .order("created_at", { ascending: false })
        .limit(20);
      return data ?? [];
    },
    enabled: testOpen && isUntreatedFlow,
  });

  const { data: recentTickets = [] } = useQuery({
    queryKey: ["recent_b2b_tickets_for_test", b2bTicketCategory],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("customer_support_tickets")
        .select("id,subject,category,contact_email,created_at,customer_id")
        .eq("category", b2bTicketCategory as string)
        .order("created_at", { ascending: false })
        .limit(20);
      if (error) {
        console.error("recent_b2b_tickets_for_test", error);
        return [];
      }
      const rows = data ?? [];
      const ids = Array.from(new Set(rows.map((t: any) => t.customer_id).filter(Boolean)));
      let custMap: Record<string, { customer_code: string | null; company_name: string | null }> = {};
      if (ids.length > 0) {
        const { data: custs, error: cErr } = await supabase
          .from("customers")
          .select("id,customer_code,company_name")
          .in("id", ids as string[]);
        if (cErr) console.error("recent_b2b_tickets_for_test customers", cErr);
        for (const c of custs ?? []) {
          custMap[(c as any).id] = {
            customer_code: (c as any).customer_code ?? null,
            company_name: (c as any).company_name ?? null,
          };
        }
      }
      return rows.map((t: any) => ({
        id: t.id,
        subject: t.subject,
        category: t.category,
        contact_email: t.contact_email,
        created_at: t.created_at,
        customer_code: custMap[t.customer_id]?.customer_code ?? null,
        company_name: custMap[t.customer_id]?.company_name ?? null,
      }));
    },
    enabled: testOpen && isB2bTicket && !!b2bTicketCategory,
  });


  /* ── Destinatari + CC configurabili ────── */
  const RECIP_KEY = isB2bTicket
    ? `email_recipients_${selectedKey}`
    : isArrivato
    ? "email_recipients_untreated_arrivato"
    : isOrdineFornitore
    ? "email_recipients_untreated_ordine_fornitore"
    : isOrdineCliente
    ? "email_recipients_untreated_ordine_cliente"
    : isDecision
    ? "email_recipients_untreated_decision"
    : isApproved
      ? "email_recipients_untreated_approved"
      : "email_recipients_untreated_orders";
  const CC_KEY = isArrivato
    ? "email_cc_untreated_arrivato"
    : isOrdineFornitore
    ? "email_cc_untreated_ordine_fornitore"
    : isOrdineCliente
    ? "email_cc_untreated_ordine_cliente"
    : isDecision
    ? "email_cc_untreated_decision"
    : isApproved
      ? "email_cc_untreated_approved"
      : "email_cc_untreated_orders";

  const { data: untreatedRecipSetting, isLoading: isLoadingUntreatedRecip } = useQuery({
    queryKey: ["app_settings", RECIP_KEY],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings").select("*")
        .eq("setting_key", RECIP_KEY).maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: hasRecipientsBlock,
  });
  const savedUntreatedRecip: string = (() => {
    const v = untreatedRecipSetting?.setting_value;
    if (!v) return "";
    if (typeof v === "string") return v;
    try { return String(v); } catch { return ""; }
  })();
  const [untreatedRecip, setUntreatedRecip] = useState<string>("");
  useEffect(() => {
    if (!isLoadingUntreatedRecip) setUntreatedRecip(savedUntreatedRecip);
  }, [isLoadingUntreatedRecip, savedUntreatedRecip]);
  const untreatedDirty = untreatedRecip.trim() !== savedUntreatedRecip.trim();

  const untreatedRecipMutation = useMutation({
    mutationFn: async (value: string) => {
      if (untreatedRecipSetting?.id) {
        const { error } = await supabase.from("app_settings")
          .update({ setting_value: value as any, updated_at: new Date().toISOString() })
          .eq("id", untreatedRecipSetting.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("app_settings")
          .insert({ setting_key: RECIP_KEY, setting_value: value as any });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast({ title: "Salvato", description: "Destinatari aggiornati." });
      qc.invalidateQueries({ queryKey: ["app_settings", RECIP_KEY] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const { data: untreatedCcSetting, isLoading: isLoadingUntreatedCc } = useQuery({
    queryKey: ["app_settings", CC_KEY],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings").select("*")
        .eq("setting_key", CC_KEY).maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: isUntreatedFlow, // CC solo per ordini non trattati
  });
  const savedUntreatedCc: string = (() => {
    const v = untreatedCcSetting?.setting_value;
    if (!v) return "";
    if (typeof v === "string") return v;
    try { return String(v); } catch { return ""; }
  })();
  const [untreatedCc, setUntreatedCc] = useState<string>("");
  useEffect(() => {
    if (!isLoadingUntreatedCc) setUntreatedCc(savedUntreatedCc);
  }, [isLoadingUntreatedCc, savedUntreatedCc]);
  const untreatedCcDirty = untreatedCc.trim() !== savedUntreatedCc.trim();

  const untreatedCcMutation = useMutation({
    mutationFn: async (value: string) => {
      if (untreatedCcSetting?.id) {
        const { error } = await supabase.from("app_settings")
          .update({ setting_value: value as any, updated_at: new Date().toISOString() })
          .eq("id", untreatedCcSetting.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("app_settings")
          .insert({ setting_key: CC_KEY, setting_value: value as any });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast({ title: "Salvato", description: "CC aggiornati." });
      qc.invalidateQueries({ queryKey: ["app_settings", CC_KEY] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const saveMut = useMutation({
    mutationFn: async () => {
      if (!draft?.id) throw new Error("Nessun template");
      const { error } = await supabase
        .from("email_templates")
        .update({
          subject: draft.subject,
          body_html: draft.body_html,
          description: draft.description,
          enabled: draft.enabled,
          updated_by: (await supabase.auth.getUser()).data.user?.id,
        })
        .eq("id", draft.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Template salvato" });
      qc.invalidateQueries({ queryKey: ["email_templates"] });
    },
    onError: (e: any) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  async function sendTest() {
    if (!testEmail || !testOrderId) {
      toast({ title: "Compila email e record di test", variant: "destructive" });
      return;
    }
    setSending(true);
    try {
      const fnName = isB2bTicket
        ? "send-b2b-ticket-email"
        : isArrivato
        ? "send-untreated-order-arrivato-email"
        : isOrdineFornitore
        ? "send-untreated-order-ordine-fornitore-email"
        : isOrdineCliente
        ? "send-untreated-order-ordine-cliente-email"
        : isDecision
        ? "send-untreated-order-decision-email"
        : isApproved
          ? "send-untreated-order-approved-email"
          : isUntreated
            ? "send-untreated-order-request-email"
            : "send-order-confirmation-email";
      const body = isB2bTicket
        ? { ticket_id: testOrderId, test: true, override_email: testEmail, template_override: { subject: draft?.subject, body_html: draft?.body_html } }
        : isDecision
        ? { request_id: testOrderId, decision: decisionValue, test: true, override_email: testEmail, template_override: { subject: draft?.subject, body_html: draft?.body_html } }
        : isUntreatedFlow
        ? { request_id: testOrderId, test: true, override_email: testEmail, template_override: { subject: draft?.subject, body_html: draft?.body_html } }
        : { order_id: testOrderId, test: true, override_email: testEmail, template_override: { subject: draft?.subject, body_html: draft?.body_html } };
      const { data, error } = await supabase.functions.invoke(fnName, { body });
      if (error) throw error;
      if ((data as any)?.error) throw new Error((data as any).error);
      toast({ title: "Mail di test inviata", description: `A ${testEmail}` });
      setTestOpen(false);
    } catch (e: any) {
      toast({ title: "Invio fallito", description: e.message, variant: "destructive" });
    } finally {
      setSending(false);
    }
  }

  function insertPlaceholder(p: string) {
    const ta = document.getElementById("body_html_editor") as HTMLTextAreaElement | null;
    if (!ta || !draft) return;
    const start = ta.selectionStart, end = ta.selectionEnd;
    const before = (draft.body_html ?? "").slice(0, start);
    const after = (draft.body_html ?? "").slice(end);
    const insert = `{{${p}}}`;
    setDraft({ ...draft, body_html: before + insert + after });
    setTimeout(() => { ta.focus(); ta.selectionStart = ta.selectionEnd = start + insert.length; }, 0);
  }

  if (!draft) return <div className="p-6 text-muted-foreground">Caricamento...</div>;

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold flex items-center gap-2"><Mail className="h-6 w-6" /> Template Email</h1>
          <p className="text-sm text-muted-foreground">Gestisci il testo delle mail automatiche del sistema.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setPreviewOpen(true)}><Eye className="mr-2 h-4 w-4" />Anteprima</Button>
          <Button variant="outline" onClick={() => setTestOpen(true)}><Send className="mr-2 h-4 w-4" />Invia Test</Button>
          <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}><Save className="mr-2 h-4 w-4" />Salva</Button>
        </div>
      </div>

      <div className="grid grid-cols-[260px_1fr_280px] gap-4">
        {/* Template list */}
        <Card className="p-3 space-y-3">
          {(() => {
            const GROUPS: { label: string; keys: string[] }[] = [
              { label: "Clienti", keys: ["agent_new_customer_request", "agent_new_customer_approved", "agent_new_customer_rejected"] },
              { label: "Ordini", keys: ["order_confirmation_agent"] },
              { label: "Ordini non trattati", keys: ["untreated_order_request_office", "untreated_order_approved_purchases", "untreated_order_decision_accettato", "untreated_order_decision_rifiutato", "untreated_order_ordine_cliente", "untreated_order_ordine_fornitore", "untreated_order_arrivato"] },
              { label: "Ticket B2B", keys: B2B_TICKET_CATEGORIES.map(c => `b2b_ticket_${c.key}`) },
            ];
            const known = new Set(GROUPS.flatMap(g => g.keys));
            const misc = templates
              .filter(t => !known.has(t.key))
              .sort((a, b) => a.name.localeCompare(b.name, "it"));
            const sections = [
              ...GROUPS.map(g => ({
                label: g.label,
                items: g.keys.map(k => templates.find(t => t.key === k)).filter(Boolean) as EmailTemplate[],
              })),
              { label: "Varie", items: misc },
            ].filter(s => s.items.length > 0);
            return sections.map(section => (
              <div key={section.label} className="space-y-1">
                <div className="text-[11px] uppercase tracking-wide text-muted-foreground px-2 pt-1 pb-1 border-b">
                  {section.label}
                </div>
                {section.items.map(t => (
                  <button key={t.id}
                    onClick={() => setSelectedKey(t.key)}
                    className={`w-full text-left px-3 py-2 rounded text-sm hover:bg-accent ${selectedKey === t.key ? "bg-accent font-medium" : ""}`}>
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate">{t.name}</span>
                      {!t.enabled && <Badge variant="outline" className="text-xs">off</Badge>}
                    </div>
                    <div className="text-xs text-muted-foreground font-mono truncate">{t.key}</div>
                  </button>
                ))}
              </div>
            ));
          })()}
        </Card>

        {/* Editor */}
        <Card className="p-4 space-y-4">
          {draft.description && <p className="text-sm text-muted-foreground">{draft.description}</p>}
          <div className="flex items-center gap-3">
            <Switch checked={!!draft.enabled} onCheckedChange={(v) => setDraft({ ...draft, enabled: v })} />
            <Label className="text-sm">Invio automatico attivo</Label>
          </div>
          {hasRecipientsBlock && (
            <div className="space-y-2 rounded-md border border-amber-200 bg-amber-50/50 dark:bg-amber-950/20 dark:border-amber-900/50 p-3">
              <Label className="text-sm font-medium">Destinatari mail</Label>
              <p className="text-xs text-muted-foreground">
                {isB2bTicket
                  ? `Quando un cliente apre un ticket dal Portale B2B in categoria "${B2B_TICKET_CATEGORIES.find(c => c.key === b2bTicketCategory)?.label ?? b2bTicketCategory}", viene inviata una mail a questi indirizzi.`
                  : isArrivato
                  ? "Quando Acquisti segna la merce come Arrivata, viene inviata una mail a questi indirizzi."
                  : isOrdineFornitore
                  ? "Quando Vendite fa avanzare una richiesta da Ordine cliente a Ordine fornitore, viene inviata una mail a questi indirizzi."
                  : isOrdineCliente
                  ? "Quando Vendite fa avanzare una richiesta da Codificato a Ordine cliente, viene inviata una mail a questi indirizzi."
                  : isDecision
                  ? "Quando l'agente accetta o rifiuta un preventivo, viene inviata una mail a questi indirizzi (unico set per Accettato e Rifiutato)."
                  : isApproved
                  ? "Quando le Vendite inoltrano una richiesta ad Acquisti (transizione \"Invia ad Acquisti\"), viene inviata una mail a questi indirizzi."
                  : "Quando un agente inserisce una richiesta di ordine non trattato, viene inviata una mail a questi indirizzi."}
              </p>
              {isLoadingUntreatedRecip ? (
                <p className="text-xs text-muted-foreground">Caricamento...</p>
              ) : (
                <>
                  <Input
                    placeholder="vendite@fraschetti.com, acquisti@fraschetti.com"
                    value={untreatedRecip}
                    onChange={(e) => setUntreatedRecip(e.target.value)}
                  />
                  {untreatedDirty && (
                    <Button size="sm" onClick={() => untreatedRecipMutation.mutate(untreatedRecip.trim())} disabled={untreatedRecipMutation.isPending}>
                      <Save className="h-3.5 w-3.5 mr-1.5" />
                      {untreatedRecipMutation.isPending ? "Salvataggio..." : "Salva destinatari"}
                    </Button>
                  )}

                  {isUntreatedFlow && (
                    <div className="pt-2">
                      <Label className="text-sm font-medium">CC (copia conoscenza)</Label>
                      <p className="text-xs text-muted-foreground mb-1">
                        Indirizzi in copia, separati da virgola. Lascia vuoto per nessun CC.
                      </p>
                      {isLoadingUntreatedCc ? (
                        <p className="text-xs text-muted-foreground">Caricamento...</p>
                      ) : (
                        <>
                          <Input
                            placeholder="responsabile@fraschetti.com, ..."
                            value={untreatedCc}
                            onChange={(e) => setUntreatedCc(e.target.value)}
                          />
                          {untreatedCcDirty && (
                            <Button size="sm" className="mt-2" onClick={() => untreatedCcMutation.mutate(untreatedCc.trim())} disabled={untreatedCcMutation.isPending}>
                              <Save className="h-3.5 w-3.5 mr-1.5" />
                              {untreatedCcMutation.isPending ? "Salvataggio..." : "Salva CC"}
                            </Button>
                          )}
                        </>
                      )}
                    </div>
                  )}

                  {isB2bTicket && b2bTicketCategory === "annullamento_ordine" && (
                    <div className="mt-2 flex gap-2 rounded-md border border-blue-200 bg-blue-50/60 dark:bg-blue-950/20 dark:border-blue-900/50 p-3">
                      <Info className="h-4 w-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                      <div className="text-xs text-blue-900 dark:text-blue-200 leading-relaxed">
                        <div className="font-medium mb-0.5">CC automatico</div>
                        L'agente assegnato al cliente che ha aperto il ticket viene aggiunto automaticamente in CC
                        (via <code className="font-mono">assigned_agent_id</code>, fallback <code className="font-mono">original_agent_code</code>).
                        Non serve configurarlo qui.
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
          <div>
            <Label>Oggetto</Label>
            <Input value={draft.subject ?? ""} onChange={(e) => setDraft({ ...draft, subject: e.target.value })} />
          </div>
          <div>
            <Label className="flex items-center gap-1"><Code2 className="h-3 w-3" />Corpo HTML</Label>
            <Textarea
              id="body_html_editor"
              value={draft.body_html ?? ""}
              onChange={(e) => setDraft({ ...draft, body_html: e.target.value })}
              className="font-mono text-xs min-h-[480px]"
            />
          </div>
        </Card>

        {/* Placeholders */}
        <Card className="p-3 space-y-2">
          <div className="text-xs uppercase text-muted-foreground px-1 py-1">Variabili disponibili</div>
          <p className="text-xs text-muted-foreground px-1">Click per inserire nel cursore.</p>
          <div className="space-y-1">
            {placeholders.map(p => (
              <button key={p.key} onClick={() => insertPlaceholder(p.key)}
                className="w-full text-left px-2 py-1.5 rounded hover:bg-accent text-xs">
                <div className="font-mono text-primary">{`{{${p.key}}}`}</div>
                <div className="text-muted-foreground">{p.label}</div>
              </button>
            ))}
          </div>
        </Card>
      </div>

      {/* Preview */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle>Anteprima · {renderPreview(draft.subject ?? "", placeholders)}</DialogTitle>
          </DialogHeader>
          <div className="border rounded p-2 bg-muted/30">
            <div dangerouslySetInnerHTML={{ __html: renderPreview(draft.body_html ?? "", placeholders) }} />
          </div>
        </DialogContent>
      </Dialog>

      {/* Test */}
      <Dialog open={testOpen} onOpenChange={setTestOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Invia mail di test</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Email destinatario</Label>
              <Input type="email" placeholder="tua@email.com" value={testEmail} onChange={e => setTestEmail(e.target.value)} />
            </div>
            <div>
              <Label>
                {isB2bTicket
                  ? "Usa dati di un ticket B2B recente"
                  : isUntreatedFlow
                  ? "Usa dati di una richiesta non trattata"
                  : "Usa dati dell'ordine"}
              </Label>
              <Select value={testOrderId} onValueChange={setTestOrderId}>
                <SelectTrigger>
                  <SelectValue
                    placeholder={
                      isB2bTicket
                        ? recentTickets.length === 0
                          ? "Nessun ticket in questa categoria"
                          : "Seleziona ticket recente..."
                        : isUntreatedFlow
                        ? "Seleziona richiesta recente..."
                        : "Seleziona ordine recente..."
                    }
                  />
                </SelectTrigger>
                <SelectContent className="max-h-[320px]">
                  {isB2bTicket
                    ? recentTickets.map((t: any) => (
                        <SelectItem key={t.id} value={t.id}>
                          <div className="flex flex-col text-left">
                            <span className="font-medium truncate max-w-[420px]">{t.subject}</span>
                            <span className="text-xs text-muted-foreground">
                              {t.company_name ?? "—"} · {t.customer_code ?? "—"} · {new Date(t.created_at).toLocaleDateString("it-IT")}
                            </span>
                          </div>
                        </SelectItem>
                      ))
                    : isUntreatedFlow
                    ? recentUntreated.map((r: any) => (
                        <SelectItem key={r.id} value={r.id}>
                          <div className="flex flex-col text-left">
                            <span className="font-medium">{r.fornitore} · {r.codice_articolo_fornitore}</span>
                            <span className="text-xs text-muted-foreground">
                              {r.cliente_nominativo} · Agente {[r.agente_cognome, r.agente_nome].filter(Boolean).join(" ")}
                            </span>
                          </div>
                        </SelectItem>
                      ))
                    : recentOrders.map((o: any) => (
                        <SelectItem key={o.id} value={o.id}>
                          <div className="flex flex-col text-left">
                            <span className="font-medium">
                              {o.company_name} <span className="text-muted-foreground font-normal">· {o.codice_cliente}</span>
                            </span>
                            <span className="text-xs text-muted-foreground">
                              #{o.transmission_id || o.id.slice(0, 8)} · Agente {o.agent_name} · {Number(o.total ?? 0).toFixed(2)} €
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground mt-1">Il test usa il template in editing (anche non salvato).</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTestOpen(false)}>Annulla</Button>
            <Button onClick={sendTest} disabled={sending}><Send className="mr-2 h-4 w-4" />Invia</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import { ArticleList } from "@/components/articles/ArticleList";

export default function ArticlesPage() {
  return (
    <div className="h-[calc(100vh-3rem)] flex flex-col">
      <ArticleList />
    </div>
  );
}

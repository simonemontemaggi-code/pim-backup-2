import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Plus, Pencil, Trash2, Bell, AlertCircle, FileText, Info, Users } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { format } from "date-fns";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CommunicationPublishConfirm } from "@/components/b2b/CommunicationPublishConfirm";

interface AudienceFilters {
  customer_codes?: string[];
  agent_codes?: string[];
  zone_codes?: string[];
}

interface Communication {
  id: string;
  title: string;
  display_mode: "popup" | "notification";
  target_apps: string[];
  active: boolean;
  pdf_url: string | null;
  created_at: string;
  updated_at: string;
  audience_filters: AudienceFilters | null;
}

function hasAudience(af: AudienceFilters | null | undefined): boolean {
  if (!af) return false;
  return (
    (af.customer_codes?.length ?? 0) > 0 ||
    (af.agent_codes?.length ?? 0) > 0 ||
    (af.zone_codes?.length ?? 0) > 0
  );
}

function AudienceDialog({ open, onOpenChange, communication }: { open: boolean; onOpenChange: (v: boolean) => void; communication: Communication | null }) {
  const af = communication?.audience_filters ?? {};
  const groups: Array<{ key: string; label: string; codes: string[] }> = [
    { key: "customers", label: "Clienti", codes: af.customer_codes ?? [] },
    { key: "agents", label: "Agenti", codes: af.agent_codes ?? [] },
    { key: "zones", label: "Zone", codes: af.zone_codes ?? [] },
  ].filter((g) => g.codes.length > 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Users className="h-5 w-5" />Destinatari</DialogTitle>
          <DialogDescription>{communication?.title}</DialogDescription>
        </DialogHeader>
        <ScrollArea className="max-h-[60vh] pr-2">
          <div className="space-y-4">
            {groups.length === 0 && (
              <p className="text-sm text-muted-foreground">Nessun filtro configurato.</p>
            )}
            {groups.map((g) => (
              <div key={g.key}>
                <h4 className="text-sm font-semibold mb-2">{g.label} ({g.codes.length})</h4>
                <div className="flex flex-wrap gap-1.5">
                  {g.codes.map((c) => (
                    <Badge key={c} variant="outline" className="font-mono text-xs">{c}</Badge>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

export default function B2bCommunicationsPage() {
  const confirm = useConfirm();
  const [items, setItems] = useState<Communication[]>([]);
  const [loading, setLoading] = useState(true);
  const [audienceOpen, setAudienceOpen] = useState<Communication | null>(null);
  const [pendingActivate, setPendingActivate] = useState<Communication | null>(null);
  const [activating, setActivating] = useState(false);
  const navigate = useNavigate();

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("b2b_communications")
      .select("id,title,display_mode,target_apps,active,pdf_url,created_at,updated_at,audience_filters")
      .order("created_at", { ascending: false });
    if (error) toast.error(error.message);
    setItems((data as any) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const toggleActive = async (id: string, active: boolean) => {
    const { error } = await supabase.from("b2b_communications").update({ active }).eq("id", id);
    if (error) return toast.error(error.message);
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, active } : i)));
  };

  const remove = async (id: string) => {
    if (!(await confirm({ title: "Eliminare la comunicazione?", description: "Verranno rimossi anche i tracking di lettura.", destructive: true, confirmText: "Elimina" }))) return;
    const { error } = await supabase.from("b2b_communications").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Eliminata");
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  const create = async () => {
    const { data, error } = await supabase
      .from("b2b_communications")
      .insert({ title: "Nuova comunicazione", body_html: "", display_mode: "notification", target_apps: ["b2b", "agent_hub"], active: false })
      .select("id")
      .single();
    if (error) return toast.error(error.message);
    navigate(`/pim/b2b/communications/${data.id}`);
  };

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Comunicazioni Portale</h1>
          <p className="text-sm text-muted-foreground">Avvisi e notifiche di servizio mostrati su B2B e Portale Agenti</p>
        </div>
        <Button onClick={create}><Plus className="h-4 w-4 mr-2" />Nuova comunicazione</Button>
      </div>

      <Card className="p-0 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="text-left px-4 py-2">Titolo</th>
              <th className="text-left px-4 py-2">Modalità</th>
              <th className="text-left px-4 py-2">App</th>
              <th className="text-left px-4 py-2">PDF</th>
              <th className="text-left px-4 py-2">Aggiornato</th>
              <th className="text-left px-4 py-2">Attiva</th>
              <th className="px-4 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td colSpan={7} className="p-6 text-center text-muted-foreground">Caricamento…</td></tr>
            )}
            {!loading && items.length === 0 && (
              <tr><td colSpan={7} className="p-6 text-center text-muted-foreground">Nessuna comunicazione</td></tr>
            )}
            {items.map((c) => (
              <tr key={c.id} className="border-t hover:bg-muted/30">
                <td className="px-4 py-2 font-medium">
                  <Link to={`/pim/b2b/communications/${c.id}`} className="hover:underline">{c.title}</Link>
                </td>
                <td className="px-4 py-2">
                  {c.display_mode === "popup" ? (
                    <Badge variant="destructive" className="gap-1"><AlertCircle className="h-3 w-3" />Popup</Badge>
                  ) : (
                    <Badge variant="secondary" className="gap-1"><Bell className="h-3 w-3" />Notifica</Badge>
                  )}
                </td>
                <td className="px-4 py-2">
                  <div className="flex items-center gap-1">
                    {c.target_apps.includes("b2b") && <Badge variant="outline">B2B</Badge>}
                    {c.target_apps.includes("agent_hub") && <Badge variant="outline">Agent Hub</Badge>}
                    {hasAudience(c.audience_filters) && (
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-6 w-6 ml-1"
                        title="Vedi destinatari"
                        onClick={() => setAudienceOpen(c)}
                      >
                        <Info className="h-4 w-4 text-primary" />
                      </Button>
                    )}
                  </div>
                </td>
                <td className="px-4 py-2">{c.pdf_url ? <FileText className="h-4 w-4 text-primary" /> : <span className="text-muted-foreground">—</span>}</td>
                <td className="px-4 py-2 text-muted-foreground">{format(new Date(c.updated_at), "dd/MM/yyyy HH:mm")}</td>
                <td className="px-4 py-2"><Switch checked={c.active} onCheckedChange={(v) => { if (v) setPendingActivate(c); else toggleActive(c.id, false); }} /></td>
                <td className="px-4 py-2">
                  <div className="flex justify-end gap-1">
                    <Button size="sm" variant="ghost" asChild><Link to={`/pim/b2b/communications/${c.id}`}><Pencil className="h-4 w-4" /></Link></Button>
                    <Button size="sm" variant="ghost" onClick={() => remove(c.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      <AudienceDialog open={!!audienceOpen} onOpenChange={(v) => !v && setAudienceOpen(null)} communication={audienceOpen} />
      <CommunicationPublishConfirm
        open={!!pendingActivate}
        onOpenChange={(v) => { if (!v) setPendingActivate(null); }}
        title={pendingActivate?.title ?? ""}
        targetApps={pendingActivate?.target_apps ?? []}
        audience={pendingActivate?.audience_filters ?? null}
        loading={activating}
        onConfirm={async () => {
          if (!pendingActivate) return;
          setActivating(true);
          await toggleActive(pendingActivate.id, true);
          setActivating(false);
          setPendingActivate(null);
        }}
      />
    </div>
  );
}

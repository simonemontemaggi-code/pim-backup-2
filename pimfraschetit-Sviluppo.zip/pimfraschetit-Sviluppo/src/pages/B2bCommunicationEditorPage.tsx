import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";

import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Save, Upload, Trash2, FileText, Eye, X, AlertCircle, Plus } from "lucide-react";
import { toast } from "sonner";
import { RichTextEditor } from "@/components/communications/RichTextEditor";
import { CommunicationReadsDialog } from "@/components/communications/CommunicationReadsDialog";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { maybeOptimizePdf } from "@/lib/maybeOptimizePdf";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";

interface AudienceFilters {
  customer_codes?: string[];
  agent_codes?: string[];
  zone_codes?: string[];
}

interface Comm {
  id: string;
  title: string;
  body_html: string;
  pdf_url: string | null;
  pdf_filename: string | null;
  display_mode: "popup" | "notification";
  target_apps: string[];
  audience_filters: AudienceFilters;
  active: boolean;
  published_at: string | null;
}

interface AgentProfile {
  agent_code: string;
  full_name: string | null;
}

const csvToList = (s: string) =>
  s.split(/[\s,;\n]+/).map((x) => x.trim()).filter(Boolean);

export default function B2bCommunicationEditorPage() {
  const confirm = useConfirm();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [data, setData] = useState<Comm | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [readsCount, setReadsCount] = useState(0);
  const [readsOpen, setReadsOpen] = useState(false);
  const pdfInputRef = useRef<HTMLInputElement>(null);
  const [customersText, setCustomersText] = useState("");
  const [agentsText, setAgentsText] = useState("");
  const [zonesText, setZonesText] = useState("");
  const [agents, setAgents] = useState<AgentProfile[]>([]);
  const [agentPickerOpen, setAgentPickerOpen] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: rows } = await supabase
        .from("profiles")
        .select("agent_code, full_name")
        .not("agent_code", "is", null)
        .neq("agent_code", "")
        .order("agent_code", { ascending: true });
      setAgents((rows || []) as AgentProfile[]);
    })();
  }, []);

  useEffect(() => {
    (async () => {
      if (!id) return;
      const { data: row, error } = await supabase
        .from("b2b_communications")
        .select("*")
        .eq("id", id)
        .single();
      if (error) return toast.error(error.message);
      setData(row as any);
      const af = ((row as any)?.audience_filters || {}) as AudienceFilters;
      setCustomersText((af.customer_codes || []).join(", "));
      setAgentsText((af.agent_codes || []).join(", "));
      setZonesText((af.zone_codes || []).join(", "));
      const { count } = await supabase
        .from("b2b_communication_reads")
        .select("id", { count: "exact", head: true })
        .eq("communication_id", id);
      setReadsCount(count || 0);
    })();
  }, [id]);

  if (!data) {
    return <div className="p-6 text-muted-foreground">Caricamento…</div>;
  }

  const update = (patch: Partial<Comm>) => setData({ ...data, ...patch });

  const updateAudience = (patch: Partial<AudienceFilters>) =>
    setData({ ...data, audience_filters: { ...data.audience_filters, ...patch } });

  const toggleApp = (app: string) => {
    const has = data.target_apps.includes(app);
    update({
      target_apps: has ? data.target_apps.filter((a) => a !== app) : [...data.target_apps, app],
    });
  };

  const save = async () => {
    setSaving(true);
    const wasActive = data.active;
    const flushedAudience: AudienceFilters = {
      ...data.audience_filters,
      customer_codes: csvToList(customersText),
      agent_codes: csvToList(agentsText),
      zone_codes: csvToList(zonesText),
    };
    setData({ ...data, audience_filters: flushedAudience });
    const payload: any = {
      title: data.title,
      body_html: data.body_html,
      pdf_url: data.pdf_url,
      pdf_filename: data.pdf_filename,
      display_mode: data.display_mode,
      target_apps: data.target_apps,
      audience_filters: flushedAudience,
      active: data.active,
    };
    if (wasActive && !data.published_at) payload.published_at = new Date().toISOString();
    const { error } = await supabase.from("b2b_communications").update(payload).eq("id", id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Comunicazione salvata");
  };

  const uploadPdf = async (file: File) => {
    if (file.type !== "application/pdf") return toast.error("Carica solo file PDF");
    setUploading(true);
    try {
      const optimized = await maybeOptimizePdf(file);
      const path = `pdf/${id}-${Date.now()}.pdf`;
      const { error } = await supabase.storage
        .from("b2b-communications")
        .upload(path, optimized, { contentType: "application/pdf", upsert: true });
      if (error) throw error;
      const { data: urlData } = supabase.storage.from("b2b-communications").getPublicUrl(path);
      update({ pdf_url: urlData.publicUrl, pdf_filename: file.name });
      toast.success("PDF caricato");
    } catch (e: any) {
      toast.error(`Errore: ${e.message}`);
    } finally {
      setUploading(false);
    }
  };

  const removePdf = () => update({ pdf_url: null, pdf_filename: null });

  const resetReads = async () => {
    if (!(await confirm({ title: "Azzerare le letture?", description: `Verranno cancellate ${readsCount} letture. Il popup riapparirà a tutti gli utenti.`, destructive: true, confirmText: "Azzera" }))) return;
    const { error } = await supabase.from("b2b_communication_reads").delete().eq("communication_id", id);
    if (error) return toast.error(error.message);
    setReadsCount(0);
    toast.success("Letture azzerate");
  };

  const agentByCode = new Map(agents.map((a) => [a.agent_code, a.full_name || ""]));
  const parsedAgentCodes = csvToList(agentsText);
  const selectedAgentSet = new Set(parsedAgentCodes);
  const removeAgentCode = (code: string) => {
    const next = parsedAgentCodes.filter((c) => c !== code);
    setAgentsText(next.join(", "));
    updateAudience({ agent_codes: next });
  };
  const addAgentCode = (code: string) => {
    if (selectedAgentSet.has(code)) return;
    const next = [...parsedAgentCodes, code];
    setAgentsText(next.join(", "));
    updateAudience({ agent_codes: next });
    setAgentPickerOpen(false);
  };



  return (
    <div className="p-6 space-y-4 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" asChild><Link to="/pim/b2b/communications"><ArrowLeft className="h-4 w-4" /></Link></Button>
          <h1 className="text-xl font-semibold">Comunicazione</h1>
          {data.active ? <Badge>Attiva</Badge> : <Badge variant="secondary">Bozza</Badge>}
        </div>
        <Button onClick={save} disabled={saving}><Save className="h-4 w-4 mr-2" />{saving ? "Salvataggio…" : "Salva"}</Button>
      </div>

      <Card className="p-4 space-y-4">
        <div>
          <Label>Titolo</Label>
          <Input value={data.title} onChange={(e) => update({ title: e.target.value })} className="text-base font-medium" />
        </div>

        <div>
          <Label>Contenuto</Label>
          <RichTextEditor value={data.body_html} onChange={(html) => update({ body_html: html })} />
        </div>
      </Card>

      <div className="grid md:grid-cols-2 gap-4">
        <Card className="p-4 space-y-3">
          <Label className="text-base">Allegato PDF</Label>
          {data.pdf_url ? (
            <div className="flex items-center justify-between border rounded p-3 bg-muted/30">
              <div className="flex items-center gap-2 truncate">
                <FileText className="h-5 w-5 text-primary shrink-0" />
                <a href={data.pdf_url} target="_blank" rel="noreferrer" className="text-sm hover:underline truncate">
                  {data.pdf_filename || "Visualizza PDF"}
                </a>
              </div>
              <div className="flex gap-1">
                <Button size="sm" variant="ghost" asChild><a href={data.pdf_url} target="_blank" rel="noreferrer"><Eye className="h-4 w-4" /></a></Button>
                <Button size="sm" variant="ghost" onClick={removePdf}><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
            </div>
          ) : (
            <Button variant="outline" onClick={() => pdfInputRef.current?.click()} disabled={uploading}>
              <Upload className="h-4 w-4 mr-2" />{uploading ? "Caricamento…" : "Carica PDF"}
            </Button>
          )}
          <input
            ref={pdfInputRef}
            type="file"
            accept="application/pdf"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) uploadPdf(f);
              e.target.value = "";
            }}
          />
        </Card>

        <Card className="p-4 space-y-3">
          <Label className="text-base">Modalità di visualizzazione</Label>
          <RadioGroup value={data.display_mode} onValueChange={(v) => update({ display_mode: v as any })}>
            <div className="flex items-start gap-2 p-2 rounded hover:bg-muted/30">
              <RadioGroupItem value="popup" id="popup" className="mt-1" />
              <div>
                <Label htmlFor="popup" className="font-medium">Popup importante</Label>
                <p className="text-xs text-muted-foreground">Mostrato a schermo intero al login. Una volta chiuso non riappare.</p>
              </div>
            </div>
            <div className="flex items-start gap-2 p-2 rounded hover:bg-muted/30">
              <RadioGroupItem value="notification" id="notif" className="mt-1" />
              <div>
                <Label htmlFor="notif" className="font-medium">Notifica</Label>
                <p className="text-xs text-muted-foreground">Compare nell'icona delle notifiche, l'utente la apre quando vuole.</p>
              </div>
            </div>
          </RadioGroup>
        </Card>
      </div>

      <Card className="p-4 space-y-4">
        <Label className="text-base">Destinatari</Label>

        <div>
          <Label className="text-sm">App</Label>
          <div className="flex gap-4 mt-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <Checkbox checked={data.target_apps.includes("b2b")} onCheckedChange={() => toggleApp("b2b")} />
              <span>B2B clienti</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <Checkbox checked={data.target_apps.includes("agent_hub")} onCheckedChange={() => toggleApp("agent_hub")} />
              <span>Portale Agenti</span>
            </label>
          </div>
        </div>

        <Tabs defaultValue="customers">
          <TabsList>
            <TabsTrigger value="customers">Clienti</TabsTrigger>
            <TabsTrigger value="agents">Agenti</TabsTrigger>
            <TabsTrigger value="zones">Zone</TabsTrigger>
          </TabsList>
          <TabsContent value="customers" className="space-y-1">
            <p className="text-xs text-muted-foreground">Lascia vuoto per tutti. Inserisci uno o più codici cliente separati da virgola, spazio o a capo.</p>
            <Textarea
              rows={3}
              value={customersText}
              onChange={(e) => setCustomersText(e.target.value)}
              onBlur={() => updateAudience({ customer_codes: csvToList(customersText) })}
              placeholder="000123, 000456…"
            />
          </TabsContent>
          <TabsContent value="agents" className="space-y-2">
            <p className="text-xs text-muted-foreground">Codici agente separati da virgola/spazio. Lascia vuoto per tutti gli agenti.</p>
            <Textarea
              rows={3}
              value={agentsText}
              onChange={(e) => setAgentsText(e.target.value)}
              onBlur={() => updateAudience({ agent_codes: csvToList(agentsText) })}
              placeholder="03, 04, 12…"
            />
            {parsedAgentCodes.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {parsedAgentCodes.map((code) => {
                  const name = agentByCode.get(code);
                  const found = name !== undefined;
                  return (
                    <Badge
                      key={code}
                      variant={found ? "default" : "destructive"}
                      className={`gap-1 pl-2 pr-1 py-1 ${found ? "bg-emerald-100 text-emerald-900 hover:bg-emerald-200 border border-emerald-300" : ""}`}
                    >
                      {!found && <AlertCircle className="h-3 w-3" />}
                      <span className="font-mono text-xs">{code}</span>
                      {found ? (
                        <span className="text-xs font-normal opacity-80">— {name || "(senza nome)"}</span>
                      ) : (
                        <span className="text-xs font-normal opacity-90">· non trovato</span>
                      )}
                      <button
                        type="button"
                        onClick={() => removeAgentCode(code)}
                        className="ml-0.5 rounded hover:bg-black/10 p-0.5"
                        aria-label={`Rimuovi ${code}`}
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  );
                })}
              </div>
            )}
            <Popover open={agentPickerOpen} onOpenChange={setAgentPickerOpen}>
              <PopoverTrigger asChild>
                <Button type="button" variant="outline" size="sm" className="mt-1">
                  <Plus className="h-3.5 w-3.5 mr-1" />
                  Aggiungi agente
                </Button>
              </PopoverTrigger>
              <PopoverContent className="p-0 w-72" align="start">
                <Command>
                  <CommandInput placeholder="Cerca codice o nome…" />
                  <CommandList>
                    <CommandEmpty>Nessun agente</CommandEmpty>
                    <CommandGroup>
                      {agents
                        .filter((a) => !selectedAgentSet.has(a.agent_code))
                        .map((a) => (
                          <CommandItem
                            key={a.agent_code}
                            value={`${a.agent_code} ${a.full_name || ""}`}
                            onSelect={() => addAgentCode(a.agent_code)}
                          >
                            <span className="font-mono text-xs mr-2">{a.agent_code}</span>
                            <span className="text-sm">{a.full_name || "(senza nome)"}</span>
                          </CommandItem>
                        ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </TabsContent>
          <TabsContent value="zones" className="space-y-1">
            <p className="text-xs text-muted-foreground">Codici zona separati da virgola/spazio.</p>
            <Textarea
              rows={3}
              value={zonesText}
              onChange={(e) => setZonesText(e.target.value)}
              onBlur={() => updateAudience({ zone_codes: csvToList(zonesText) })}
              placeholder="01, 02…"
            />
          </TabsContent>
        </Tabs>
      </Card>

      <Card className="p-4 flex items-center justify-between">
        <div>
          <Label className="text-base">Pubblicazione</Label>
          <p className="text-xs text-muted-foreground">
            Per sicurezza la pubblicazione si gestisce dalla lista <Link to="/pim/b2b/communications" className="underline">Comunicazioni</Link>.
          </p>
        </div>
        <div className="flex items-center gap-3">
          {data.active ? <Badge>Attiva</Badge> : <Badge variant="secondary">Bozza</Badge>}
          {data.active && (
            <Button
              variant="outline"
              size="sm"
              onClick={async () => {
                const { error } = await supabase.from("b2b_communications").update({ active: false }).eq("id", id);
                if (error) return toast.error(error.message);
                update({ active: false });
                toast.success("Comunicazione disattivata");
              }}
            >
              Disattiva
            </Button>
          )}
        </div>
      </Card>

      <Card className="p-4 flex items-center justify-between">
        <div>
          <Label className="text-base">Letture</Label>
          <p className="text-xs text-muted-foreground">Utenti che hanno già visualizzato/chiuso il popup: <strong>{readsCount}</strong></p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setReadsOpen(true)} disabled={readsCount === 0}>Vedi dettaglio</Button>
          <Button variant="outline" onClick={resetReads} disabled={readsCount === 0}>Azzera letture</Button>
        </div>
      </Card>

      {id && (
        <CommunicationReadsDialog
          communicationId={id}
          title={data.title || "Comunicazione"}
          open={readsOpen}
          onOpenChange={setReadsOpen}
        />
      )}

    </div>
  );
}

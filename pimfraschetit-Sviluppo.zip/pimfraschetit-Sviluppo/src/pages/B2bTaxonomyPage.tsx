import { useEffect, useMemo, useState } from "react";
import { ChevronRight, ChevronDown, Loader2, Image as ImageIcon, ArrowUp, ArrowDown, Pencil, Save, X, GripVertical } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { MediaUploader } from "@/components/b2b/MediaUploader";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

type NodeType = "clmer" | "reparto" | "gamma";

interface Lookup {
  category: string;
  code: string;
  label: string | null;
  parent_category: string | null;
  parent_code: string | null;
  sort_order: number | null;
}

interface Content {
  id?: string;
  node_type: NodeType;
  node_code: string;
  display_name: string | null;
  tagline: string | null;
  description: string | null;
  hero_image_url: string | null;
  thumb_image_url: string | null;
  button_image_url: string | null;
  gradient_from: string | null;
  gradient_to: string | null;
  is_published_b2b: boolean;
}

const TYPE_LABEL: Record<NodeType, string> = {
  clmer: "Settore",
  reparto: "Reparto",
  gamma: "Gamma",
};

const sorter = (a: Lookup, b: Lookup) => {
  const sa = a.sort_order ?? 9999;
  const sb = b.sort_order ?? 9999;
  if (sa !== sb) return sa - sb;
  const an = Number(a.code);
  const bn = Number(b.code);
  if (!isNaN(an) && !isNaN(bn)) return an - bn;
  return (a.label ?? a.code).localeCompare(b.label ?? b.code, "it", { numeric: true });
};

export default function B2bTaxonomyPage() {
  const { user } = useAuth();
  const [lookups, setLookups] = useState<Record<NodeType, Lookup[]>>({ clmer: [], reparto: [], gamma: [] });
  const [contents, setContents] = useState<Record<string, Content>>({});
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState<{ clmer: Set<string>; reparto: Set<string> }>({
    clmer: new Set(),
    reparto: new Set(),
  });
  const [expandedReparto, setExpandedReparto] = useState<Set<string>>(new Set());
  const [selected, setSelected] = useState<{ type: NodeType; code: string } | null>(null);
  const [reorderMode, setReorderMode] = useState(false);
  const [draftLookups, setDraftLookups] = useState<Record<NodeType, Lookup[]> | null>(null);
  const [savingOrder, setSavingOrder] = useState(false);

  const loadAll = async () => {
    setLoading(true);
    const [{ data: lk }, { data: ct }] = await Promise.all([
      supabase
        .from("lookup_values")
        .select("category, code, label, parent_category, parent_code, sort_order")
        .in("category", ["clmer", "reparto", "gamma"])
        .eq("is_active", true),
      supabase.from("taxonomy_content").select("*"),
    ]);
    if (lk) {
      const grouped: Record<NodeType, Lookup[]> = { clmer: [], reparto: [], gamma: [] };
      (lk as Lookup[]).forEach((r) => {
        if (grouped[r.category as NodeType]) grouped[r.category as NodeType].push(r);
      });
      (Object.keys(grouped) as NodeType[]).forEach((k) => grouped[k].sort(sorter));
      setLookups(grouped);
    }
    if (ct) {
      const map: Record<string, Content> = {};
      (ct as Content[]).forEach((c) => {
        map[`${c.node_type}::${c.node_code}`] = c;
      });
      setContents(map);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadAll();
  }, []);

  const labelOf = (type: NodeType, code: string): string | null => {
    const l = lookups[type].find((x) => x.code === code);
    return l?.label ?? null;
  };

  const draft: Content | null = useMemo(() => {
    if (!selected) return null;
    const key = `${selected.type}::${selected.code}`;
    const existing = contents[key];
    if (existing) return existing;
    return {
      node_type: selected.type,
      node_code: selected.code,
      display_name: labelOf(selected.type, selected.code),
      tagline: null,
      description: null,
      hero_image_url: null,
      thumb_image_url: null,
      button_image_url: null,
      gradient_from: null,
      gradient_to: "transparent",
      is_published_b2b: true,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected, contents, lookups]);

  const upsertContent = async (patch: Partial<Content>) => {
    if (!selected) return;
    const key = `${selected.type}::${selected.code}`;
    // Leggo lo state più aggiornato via setter funzionale per evitare race
    // (es. upload in corso mentre prepublishAll modifica contents).
    let current: Content | undefined;
    setContents((c) => {
      current = c[key];
      return c;
    });
    const base: Content = current ?? {
      node_type: selected.type,
      node_code: selected.code,
      display_name: labelOf(selected.type, selected.code),
      tagline: null,
      description: null,
      hero_image_url: null,
      thumb_image_url: null,
      button_image_url: null,
      gradient_from: null,
      gradient_to: "transparent",
      is_published_b2b: true,
    };
    const payload = {
      ...base,
      ...patch,
      gradient_to: "transparent",
      is_published_b2b: true,
      updated_by: user?.id,
    };
    const { data, error } = await supabase
      .from("taxonomy_content")
      .upsert(payload, { onConflict: "node_type,node_code" })
      .select()
      .single();
    if (error) {
      toast.error(`Errore: ${error.message}`);
      return;
    }
    if (data) {
      setContents((c) => ({ ...c, [`${data.node_type}::${data.node_code}`]: data as Content }));
      toast.success("Salvato");
    }
  };

  const toggleExpand = (level: "clmer" | "reparto", code: string) => {
    setExpanded((e) => {
      const next = { clmer: new Set(e.clmer), reparto: new Set(e.reparto) };
      if (next[level].has(code)) next[level].delete(code);
      else next[level].add(code);
      return next;
    });
  };

  const stats = useMemo(() => {
    const all = Object.values(contents);
    return {
      clmerWithImg: all.filter((c) => c.node_type === "clmer" && c.thumb_image_url).length,
      repartoWithImg: all.filter((c) => c.node_type === "reparto" && c.thumb_image_url).length,
    };
  }, [contents]);
  const [prepublishing, setPrepublishing] = useState(false);

  const prepublishAll = async () => {
    setPrepublishing(true);
    const existingKeys = new Set(Object.keys(contents));
    const rows: any[] = [];
    settoriVisibili.forEach((s) => {
      if (!existingKeys.has(`clmer::${s.code}`)) {
        rows.push({
          node_type: "clmer",
          node_code: s.code,
          display_name: s.label ?? s.code,
          gradient_to: "transparent",
          is_published_b2b: true,
          updated_by: user?.id,
        });
      }
    });
    lookups.reparto.forEach((r) => {
      if (!existingKeys.has(`reparto::${r.code}`)) {
        rows.push({
          node_type: "reparto",
          node_code: r.code,
          display_name: r.label ?? r.code,
          gradient_to: "transparent",
          is_published_b2b: true,
          updated_by: user?.id,
        });
      }
    });
    if (rows.length === 0) {
      toast.info("Tutti i nodi sono già pubblicati");
      setPrepublishing(false);
      return;
    }
    const { error } = await supabase
      .from("taxonomy_content")
      .upsert(rows, { onConflict: "node_type,node_code" });
    if (error) {
      toast.error(`Errore: ${error.message}`);
    } else {
      toast.success(`${rows.length} nodi pre-pubblicati`);
      await loadAll();
    }
    setPrepublishing(false);
  };

  const activeLookups = reorderMode && draftLookups ? draftLookups : lookups;

  const repartiBySettore = useMemo(() => {
    const m: Record<string, Lookup[]> = {};
    activeLookups.reparto.forEach((r) => {
      if (!r.parent_code) return;
      (m[r.parent_code] ||= []).push(r);
    });
    Object.keys(m).forEach((k) => m[k].sort(sorter));
    return m;
  }, [activeLookups.reparto]);

  const gammeByReparto = useMemo(() => {
    const m: Record<string, Lookup[]> = {};
    activeLookups.gamma.forEach((g) => {
      if (!g.parent_code) return;
      (m[g.parent_code] ||= []).push(g);
    });
    Object.keys(m).forEach((k) => m[k].sort(sorter));
    return m;
  }, [activeLookups.gamma]);

  const settoriVisibili = useMemo(
    () => activeLookups.clmer.filter((s) => (repartiBySettore[s.code]?.length ?? 0) > 0),
    [activeLookups.clmer, repartiBySettore],
  );

  const enterReorder = () => {
    setDraftLookups({
      clmer: lookups.clmer.map((x) => ({ ...x })),
      reparto: lookups.reparto.map((x) => ({ ...x })),
      gamma: lookups.gamma.map((x) => ({ ...x })),
    });
    setReorderMode(true);
  };

  const cancelReorder = () => {
    setDraftLookups(null);
    setReorderMode(false);
  };

  // Riordina la lista (filtrata per parent) e riassegna sort_order normalizzati 10,20,30...
  const reorderDraft = (
    type: NodeType,
    parentCode: string | null,
    fromIdx: number,
    toIdx: number,
  ) => {
    setDraftLookups((prev) => {
      if (!prev) return prev;
      const all = prev[type];
      const filtered = all
        .filter((x) => (parentCode === null ? true : x.parent_code === parentCode))
        .sort(sorter);
      if (fromIdx < 0 || toIdx < 0 || fromIdx >= filtered.length || toIdx >= filtered.length) return prev;
      const reordered = arrayMove(filtered, fromIdx, toIdx);
      // Riassegna sort_order 10,20,30...
      const newOrderMap = new Map<string, number>();
      reordered.forEach((item, i) => newOrderMap.set(item.code, (i + 1) * 10));
      const nextList = all.map((x) =>
        newOrderMap.has(x.code) ? { ...x, sort_order: newOrderMap.get(x.code)! } : x,
      );
      return { ...prev, [type]: nextList };
    });
  };

  const moveSettore = (s: Lookup, dir: -1 | 1) => {
    const idx = settoriVisibili.findIndex((x) => x.code === s.code);
    if (idx < 0) return;
    reorderDraft("clmer", null, idx, idx + dir);
  };

  const moveReparto = (parent: string, r: Lookup, dir: -1 | 1) => {
    const list = repartiBySettore[parent] ?? [];
    const idx = list.findIndex((x) => x.code === r.code);
    if (idx < 0) return;
    reorderDraft("reparto", parent, idx, idx + dir);
  };

  const moveGamma = (parent: string, g: Lookup, dir: -1 | 1) => {
    const list = gammeByReparto[parent] ?? [];
    const idx = list.findIndex((x) => x.code === g.code);
    if (idx < 0) return;
    reorderDraft("gamma", parent, idx, idx + dir);
  };

  // Sensors per drag-and-drop
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 4 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const handleDragEndSettori = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const from = settoriVisibili.findIndex((x) => x.code === active.id);
    const to = settoriVisibili.findIndex((x) => x.code === over.id);
    reorderDraft("clmer", null, from, to);
  };

  const handleDragEndReparti = (parent: string) => (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const list = repartiBySettore[parent] ?? [];
    const from = list.findIndex((x) => x.code === active.id);
    const to = list.findIndex((x) => x.code === over.id);
    reorderDraft("reparto", parent, from, to);
  };

  const handleDragEndGamme = (parent: string) => (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const list = gammeByReparto[parent] ?? [];
    const from = list.findIndex((x) => x.code === active.id);
    const to = list.findIndex((x) => x.code === over.id);
    reorderDraft("gamma", parent, from, to);
  };

  const saveOrder = async () => {
    if (!draftLookups) return;
    setSavingOrder(true);
    // Calcola sort_order normalizzati 10,20,30... e diff con originale
    const updates: { category: NodeType; code: string; sort_order: number }[] = [];
    (["clmer", "reparto", "gamma"] as NodeType[]).forEach((type) => {
      // Per reparti e gamme normalizzo per parent
      if (type === "reparto" || type === "gamma") {
        const byParent: Record<string, Lookup[]> = {};
        draftLookups[type].forEach((r) => {
          if (!r.parent_code) return;
          (byParent[r.parent_code] ||= []).push(r);
        });
        Object.values(byParent).forEach((list) => {
          list.sort(sorter);
          list.forEach((r, i) => {
            const newOrder = (i + 1) * 10;
            const orig = lookups[type].find((x) => x.code === r.code);
            if (!orig || orig.sort_order !== newOrder) {
              updates.push({ category: type, code: r.code, sort_order: newOrder });
            }
          });
        });
      } else {
        const list = [...draftLookups.clmer].sort(sorter);
        list.forEach((s, i) => {
          const newOrder = (i + 1) * 10;
          const orig = lookups.clmer.find((x) => x.code === s.code);
          if (!orig || orig.sort_order !== newOrder) {
            updates.push({ category: "clmer", code: s.code, sort_order: newOrder });
          }
        });
      }
    });

    if (updates.length === 0) {
      toast.info("Nessuna modifica da salvare");
      setSavingOrder(false);
      setReorderMode(false);
      setDraftLookups(null);
      return;
    }

    const results = await Promise.all(
      updates.map((u) =>
        supabase
          .from("lookup_values")
          .update({ sort_order: u.sort_order })
          .eq("category", u.category)
          .eq("code", u.code),
      ),
    );
    const failed = results.filter((r) => r.error);
    if (failed.length > 0) {
      toast.error(`Errore salvataggio (${failed.length} update falliti)`);
      setSavingOrder(false);
      return;
    }
    toast.success(`Ordine salvato (${updates.length} modifiche)`);
    setSavingOrder(false);
    setReorderMode(false);
    setDraftLookups(null);
    loadAll();
  };

  if (loading)
    return (
      <div className="p-6">
        <Loader2 className="animate-spin" />
      </div>
    );

  const isPublished = (type: NodeType, code: string) =>
    contents[`${type}::${code}`]?.is_published_b2b;

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Settori, Reparti e Gamme</h1>
          <p className="text-sm text-muted-foreground">
            Gestisci immagini e ordine delle categorie merceologiche del B2B
          </p>
        </div>
        <Button onClick={prepublishAll} disabled={prepublishing} variant="outline">
          {prepublishing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
          Pre-pubblica tutti i nodi
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Card className="p-4">
          <div className="text-xs text-muted-foreground">Settori con immagine</div>
          <div className="text-2xl font-bold">
            {stats.clmerWithImg} / {settoriVisibili.length}
          </div>
        </Card>
        <Card className="p-4">
          <div className="text-xs text-muted-foreground">Reparti con immagine</div>
          <div className="text-2xl font-bold">
            {stats.repartoWithImg} / {lookups.reparto.length}
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Tree */}
        <Card className="p-3 max-h-[75vh] overflow-y-auto col-span-1">
          <div className="flex items-center justify-between mb-2">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Albero</div>
            {!reorderMode ? (
              <Button size="sm" variant="outline" className="h-7 text-xs" onClick={enterReorder}>
                <Pencil className="h-3 w-3 mr-1" /> Riordina
              </Button>
            ) : (
              <div className="flex gap-1">
                <Button
                  size="sm"
                  variant="default"
                  className="h-7 text-xs"
                  onClick={saveOrder}
                  disabled={savingOrder}
                >
                  {savingOrder ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : <Save className="h-3 w-3 mr-1" />}
                  Salva
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 text-xs"
                  onClick={cancelReorder}
                  disabled={savingOrder}
                >
                  <X className="h-3 w-3 mr-1" /> Annulla
                </Button>
              </div>
            )}
          </div>
          {reorderMode && (
            <div className="text-[11px] text-amber-600 dark:text-amber-400 mb-2 px-1">
              Modalità riordino: trascina per riordinare oppure usa le frecce. Premi Salva per confermare.
            </div>
          )}
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEndSettori}>
            <SortableContext
              items={settoriVisibili.map((s) => s.code)}
              strategy={verticalListSortingStrategy}
            >
              {settoriVisibili.map((s, sIdx) => {
                const sExp = expanded.clmer.has(s.code);
                const reparti = repartiBySettore[s.code] ?? [];
                return (
                  <SortableRow key={s.code} id={s.code} disabled={!reorderMode}>
                    {(dragHandle) => (
                      <div className="text-sm">
                        <div className="flex items-center gap-1 hover:bg-muted/50 rounded px-1 py-1">
                          {reorderMode && (
                            <>
                              {dragHandle}
                              <div className="flex flex-col">
                                <button
                                  type="button"
                                  className="p-0 disabled:opacity-30"
                                  disabled={sIdx === 0}
                                  onClick={() => moveSettore(s, -1)}
                                  title="Sposta su"
                                >
                                  <ArrowUp className="h-3 w-3" />
                                </button>
                                <button
                                  type="button"
                                  className="p-0 disabled:opacity-30"
                                  disabled={sIdx === settoriVisibili.length - 1}
                                  onClick={() => moveSettore(s, 1)}
                                  title="Sposta giù"
                                >
                                  <ArrowDown className="h-3 w-3" />
                                </button>
                              </div>
                            </>
                          )}
                          <button type="button" onClick={() => toggleExpand("clmer", s.code)} className="p-0.5">
                            {sExp ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                          </button>
                          <button
                            type="button"
                            className={`flex-1 text-left ${
                              selected?.type === "clmer" && selected.code === s.code ? "font-bold text-primary" : ""
                            } ${reorderMode ? "cursor-default" : ""}`}
                            onClick={() => {
                              if (reorderMode) return;
                              setSelected({ type: "clmer", code: s.code });
                            }}
                          >
                            {s.label || s.code}
                            <span className="ml-2 text-[10px] text-muted-foreground">({reparti.length})</span>
                          </button>
                          {isPublished("clmer", s.code) && (
                            <Badge variant="outline" className="h-4 text-[10px] px-1">●</Badge>
                          )}
                        </div>
                        {sExp && (
                          <div className="ml-5 border-l pl-2">
                            <DndContext
                              sensors={sensors}
                              collisionDetection={closestCenter}
                              onDragEnd={handleDragEndReparti(s.code)}
                            >
                              <SortableContext
                                items={reparti.map((r) => r.code)}
                                strategy={verticalListSortingStrategy}
                              >
                                {reparti.map((r, rIdx) => {
                                  const gamme = gammeByReparto[r.code] ?? [];
                                  const rExp = expandedReparto.has(r.code);
                                  return (
                                    <SortableRow key={r.code} id={r.code} disabled={!reorderMode}>
                                      {(dragHandleR) => (
                                        <div>
                                          <div className="flex items-center gap-1 hover:bg-muted/50 rounded px-1 py-1">
                                            {reorderMode && (
                                              <>
                                                {dragHandleR}
                                                <div className="flex flex-col">
                                                  <button
                                                    type="button"
                                                    className="p-0 disabled:opacity-30"
                                                    disabled={rIdx === 0}
                                                    onClick={() => moveReparto(s.code, r, -1)}
                                                    title="Sposta su"
                                                  >
                                                    <ArrowUp className="h-3 w-3" />
                                                  </button>
                                                  <button
                                                    type="button"
                                                    className="p-0 disabled:opacity-30"
                                                    disabled={rIdx === reparti.length - 1}
                                                    onClick={() => moveReparto(s.code, r, 1)}
                                                    title="Sposta giù"
                                                  >
                                                    <ArrowDown className="h-3 w-3" />
                                                  </button>
                                                </div>
                                              </>
                                            )}
                                            {gamme.length > 0 ? (
                                              <button
                                                type="button"
                                                onClick={() =>
                                                  setExpandedReparto((prev) => {
                                                    const n = new Set(prev);
                                                    n.has(r.code) ? n.delete(r.code) : n.add(r.code);
                                                    return n;
                                                  })
                                                }
                                                className="p-0.5"
                                                title={rExp ? "Comprimi" : "Espandi gamme"}
                                              >
                                                {rExp ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                                              </button>
                                            ) : (
                                              <span className="w-3.5" />
                                            )}
                                            <button
                                              type="button"
                                              className={`flex-1 text-left text-xs ${
                                                selected?.type === "reparto" && selected.code === r.code
                                                  ? "font-bold text-primary"
                                                  : ""
                                              } ${reorderMode ? "cursor-default" : ""}`}
                                              onClick={() => {
                                                if (reorderMode) return;
                                                setSelected({ type: "reparto", code: r.code });
                                              }}
                                            >
                                              {r.label || r.code}
                                              {gamme.length > 0 && (
                                                <span className="ml-2 text-[10px] text-muted-foreground">({gamme.length})</span>
                                              )}
                                            </button>
                                            {isPublished("reparto", r.code) && (
                                              <Badge variant="outline" className="h-4 text-[10px] px-1">●</Badge>
                                            )}
                                          </div>
                                          {rExp && gamme.length > 0 && (
                                            <div className="ml-5 border-l pl-2">
                                              <DndContext
                                                sensors={sensors}
                                                collisionDetection={closestCenter}
                                                onDragEnd={handleDragEndGamme(r.code)}
                                              >
                                                <SortableContext
                                                  items={gamme.map((g) => g.code)}
                                                  strategy={verticalListSortingStrategy}
                                                >
                                                  {gamme.map((g, gIdx) => (
                                                    <SortableRow key={g.code} id={g.code} disabled={!reorderMode}>
                                                      {(dragHandleG) => (
                                                        <div className="flex items-center gap-1 rounded px-1 py-0.5 text-[11px] text-muted-foreground">
                                                          {reorderMode && (
                                                            <>
                                                              {dragHandleG}
                                                              <div className="flex flex-col">
                                                                <button
                                                                  type="button"
                                                                  className="p-0 disabled:opacity-30"
                                                                  disabled={gIdx === 0}
                                                                  onClick={() => moveGamma(r.code, g, -1)}
                                                                  title="Sposta su"
                                                                >
                                                                  <ArrowUp className="h-3 w-3" />
                                                                </button>
                                                                <button
                                                                  type="button"
                                                                  className="p-0 disabled:opacity-30"
                                                                  disabled={gIdx === gamme.length - 1}
                                                                  onClick={() => moveGamma(r.code, g, 1)}
                                                                  title="Sposta giù"
                                                                >
                                                                  <ArrowDown className="h-3 w-3" />
                                                                </button>
                                                              </div>
                                                            </>
                                                          )}
                                                          <span className="w-3.5" />
                                                          <span className="flex-1 truncate" title={g.label || g.code}>
                                                            {g.label || g.code}
                                                          </span>
                                                        </div>
                                                      )}
                                                    </SortableRow>
                                                  ))}
                                                </SortableContext>
                                              </DndContext>
                                            </div>
                                          )}
                                        </div>
                                      )}
                                    </SortableRow>
                                  );
                                })}
                              </SortableContext>
                            </DndContext>
                          </div>
                        )}
                      </div>
                    )}
                  </SortableRow>
                );
              })}
            </SortableContext>
          </DndContext>
        </Card>

        {/* Editor */}
        <Card className={`col-span-2 p-5 ${reorderMode ? "opacity-50 pointer-events-none" : ""}`}>
          {!draft && (
            <div className="text-center py-12 text-muted-foreground">
              <ImageIcon className="h-10 w-10 mx-auto mb-2 opacity-50" />
              {reorderMode
                ? "Editor disabilitato durante il riordino"
                : "Seleziona un nodo dall'albero per gestirne le immagini"}
            </div>
          )}
          {draft && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <Badge variant="outline">{TYPE_LABEL[draft.node_type]}</Badge>
                  <h2 className="text-lg font-bold mt-1">
                    {labelOf(draft.node_type, draft.node_code) || draft.node_code}
                  </h2>
                  <p className="text-xs font-mono text-muted-foreground">{draft.node_code}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <MediaUploader
                  label="Thumb card (griglia)"
                  hint="Consigliato 600×600 — quadrata, PNG o JPG"
                  currentUrl={draft.thumb_image_url}
                  storagePath={`taxonomy/${draft.node_type}/${draft.node_code}/thumb`}
                  aspect="square"
                  onUploaded={(url) => upsertContent({ thumb_image_url: url })}
                />
                <MediaUploader
                  label="Pulsante filtro (220×64)"
                  hint="Consigliato 660×192 (3x retina) — minimo 440×128"
                  currentUrl={draft.button_image_url}
                  storagePath={`taxonomy/${draft.node_type}/${draft.node_code}/button`}
                  aspect="wide"
                  onUploaded={(url) => upsertContent({ button_image_url: url })}
                />
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

interface SortableRowProps {
  id: string;
  disabled?: boolean;
  children: (dragHandle: React.ReactNode) => React.ReactNode;
}

function SortableRow({ id, disabled, children }: SortableRowProps) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id,
    disabled,
  });
  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    zIndex: isDragging ? 10 : undefined,
    position: "relative",
  };
  const handle = disabled ? null : (
    <button
      type="button"
      ref={undefined}
      className="cursor-grab active:cursor-grabbing touch-none p-0.5 text-muted-foreground hover:text-foreground"
      title="Trascina per riordinare"
      {...attributes}
      {...listeners}
    >
      <GripVertical className="h-3.5 w-3.5" />
    </button>
  );
  return (
    <div ref={setNodeRef} style={style}>
      {children(handle)}
    </div>
  );
}

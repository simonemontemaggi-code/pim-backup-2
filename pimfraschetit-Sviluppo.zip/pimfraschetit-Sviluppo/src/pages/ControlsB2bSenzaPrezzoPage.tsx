import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { ArrowLeft, AlertTriangle, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { useActivePriceList } from "@/hooks/useActivePriceList";
import { useOnlineAssortments, buildOnlineB2bOrFilter } from "@/hooks/useOnlineAssortments";

interface Row {
  cdpar: string;
  depar: string | null;
  pcfor: string | null;
  has_criterio: boolean;
  has_costo: boolean;
}

/**
 * Controllo: articoli B2B online attivi per cui la RPC `pim_prezzo_listino_batch`
 * sul listino primario restituisce NULL o <= 0 (stessa identica logica del B2B Mockup).
 * Suddivisi in:
 *  - "scoperti" → manca criterio o costo: a video B2B saranno 0,00 €.
 *  - "calcolabili" → criterio + costo presenti ma la RPC ritorna comunque 0/NULL
 *    (bug RPC / configurazione listino da verificare).
 */
async function fetchData(activeList: string, orFilter: string): Promise<{ scoperti: Row[]; calcolabili: Row[] }> {
  // 1. Tutti i cdpar B2B online attivi (online_assortments auto + override manuali), paginati.
  const PAGE = 1000;
  const cdpars: string[] = [];
  let from = 0;
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const { data, error } = await supabase
      .from("archivio_articoli_fraschetti")
      .select("cdpar")
      .or(orFilter)
      .order("cdpar")
      .range(from, from + PAGE - 1);
    if (error) throw error;
    const rows = data ?? [];
    rows.forEach((r: any) => cdpars.push((r.cdpar ?? "").trim()));
    if (rows.length < PAGE) break;
    from += PAGE;
  }
  if (!cdpars.length) return { scoperti: [], calcolabili: [] };

  // 2. Calcolo prezzo per chunk via la STESSA RPC usata dal B2B Mockup.
  const RPC_CHUNK = 500;
  const mancantiSet = new Set<string>();
  for (let i = 0; i < cdpars.length; i += RPC_CHUNK) {
    const slice = cdpars.slice(i, i + RPC_CHUNK);
    const { data, error } = await supabase.rpc("pim_prezzo_listino_batch" as any, {
      _cdpars: slice,
      _cdls: activeList,
    });
    if (error) throw error;
    (data ?? []).forEach((r: any) => {
      const p = r?.prezzo;
      if (p == null || Number(p) <= 0) {
        mancantiSet.add(String(r.cdpar).trim());
      }
    });
  }
  if (!mancantiSet.size) return { scoperti: [], calcolabili: [] };
  const mancantiCdpars = Array.from(mancantiSet);

  // 3. Arricchimento (descrizione + fornitore) per i soli mancanti.
  const meta = new Map<string, { depar: string | null; pcfor: string | null }>();
  for (let i = 0; i < mancantiCdpars.length; i += PAGE) {
    const slice = mancantiCdpars.slice(i, i + PAGE);
    const { data, error } = await supabase
      .from("archivio_articoli_fraschetti")
      .select("cdpar,depar,pcfor")
      .in("cdpar", slice);
    if (error) throw error;
    (data ?? []).forEach((r: any) => {
      meta.set(String(r.cdpar).trim(), {
        depar: r.depar,
        pcfor: r.pcfor ? String(r.pcfor).trim() : null,
      });
    });
  }

  // 4. Diagnostica: criterio + costo (per spiegare perché la RPC torna 0).
  const criterioSet = new Set<string>();
  for (let i = 0; i < mancantiCdpars.length; i += PAGE) {
    const slice = mancantiCdpars.slice(i, i + PAGE);
    const { data, error } = await supabase
      .from("listini_vendita_criteri_prezzo")
      .select("wcdpa")
      .eq("wcdls", activeList)
      .in("wcdpa", slice);
    if (error) throw error;
    (data ?? []).forEach((r: any) => criterioSet.add(String(r.wcdpa).trim()));
  }

  const costoSet = new Set<string>();
  for (let i = 0; i < mancantiCdpars.length; i += PAGE) {
    const slice = mancantiCdpars.slice(i, i + PAGE);
    const { data, error } = await supabase
      .from("archivio_listini_fraschetti")
      .select("cdpar,wprsc")
      .gt("wprsc", 0)
      .in("cdpar", slice);
    if (error) throw error;
    (data ?? []).forEach((r: any) => costoSet.add(String(r.cdpar).trim()));
  }

  const scoperti: Row[] = [];
  const calcolabili: Row[] = [];
  for (const cdpar of mancantiCdpars) {
    const m = meta.get(cdpar) ?? { depar: null, pcfor: null };
    const has_criterio = criterioSet.has(cdpar);
    const has_costo = costoSet.has(cdpar);
    const row: Row = { cdpar, depar: m.depar, pcfor: m.pcfor, has_criterio, has_costo };
    if (has_criterio && has_costo) calcolabili.push(row);
    else scoperti.push(row);
  }
  return { scoperti, calcolabili };
}

export default function ControlsB2bSenzaPrezzoPage() {
  const { data: activeList } = useActivePriceList();
  const { data: onlineAssortments = [] } = useOnlineAssortments();
  const orFilter = buildOnlineB2bOrFilter(onlineAssortments);

  const { data, isLoading, error } = useQuery({
    queryKey: ["controls", "b2b_senza_prezzo", activeList, onlineAssortments.join(",")],
    queryFn: () => fetchData(activeList!, orFilter),
    enabled: !!activeList,
    staleTime: 60_000,
  });

  const scoperti = data?.scoperti ?? [];
  const calcolabili = data?.calcolabili ?? [];

  const counts = useMemo(() => ({
    scoperti: scoperti.length,
    calcolabili: calcolabili.length,
    totale: scoperti.length + calcolabili.length,
  }), [scoperti, calcolabili]);

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center gap-2">
        <Button asChild variant="ghost" size="icon" className="h-8 w-8">
          <Link to="/pim/controls"><ArrowLeft className="h-4 w-4" /></Link>
        </Button>
        <h1 className="text-2xl font-semibold flex items-center gap-2">
          <AlertTriangle className="h-6 w-6 text-warning" />
          Articoli B2B online senza prezzo
        </h1>
      </div>
      <p className="text-sm text-muted-foreground">
        Articoli con <strong>B2B online attivo</strong> per cui la RPC <code className="px-1 rounded bg-muted">pim_prezzo_listino_batch</code> sul listino
        {activeList ? <code className="mx-1 px-1 rounded bg-muted">{activeList}</code> : null}
        restituisce <strong>0</strong> o <strong>NULL</strong> (stessa logica usata dal B2B Mockup).
      </p>

      {isLoading && (
        <div className="space-y-2">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      )}

      {error && (
        <div className="text-sm text-destructive">Errore: {(error as Error).message}</div>
      )}

      {!isLoading && data && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Totale articoli senza prezzo</CardTitle>
              </CardHeader>
              <CardContent><div className="text-3xl font-bold">{counts.totale}</div></CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Da verificare (RPC torna 0)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-warning">{counts.calcolabili}</div>
                <p className="text-xs text-muted-foreground mt-1">Hanno criterio + costo ma la RPC torna 0/NULL: bug listino da investigare.</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Davvero scoperti</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-destructive">{counts.scoperti}</div>
                <p className="text-xs text-muted-foreground mt-1">Manca criterio o costo: a video B2B saranno 0,00 €.</p>
              </CardContent>
            </Card>
          </div>

          {scoperti.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-destructive" />
                  Articoli da sistemare manualmente ({scoperti.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[140px]">Codice</TableHead>
                      <TableHead>Descrizione</TableHead>
                      <TableHead className="w-[100px]">Forn.</TableHead>
                      <TableHead className="w-[100px] text-center">Criterio</TableHead>
                      <TableHead className="w-[100px] text-center">Costo</TableHead>
                      <TableHead className="w-[60px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {scoperti.map((r) => (
                      <TableRow key={r.cdpar}>
                        <TableCell className="font-mono text-xs">{r.cdpar}</TableCell>
                        <TableCell className="text-sm">{r.depar ?? "—"}</TableCell>
                        <TableCell className="font-mono text-xs">{r.pcfor ?? "—"}</TableCell>
                        <TableCell className="text-center">
                          {r.has_criterio
                            ? <Badge variant="outline" className="text-success border-success">✓</Badge>
                            : <Badge variant="outline" className="text-destructive border-destructive">manca</Badge>}
                        </TableCell>
                        <TableCell className="text-center">
                          {r.has_costo
                            ? <Badge variant="outline" className="text-success border-success">✓</Badge>
                            : <Badge variant="outline" className="text-destructive border-destructive">manca</Badge>}
                        </TableCell>
                        <TableCell>
                          <Button asChild size="icon" variant="ghost" className="h-7 w-7">
                            <Link to={`/pim/articles/${encodeURIComponent(r.cdpar)}?tab=listini`}>
                              <ExternalLink className="h-3.5 w-3.5" />
                            </Link>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}

          {calcolabili.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">
                  Da verificare — RPC torna 0 nonostante criterio + costo ({calcolabili.length})
                </CardTitle>
                <p className="text-xs text-muted-foreground">
                  Hanno sia il criterio sul listino sia un costo &gt; 0, ma <code>pim_prezzo_listino_batch</code> ritorna comunque 0/NULL.
                  Indica un mismatch nella configurazione del listino (es. criterio non applicabile, riga prezzo mancante in <code>listini_vendita_dettagli</code>): da investigare nella RPC.
                </p>
              </CardHeader>
              <CardContent className="p-0 max-h-[400px] overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[140px]">Codice</TableHead>
                      <TableHead>Descrizione</TableHead>
                      <TableHead className="w-[100px]">Forn.</TableHead>
                      <TableHead className="w-[60px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {calcolabili.map((r) => (
                      <TableRow key={r.cdpar}>
                        <TableCell className="font-mono text-xs">{r.cdpar}</TableCell>
                        <TableCell className="text-sm">{r.depar ?? "—"}</TableCell>
                        <TableCell className="font-mono text-xs">{r.pcfor ?? "—"}</TableCell>
                        <TableCell>
                          <Button asChild size="icon" variant="ghost" className="h-7 w-7">
                            <Link to={`/pim/articles/${encodeURIComponent(r.cdpar)}?tab=listini`}>
                              <ExternalLink className="h-3.5 w-3.5" />
                            </Link>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}

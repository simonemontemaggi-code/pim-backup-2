import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { as400DateToDisplay } from "@/lib/dateUtils";
import { Search, AlertCircle, CalendarClock, Download } from "lucide-react";
import { useActivePriceList } from "@/hooks/useActivePriceList";
import * as XLSX from "xlsx";

interface Row {
  id: string;
  wcdpa: string;
  wcdls: string | null;
  wdtin: string | null;
  wprun: number | null;
  wsm01: number | null;
  wsm02: number | null;
  wvaef: string | null;
  depar: string | null;
  prezzo_precedente: number | null;
  scostamento: number | null;
  scostamento_pct: number | null;
}

export default function ControlsPrezziAttesaPage() {
  const [search, setSearch] = useState("");

  const { data: activeList } = useActivePriceList();

  const { data, isLoading, error } = useQuery({
    queryKey: ["controls", "prezzi_attesa_M", activeList],
    enabled: !!activeList,
    queryFn: async () => {
      const { data: prezzi, error: e1 } = await supabase
        .from("prezzi_in_attesa" as any)
        .select("id,wcdpa,wcdls,wdtin,wprun,wsm01,wsm02,wvaef")
        .eq("wvaef", "M")
        .eq("wcdls", activeList!)
        .order("wdtin", { ascending: true });
      if (e1) throw e1;
      const rows = (prezzi ?? []) as any[];
      if (rows.length === 0) return [] as Row[];

      const cdpars = Array.from(new Set(rows.map((r) => r.wcdpa)));
      const cdparsTrim = Array.from(new Set(cdpars.map((c) => c.trim())));

      const [{ data: arts, error: e2 }, { data: prevs, error: e3 }] = await Promise.all([
        supabase
          .from("archivio_articoli_fraschetti")
          .select("cdpar,depar")
          .in("cdpar", cdpars),
        supabase
          .from("listini_vendita_dettagli" as any)
          .select("cdarl,cdlsl,prmil")
          .in("cdarl", cdparsTrim)
          .eq("cdlsl", activeList!),
      ]);
      if (e2) throw e2;
      if (e3) throw e3;

      const byCdpar = new Map<string, string>();
      (arts ?? []).forEach((a: any) => {
        byCdpar.set(a.cdpar, a.depar ?? "");
        byCdpar.set(a.cdpar.trim(), a.depar ?? "");
      });
      const prevByCdpar = new Map<string, number>();
      (prevs ?? []).forEach((p: any) => {
        if (p.prmil != null) prevByCdpar.set(p.cdarl, Number(p.prmil));
      });

      return rows.map((r) => {
        const key = r.wcdpa.trim();
        const prezzo_precedente = prevByCdpar.get(key) ?? null;
        const scostamento =
          prezzo_precedente != null && r.wprun != null ? r.wprun - prezzo_precedente : null;
        const scostamento_pct =
          prezzo_precedente != null && prezzo_precedente !== 0 && scostamento != null
            ? (scostamento / prezzo_precedente) * 100
            : null;
        return {
          ...r,
          depar: byCdpar.get(r.wcdpa) ?? byCdpar.get(key) ?? null,
          prezzo_precedente,
          scostamento,
          scostamento_pct,
        };
      }) as Row[];
    },
    staleTime: 30_000,
  });

  const filtered = useMemo(() => {
    if (!data) return [];
    const q = search.trim().toLowerCase();
    if (!q) return data;
    return data.filter(
      (r) =>
        r.wcdpa.toLowerCase().includes(q) ||
        (r.depar ?? "").toLowerCase().includes(q) ||
        (r.wdtin ?? "").includes(q) ||
        as400DateToDisplay(r.wdtin).includes(q),
    );
  }, [data, search]);

  const grouped = useMemo(() => {
    const map = new Map<string, Row[]>();
    filtered.forEach((r) => {
      const k = r.wdtin ?? "—";
      if (!map.has(k)) map.set(k, []);
      map.get(k)!.push(r);
    });
    return Array.from(map.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [filtered]);

  const todayStr = useMemo(() => {
    const d = new Date();
    return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
  }, []);

  const handleExport = () => {
    const rows = filtered.map((r) => ({
      "Validità": as400DateToDisplay(r.wdtin),
      "Codice": r.wcdpa.trim(),
      "Descrizione": r.depar?.trim() ?? "",
      "Listino": r.wcdls ?? "",
      "Prezzo precedente": r.prezzo_precedente ?? "",
      "Nuovo prezzo": r.wprun ?? "",
      "Scostamento": r.scostamento != null ? Number(r.scostamento.toFixed(4)) : "",
      "Scostamento %": r.scostamento_pct != null ? Number(r.scostamento_pct.toFixed(2)) : "",
      "Ricarico": r.wsm01 ?? "",
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Prezzi in Attesa");
    const today = new Date().toISOString().slice(0, 10);
    XLSX.writeFile(wb, `prezzi-in-attesa-${today}.xlsx`);
  };

  const fmt = (n: number | null | undefined) =>
    n != null ? n.toFixed(2).replace(".", ",") : "—";

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold flex items-center gap-2">
            <CalendarClock className="h-6 w-6 text-primary" />
            Prezzi in Attesa — Stato "M" (Modificato)
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Tutti i prezzi pianificati in attesa di entrare in vigore. Ordinati per data di validità.
          </p>
        </div>
        <div className="flex gap-3 items-center">
          <Card className="px-4 py-2">
            <div className="text-xs text-muted-foreground">Totale</div>
            <div className="text-2xl font-bold">{data?.length ?? 0}</div>
          </Card>
          <Card className="px-4 py-2">
            <div className="text-xs text-muted-foreground">In vigore oggi</div>
            <div className="text-2xl font-bold text-warning">
              {data?.filter((r) => r.wdtin === todayStr).length ?? 0}
            </div>
          </Card>
          <Button onClick={handleExport} disabled={!filtered.length} className="gap-2">
            <Download className="h-4 w-4" />
            Esporta Excel
          </Button>
        </div>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Filtra per codice, descrizione o data..."
          className="pl-8"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {error && (
        <div className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive flex items-center gap-2">
          <AlertCircle className="h-4 w-4" />
          {(error as Error).message}
        </div>
      )}

      {isLoading && (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      )}

      {!isLoading && grouped.length === 0 && (
        <div className="rounded-md border border-dashed p-12 text-center text-muted-foreground">
          Nessun prezzo in attesa con stato "M".
        </div>
      )}

      {grouped.map(([data_, rows]) => {
        const isToday = data_ === todayStr;
        const isPast = data_ < todayStr && data_ !== "—";
        return (
          <Card key={data_} className={isToday ? "border-warning" : isPast ? "border-destructive/50" : ""}>
            <CardHeader className="py-3">
              <CardTitle className="text-base flex items-center justify-between">
                <span className="flex items-center gap-2">
                  Validità: {as400DateToDisplay(data_)}
                  {isToday && <Badge variant="outline" className="border-warning text-warning">OGGI</Badge>}
                  {isPast && <Badge variant="destructive">SCADUTO non attivato</Badge>}
                </span>
                <Badge variant="secondary">{rows.length} articol{rows.length === 1 ? "o" : "i"}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <table className="w-full text-sm">
                <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="text-left px-3 py-2 w-[110px]">Codice</th>
                    <th className="text-left px-3 py-2">Descrizione</th>
                    <th className="text-left px-3 py-2 w-[70px]">List.</th>
                    <th className="text-right px-3 py-2 w-[100px]">Prezzo prec.</th>
                    <th className="text-right px-3 py-2 w-[100px]">Nuovo prezzo</th>
                    <th className="text-right px-3 py-2 w-[120px]">Scostamento</th>
                    <th className="text-right px-3 py-2 w-[80px]">Ric.</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => {
                    const sc = r.scostamento;
                    const scPct = r.scostamento_pct;
                    const scClass =
                      sc == null
                        ? "text-muted-foreground"
                        : sc > 0
                          ? "text-success"
                          : sc < 0
                            ? "text-destructive"
                            : "";
                    return (
                      <tr key={r.id} className="border-t hover:bg-muted/20">
                        <td className="px-3 py-2 font-mono">
                          <a
                            href={`/pim/articles/${r.wcdpa.trim()}?tab=listini`}
                            className="text-primary hover:underline"
                          >
                            {r.wcdpa.trim()}
                          </a>
                        </td>
                        <td className="px-3 py-2">
                          <a
                            href={`/pim/articles/${r.wcdpa.trim()}?tab=listini`}
                            className="hover:underline"
                          >
                            {r.depar?.trim() || <span className="text-muted-foreground italic">—</span>}
                          </a>
                        </td>
                        <td className="px-3 py-2 font-mono">{r.wcdls ?? "—"}</td>
                        <td className="px-3 py-2 text-right font-mono text-muted-foreground">
                          {fmt(r.prezzo_precedente)}
                        </td>
                        <td className="px-3 py-2 text-right font-mono font-semibold">
                          {fmt(r.wprun)}
                        </td>
                        <td className={`px-3 py-2 text-right font-mono ${scClass}`}>
                          {sc != null ? (
                            <>
                              {sc > 0 ? "+" : ""}
                              {fmt(sc)}
                              {scPct != null && (
                                <span className="text-xs ml-1 opacity-80">
                                  ({sc > 0 ? "+" : ""}
                                  {scPct.toFixed(1).replace(".", ",")}%)
                                </span>
                              )}
                            </>
                          ) : (
                            "—"
                          )}
                        </td>
                        <td className="px-3 py-2 text-right font-mono">{fmt(r.wsm01)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Search, ShoppingCart, Loader2, ArrowUp, ArrowDown, ArrowUpDown, StickyNote, RefreshCw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { OrderDetailSheet } from "@/components/sales/OrderDetailSheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { OrderDownloadButton } from "@/components/sales/OrderDownloadButton";
import { DownloadedOrdersTab } from "@/components/sales/DownloadedOrdersTab";
import { Checkbox } from "@/components/ui/checkbox";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { usePermissions } from "@/lib/permissions";

interface OrderRow {
  id: string;
  transmission_id: string | null;
  codice_cliente: string | null;
  codice_agente: string | null;
  origine: string | null;
  tipo: "negozio" | "agente";
  total: number | null;
  created_at: string;
  righe: number;
  company_name: string | null;
  zone_code: string | null;
  agent_name: string | null;
  listino: string | null;
  note: string | null;
}

type SortKey = "codice_cliente" | "company_name" | "zone_code" | "codice_agente" | "tipo" | "righe" | "created_at" | "total";
type SortDir = "asc" | "desc";

const fmtEuro = (n: number | null | undefined) =>
  new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" }).format(Number(n ?? 0));
const fmtDate = (s: string | null | undefined) => {
  if (!s) return "—";
  const d = new Date(s);
  if (isNaN(d.getTime())) return "—";
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

function TipoBadge({ tipo }: { tipo: "negozio" | "agente" }) {
  return tipo === "negozio" ? (
    <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 border-blue-200">Cliente CC</Badge>
  ) : (
    <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100 border-amber-200">Agente CA</Badge>
  );
}

function NoteIcon({ note, label }: { note: string; label?: string }) {
  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          <span
            className="inline-flex items-center text-amber-600 cursor-help"
            onClick={(e) => e.stopPropagation()}
            aria-label="Ordine con nota"
          >
            <StickyNote className="h-4 w-4" />
          </span>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-sm">
          {label && <div className="text-xs font-semibold mb-1">{label}</div>}
          <div className="text-xs whitespace-pre-wrap">{note.length > 400 ? note.slice(0, 400) + "…" : note}</div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function SortHeader({
  label,
  k,
  sortBy,
  sortDir,
  onSort,
  className,
}: {
  label: string;
  k: SortKey;
  sortBy: SortKey;
  sortDir: SortDir;
  onSort: (k: SortKey) => void;
  className?: string;
}) {
  const active = sortBy === k;
  const Icon = !active ? ArrowUpDown : sortDir === "asc" ? ArrowUp : ArrowDown;
  return (
    <TableHead className={className}>
      <button
        type="button"
        onClick={() => onSort(k)}
        className="inline-flex items-center gap-1 hover:text-foreground transition-colors"
      >
        <span>{label}</span>
        <Icon className={`h-3 w-3 ${active ? "text-primary" : "text-muted-foreground/60"}`} />
      </button>
    </TableHead>
  );
}

export default function SalesOrdersPage() {
  const qc = useQueryClient();
  const { canAction } = usePermissions();
  const canDownload = canAction("sales_orders", "download_orders");
  const [search, setSearch] = useState("");
  const [agentFilter, setAgentFilter] = useState<string>("all");
  const [zoneFilter, setZoneFilter] = useState<string>("all");
  const [tipoFilter, setTipoFilter] = useState<"all" | "negozio" | "agente">("all");

  
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [sortBy, setSortBy] = useState<SortKey>("created_at");
  const [sortDir, setSortDir] = useState<SortDir>("asc");

  const handleSort = (k: SortKey) => {
    if (sortBy === k) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortBy(k);
      setSortDir("asc");
    }
  };
  const toggleId = (id: string) =>
    setSelectedIds((prev) => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  const toggleMany = (ids: string[], on: boolean) =>
    setSelectedIds((prev) => {
      const n = new Set(prev);
      ids.forEach((id) => (on ? n.add(id) : n.delete(id)));
      return n;
    });

  const { data: rows, isLoading } = useQuery({
    queryKey: ["sales-orders-pending"],
    queryFn: async (): Promise<OrderRow[]> => {
      const { data: downloaded } = await supabase
        .from("order_download_batch_items")
        .select("order_id");
      const downloadedIds = new Set((downloaded ?? []).map((d: any) => d.order_id));

      const { data: orders, error } = await supabase
        .from("customer_orders")
        .select("id, transmission_id, codice_cliente, codice_agente, origine, total, created_at, listino, note")
        .eq("status", "trasmesso")
        .order("created_at", { ascending: true });
      if (error) throw error;
      // Defensive dedup: guarantee unique order ids reach the renderer.
      const seenIds = new Set<string>();
      const uniqueOrders = (orders ?? []).filter((o: any) => {
        if (!o?.id || seenIds.has(o.id)) return false;
        seenIds.add(o.id);
        return true;
      });
      if (uniqueOrders.length !== (orders ?? []).length) {
        console.warn(
          "[SalesOrdersPage] customer_orders query returned duplicate ids",
          { returned: orders?.length ?? 0, unique: uniqueOrders.length },
        );
      }
      const list = uniqueOrders.filter((o: any) => !downloadedIds.has(o.id));
      if (list.length === 0) return [];

      const customerCodes = Array.from(
        new Set(list.map((o) => o.codice_cliente).filter(Boolean) as string[]),
      );
      const orderIds = list.map((o) => o.id);

      const [customersRes, itemsRes] = await Promise.all([
        customerCodes.length
          ? supabase
              .from("customers")
              .select("customer_code, company_name, zone_code, original_agent_code, assigned_agent_id")
              .in("customer_code", customerCodes)
          : Promise.resolve({ data: [] as any[], error: null }),
        supabase
          .from("customer_order_items")
          .select("order_id")
          .in("order_id", orderIds),
      ]);

      const customerMap = new Map<string, { company_name: string | null; zone_code: string | null; original_agent_code: string | null; assigned_agent_id: string | null }>();
      (customersRes.data ?? []).forEach((c: any) => {
        customerMap.set(c.customer_code, {
          company_name: c.company_name,
          zone_code: c.zone_code,
          original_agent_code: c.original_agent_code,
          assigned_agent_id: c.assigned_agent_id,
        });
      });

      const effectiveAgentCode = (o: any): string | null => {
        if (o.codice_agente) return o.codice_agente;
        const c = o.codice_cliente ? customerMap.get(o.codice_cliente) : undefined;
        return c?.original_agent_code ?? null;
      };

      const agentCodes = Array.from(
        new Set(list.map((o) => effectiveAgentCode(o)).filter(Boolean) as string[]),
      );
      const assignedIds = Array.from(
        new Set(
          (customersRes.data ?? [])
            .map((c: any) => c.assigned_agent_id)
            .filter(Boolean) as string[],
        ),
      );

      const [agentsByCodeRes, agentsByIdRes] = await Promise.all([
        agentCodes.length
          ? supabase
              .from("profiles")
              .select("agent_code, full_name")
              .in("agent_code", agentCodes)
          : Promise.resolve({ data: [] as any[], error: null }),
        assignedIds.length
          ? supabase
              .from("profiles")
              .select("id, agent_code, full_name")
              .in("id", assignedIds)
          : Promise.resolve({ data: [] as any[], error: null }),
      ]);

      const agentByCode = new Map<string, string>();
      (agentsByCodeRes.data ?? []).forEach((a: any) => {
        if (a.agent_code) agentByCode.set(a.agent_code, a.full_name ?? "");
      });
      const agentById = new Map<string, { code: string | null; name: string | null }>();
      (agentsByIdRes.data ?? []).forEach((a: any) => {
        agentById.set(a.id, { code: a.agent_code, name: a.full_name });
      });

      const itemCounts = new Map<string, number>();
      (itemsRes.data ?? []).forEach((it: any) => {
        itemCounts.set(it.order_id, (itemCounts.get(it.order_id) ?? 0) + 1);
      });

      return list.map((o: any) => {
        const c = o.codice_cliente ? customerMap.get(o.codice_cliente) : undefined;
        let agentCode = effectiveAgentCode(o);
        let agentName: string | null = agentCode ? agentByCode.get(agentCode) ?? null : null;
        if (!agentCode && c?.assigned_agent_id) {
          const a = agentById.get(c.assigned_agent_id);
          agentCode = a?.code ?? null;
          agentName = a?.name ?? null;
        }
        return {
          id: o.id,
          transmission_id: o.transmission_id,
          codice_cliente: o.codice_cliente,
          codice_agente: agentCode,
          origine: o.origine ?? null,
          tipo: (o.origine === "NE" ? "negozio" : "agente") as "negozio" | "agente",
          total: o.total,
          created_at: o.created_at as string,
          righe: itemCounts.get(o.id) ?? 0,
          company_name: c?.company_name ?? null,
          zone_code: c?.zone_code ?? null,
          agent_name: agentName,
          listino: o.listino ?? null,
          note: o.note ?? null,
        };
      });
    },
  });

  // Diagnostic: log the ids that reach the renderer so we can spot any
  // residual duplication (data vs DOM) the next time a ghost row appears.
  useEffect(() => {
    if (!rows) return;
    const ids = rows.map((r) => r.id);
    const uniq = new Set(ids);
    if (uniq.size !== ids.length) {
      console.error("[SalesOrdersPage] duplicate order ids in rendered rows", ids);
    } else {
      console.debug("[SalesOrdersPage] orders ids", ids);
    }
  }, [rows]);


  const agents = useMemo(() => {
    const m = new Map<string, string>();
    (rows ?? []).forEach((r) => {
      if (r.codice_agente) m.set(r.codice_agente, r.agent_name || r.codice_agente);
    });
    return Array.from(m.entries()).sort(([a], [b]) => a.localeCompare(b));
  }, [rows]);

  const zones = useMemo(() => {
    const s = new Set<string>();
    (rows ?? []).forEach((r) => {
      if (r.zone_code) s.add(r.zone_code);
    });
    return Array.from(s).sort();
  }, [rows]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (rows ?? []).filter((r) => {
      if (agentFilter !== "all" && r.codice_agente !== agentFilter) return false;
      if (zoneFilter !== "all" && r.zone_code !== zoneFilter) return false;
      if (tipoFilter !== "all" && r.tipo !== tipoFilter) return false;
      if (!q) return true;
      return (
        r.codice_cliente?.toLowerCase().includes(q) ||
        r.company_name?.toLowerCase().includes(q) ||
        r.transmission_id?.toLowerCase().includes(q)
      );
    });
  }, [rows, search, agentFilter, zoneFilter, tipoFilter]);

  const sorted = useMemo(() => {
    const dir = sortDir === "asc" ? 1 : -1;
    const cmpStr = (a: string | null | undefined, b: string | null | undefined) =>
      (a ?? "").localeCompare(b ?? "", "it", { numeric: true, sensitivity: "base" }) * dir;
    const cmpNum = (a: number, b: number) => (a - b) * dir;
    const arr = [...filtered];
    arr.sort((a, b) => {
      switch (sortBy) {
        case "codice_cliente": return cmpStr(a.codice_cliente, b.codice_cliente);
        case "company_name": return cmpStr(a.company_name, b.company_name);
        case "zone_code": return cmpStr(a.zone_code, b.zone_code);
        case "codice_agente": return cmpStr(a.codice_agente, b.codice_agente);
        case "tipo": return cmpStr(a.tipo, b.tipo);
        case "righe": return cmpNum(a.righe, b.righe);
        case "total": return cmpNum(Number(a.total ?? 0), Number(b.total ?? 0));
        case "created_at":
        default:
          return a.created_at.localeCompare(b.created_at) * dir;
      }
    });
    return arr;
  }, [filtered, sortBy, sortDir]);

  const totals = useMemo(() => {
    const totalValue = filtered.reduce((s, r) => s + Number(r.total ?? 0), 0);
    const totalRighe = filtered.reduce((s, r) => s + r.righe, 0);
    return { count: filtered.length, value: totalValue, righe: totalRighe };
  }, [filtered]);

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShoppingCart className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-semibold">Ordini</h1>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-sm text-muted-foreground">
            Da scaricare: <span className="font-semibold text-foreground">{totals.count}</span>
            {" · "}
            <span className="font-semibold text-foreground">{fmtEuro(totals.value)}</span>
            {" · "}
            {totals.righe} righe
            {selectedIds.size > 0 && (
              <> {" · "}<span className="font-semibold text-primary">{selectedIds.size} selezionati</span></>
            )}
          </div>
          {selectedIds.size > 0 && (
            <Button variant="ghost" size="sm" onClick={() => setSelectedIds(new Set())}>
              Deseleziona
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={async () => {
              // Hard refresh: drop cached snapshots before refetching to avoid
              // stale duplicated rows lingering after a transient render glitch.
              await qc.resetQueries({ queryKey: ["sales-orders-pending"] });
              await qc.resetQueries({ queryKey: ["sales-orders-downloaded"] });
              qc.refetchQueries({ queryKey: ["sales-orders-pending"], type: "active" });
              qc.refetchQueries({ queryKey: ["sales-orders-downloaded"], type: "active" });
            }}
            disabled={isLoading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
            Aggiorna
          </Button>
          {canDownload && (
            <OrderDownloadButton count={totals.count} selectedIds={Array.from(selectedIds)} onDownloaded={() => setSelectedIds(new Set())} />
          )}
        </div>
      </div>

      <Tabs defaultValue="pending" className="space-y-4">
        <TabsList>
          <TabsTrigger value="pending">Da scaricare ({totals.count})</TabsTrigger>
          <TabsTrigger value="downloaded">Scaricati</TabsTrigger>
        </TabsList>
        <TabsContent value="pending" className="space-y-4 mt-0">


      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cerca codice, ragione sociale, n° ordine…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8"
          />
        </div>
        <Select value={tipoFilter} onValueChange={(v) => setTipoFilter(v as any)}>
          <SelectTrigger className="w-[160px]"><SelectValue placeholder="Tipo" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutti i tipi</SelectItem>
            <SelectItem value="negozio">Cliente CC</SelectItem>
            <SelectItem value="agente">Agente CA</SelectItem>
          </SelectContent>
        </Select>
        <Select value={agentFilter} onValueChange={setAgentFilter}>
          <SelectTrigger className="w-[200px]"><SelectValue placeholder="Agente" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutti gli agenti</SelectItem>
            {agents.map(([code, name]) => (
              <SelectItem key={code} value={code}>{code} · {name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={zoneFilter} onValueChange={setZoneFilter}>
          <SelectTrigger className="w-[160px]"><SelectValue placeholder="Zona" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutte le zone</SelectItem>
            {zones.map((z) => (
              <SelectItem key={z} value={z}>{z}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="flex items-center gap-2 text-muted-foreground p-8 justify-center">
          <Loader2 className="h-4 w-4 animate-spin" /> Caricamento…
        </div>
      ) : sorted.length === 0 ? (
        <div className="border rounded-md p-8 text-center text-muted-foreground">
          Nessun ordine in attesa di scarico.
        </div>
      ) : (
        <div className="border rounded-md overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-8"></TableHead>
                <TableHead className="w-8">
                  <Checkbox
                    checked={filtered.length > 0 && filtered.every((r) => selectedIds.has(r.id))}
                    onCheckedChange={(v) => toggleMany(filtered.map((r) => r.id), !!v)}
                    aria-label="Seleziona tutti"
                  />
                </TableHead>
                <SortHeader label="Codice cliente" k="codice_cliente" sortBy={sortBy} sortDir={sortDir} onSort={handleSort} />
                <SortHeader label="Ragione sociale" k="company_name" sortBy={sortBy} sortDir={sortDir} onSort={handleSort} />
                <SortHeader label="Zona" k="zone_code" sortBy={sortBy} sortDir={sortDir} onSort={handleSort} />
                <SortHeader label="Agente" k="codice_agente" sortBy={sortBy} sortDir={sortDir} onSort={handleSort} />
                <SortHeader label="Tipo" k="tipo" sortBy={sortBy} sortDir={sortDir} onSort={handleSort} />
                <SortHeader label="N° righe" k="righe" sortBy={sortBy} sortDir={sortDir} onSort={handleSort} className="text-right" />
                <SortHeader label="Data e ora trasmissione" k="created_at" sortBy={sortBy} sortDir={sortDir} onSort={handleSort} className="whitespace-nowrap" />
                <SortHeader label="Valore ordinato" k="total" sortBy={sortBy} sortDir={sortDir} onSort={handleSort} className="text-right" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {sorted.map((o) => (
                <TableRow
                  key={o.id}
                  className="cursor-pointer hover:bg-accent/40"
                  onClick={() =>
                    setSelectedOrder({
                      id: o.id,
                      transmission_id: o.transmission_id,
                      codice_cliente: o.codice_cliente,
                      company_name: o.company_name,
                      created_at: o.created_at,
                      total: o.total,
                      tipo: o.tipo,
                      zone_code: o.zone_code,
                      agent_label: o.codice_agente
                        ? `${o.codice_agente}${o.agent_name ? ` · ${o.agent_name}` : ""}`
                        : null,
                      listino: o.listino,
                    })
                  }
                >
                  <TableCell></TableCell>
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <Checkbox
                      checked={selectedIds.has(o.id)}
                      onCheckedChange={() => toggleId(o.id)}
                      aria-label="Seleziona ordine"
                    />
                  </TableCell>
                  <TableCell className="font-mono text-xs">{o.codice_cliente ?? "—"}</TableCell>
                  <TableCell>
                    <div className="inline-flex items-center gap-1.5">
                      <span>{o.company_name ?? "—"}</span>
                      {o.note && o.note.trim().length > 0 && (
                        <NoteIcon note={o.note} label="Nota ordine" />
                      )}
                    </div>
                  </TableCell>
                  <TableCell>{o.zone_code ?? "—"}</TableCell>
                  <TableCell>
                    {o.codice_agente
                      ? `${o.codice_agente}${o.agent_name ? ` · ${o.agent_name}` : ""}`
                      : "—"}
                  </TableCell>
                  <TableCell><TipoBadge tipo={o.tipo} /></TableCell>
                  <TableCell className="text-right">{o.righe}</TableCell>
                  <TableCell className="whitespace-nowrap">{fmtDate(o.created_at)}</TableCell>
                  <TableCell className="text-right">{fmtEuro(o.total)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
        </TabsContent>
        <TabsContent value="downloaded" className="mt-0">
          <DownloadedOrdersTab />
        </TabsContent>
      </Tabs>

      <OrderDetailSheet order={selectedOrder} onClose={() => setSelectedOrder(null)} />
    </div>
  );
}

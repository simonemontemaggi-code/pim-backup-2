import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronLeft, ChevronRight, Download, FileSearch, Eye } from "lucide-react";
import { downloadXlsx } from "@/lib/xlsxExport";
import { useUserDisplayNames } from "@/hooks/useUserDisplayNames";

const OP_BADGE: Record<string, string> = {
  INSERT: "bg-success text-success-foreground",
  UPDATE: "bg-warning text-warning-foreground",
  DELETE: "bg-destructive text-destructive-foreground",
};

const PAGE_SIZE = 50;

function formatDetailValue(val: unknown): string {
  if (val === null || val === undefined) return "—";
  if (typeof val === "string") return val.length > 120 ? val.slice(0, 120) + "…" : val;
  if (typeof val === "object") return JSON.stringify(val);
  return String(val);
}

export default function AdminAuditPage() {
  const [tableName, setTableName] = useState("all");
  const [operation, setOperation] = useState("all");
  const [searchRecord, setSearchRecord] = useState("");
  const [page, setPage] = useState(0);
  const [detailItem, setDetailItem] = useState<any>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["audit_log", tableName, operation, searchRecord, page],
    queryFn: async () => {
      let q = supabase.from("audit_log").select("*", { count: "estimated" }).order("created_at", { ascending: false }).range(page * PAGE_SIZE, (page + 1) * PAGE_SIZE - 1);
      if (tableName !== "all") q = q.eq("table_name", tableName);
      if (operation !== "all") q = q.eq("operation", operation);
      if (searchRecord.length >= 2) q = q.ilike("record_id", `%${searchRecord}%`);
      const { data, count, error } = await q;
      if (error) throw error;
      return { rows: data ?? [], count: count ?? 0 };
    },
  });

  const rows = data?.rows ?? [];
  const totalCount = data?.count ?? 0;
  const totalPages = Math.ceil(totalCount / PAGE_SIZE);
  const { display: displayUser } = useUserDisplayNames(rows.map((r: any) => r.user_id));

  const serializeValues = (r: any, side: "old" | "new"): string => {
    const src = side === "old" ? r.old_values : r.new_values;
    if (!src) return "";
    const fields: string[] =
      r.operation === "UPDATE"
        ? r.changed_fields ?? []
        : r.operation === "INSERT" && side === "new"
        ? Object.keys(src)
        : r.operation === "DELETE" && side === "old"
        ? Object.keys(src)
        : [];
    return fields.map((f) => `${f}=${formatDetailValue(src?.[f])}`).join("; ");
  };

  const handleExport = () => {
    const data = rows.map((r: any) => ({
      timestamp: r.created_at,
      user: displayUser(r.user_id, r.user_email),
      user_email: r.user_email,
      user_id: r.user_id,
      table_name: r.table_name,
      operation: r.operation,
      record_id: r.record_id,
      changed_fields: (r.changed_fields ?? []).join(", "),
      old_values: serializeValues(r, "old"),
      new_values: serializeValues(r, "new"),
    }));
    downloadXlsx(`audit_log_${new Date().toISOString().slice(0, 10)}.xlsx`, data, { sheetName: "Audit" });
  };

  const renderValuesCell = (r: any, side: "old" | "new") => {
    const src = side === "old" ? r.old_values : r.new_values;
    const fields: string[] =
      r.operation === "UPDATE"
        ? r.changed_fields ?? []
        : r.operation === "INSERT" && side === "new"
        ? Object.keys(src ?? {})
        : r.operation === "DELETE" && side === "old"
        ? Object.keys(src ?? {})
        : [];
    if (!fields.length || !src) return <span className="text-muted-foreground text-xs">—</span>;
    const shown = fields.slice(0, 3);
    const extra = fields.length - shown.length;
    const colorCls = side === "old" ? "text-destructive" : "text-success";
    return (
      <div className="space-y-0.5 max-w-[260px]">
        {shown.map((f) => (
          <div key={f} className="text-[11px] font-mono break-all whitespace-pre-wrap leading-tight">
            <span className="text-muted-foreground">{f}:</span>{" "}
            <span className={colorCls}>{formatDetailValue(src?.[f])}</span>
          </div>
        ))}
        {extra > 0 && <div className="text-[10px] text-muted-foreground">+{extra} altri</div>}
      </div>
    );
  };

  if (isLoading) return <div className="p-6"><Skeleton className="h-64 w-full" /></div>;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Audit Log</h1>
        <Button variant="outline" size="sm" onClick={handleExport}><Download className="mr-2 h-4 w-4" /> Esporta XLSX</Button>
      </div>

      <div className="flex gap-3 flex-wrap items-center">
        <Select value={tableName} onValueChange={(v) => { setTableName(v); setPage(0); }}>
          <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutte le tabelle</SelectItem>
            <SelectItem value="archivio_articoli_fraschetti">Articoli</SelectItem>
            <SelectItem value="archivio_fornitori_fraschetti">Fornitori</SelectItem>
            <SelectItem value="archivio_listini_fraschetti">Costario</SelectItem>
            <SelectItem value="article_media">Media</SelectItem>
          </SelectContent>
        </Select>
        <Select value={operation} onValueChange={(v) => { setOperation(v); setPage(0); }}>
          <SelectTrigger className="w-[130px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutte</SelectItem>
            <SelectItem value="INSERT">INSERT</SelectItem>
            <SelectItem value="UPDATE">UPDATE</SelectItem>
            <SelectItem value="DELETE">DELETE</SelectItem>
          </SelectContent>
        </Select>
        <div className="relative">
          <FileSearch className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input className="pl-8 w-48" placeholder="Cerca record ID..." value={searchRecord} onChange={(e) => { setSearchRecord(e.target.value); setPage(0); }} />
        </div>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Timestamp</TableHead>
            <TableHead>Utente</TableHead>
            <TableHead>Tabella</TableHead>
            <TableHead>Operazione</TableHead>
            <TableHead>Record ID</TableHead>
            <TableHead>Campi</TableHead>
            <TableHead>Valore precedente</TableHead>
            <TableHead>Nuovo valore</TableHead>
            <TableHead></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.length === 0 ? (
            <TableRow><TableCell colSpan={9} className="text-center py-8">
              <FileSearch className="mx-auto h-8 w-8 text-muted-foreground/30 mb-2" />
              <p className="text-sm text-muted-foreground">Nessun record nel log</p>
            </TableCell></TableRow>
          ) : rows.map((r: any) => (
            <TableRow key={r.id}>
              <TableCell className="text-xs">{new Date(r.created_at).toLocaleString("it-IT")}</TableCell>
              <TableCell className="text-xs">{displayUser(r.user_id, r.user_email)}</TableCell>
              <TableCell className="text-xs font-mono">{r.table_name}</TableCell>
              <TableCell><Badge className={`text-[10px] ${OP_BADGE[r.operation] ?? ""}`}>{r.operation}</Badge></TableCell>
              <TableCell className="text-xs font-mono">{r.record_id}</TableCell>
              <TableCell>
                <div className="flex gap-1 flex-wrap max-w-[180px]">
                  {(r.changed_fields ?? []).slice(0, 3).map((f: string) => (
                    <Badge key={f} variant="outline" className="text-[9px]">{f}</Badge>
                  ))}
                  {(r.changed_fields ?? []).length > 3 && <Badge variant="outline" className="text-[9px]">+{(r.changed_fields ?? []).length - 3}</Badge>}
                </div>
              </TableCell>
              <TableCell className="align-top">{renderValuesCell(r, "old")}</TableCell>
              <TableCell className="align-top">{renderValuesCell(r, "new")}</TableCell>
              <TableCell>
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setDetailItem(r)}>
                  <Eye className="h-3 w-3" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      {/* Pagination */}
      <div className="flex items-center justify-between text-sm">
        <span className="text-muted-foreground">{totalCount} record totali</span>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" disabled={page === 0} onClick={() => setPage(page - 1)}><ChevronLeft className="h-4 w-4" /> Precedente</Button>
          <span>Pagina {page + 1} di {totalPages || 1}</span>
          <Button variant="ghost" size="sm" disabled={page >= totalPages - 1} onClick={() => setPage(page + 1)}>Successiva <ChevronRight className="h-4 w-4" /></Button>
        </div>
      </div>

      {/* Detail Dialog */}
      <Dialog open={!!detailItem} onOpenChange={(o) => !o && setDetailItem(null)}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Dettaglio Modifica</DialogTitle></DialogHeader>
          {detailItem && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><strong>Record:</strong> {detailItem.record_id}</div>
                <div><strong>Tabella:</strong> {detailItem.table_name}</div>
                <div><strong>Operazione:</strong> <Badge className={OP_BADGE[detailItem.operation] ?? ""}>{detailItem.operation}</Badge></div>
                <div><strong>Utente:</strong> {displayUser(detailItem.user_id, detailItem.user_email)}</div>
              </div>
              {detailItem.operation === "UPDATE" && detailItem.changed_fields && (
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-sm">
                    <thead><tr className="bg-muted/50"><th className="p-2 text-left">Campo</th><th className="p-2 text-left">Prima</th><th className="p-2 text-left">Dopo</th></tr></thead>
                    <tbody>
                      {detailItem.changed_fields.map((field: string) => (
                        <tr key={field} className="border-t bg-warning/5">
                          <td className="p-2 font-mono text-xs font-medium">{field}</td>
                          <td className="p-2 text-xs text-destructive break-all max-w-[200px]">{formatDetailValue(detailItem.old_values?.[field])}</td>
                          <td className="p-2 text-xs text-success break-all max-w-[200px]">{formatDetailValue(detailItem.new_values?.[field])}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              {(detailItem.operation === "INSERT" || detailItem.operation === "DELETE") && (
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full text-sm">
                    <thead><tr className="bg-muted/50"><th className="p-2 text-left">Campo</th><th className="p-2 text-left">Valore</th></tr></thead>
                    <tbody>
                      {Object.entries((detailItem.operation === "INSERT" ? detailItem.new_values : detailItem.old_values) ?? {}).map(([key, val]) => (
                        <tr key={key} className="border-t">
                          <td className="p-2 font-mono text-xs font-medium whitespace-nowrap">{key}</td>
                          <td className="p-2 text-xs break-all max-w-[400px]">{formatDetailValue(val)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

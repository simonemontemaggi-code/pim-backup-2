import { useState, useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Select, SelectContent, SelectItem, SelectTrigger } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Lock, Eye, Pencil, EyeOff, ChevronRight, ChevronDown, CornerDownRight, Plus, Trash2, Globe, CheckCircle2, Download } from "lucide-react";
import { SECTION_FIELDS } from "@/lib/fieldDefinitions";

// Azioni granulari disponibili (oltre a read/write/hidden della sezione)
const ACTIONS = [
  { key: "create", label: "Crea", icon: Plus },
  { key: "delete", label: "Elimina", icon: Trash2 },
  { key: "publish", label: "Pubblica", icon: Globe },
  { key: "confirm_payment", label: "Conferma pagamento", icon: CheckCircle2 },
  { key: "download_orders", label: "Scarica ordini", icon: Download },
] as const;

type ActionKey = typeof ACTIONS[number]["key"];

// Per ogni sezione, quali azioni mostrare. Sezioni assenti = nessuna azione granulare.
const SECTION_ACTIONS: Record<string, ReadonlyArray<ActionKey>> = {
  articles_registry: ["create", "delete", "publish"],
  suppliers: ["create", "delete", "publish"],
  promo_strutturate: ["create", "delete", "publish"],
  b2b_brands: ["create", "delete", "publish"],
  b2b_catalogs: ["create", "delete", "publish"],
  b2b_hero_slider: ["create", "delete", "publish"],
  b2b_promo_settori: ["create", "delete", "publish"],
  b2b_assortments: ["create", "delete", "publish"],
  b2b_novita: ["create", "delete", "publish"],
  b2b_taxonomy: ["create", "delete", "publish"],
  b2b_promo_order: ["create", "delete", "publish"],
  b2b_communications: ["create", "delete", "publish"],
  agent_news: ["create", "delete", "publish"],
  scadenziario: ["confirm_payment"],
  sales_orders: ["create", "download_orders"],
};

// Struttura allineata alla sidebar del PIM (src/components/layout/PimSidebar.tsx)
type NavGroup = { label: string; sections: string[] };

const NAV_STRUCTURE: NavGroup[] = [
  {
    label: "Generale",
    sections: ["pim_dashboard"],
  },
  {
    label: "Catalogo",
    sections: [
      "articles_registry",
      "articles_units",
      "articles_purchase",
      "articles_pricing",
      "articles_marketing",
      "articles_logistics",
      "barcodes",
      "price_lists",
      "suppliers",
      "promo_strutturate",
      "media_library",
    ],
  },
  {
    label: "Anagrafiche",
    sections: ["customers", "customer_requests", "agents"],
  },
  {
    label: "Vendite",
    sections: ["sales_dashboard", "sales_orders", "sales_untreated", "purchases_untreated"],
  },
  {
    label: "Marketing B2B",
    sections: [
      "b2b_brands",
      "b2b_taxonomy",
      "b2b_hero_slider",
      "b2b_promo_settori",
      "b2b_assortments",
      "b2b_novita",
      "b2b_catalogs",
      "b2b_promo_order",
      "b2b_communications",
      "agent_news",
    ],
  },
  {
    label: "Analytics",
    sections: ["navigation_analysis", "portal_adoption"],
  },
  {
    label: "Operazioni",
    sections: [
      "as400_sync",
      "import_export",
      "import_una_tantum",
      "import_documentazione",
      "import_giornaliera",
      "import_clienti",
      "import_assortimenti",
      "import_temp",
      "operations_controls",
      "controls_articoli_content",
      "controls_articoli_classificazione",
      "controls_fornitori_brand",
      "controls_prezzi",
    ],
  },
  {
    label: "Amministrazione",
    sections: ["scadenziario"],
  },
  {
    label: "Impostazioni",
    sections: ["users_admin"],
  },
];


const isITDept = (name: string) => {
  const n = name.toLowerCase().trim();
  return n.includes("digital") || n === "it" || n.startsWith("it ") || n.endsWith(" it");
};

const PERM_OPTIONS = [
  { value: "hidden", icon: EyeOff, label: "Nascosto" },
  { value: "read", icon: Eye, label: "Lettura" },
  { value: "write", icon: Pencil, label: "Scrittura" },
];

const FIELD_PERM_OPTIONS = [
  { value: "inherit", icon: CornerDownRight, label: "Eredita" },
  ...PERM_OPTIONS,
];

const PermIcon = ({ value }: { value: string }) => {
  const all = [...FIELD_PERM_OPTIONS];
  const opt = all.find((o) => o.value === value);
  if (!opt) return null;
  const Icon = opt.icon;
  return <Icon className="h-3.5 w-3.5" />;
};


type RoleKey = "manager" | "assistant_manager" | "collaborator" | "viewer";
const ROLE_TABS: { key: RoleKey; label: string }[] = [
  { key: "manager", label: "Manager" },
  { key: "assistant_manager", label: "Assistant Manager" },
  { key: "collaborator", label: "Collaboratore" },
  { key: "viewer", label: "Viewer" },
];

export default function AdminPermissionsPage() {
  const queryClient = useQueryClient();
  const [savedMsg, setSavedMsg] = useState("");
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [role, setRole] = useState<RoleKey>("manager");

  const { data: departments = [], isLoading: loadingDepts } = useQuery({
    queryKey: ["departments"],
    queryFn: async () => {
      const { data } = await supabase.from("departments").select("id, name").order("name");
      return data ?? [];
    },
  });

  const { data: permsMap = {}, isLoading: loadingPerms } = useQuery({
    queryKey: ["section_permissions_matrix", role],
    queryFn: async () => {
      const { data } = await supabase.from("section_permissions").select("*").eq("role", role as any);
      const map: Record<string, Record<string, string>> = {};
      (data ?? []).forEach((p: any) => {
        if (!map[p.department_id]) map[p.department_id] = {};
        map[p.department_id][p.section_key] = p.permission;
      });
      return map;
    },
  });

  const { data: fieldPermsMap = {} } = useQuery({
    queryKey: ["field_permissions_matrix", role],
    queryFn: async () => {
      const { data } = await supabase.from("field_permissions").select("*").eq("role", role as any);
      const map: Record<string, Record<string, Record<string, string>>> = {};
      (data ?? []).forEach((p: any) => {
        if (!map[p.department_id]) map[p.department_id] = {};
        if (!map[p.department_id][p.section_key]) map[p.department_id][p.section_key] = {};
        map[p.department_id][p.section_key][p.field_key] = p.permission;
      });
      return map;
    },
  });

  const { data: actionPermsMap = {} } = useQuery({
    queryKey: ["section_action_permissions_matrix", role],
    queryFn: async () => {
      const { data } = await (supabase as any).from("section_action_permissions").select("*").eq("role", role);
      const map: Record<string, Record<string, Record<string, boolean>>> = {};
      (data ?? []).forEach((p: any) => {
        if (!map[p.department_id]) map[p.department_id] = {};
        if (!map[p.department_id][p.section]) map[p.department_id][p.section] = {};
        map[p.department_id][p.section][p.action] = !!p.allowed;
      });
      return map;
    },
  });


  // Lookup map (sectionKey -> SectionFields def) e gestione "orfani"
  const { sectionMap, groups } = useMemo(() => {
    const map = new Map<string, any>();
    SECTION_FIELDS.forEach((s) => map.set(s.key, s));

    const placed = new Set<string>();
    NAV_STRUCTURE.forEach((g) => g.sections.forEach((k) => placed.add(k)));
    const orphans = SECTION_FIELDS.filter((s) => !placed.has(s.key)).map((s) => s.key);

    const finalGroups: NavGroup[] = orphans.length
      ? [...NAV_STRUCTURE, { label: "Altro", sections: orphans }]
      : NAV_STRUCTURE;

    // tieni solo gruppi con almeno una sezione esistente in SECTION_FIELDS
    return {
      sectionMap: map,
      groups: finalGroups
        .map((g) => ({ ...g, sections: g.sections.filter((k) => map.has(k)) }))
        .filter((g) => g.sections.length > 0),
    };
  }, []);

  const isOpen = (k: string) => expanded.has(k);
  const toggle = (k: string) =>
    setExpanded((prev) => {
      const n = new Set(prev);
      n.has(k) ? n.delete(k) : n.add(k);
      return n;
    });

  const handleActionChange = async (deptId: string, section: string, action: string, allowed: boolean) => {
    const { data: existing } = await (supabase as any)
      .from("section_action_permissions")
      .select("id")
      .eq("department_id", deptId)
      .eq("role", role)
      .eq("section", section)
      .eq("action", action);

    if (existing && existing.length > 0) {
      await (supabase as any).from("section_action_permissions").update({ allowed }).eq("id", existing[0].id);
    } else {
      await (supabase as any).from("section_action_permissions").insert({ department_id: deptId, role, section, action, allowed });
    }
    queryClient.invalidateQueries({ queryKey: ["section_action_permissions_matrix", role] });
    flash();
  };

  const flash = () => {
    setSavedMsg("Salvato ✓");
    setTimeout(() => setSavedMsg(""), 2000);
  };

  const handleSectionChange = async (deptId: string, sectionKey: string, newPerm: string) => {
    const { data: existing } = await supabase
      .from("section_permissions")
      .select("id")
      .eq("department_id", deptId)
      .eq("role", role as any)
      .eq("section_key", sectionKey);

    if (existing && existing.length > 0) {
      await supabase.from("section_permissions").update({ permission: newPerm } as any).eq("id", existing[0].id);
    } else {
      await supabase.from("section_permissions").insert({ department_id: deptId, role, section_key: sectionKey, permission: newPerm } as any);
    }

    queryClient.invalidateQueries({ queryKey: ["section_permissions_matrix", role] });
    flash();
  };

  const handleFieldChange = async (deptId: string, sectionKey: string, fieldKey: string, newPerm: string) => {
    if (newPerm === "inherit") {
      await supabase
        .from("field_permissions")
        .delete()
        .eq("department_id", deptId)
        .eq("role", role as any)
        .eq("section_key", sectionKey)
        .eq("field_key", fieldKey);
    } else {
      const { data: existing } = await supabase
        .from("field_permissions")
        .select("id")
        .eq("department_id", deptId)
        .eq("role", role as any)
        .eq("section_key", sectionKey)
        .eq("field_key", fieldKey);

      if (existing && existing.length > 0) {
        await supabase.from("field_permissions").update({ permission: newPerm } as any).eq("id", existing[0].id);
      } else {
        await supabase.from("field_permissions").insert({
          department_id: deptId,
          role,
          section_key: sectionKey,
          field_key: fieldKey,
          permission: newPerm,
        } as any);
      }
    }

    queryClient.invalidateQueries({ queryKey: ["field_permissions_matrix", role] });
    flash();
  };


  if (loadingDepts || loadingPerms) return <div className="p-6"><Skeleton className="h-64 w-full" /></div>;

  const colCount = 1 + departments.length;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Matrice Permessi</h1>
        {savedMsg && <Badge className="bg-green-600 text-white animate-pulse">{savedMsg}</Badge>}
      </div>

      <div className="flex items-center gap-2">
        <span className="text-xs text-muted-foreground mr-1">Ruolo:</span>
        {ROLE_TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setRole(t.key)}
            className={`px-3 py-1.5 rounded-md text-xs font-medium border transition-colors ${
              role === t.key
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-background text-muted-foreground hover:bg-muted"
            }`}
          >
            {t.label}
          </button>
        ))}
        <span className="ml-3 text-[11px] text-muted-foreground">
          Admin ha sempre permessi pieni e non è configurabile qui.
        </span>
      </div>

      <div className="flex gap-4 text-sm text-muted-foreground mb-4 flex-wrap">
        <span className="flex items-center gap-1"><EyeOff className="h-3 w-3" /> Nascosto</span>
        <span className="flex items-center gap-1"><Eye className="h-3 w-3" /> Lettura</span>
        <span className="flex items-center gap-1"><Pencil className="h-3 w-3" /> Scrittura</span>
        <span className="flex items-center gap-1 border-l pl-4"><CornerDownRight className="h-3 w-3" /> Eredita (campo)</span>
        <span className="flex items-center gap-1 border-l pl-4 text-xs">Struttura allineata al menu laterale: gruppo → sezione → Azioni / Campi</span>
      </div>


      <div className="overflow-auto border rounded-lg max-h-[calc(100vh-220px)] relative">
        <table className="w-full text-sm border-separate border-spacing-0">
          <thead>
            <tr>
              <th className="text-left p-3 font-medium min-w-[260px] sticky top-0 left-0 z-30 bg-muted border-b border-r">Sezione / Campo</th>
              {departments.map((dept: any) => (
                <th key={dept.id} className="text-center p-2 font-medium text-xs min-w-[110px] sticky top-0 z-20 bg-muted border-b">
                  <span className="flex items-center justify-center gap-1">
                    {dept.name}
                    {isITDept(dept.name) && <Lock className="h-3 w-3 text-muted-foreground" />}
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {groups.map((group) => {
              const groupKey = `g:${group.label}`;
              const groupOpen = isOpen(groupKey);
              return (
                <GroupBlock
                  key={groupKey}
                  group={group}
                  groupKey={groupKey}
                  groupOpen={groupOpen}
                  colCount={colCount}
                  sectionMap={sectionMap}
                  departments={departments}
                  permsMap={permsMap}
                  fieldPermsMap={fieldPermsMap}
                  actionPermsMap={actionPermsMap}
                  isOpen={isOpen}
                  toggle={toggle}
                  onSectionChange={handleSectionChange}
                  onFieldChange={handleFieldChange}
                  onActionChange={handleActionChange}
                />
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ----- Group level 1 -----
function GroupBlock(props: {
  group: NavGroup;
  groupKey: string;
  groupOpen: boolean;
  colCount: number;
  sectionMap: Map<string, any>;
  departments: any[];
  permsMap: Record<string, Record<string, string>>;
  fieldPermsMap: Record<string, Record<string, Record<string, string>>>;
  actionPermsMap: Record<string, Record<string, Record<string, boolean>>>;
  isOpen: (k: string) => boolean;
  toggle: (k: string) => void;
  onSectionChange: (d: string, s: string, p: string) => void;
  onFieldChange: (d: string, s: string, f: string, p: string) => void;
  onActionChange: (d: string, s: string, a: string, allowed: boolean) => void;
}) {
  const { group, groupKey, groupOpen, colCount, sectionMap, departments } = props;
  return (
    <>
      <tr>
        <td
          colSpan={colCount}
          className="sticky left-0 z-10 bg-primary/10 border-t border-b border-primary/20 px-3 py-2 cursor-pointer hover:bg-primary/15"
          onClick={() => props.toggle(groupKey)}
        >
          <div className="flex items-center gap-2 font-semibold text-sm uppercase tracking-wide">
            {groupOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            {group.label}
            <Badge variant="secondary" className="text-[10px]">{group.sections.length}</Badge>
          </div>
        </td>
      </tr>
      {groupOpen && group.sections.map((secKey) => {
        const sec = sectionMap.get(secKey);
        if (!sec) return null;
        return (
          <SectionBlock
            key={`${groupKey}:${secKey}`}
            sec={sec}
            parentKey={groupKey}
            colCount={colCount}
            departments={departments}
            permsMap={props.permsMap}
            fieldPermsMap={props.fieldPermsMap}
            actionPermsMap={props.actionPermsMap}
            isOpen={props.isOpen}
            toggle={props.toggle}
            onSectionChange={props.onSectionChange}
            onFieldChange={props.onFieldChange}
            onActionChange={props.onActionChange}
          />
        );
      })}
    </>
  );
}

// ----- Section level 2 -----
function SectionBlock(props: {
  sec: any;
  parentKey: string;
  colCount: number;
  departments: any[];
  permsMap: Record<string, Record<string, string>>;
  fieldPermsMap: Record<string, Record<string, Record<string, string>>>;
  actionPermsMap: Record<string, Record<string, Record<string, boolean>>>;
  isOpen: (k: string) => boolean;
  toggle: (k: string) => void;
  onSectionChange: (d: string, s: string, p: string) => void;
  onFieldChange: (d: string, s: string, f: string, p: string) => void;
  onActionChange: (d: string, s: string, a: string, allowed: boolean) => void;
}) {
  const { sec, parentKey, colCount, departments, permsMap } = props;
  const secKey = `${parentKey}:s:${sec.key}`;
  const actionsKey = `${secKey}:actions`;
  const fieldsKey = `${secKey}:fields`;
  const actions = SECTION_ACTIONS[sec.key] ?? [];
  const hasActions = actions.length > 0;
  const hasFields = !!sec.fields && sec.fields.length > 0;
  const expandable = hasActions || hasFields;
  const open = props.isOpen(secKey);

  return (
    <>
      <tr>
        <td className="p-2 pl-6 sticky left-0 z-10 bg-muted/40 border-t border-r">
          {expandable ? (
            <button className="flex items-center gap-1.5 hover:text-primary w-full text-left" onClick={() => props.toggle(secKey)}>
              {open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              <span className="font-medium">{sec.label}</span>
              <span className="flex items-center gap-1 ml-1">
                {hasActions && <Badge variant="outline" className="text-[10px]">{actions.length} az.</Badge>}
                {hasFields && <Badge variant="secondary" className="text-[10px]">{sec.fields.length} campi</Badge>}
              </span>
            </button>
          ) : (
            <span className="pl-5 font-medium">{sec.label}</span>
          )}
        </td>
        {departments.map((dept: any) => {
          const isIT = isITDept(dept.name);
          const currentPerm = permsMap[dept.id]?.[sec.key] ?? "hidden";
          return (
            <td key={dept.id} className="p-2 text-center bg-muted/20 border-t">
              {isIT ? (
                <Badge className="bg-green-600/20 text-green-700 text-[10px]">
                  <Lock className="h-2.5 w-2.5" />
                </Badge>
              ) : (
                <Select value={currentPerm} onValueChange={(v) => props.onSectionChange(dept.id, sec.key, v)}>
                  <SelectTrigger className="h-7 w-[50px] mx-auto flex items-center justify-center">
                    <PermIcon value={currentPerm} />
                  </SelectTrigger>
                  <SelectContent>
                    {PERM_OPTIONS.map((o) => {
                      const Icon = o.icon;
                      return (
                        <SelectItem key={o.value} value={o.value} className="text-xs">
                          <span className="flex items-center gap-1.5"><Icon className="h-3.5 w-3.5" /> {o.label}</span>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              )}
            </td>
          );
        })}
      </tr>

      {open && hasActions && (
        <SubHeader
          label="Azioni"
          subKey={actionsKey}
          count={actions.length}
          colCount={colCount}
          isOpen={props.isOpen}
          toggle={props.toggle}
        />
      )}
      {open && hasActions && props.isOpen(actionsKey) && actions.map((aKey) => {
        const act = ACTIONS.find((a) => a.key === aKey)!;
        const ActIcon = act.icon;
        return (
          <tr key={`${actionsKey}:${aKey}`}>
            <td className="p-1.5 pl-16 text-[11px] text-muted-foreground sticky left-0 z-10 bg-background border-r border-t border-dashed">
              <span className="flex items-center gap-1.5">
                <ActIcon className="h-3 w-3 text-muted-foreground/70" />
                {act.label}
              </span>
            </td>
            {departments.map((dept: any) => {
              const isIT = isITDept(dept.name);
              if (isIT) return <td key={dept.id} className="p-1 text-center border-t border-dashed"><span className="text-[10px] text-muted-foreground">—</span></td>;
              const sectionPerm = permsMap[dept.id]?.[sec.key] ?? "hidden";
              const hasWrite = sectionPerm === "write";
              const override = props.actionPermsMap[dept.id]?.[sec.key]?.[act.key];
              const effective = typeof override === "boolean" ? override : hasWrite;
              const disabled = sectionPerm === "hidden";
              return (
                <td key={dept.id} className="p-1 text-center border-t border-dashed">
                  <button
                    disabled={disabled}
                    onClick={() => props.onActionChange(dept.id, sec.key, act.key, !effective)}
                    className={`h-6 w-6 rounded mx-auto flex items-center justify-center transition-colors ${
                      disabled ? "opacity-30 cursor-not-allowed" :
                      effective ? "bg-primary text-primary-foreground hover:bg-primary/80" :
                      "bg-muted text-muted-foreground hover:bg-muted/70"
                    }`}
                    title={`${act.label}: ${effective ? "consentito" : "negato"}${typeof override === "boolean" ? " (override)" : " (default da Scrittura)"}`}
                  >
                    <ActIcon className="h-3 w-3" />
                  </button>
                </td>
              );
            })}
          </tr>
        );
      })}

      {open && hasFields && (
        <SubHeader
          label="Campi"
          subKey={fieldsKey}
          count={sec.fields.length}
          colCount={colCount}
          isOpen={props.isOpen}
          toggle={props.toggle}
        />
      )}
      {open && hasFields && props.isOpen(fieldsKey) && sec.fields.map((field: any) => (
        <tr key={`${fieldsKey}:${field.key}`}>
          <td className="p-2 pl-16 text-xs text-muted-foreground sticky left-0 z-10 bg-background border-r border-t border-dashed">
            <span className="flex items-center gap-1.5">
              <CornerDownRight className="h-3 w-3 text-muted-foreground/50" />
              {field.label}
            </span>
          </td>
          {departments.map((dept: any) => {
            const isIT = isITDept(dept.name);
            if (isIT) return <td key={dept.id} className="p-1 text-center border-t border-dashed"><span className="text-[10px] text-muted-foreground">—</span></td>;
            const fieldPerm = props.fieldPermsMap[dept.id]?.[sec.key]?.[field.key] ?? "inherit";
            return (
              <td key={dept.id} className="p-1 text-center border-t border-dashed">
                <Select value={fieldPerm} onValueChange={(v) => props.onFieldChange(dept.id, sec.key, field.key, v)}>
                  <SelectTrigger className="h-6 w-[50px] mx-auto flex items-center justify-center text-xs">
                    <PermIcon value={fieldPerm} />
                  </SelectTrigger>
                  <SelectContent>
                    {FIELD_PERM_OPTIONS.map((o) => {
                      const Icon = o.icon;
                      return (
                        <SelectItem key={o.value} value={o.value} className="text-xs">
                          <span className="flex items-center gap-1.5"><Icon className="h-3 w-3" /> {o.label}</span>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </td>
            );
          })}
        </tr>
      ))}
    </>
  );
}

function SubHeader({
  label, subKey, count, colCount, isOpen, toggle,
}: { label: string; subKey: string; count: number; colCount: number; isOpen: (k: string) => boolean; toggle: (k: string) => void }) {
  const open = isOpen(subKey);
  return (
    <tr>
      <td
        colSpan={colCount}
        className="sticky left-0 z-10 bg-muted/60 border-t px-3 py-1 pl-12 cursor-pointer hover:bg-muted/80"
        onClick={() => toggle(subKey)}
      >
        <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
          {open ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
          {label}
          <Badge variant="outline" className="text-[10px]">{count}</Badge>
        </div>
      </td>
    </tr>
  );
}

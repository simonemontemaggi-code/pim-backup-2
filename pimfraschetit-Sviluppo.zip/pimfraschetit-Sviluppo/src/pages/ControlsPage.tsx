import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import {
  Activity,
  Image as ImageIcon,
  FileText,
  FileBadge,
  ListChecks,
  FolderTree,
  Layers,
  Users,
  UserCog,
  Award,
  AlertTriangle,
  CalendarClock,
  Euro,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useQuery } from "@tanstack/react-query";
import { useControlsFilter, CONTROLS_FILTER_OPTIONS, CONTROLS_FILTER_DEFAULTS } from "@/hooks/useControlsFilter";
import { supabase } from "@/integrations/supabase/client";
import { useOnlineAssortments, buildOnlineB2bOrFilter } from "@/hooks/useOnlineAssortments";
import { useActivePriceList } from "@/hooks/useActivePriceList";
import { useControlCounts } from "@/hooks/useControlCounts";
import { MiniControlCard } from "@/components/controls/MiniControlCard";
import { Skeleton } from "@/components/ui/skeleton";
import { usePermissions } from "@/lib/permissions";

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-2 mt-4">
      <h2 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{children}</h2>
      <div className="h-px flex-1 bg-border" />
    </div>
  );
}

function PrezziAttesaCard() {
  const { data: activeList } = useActivePriceList();
  const { data: count, isLoading } = useQuery({
    queryKey: ["controls", "prezzi_attesa_count", activeList],
    enabled: !!activeList,
    staleTime: 60_000,
    queryFn: async () => {
      const { count, error } = await supabase
        .from("prezzi_in_attesa" as any)
        .select("*", { count: "exact", head: true })
        .eq("wvaef", "M")
        .eq("wcdls", activeList!);
      if (error) throw error;
      return count ?? 0;
    },
  });
  return (
    <MiniControlCard
      title="Prezzi in attesa (M)"
      icon={CalendarClock}
      count={count ?? 0}
      href="/pim/controls/prezzi-attesa"
      loading={isLoading}
      invertGood
      subtitle={activeList ? `Listino ${activeList}` : "—"}
    />
  );
}

function B2bSenzaPrezzoCard() {
  const { data: activeList } = useActivePriceList();
  const { data: onlineAssortments = [] } = useOnlineAssortments();
  const orFilter = buildOnlineB2bOrFilter(onlineAssortments);
  const { data, isLoading } = useQuery({
    queryKey: ["controls", "b2b_senza_prezzo_minicount_rpc", activeList, onlineAssortments.join(",")],
    enabled: !!activeList,
    staleTime: 60_000,
    queryFn: async () => {
      // Count articoli b2b online (auto da wfuas + override manuali)
      const { count: total } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("*", { count: "exact", head: true })
        .or(orFilter);

      // Paginiamo i cdpar b2b online
      const PAGE = 1000;
      const cdpars: string[] = [];
      let from = 0;
      while (true) {
        const { data, error } = await supabase
          .from("archivio_articoli_fraschetti")
          .select("cdpar")
          .or(orFilter)
          .order("cdpar")
          .range(from, from + PAGE - 1);
        if (error) throw error;
        const rows = data ?? [];
        rows.forEach((r: any) => cdpars.push((r.cdpar ?? "").trim()));
        if (rows.length < PAGE) break;
        from += PAGE;
      }
      if (!cdpars.length) return { total: total ?? 0, mancanti: 0 };

      // Stessa RPC del B2B Mockup
      const CHUNK = 500;
      let mancanti = 0;
      for (let i = 0; i < cdpars.length; i += CHUNK) {
        const slice = cdpars.slice(i, i + CHUNK);
        const { data, error } = await supabase.rpc("pim_prezzo_listino_batch" as any, {
          _cdpars: slice,
          _cdls: activeList!,
        });
        if (error) throw error;
        (data ?? []).forEach((r: any) => {
          const p = r?.prezzo;
          if (p == null || Number(p) <= 0) mancanti++;
        });
      }
      return { total: total ?? 0, mancanti };
    },
  });

  return (
    <MiniControlCard
      title="B2B online senza prezzo"
      icon={AlertTriangle}
      count={data?.mancanti ?? 0}
      total={data?.total}
      href="/pim/controls/b2b-senza-prezzo"
      loading={isLoading}
      invertGood
      subtitle={activeList ? `Listino ${activeList}` : ""}
    />
  );
}

// I settori validi sono i clmer >= 11 (codici < 11 = legacy da riclassificare)

export default function ControlsPage() {
  const { selected: selectedFilters, toggle: toggleFilter, reset: resetFilters } = useControlsFilter();
  const [onlyOnlineClass, setOnlyOnlineClass] = useState<boolean>(() => {
    try { return localStorage.getItem("controls.classificazione.onlyOnline") === "1"; } catch { return false; }
  });
  useEffect(() => {
    try { localStorage.setItem("controls.classificazione.onlyOnline", onlyOnlineClass ? "1" : "0"); } catch {}
  }, [onlyOnlineClass]);
  const { data: counts, isLoading } = useControlCounts(selectedFilters);
  const { data: countsOnline, isLoading: isLoadingOnline } = useControlCounts(selectedFilters, onlyOnlineClass);
  const total = counts?.total;
  const classCounts = onlyOnlineClass ? countsOnline : counts;
  const classTotal = onlyOnlineClass ? countsOnline?.total : total;
  const classLoading = onlyOnlineClass ? isLoadingOnline : isLoading;
  const { sectionVisible } = usePermissions();
  const showContent = sectionVisible("controls_articoli_content");
  const showClass = sectionVisible("controls_articoli_classificazione");
  const showForn = sectionVisible("controls_fornitori_brand");
  const showPrezzi = sectionVisible("controls_prezzi");
  const anyVisible = showContent || showClass || showForn || showPrezzi;


  return (
    <div className="p-6 space-y-3">
      <div>
        <h1 className="text-2xl font-semibold flex items-center gap-2">
          <Activity className="h-6 w-6 text-primary" />
          Controlli & Verifiche
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Dashboard di completezza: ogni card mostra il numero di entità da sistemare. Click per il dettaglio.
        </p>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs font-medium text-muted-foreground mr-1">Assortimenti:</span>
        {CONTROLS_FILTER_OPTIONS.map((code) => {
          const active = selectedFilters.includes(code);
          return (
            <button
              key={code}
              type="button"
              onClick={() => toggleFilter(code)}
              className={`h-7 min-w-[2rem] px-2 rounded-md text-xs font-semibold border transition-colors ${
                active
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-background text-muted-foreground border-border hover:bg-accent"
              }`}
            >
              {code}
            </button>
          );
        })}
        <button
          type="button"
          onClick={resetFilters}
          className="ml-2 text-xs text-muted-foreground hover:text-foreground underline"
        >
          Reset
        </button>
      </div>

      {!anyVisible && (
        <div className="rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">
          Nessun controllo abilitato per il tuo reparto. Contatta l'amministratore.
        </div>
      )}

      {showContent && (<>
      <SectionTitle>Articoli</SectionTitle>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
        <MiniControlCard
          title="Senza immagine"
          icon={ImageIcon}
          count={counts?.no_image}
          total={total}
          href="/pim/controls/articoli/senza-immagine"
          loading={isLoading}
        />
        <MiniControlCard
          title="Senza titolo prodotto"
          icon={FileText}
          count={counts?.no_desc}
          total={total}
          href="/pim/controls/articoli/senza-descrizione"
          loading={isLoading}
        />
        <MiniControlCard
          title="Senza scheda tecnica"
          icon={FileBadge}
          count={counts?.no_st}
          total={total}
          href="/pim/controls/articoli/senza-scheda-tecnica"
          loading={isLoading}
        />
        <MiniControlCard
          title="Senza attributi obbligatori"
          icon={ListChecks}
          count={counts?.no_attr}
          total={total}
          href="/pim/controls/articoli/senza-attributi-obbligatori"
          loading={isLoading}
        />
        <MiniControlCard
          title="Senza attributi (nessuno)"
          icon={ListChecks}
          count={counts?.no_attr_any}
          total={total}
          href="/pim/controls/articoli/senza-attributi"
          loading={isLoading}
        />
        <MiniControlCard
          title="Senza listino"
          icon={Euro}
          count={counts?.no_listino}
          total={total}
          href="/pim/controls/articoli/senza-listino"
          loading={isLoading}
        />
      </div>
      </>)}

      {showClass && (<>
      <SectionTitle>Classificazione</SectionTitle>
      <div className="flex items-center justify-between gap-2 -mt-1 mb-1">
        <p className="text-[11px] text-muted-foreground">
          Settore → Reparto → Gamma. Gli articoli senza settore (clmer 1-9 o vuoto) vengono conteggiati anche come senza reparto e senza gamma, perché non possono averli.
        </p>
        <div className="flex items-center gap-2 shrink-0">
          <Label htmlFor="only-online-class" className="text-xs text-muted-foreground cursor-pointer">
            Solo B2B online
          </Label>
          <Switch
            id="only-online-class"
            checked={onlyOnlineClass}
            onCheckedChange={setOnlyOnlineClass}
          />
        </div>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
        <MiniControlCard
          title="Senza settore (da riclassificare)"
          icon={AlertTriangle}
          count={classCounts?.clmer_legacy}
          total={classTotal}
          href="/pim/controls/articoli/clmer-legacy"
          loading={classLoading}
        />
        <MiniControlCard
          title="Senza reparto"
          icon={FolderTree}
          count={classCounts?.no_reparto}
          total={classTotal}
          href="/pim/controls/articoli/senza-reparto"
          loading={classLoading}
        />
        <MiniControlCard
          title="Senza gamma"
          icon={Layers}
          count={classCounts?.no_gamma}
          total={classTotal}
          href="/pim/controls/articoli/senza-gamma"
          loading={classLoading}
        />
      </div>

      <div className="mt-2">
        <h3 className="text-[11px] uppercase tracking-wide text-muted-foreground mb-1">Settori (clmer ≥ 11){onlyOnlineClass ? " · solo B2B online" : ""}</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-2">
          {(classCounts?.settori ?? []).map((s) => (
            <MiniControlCard
              key={s.code}
              title={`${s.code} · ${s.label}`}
              icon={Layers}
              count={s.count}
              total={classTotal}
              href={`/pim/controls/articoli/settore/${s.code}`}
              loading={classLoading}
              invertGood={false}

            />
          ))}
        </div>
      </div>
      </>)}

      {showForn && (<>
      <SectionTitle>Fornitori &amp; Brand</SectionTitle>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
        <MiniControlCard
          title="Fornitori senza buyer"
          icon={Users}
          count={counts?.forn_no_buyer}
          href="/pim/controls/fornitori/senza-buyer"
          loading={isLoading}
        />
        <MiniControlCard
          title="Fornitori senza demand planner"
          icon={UserCog}
          count={counts?.forn_no_dp}
          href="/pim/controls/fornitori/senza-demand-planner"
          loading={isLoading}
        />
        <MiniControlCard
          title="Brand senza immagini"
          icon={Award}
          count={counts?.brand_no_img}
          href="/pim/controls/brand/senza-immagini"
          loading={isLoading}
        />
      </div>
      </>)}

      {showPrezzi && (<>
      <SectionTitle>Prezzi</SectionTitle>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
        <PrezziAttesaCard />
        <B2bSenzaPrezzoCard />
      </div>
      </>)}

      {isLoading && anyVisible && (
        <div className="pt-4">
          <Skeleton className="h-3 w-32" />
        </div>
      )}

    </div>
  );
}

import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/lib/permissions";
import { computeNetPrice } from "@/lib/priceUtils";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Plus, Search, ListFilter } from "lucide-react";

const PAGE_SIZE = 50;

function todayAsNumber(): number {
  const d = new Date();
  return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
}

export default function PriceListsPage() {
  const navigate = useNavigate();
  const { can } = usePermissions();
  const canWrite = can("write", "price_lists");
  const queryClient = useQueryClient();

  const [search, setSearch] = useState("");
  const [filterCdfor, setFilterCdfor] = useState<string>("__all__");
  const [onlyActive, setOnlyActive] = useState(false);
  const [page, setPage] = useState(0);
  const [addOpen, setAddOpen] = useState(false);
  const [newRow, setNewRow] = useState<Record<string, any>>({});

  // Fetch suppliers for dropdown + name lookup
  const { data: suppliers = [] } = useQuery({
    queryKey: ["suppliers_lookup"],
    queryFn: async () => {
      const { data } = await supabase
        .from("archivio_fornitori_fraschetti")
        .select("cdfor,rasfo")
        .order("cdfor");
      return data ?? [];
    },
    staleTime: 120_000,
  });
  const supplierMap = useMemo(() => {
    const m: Record<string, string> = {};
    suppliers.forEach((s: any) => { m[s.cdfor] = s.rasfo ?? s.cdfor; });
    return m;
  }, [suppliers]);

  // Fetch articles for depar lookup
  const { data: articleMap = {} } = useQuery({
    queryKey: ["articles_depar_lookup"],
    queryFn: async () => {
      const { data } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar,depar");
      const m: Record<string, string> = {};
      (data ?? []).forEach((a: any) => { m[a.cdpar] = a.depar ?? ""; });
      return m;
    },
    staleTime: 120_000,
  });

  // Fetch price lists
  const { data: allRows = [], isLoading } = useQuery({
    queryKey: ["all_price_lists"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("archivio_listini_fraschetti")
        .select("id,cdpar,cdfor,rifli,dtvai,dtvaf,cdval,wprsc,wscfa,wscfb,wscfc,wscfd,wscfe,wmasc,wuord")
        .order("dtvai", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const today = todayAsNumber();

  const filtered = useMemo(() => {
    let rows = allRows;
    if (search) {
      const q = search.toLowerCase();
      rows = rows.filter((r: any) =>
        (r.cdpar ?? "").toLowerCase().includes(q) ||
        (supplierMap[r.cdfor] ?? "").toLowerCase().includes(q) ||
        (r.cdfor ?? "").toLowerCase().includes(q)
      );
    }
    if (filterCdfor && filterCdfor !== "__all__") {
      rows = rows.filter((r: any) => r.cdfor === filterCdfor);
    }
    if (onlyActive) {
      rows = rows.filter((r: any) => {
        const dai = Number(r.dtvai) || 0;
        const daf = Number(r.dtvaf) || 99999999;
        return dai <= today && daf >= today;
      });
    }
    return rows;
  }, [allRows, search, filterCdfor, onlyActive, supplierMap, today]);

  const paged = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);

  const saveMutation = useMutation({
    mutationFn: async (values: Record<string, any>) => {
      const cleaned = { ...values };
      for (const k of ["wprsc", "wscfa", "wscfb", "wscfc", "wscfd", "wscfe", "wmasc", "dtvai", "dtvaf"]) {
        cleaned[k] = cleaned[k] === "" || cleaned[k] == null ? null : Number(cleaned[k]);
      }
      const { error } = await supabase.from("archivio_listini_fraschetti").insert(cleaned as any);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Salvato", description: "Listino aggiunto." });
      setAddOpen(false);
      setNewRow({});
      queryClient.invalidateQueries({ queryKey: ["all_price_lists"] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  if (!can("read", "price_lists")) {
    return <div className="p-8 text-muted-foreground">Accesso non consentito.</div>;
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Costario Fornitori</h1>
        {canWrite && (
          <Button onClick={() => setAddOpen(true)}>
            <Plus className="h-4 w-4 mr-1" /> Nuovo listino
          </Button>
        )}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cerca cdpar o fornitore..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(0); }}
            className="pl-9"
          />
        </div>
        <Select value={filterCdfor} onValueChange={(v) => { setFilterCdfor(v); setPage(0); }}>
          <SelectTrigger className="w-[180px]">
            <ListFilter className="h-4 w-4 mr-1" />
            <SelectValue placeholder="Fornitore" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">Tutti i fornitori</SelectItem>
            {suppliers.map((s: any) => (
              <SelectItem key={s.cdfor} value={s.cdfor}>{s.cdfor} — {s.rasfo}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex items-center gap-2">
          <Switch id="active-toggle" checked={onlyActive} onCheckedChange={(v) => { setOnlyActive(v); setPage(0); }} />
          <Label htmlFor="active-toggle" className="text-sm">Solo attivi oggi</Label>
        </div>
        <span className="text-sm text-muted-foreground ml-auto">{filtered.length} risultati</span>
      </div>

      {/* Table */}
      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[100px]">Codice</TableHead>
              <TableHead>Descrizione</TableHead>
              <TableHead className="w-[100px]">Fornitore</TableHead>
              <TableHead className="w-[80px]">Rif. List.</TableHead>
              <TableHead className="w-[80px]">Val. Da</TableHead>
              <TableHead className="w-[80px]">Val. A</TableHead>
              <TableHead className="w-[60px]">Valuta</TableHead>
              <TableHead className="w-[80px]">Prezzo</TableHead>
              <TableHead className="w-[80px]">Netto</TableHead>
              <TableHead className="w-[70px]">UM Ord.</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={10} className="text-center text-muted-foreground py-8">Caricamento...</TableCell></TableRow>
            ) : paged.length === 0 ? (
              <TableRow><TableCell colSpan={10} className="text-center py-8">
                <div className="flex flex-col items-center gap-2 text-muted-foreground">
                  <ListFilter className="h-8 w-8" />
                  <p className="font-medium">Nessun listino trovato</p>
                  <p className="text-sm">Prova a modificare i filtri di ricerca</p>
                  {(search || filterCdfor !== "__all__" || onlyActive) && (
                    <Button variant="outline" size="sm" onClick={() => { setSearch(""); setFilterCdfor("__all__"); setOnlyActive(false); }}>
                      Azzera filtri
                    </Button>
                  )}
                </div>
              </TableCell></TableRow>
            ) : paged.map((row: any) => (
              <TableRow
                key={row.id}
                className="cursor-pointer hover:bg-accent/50"
                onClick={() => navigate(`/pim/articles/${row.cdpar}?tab=pricing`)}
              >
                <TableCell className="font-mono text-xs">{row.cdpar}</TableCell>
                <TableCell className="truncate max-w-[200px]">{articleMap[row.cdpar] ?? ""}</TableCell>
                <TableCell className="text-xs" title={supplierMap[row.cdfor] ?? ""}>
                  {row.cdfor}
                </TableCell>
                <TableCell className="text-xs">{row.rifli ?? ""}</TableCell>
                <TableCell className="text-xs">{row.dtvai ?? ""}</TableCell>
                <TableCell className="text-xs">{row.dtvaf ?? ""}</TableCell>
                <TableCell className="text-xs">{row.cdval ?? ""}</TableCell>
                <TableCell className="text-xs">{row.wprsc != null ? `€${row.wprsc}` : ""}</TableCell>
                <TableCell>
                  <Badge variant="secondary" className="text-[10px]">€{computeNetPrice(row)}</Badge>
                </TableCell>
                <TableCell className="text-xs">{row.wuord ?? ""}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button variant="outline" size="sm" disabled={page === 0} onClick={() => setPage(p => p - 1)}>Precedente</Button>
          <span className="text-sm text-muted-foreground">Pag. {page + 1} / {totalPages}</span>
          <Button variant="outline" size="sm" disabled={page >= totalPages - 1} onClick={() => setPage(p => p + 1)}>Successiva</Button>
        </div>
      )}

      {/* Add Modal */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Nuovo Listino</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            {[
              { key: "cdpar", label: "Codice Articolo" },
              { key: "cdfor", label: "Codice Fornitore" },
              { key: "rifli", label: "Rif. Listino" },
              { key: "dtvai", label: "Val. Da (YYYYMMDD)" },
              { key: "dtvaf", label: "Val. A (YYYYMMDD)" },
              { key: "cdval", label: "Valuta" },
              { key: "wprsc", label: "Prezzo" },
              { key: "wscfa", label: "Sconto A %" },
              { key: "wscfb", label: "Sconto B %" },
              { key: "wscfc", label: "Sconto C %" },
              { key: "wscfd", label: "Sconto D %" },
              { key: "wscfe", label: "Sconto E %" },
              { key: "wmasc", label: "Maggiorazione %" },
            ].map(({ key, label }) => (
              <div key={key} className="space-y-1">
                <Label className="text-xs">{label}</Label>
                <Input
                  value={newRow[key] ?? ""}
                  onChange={(e) => setNewRow({ ...newRow, [key]: e.target.value })}
                  className="h-8 text-sm"
                />
              </div>
            ))}
          </div>
          {newRow.wprsc && (
            <div className="text-sm text-muted-foreground">
              Prezzo netto calcolato: <strong>€{computeNetPrice(newRow)}</strong>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>Annulla</Button>
            <Button
              onClick={() => saveMutation.mutate(newRow)}
              disabled={!newRow.cdpar || !newRow.cdfor || saveMutation.isPending}
            >
              Salva
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

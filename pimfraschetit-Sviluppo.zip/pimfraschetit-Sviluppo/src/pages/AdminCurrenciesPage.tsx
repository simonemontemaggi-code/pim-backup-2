import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "@/hooks/use-toast";
import { RefreshCw } from "lucide-react";

function deltaColor(delta: number | null | undefined): string {
  if (delta == null) return "bg-muted text-muted-foreground";
  const a = Math.abs(delta);
  if (a < 2) return "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400";
  if (a < 5) return "bg-amber-500/15 text-amber-700 dark:text-amber-400";
  return "bg-destructive/15 text-destructive";
}

export default function AdminCurrenciesPage() {
  const today = new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState<string>("");
  const queryClient = useQueryClient();

  // Find latest available rate_date
  const { data: latestDate } = useQuery({
    queryKey: ["currency_rates_daily_latest"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("currency_rates_daily")
        .select("rate_date")
        .order("rate_date", { ascending: false })
        .limit(1);
      if (error) throw error;
      return (data?.[0]?.rate_date as string) ?? today;
    },
  });

  const effectiveDate = date || latestDate || today;

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["currency_rates_daily", effectiveDate],
    enabled: !!effectiveDate,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("currency_rates_daily")
        .select("*")
        .eq("rate_date", effectiveDate)
        .order("cdval", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });

  const refresh = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.functions.invoke("fetch-currency-rates");
      if (error) throw error;
      return data;
    },
    onSuccess: (d: any) => {
      toast({ title: "Aggiornato", description: `Processate ${d?.processed ?? 0} valute (${d?.rate_date ?? ""}).` });
      queryClient.invalidateQueries({ queryKey: ["currency_rates_daily"] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  return (
    <div className="p-6 space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <CardTitle className="text-lg">Valute — Confronto AS400 vs Mercato</CardTitle>
          <div className="flex items-center gap-2">
            <Input
              type="date"
              value={effectiveDate}
              onChange={(e) => setDate(e.target.value)}
              className="h-9 w-40"
            />
            <Button size="sm" onClick={() => refresh.mutate()} disabled={refresh.isPending}>
              <RefreshCw className={`h-4 w-4 mr-1 ${refresh.isPending ? "animate-spin" : ""}`} />
              Aggiorna ora
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-muted-foreground text-sm">Caricamento...</div>
          ) : rows.length === 0 ? (
            <div className="text-muted-foreground text-sm">
              Nessun dato per {date}. Premi <strong>Aggiorna ora</strong> per scaricare i tassi di mercato.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Valuta</TableHead>
                  <TableHead>Riferimento</TableHead>
                  <TableHead className="text-right">Cambio AS400 (CDAN)</TableHead>
                  <TableHead className="text-right">Cambio Mercato</TableHead>
                  <TableHead className="text-right">Delta %</TableHead>
                  <TableHead>Fonte</TableHead>
                  <TableHead>Aggiornato</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((r: any) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-mono font-semibold">{r.cdval}</TableCell>
                    <TableCell className="text-muted-foreground">{r.cdval_ref}</TableCell>
                    <TableCell className="text-right font-mono">
                      {r.as400_rate != null ? Number(r.as400_rate).toFixed(6) : "—"}
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {Number(r.market_rate).toFixed(6)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge className={deltaColor(r.delta_pct)} variant="outline">
                        {r.delta_pct != null ? `${Number(r.delta_pct).toFixed(2)}%` : "—"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">{r.source}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(r.updated_at).toLocaleString("it-IT")}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

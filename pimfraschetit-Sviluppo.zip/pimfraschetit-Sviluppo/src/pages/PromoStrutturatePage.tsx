import { useState } from "react";
import { Tags } from "lucide-react";
import { PromoTestateList, type TestataRow } from "@/components/promo/PromoTestateList";
import { PromoTestataDetail } from "@/components/promo/PromoTestataDetail";
import { NewPromoDialog } from "@/components/promo/NewPromoDialog";
import { supabase } from "@/integrations/supabase/client";
import { usePermissions } from "@/lib/permissions";

export default function PromoStrutturatePage() {
  const [selected, setSelected] = useState<TestataRow | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [newOpen, setNewOpen] = useState(false);
  const { canAction } = usePermissions();
  const canCreatePromo = canAction("promo_strutturate", "create");

  const refresh = () => setRefreshKey((k) => k + 1);

  const reloadSelected = async () => {
    if (!selected) return;
    const { data } = await supabase
      .from("promo_strutturate_testate")
      .select("*")
      .eq("id", selected.id)
      .single();
    if (data) setSelected(data as any);
    refresh();
  };

  const selectById = async (id: string) => {
    const { data } = await supabase
      .from("promo_strutturate_testate")
      .select("*")
      .eq("id", id)
      .single();
    if (data) setSelected(data as any);
    refresh();
  };

  return (
    <div className="flex h-[calc(100vh-3rem)] min-h-0 flex-col overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 border-b">
        <Tags className="h-5 w-5 text-primary" />
        <h1 className="text-lg font-semibold">Promo Strutturate</h1>
        <span className="text-xs text-muted-foreground ml-2">
          Gestione testate, elementi, campagne e condizioni — sync AS400 ad ogni save
        </span>
      </div>

      <div className="grid min-h-0 flex-1 grid-cols-[320px_minmax(0,1fr)] overflow-hidden">
        <PromoTestateList
          selectedId={selected?.id ?? null}
          onSelect={(r) => setSelected(r)}
          onNew={canCreatePromo ? () => setNewOpen(true) : undefined}
          refreshKey={refreshKey}
        />
        <div className="flex min-h-0 min-w-0 flex-col overflow-hidden p-4">
          {selected ? (
            <PromoTestataDetail testata={selected} onSaved={reloadSelected} />
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground text-sm">
              Seleziona una promo dall'elenco a sinistra, oppure creane una nuova.
            </div>
          )}
        </div>
      </div>

      <NewPromoDialog
        open={newOpen}
        onOpenChange={setNewOpen}
        onCreated={(id) => selectById(id)}
      />
    </div>
  );
}

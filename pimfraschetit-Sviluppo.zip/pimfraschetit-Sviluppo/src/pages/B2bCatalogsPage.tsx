import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList,
} from "@/components/ui/command";
import { cn } from "@/lib/utils";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, ExternalLink, ImageIcon, BookOpen, Upload, Loader2, Eye, MousePointerClick, FileText, Copy, Share2, Globe } from "lucide-react";
import { MediaUploader } from "@/components/b2b/MediaUploader";
import { useAuth } from "@/contexts/AuthContext";
import { FlipbookViewer } from "@/components/b2b/flipbook/FlipbookViewer";
import { B2bProductOverlay } from "@/components/b2b/flipbook/B2bProductOverlay";

import { Check, ChevronsUpDown } from "lucide-react";
import { maybeOptimizePdf } from "@/lib/maybeOptimizePdf";

type Catalog = {
  id: string;
  name: string;
  cover_url: string | null;
  catalog_url: string | null;
  pdf_url: string | null;
  pdf_storage_path: string | null;
  hotspots: any[] | null;
  total_pages: number | null;
  clas2: string | null;
  assortment_id: string | null;
  is_published_b2b: boolean;
  sort_order: number;
  updated_at: string;
  public_slug: string | null;
  is_public: boolean;
  og_image_url: string | null;
  public_views_count: number;
};

function slugify(s: string) {
  return s
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

type BrandOpt = { clas2: string; label: string };
type AssortmentOpt = { id: string; name: string };

type ComboOption = { value: string; label: string };

function SearchableCombobox({
  value, onChange, options, placeholder = "Seleziona...", emptyText = "Nessun risultato.",
}: {
  value: string | null;
  onChange: (v: string | null) => void;
  options: ComboOption[];
  placeholder?: string;
  emptyText?: string;
}) {
  const [open, setOpen] = useState(false);
  const selected = options.find((o) => o.value === value);
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between font-normal"
        >
          <span className={cn("truncate", !selected && "text-muted-foreground")}>
            {selected?.label ?? placeholder}
          </span>
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
        <Command>
          <CommandInput placeholder="Cerca..." />
          <CommandList className="max-h-72">
            <CommandEmpty>{emptyText}</CommandEmpty>
            <CommandGroup>
              <CommandItem
                value="__none__"
                onSelect={() => { onChange(null); setOpen(false); }}
              >
                <Check className={cn("mr-2 h-4 w-4", !value ? "opacity-100" : "opacity-0")} />
                — Nessuno —
              </CommandItem>
              {options.map((o) => (
                <CommandItem
                  key={o.value}
                  value={o.label}
                  onSelect={() => { onChange(o.value); setOpen(false); }}
                >
                  <Check className={cn("mr-2 h-4 w-4", value === o.value ? "opacity-100" : "opacity-0")} />
                  {o.label}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}


export default function B2bCatalogsPage() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [editing, setEditing] = useState<Partial<Catalog> | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [previewing, setPreviewing] = useState<Catalog | null>(null);
  const [overlayCdpar, setOverlayCdpar] = useState<string | null>(null);

  const { data: items = [], isLoading } = useQuery({
    queryKey: ["b2b_catalogs"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("b2b_catalogs")
        .select("*")
        .order("sort_order", { ascending: true })
        .order("name", { ascending: true });
      if (error) throw error;
      return (data ?? []) as Catalog[];
    },
  });

  const { data: brands = [] } = useQuery({
    queryKey: ["b2b_catalogs_brands"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("archivio_brand_fraschetti")
        .select("clas2, display_name, nome_as400_brand")
        .order("display_name", { ascending: true, nullsFirst: false });
      if (error) throw error;
      return (data ?? []).map((b: any) => ({
        clas2: b.clas2,
        label: (b.display_name?.trim() || b.nome_as400_brand || b.clas2) as string,
      })) as BrandOpt[];
    },
  });

  const { data: assortments = [] } = useQuery({
    queryKey: ["b2b_catalogs_assortments"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("b2b_assortments")
        .select("id, name")
        .order("name", { ascending: true });
      if (error) throw error;
      return (data ?? []) as AssortmentOpt[];
    },
  });

  const brandLabel = (clas2?: string | null) =>
    brands.find((b) => b.clas2 === clas2)?.label ?? clas2 ?? "—";
  const assortmentLabel = (id?: string | null) =>
    assortments.find((a) => a.id === id)?.name ?? "—";

  const upsert = useMutation({
    mutationFn: async (c: Partial<Catalog>) => {
      const name = (c.name ?? "").trim();
      if (!name) throw new Error("Il nome è obbligatorio");
      const url = (c.catalog_url ?? "").trim();
      if (url && !/^https?:\/\/.+/i.test(url)) {
        throw new Error("Link catalogo non valido (deve iniziare con http:// o https://)");
      }
      if (url.length > 500) throw new Error("Link troppo lungo (max 500 caratteri)");

      const payload = {
        name,
        cover_url: c.cover_url || null,
        catalog_url: url || null,
        pdf_url: c.pdf_url || null,
        pdf_storage_path: c.pdf_storage_path || null,
        clas2: c.clas2 || null,
        assortment_id: c.assortment_id || null,
        is_published_b2b: c.is_published_b2b ?? true,
        sort_order: c.sort_order ?? 0,
        public_slug: c.public_slug ? slugify(c.public_slug) || null : null,
        is_public: c.is_public ?? false,
        og_image_url: c.og_image_url || null,
        updated_by: user?.id ?? null,
      };

      if (c.id) {
        const { error } = await supabase.from("b2b_catalogs").update(payload).eq("id", c.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("b2b_catalogs")
          .insert({ ...payload, created_by: user?.id ?? null });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast({ title: "Salvato" });
      qc.invalidateQueries({ queryKey: ["b2b_catalogs"] });
      setEditing(null);
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("b2b_catalogs").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Eliminato" });
      qc.invalidateQueries({ queryKey: ["b2b_catalogs"] });
      setDeleteId(null);
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const togglePublished = useMutation({
    mutationFn: async ({ id, value }: { id: string; value: boolean }) => {
      const { error } = await supabase
        .from("b2b_catalogs")
        .update({ is_published_b2b: value })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["b2b_catalogs"] }),
  });

  return (
    <div className="p-6 space-y-4 max-w-6xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold flex items-center gap-2">
            <BookOpen className="h-5 w-5" /> Cataloghi B2B
          </h1>
          <p className="text-sm text-muted-foreground">
            Gestisci i cataloghi (immagine + link), associabili opzionalmente a un brand e/o assortimento.
          </p>
        </div>
        <Button
          onClick={() =>
            setEditing({ name: "", is_published_b2b: true, sort_order: 0 })
          }
        >
          <Plus className="h-4 w-4 mr-2" /> Nuovo catalogo
        </Button>
      </div>

      <div className="rounded-lg border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 border-b">
            <tr className="text-left">
              <th className="px-4 py-2 w-20">Cover</th>
              <th className="px-4 py-2">Nome</th>
              <th className="px-4 py-2">PDF</th>
              <th className="px-4 py-2">Hotspot</th>
              <th className="px-4 py-2">Link</th>
              <th className="px-4 py-2">Brand</th>
              <th className="px-4 py-2">Assortimento</th>
              <th className="px-4 py-2 text-center">Pubblicato</th>
              <th className="px-4 py-2 text-right">Azioni</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={9} className="px-4 py-8 text-center text-muted-foreground">Caricamento...</td></tr>
            ) : items.length === 0 ? (
              <tr><td colSpan={9} className="px-4 py-8 text-center text-muted-foreground">
                Nessun catalogo. Creane uno per iniziare.
              </td></tr>
            ) : items.map((it) => (
              <tr key={it.id} className="border-b last:border-b-0 hover:bg-muted/30">
                <td className="px-4 py-2">
                  {it.cover_url ? (
                    <img src={it.cover_url} alt={it.name} className="h-12 w-16 object-cover rounded border" />
                  ) : (
                    <div className="h-12 w-16 flex items-center justify-center bg-muted rounded border">
                      <ImageIcon className="h-4 w-4 text-muted-foreground" />
                    </div>
                  )}
                </td>
                <td className="px-4 py-2 font-medium">{it.name}</td>
                <td className="px-4 py-2">
                  {it.pdf_url ? (
                    <Badge variant="outline" className="text-xs gap-1">
                      <FileText className="h-3 w-3" />
                      {it.total_pages ? `${it.total_pages} pag` : "Sì"}
                    </Badge>
                  ) : (
                    <span className="text-xs text-muted-foreground">—</span>
                  )}
                </td>
                <td className="px-4 py-2">
                  {(it.hotspots?.length ?? 0) > 0 ? (
                    <Badge variant="secondary" className="text-xs">{it.hotspots!.length}</Badge>
                  ) : (
                    <span className="text-xs text-muted-foreground">0</span>
                  )}
                </td>
                <td className="px-4 py-2">
                  {it.catalog_url ? (
                    <a
                      href={it.catalog_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-primary hover:underline text-xs"
                    >
                      <ExternalLink className="h-3 w-3" /> Apri
                    </a>
                  ) : (
                    <span className="text-xs text-muted-foreground">—</span>
                  )}
                </td>
                <td className="px-4 py-2">
                  {it.clas2 ? (
                    <Badge variant="outline" className="text-xs">{brandLabel(it.clas2)}</Badge>
                  ) : (
                    <span className="text-xs text-muted-foreground">—</span>
                  )}
                </td>
                <td className="px-4 py-2">
                  {it.assortment_id ? (
                    <Badge variant="outline" className="text-xs">{assortmentLabel(it.assortment_id)}</Badge>
                  ) : (
                    <span className="text-xs text-muted-foreground">—</span>
                  )}
                </td>
                <td className="px-4 py-2 text-center">
                  <Switch
                    checked={it.is_published_b2b}
                    onCheckedChange={(v) => togglePublished.mutate({ id: it.id, value: v })}
                  />
                </td>
                <td className="px-4 py-2 text-right whitespace-nowrap">
                  {it.pdf_url && (
                    <>
                      <Button variant="ghost" size="icon" className="h-7 w-7" title="Anteprima flipbook" onClick={() => setPreviewing(it)}>
                        <Eye className="h-3.5 w-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7" title="Gestisci hotspot" onClick={() => navigate(`/pim/b2b/catalogs/${it.id}/hotspots`)}>
                        <MousePointerClick className="h-3.5 w-3.5" />
                      </Button>
                    </>
                  )}
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setEditing(it)}>
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    variant="ghost" size="icon"
                    className="h-7 w-7 text-destructive"
                    onClick={() => setDeleteId(it.id)}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Editor */}
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editing?.id ? "Modifica catalogo" : "Nuovo catalogo"}</DialogTitle>
          </DialogHeader>

          {editing && (
            <div className="space-y-4">
              <div className="space-y-1">
                <Label>Nome *</Label>
                <Input
                  value={editing.name ?? ""}
                  onChange={(e) => setEditing({ ...editing, name: e.target.value })}
                  placeholder="es. Catalogo Generale 2026"
                />
              </div>

              <div className="grid grid-cols-[180px_1fr] gap-4">
                <div className="space-y-1">
                  <MediaUploader
                    label="Copertina"
                    hint="Immagine di copertina"
                    currentUrl={editing.cover_url ?? null}
                    storagePath={`catalogs/${editing.id ?? `new-${Date.now()}`}/cover`}
                    aspect="wide"
                    onUploaded={(url) => setEditing({ ...editing, cover_url: url })}
                  />
                </div>
                <div className="space-y-3">
                  <div className="space-y-1">
                    <Label>Link catalogo</Label>
                    <Input
                      type="url"
                      value={editing.catalog_url ?? ""}
                      onChange={(e) => setEditing({ ...editing, catalog_url: e.target.value })}
                      placeholder="https://brand.com/catalogo.pdf"
                      maxLength={500}
                    />
                    <p className="text-xs text-muted-foreground">
                      URL del catalogo (PDF o pagina web).
                    </p>
                  </div>
                  <div className="space-y-1">
                    <Label>Ordine</Label>
                    <Input
                      type="number"
                      value={editing.sort_order ?? 0}
                      onChange={(e) =>
                        setEditing({ ...editing, sort_order: parseInt(e.target.value) || 0 })
                      }
                    />
                  </div>
                </div>
              </div>

              <PdfUploadField
                editing={editing}
                onChange={(patch) => setEditing({ ...editing, ...patch })}
              />

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label>Brand associato (opzionale)</Label>
                  <SearchableCombobox
                    value={editing.clas2 ?? null}
                    onChange={(v) => setEditing({ ...editing, clas2: v })}
                    options={[...brands]
                      .sort((a, b) => a.label.localeCompare(b.label, "it", { sensitivity: "base" }))
                      .map((b) => ({ value: b.clas2, label: b.label }))}
                    placeholder="— Nessuno —"
                  />
                </div>
                <div className="space-y-1">
                  <Label>Assortimento associato (opzionale)</Label>
                  <SearchableCombobox
                    value={editing.assortment_id ?? null}
                    onChange={(v) => setEditing({ ...editing, assortment_id: v })}
                    options={[...assortments]
                      .sort((a, b) => a.name.localeCompare(b.name, "it", { sensitivity: "base" }))
                      .map((a) => ({ value: a.id, label: a.name }))}
                    placeholder="— Nessuno —"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Switch
                  id="published"
                  checked={editing.is_published_b2b ?? true}
                  onCheckedChange={(v) => setEditing({ ...editing, is_published_b2b: v })}
                />
                <Label htmlFor="published" className="cursor-pointer">Pubblicato sul B2B</Label>
              </div>

              {/* Pubblicazione link pubblico condivisibile */}
              <div className="rounded-lg border bg-muted/30 p-3 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Globe className="h-4 w-4 text-primary" />
                    <Label htmlFor="is_public" className="cursor-pointer font-medium">
                      Link pubblico condivisibile
                    </Label>
                  </div>
                  <Switch
                    id="is_public"
                    checked={editing.is_public ?? false}
                    onCheckedChange={(v) =>
                      setEditing({
                        ...editing,
                        is_public: v,
                        public_slug:
                          v && !editing.public_slug ? slugify(editing.name ?? "") : editing.public_slug,
                      })
                    }
                  />
                </div>
                {editing.is_public && (
                  <>
                    <div className="space-y-1">
                      <Label className="text-xs">Slug URL</Label>
                      <Input
                        value={editing.public_slug ?? ""}
                        onChange={(e) =>
                          setEditing({ ...editing, public_slug: slugify(e.target.value) })
                        }
                        placeholder="es. catalogo-2026"
                      />
                      {editing.public_slug && (
                        <p className="text-xs text-muted-foreground break-all">
                          {window.location.origin}/c/{editing.public_slug}
                        </p>
                      )}
                    </div>
                    {editing.public_slug && editing.id && (
                      <div className="flex flex-wrap gap-2">
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const url = `${window.location.origin}/c/${editing.public_slug}`;
                            navigator.clipboard.writeText(url);
                            toast({ title: "Link copiato" });
                          }}
                        >
                          <Copy className="h-3.5 w-3.5 mr-1" /> Copia link
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const url = `${window.location.origin}/c/${editing.public_slug}`;
                            const text = `${editing.name ?? "Catalogo"} — ${url}`;
                            window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
                          }}
                        >
                          <Share2 className="h-3.5 w-3.5 mr-1" /> WhatsApp
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          onClick={() => window.open(`/c/${editing.public_slug}`, "_blank")}
                        >
                          <ExternalLink className="h-3.5 w-3.5 mr-1" /> Apri
                        </Button>
                        {(editing.public_views_count ?? 0) > 0 && (
                          <Badge variant="secondary" className="text-xs ml-auto">
                            {editing.public_views_count} visite
                          </Badge>
                        )}
                      </div>
                    )}
                    {!editing.id && (
                      <p className="text-xs text-muted-foreground">
                        Salva il catalogo per ottenere il link condivisibile.
                      </p>
                    )}
                    <div className="space-y-1">
                      <Label className="text-xs">Immagine social (opzionale)</Label>
                      <Input
                        type="url"
                        value={editing.og_image_url ?? ""}
                        onChange={(e) => setEditing({ ...editing, og_image_url: e.target.value })}
                        placeholder="Lascia vuoto per usare la copertina"
                      />
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditing(null)}>Annulla</Button>
            <Button onClick={() => editing && upsert.mutate(editing)} disabled={upsert.isPending}>
              Salva
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminare il catalogo?</AlertDialogTitle>
            <AlertDialogDescription>
              L'operazione non è reversibile.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteId && remove.mutate(deleteId)}>
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Anteprima Flipbook */}
      <Dialog open={!!previewing} onOpenChange={(o) => !o && setPreviewing(null)}>
        <DialogContent className="max-w-[95vw] w-[95vw] h-[95vh] max-h-[95vh] p-0 gap-0 flex flex-col overflow-hidden">
          <DialogHeader className="sr-only">
            <DialogTitle>Anteprima {previewing?.name}</DialogTitle>
          </DialogHeader>
          {previewing?.pdf_url && (
            <FlipbookViewer
              pdfUrl={previewing.pdf_url}
              hotspots={(previewing.hotspots ?? []) as any}
              onClose={() => setPreviewing(null)}
              onHotspotClick={(h) => {
                // Tutti gli hotspot nuovi sono di tipo article. Per backward-compat,
                // se esistono ancora url/assortment li apriamo come prima.
                if (h.cdpar) {
                  setOverlayCdpar(h.cdpar.trim());
                } else if (h.url) {
                  window.open(h.url, "_blank");
                } else if (h.assortment_id) {
                  window.open(`/pim/b2b/assortments/${h.assortment_id}/articles`, "_blank");
                }
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Overlay prodotto stile B2B mockup */}
      <B2bProductOverlay cdpar={overlayCdpar} onClose={() => setOverlayCdpar(null)} />
    </div>
  );
}

function PdfUploadField({
  editing,
  onChange,
}: {
  editing: Partial<Catalog>;
  onChange: (patch: Partial<Catalog>) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const handleFile = async (file: File) => {
    if (file.type !== "application/pdf") {
      toast({ title: "Solo file PDF", variant: "destructive" });
      return;
    }
    if (file.size > 50 * 1024 * 1024) {
      toast({ title: "File troppo grande (max 50MB)", variant: "destructive" });
      return;
    }
    setUploading(true);
    try {
      const optimized = await maybeOptimizePdf(file);
      const id = editing.id ?? `new-${Date.now()}`;
      const path = `catalogs/${id}/catalog.pdf`;
      const { error } = await supabase.storage
        .from("b2b-catalogs")
        .upload(path, optimized, { upsert: true, contentType: "application/pdf" });
      if (error) throw error;
      const { data } = supabase.storage.from("b2b-catalogs").getPublicUrl(path);
      const url = `${data.publicUrl}?v=${Date.now()}`;
      onChange({ pdf_url: url, pdf_storage_path: path });
      toast({ title: "PDF caricato" });
    } catch (e: any) {
      toast({ title: "Errore upload", description: e.message, variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <Label>PDF Flipbook (opzionale)</Label>
        {editing.pdf_url && (
          <Button
            variant="ghost"
            size="sm"
            type="button"
            onClick={() => onChange({ pdf_url: null, pdf_storage_path: null })}
          >
            Rimuovi
          </Button>
        )}
      </div>
      <div
        className="border-2 border-dashed rounded-lg p-3 cursor-pointer hover:bg-muted/50 transition flex items-center justify-center min-h-[60px]"
        onClick={() => inputRef.current?.click()}
      >
        {uploading ? (
          <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
        ) : editing.pdf_url ? (
          <div className="flex items-center gap-2 text-sm">
            <FileText className="h-4 w-4 text-primary" />
            <span className="font-medium">PDF caricato</span>
            <a href={editing.pdf_url} target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline">
              <ExternalLink className="h-3 w-3 inline" /> apri
            </a>
          </div>
        ) : (
          <div className="text-center text-muted-foreground text-sm">
            <Upload className="h-5 w-5 mx-auto mb-1" />
            Clicca per caricare un PDF (max 50MB)
          </div>
        )}
      </div>
      <p className="text-xs text-muted-foreground">
        Caricando un PDF potrai sfogliarlo in 3D con effetto flipbook e aggiungere hotspot cliccabili.
      </p>
      <input
        ref={inputRef}
        type="file"
        accept="application/pdf"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFile(f);
          e.target.value = "";
        }}
      />
    </div>
  );
}


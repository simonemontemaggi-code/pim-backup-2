import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import {
  Users,
  Search,
  Loader2,
  ChevronLeft,
  ChevronRight,
  Inbox,
  AtSign,
  ShieldCheck,
  Mail,
  MailX,
  UserCheck,
  Download,
  Tv,
  ShoppingCart,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useCustomersList, CUSTOMERS_PAGE_SIZE, type CustomersSortColumn, type SortDirection } from "@/hooks/useCustomers";
import { useCustomerRequestsPendingCount } from "@/hooks/useCustomerRequests";
import { useSelfOnboardingPendingCount } from "@/hooks/useSelfOnboardingRequests";
import { usePermissions } from "@/lib/permissions";
import CustomerRequestsTab from "@/components/customers/CustomerRequestsTab";
import SelfOnboardingRequestsTab from "@/components/customers/SelfOnboardingRequestsTab";
import { supabase } from "@/integrations/supabase/client";
import { downloadXlsx } from "@/lib/xlsxExport";
import { toast } from "@/hooks/use-toast";

function CustomersListView() {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [onlyB2bActive, setOnlyB2bActive] = useState(false);
  const [onlyTerms, setOnlyTerms] = useState(false);
  const [onlyNewsletter, setOnlyNewsletter] = useState(false);
  const [onlyPending, setOnlyPending] = useState(false);
  const [onlyOptOut, setOnlyOptOut] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [sortColumn, setSortColumn] = useState<CustomersSortColumn>("customer_code");
  const [sortDirection, setSortDirection] = useState<SortDirection>("asc");
  const navigate = useNavigate();

  const { data, isLoading, isFetching } = useCustomersList(
    search,
    page,
    onlyB2bActive,
    onlyTerms,
    onlyNewsletter,
    onlyPending,
    onlyOptOut,
    sortColumn,
    sortDirection,
  );
  const rows = data?.rows ?? [];
  const total = data?.total ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / CUSTOMERS_PAGE_SIZE));

  const toggleSort = (col: CustomersSortColumn) => {
    setPage(0);
    if (sortColumn !== col) {
      setSortColumn(col);
      setSortDirection("asc");
    } else if (sortDirection === "asc") {
      setSortDirection("desc");
    } else {
      // reset to default
      setSortColumn("customer_code");
      setSortDirection("asc");
    }
  };

  const SortHeader = ({ col, children, className = "" }: { col: CustomersSortColumn; children: React.ReactNode; className?: string }) => {
    const active = sortColumn === col;
    const Icon = active ? (sortDirection === "asc" ? ArrowUp : ArrowDown) : ArrowUpDown;
    return (
      <th className={`text-left px-3 py-2 font-medium ${className}`}>
        <button
          type="button"
          onClick={() => toggleSort(col)}
          className={`inline-flex items-center gap-1 hover:text-foreground ${active ? "text-foreground" : ""}`}
        >
          {children}
          <Icon className="h-3 w-3 opacity-60" />
        </button>
      </th>
    );
  };

  const handleSearchChange = (v: string) => {
    setSearch(v);
    setPage(0);
  };

  const toggle = (setter: (fn: (v: boolean) => boolean) => void) => () => {
    setter((v) => !v);
    setPage(0);
  };

  const exportNewsletter = async () => {
    setExporting(true);
    try {
      const { data: profs, error: perr } = await supabase
        .from("profiles")
        .select("user_id, marketing_consent_at, marketing_consent_source")
        .eq("newsletter_subscribed", true)
        .limit(20000);
      if (perr) throw perr;
      const list = profs ?? [];
      if (list.length === 0) {
        toast({ title: "Nessun iscritto", description: "Nessun cliente iscritto alla newsletter." });
        return;
      }
      const byUid = new Map<string, any>();
      list.forEach((p: any) => byUid.set(p.user_id, p));
      const uids = list.map((p: any) => p.user_id).filter(Boolean);

      // batch in chunks di 500 per evitare URL troppo lunghi
      const chunks: string[][] = [];
      for (let i = 0; i < uids.length; i += 500) chunks.push(uids.slice(i, i + 500));
      const allRows: any[] = [];
      for (const chunk of chunks) {
        const { data: cust, error: cerr } = await supabase
          .from("customers")
          .select("customer_code, company_full_name, company_name, email, mail_accesso_cliente, auth_user_id")
          .in("auth_user_id", chunk);
        if (cerr) throw cerr;
        (cust ?? []).forEach((c: any) => {
          const p = byUid.get(c.auth_user_id);
          allRows.push({
            "Codice Cliente": c.customer_code,
            "Ragione Sociale": c.company_full_name ?? c.company_name ?? "",
            Email: c.email ?? "",
            "Email B2B": c.mail_accesso_cliente ?? "",
            "Consenso marketing del": p?.marketing_consent_at
              ? new Date(p.marketing_consent_at).toISOString()
              : "",
            Origine: p?.marketing_consent_source ?? "",
          });
        });
      }
      const today = new Date().toISOString().slice(0, 10).replace(/-/g, "");
      downloadXlsx(`iscritti-newsletter-${today}.xlsx`, allRows, {
        sheetName: "Newsletter",
      });
      toast({
        title: "Export completato",
        description: `${allRows.length} iscritti esportati.`,
      });
    } catch (e: any) {
      toast({
        title: "Errore export",
        description: e?.message ?? "Impossibile esportare gli iscritti.",
        variant: "destructive",
      });
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => handleSearchChange(e.target.value)}
            placeholder="Cerca per codice cliente o ragione sociale…"
            className="pl-9"
          />
        </div>
        <Button
          variant={onlyB2bActive ? "default" : "outline"}
          size="sm"
          onClick={toggle(setOnlyB2bActive)}
          className="gap-1.5"
        >
          <AtSign className={`h-4 w-4 ${onlyB2bActive ? "" : "text-green-600"}`} />
          Attivi B2B
        </Button>
        <Button
          variant={onlyTerms ? "default" : "outline"}
          size="sm"
          onClick={toggle(setOnlyTerms)}
          className="gap-1.5"
        >
          <ShieldCheck className={`h-4 w-4 ${onlyTerms ? "" : "text-green-600"}`} />
          Contratti accettati
        </Button>
        <Button
          variant={onlyPending ? "default" : "outline"}
          size="sm"
          onClick={toggle(setOnlyPending)}
          className="gap-1.5"
        >
          <UserCheck className={`h-4 w-4 ${onlyPending ? "" : "text-orange-500"}`} />
          Primo accesso in attesa
        </Button>
        <Button
          variant={onlyNewsletter ? "default" : "outline"}
          size="sm"
          onClick={toggle(setOnlyNewsletter)}
          className="gap-1.5"
        >
          <Mail className={`h-4 w-4 ${onlyNewsletter ? "" : "text-green-600"}`} />
          Iscritti newsletter
        </Button>
        <Button
          variant={onlyOptOut ? "default" : "outline"}
          size="sm"
          onClick={toggle(setOnlyOptOut)}
          className="gap-1.5"
        >
          <MailX className={`h-4 w-4 ${onlyOptOut ? "" : "text-red-500"}`} />
          Opt-out recenti (90gg)
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={exportNewsletter}
          disabled={exporting}
          className="gap-1.5"
        >
          {exporting ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Download className="h-4 w-4" />
          )}
          Esporta iscritti newsletter
        </Button>
        <Badge variant="outline" className="ml-auto">
          {total.toLocaleString("it-IT")} clienti
        </Badge>
        {isFetching && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
      </div>


      <div className="rounded-lg border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <SortHeader col="customer_code">CDCLI</SortHeader>
              <SortHeader col="company_full_name">Ragione Sociale</SortHeader>
              <SortHeader col="city">Località</SortHeader>
              <SortHeader col="province" className="w-12">PR</SortHeader>
              <SortHeader col="activated_at">Attivo dal</SortHeader>
              <SortHeader col="mail_accesso_cliente">Email B2B</SortHeader>
              <SortHeader col="price_list_code" className="w-16">List.</SortHeader>
              <SortHeader col="original_agent_code" className="w-16">Agente</SortHeader>
              <SortHeader col="zone_code" className="w-16">Zona</SortHeader>
              <th className="text-left px-3 py-2 font-medium w-20">Consensi</th>
              <th className="text-center px-3 py-2 font-medium w-16" title="Videocatalogo attivo">Videocat.</th>
              <th className="text-center px-3 py-2 font-medium w-16" title="Cliente con ordini da videocatalogo">Ord. Vid.</th>

            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan={12} className="text-center py-12 text-muted-foreground">
                  <Loader2 className="h-5 w-5 animate-spin inline" />
                </td>
              </tr>
            ) : rows.length === 0 ? (
              <tr>
                <td colSpan={12} className="text-center py-12 text-muted-foreground">
                  <Inbox className="h-6 w-6 mx-auto mb-2 opacity-50" />
                  Nessun cliente trovato.
                </td>
              </tr>

            ) : (
              rows.map((c) => {
                const consents = (c as any).b2b_consents;
                const termsOn = !!consents?.terms_accepted_at;
                const newsOn = consents?.newsletter_subscribed === true;
                return (
                <tr
                  key={c.id}
                  onClick={() => c.id && navigate(`/pim/customers/${c.id}`)}
                  className="border-t hover:bg-muted/30 cursor-pointer"
                >
                  <td className="px-3 py-2 font-mono text-xs">{c.customer_code}</td>
                  <td className="px-3 py-2">
                    <div className="font-medium">
                      {(c.company_name ?? "") + (c.company_name_aux ?? "")}
                    </div>
                  </td>
                  <td className="px-3 py-2">{c.city ?? "—"}</td>
                  <td className="px-3 py-2">{c.province ?? "—"}</td>
                  <td className="px-3 py-2 text-xs">
                    {(() => {
                      const activatedAt = (c as any).activated_at as string | null;
                      if (!activatedAt) return <span className="text-muted-foreground">—</span>;
                      return (
                        <span className="tabular-nums" title="Data attivazione B2B">
                          {new Date(activatedAt).toLocaleDateString("it-IT", { day: "2-digit", month: "2-digit", year: "numeric" })}
                        </span>
                      );
                    })()}
                  </td>
                  <td className="px-3 py-2 text-xs">
                    {(() => {
                      const b2bMail = (c as any).mail_accesso_cliente as string | null;
                      const activatedAt = (c as any).activated_at as string | null;
                      if (!activatedAt) return <span className="text-muted-foreground">—</span>;
                      return (
                        <span className="truncate" title="Email registrazione B2B">
                          {b2bMail ?? "—"}
                        </span>
                      );
                    })()}
                  </td>
                  <td className="px-3 py-2 font-mono text-xs">{c.price_list_code ?? "—"}</td>
                  <td className="px-3 py-2 font-mono text-xs">{c.original_agent_code ?? "—"}</td>
                  <td className="px-3 py-2 font-mono text-xs">{c.zone_code ?? "—"}</td>
                  <td className="px-3 py-2">
                    <div className="flex items-center gap-1.5">
                      <ShieldCheck
                        className={`h-4 w-4 ${termsOn ? "text-green-600" : "text-muted-foreground/40"}`}
                        aria-label={termsOn ? "Contratti accettati" : "Contratti non accettati"}
                      >
                        <title>{termsOn ? "Contratti accettati" : "Contratti non accettati"}</title>
                      </ShieldCheck>
                      <Mail
                        className={`h-4 w-4 ${newsOn ? "text-green-600" : "text-muted-foreground/40"}`}
                        aria-label={newsOn ? "Iscritto newsletter" : "Non iscritto newsletter"}
                      >
                        <title>{newsOn ? "Iscritto newsletter" : "Non iscritto newsletter"}</title>
                      </Mail>
                    </div>
                  </td>
                  <td className="px-3 py-2 text-center">
                    {(c as any).videocatalogo_attivo ? (
                      <Tv className="h-4 w-4 text-green-600 inline" aria-label="Videocatalogo attivo">
                        <title>Videocatalogo attivo</title>
                      </Tv>
                    ) : (
                      <span className="text-muted-foreground/40">—</span>
                    )}
                  </td>
                  <td className="px-3 py-2 text-center">
                    {(c as any).videocatalogo_con_ordini ? (
                      <ShoppingCart className="h-4 w-4 text-green-600 inline" aria-label="Con ordini da videocatalogo">
                        <title>Con ordini da videocatalogo</title>
                      </ShoppingCart>
                    ) : (
                      <span className="text-muted-foreground/40">—</span>
                    )}
                  </td>

                </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between text-sm">
          <div className="text-muted-foreground">
            Pagina {page + 1} di {totalPages}
          </div>
          <div className="flex gap-1">
            <Button
              size="sm"
              variant="outline"
              disabled={page === 0}
              onClick={() => setPage((p) => Math.max(0, p - 1))}
            >
              <ChevronLeft className="h-4 w-4" /> Prec.
            </Button>
            <Button
              size="sm"
              variant="outline"
              disabled={page + 1 >= totalPages}
              onClick={() => setPage((p) => p + 1)}
            >
              Succ. <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function RequestsTabTrigger() {
  const { data: pendingCount = 0 } = useCustomerRequestsPendingCount();
  return (
    <TabsTrigger value="requests" className="gap-2">
      Richieste
      {pendingCount > 0 && (
        <Badge className="bg-warning/15 text-warning border-warning/30 hover:bg-warning/20 h-5 px-1.5">
          {pendingCount}
        </Badge>
      )}
    </TabsTrigger>
  );
}

function SelfRequestsTabTrigger() {
  const { data: pendingCount = 0 } = useSelfOnboardingPendingCount();
  return (
    <TabsTrigger value="self-requests" className="gap-2">
      Auto Richieste
      {pendingCount > 0 && (
        <Badge className="bg-warning/15 text-warning border-warning/30 hover:bg-warning/20 h-5 px-1.5">
          {pendingCount}
        </Badge>
      )}
    </TabsTrigger>
  );
}

export default function CustomersPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { sectionVisible } = usePermissions();
  const canSeeRequests = sectionVisible("customer_requests");
  const canSeeSelfRequests = sectionVisible("customers");
  const rawTab = searchParams.get("tab");
  let requestedTab: "clienti" | "requests" | "self-requests" = "clienti";
  if (rawTab === "requests") requestedTab = "requests";
  else if (rawTab === "self-requests") requestedTab = "self-requests";
  const activeTab =
    requestedTab === "requests" && !canSeeRequests
      ? "clienti"
      : requestedTab === "self-requests" && !canSeeSelfRequests
        ? "clienti"
        : requestedTab;

  const setTab = (v: string) => {
    const next = new URLSearchParams(searchParams);
    if (v === "clienti") next.delete("tab");
    else next.set("tab", v);
    setSearchParams(next, { replace: true });
  };

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center gap-3">
        <Users className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold">Clienti</h1>
          <p className="text-sm text-muted-foreground">
            {canSeeRequests
              ? "Anagrafica clienti AS400 + richieste di codifica inviate dagli agenti + auto-registrazioni B2B."
              : "Anagrafica clienti AS400."}
          </p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="clienti">Clienti</TabsTrigger>
          {canSeeRequests && <RequestsTabTrigger />}
          {canSeeSelfRequests && <SelfRequestsTabTrigger />}
        </TabsList>

        <TabsContent value="clienti" className="mt-4">
          <CustomersListView />
        </TabsContent>
        {canSeeRequests && (
          <TabsContent value="requests" className="mt-4">
            <CustomerRequestsTab />
          </TabsContent>
        )}
        {canSeeSelfRequests && (
          <TabsContent value="self-requests" className="mt-4">
            <SelfOnboardingRequestsTab />
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}

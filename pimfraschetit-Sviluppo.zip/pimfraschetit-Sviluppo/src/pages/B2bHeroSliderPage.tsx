import { useEffect, useState } from "react";
import { Plus, Trash2, ArrowUp, ArrowDown, Save, Loader2, Pencil, X, Clock, Calendar } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { useConfirm } from "@/components/ui/confirm-dialog";
import { HeroSlidePreview } from "@/components/b2b/HeroSlidePreview";
import { MediaUploader } from "@/components/b2b/MediaUploader";
import { utcToLocalDateTimeInput, localDateTimeInputToUtcIso } from "@/lib/datetimeHelpers";
import { LinkTargetPicker } from "@/components/b2b/LinkTargetPicker";

interface Slide {
  id: string;
  title: string;
  subtitle: string | null;
  cta_label: string | null;
  link_url: string | null;
  image_url: string | null;
  sort_order: number;
  is_active: boolean;
  starts_at: string | null;
  ends_at: string | null;
}

const empty = (sort_order: number): Slide => ({
  id: "",
  title: "Nuovo slide",
  subtitle: "",
  cta_label: "Scopri",
  link_url: "/",
  image_url: null,
  sort_order,
  is_active: true,
  starts_at: null,
  ends_at: null,
});

export default function B2bHeroSliderPage() {
  const confirm = useConfirm();
  const { user } = useAuth();
  const [slides, setSlides] = useState<Slide[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState<Slide | null>(null);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("b2b_hero_slides")
      .select("*")
      .order("sort_order", { ascending: true });
    if (error) toast.error(error.message);
    setSlides((data as Slide[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const newSlide = () => setEditing(empty(slides.length));

  const save = async () => {
    if (!editing) return;
    setSaving(true);
    const payload = {
      title: editing.title,
      subtitle: editing.subtitle,
      cta_label: editing.cta_label,
      link_url: editing.link_url,
      image_url: editing.image_url,
      sort_order: editing.sort_order,
      is_active: editing.is_active,
      starts_at: editing.starts_at,
      ends_at: editing.ends_at,
      updated_by: user?.id,
    };
    const { error } = editing.id
      ? await supabase.from("b2b_hero_slides").update(payload).eq("id", editing.id)
      : await supabase.from("b2b_hero_slides").insert(payload);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Slide salvato");
    setEditing(null);
    load();
  };

  const remove = async (id: string) => {
    if (!(await confirm({ title: "Eliminare questo slide?", destructive: true, confirmText: "Elimina" }))) return;
    const { error } = await supabase.from("b2b_hero_slides").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Eliminato"); load(); }
  };

  const move = async (s: Slide, dir: -1 | 1) => {
    const sorted = [...slides].sort((a, b) => a.sort_order - b.sort_order);
    const idx = sorted.findIndex((x) => x.id === s.id);
    const swap = sorted[idx + dir];
    if (!swap) return;
    await Promise.all([
      supabase.from("b2b_hero_slides").update({ sort_order: swap.sort_order }).eq("id", s.id),
      supabase.from("b2b_hero_slides").update({ sort_order: s.sort_order }).eq("id", swap.id),
    ]);
    load();
  };

  const upd = <K extends keyof Slide>(k: K, v: Slide[K]) =>
    setEditing((e) => (e ? { ...e, [k]: v } : e));

  // Stato semaforo: verde = visibile ora, giallo = programmato (futuro), rosso = non attivo o scaduto
  const getStatus = (s: Slide): { color: "green" | "yellow" | "red"; label: string } => {
    if (!s.is_active) return { color: "red", label: "Non attivo" };
    const now = new Date();
    const start = s.starts_at ? new Date(s.starts_at) : null;
    const end = s.ends_at ? new Date(s.ends_at) : null;
    if (end && end < now) return { color: "red", label: "Scaduto" };
    if (start && start > now) return { color: "yellow", label: "Programmato" };
    return { color: "green", label: "Online" };
  };

  const fmtDate = (iso: string | null) => {
    if (!iso) return null;
    const d = new Date(iso);
    return d.toLocaleString("it-IT", {
      day: "2-digit",
      month: "2-digit",
      year: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const dotClass = (c: "green" | "yellow" | "red") =>
    c === "green"
      ? "bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]"
      : c === "yellow"
      ? "bg-yellow-500 shadow-[0_0_8px_rgba(234,179,8,0.6)]"
      : "bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]";

  return (
    <div className="p-6 space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Slider Homepage B2B</h1>
          <p className="text-sm text-muted-foreground">
            Gli slide pubblicati appariranno nella homepage del B2B in ordine.
          </p>
        </div>
        <Button onClick={newSlide}><Plus className="h-4 w-4 mr-1" /> Nuovo slide</Button>
      </div>

      {loading ? (
        <div className="p-10 text-center"><Loader2 className="animate-spin inline" /></div>
      ) : slides.length === 0 ? (
        <Card className="p-10 text-center text-muted-foreground">
          Nessuno slide. Clicca "Nuovo slide" per iniziare.
        </Card>
      ) : (
        <div className="space-y-3">
          {slides.map((s, i) => {
            const status = getStatus(s);
            const startStr = fmtDate(s.starts_at);
            const endStr = fmtDate(s.ends_at);
            return (
              <Card key={s.id} className="p-3 flex items-center gap-3">
                <div className="flex flex-col gap-1">
                  <Button size="icon" variant="ghost" disabled={i === 0} onClick={() => move(s, -1)}>
                    <ArrowUp className="h-3 w-3" />
                  </Button>
                  <Button size="icon" variant="ghost" disabled={i === slides.length - 1} onClick={() => move(s, 1)}>
                    <ArrowDown className="h-3 w-3" />
                  </Button>
                </div>
                <div
                  className={`h-3 w-3 rounded-full shrink-0 ${dotClass(status.color)}`}
                  title={status.label}
                />
                <div className="w-40 shrink-0 rounded overflow-hidden bg-muted" style={{ aspectRatio: "16/5.5" }}>
                  {s.image_url ? (
                    <img src={s.image_url} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-xs text-muted-foreground">no img</div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold truncate">{s.title}</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                        status.color === "green"
                          ? "bg-green-500/15 text-green-700 dark:text-green-400"
                          : status.color === "yellow"
                          ? "bg-yellow-500/15 text-yellow-700 dark:text-yellow-400"
                          : "bg-red-500/15 text-red-700 dark:text-red-400"
                      }`}
                    >
                      {status.label}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{s.subtitle}</p>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground mt-0.5">
                    <span className="truncate">→ {s.link_url || "—"}</span>
                    {startStr && (
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" /> dal {startStr}
                      </span>
                    )}
                    {endStr && (
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" /> fino al {endStr}
                      </span>
                    )}
                    {!startStr && !endStr && s.is_active && (
                      <span className="italic opacity-70">sempre visibile</span>
                    )}
                  </div>
                </div>
                <Button variant="outline" size="sm" onClick={() => setEditing(s)}>
                  <Pencil className="h-3 w-3 mr-1" /> Modifica
                </Button>
                <Button variant="ghost" size="sm" onClick={() => remove(s.id)}>
                  <Trash2 className="h-3 w-3 text-destructive" />
                </Button>
              </Card>
            );
          })}
        </div>
      )}

      {editing && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 overflow-auto p-6">
          <div className="max-w-5xl mx-auto space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold">{editing.id ? "Modifica slide" : "Nuovo slide"}</h2>
              <div className="flex gap-2">
                <Button variant="ghost" onClick={() => setEditing(null)}><X className="h-4 w-4 mr-1" />Annulla</Button>
                <Button onClick={save} disabled={saving}>
                  {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                  Salva
                </Button>
              </div>
            </div>

            <Card className="p-4 space-y-3">
              <Label className="text-xs uppercase text-muted-foreground">Anteprima live</Label>
              <HeroSlidePreview
                image={editing.image_url}
                title={editing.title}
                subtitle={editing.subtitle}
                cta={editing.cta_label}
                link={editing.link_url}
              />
            </Card>

            <Card className="p-5 space-y-4">
              <MediaUploader
                label="Immagine slide"
                hint="Consigliato 1920×660"
                currentUrl={editing.image_url}
                storagePath={`b2b/hero/${editing.id || `new-${Date.now()}`}`}
                aspect="wide"
                onUploaded={(url) => upd("image_url", url)}
              />

              <div className="space-y-2">
                <Label>Titolo</Label>
                <Input value={editing.title} onChange={(e) => upd("title", e.target.value)} maxLength={120} />
              </div>

              <div className="space-y-2">
                <Label>Sottotitolo</Label>
                <Textarea
                  rows={2}
                  value={editing.subtitle ?? ""}
                  onChange={(e) => upd("subtitle", e.target.value)}
                  maxLength={200}
                />
              </div>

              <div className="grid grid-cols-[auto_1fr_1fr] gap-3 items-end">
                <div className="space-y-2">
                  <Label>Mostra CTA</Label>
                  <div className="h-10 flex items-center">
                    <Switch
                      checked={!!editing.cta_label}
                      onCheckedChange={(v) => upd("cta_label", v ? "Scopri" : "")}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Testo pulsante (CTA)</Label>
                  <Input
                    value={editing.cta_label ?? ""}
                    onChange={(e) => upd("cta_label", e.target.value)}
                    placeholder="Disattivata"
                    maxLength={40}
                    disabled={!editing.cta_label}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Destinazione link</Label>
                  <LinkTargetPicker
                    value={editing.link_url}
                    onChange={(url) => upd("link_url", url)}
                  />
                  {!editing.cta_label && editing.link_url && (
                    <p className="text-[11px] text-muted-foreground">
                      Senza pulsante: tutta l'immagine sarà cliccabile.
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2">
                  <Label>Attivo</Label>
                  <div className="h-10 flex items-center">
                    <Switch checked={editing.is_active} onCheckedChange={(v) => upd("is_active", v)} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Inizio (opz.)</Label>
                  <Input
                    type="datetime-local"
                    value={utcToLocalDateTimeInput(editing.starts_at)}
                    onChange={(e) => upd("starts_at", localDateTimeInputToUtcIso(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Fine (opz.)</Label>
                  <Input
                    type="datetime-local"
                    value={utcToLocalDateTimeInput(editing.ends_at)}
                    onChange={(e) => upd("ends_at", localDateTimeInputToUtcIso(e.target.value))}
                  />
                </div>
              </div>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}

import { useState, useCallback, useMemo, useRef } from "react";
import { Badge } from "@/components/ui/badge";
import Papa from "papaparse";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { TEMPLATES, type ImportType, normalizeCdpar, cdparKey, ATTR_DETTAGLIO_MAX_BLOCKS } from "@/lib/csvTemplates";
import { validateRows, type RowValidation } from "@/lib/csvValidation";
import { buildAttrLookupCategory, parseObbligo, parseVarianti } from "@/lib/gammaPathResolver";
import { deriveDisplayName } from "@/hooks/useGammaAttributes";
import { StepUpload } from "@/components/import/StepUpload";
import { StepMapping } from "@/components/import/StepMapping";
import { StepValidation } from "@/components/import/StepValidation";
import { StepResult } from "@/components/import/StepResult";
import { StepGammaPathMapping, type PathMappingResult } from "@/components/import/StepGammaPathMapping";
import { toast } from "@/hooks/use-toast";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { BulkBrandLogos } from "@/components/import/BulkBrandLogos";
import SdsImportPage from "@/pages/SdsImportPage";
import { InventoryImportPanel } from "@/components/import/InventoryImportPanel";
import { EncodingHealthPanel } from "@/components/import/EncodingHealthPanel";
import { CustomersImportPanel } from "@/components/import/CustomersImportPanel";
import { AssortimentiImportPanel } from "@/components/import/AssortimentiImportPanel";
import { ShieldAlert, FileText, Package, BookMarked, Store, Users, Database, Package2 } from "lucide-react";
import { TempImportPanel } from "@/components/import/temp/TempImportPanel";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { usePermissions } from "@/lib/permissions";
import type { SectionKey } from "@/contexts/AuthContext";

// Normalizza una label di gamma: lowercase, underscore→spazio, rimuove accenti e
// caratteri non alfanumerici, collassa spazi. Usato come prima passata di confronto.
function normGammaLabel(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/_/g, " ")
    .replace(/[^a-z0-9 ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// Levenshtein distance — piccola implementazione iterativa.
function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const prev = new Array(b.length + 1).fill(0).map((_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let curr = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      const next = Math.min(prev[j] + 1, curr + 1, prev[j - 1] + cost);
      prev[j - 1] = curr;
      curr = next;
    }
    prev[b.length] = curr;
  }
  return prev[b.length];
}

// Considera uguali due gamme se la versione normalizzata coincide oppure se
// la distanza di Levenshtein è ≤ max(2, 15% della lunghezza) — tollera typo
// tipo "aereazione" vs "aerazione" già corretti nelle lookup.
function sameGammaFuzzy(a: string, b: string): boolean {
  const na = normGammaLabel(a);
  const nb = normGammaLabel(b);
  if (!na || !nb) return false;
  if (na === nb) return true;
  const threshold = Math.max(2, Math.floor(Math.max(na.length, nb.length) * 0.15));
  return levenshtein(na, nb) <= threshold;
}

interface GammaAttrIndex {
  byNormalized: Map<string, string>;
  candidates: Array<{ normalized: string; canonical: string }>;
}

function createGammaAttrIndex(): GammaAttrIndex {
  return { byNormalized: new Map(), candidates: [] };
}

function normalizeAttrComparable(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/aereazion/g, "aerazion")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function addGammaAttrCandidate(index: GammaAttrIndex, canonical: string, label?: string | null) {
  const normalized = normalizeAttrComparable(label || canonical);
  if (!normalized) return;
  if (!index.byNormalized.has(normalized)) index.byNormalized.set(normalized, canonical);
  if (!index.candidates.some((c) => c.normalized === normalized && c.canonical === canonical)) {
    index.candidates.push({ normalized, canonical });
  }
}

function resolveGammaAttrName(rawName: string, index: GammaAttrIndex): string | null {
  const normalized = normalizeAttrComparable(rawName);
  if (!normalized) return null;
  const exact = index.byNormalized.get(normalized);
  if (exact) return exact;
  if (normalized.length < 5) return null;

  let best: { canonical: string; distance: number } | null = null;
  let ties = 0;
  for (const candidate of index.candidates) {
    const distance = levenshtein(normalized, candidate.normalized);
    const threshold = Math.max(1, Math.floor(Math.max(normalized.length, candidate.normalized.length) * 0.18));
    if (distance <= threshold && (!best || distance < best.distance)) {
      best = { canonical: candidate.canonical, distance };
      ties = 1;
    } else if (best && distance === best.distance) {
      ties++;
    }
  }

  return best && ties === 1 ? best.canonical : null;
}

const STEPS_DEFAULT = ["Upload", "Mapping", "Validazione", "Risultato"];
const STEPS_ATTR = ["Upload", "Mapping", "Path → Gamma", "Validazione", "Risultato"];
const ARTICLE_UPDATE_IMPORTS: ImportType[] = [
  "articoli_settore_reparto_gamma",
  "articoli_brand_pim",
  "articoli_cod_padre",
  "articoli_scheda_prodotto",
  "articoli_master_pack",
  "articoli_attributi_dettaglio",
];

// Wrapper sul helper condiviso (compat: stesso nome usato in tutto il file)
const normalizeArticleCdpar = normalizeCdpar;

const normalizeNullableText = (value?: string) => {
  const trimmed = (value ?? "").trim();
  return trimmed || null;
};

const formatImportError = (message?: string) => {
  const raw = message ?? "Errore sconosciuto";
  if (raw.toLowerCase().includes("violates row-level security policy")) {
    return "Permessi insufficienti per aggiornare articoli: verifica di avere il permesso di scrittura sulla sezione articoli corretta.";
  }
  return raw;
};

const decodeCsvFile = async (file: File): Promise<string> => {
  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer);

  let text: string;
  if (bytes[0] === 0xff && bytes[1] === 0xfe) {
    text = new TextDecoder("utf-16le").decode(bytes.subarray(2));
  } else if (bytes[0] === 0xfe && bytes[1] === 0xff) {
    text = new TextDecoder("utf-16be").decode(bytes.subarray(2));
  } else if (bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
    text = new TextDecoder("utf-8").decode(bytes.subarray(3));
  } else {
    try {
      text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    } catch {
      text = new TextDecoder("windows-1252").decode(bytes);
    }
  }

  // Blocca file già corrotti (contengono U+FFFD): il dato originale è perso,
  // importarli propagherebbe i caratteri `�` in DB.
  const badIdx = text.indexOf("\uFFFD");
  if (badIdx >= 0) {
    const start = Math.max(0, badIdx - 30);
    const end = Math.min(text.length, badIdx + 30);
    const snippet = text.slice(start, end).replace(/\s+/g, " ");
    throw new Error(
      `Il file CSV contiene caratteri corrotti (\uFFFD) — es. "...${snippet}...". ` +
      `Probabilmente è stato aperto e risalvato in Excel con encoding sbagliato, ` +
      `perdendo definitivamente lettere accentate (à, è, ì, ò, ù, °, €). ` +
      `Esporta di nuovo il file dalla fonte originale scegliendo "CSV UTF-8 (delimitato da virgole)".`
    );
  }
  return text;
};

export default function ImportPage() {
  const { user, profile } = useAuth();
  const [step, setStep] = useState(0);
  const [file, setFile] = useState<File | null>(null);
  const [importType, setImportType] = useState<ImportType | null>(null);
  const [csvData, setCsvData] = useState<Record<string, string>[]>([]);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [validations, setValidations] = useState<RowValidation[]>([]);
  const [progress, setProgress] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [stats, setStats] = useState({ created: 0, updated: 0, skipped: 0, errors: 0 });
  const [reportRows, setReportRows] = useState<Record<string, string>[]>([]);
  const [pathMapping, setPathMapping] = useState<PathMappingResult | null>(null);
  const [runPhase, setRunPhase] = useState<string>("");
  const [isValidating, setIsValidating] = useState(false);
  // Cache popolata in validazione, riutilizzata in runImport per evitare doppio fetch
  const articleCacheRef = useRef<Map<string, { id: string; attributes: Record<string, any>; clmer?: string | null }>>(new Map());
  const [gammaChangePrompt, setGammaChangePrompt] = useState<null | {
    mode: "valid" | "valid_warning";
    changes: { cdpar: string; oldGamma: string; newGamma: string; attrCount: number }[];
  }>(null);

  const isAttrFlow = importType === "attributi_gamma";
  const STEPS = isAttrFlow ? STEPS_ATTR : STEPS_DEFAULT;

  const mappedRows = useMemo(() => {
    return csvData.map((row) => {
      const mapped: Record<string, string> = {};
      for (const [csvCol, dbField] of Object.entries(mapping)) {
        if (dbField !== "__skip__") mapped[dbField] = row[csvCol] ?? "";
      }
      return mapped;
    });
  }, [csvData, mapping]);

  const mappedHeaders = useMemo(() => {
    return Object.values(mapping).filter((v) => v !== "__skip__");
  }, [mapping]);

  const parseFile = useCallback(
    async (f: File) => {
      setFile(f);
      let csvText = "";
      try {
        csvText = await decodeCsvFile(f);
      } catch (error: any) {
        toast({ title: "Errore lettura CSV", description: error?.message ?? "Impossibile leggere il file", variant: "destructive" });
        return;
      }

      // Wide-format speciale: header con "valore"/"obbligatorio" ripetuti.
      // Leggiamo SENZA header e mappiamo per indice in chiavi sintetiche.
      if (importType === "articoli_attributi_dettaglio") {
        Papa.parse(csvText, {
          header: false,
          skipEmptyLines: true,
          delimitersToGuess: [";", ",", "\t", "|"],
          complete: (results) => {
            const rows = results.data as string[][];
            if (rows.length === 0) return;
            // La prima riga è l'header del file (la mostriamo come anteprima),
            // le successive sono dati.
            const dataRows = rows.slice(1);
            const syntheticHeaders = [
              "sku",
              ...Array.from({ length: ATTR_DETTAGLIO_MAX_BLOCKS }, (_, i) => [
                `attributo_${i + 1}`, `valore_${i + 1}`, `obbligatorio_${i + 1}`,
              ]).flat(),
            ];
            const parsed: Record<string, string>[] = dataRows.map((cols) => {
              const out: Record<string, string> = { sku: (cols[0] ?? "").toString() };
              for (let i = 0; i < ATTR_DETTAGLIO_MAX_BLOCKS; i++) {
                const base = 1 + i * 3;
                out[`attributo_${i + 1}`] = (cols[base] ?? "").toString();
                out[`valore_${i + 1}`] = (cols[base + 1] ?? "").toString();
                out[`obbligatorio_${i + 1}`] = (cols[base + 2] ?? "").toString();
              }
              return out;
            });
            setCsvHeaders(syntheticHeaders);
            setCsvData(parsed);
            // Auto-mapping identità (csvCol === dbField)
            const autoMap: Record<string, string> = {};
            syntheticHeaders.forEach((h) => { autoMap[h] = h; });
            setMapping(autoMap);
          },
        });
        return;
      }

      Papa.parse(csvText, {
        header: true,
        skipEmptyLines: true,
        delimitersToGuess: [";", ",", "\t", "|"],
        complete: (results) => {
          const headers = results.meta.fields ?? [];
          setCsvHeaders(headers);
          setCsvData(results.data as Record<string, string>[]);

          if (importType) {
            const tpl = TEMPLATES[importType];
            const autoMap: Record<string, string> = {};
            headers.forEach((h) => {
              const lower = h.toLowerCase();
              const match = tpl.headers.find((db) => db.toLowerCase() === lower);
              if (match) autoMap[h] = match;
            });
            setMapping(autoMap);
          }
        },
      });
    },
    [importType]
  );

  const goToValidation = async (pathMap?: PathMappingResult) => {
    if (!importType) return;
    if (isValidating) return; // guard contro doppi click
    setIsValidating(true);

    let existingKeys = new Set<string>();
    let extraContext: { existingSettori?: Map<string, string>; pathToGamma?: Map<string, string | null> } = {};

    // Lookup mirata: query DB SOLO sui codici presenti nel CSV (chunk piccoli per limitare URL length)
    const LOOKUP_CHUNK = 500;
    articleCacheRef.current.clear();

    const isArticleType =
      importType === "articoli_settore_reparto_gamma" ||
      importType === "articoli_brand_pim" ||
      importType === "articoli_cod_padre" ||
      importType === "articoli_scheda_prodotto" ||
      importType === "articoli_master_pack" ||
      importType === "articoli_attributi_dettaglio";

    // Per articoli_attributi_dettaglio il codice articolo si chiama "sku" anziché "cdpar"
    const articleCodeField = importType === "articoli_attributi_dettaglio" ? "sku" : "cdpar";

    if (importType === "fornitori_buyer_dp") {
      const csvCdfor = Array.from(new Set(
        mappedRows.map((r) => (r.cdfor ?? "").trim()).filter(Boolean)
      ));
      for (let i = 0; i < csvCdfor.length; i += LOOKUP_CHUNK) {
        const chunk = csvCdfor.slice(i, i + LOOKUP_CHUNK);
        const { data, error } = await supabase
          .from("archivio_fornitori_fraschetti")
          .select("cdfor")
          .in("cdfor", chunk);
        if (error) {
          console.error("[Validation] Errore lookup fornitori:", error);
          toast({ title: "Errore validazione", description: error.message, variant: "destructive" });
          setIsValidating(false);
          return;
        }
        (data ?? []).forEach((r: any) => {
          const k = (r.cdfor ?? "").trim();
          if (k) existingKeys.add(k);
        });
      }
    } else if (isArticleType) {
      // Estrai i cdpar UNICI dal CSV in formato DB (15 char, zero-pad numerico)
      const cdparMap = new Map<string, string>(); // dbCdpar (15) -> key (compact)
      mappedRows.forEach((r) => {
        const padded = normalizeCdpar(r[articleCodeField]);
        if (padded) cdparMap.set(padded, cdparKey(r[articleCodeField]));
      });
      const dbCdpars = Array.from(cdparMap.keys());
      console.log(`[Validation] Lookup mirato di ${dbCdpars.length} cdpar unici dal CSV...`);

      const selectCols = importType === "articoli_settore_reparto_gamma"
        ? "id, cdpar, attributes, clmer"
        : "id, cdpar, attributes";
      const settoriMap = new Map<string, string>();

      for (let i = 0; i < dbCdpars.length; i += LOOKUP_CHUNK) {
        const chunk = dbCdpars.slice(i, i + LOOKUP_CHUNK);
        try {
          const { data, error } = await supabase
            .from("archivio_articoli_fraschetti")
            .select(selectCols)
            .in("cdpar", chunk);
          if (error) throw error;
          (data ?? []).forEach((a: any) => {
            const key = cdparKey(a.cdpar);
            if (!key) return;
            existingKeys.add(key);
            articleCacheRef.current.set(key, {
              id: a.id,
              attributes: (a.attributes as Record<string, any>) ?? {},
              clmer: a.clmer ?? null,
            });
            if (a.clmer) settoriMap.set(key, String(a.clmer).trim());
          });
        } catch (e: any) {
          console.error(`[Validation] Errore chunk ${i}-${i + LOOKUP_CHUNK}:`, e);
          toast({ title: "Errore validazione", description: e?.message ?? "Errore lookup articoli", variant: "destructive" });
          setIsValidating(false);
          return;
        }
      }
      console.log(`[Validation] Trovati ${existingKeys.size}/${dbCdpars.length} articoli in archivio`);

      if (importType === "articoli_settore_reparto_gamma") {
        extraContext = { existingSettori: settoriMap };
      }
    } else if (importType === "attributi_gamma") {
      extraContext = { pathToGamma: pathMap?.pathToGamma ?? pathMapping?.pathToGamma };
    }

    const results = validateRows(mappedRows, importType, existingKeys, extraContext);
    setValidations(results);
    setStep(isAttrFlow ? 3 : 2);
    setIsValidating(false);
  };

  const handleAfterMapping = () => {
    if (isAttrFlow) {
      setStep(2); // → Path → Gamma
    } else {
      goToValidation();
    }
  };

  const handlePathMappingDone = (result: PathMappingResult) => {
    setPathMapping(result);
    goToValidation(result);
  };

  // Wrapper: intercetta l'import per reparto/gamma e mostra il dialog di conferma
  // se ci sono articoli che cambiano gamma e perderanno gli attributi gamma esistenti.
  const requestImport = (mode: "valid" | "valid_warning") => {
    if (importType === "articoli_settore_reparto_gamma") {
      const rowsToImport = mappedRows.filter((_, i) => {
        const v = validations[i];
        return mode === "valid" ? v?.status === "valid" : v?.status !== "error";
      });
      const changes: { cdpar: string; oldGamma: string; newGamma: string; attrCount: number }[] = [];
      for (const row of rowsToImport) {
        const key = cdparKey(row.cdpar);
        const cached = articleCacheRef.current.get(key);
        if (!cached) continue;
        const oldGamma = (cached.attributes?.gamma ?? "").toString().trim();
        const newGamma = (row.gamma ?? "").trim();
        if (!newGamma || !oldGamma || sameGammaFuzzy(newGamma, oldGamma)) continue;
        const gammaAttrs = (cached.attributes?.gamma_attrs && typeof cached.attributes.gamma_attrs === "object")
          ? cached.attributes.gamma_attrs as Record<string, any>
          : {};
        const attrCount = Object.keys(gammaAttrs).length;
        if (attrCount === 0) continue;
        changes.push({ cdpar: key, oldGamma, newGamma, attrCount });
      }
      if (changes.length > 0) {
        setGammaChangePrompt({ mode, changes });
        return;
      }
    }
    runImport(mode);
  };

  const runImport = async (mode: "valid" | "valid_warning") => {
    if (!importType) return;
    const resultStep = isAttrFlow ? 4 : 3;
    setStep(resultStep);
    setIsRunning(true);
    setProgress(0);
    setRunPhase("Preparazione import...");
    const tpl = TEMPLATES[importType];

    const rowsToImport = mappedRows.filter((_, i) => {
      const v = validations[i];
      return mode === "valid" ? v.status === "valid" : v.status !== "error";
    });

    // Batch più piccolo per gli update articoli (audit trigger pesante)
    const isArticleUpdate = ARTICLE_UPDATE_IMPORTS.includes(importType);
    const BATCH = isArticleUpdate ? 100 : 500;
    let created = 0, updated = 0, errors = 0;
    const report: Record<string, string>[] = [];
    const existingArticles = new Map<string, { id: string; attributes: Record<string, any> }>();

    let session: any = null;

    try {
      if (isArticleUpdate) {
        // 1) Riusa la cache popolata in validazione (key = cdparKey compact)
        const cache = articleCacheRef.current;

        // 2) Calcola i cdpar effettivamente richiesti dalle righe da importare
        const articleCodeField = importType === "articoli_attributi_dettaglio" ? "sku" : "cdpar";
        const csvCdparKeys = Array.from(new Set(
          rowsToImport
            .map((row) => cdparKey(row[articleCodeField]))
            .filter((k) => k.length > 0)
        ));

        // 3) Popola existingArticles dalla cache, traccia i mancanti
        const missing: string[] = [];
        csvCdparKeys.forEach((k) => {
          const cached = cache.get(k);
          if (cached) {
            // Riconverti la chiave a formato DB (15 char) usato nei payload
            const dbKey = normalizeArticleCdpar(k);
            existingArticles.set(dbKey, { id: cached.id, attributes: cached.attributes });
          } else {
            missing.push(k);
          }
        });

        // 4) Fetch residuale solo per i mancanti (chunk piccoli)
        if (missing.length > 0) {
          setRunPhase(`Caricamento ${missing.length} articoli residui...`);
          console.log(`[Import] Fetch residuale per ${missing.length} cdpar non in cache`);
          const RESIDUAL_CHUNK = 80;
          const dbMissing = missing.map((k) => normalizeArticleCdpar(k));
          for (let i = 0; i < dbMissing.length; i += RESIDUAL_CHUNK) {
            const chunk = dbMissing.slice(i, i + RESIDUAL_CHUNK);
            const { data, error } = await supabase
              .from("archivio_articoli_fraschetti")
              .select("id, cdpar, attributes")
              .in("cdpar", chunk);
            if (error) {
              console.error("[Import] Errore fetch residuale:", error);
              throw new Error(`Errore caricamento articoli: ${error.message}`);
            }
            (data ?? []).forEach((article: any) => {
              existingArticles.set(article.cdpar, {
                id: article.id,
                attributes: (article.attributes as Record<string, any>) ?? {},
              });
            });
            setProgress(Math.min(((i + RESIDUAL_CHUNK) / dbMissing.length) * 10, 10));
          }
        }

        console.log(`[Import] Articoli pronti: ${existingArticles.size}/${csvCdparKeys.length}`);
        if (existingArticles.size === 0 && csvCdparKeys.length > 0) {
          throw new Error(`Nessuno dei ${csvCdparKeys.length} cdpar del CSV è stato trovato in archivio. Controlla i codici.`);
        }
        setRunPhase("Scrittura batch in corso...");
      } else {
        setRunPhase("Scrittura batch in corso...");
      }

      try {
        const { data: s } = await supabase
          .from("import_sessions" as any)
          .insert({
            import_type: importType,
            filename: file?.name,
            total_rows: rowsToImport.length,
            user_id: user?.id,
            user_email: profile?.email,
          } as any)
          .select("id")
          .single() as any;
        session = s;
      } catch (e) {
        console.warn("[Import] import_sessions insert fallita (non bloccante):", e);
      }

    if (importType === "attributi_gamma") {
      // Special: configure gamma_attributes + lookup_values for variants
      const pathMap = pathMapping?.pathToGamma ?? new Map<string, string | null>();

      // Preload all gamma_codes coinvolti in un'unica query
      const gammaCodesInvolved = Array.from(new Set(
        rowsToImport
          .map(r => pathMap.get((r.gamma ?? "").trim()))
          .filter((c): c is string => !!c)
      ));
      const existingAttrsMap = new Map<string, string>(); // key=`${gammaCode}|${attributeName}` → id
      if (gammaCodesInvolved.length > 0) {
        const { data: existingAttrs } = await supabase
          .from("gamma_attributes")
          .select("id, gamma_code, attribute_name")
          .in("gamma_code", gammaCodesInvolved);
        (existingAttrs ?? []).forEach((a: any) => {
          existingAttrsMap.set(`${a.gamma_code}|${a.attribute_name}`, a.id);
        });
      }

      // Preload existing lookup_values codes per category
      const lookupCategoriesInvolved = new Set<string>();
      rowsToImport.forEach((row) => {
        const path = (row.gamma ?? "").trim();
        const attributo = (row.attributo ?? "").trim();
        const variants = parseVarianti(row.varianti ?? "");
        const gammaCode = pathMap.get(path);
        if (gammaCode && attributo && variants.length > 0) {
          lookupCategoriesInvolved.add(buildAttrLookupCategory(gammaCode, attributo));
        }
      });
      const existingLookupsMap = new Map<string, Set<string>>(); // category → Set(codes)
      if (lookupCategoriesInvolved.size > 0) {
        const { data: existingLookups } = await supabase
          .from("lookup_values")
          .select("category, code")
          .in("category", Array.from(lookupCategoriesInvolved));
        (existingLookups ?? []).forEach((r: any) => {
          if (!existingLookupsMap.has(r.category)) existingLookupsMap.set(r.category, new Set());
          existingLookupsMap.get(r.category)!.add(r.code);
        });
      }

      // Process rows: only DB write per row, no preliminary selects.
      // sort_order = posizione della riga nel CSV (per-gamma), così l'ordine
      // mostrato in UI rispecchia esattamente l'ordine del file importato.
      const lookupRowsToInsert: any[] = [];
      const sortCounters = new Map<string, number>(); // gammaCode -> next sort_order
      for (let i = 0; i < rowsToImport.length; i++) {
        const row = rowsToImport[i];
        const path = (row.gamma ?? "").trim();
        const attributo = (row.attributo ?? "").trim();
        const displayName = (row.display_name ?? "").trim() || deriveDisplayName(attributo);
        const isRequired = parseObbligo(row.obbligo ?? "");
        const variants = parseVarianti(row.varianti ?? "");
        const gammaCode = pathMap.get(path) || null;

        try {
          if (!gammaCode) throw new Error("Gamma non risolta");

          const lookupCategory = variants.length > 0
            ? buildAttrLookupCategory(gammaCode, attributo)
            : null;

          const rowSortOrder = sortCounters.get(gammaCode) ?? 0;
          sortCounters.set(gammaCode, rowSortOrder + 1);

          const existingId = existingAttrsMap.get(`${gammaCode}|${attributo}`);
          if (existingId) {
            const { error } = await supabase
              .from("gamma_attributes")
              .update({
                display_name: displayName,
                lookup_category: lookupCategory,
                is_required: isRequired,
                sort_order: rowSortOrder,
              } as any)
              .eq("id", existingId);
            if (error) throw error;
            updated++;
          } else {
            const { error } = await supabase
              .from("gamma_attributes")
              .insert({
                gamma_code: gammaCode,
                attribute_name: attributo,
                display_name: displayName,
                lookup_category: lookupCategory,
                is_required: isRequired,
                has_unit_select: false,
                sort_order: rowSortOrder,
              } as any);
            if (error) throw error;
            created++;
          }

          // Accumula varianti nuove per insert batch finale
          if (lookupCategory && variants.length > 0) {
            const existingCodes = existingLookupsMap.get(lookupCategory) ?? new Set<string>();
            variants.forEach((v, idx) => {
              if (!existingCodes.has(v)) {
                lookupRowsToInsert.push({
                  category: lookupCategory,
                  code: v,
                  label: v,
                  sort_order: idx,
                  is_active: true,
                  synced_as400: false,
                });
                existingCodes.add(v); // evita duplicati nello stesso batch
              }
            });
            existingLookupsMap.set(lookupCategory, existingCodes);
          }

          report.push({
            ...row,
            resolved_gamma: gammaCode,
            lookup_category: lookupCategory ?? "",
            import_result: "ok",
            error_message: "",
          });
        } catch (e: any) {
          errors++;
          report.push({ ...row, import_result: "error", error_message: e.message });
        }
        setProgress(((i + 1) / rowsToImport.length) * 100);
      }

      // Batch insert di tutte le varianti nuove in una singola chiamata
      if (lookupRowsToInsert.length > 0) {
        const { error: lookupErr } = await supabase
          .from("lookup_values")
          .insert(lookupRowsToInsert as any);
        if (lookupErr) console.error("Lookup batch insert error:", lookupErr);
      }
    } else if (importType === "articoli_settore_reparto_gamma" || importType === "articoli_brand_pim" || importType === "articoli_cod_padre" || importType === "articoli_scheda_prodotto" || importType === "articoli_master_pack" || importType === "articoli_attributi_dettaglio") {
      const codeField = importType === "articoli_attributi_dettaglio" ? "sku" : "cdpar";

      // Per articoli_attributi_dettaglio: carica TUTTI gli attributi gamma e le label
      // delle gamme da lookup_values, così possiamo risolvere fuzzy anche gli articoli
      // la cui attributes.gamma è la LABEL (a volte con accenti mancanti o typo)
      // invece del code reale (es. "Alta Visibilit " → "alta_visibilit",
      // "Aereatori e Rulli" → "aeratori_e_rulli", "Bauli E Portattrezzi" → "bauli_e_portaattrezzi").
      const gammaAttrsByGamma = new Map<string, GammaAttrIndex>(); // key: gamma_code reale
      const gammaResolveCache = new Map<string, string | null>();
      const gammaKeyIndex: Array<{ normalized: string; code: string }> = [];
      const resolveArticleGammaToCode = (raw: string): string | null => {
        const key = raw.trim();
        if (!key) return null;
        if (gammaResolveCache.has(key)) return gammaResolveCache.get(key)!;
        const n = normGammaLabel(key);
        if (!n) { gammaResolveCache.set(key, null); return null; }
        let hit = gammaKeyIndex.find((e) => e.normalized === n);
        if (!hit) {
          let best: { code: string; dist: number } | null = null;
          let ties = 0;
          for (const e of gammaKeyIndex) {
            const thr = Math.max(2, Math.floor(Math.max(n.length, e.normalized.length) * 0.2));
            const d = levenshtein(n, e.normalized);
            if (d <= thr && (!best || d < best.dist)) { best = { code: e.code, dist: d }; ties = 1; }
            else if (best && d === best.dist) ties++;
          }
          if (best && ties === 1) hit = { normalized: n, code: best.code };
        }
        const code = hit?.code ?? null;
        gammaResolveCache.set(key, code);
        return code;
      };

      if (importType === "articoli_attributi_dettaglio") {
        const [gaRes, lvRes] = await Promise.all([
          supabase.from("gamma_attributes").select("gamma_code, attribute_name, display_name"),
          supabase.from("lookup_values").select("code, label").eq("category", "gamma"),
        ]);
        if (gaRes.error) throw new Error(`Errore caricamento attributi gamma: ${gaRes.error.message}`);
        if (lvRes.error) throw new Error(`Errore caricamento lookup gamme: ${lvRes.error.message}`);
        (gaRes.data ?? []).forEach((a: any) => {
          if (!gammaAttrsByGamma.has(a.gamma_code)) gammaAttrsByGamma.set(a.gamma_code, createGammaAttrIndex());
          const index = gammaAttrsByGamma.get(a.gamma_code)!;
          addGammaAttrCandidate(index, a.attribute_name);
          addGammaAttrCandidate(index, a.attribute_name, a.display_name);
        });
        const seen = new Set<string>();
        const pushKey = (code: string, raw: string) => {
          const n = normGammaLabel(raw);
          if (!n) return;
          const k = `${n}|${code}`;
          if (seen.has(k)) return;
          seen.add(k);
          gammaKeyIndex.push({ normalized: n, code });
        };
        Array.from(gammaAttrsByGamma.keys()).forEach((code) => pushKey(code, code));
        (lvRes.data ?? []).forEach((l: any) => { if (l.code) pushKey(l.code, l.label || l.code); });
      }

      const entries = rowsToImport.map((row): { row: Record<string, string>; payload: Record<string, any> | null; error: string | null; warning?: string } => {
        const cdpar = normalizeArticleCdpar(row[codeField]);
        const existing = existingArticles.get(cdpar);

        if (!existing) {
          return { row, payload: null as Record<string, any> | null, error: "Articolo non trovato: import bloccato, nessuna nuova riga creata." };
        }

        if (importType === "articoli_attributi_dettaglio") {
          const articleGammaRaw = (existing.attributes?.gamma ?? "").toString().trim();
          if (!articleGammaRaw) {
            return { row, payload: null, error: "Articolo senza gamma assegnata: impossibile importare attributi." };
          }
          const resolvedGammaCode = resolveArticleGammaToCode(articleGammaRaw);
          if (!resolvedGammaCode) {
            return { row, payload: null, error: `Gamma "${articleGammaRaw}" non riconosciuta tra le gamme configurate (nessun match anche fuzzy).` };
          }
          const articleGamma = resolvedGammaCode;
          const allowed = gammaAttrsByGamma.get(articleGamma) ?? createGammaAttrIndex();

          const attrs: Record<string, any> = { ...existing.attributes };
          const prevGammaAttrs: Record<string, any> =
            (attrs.gamma_attrs && typeof attrs.gamma_attrs === "object" && !Array.isArray(attrs.gamma_attrs))
              ? { ...(attrs.gamma_attrs as Record<string, any>) }
              : {};
          let written = 0;
          const skippedUnknown: string[] = [];
          for (let i = 1; i <= ATTR_DETTAGLIO_MAX_BLOCKS; i++) {
            const name = (row[`attributo_${i}`] ?? "").trim();
            const value = (row[`valore_${i}`] ?? "").trim();
            if (!name || !value) continue;
            const resolvedName = resolveGammaAttrName(name, allowed);
            if (!resolvedName) {
              skippedUnknown.push(name);
              continue;
            }
            const prev = (prevGammaAttrs[resolvedName] && typeof prevGammaAttrs[resolvedName] === "object" && !Array.isArray(prevGammaAttrs[resolvedName]))
              ? prevGammaAttrs[resolvedName] as Record<string, any>
              : {};
            prevGammaAttrs[resolvedName] = { value, unit: typeof prev.unit === "string" ? prev.unit : "" };
            written++;
          }
          if (written === 0) {
            const suffix = skippedUnknown.length > 0
              ? ` Attributi saltati perché non definiti nella gamma "${articleGamma}": ${skippedUnknown.join(", ")}.`
              : "";
            return { row, payload: null, error: `Nessun attributo valido da scrivere.${suffix}` };
          }
          attrs.gamma_attrs = prevGammaAttrs;
          return {
            row,
            error: null,
            warning: skippedUnknown.length > 0
              ? `Attributi saltati perché non definiti nella gamma "${articleGamma}": ${skippedUnknown.join(", ")}`
              : undefined,
            payload: { id: existing.id, cdpar, attributes: attrs },
          };
        }

        if (importType === "articoli_settore_reparto_gamma") {
          const clmer = (row.clmer ?? "").trim();
          const reparto = (row.reparto ?? "").trim();
          const newGamma = (row.gamma ?? "").trim();
          const payload: Record<string, any> = { id: existing.id, cdpar };
          if (clmer) payload.clmer = clmer;
          if (reparto || newGamma) {
            const attrs = { ...existing.attributes };
            const oldGamma = (attrs.gamma ?? "").toString().trim();
            if (reparto) attrs.reparto = reparto;
            if (newGamma) attrs.gamma = newGamma;
            // Gamma realmente cambiata → azzera attributi gamma (per-gamma).
            if (newGamma && oldGamma && !sameGammaFuzzy(newGamma, oldGamma)) {
              attrs.gamma_attrs = {};
            }
            payload.attributes = attrs;
          }
          if (!clmer && !reparto && !newGamma) {
            return { row, payload: null, error: "Nessun campo valorizzato (settore/reparto/gamma)." };
          }
          return { row, error: null, payload };
        }

        if (importType === "articoli_brand_pim") {
          const brand = (row.clas2 ?? "").trim().toUpperCase();
          const linea = (row.nmdis ?? "").trim();
          const payload: any = { id: existing.id, cdpar };
          if (brand) payload.clas2 = brand;
          if (linea) payload.nmdis = linea;
          if (!brand && !linea) {
            return { row, payload: null, error: "Nessun campo valorizzato (clas2/nmdis)." };
          }
          return { row, error: null, payload };
        }


        if (importType === "articoli_cod_padre") {
          const raw = (row.cod_padre ?? "").trim();
          return {
            row,
            error: null,
            payload: { id: existing.id, cdpar, cod_padre: /^\d{1,6}$/.test(raw) ? raw.padStart(6, "0") : raw },
          };
        }

        if (importType === "articoli_master_pack") {
          const raw = String(row.master_pack ?? "").trim().replace(",", ".");
          if (raw === "") return { row, payload: null, error: "master_pack mancante" };
          const n = Number(raw);
          if (!Number.isFinite(n) || n < 0 || !Number.isInteger(n)) {
            return { row, payload: null, error: "master_pack deve essere un intero ≥ 0" };
          }
          return { row, error: null, payload: { id: existing.id, cdpar, master_pack: n } };
        }



        if (importType === "articoli_scheda_prodotto") {
          const title = normalizeNullableText(row.titolo_b2b);
          const variant = normalizeNullableText(row.descrizione_variante);
          const description = normalizeNullableText(row.descrizione_b2b);
          const tagsRaw = String(row.tags ?? "").trim();
          let parsedTags: string[] | null = null;
          if (tagsRaw !== "") {
            const seen = new Set<string>();
            parsedTags = [];
            for (const part of tagsRaw.split("|")) {
              const t = part.trim();
              if (!t) continue;
              const key = t.toLowerCase();
              if (seen.has(key)) continue;
              seen.add(key);
              parsedTags.push(t);
            }
            if (parsedTags.length === 0) parsedTags = null;
          }
          const payload: Record<string, any> = { id: existing.id, cdpar };
          // Non sovrascrivere con null: aggiorna solo le colonne valorizzate nel CSV
          if (title !== null) {
            payload.b2b_product_title = title;
            payload.titolo_b2b = title;
          }
          if (variant !== null) {
            payload.descrizione_variante = variant;
          }
          if (description !== null) {
            payload.b2b_product_description = description;
            payload.descrizione_b2b = description;
          }
          if (parsedTags !== null) {
            payload.tags = parsedTags;
          }
          if (Object.keys(payload).length === 2) {
            return { row, payload: null, error: "Riga vuota: né titolo, né descrizione variante, né descrizione prodotto, né tag valorizzati." };
          }
          return { row, error: null, payload };
        }

        return {
          row,
          error: null,
          payload: { id: existing.id, cdpar },
        };
      });

      for (let i = 0; i < entries.length; i += BATCH) {
        const batch = entries.slice(i, i + BATCH);
        const validBatch = batch.filter((entry) => entry.payload);

        batch
          .filter((entry) => entry.error)
          .forEach((entry) => {
            errors++;
            report.push({ ...entry.row, import_result: "error", error_message: entry.error ?? "Articolo non trovato" });
          });

        if (validBatch.length > 0) {
          for (const entry of validBatch) {
            try {
              const payload = entry.payload as Record<string, any>;
              const id = payload.id;
              const updatePayload = { ...payload };
              delete updatePayload.id;
              delete updatePayload.cdpar;

              if (!id || Object.keys(updatePayload).length === 0) {
                throw new Error("Nessun campo aggiornabile valorizzato per questo articolo.");
              }

              const { data, error } = await supabase
                .from("archivio_articoli_fraschetti")
                .update(updatePayload as any)
                .eq("id", id)
                .select("id")
                .maybeSingle();

              if (error) throw error;
              if (!data) {
                throw new Error("Nessuna riga aggiornata: articolo non trovato o permessi insufficienti per aggiornare articoli.");
              }

              updated++;
              report.push({ ...entry.row, import_result: "ok", error_message: entry.warning ?? "" });
            } catch (e: any) {
              errors++;
              report.push({ ...entry.row, import_result: "error", error_message: formatImportError(e?.message) });
            }
          }
        }

        setProgress(Math.min(((i + BATCH) / entries.length) * 100, 100));
      }
    } else {
      for (let i = 0; i < rowsToImport.length; i += BATCH) {
        const batch = rowsToImport.slice(i, i + BATCH);
        try {
          const { error } = await supabase
            .from(tpl.table as any)
            .upsert(batch as any, { onConflict: tpl.conflictKey })
            .select(tpl.conflictKey);

          if (error) throw error;

          if (tpl.syncAs400) {
            const syncRows = batch.map((r) => ({
              cdpar: r.cdpar,
              operation: "upsert",
              payload: r,
              status: "pending",
            }));
            await supabase.from("as400_sync_queue").insert(syncRows);
          }

          batch.forEach((r) => {
            created++;
            report.push({ ...r, import_result: "ok", error_message: "" });
          });
        } catch (e: any) {
          batch.forEach((r) => {
            errors++;
            report.push({ ...r, import_result: "error", error_message: e.message });
          });
        }
        setProgress(Math.min(((i + BATCH) / rowsToImport.length) * 100, 100));
      }
    }
    } catch (e: any) {
      console.error("[Import] Errore fatale:", e);
      toast({ title: "Errore import", description: e?.message ?? "Errore sconosciuto", variant: "destructive" });
    } finally {
      const skipped = mappedRows.length - rowsToImport.length;
      setStats({ created, updated, skipped, errors });
      setReportRows(report);
      setIsRunning(false);
      setProgress(100);
      setRunPhase("");

      if (session?.id) {
        await supabase
          .from("import_sessions" as any)
          .update({ status: "completed", created_rows: created, updated_rows: updated, error_rows: errors, skipped_rows: skipped, completed_at: new Date().toISOString() } as any)
          .eq("id", session.id);
      }

      toast({ title: "Import completato", description: `${created + updated} righe processate, ${errors} errori.` });
    }
  };

  // Step routing
  const isStepUpload = step === 0;
  const isStepMapping = step === 1;
  const isStepPathMapping = isAttrFlow && step === 2;
  const isStepValidation = isAttrFlow ? step === 3 : step === 2;
  const isStepResult = isAttrFlow ? step === 4 : step === 3;

  const { sectionVisible } = usePermissions();
  const importTabs: Array<{ value: string; section: SectionKey }> = [
    { value: "una-tantum", section: "import_una_tantum" },
    { value: "documentazione", section: "import_documentazione" },
    { value: "giornaliera", section: "import_giornaliera" },
    { value: "clienti", section: "import_clienti" },
    { value: "import-temp", section: "import_temp" },
  ];
  const visibleImport = importTabs.filter((t) => sectionVisible(t.section));
  const defaultImportTab = visibleImport[0]?.value ?? "una-tantum";

  if (visibleImport.length === 0) {
    return (
      <div className="p-6 max-w-5xl mx-auto">
        <div className="rounded-md border bg-muted/40 p-8 text-center text-sm text-muted-foreground">
          Non hai i permessi per visualizzare alcuna sezione di Import/Export. Contatta un amministratore.
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <Tabs defaultValue={defaultImportTab} className="space-y-6">
        <TabsList className="h-auto flex-wrap gap-1">
          {sectionVisible("import_una_tantum") && (
            <TabsTrigger value="una-tantum" className="flex-col items-start gap-0 py-2">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Una tantum</span>
              <span>Anagrafiche &amp; Brand</span>
            </TabsTrigger>
          )}
          {sectionVisible("import_documentazione") && (
            <TabsTrigger value="documentazione" className="flex-col items-start gap-0 py-2">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Una tantum</span>
              <span>Documentazione</span>
            </TabsTrigger>
          )}
          {sectionVisible("import_giornaliera") && (
            <TabsTrigger value="giornaliera" className="flex-col items-start gap-0 py-2">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Giornaliera</span>
              <span><Package className="h-4 w-4 mr-1 inline" />Giacenze</span>
            </TabsTrigger>
          )}
          {sectionVisible("import_clienti") && (
            <TabsTrigger value="clienti" className="flex-col items-start gap-0 py-2">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Settimanale</span>
              <span><Users className="h-4 w-4 mr-1 inline" />Clienti</span>
            </TabsTrigger>
          )}
          {sectionVisible("import_assortimenti") && (
            <TabsTrigger value="assortimenti" className="flex-col items-start gap-0 py-2">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Settimanale</span>
              <span><Package2 className="h-4 w-4 mr-1 inline" />Assortimenti</span>
            </TabsTrigger>
          )}
          {sectionVisible("import_temp") && (
            <TabsTrigger value="import-temp" className="flex-col items-start gap-0 py-2">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Temporaneo</span>
              <span><Database className="h-4 w-4 mr-1 inline" />Import Temporaneo</span>
            </TabsTrigger>
          )}
        </TabsList>

        {sectionVisible("import_una_tantum") && (
          <TabsContent value="una-tantum">
            <Tabs defaultValue="csv" className="space-y-6">
              <TabsList>
                <TabsTrigger value="csv">Import CSV</TabsTrigger>
                <TabsTrigger value="brand-logos">Loghi Brand</TabsTrigger>
                <TabsTrigger value="qualita-dati">Qualità dati</TabsTrigger>
              </TabsList>
              <TabsContent value="csv" className="space-y-0">
                <CsvImportInner
                  STEPS={STEPS}
                  step={step}
                  importType={importType}
                  isStepUpload={isStepUpload}
                  isStepMapping={isStepMapping}
                  isStepPathMapping={isStepPathMapping}
                  isStepValidation={isStepValidation}
                  isStepResult={isStepResult}
                  isAttrFlow={isAttrFlow}
                  file={file}
                  parseFile={parseFile}
                  setImportType={setImportType}
                  setStep={setStep}
                  csvHeaders={csvHeaders}
                  csvData={csvData}
                  mapping={mapping}
                  setMapping={setMapping}
                  handleAfterMapping={handleAfterMapping}
                  mappedRows={mappedRows}
                  handlePathMappingDone={handlePathMappingDone}
                  validations={validations}
                  mappedHeaders={mappedHeaders}
                  runImport={requestImport}
                  progress={progress}
                  isRunning={isRunning}
                  stats={stats}
                  reportRows={reportRows}
                  runPhase={runPhase}
                  isValidating={isValidating}
                />
              </TabsContent>
              <TabsContent value="brand-logos"><BulkBrandLogos /></TabsContent>
              <TabsContent value="qualita-dati"><EncodingHealthPanel /></TabsContent>
            </Tabs>
          </TabsContent>
        )}

        {sectionVisible("import_documentazione") && (
          <TabsContent value="documentazione">
            <Tabs defaultValue="sds" className="space-y-6">
              <TabsList>
                <TabsTrigger value="sds"><ShieldAlert className="h-4 w-4 mr-1" />SDS</TabsTrigger>
                <TabsTrigger value="st"><FileText className="h-4 w-4 mr-1" />ST</TabsTrigger>
                <TabsTrigger value="col"><BookMarked className="h-4 w-4 mr-1" />Collezioni</TabsTrigger>
                <TabsTrigger value="expo"><Store className="h-4 w-4 mr-1" />Expo</TabsTrigger>
              </TabsList>
              <TabsContent value="sds"><SdsImportPage kind="sds" /></TabsContent>
              <TabsContent value="st"><SdsImportPage kind="st" /></TabsContent>
              <TabsContent value="col"><SdsImportPage kind="col" /></TabsContent>
              <TabsContent value="expo"><SdsImportPage kind="expo" /></TabsContent>
            </Tabs>
          </TabsContent>
        )}

        {sectionVisible("import_giornaliera") && (
          <TabsContent value="giornaliera">
            <InventoryImportPanel />
          </TabsContent>
        )}

        {sectionVisible("import_clienti") && (
          <TabsContent value="clienti">
            <CustomersImportPanel />
          </TabsContent>
        )}

        {sectionVisible("import_assortimenti") && (
          <TabsContent value="assortimenti">
            <AssortimentiImportPanel />
          </TabsContent>
        )}

        {sectionVisible("import_temp") && (
          <TabsContent value="import-temp">
            <TempImportPanel />
          </TabsContent>
        )}
      </Tabs>

      <AlertDialog open={!!gammaChangePrompt} onOpenChange={(o) => { if (!o) setGammaChangePrompt(null); }}>
        <AlertDialogContent className="max-w-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Cambio gamma rilevato</AlertDialogTitle>
            <AlertDialogDescription>
              <strong>{gammaChangePrompt?.changes.length ?? 0}</strong> articoli stanno cambiando gamma.
              Gli attributi gamma attualmente salvati su questi codici verranno{" "}
              <strong className="text-destructive">cancellati</strong> (gli attributi sono specifici per gamma).
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-2 select-text">
            <div className="flex justify-end">
              <button
                type="button"
                className="text-xs px-2 py-1 border rounded hover:bg-muted"
                onClick={() => {
                  const rows = gammaChangePrompt?.changes ?? [];
                  const txt = rows.map((c) => `${c.cdpar}\t${c.oldGamma}\t${c.newGamma}\t${c.attrCount}`).join("\n");
                  navigator.clipboard?.writeText(txt).then(
                    () => toast({ title: "Copiato", description: `${rows.length} righe negli appunti` }),
                    () => toast({ title: "Copia fallita", variant: "destructive" }),
                  );
                }}
              >
                📋 Copia tutto
              </button>
            </div>
            <div className="max-h-72 overflow-auto border rounded-md select-text">
              <table className="w-full text-xs select-text">
                <thead className="sticky top-0 bg-muted">
                  <tr>
                    <th className="text-left px-2 py-1">Cdpar</th>
                    <th className="text-left px-2 py-1">Gamma attuale</th>
                    <th className="text-left px-2 py-1">Nuova gamma</th>
                    <th className="text-right px-2 py-1">Attributi da cancellare</th>
                  </tr>
                </thead>
                <tbody>
                  {gammaChangePrompt?.changes.map((c) => (
                    <tr key={c.cdpar} className="border-t">
                      <td className="px-2 py-1 font-mono select-text">{c.cdpar}</td>
                      <td className="px-2 py-1 select-text">{c.oldGamma}</td>
                      <td className="px-2 py-1 select-text">{c.newGamma}</td>
                      <td className="px-2 py-1 text-right select-text">{c.attrCount}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                const prompt = gammaChangePrompt;
                setGammaChangePrompt(null);
                if (prompt) runImport(prompt.mode);
              }}
            >
              Conferma e cancella attributi
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

interface CsvImportInnerProps {
  STEPS: string[];
  step: number;
  importType: ImportType | null;
  isStepUpload: boolean;
  isStepMapping: boolean;
  isStepPathMapping: boolean;
  isStepValidation: boolean;
  isStepResult: boolean;
  isAttrFlow: boolean;
  file: File | null;
  parseFile: (f: File) => void;
  setImportType: (t: ImportType) => void;
  setStep: (n: number) => void;
  csvHeaders: string[];
  csvData: Record<string, string>[];
  mapping: Record<string, string>;
  setMapping: (m: Record<string, string>) => void;
  handleAfterMapping: () => void;
  mappedRows: Record<string, string>[];
  handlePathMappingDone: (r: PathMappingResult) => void;
  validations: RowValidation[];
  mappedHeaders: string[];
  runImport: (mode: "valid" | "valid_warning") => void;
  progress: number;
  isRunning: boolean;
  stats: { created: number; updated: number; skipped: number; errors: number };
  reportRows: Record<string, string>[];
  runPhase: string;
  isValidating: boolean;
}

function CsvImportInner(p: CsvImportInnerProps) {
  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <h1 className="text-2xl font-bold">Import Massivo CSV</h1>
        {p.importType && TEMPLATES[p.importType] && (
          TEMPLATES[p.importType].pimOnly
            ? <Badge className="bg-blue-600 text-white">PIM</Badge>
            : <Badge className="bg-amber-600 text-white">AS400</Badge>
        )}
      </div>

      <div className="flex items-center gap-2 mb-8">
        {p.STEPS.map((s, i) => (
          <div key={s} className="flex items-center gap-2">
            <Badge variant={i === p.step ? "default" : i < p.step ? "secondary" : "outline"} className="text-xs">
              {i + 1}. {s}
            </Badge>
            {i < p.STEPS.length - 1 && <span className="text-muted-foreground">→</span>}
          </div>
        ))}
      </div>

      {p.isStepUpload && (
        <StepUpload
          file={p.file}
          importType={p.importType}
          onFileChange={p.parseFile}
          onTypeChange={p.setImportType}
          onNext={() => p.setStep(1)}
        />
      )}

      {p.isStepMapping && p.importType && (
        <StepMapping
          csvHeaders={p.csvHeaders}
          csvPreview={p.csvData}
          importType={p.importType}
          mapping={p.mapping}
          onMappingChange={p.setMapping}
          onBack={() => p.setStep(0)}
          onNext={p.handleAfterMapping}
          isLoading={p.isValidating}
        />
      )}

      {p.isStepPathMapping && (
        <StepGammaPathMapping
          csvData={p.mappedRows}
          pathColumn="gamma"
          onBack={() => p.setStep(1)}
          onNext={p.handlePathMappingDone}
        />
      )}

      {p.isStepValidation && (
        <StepValidation
          rows={p.mappedRows}
          validations={p.validations}
          headers={p.mappedHeaders}
          onBack={() => p.setStep(p.isAttrFlow ? 2 : 1)}
          onImport={p.runImport}
        />
      )}

      {p.isStepResult && (
        <StepResult progress={p.progress} isRunning={p.isRunning} stats={p.stats} reportRows={p.reportRows} phaseLabel={p.runPhase} importType={p.importType ?? undefined} />
      )}
    </div>
  );
}


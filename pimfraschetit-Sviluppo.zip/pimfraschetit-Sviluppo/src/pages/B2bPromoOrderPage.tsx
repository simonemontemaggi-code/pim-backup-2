import { useEffect, useMemo, useState } from "react";
import {
  DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove, SortableContext, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { ArrowLeft, GripVertical, Image as ImageIcon, Loader2, Save, Tags, Gift, Layers } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { dateToYyyymmdd, formatYyyymmddDisplay } from "@/lib/as400DateUtils";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type StatusFilter = "active" | "future" | "past";


type PromoRow = {
  id: string;
  wpprgf: number | null;
  wptpbd: string | null;
  wpcca: string | null;
  wpstato: string | null;
  wpdvali: number | null;
  wpdvalf: number | null;
  cover_image_url: string | null;
  b2b_sort_order: number | null;
};

type TemaRow = {
  id: string;
  nome: string;
  image_url: string | null;
  tipo: string | null;
  sort_order: number;
  dal: string | null;
  al: string | null;
};


export default function B2bPromoOrderPage() {
  const [selected, setSelected] = useState<PromoRow | null>(null);

  return (
    <div className="p-6 space-y-4">
      <header className="flex items-center gap-3">
        {selected && (
          <Button variant="ghost" size="sm" onClick={() => setSelected(null)}>
            <ArrowLeft className="h-4 w-4 mr-1" /> Promo
          </Button>
        )}
        <Tags className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-2xl font-semibold leading-tight">
            {selected ? `Ordine offerte — #${selected.wpprgf}` : "Ordine promo B2B"}
          </h1>
          <p className="text-sm text-muted-foreground">
            {selected
              ? "Trascina le offerte per definire l'ordine di visualizzazione sul B2B."
              : "Trascina le promo in corso per definire l'ordine di visualizzazione sul B2B. Clicca una promo per ordinarne le offerte."}
          </p>
        </div>
      </header>

      {selected ? (
        <TemiOrderPanel promo={selected} />
      ) : (
        <PromoOrderPanel onOpen={(p) => setSelected(p)} />
      )}
    </div>
  );
}

// ─────────── PROMO ───────────

function PromoOrderPanel({ onOpen }: { onOpen: (p: PromoRow) => void }) {
  const [rows, setRows] = useState<PromoRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [status, setStatus] = useState<StatusFilter>("active");

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 4 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  useEffect(() => {
    let alive = true;
    setLoading(true);
    supabase
      .from("promo_strutturate_testate")
      .select("id,wpprgf,wptpbd,wpcca,wpstato,wpdvali,wpdvalf,cover_image_url,b2b_sort_order")
      .order("b2b_sort_order", { ascending: true, nullsFirst: false })
      .order("wpprgf", { ascending: false })
      .limit(1000)
      .then(({ data, error }) => {
        if (!alive) return;
        if (error) toast({ title: "Errore", description: error.message, variant: "destructive" });
        setRows((data ?? []) as PromoRow[]);
        setDirty(false);
        setLoading(false);
      });
    return () => { alive = false; };
  }, []);

  const today = useMemo(() => dateToYyyymmdd(new Date()) as number, []);

  const classify = (r: PromoRow): StatusFilter => {
    const di = r.wpdvali ?? 0;
    const df = r.wpdvalf ?? 0;
    if (di && di > today) return "future";
    if (df && df < today) return "past";
    return "active";
  };

  const counts = useMemo(() => {
    const c = { active: 0, future: 0, past: 0 };
    for (const r of rows) c[classify(r)]++;
    return c;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows, today]);

  const filtered = useMemo(() => rows.filter((r) => classify(r) === status), [rows, status, today]);

  const ids = useMemo(() => filtered.map((r) => r.id), [filtered]);

  const onDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const from = filtered.findIndex((r) => r.id === active.id);
    const to = filtered.findIndex((r) => r.id === over.id);
    if (from < 0 || to < 0) return;
    const newFiltered = arrayMove(filtered, from, to);
    // Riapplica l'ordine nel set completo: gli elementi non filtrati restano al loro posto.
    const newOrder: PromoRow[] = [];
    let fi = 0;
    for (const r of rows) {
      if (classify(r) === status) {
        newOrder.push(newFiltered[fi++]);
      } else {
        newOrder.push(r);
      }
    }
    setRows(newOrder);
    setDirty(true);
  };

  const save = async () => {
    setSaving(true);
    // Salva sort_order solo per la lista attualmente filtrata.
    const results = await Promise.all(
      filtered.map((r, idx) =>
        supabase.from("promo_strutturate_testate").update({ b2b_sort_order: idx + 1 }).eq("id", r.id),
      ),
    );
    setSaving(false);
    const err = results.find((r) => r.error);
    if (err?.error) {
      toast({ title: "Errore", description: err.error.message, variant: "destructive" });
      return;
    }
    setDirty(false);
    toast({ title: "Ordine promo salvato" });
  };

  const statusLabel: Record<StatusFilter, string> = {
    active: "in corso",
    future: "future",
    past: "passate",
  };

  return (
    <Card className="overflow-hidden">
      <div className="p-3 border-b flex items-center justify-between gap-3 flex-wrap">
        <Tabs value={status} onValueChange={(v) => setStatus(v as StatusFilter)}>
          <TabsList className="h-8">
            <TabsTrigger value="active" className="text-xs px-3">In corso ({counts.active})</TabsTrigger>
            <TabsTrigger value="future" className="text-xs px-3">Future ({counts.future})</TabsTrigger>
            <TabsTrigger value="past" className="text-xs px-3">Passate ({counts.past})</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="text-sm text-muted-foreground flex-1">
          {loading ? "Caricamento…" : `${filtered.length} promo ${statusLabel[status]}`}
        </div>
        <Button size="sm" onClick={save} disabled={!dirty || saving || loading}>
          {saving ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Save className="h-4 w-4 mr-1" />}
          Salva ordine
        </Button>
      </div>
      <ScrollArea className="h-[calc(100vh-220px)]">
        {loading ? (
          <div className="p-6 flex items-center gap-2 text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Caricamento…
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-6 text-sm text-muted-foreground text-center">Nessuna promo {statusLabel[status]}.</div>
        ) : (
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
            <SortableContext items={ids} strategy={verticalListSortingStrategy}>
              <ul className="divide-y">
                {filtered.map((r, idx) => (
                  <SortablePromoRow key={r.id} row={r} index={idx + 1} onOpen={onOpen} />
                ))}
              </ul>
            </SortableContext>
          </DndContext>
        )}
      </ScrollArea>
    </Card>

  );
}

function SortablePromoRow({ row, index, onOpen }: { row: PromoRow; index: number; onOpen: (p: PromoRow) => void }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: row.id });
  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.6 : 1,
    zIndex: isDragging ? 10 : undefined,
    position: "relative",
  };
  return (
    <li ref={setNodeRef} style={style}>
      <div className="flex items-center gap-3 px-3 py-2 hover:bg-muted/40">
        <button
          type="button"
          className="cursor-grab active:cursor-grabbing touch-none p-1 text-muted-foreground hover:text-foreground"
          title="Trascina per riordinare"
          {...attributes}
          {...listeners}
        >
          <GripVertical className="h-4 w-4" />
        </button>
        <span className="text-xs font-mono text-muted-foreground w-6 text-right">{index}</span>
        <div className="w-14 h-10 rounded border bg-muted/30 overflow-hidden flex items-center justify-center shrink-0">
          {row.cover_image_url ? (
            <img src={row.cover_image_url} alt="" className="w-full h-full object-cover" />
          ) : (
            <ImageIcon className="h-4 w-4 text-muted-foreground/50" />
          )}
        </div>
        <button onClick={() => onOpen(row)} className="flex-1 text-left min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs text-muted-foreground">#{row.wpprgf ?? "—"}</span>
            {row.wpstato && (
              <Badge variant={row.wpstato === "V" ? "default" : "secondary"} className="text-[10px] h-4">{row.wpstato}</Badge>
            )}
            <span className="text-sm font-medium truncate">{row.wptpbd?.trim() || "(senza descrizione)"}</span>
          </div>
          <div className="text-[11px] text-muted-foreground flex items-center gap-2">
            {row.wpcca && <span className="font-mono">{row.wpcca.trim()}</span>}
            <span>{formatYyyymmddDisplay(row.wpdvali)} → {formatYyyymmddDisplay(row.wpdvalf)}</span>
          </div>
        </button>
        <Button size="sm" variant="ghost" onClick={() => onOpen(row)}>Offerte →</Button>
      </div>
    </li>
  );
}

// ─────────── TEMI (offerte) ───────────

function TemiOrderPanel({ promo }: { promo: PromoRow }) {
  const [items, setItems] = useState<TemaRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [status, setStatus] = useState<StatusFilter>("active");

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 4 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  useEffect(() => {
    let alive = true;
    if (promo.wpprgf == null) return;
    setLoading(true);
    supabase
      .from("promo_strutturate_temi")
      .select("id,nome,image_url,tipo,sort_order,dal,al")
      .eq("wpprgf", promo.wpprgf)
      .order("sort_order", { ascending: true })
      .then(({ data, error }) => {
        if (!alive) return;
        if (error) toast({ title: "Errore", description: error.message, variant: "destructive" });
        setItems((data ?? []) as TemaRow[]);
        setDirty(false);
        setLoading(false);
      });
    return () => { alive = false; };
  }, [promo.wpprgf]);

  const todayIso = useMemo(() => new Date().toISOString().slice(0, 10), []);

  const classify = (t: TemaRow): StatusFilter => {
    if (t.dal && t.dal > todayIso) return "future";
    if (t.al && t.al < todayIso) return "past";
    return "active";
  };

  const counts = useMemo(() => {
    const c = { active: 0, future: 0, past: 0 };
    for (const t of items) c[classify(t)]++;
    return c;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items, todayIso]);

  const filtered = useMemo(
    () => items.filter((t) => classify(t) === status),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [items, status, todayIso],
  );

  const ids = useMemo(() => filtered.map((t) => t.id), [filtered]);

  const onDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const from = filtered.findIndex((t) => t.id === active.id);
    const to = filtered.findIndex((t) => t.id === over.id);
    if (from < 0 || to < 0) return;
    const newFiltered = arrayMove(filtered, from, to);
    const newAll: TemaRow[] = [];
    let fi = 0;
    for (const t of items) {
      if (classify(t) === status) newAll.push(newFiltered[fi++]);
      else newAll.push(t);
    }
    setItems(newAll);
    setDirty(true);
  };

  const save = async () => {
    setSaving(true);
    // Salva sort_order solo per il sottoinsieme filtrato.
    const results = await Promise.all(
      filtered.map((t, idx) =>
        supabase.from("promo_strutturate_temi").update({ sort_order: idx }).eq("id", t.id),
      ),
    );
    setSaving(false);
    const err = results.find((r) => r.error);
    if (err?.error) {
      toast({ title: "Errore", description: err.error.message, variant: "destructive" });
      return;
    }
    setDirty(false);
    toast({ title: "Ordine offerte salvato" });
  };

  const statusLabel: Record<StatusFilter, string> = {
    active: "in corso",
    future: "future",
    past: "passate",
  };

  return (
    <Card className="overflow-hidden">
      <div className="p-3 border-b flex items-center justify-between gap-3 flex-wrap">
        <Tabs value={status} onValueChange={(v) => setStatus(v as StatusFilter)}>
          <TabsList className="h-8">
            <TabsTrigger value="active" className="text-xs px-3">In corso ({counts.active})</TabsTrigger>
            <TabsTrigger value="future" className="text-xs px-3">Future ({counts.future})</TabsTrigger>
            <TabsTrigger value="past" className="text-xs px-3">Passate ({counts.past})</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="text-sm text-muted-foreground flex-1">
          {loading ? "Caricamento…" : `${filtered.length} offerte ${statusLabel[status]}`}
        </div>
        <Button size="sm" onClick={save} disabled={!dirty || saving || loading}>
          {saving ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Save className="h-4 w-4 mr-1" />}
          Salva ordine
        </Button>
      </div>
      <ScrollArea className="h-[calc(100vh-220px)]">
        {loading ? (
          <div className="p-6 flex items-center gap-2 text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Caricamento…
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-6 text-sm text-muted-foreground text-center">Nessuna offerta {statusLabel[status]}.</div>
        ) : (
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
            <SortableContext items={ids} strategy={verticalListSortingStrategy}>
              <ul className="divide-y">
                {filtered.map((t, idx) => (
                  <SortableTemaRow key={t.id} tema={t} index={idx + 1} />
                ))}
              </ul>
            </SortableContext>
          </DndContext>
        )}
      </ScrollArea>
    </Card>
  );
}



function SortableTemaRow({ tema, index }: { tema: TemaRow; index: number }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: tema.id });
  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.6 : 1,
    zIndex: isDragging ? 10 : undefined,
    position: "relative",
  };
  return (
    <li ref={setNodeRef} style={style}>
      <div className={cn("flex items-center gap-3 px-3 py-2 hover:bg-muted/40")}>
        <button
          type="button"
          className="cursor-grab active:cursor-grabbing touch-none p-1 text-muted-foreground hover:text-foreground"
          title="Trascina per riordinare"
          {...attributes}
          {...listeners}
        >
          <GripVertical className="h-4 w-4" />
        </button>
        <span className="text-xs font-mono text-muted-foreground w-6 text-right">{index}</span>
        <div className="w-10 h-10 rounded bg-muted overflow-hidden shrink-0 flex items-center justify-center">
          {tema.image_url ? (
            <img src={tema.image_url} alt="" className="w-full h-full object-cover" />
          ) : tema.tipo === "omaggio" ? (
            <Gift className="h-4 w-4 text-muted-foreground/50" />
          ) : (
            <Layers className="h-4 w-4 text-muted-foreground/50" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-sm font-medium truncate">{tema.nome}</div>
          {tema.tipo && <div className="text-[10px] uppercase text-muted-foreground">{tema.tipo}</div>}
        </div>
      </div>
    </li>
  );
}

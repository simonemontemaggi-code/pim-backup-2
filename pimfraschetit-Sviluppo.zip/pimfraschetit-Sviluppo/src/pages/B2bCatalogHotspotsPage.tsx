import { useEffect, useMemo, useRef, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Loader2, ArrowLeft, Save, Trash2, Copy, ChevronLeft, ChevronRight, Search, Wand2, ChevronDown, Layers, ZoomIn, ZoomOut, Maximize2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { usePdfDocument, renderPageToDataUrl } from "@/components/b2b/flipbook/usePdfDocument";
import type { Hotspot } from "@/components/b2b/flipbook/types";
import { extractCodeCandidatesFromPage, buildHotspotFromCode, padCdpar, groupCandidatesByParent, type CodeCandidate } from "@/components/b2b/flipbook/autoDetectHotspots";
import { AutoDetectDialog, type AutoDetectResult, type MergeStrategy, type HotspotShape } from "@/components/b2b/flipbook/AutoDetectDialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { resolveOverlaps } from "@/components/b2b/flipbook/resolveOverlaps";
import { ResolveOverlapsDialog } from "@/components/b2b/flipbook/ResolveOverlapsDialog";

type ResizeMode = "move" | "n" | "s" | "e" | "w" | "ne" | "nw" | "se" | "sw";
interface DragState {
  id: string;
  mode: ResizeMode;
  startX: number;
  startY: number;
  startHotspot: Hotspot;
}

type Catalog = {
  id: string;
  name: string;
  pdf_url: string | null;
  hotspots: Hotspot[] | null;
  total_pages: number | null;
};

function uid() {
  return crypto.randomUUID?.() ?? `h_${Math.random().toString(36).slice(2)}_${Date.now()}`;
}

export default function B2bCatalogHotspotsPage() {
  const { id } = useParams<{ id: string }>();
  const nav = useNavigate();
  const pageWrapRef = useRef<HTMLDivElement>(null);
  const [pageImg, setPageImg] = useState<string | null>(null);
  const [pageAspect, setPageAspect] = useState<number>(1 / 1.41); // w/h
  const [renderingPage, setRenderingPage] = useState(false);
  const [thumbs, setThumbs] = useState<Record<number, string>>({});
  const [currentPage, setCurrentPage] = useState(1);
  const [hotspots, setHotspots] = useState<Hotspot[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [drawing, setDrawing] = useState<{ x: number; y: number } | null>(null);
  const [draftRect, setDraftRect] = useState<{ x: number; y: number; w: number; h: number } | null>(null);

  const { data: catalog, isLoading } = useQuery({
    queryKey: ["b2b_catalog", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("b2b_catalogs").select("id, name, pdf_url, hotspots, total_pages").eq("id", id!).single();
      if (error) throw error;
      return data as unknown as Catalog;
    },
    enabled: !!id,
  });

  useEffect(() => {
    if (catalog?.hotspots) setHotspots(catalog.hotspots as Hotspot[]);
  }, [catalog?.id]);

  const { doc, numPages, loading: pdfLoading, error: pdfError } = usePdfDocument(catalog?.pdf_url ?? null);

  // Render pagina corrente
  useEffect(() => {
    if (!doc) return;
    let cancelled = false;
    setRenderingPage(true);
    renderPageToDataUrl(doc, currentPage, 1.8).then((d) => {
      if (!cancelled) {
        setPageImg(d.dataUrl);
        if (d.width > 0 && d.height > 0) setPageAspect(d.width / d.height);
        setRenderingPage(false);
      }
    }).catch((e) => {
      if (!cancelled) {
        toast({ title: "Errore render pagina", description: e.message, variant: "destructive" });
        setRenderingPage(false);
      }
    });
    return () => { cancelled = true; };
  }, [doc, currentPage]);

  // Render miniature
  useEffect(() => {
    if (!doc) return;
    let cancelled = false;
    (async () => {
      for (let p = 1; p <= numPages; p++) {
        if (cancelled || thumbs[p]) continue;
        try {
          const data = await renderPageToDataUrl(doc, p, 0.25);
          if (!cancelled) setThumbs((s) => ({ ...s, [p]: data.dataUrl }));
        } catch {/* ignore */}
      }
    })();
    return () => { cancelled = true; };
  }, [doc, numPages]);

  const qc = useQueryClient();
  const save = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("b2b_catalogs")
        .update({ hotspots: hotspots as any, total_pages: numPages || null })
        .eq("id", id!);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Hotspot salvati" });
      qc.invalidateQueries({ queryKey: ["b2b_catalog", id] });
      qc.invalidateQueries({ queryKey: ["b2b_catalogs"] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const pageHotspots = useMemo(() => hotspots.filter((h) => h.page === currentPage), [hotspots, currentPage]);
  const selected = hotspots.find((h) => h.id === selectedId) ?? null;
  const updateSelected = (patch: Partial<Hotspot>) => {
    if (!selected) return;
    setHotspots((arr) => arr.map((h) => (h.id === selected.id ? { ...h, ...patch } : h)));
  };
  const removeSelected = () => {
    if (!selected) return;
    setHotspots((arr) => arr.filter((h) => h.id !== selected.id));
    setSelectedId(null);
  };

  const [dragState, setDragState] = useState<DragState | null>(null);

  const startResize = (e: React.MouseEvent, h: Hotspot, mode: ResizeMode) => {
    if (!pageWrapRef.current) return;
    e.stopPropagation();
    e.preventDefault();
    const rect = pageWrapRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    setSelectedId(h.id);
    setDragState({ id: h.id, mode, startX: x, startY: y, startHotspot: { ...h } });
  };

  const onMouseDown = (e: React.MouseEvent) => {
    if (dragState) return;
    if (!pageWrapRef.current) return;
    const rect = pageWrapRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    if (x < 0 || x > 1 || y < 0 || y > 1) return;
    setSelectedId(null);
    setDrawing({ x, y });
    setDraftRect({ x, y, w: 0, h: 0 });
  };
  const onMouseMove = (e: React.MouseEvent) => {
    if (!pageWrapRef.current) return;
    const rect = pageWrapRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const y = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));

    // Resize/move drag
    if (dragState) {
      const dx = x - dragState.startX;
      const dy = y - dragState.startY;
      const s = dragState.startHotspot;
      let nx = s.x, ny = s.y, nw = s.w, nh = s.h;
      const m = dragState.mode;
      const MIN = 0.01;
      if (m === "move") { nx = s.x + dx; ny = s.y + dy; }
      if (m === "n" || m === "ne" || m === "nw") { ny = s.y + dy; nh = s.h - dy; }
      if (m === "s" || m === "se" || m === "sw") { nh = s.h + dy; }
      if (m === "w" || m === "nw" || m === "sw") { nx = s.x + dx; nw = s.w - dx; }
      if (m === "e" || m === "ne" || m === "se") { nw = s.w + dx; }
      // min size
      if (nw < MIN) { if (m === "w" || m === "nw" || m === "sw") nx = s.x + s.w - MIN; nw = MIN; }
      if (nh < MIN) { if (m === "n" || m === "ne" || m === "nw") ny = s.y + s.h - MIN; nh = MIN; }
      // clamp
      if (nx < 0) { if (m !== "move") nw += nx; nx = 0; }
      if (ny < 0) { if (m !== "move") nh += ny; ny = 0; }
      if (nx + nw > 1) { if (m === "move") nx = 1 - nw; else nw = 1 - nx; }
      if (ny + nh > 1) { if (m === "move") ny = 1 - nh; else nh = 1 - ny; }
      setHotspots((arr) => arr.map((h) => h.id === dragState.id ? { ...h, x: nx, y: ny, w: nw, h: nh } : h));
      return;
    }

    // Drawing new hotspot
    if (!drawing) return;
    const nx = Math.min(drawing.x, x);
    const ny = Math.min(drawing.y, y);
    const w = Math.abs(x - drawing.x);
    const h = Math.abs(y - drawing.y);
    setDraftRect({ x: nx, y: ny, w, h });
  };
  const onMouseUp = () => {
    if (dragState) {
      setDragState(null);
      return;
    }
    if (drawing && draftRect && draftRect.w > 0.01 && draftRect.h > 0.01) {
      const newH: Hotspot = {
        id: uid(),
        page: currentPage,
        x: draftRect.x, y: draftRect.y, w: draftRect.w, h: draftRect.h,
        type: "article",
      };
      setHotspots((arr) => [...arr, newH]);
      setSelectedId(newH.id);
    }
    setDrawing(null);
    setDraftRect(null);
  };

  const copyFromPrevPage = () => {
    if (currentPage <= 1) return;
    const prev = hotspots.filter((h) => h.page === currentPage - 1);
    if (prev.length === 0) {
      toast({ title: "Nessun hotspot nella pagina precedente" });
      return;
    }
    const copies = prev.map((h) => ({ ...h, id: uid(), page: currentPage }));
    setHotspots((arr) => [...arr, ...copies]);
    toast({ title: `${copies.length} hotspot copiati` });
  };

  // ===== Auto-detect hotspot =====
  const [autoOpen, setAutoOpen] = useState(false);
  const [autoScanning, setAutoScanning] = useState(false);
  const [autoProgress, setAutoProgress] = useState(0);
  const [autoResult, setAutoResult] = useState<AutoDetectResult | null>(null);
  const [autoCandidates, setAutoCandidates] = useState<CodeCandidate[]>([]);

  // ===== Resolve overlaps =====
  const [resolveOpen, setResolveOpen] = useState(false);
  const [zoom, setZoom] = useState(1);
  const ZOOM_MIN = 0.5;
  const ZOOM_MAX = 3;
  const ZOOM_STEP = 0.25;
  const applyResolveOverlaps = (opts: { padding: number; strategy: "both" | "larger"; pages: number[] }) => {
    const result = resolveOverlaps(hotspots, opts);
    setHotspots(result.resolved);
    setResolveOpen(false);
    const parts = [`${result.resolvedPairs} coppie risolte`];
    if (result.unresolvedPairs > 0) parts.push(`${result.unresolvedPairs} non risolvibili (dim. minima)`);
    if (result.duplicates > 0) parts.push(`${result.duplicates} duplicati esatti da cancellare a mano`);
    toast({ title: "Sovrapposizioni gestite", description: parts.join(" · ") });
  };

  const runAutoDetect = async (mode: "page" | "all") => {
    if (!doc) return;
    const pages = mode === "page" ? [currentPage] : Array.from({ length: numPages }, (_, i) => i + 1);
    setAutoOpen(true);
    setAutoScanning(true);
    setAutoProgress(0);
    setAutoResult(null);

    try {
      const allCandidates: CodeCandidate[] = [];
      for (let i = 0; i < pages.length; i++) {
        const p = pages[i];
        try {
          const cands = await extractCodeCandidatesFromPage(doc, p);
          allCandidates.push(...cands);
        } catch (e) {
          console.warn(`Errore scansione pagina ${p}`, e);
        }
        setAutoProgress(Math.round(((i + 1) / pages.length) * 80));
      }

      const uniqueCodes = Array.from(new Set(allCandidates.map((c) => c.code)));
      setAutoProgress(85);

      const matched = new Set<string>();
      const parentMap = new Map<string, string>(); // code6 -> parent6
      const BATCH = 1000;
      for (let i = 0; i < uniqueCodes.length; i += BATCH) {
        const batch = uniqueCodes.slice(i, i + BATCH).map(padCdpar);
        const { data, error } = await supabase
          .from("archivio_articoli_fraschetti")
          .select("cdpar, cod_padre")
          .in("cdpar", batch);
        if (error) throw error;
        for (const row of data ?? []) {
          const code = (row.cdpar as string).trim();
          matched.add(code);
          const parentRaw = (row as { cod_padre?: string | null }).cod_padre;
          const parent = parentRaw ? String(parentRaw).trim() : "";
          if (parent && parent !== code) {
            parentMap.set(code, parent);
          }
        }
      }
      setAutoProgress(100);

      const matchedCandidates = allCandidates.filter((c) => matched.has(c.code));
      // Raggruppa varianti dello stesso padre presenti sulla stessa pagina
      const groupedCandidates = groupCandidatesByParent(matchedCandidates, parentMap);
      const existingOnPages = hotspots.filter((h) => pages.includes(h.page)).length;

      setAutoCandidates(groupedCandidates);
      setAutoResult({
        candidatesCount: uniqueCodes.length,
        matchedCodes: Array.from(matched),
        hotspotsToCreate: groupedCandidates.length,
        pagesScanned: pages,
        existingOnPages,
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      toast({ title: "Errore auto-rilevamento", description: msg, variant: "destructive" });
      setAutoOpen(false);
    } finally {
      setAutoScanning(false);
    }
  };

  const applyAutoDetect = (strategy: MergeStrategy, shape: HotspotShape) => {
    if (!autoResult) return;
    const pagesScanned = new Set(autoResult.pagesScanned);

    setHotspots((prev) => {
      let base = prev;
      let candidates = autoCandidates;

      if (strategy === "replace") {
        base = prev.filter((h) => !pagesScanned.has(h.page));
      } else if (strategy === "skip") {
        const pagesWithExisting = new Set(prev.filter((h) => pagesScanned.has(h.page)).map((h) => h.page));
        candidates = autoCandidates.filter((c) => !pagesWithExisting.has(c.page));
      }

      const newHotspots = candidates.map((c) => buildHotspotFromCode(c, uid(), shape));
      return [...base, ...newHotspots];
    });

    toast({
      title: "Hotspot creati",
      description: `${autoCandidates.length} hotspot generati. Ricordati di salvare.`,
    });
    setAutoOpen(false);
    setAutoResult(null);
    setAutoCandidates([]);
  };

  if (isLoading || !catalog) {
    return <div className="p-6"><Loader2 className="h-5 w-5 animate-spin" /></div>;
  }

  if (!catalog.pdf_url) {
    return (
      <div className="p-6 space-y-3 max-w-2xl">
        <Button variant="ghost" size="sm" onClick={() => nav("/pim/b2b/catalogs")}>
          <ArrowLeft className="h-4 w-4 mr-1" /> Torna ai cataloghi
        </Button>
        <div className="rounded-lg border p-6 text-center text-muted-foreground">
          Questo catalogo non ha un PDF caricato. Caricane uno dall'editor per gestire gli hotspot.
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-3.5rem)]">
      <div className="flex items-center justify-between gap-2 px-4 py-2 border-b bg-card">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => nav("/pim/b2b/catalogs")}>
            <ArrowLeft className="h-4 w-4 mr-1" /> Torna
          </Button>
          <h1 className="text-sm font-semibold">Hotspot · {catalog.name}</h1>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          {pdfError && <span className="text-destructive">{pdfError}</span>}
          {!pdfError && numPages > 0 && <span>{hotspots.length} hotspot totali · {numPages} pagine</span>}
          <Button size="sm" onClick={() => save.mutate()} disabled={save.isPending}>
            <Save className="h-4 w-4 mr-1" /> Salva
          </Button>
        </div>
      </div>

      <div className="flex flex-1 min-h-0">
        {/* Miniature */}
        <div className="w-32 border-r bg-muted/30 shrink-0">
          <ScrollArea className="h-full">
            <div className="p-2 space-y-2">
              {Array.from({ length: numPages }).map((_, i) => {
                const p = i + 1;
                const count = hotspots.filter((h) => h.page === p).length;
                return (
                  <button
                    key={p}
                    onClick={() => { setCurrentPage(p); setSelectedId(null); }}
                    className={cn(
                      "w-full border rounded overflow-hidden text-xs relative hover:border-primary transition",
                      currentPage === p ? "border-primary ring-2 ring-primary/40" : "border-border"
                    )}
                  >
                    {thumbs[p] ? (
                      <img src={thumbs[p]} alt={`p ${p}`} className="w-full block" />
                    ) : (
                      <div className="aspect-[1/1.41] bg-muted flex items-center justify-center">
                        <Loader2 className="h-3 w-3 animate-spin" />
                      </div>
                    )}
                    <div className="flex items-center justify-between text-center py-0.5 bg-muted px-1">
                      <span>{p}</span>
                      {count > 0 && <span className="bg-primary text-primary-foreground rounded-full px-1.5 text-[10px]">{count}</span>}
                    </div>
                  </button>
                );
              })}
            </div>
          </ScrollArea>
        </div>

        {/* Area pagina */}
        <div className="flex-1 flex flex-col bg-slate-100 min-w-0">
          <div className="flex items-center justify-center gap-2 p-2 border-b bg-card">
            <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} disabled={currentPage <= 1}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm">Pagina {currentPage} / {numPages}</span>
            <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => setCurrentPage((p) => Math.min(numPages, p + 1))} disabled={currentPage >= numPages}>
              <ChevronRight className="h-4 w-4" />
            </Button>
            <div className="ml-4 text-xs text-muted-foreground">Trascina sulla pagina per creare un hotspot</div>
            <div className="ml-4 flex items-center gap-1 border rounded-md px-1 py-0.5">
              <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => setZoom((z) => Math.max(ZOOM_MIN, +(z - ZOOM_STEP).toFixed(2)))} disabled={zoom <= ZOOM_MIN} title="Riduci zoom">
                <ZoomOut className="h-3.5 w-3.5" />
              </Button>
              <span className="text-xs tabular-nums w-10 text-center">{Math.round(zoom * 100)}%</span>
              <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => setZoom((z) => Math.min(ZOOM_MAX, +(z + ZOOM_STEP).toFixed(2)))} disabled={zoom >= ZOOM_MAX} title="Aumenta zoom">
                <ZoomIn className="h-3.5 w-3.5" />
              </Button>
              <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => setZoom(1)} disabled={zoom === 1} title="Adatta">
                <Maximize2 className="h-3.5 w-3.5" />
              </Button>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="sm" variant="default" disabled={!doc}>
                    <Wand2 className="h-3.5 w-3.5 mr-1" /> Auto-rileva
                    <ChevronDown className="h-3 w-3 ml-1" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => runAutoDetect("page")}>
                    Solo questa pagina
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => runAutoDetect("all")}>
                    Tutto il catalogo ({numPages} pagine)
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <Button size="sm" variant="outline" onClick={() => setResolveOpen(true)}>
                <Layers className="h-3.5 w-3.5 mr-1" /> Riduci sovrapposizioni
              </Button>
              <Button size="sm" variant="outline" onClick={copyFromPrevPage}>
                <Copy className="h-3.5 w-3.5 mr-1" /> Copia da pag {currentPage - 1}
              </Button>
            </div>
          </div>

          <div className={cn("flex-1 min-h-0 overflow-auto p-2 flex", zoom > 1 ? "items-start justify-start" : "items-center justify-center")}>
            <div
              ref={pageWrapRef}
              className="relative shadow-lg bg-white select-none flex-shrink-0"
              style={{
                aspectRatio: String(pageAspect),
                maxWidth: zoom <= 1 ? "100%" : undefined,
                maxHeight: zoom <= 1 ? "100%" : undefined,
                width: `calc(100vh * ${pageAspect} * ${zoom})`,
                height: "auto",
              }}
              onMouseDown={onMouseDown}
              onMouseMove={onMouseMove}
              onMouseUp={onMouseUp}
              onMouseLeave={onMouseUp}
            >
              {pdfLoading || renderingPage || !pageImg ? (
                <div className="absolute inset-0 flex items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
              ) : (
                <img src={pageImg} alt={`Pagina ${currentPage}`} className="block w-full h-full pointer-events-none" draggable={false} />
              )}
              {/* Hotspot esistenti */}
              {pageHotspots.map((h) => {
                const isSelected = selectedId === h.id;
                return (
                  <div
                    key={h.id}
                    onMouseDown={(e) => startResize(e, h, "move")}
                    className={cn(
                      "absolute border-2 transition",
                      isSelected
                        ? "border-primary bg-primary/30 cursor-move"
                        : "border-primary/60 bg-primary/15 hover:bg-primary/25 cursor-pointer"
                    )}
                    style={{ left: `${h.x*100}%`, top: `${h.y*100}%`, width: `${h.w*100}%`, height: `${h.h*100}%` }}
                    title={h.label || h.cdpar || h.url || ""}
                  >
                    <div className="absolute -top-5 left-0 text-[10px] bg-primary text-primary-foreground px-1 rounded whitespace-nowrap pointer-events-none">
                      {h.cdpar?.trim() || "(seleziona articolo)"}
                    </div>
                    {isSelected && (
                      <>
                        {/* Maniglie angolari */}
                        <div onMouseDown={(e) => startResize(e, h, "nw")} className="absolute -top-1.5 -left-1.5 w-3 h-3 bg-background border-2 border-primary cursor-nwse-resize" />
                        <div onMouseDown={(e) => startResize(e, h, "ne")} className="absolute -top-1.5 -right-1.5 w-3 h-3 bg-background border-2 border-primary cursor-nesw-resize" />
                        <div onMouseDown={(e) => startResize(e, h, "sw")} className="absolute -bottom-1.5 -left-1.5 w-3 h-3 bg-background border-2 border-primary cursor-nesw-resize" />
                        <div onMouseDown={(e) => startResize(e, h, "se")} className="absolute -bottom-1.5 -right-1.5 w-3 h-3 bg-background border-2 border-primary cursor-nwse-resize" />
                        {/* Maniglie laterali */}
                        <div onMouseDown={(e) => startResize(e, h, "n")} className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-background border-2 border-primary cursor-ns-resize" />
                        <div onMouseDown={(e) => startResize(e, h, "s")} className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-background border-2 border-primary cursor-ns-resize" />
                        <div onMouseDown={(e) => startResize(e, h, "w")} className="absolute top-1/2 -left-1.5 -translate-y-1/2 w-3 h-3 bg-background border-2 border-primary cursor-ew-resize" />
                        <div onMouseDown={(e) => startResize(e, h, "e")} className="absolute top-1/2 -right-1.5 -translate-y-1/2 w-3 h-3 bg-background border-2 border-primary cursor-ew-resize" />
                      </>
                    )}
                  </div>
                );
              })}
              {/* Draft mentre si disegna */}
              {draftRect && (
                <div
                  className="absolute border-2 border-dashed border-primary bg-primary/10 pointer-events-none"
                  style={{ left: `${draftRect.x*100}%`, top: `${draftRect.y*100}%`, width: `${draftRect.w*100}%`, height: `${draftRect.h*100}%` }}
                />
              )}
            </div>
          </div>
        </div>

        {/* Pannello laterale */}
        <div className="w-80 border-l bg-card shrink-0">
          <ScrollArea className="h-full">
            <div className="p-3 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Hotspot pagina {currentPage}</h3>
                <span className="text-xs text-muted-foreground">{pageHotspots.length}</span>
              </div>

              {pageHotspots.length === 0 && (
                <div className="text-xs text-muted-foreground border rounded p-3 text-center">
                  Nessun hotspot. Trascina sulla pagina per crearne uno.
                </div>
              )}

              {pageHotspots.map((h) => (
                <button
                  key={h.id}
                  onClick={() => setSelectedId(h.id)}
                  className={cn(
                    "w-full text-left text-xs px-2 py-1.5 rounded border transition",
                    selectedId === h.id ? "border-primary bg-primary/10" : "border-border hover:bg-muted"
                  )}
                >
                  <div className="font-medium">{h.label || h.cdpar || "(seleziona articolo)"}</div>
                  <div className="text-muted-foreground font-mono text-[10px]">{h.cdpar || "—"}</div>
                </button>
              ))}

              {selected && (
                <div className="border-t pt-3 space-y-3">
                  <h4 className="text-sm font-semibold">Modifica hotspot</h4>

                  <ArticlePicker
                    value={selected.cdpar ?? null}
                    onChange={(cdpar) => updateSelected({ cdpar: cdpar ?? undefined, type: "article" })}
                  />

                  <div className="space-y-1">
                    <Label className="text-xs">Etichetta (opzionale)</Label>
                    <Input
                      className="h-8 text-xs"
                      value={selected.label ?? ""}
                      onChange={(e) => updateSelected({ label: e.target.value })}
                      placeholder="Tooltip mostrato sull'hotspot"
                    />
                  </div>

                  <Button variant="destructive" size="sm" className="w-full" onClick={removeSelected}>
                    <Trash2 className="h-3.5 w-3.5 mr-1" /> Elimina hotspot
                  </Button>
                </div>
              )}
            </div>
          </ScrollArea>
        </div>
      </div>

      <AutoDetectDialog
        open={autoOpen}
        onOpenChange={setAutoOpen}
        scanning={autoScanning}
        progress={autoProgress}
        result={autoResult}
        onConfirm={applyAutoDetect}
      />
      <ResolveOverlapsDialog
        open={resolveOpen}
        onOpenChange={setResolveOpen}
        hotspots={hotspots}
        currentPage={currentPage}
        numPages={numPages}
        onApply={applyResolveOverlaps}
      />
    </div>
  );
}

function ArticlePicker({ value, onChange }: { value: string | null; onChange: (v: string | null) => void }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const { data: results = [], isFetching } = useQuery({
    queryKey: ["hotspot-article-search", q],
    enabled: open && q.trim().length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("archivio_articoli_fraschetti")
        .select("cdpar, depar")
        .or(`cdpar.ilike.%${q.trim()}%,depar.ilike.%${q.trim()}%`)
        .limit(20);
      if (error) throw error;
      return data as { cdpar: string; depar: string | null }[];
    },
  });

  return (
    <div className="space-y-1">
      <Label className="text-xs">Articolo (cdpar)</Label>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button type="button" variant="outline" className="w-full justify-between h-8 text-xs font-normal">
            <span className={cn("truncate", !value && "text-muted-foreground")}>{value || "Cerca articolo..."}</span>
            <Search className="h-3.5 w-3.5 ml-2 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
          <Command shouldFilter={false}>
            <CommandInput placeholder="cdpar o descrizione..." value={q} onValueChange={setQ} />
            <CommandList className="max-h-72">
              {isFetching && <div className="p-3 text-xs text-muted-foreground"><Loader2 className="h-3 w-3 animate-spin inline mr-1" /> ricerca...</div>}
              {!isFetching && q.length < 2 && <div className="p-3 text-xs text-muted-foreground">Digita almeno 2 caratteri</div>}
              {!isFetching && q.length >= 2 && results.length === 0 && <CommandEmpty>Nessun risultato</CommandEmpty>}
              <CommandGroup>
                {results.map((a) => (
                  <CommandItem key={a.cdpar} value={a.cdpar} onSelect={() => { onChange(a.cdpar.trim()); setOpen(false); }}>
                    <div className="text-xs">
                      <div className="font-mono">{a.cdpar.trim()}</div>
                      {a.depar && <div className="text-muted-foreground truncate">{a.depar}</div>}
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  );
}

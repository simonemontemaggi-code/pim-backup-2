import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { usePermissions } from "@/lib/permissions";
import { useVisibleAssortments } from "@/hooks/useVisibleAssortments";
import { useLookupValues } from "@/hooks/useLookupValues";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose,
} from "@/components/ui/dialog";
import { Plus, Search, Save, X, AlertCircle, Settings2, AlertTriangle } from "lucide-react";
import SupplierDifferentialDialog from "@/components/suppliers/SupplierDifferentialDialog";

const PAGE_SIZE = 50;

interface SupplierRow {
  id: string;
  cdfor: string;
  rasfo: string | null;
  buyer: string | null;
  demand_planner: string | null;
}

export default function SuppliersPage() {
  const queryClient = useQueryClient();
  const { user, profile } = useAuth();
  const { data: visibleAssortments = [] } = useVisibleAssortments();
  const { data: buyerOptions = [] } = useLookupValues("buyer");
  const { data: dpOptions = [] } = useLookupValues("demand_planner");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");
  const [newCdfor, setNewCdfor] = useState("");
  const [newRasfo, setNewRasfo] = useState("");
  const [debouncedCdfor, setDebouncedCdfor] = useState("");

  useEffect(() => {
    const t = setTimeout(() => setDebouncedCdfor(newCdfor.trim().toUpperCase()), 300);
    return () => clearTimeout(t);
  }, [newCdfor]);

  const { data: existingSupplier } = useQuery({
    queryKey: ["supplier-exists", debouncedCdfor],
    queryFn: async () => {
      const { data } = await supabase
        .from("archivio_fornitori_fraschetti")
        .select("id")
        .eq("cdfor", debouncedCdfor)
        .maybeSingle();
      return data;
    },
    enabled: debouncedCdfor.length >= 1,
  });

  const isDuplicate = !!existingSupplier && debouncedCdfor === newCdfor.trim().toUpperCase();
  const canCreate = newCdfor.trim().length > 0 && newCdfor.trim().length <= 10 && newRasfo.trim().length > 0 && newRasfo.trim().length <= 60 && !isDuplicate;

  const { data, isLoading } = useQuery({
    queryKey: ["suppliers", search, page],
    queryFn: async () => {
      let q = supabase
        .from("archivio_fornitori_fraschetti")
        .select("id,cdfor,rasfo,buyer,demand_planner", { count: "exact" })
        .order("cdfor")
        .range(page * PAGE_SIZE, (page + 1) * PAGE_SIZE - 1);
      if (search.length >= 2) {
        q = q.or(`cdfor.ilike.%${search}%,rasfo.ilike.%${search}%`);
      }
      const { data, error, count } = await q;
      if (error) throw error;
      return { rows: (data ?? []) as SupplierRow[], count: count ?? 0 };
    },
    staleTime: 30_000,
    placeholderData: (prev) => prev,
  });

  const supplierCodes = data?.rows.map((r) => r.cdfor) ?? [];
  const { data: articleCounts } = useQuery({
    queryKey: ["supplier_article_counts", supplierCodes, visibleAssortments],
    queryFn: async () => {
      if (supplierCodes.length === 0) return {};
      let q = supabase
        .from("archivio_articoli_fraschetti")
        .select("pcfor")
        .in("pcfor", supplierCodes);
      if (visibleAssortments.length > 0) q = q.in("wfuas", visibleAssortments);
      const { data, error } = await q;
      if (error) throw error;
      const counts: Record<string, number> = {};
      (data ?? []).forEach((r: any) => { counts[r.pcfor] = (counts[r.pcfor] || 0) + 1; });
      return counts;
    },
    enabled: supplierCodes.length > 0,
  });

  // Recupera fornitori con differenziale attivo (record §DC e wan02 != 'A')
  const { data: activeDiffs } = useQuery({
    queryKey: ["suppliers_active_diffs", supplierCodes],
    queryFn: async () => {
      if (supplierCodes.length === 0) return new Set<string>();
      const { data, error } = await supabase
        .from("differenziale_cambio")
        .select("wcdfo,wcacq,wan02")
        .in("wcdfo", supplierCodes);
      if (error) throw error;
      const set = new Set<string>();
      (data ?? []).forEach((r: any) => {
        const wcacq = String(r.wcacq ?? "").trim();
        const wan02 = String(r.wan02 ?? "").trim().toUpperCase();
        const hasDC = wcacq.includes("§DC") || wcacq.includes("Â§DC");
        if (hasDC && wan02 !== "A") set.add(String(r.wcdfo ?? "").trim());
      });
      return set;
    },
    enabled: supplierCodes.length > 0,
  });

  const [newDialogOpen, setNewDialogOpen] = useState(false);
  const [diffSupplier, setDiffSupplier] = useState<SupplierRow | null>(null);
  const { canAction } = usePermissions();
  const canCreateSupplier = canAction("suppliers", "create");

  const addMutation = useMutation({
    mutationFn: async () => {
      const code = newCdfor.trim().toUpperCase();
      if (!code || code.length > 10) throw new Error("Codice fornitore: max 10 caratteri, richiesto.");
      if (!newRasfo.trim() || newRasfo.trim().length > 60) throw new Error("Ragione sociale: max 60 caratteri, richiesta.");
      const { data: existing } = await supabase.from("archivio_fornitori_fraschetti").select("id").eq("cdfor", code).maybeSingle();
      if (existing) throw new Error(`Fornitore ${code} già esistente.`);
      const payload = { cdfor: code, rasfo: newRasfo.trim() };
      const { error } = await supabase.from("archivio_fornitori_fraschetti").insert(payload);
      if (error) throw error;
      return payload;
    },
    onSuccess: (payload) => {
      toast({ title: "Fornitore creato" });
      const json = JSON.stringify(payload, null, 2);
      const blob = new Blob([json], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `fornitore_${payload.cdfor}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setNewCdfor("");
      setNewRasfo("");
      setNewDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["suppliers"] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const updateField = useMutation({
    mutationFn: async ({ id, cdfor, field, value }: { id: string; cdfor: string; field: "rasfo" | "buyer" | "demand_planner"; value: string }) => {
      const trimmed = value.trim();
      const updatePayload: Record<string, string | null> = {};
      updatePayload[field] = trimmed || null;
      const { error } = await supabase.from("archivio_fornitori_fraschetti").update(updatePayload as any).eq("id", id);
      if (error) throw error;
      await supabase.from("audit_log" as any).insert({
        table_name: "archivio_fornitori_fraschetti", record_id: cdfor, operation: "update",
        new_values: updatePayload, changed_fields: [field],
        user_id: user?.id, user_email: profile?.email,
      });
    },
    onSuccess: () => {
      toast({ title: "Aggiornato" });
      setEditingId(null);
      queryClient.invalidateQueries({ queryKey: ["suppliers"] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const handleSelectChange = (row: SupplierRow, field: "buyer" | "demand_planner", value: string) => {
    const finalValue = value === "__clear__" ? "" : value;
    updateField.mutate({ id: row.id, cdfor: row.cdfor, field, value: finalValue });
  };

  const startEdit = (row: SupplierRow, field: "rasfo") => {
    setEditingId(`${row.id}_${field}`);
    setEditValue(row[field] ?? "");
  };

  const totalPages = Math.ceil((data?.count ?? 0) / PAGE_SIZE);

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">Fornitori</h1>
        {canCreateSupplier && (
        <Button size="sm" onClick={() => setNewDialogOpen(true)}>
          <Plus className="h-3 w-3 mr-1" /> Nuovo Fornitore
        </Button>
        )}
        <Dialog open={newDialogOpen} onOpenChange={setNewDialogOpen}>
          <DialogContent>
            <DialogHeader><DialogTitle>Nuovo Fornitore</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div>
                <Label className="text-xs">Codice (max 10 car.)</Label>
                <Input value={newCdfor} onChange={(e) => setNewCdfor(e.target.value.toUpperCase().slice(0, 10))} className="h-8 text-sm font-mono" />
                {isDuplicate && (
                  <p className="text-xs text-destructive flex items-center gap-1 mt-1">
                    <AlertCircle className="h-3 w-3" /> Fornitore già esistente
                  </p>
                )}
              </div>
              <div>
                <Label className="text-xs">Ragione Sociale (max 60 car.)</Label>
                <Input value={newRasfo} onChange={(e) => setNewRasfo(e.target.value.slice(0, 60))} className="h-8 text-sm" />
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild><Button variant="outline" size="sm">Annulla</Button></DialogClose>
              <Button size="sm" onClick={() => addMutation.mutate()} disabled={!canCreate || addMutation.isPending}>Crea</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Cerca fornitore..." value={search} onChange={(e) => { setSearch(e.target.value); setPage(0); }} className="pl-9 h-9" />
      </div>

      <div className="border rounded-lg overflow-hidden">
        <div className="flex items-center bg-muted/50 text-xs font-medium text-muted-foreground px-4 h-9">
          <div className="w-[100px]">Codice</div>
          <div className="flex-1 min-w-[180px]">Ragione Sociale</div>
          <div className="w-[170px]">Buyer</div>
          <div className="w-[170px]">Demand Planner</div>
          <div className="w-[70px] text-center">Articoli</div>
          <div className="w-[40px] text-center">Diff</div>
        </div>
        {isLoading ? (
          <div className="p-4 text-sm text-muted-foreground">Caricamento...</div>
        ) : (data?.rows ?? []).map((row) => {
          const editKey = (field: string) => `${row.id}_${field}`;
          return (
            <div key={row.id} className="flex items-center px-4 h-10 border-t text-sm hover:bg-accent/30">
              <div
                className="w-[100px] font-mono text-xs cursor-pointer hover:underline hover:text-primary"
                onClick={() => setDiffSupplier(row)}
                title="Apri differenziale cambio"
              >
                {row.cdfor}
              </div>
              
              {/* Ragione Sociale — inline text edit */}
              <div className="flex-1 min-w-[180px] flex items-center gap-1 pr-2">
                {editingId === editKey("rasfo") ? (
                  <>
                    <Input value={editValue} onChange={(e) => setEditValue(e.target.value.slice(0, 60))} className="h-7 text-sm flex-1" />
                    <Button size="icon" variant="ghost" className="h-6 w-6 shrink-0" onClick={() => updateField.mutate({ id: row.id, cdfor: row.cdfor, field: "rasfo", value: editValue })}><Save className="h-3 w-3" /></Button>
                    <Button size="icon" variant="ghost" className="h-6 w-6 shrink-0" onClick={() => setEditingId(null)}><X className="h-3 w-3" /></Button>
                  </>
                ) : (
                  <span className="cursor-pointer hover:underline truncate" onDoubleClick={() => startEdit(row, "rasfo")}>
                    {row.rasfo ?? "—"}
                  </span>
                )}
              </div>

              {/* Buyer — select dropdown */}
              <div className="w-[170px] pr-2">
                <Select
                  value={row.buyer ?? ""}
                  onValueChange={(v) => handleSelectChange(row, "buyer", v)}
                >
                  <SelectTrigger className="h-7 text-xs border-0 bg-transparent shadow-none hover:bg-accent/50 px-2">
                    <SelectValue placeholder="—" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__clear__" className="text-xs text-muted-foreground">— Nessuno —</SelectItem>
                    {buyerOptions.map((opt) => (
                      <SelectItem key={opt.id} value={opt.code} className="text-xs">
                        {opt.label || opt.code}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Demand Planner — select dropdown */}
              <div className="w-[170px] pr-2">
                <Select
                  value={row.demand_planner ?? ""}
                  onValueChange={(v) => handleSelectChange(row, "demand_planner", v)}
                >
                  <SelectTrigger className="h-7 text-xs border-0 bg-transparent shadow-none hover:bg-accent/50 px-2">
                    <SelectValue placeholder="—" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__clear__" className="text-xs text-muted-foreground">— Nessuno —</SelectItem>
                    {dpOptions.map((opt) => (
                      <SelectItem key={opt.id} value={opt.code} className="text-xs">
                        {opt.label || opt.code}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="w-[70px] text-center text-xs">{articleCounts?.[row.cdfor] ?? 0}</div>

              <div className="w-[40px] text-center">
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-6 w-6 relative"
                  onClick={() => setDiffSupplier(row)}
                  title={activeDiffs?.has(row.cdfor) ? "Differenziale cambio ATTIVO" : "Differenziale cambio"}
                >
                  <Settings2 className="h-3 w-3" />
                  {activeDiffs?.has(row.cdfor) && (
                    <AlertTriangle className="h-3 w-3 text-destructive absolute -top-0.5 -right-0.5 fill-destructive/20" />
                  )}
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      <SupplierDifferentialDialog
        open={!!diffSupplier}
        onClose={() => setDiffSupplier(null)}
        supplier={diffSupplier}
      />

      <div className="flex items-center justify-end gap-2 text-sm text-muted-foreground">
        <span>{data?.count ?? 0} fornitori</span>
        <Button variant="ghost" size="sm" disabled={page === 0} onClick={() => setPage(page - 1)}>←</Button>
        <span>{page + 1}/{totalPages || 1}</span>
        <Button variant="ghost" size="sm" disabled={page >= totalPages - 1} onClick={() => setPage(page + 1)}>→</Button>
      </div>
    </div>
  );
}

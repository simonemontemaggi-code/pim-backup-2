import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from "@/components/ui/sheet";
import { Sparkles, Save, History, Loader2 } from "lucide-react";

type AiPrompt = {
  id: string;
  key: string;
  label: string;
  description: string | null;
  system_prompt: string;
  user_prompt_template: string;
  model: string;
  temperature: number;
  max_tokens: number;
  is_active: boolean;
  updated_at: string;
};

const COMMON_MODELS = [
  // Free
  { value: "google/gemma-4-31b-it:free", label: "Gemma 4 31B IT (free) — consigliato, JSON nativo" },
  { value: "deepseek/deepseek-chat-v3.1:free", label: "DeepSeek V3.1 (free)" },
  { value: "google/gemini-2.0-flash-exp:free", label: "Gemini 2.0 Flash Exp (free)" },
  { value: "meta-llama/llama-3.3-70b-instruct:free", label: "Llama 3.3 70B (free, spesso rate-limited)" },
  { value: "qwen/qwen-2.5-72b-instruct:free", label: "Qwen 2.5 72B (free)" },
  // Paid (qualità superiore)
  { value: "anthropic/claude-3.5-sonnet", label: "Claude 3.5 Sonnet (a pagamento, top quality IT)" },
  { value: "openai/gpt-4o-mini", label: "GPT-4o mini (a pagamento, ottimo rapporto qualità/prezzo)" },
  { value: "google/gemini-2.0-flash-001", label: "Gemini 2.0 Flash (a pagamento)" },
];

export default function AdminAiPromptsPage() {
  const { role } = useAuth();
  const qc = useQueryClient();
  const [editing, setEditing] = useState<AiPrompt | null>(null);

  const { data: prompts, isLoading } = useQuery({
    queryKey: ["ai_prompts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ai_prompts")
        .select("*")
        .order("key");
      if (error) throw error;
      return data as AiPrompt[];
    },
  });

  if (role !== "admin") {
    return (
      <div className="p-6">
        <Card className="p-6 text-center text-muted-foreground">
          Accesso riservato agli amministratori.
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center gap-2">
        <Sparkles className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-semibold">AI Prompts — Generazione contenuti B2B</h2>
      </div>
      <p className="text-sm text-muted-foreground">
        Modifica i prompt usati dall'AI per generare i contenuti marketing degli articoli.
        Le variabili supportate nel template sono: <code className="text-xs bg-muted px-1 rounded">{`{{cdpar}}`}</code>,{" "}
        <code className="text-xs bg-muted px-1 rounded">{`{{depar}}`}</code>,{" "}
        <code className="text-xs bg-muted px-1 rounded">{`{{clas2}}`}</code>,{" "}
        <code className="text-xs bg-muted px-1 rounded">{`{{nmcat}}`}</code>,{" "}
        <code className="text-xs bg-muted px-1 rounded">{`{{lipro}}`}</code>,{" "}
        <code className="text-xs bg-muted px-1 rounded">{`{{wfuas}}`}</code>,{" "}
        <code className="text-xs bg-muted px-1 rounded">{`{{clmer}}`}</code>,{" "}
        <code className="text-xs bg-muted px-1 rounded">{`{{attributes}}`}</code>.
      </p>

      {isLoading ? (
        <div className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}
        </div>
      ) : (
        <div className="grid gap-3">
          {prompts?.map((p) => (
            <Card key={p.id} className="p-4 hover:shadow-md transition-shadow cursor-pointer" onClick={() => setEditing(p)}>
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-sm">{p.label}</h3>
                    <Badge variant="outline" className="text-[10px] font-mono">{p.key}</Badge>
                    {!p.is_active && <Badge variant="secondary" className="text-[10px]">Disattivo</Badge>}
                  </div>
                  {p.description && (
                    <p className="text-xs text-muted-foreground mb-2">{p.description}</p>
                  )}
                  <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                    <span>Modello: <code className="bg-muted px-1 rounded">{p.model}</code></span>
                    <span>Temp: {p.temperature}</span>
                    <span>Max tokens: {p.max_tokens}</span>
                  </div>
                </div>
                <Button size="sm" variant="outline">Modifica</Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {editing && (
        <PromptEditor
          prompt={editing}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            qc.invalidateQueries({ queryKey: ["ai_prompts"] });
          }}
        />
      )}
    </div>
  );
}

function PromptEditor({ prompt, onClose, onSaved }: { prompt: AiPrompt; onClose: () => void; onSaved: () => void }) {
  const [systemPrompt, setSystemPrompt] = useState(prompt.system_prompt);
  const [userTemplate, setUserTemplate] = useState(prompt.user_prompt_template);
  const [model, setModel] = useState(prompt.model);
  const [temperature, setTemperature] = useState(prompt.temperature);
  const [maxTokens, setMaxTokens] = useState(prompt.max_tokens);
  const [isActive, setIsActive] = useState(prompt.is_active);
  const [showHistory, setShowHistory] = useState(false);

  const save = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("ai_prompts")
        .update({
          system_prompt: systemPrompt,
          user_prompt_template: userTemplate,
          model,
          temperature,
          max_tokens: maxTokens,
          is_active: isActive,
          updated_by: (await supabase.auth.getUser()).data.user?.id,
        })
        .eq("id", prompt.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Prompt salvato");
      onSaved();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const { data: versions } = useQuery({
    queryKey: ["ai_prompt_versions", prompt.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ai_prompt_versions")
        .select("*")
        .eq("prompt_id", prompt.id)
        .order("changed_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      return data;
    },
    enabled: showHistory,
  });

  return (
    <Sheet open={true} onOpenChange={(o) => { if (!o) onClose(); }}>
      <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            {prompt.label}
            <Badge variant="outline" className="text-[10px] font-mono">{prompt.key}</Badge>
          </SheetTitle>
          <SheetDescription>{prompt.description}</SheetDescription>
        </SheetHeader>

        <div className="space-y-4 mt-6">
          <div className="flex items-center gap-3">
            <Switch checked={isActive} onCheckedChange={setIsActive} id="is_active" />
            <Label htmlFor="is_active" className="cursor-pointer">Prompt attivo</Label>
          </div>

          <div className="space-y-1.5">
            <Label className="text-sm font-semibold">Modello OpenRouter</Label>
            <Input value={model} onChange={(e) => setModel(e.target.value)} className="font-mono text-xs" />
            <div className="flex flex-wrap gap-1 mt-1">
              {COMMON_MODELS.map((m) => (
                <Button
                  key={m.value} size="sm" variant="ghost" type="button"
                  className="h-6 text-[10px] font-mono"
                  onClick={() => setModel(m.value)}
                  title={m.label}
                >{m.value}</Button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-sm font-semibold">Temperature ({temperature})</Label>
              <Input type="number" min={0} max={2} step={0.1} value={temperature} onChange={(e) => setTemperature(Number(e.target.value))} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-semibold">Max tokens</Label>
              <Input type="number" min={50} max={8000} value={maxTokens} onChange={(e) => setMaxTokens(Number(e.target.value))} />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-sm font-semibold">System Prompt</Label>
            <p className="text-xs text-muted-foreground">Istruzioni di ruolo e tono per l'AI.</p>
            <Textarea value={systemPrompt} onChange={(e) => setSystemPrompt(e.target.value)} className="min-h-[140px] text-xs font-mono" />
          </div>

          <div className="space-y-1.5">
            <Label className="text-sm font-semibold">User Prompt Template</Label>
            <p className="text-xs text-muted-foreground">
              Template della richiesta. Usa <code className="bg-muted px-1 rounded">{`{{variabile}}`}</code> per inserire i dati dell'articolo.
            </p>
            <Textarea value={userTemplate} onChange={(e) => setUserTemplate(e.target.value)} className="min-h-[200px] text-xs font-mono" />
          </div>

          <div className="flex items-center gap-2 pt-4 border-t">
            <Button onClick={() => save.mutate()} disabled={save.isPending} className="gap-2">
              {save.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Salva
            </Button>
            <Button variant="outline" onClick={onClose}>Annulla</Button>
            <Button variant="ghost" onClick={() => setShowHistory((s) => !s)} className="gap-1.5 ml-auto">
              <History className="h-4 w-4" /> {showHistory ? "Nascondi" : "Mostra"} storico
            </Button>
          </div>

          {showHistory && versions && (
            <div className="space-y-2 pt-2 border-t">
              <h4 className="text-xs font-semibold uppercase text-muted-foreground">Storico versioni</h4>
              {versions.length === 0 && <p className="text-xs text-muted-foreground italic">Nessuna versione precedente.</p>}
              {versions.map((v) => (
                <Card key={v.id} className="p-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-muted-foreground">{new Date(v.changed_at).toLocaleString("it-IT")}</span>
                    <Button
                      size="sm" variant="ghost" className="h-6 text-[11px]"
                      onClick={() => {
                        setSystemPrompt(v.system_prompt);
                        setUserTemplate(v.user_prompt_template);
                        setModel(v.model);
                        setTemperature(Number(v.temperature));
                        setMaxTokens(v.max_tokens);
                        toast.info("Versione caricata. Ricordati di salvare.");
                      }}
                    >Ripristina</Button>
                  </div>
                  <code className="text-[10px] block">{v.model} • temp {v.temperature} • {v.max_tokens}tok</code>
                  <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2">{v.system_prompt}</p>
                </Card>
              ))}
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

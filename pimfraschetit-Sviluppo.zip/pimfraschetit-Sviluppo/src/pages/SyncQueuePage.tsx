import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "@/hooks/use-toast";
import { Download, CheckCircle, RefreshCw, AlertTriangle } from "lucide-react";

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-warning/10 text-warning border-warning/30",
  synced: "bg-success/10 text-success border-success/30",
  error: "bg-destructive/10 text-destructive border-destructive/30",
};

const TABS = [
  { value: "all", label: "Tutti" },
  { value: "pending", label: "In attesa" },
  { value: "synced", label: "Inviati" },
  { value: "error", label: "Errori" },
];

function relativeTime(dateStr: string | null): string {
  if (!dateStr) return "";
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "ora";
  if (mins < 60) return `${mins}m fa`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h fa`;
  return `${Math.floor(hrs / 24)}g fa`;
}

export default function SyncQueuePage() {
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState("all");
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["sync_queue", statusFilter],
    queryFn: async () => {
      let q = supabase
        .from("as400_sync_queue" as any)
        .select("*")
        .order("created_at", { ascending: false })
        .limit(200);
      if (statusFilter !== "all") q = q.eq("status", statusFilter);
      const { data, error } = await q;
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 10_000,
    refetchInterval: (query) => {
      const data = query.state.data as any[] | undefined;
      const hasPending = data?.some((r: any) => r.status === "pending");
      return hasPending ? 30_000 : 0;
    },
  });

  const errorCount = useMemo(() => rows.filter((r: any) => (r.attempts ?? 0) >= 3 && r.status === "error").length, [rows]);

  const markSynced = useMutation({
    mutationFn: async (ids: string[]) => {
      for (const id of ids) {
        await supabase.from("as400_sync_queue" as any).update({ status: "synced", sent_at: new Date().toISOString(), updated_at: new Date().toISOString() }).eq("id", id);
      }
    },
    onSuccess: () => {
      toast({ title: "Aggiornato", description: "Elementi marcati come sincronizzati." });
      setSelected(new Set());
      queryClient.invalidateQueries({ queryKey: ["sync_queue"] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const retryNow = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.functions.invoke("sync-as400-retry");
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      toast({ title: "Sync completato", description: `Processati: ${data?.processed ?? 0}, Inviati: ${data?.sent ?? 0}, Errori: ${data?.errors ?? 0}` });
      queryClient.invalidateQueries({ queryKey: ["sync_queue"] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });

  const exportJson = () => {
    const pending = rows.filter((r: any) => r.status === "pending");
    const blob = new Blob([JSON.stringify(pending.map((r: any) => r.payload), null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `as400_queue_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const toggleSelect = (id: string) => {
    const next = new Set(selected);
    next.has(id) ? next.delete(id) : next.add(id);
    setSelected(next);
  };

  const toggleAll = () => {
    if (selected.size === rows.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(rows.map((r: any) => r.id)));
    }
  };

  return (
    <div className="p-6 space-y-4">
      {/* Error banner */}
      {errorCount > 0 && (
        <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-destructive text-sm">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span className="font-medium">⚠️ {errorCount} element{errorCount > 1 ? "i" : "o"} in errore — richiede attenzione manuale</span>
        </div>
      )}

      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">Coda Sincronizzazione AS400</h1>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => retryNow.mutate()} disabled={retryNow.isPending}>
            <RefreshCw className={`h-3 w-3 mr-1 ${retryNow.isPending ? "animate-spin" : ""}`} /> Riprova ora
          </Button>
          <Button size="sm" variant="outline" onClick={exportJson}>
            <Download className="h-3 w-3 mr-1" /> Esporta JSON
          </Button>
          {selected.size > 0 && (
            <Button size="sm" onClick={() => markSynced.mutate(Array.from(selected))} disabled={markSynced.isPending}>
              <CheckCircle className="h-3 w-3 mr-1" /> Segna come inviati ({selected.size})
            </Button>
          )}
        </div>
      </div>

      {/* Status tabs */}
      <div className="flex gap-1">
        {TABS.map((tab) => (
          <Button
            key={tab.value}
            size="sm"
            variant={statusFilter === tab.value ? "default" : "ghost"}
            className="h-8 text-xs"
            onClick={() => setStatusFilter(tab.value)}
          >
            {tab.label}
          </Button>
        ))}
      </div>

      <div className="border rounded-lg overflow-hidden">
        <div className="flex items-center bg-muted/50 text-xs font-medium text-muted-foreground px-4 h-9 gap-2">
          <div className="w-[30px]"><Checkbox checked={selected.size === rows.length && rows.length > 0} onCheckedChange={toggleAll} /></div>
          <div className="w-[120px]">Codice</div>
          <div className="flex-1">Descrizione</div>
          <div className="w-[80px]">Operazione</div>
          <div className="w-[120px]">Data</div>
          <div className="w-[60px]">Tentativi</div>
          <div className="w-[80px]">Ultimo</div>
          <div className="w-[80px]">Stato</div>
          <div className="flex-1">Errore</div>
          <div className="w-[100px]">Azioni</div>
        </div>
        {isLoading ? (
          <div className="p-4 text-sm text-muted-foreground">Caricamento...</div>
        ) : rows.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 text-muted-foreground">
            <RefreshCw className="h-8 w-8 text-muted-foreground/30 mb-2" />
            <p className="font-medium text-sm">Nessun elemento in coda</p>
            <p className="text-xs mt-1">La coda di sincronizzazione è vuota</p>
          </div>
        ) : rows.map((row: any) => (
          <div key={row.id} className="flex items-center px-4 h-10 border-t text-xs hover:bg-accent/30 gap-2">
            <div className="w-[30px]"><Checkbox checked={selected.has(row.id)} onCheckedChange={() => toggleSelect(row.id)} /></div>
            <div className="w-[120px] font-mono">{row.cdpar}</div>
            <div className="flex-1 truncate">{row.payload?.depar ?? ""}</div>
            <div className="w-[80px]">{row.operation}</div>
            <div className="w-[120px]">{new Date(row.created_at).toLocaleString("it-IT", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}</div>
            <div className="w-[60px] text-center">{row.attempts ?? 0}/3</div>
            <div className="w-[80px] text-muted-foreground">{relativeTime(row.last_attempt_at)}</div>
            <div className="w-[80px]">
              <Badge variant="outline" className={`text-[10px] ${STATUS_COLORS[row.status] ?? ""}`}>
                {row.status}
              </Badge>
            </div>
            <div className="flex-1 text-destructive truncate">{row.error_message}</div>
            <div className="w-[100px]">
              {row.status === "pending" && (
                <Button size="sm" variant="ghost" className="h-6 text-[10px] px-2" onClick={() => markSynced.mutate([row.id])}>
                  <CheckCircle className="h-3 w-3 mr-1" /> Inviato
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

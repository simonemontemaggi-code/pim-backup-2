import { useState, useCallback, useMemo, useEffect } from "react";
import { downloadXlsxAoa } from "@/lib/xlsxExport";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useVisibleAssortments } from "@/hooks/useVisibleAssortments";
import { useOnlineAssortments, computeIsB2bOnline } from "@/hooks/useOnlineAssortments";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious, PaginationEllipsis } from "@/components/ui/pagination";
import { toast } from "@/hooks/use-toast";
import { Image, Search, Upload, CheckCircle, AlertTriangle, XCircle, Download } from "lucide-react";
import { FileDropZone } from "@/components/ui/FileDropZone";
import { useNavigate } from "react-router-dom";
import { detectCdparFromFilename, buildImagePath, getFileExt, getMediaCdparCandidates, normalizeMediaCdpar, parseImageProgressiveFromFilename, normalizeArticleImageOrdering } from "@/lib/mediaUtils";
import {
  buildPublicMediaUrl,
  fetchAllPages,
  MEDIA_BULK_UPLOAD_CONCURRENCY,
  MEDIA_UPLOAD_CONCURRENCY,
  getStartingProgressives,
  runWithConcurrency,
} from "@/lib/mediaUpload";

type FilterMode = "all" | "no_image" | "no_datasheet" | "no_safety";
type B2bFilter = "all" | "online" | "offline";

const PAGE_SIZE = 25;
const BULK_PREVIEW_LIMIT = 300;
const EXPORT_SEARCH_PAGE_SIZE = 1000;
const SEARCH_EXPORT_CDPAR_CHUNK_SIZE = 200;
const SUPPORTED_BULK_IMAGE_EXTENSIONS = new Set(["jpg", "jpeg", "png", "webp"]);

const chunkItems = <T,>(items: T[], size: number): T[][] => {
  const chunks: T[][] = [];

  for (let index = 0; index < items.length; index += size) {
    chunks.push(items.slice(index, index + size));
  }

  return chunks;
};

interface BulkFile {
  file: File;
  detectedCdpar: string | null;
  confidence: "exact" | "partial" | "none";
  depar: string | null;
  hasExisting: boolean;
  manualCdpar: string | null;
}

const isSupportedBulkImage = (file: File) =>
  file.type.startsWith("image/") || SUPPORTED_BULK_IMAGE_EXTENSIONS.has(getFileExt(file.name));

const getBulkFileKey = (bulkFile: BulkFile) =>
  `${bulkFile.file.name}::${bulkFile.file.size}::${bulkFile.file.lastModified}`;

function CdparSearchInput({ onSelect }: { onSelect: (cdpar: string) => void }) {
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(search), 250);
    return () => clearTimeout(t);
  }, [search]);

  const { data: filtered = [] } = useQuery({
    queryKey: ["media_cdpar_search", debounced],
    enabled: debounced.length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("search_articles", {
        query: debounced,
        filter_clmer: null,
        filter_lipro: null,
        lim: 20,
        off: 0,
      });
      if (error) throw error;
      return ((data ?? []) as { cdpar: string; depar: string | null }[]).map((r) => ({
        cdpar: normalizeMediaCdpar(r.cdpar),
        depar: r.depar,
      })).filter((r) => r.cdpar);
    },
    staleTime: 30_000,
  });

  return (
    <div className="relative">
      <Input
        className="h-7 w-48 text-xs"
        placeholder="Cerca codice o desc..."
        value={search}
        onChange={(e) => { setSearch(e.target.value); setOpen(true); }}
        onFocus={() => search.length >= 2 && setOpen(true)}
        onBlur={() => setTimeout(() => setOpen(false), 200)}
      />
      {open && filtered.length > 0 && (
        <div className="absolute z-50 top-8 left-0 w-64 max-h-48 overflow-auto bg-popover border rounded-md shadow-lg">
          {filtered.map((a) => (
            <button
              key={a.cdpar}
              className="w-full text-left px-2 py-1 text-xs hover:bg-accent truncate"
              onMouseDown={(e) => { e.preventDefault(); onSelect(a.cdpar); setSearch(a.cdpar); setOpen(false); }}
            >
              <span className="font-mono font-medium">{a.cdpar}</span>
              <span className="text-muted-foreground ml-1">— {a.depar?.substring(0, 30)}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default function MediaLibraryPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { data: visibleAssortments = [] } = useVisibleAssortments();
  const { data: onlineAssortments = [] } = useOnlineAssortments();
  const [filter, setFilter] = useState<FilterMode>("all");
  const [b2bFilter, setB2bFilter] = useState<B2bFilter>("all");
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [page, setPage] = useState(0);
  const [exportingCsv, setExportingCsv] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search), 400);
    return () => clearTimeout(timer);
  }, [search]);

  // Reset page on filter/search change
  useEffect(() => { setPage(0); }, [filter, b2bFilter, debouncedSearch]);

  const [bulkFiles, setBulkFiles] = useState<BulkFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadedCount, setUploadedCount] = useState(0);
  const [uploadStage, setUploadStage] = useState("");
  

  const invalidateMediaQueries = useCallback(
    () => Promise.all([
      queryClient.invalidateQueries({ queryKey: ["all_article_media"] }),
      queryClient.invalidateQueries({ queryKey: ["media_cdpars_by_type"] }),
      queryClient.invalidateQueries({ queryKey: ["media_articles_list"] }),
    ]),
    [queryClient]
  );

  // Fetch all media grouped by cdpar
  const { data: mediaMap = {}, isLoading: loadingMedia } = useQuery({
    queryKey: ["all_article_media"],
    queryFn: async () => {
      const data = await fetchAllPages(async (from, to) => {
        const { data, error } = await supabase
          .from("article_media")
          .select("cdpar, media_type, public_url, is_primary")
          .range(from, to);
        if (error) throw error;
        return (data ?? []) as any[];
      });
      const map: Record<string, { primary?: string; types: Set<string> }> = {};
      (data ?? []).forEach((m: any) => {
        const key = normalizeMediaCdpar(m.cdpar);
        if (!key) return;
        if (!map[key]) map[key] = { types: new Set() };
        map[key].types.add(m.media_type);
        if (m.media_type === "image") {
          if (m.is_primary) {
            map[key].primary = m.public_url;
          } else if (!map[key].primary) {
            map[key].primary = m.public_url;
          }
        }
      });
      return map;
    },
    staleTime: 30_000,
  });

  // For filters != "all", get cdpars that HAVE media of a certain type
  const { data: mediaCdparsByType = { image: new Set<string>(), pdf_datasheet: new Set<string>(), pdf_safety: new Set<string>() } } = useQuery({
    queryKey: ["media_cdpars_by_type"],
    queryFn: async () => {
      const data = await fetchAllPages(async (from, to) => {
        const { data, error } = await supabase
          .from("article_media")
          .select("cdpar, media_type")
          .range(from, to);
        if (error) throw error;
        return (data ?? []) as any[];
      });
      const result = { image: new Set<string>(), pdf_datasheet: new Set<string>(), pdf_safety: new Set<string>() };
      (data ?? []).forEach((m: any) => {
        const key = normalizeMediaCdpar(m.cdpar);
        if (!key) return;
        if (m.media_type === "image") result.image.add(key);
        if (m.media_type === "pdf_datasheet") result.pdf_datasheet.add(key);
        if (m.media_type === "pdf_safety") result.pdf_safety.add(key);
      });
      return result;
    },
    staleTime: 30_000,
  });

  // Set of cdpars that are currently online B2B (cached)
  const { data: onlineCdpars = new Set<string>() } = useQuery({
    queryKey: ["media_online_b2b_cdpars", onlineAssortments],
    queryFn: async () => {
      const rows = await fetchAllPages(async (from, to) => {
        const { data, error } = await supabase
          .from("archivio_articoli_fraschetti")
          .select("cdpar, wfuas, b2b_online_active")
          .range(from, to);
        if (error) throw error;
        return (data ?? []) as any[];
      });
      const set = new Set<string>();
      rows.forEach((r: any) => {
        if (computeIsB2bOnline(r.b2b_online_active, r.wfuas, onlineAssortments)) {
          const key = normalizeMediaCdpar(r.cdpar);
          if (key) set.add(key);
        }
      });
      return set;
    },
    staleTime: 60_000,
  });

  const passesB2bFilter = useCallback((cdpar: string) => {
    if (b2bFilter === "all") return true;
    const online = onlineCdpars.has(cdpar);
    return b2bFilter === "online" ? online : !online;
  }, [b2bFilter, onlineCdpars]);

  const fetchAllSearchMatches = useCallback(async (query: string) => {
    const matches = new Map<string, string | null>();
    let offset = 0;

    while (true) {
      const { data, error } = await supabase.rpc("search_articles", {
        query,
        filter_clmer: null,
        filter_lipro: null,
        lim: EXPORT_SEARCH_PAGE_SIZE,
        off: offset,
      });

      if (error) throw error;

      const rows = (data ?? []) as { cdpar: string; depar: string | null }[];
      rows.forEach((row) => {
        const key = normalizeMediaCdpar(row.cdpar);
        if (key) matches.set(key, row.depar ?? null);
      });

      if (rows.length < EXPORT_SEARCH_PAGE_SIZE) break;
      offset += EXPORT_SEARCH_PAGE_SIZE;
    }

    return Array.from(matches.entries())
      .map(([cdpar, depar]) => ({ cdpar, depar }))
      .sort((a, b) => a.cdpar.localeCompare(b.cdpar));
  }, []);

  const fetchExportArticles = useCallback(async () => {
    let exportArticles: { cdpar: string; depar: string | null }[] = [];

    if (debouncedSearch.length >= 2) {
      const matchedArticles = await fetchAllSearchMatches(debouncedSearch);

      if (visibleAssortments.length > 0 && matchedArticles.length > 0) {
        const visibleMatches: { cdpar: string; depar: string | null }[] = [];

        for (const cdparChunk of chunkItems(
          matchedArticles.map((article) => article.cdpar),
          SEARCH_EXPORT_CDPAR_CHUNK_SIZE
        )) {
          const masterCdparCandidates = Array.from(new Set(cdparChunk.flatMap((cdpar) => getMediaCdparCandidates(cdpar))));
          const { data, error } = await supabase
            .from("archivio_articoli_fraschetti")
            .select("cdpar, depar")
            .in("cdpar", masterCdparCandidates)
            .in("wfuas", visibleAssortments)
            .order("cdpar");

          if (error) throw error;
          visibleMatches.push(
            ...((data ?? []) as { cdpar: string; depar: string | null }[]).map((row) => ({
              cdpar: normalizeMediaCdpar(row.cdpar),
              depar: row.depar,
            }))
          );
        }

        exportArticles = visibleMatches.sort((a, b) => a.cdpar.localeCompare(b.cdpar));
      } else {
        exportArticles = matchedArticles;
      }
    } else {
      exportArticles = await fetchAllPages(async (from, to) => {
        let query = supabase
          .from("archivio_articoli_fraschetti")
          .select("cdpar, depar")
          .order("cdpar")
          .range(from, to);

        if (visibleAssortments.length > 0) {
          query = query.in("wfuas", visibleAssortments);
        }

        const { data, error } = await query;
        if (error) throw error;
        return ((data ?? []) as { cdpar: string; depar: string | null }[]).map((row) => ({
          cdpar: normalizeMediaCdpar(row.cdpar),
          depar: row.depar,
        }));
      });
    }

    let result = exportArticles;
    if (filter !== "all") {
      const excludeSet = filter === "no_image"
        ? mediaCdparsByType.image
        : filter === "no_datasheet"
          ? mediaCdparsByType.pdf_datasheet
          : mediaCdparsByType.pdf_safety;
      result = result.filter((article) => !excludeSet.has(article.cdpar));
    }
    if (b2bFilter !== "all") {
      result = result.filter((article) => passesB2bFilter(article.cdpar));
    }
    return result;
  }, [debouncedSearch, fetchAllSearchMatches, filter, mediaCdparsByType, visibleAssortments, b2bFilter, passesB2bFilter]);

  const handleExportCsv = useCallback(async () => {
    setExportingCsv(true);

    try {
      const exportArticles = await fetchExportArticles();
      const aoa: any[][] = [["Codice", "Descrizione", "Immagine", "Scheda Tecnica", "Scheda Sicurezza"]];
      exportArticles.forEach((article) => {
        const media = mediaMap[article.cdpar];
        aoa.push([
          article.cdpar,
          article.depar ?? "",
          media?.types.has("image") ? "Sì" : "No",
          media?.types.has("pdf_datasheet") ? "Sì" : "No",
          media?.types.has("pdf_safety") ? "Sì" : "No",
        ]);
      });
      downloadXlsxAoa(`media_library_${filter}.xlsx`, aoa, { sheetName: "Media" });

      toast({ title: "XLSX esportato", description: `${exportArticles.length} articoli esportati.` });
    } catch (error: any) {
      toast({ title: "Errore esportazione", description: error.message, variant: "destructive" });
    } finally {
      setExportingCsv(false);
    }
  }, [fetchExportArticles, filter, mediaMap]);

  // Fetch articles with server-side pagination and filtering
  const { data: articlesResult, isLoading: loadingArticles } = useQuery({
    queryKey: ["media_articles_list", debouncedSearch, filter, b2bFilter, page, visibleAssortments, mediaCdparsByType, onlineCdpars],
    queryFn: async () => {
      const needsClientFilter = filter !== "all" || b2bFilter !== "all";
      // For "no_*" / b2b filters we need client-side exclusion because the exclusion set can be huge
      if (needsClientFilter) {
        const excludeSet = filter === "no_image" ? mediaCdparsByType.image
          : filter === "no_datasheet" ? mediaCdparsByType.pdf_datasheet
          : filter === "no_safety" ? mediaCdparsByType.pdf_safety
          : null;

        // Fetch all matching cdpars (no pagination yet — we paginate client-side)
        let allArticles: { cdpar: string; depar: string | null }[] = [];

        if (debouncedSearch.length >= 2) {
          const { data: searchResults, error: searchErr } = await supabase.rpc("search_articles", {
            query: debouncedSearch, filter_clmer: null, filter_lipro: null, lim: 5000, off: 0,
          });
          if (searchErr) throw searchErr;
          allArticles = (searchResults ?? []).map((r: any) => ({ cdpar: normalizeMediaCdpar(r.cdpar), depar: r.depar as string | null }));
        } else {
          const data = await fetchAllPages(async (from, to) => {
            let q = supabase.from("archivio_articoli_fraschetti").select("cdpar, depar").order("cdpar").range(from, to);
            if (visibleAssortments.length > 0) q = q.in("wfuas", visibleAssortments);
            const { data, error } = await q;
            if (error) throw error;
            return ((data ?? []) as { cdpar: string; depar: string | null }[]).map((row) => ({
              cdpar: normalizeMediaCdpar(row.cdpar),
              depar: row.depar,
            }));
          });
          allArticles = data;
        }

        // Client-side exclusion
        const filtered = allArticles.filter((a) => {
          if (excludeSet && excludeSet.has(a.cdpar)) return false;
          if (!passesB2bFilter(a.cdpar)) return false;
          return true;
        });
        const totalCount = filtered.length;
        const pageSlice = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
        return { articles: pageSlice, totalCount };
      }

      // "all" filter — use server-side pagination
      let q = supabase.from("archivio_articoli_fraschetti").select("cdpar, depar", { count: "exact" }).order("cdpar");
      if (visibleAssortments.length > 0) q = q.in("wfuas", visibleAssortments);

      if (debouncedSearch.length >= 2) {
        const { data: searchResults, error: searchErr } = await supabase.rpc("search_articles", {
          query: debouncedSearch, filter_clmer: null, filter_lipro: null, lim: 1000, off: 0,
        });
        if (searchErr) throw searchErr;
        const matchedCdpars = Array.from(new Set((searchResults ?? []).flatMap((r: any) => getMediaCdparCandidates(r.cdpar))));
        if (matchedCdpars.length === 0) return { articles: [], totalCount: 0 };
        q = q.in("cdpar", matchedCdpars);
      }

      q = q.range(page * PAGE_SIZE, (page + 1) * PAGE_SIZE - 1);
      const { data, error, count } = await q;
      if (error) throw error;
      return {
        articles: ((data ?? []) as { cdpar: string; depar: string | null }[]).map((row) => ({
          cdpar: normalizeMediaCdpar(row.cdpar),
          depar: row.depar,
        })),
        totalCount: count ?? 0,
      };
    },
    staleTime: 30_000,
  });

  const articles = articlesResult?.articles ?? [];
  const totalCount = articlesResult?.totalCount ?? 0;
  const totalPages = Math.ceil(totalCount / PAGE_SIZE);

  // All cdpars for auto-detect (cached)
  const { data: allCdpars = [] } = useQuery({
    queryKey: ["all_cdpars_for_detect"],
    queryFn: async () => {
      const data = await fetchAllPages(async (from, to) => {
        const { data, error } = await supabase
          .from("archivio_articoli_fraschetti")
          .select("cdpar, depar")
          .range(from, to);
        if (error) throw error;
        return (data ?? []) as { cdpar: string; depar: string | null }[];
      });

      return data;
    },
    staleTime: 5 * 60_000,
  });


  const cdparList = useMemo(() => allCdpars.map((a) => normalizeMediaCdpar(a.cdpar)).filter(Boolean), [allCdpars]);
  const cdparMap = useMemo(() => {
    const m: Record<string, string | null> = {};
    allCdpars.forEach((a) => {
      const key = normalizeMediaCdpar(a.cdpar);
      if (key) m[key] = a.depar;
    });
    return m;
  }, [allCdpars]);

  // --- Bulk upload logic ---
  const handleBulkFiles = useCallback(
    (fileList: File[]) => {
      const imageFiles = fileList.filter(isSupportedBulkImage);
      const skippedCount = fileList.length - imageFiles.length;

      const results: BulkFile[] = imageFiles.map((file) => {
        const det = detectCdparFromFilename(file.name, cdparList);
        return {
          file,
          detectedCdpar: det.cdpar,
          confidence: det.confidence,
          depar: det.cdpar ? cdparMap[det.cdpar] ?? null : null,
          hasExisting: det.cdpar ? !!mediaMap[det.cdpar]?.types.has("image") : false,
          manualCdpar: null,
        };
      });

      setBulkFiles(results);

      if (skippedCount > 0) {
        toast({
          title: `${skippedCount} file ignorati`,
          description: "Nel caricamento massivo immagini sono supportati solo JPG, PNG e WebP.",
          variant: "destructive",
        });
      }
    },
    [cdparList, cdparMap, mediaMap]
  );

  const updateManualCdpar = (idx: number, cdpar: string) => {
    setBulkFiles((prev) => {
      const next = [...prev];
      next[idx] = {
        ...next[idx],
        manualCdpar: cdpar,
        depar: cdparMap[cdpar] ?? null,
        hasExisting: !!mediaMap[cdpar]?.types.has("image"),
      };
      return next;
    });
  };

  const getEffectiveCdpar = (bf: BulkFile) => bf.manualCdpar || bf.detectedCdpar;
  const getStatus = (bf: BulkFile): "green" | "yellow" | "red" => {
    const c = getEffectiveCdpar(bf);
    if (!c || !cdparMap.hasOwnProperty(c)) return "red";
    return bf.hasExisting || (mediaMap[c]?.types.has("image")) ? "yellow" : "green";
  };

  const uploadableFiles = useMemo(
    () => bulkFiles.filter((bf) => getStatus(bf) !== "red"),
    [bulkFiles, cdparMap, mediaMap]
  );

  const bulkStatusCounts = useMemo(() => {
    return bulkFiles.reduce(
      (counts, bulkFile) => {
        counts[getStatus(bulkFile)] += 1;
        return counts;
      },
      { green: 0, yellow: 0, red: 0 }
    );
  }, [bulkFiles, cdparMap, mediaMap]);

  const previewBulkFiles = useMemo(
    () => bulkFiles.slice(0, BULK_PREVIEW_LIMIT),
    [bulkFiles]
  );

  const handleBulkUpload = async () => {
    if (uploadableFiles.length === 0) return;

    setUploading(true);
    setUploadedCount(0);
    setUploadStage("Caricamento immagini...");

    const articlesUpdated = new Set<string>();
    const successfulUploads = new Set<string>();
    let uploaded = 0;
    let failed = 0;
    let lastErrorMessage = "";

    try {
      const plannedBase = uploadableFiles.map((bf) => {
        const cdpar = normalizeMediaCdpar(getEffectiveCdpar(bf)!);
        return {
          bf,
          cdpar,
          ext: getFileExt(bf.file.name),
        };
      });

      // Pre-carica righe esistenti per (cdpar, media_type=image): l'upload deve
      // sovrascrivere righe esistenti, non fare upsert sul vincolo sbagliato.
      const cdparsInBatch = Array.from(new Set(plannedBase.map((p) => p.cdpar)));
      const cdparCandidatesInBatch = Array.from(new Set(cdparsInBatch.flatMap((c) => getMediaCdparCandidates(c))));
      type ExistingMediaRow = { id: string; storage_path: string; progressive: number | null; original_filename?: string | null };
      const existingByName = new Map<string, ExistingMediaRow>();
      const existingByBaseName = new Map<string, ExistingMediaRow>();
      const existingByProgressive = new Map<string, ExistingMediaRow>();
      const existingByStoragePath = new Map<string, ExistingMediaRow>();
      const usedProgressivesByCdpar = new Map<string, Set<number>>();
      const stripExt = (name: string) => name.replace(/\.[^/.]+$/, "").trim().toLowerCase();
      if (cdparsInBatch.length > 0) {
        for (const chunk of chunkItems(cdparCandidatesInBatch, 200)) {
          const { data: existingRows, error: existingErr } = await supabase
            .from("article_media")
            .select("id, cdpar, original_filename, storage_path, progressive")
            .eq("media_type", "image")
            .in("cdpar", chunk);
          if (existingErr) throw existingErr;
          (existingRows ?? []).forEach((row: any) => {
            const rowCdpar = normalizeMediaCdpar(row.cdpar);
            const rowRef: ExistingMediaRow = {
              id: row.id,
              storage_path: row.storage_path,
              progressive: row.progressive,
              original_filename: row.original_filename,
            };
            if (row?.original_filename) {
              existingByName.set(`${rowCdpar}::${row.original_filename}`, rowRef);
              const base = stripExt(row.original_filename);
              const baseKey = `${rowCdpar}::${base}`;
              if (base && !existingByBaseName.has(baseKey)) existingByBaseName.set(baseKey, rowRef);
            }
            if (row?.storage_path) {
              existingByStoragePath.set(`${rowCdpar}::${row.storage_path}`, rowRef);
              const pathFile = row.storage_path.split("/").pop() ?? "";
              const base = stripExt(pathFile);
              const baseKey = `${rowCdpar}::${base}`;
              if (base && !existingByBaseName.has(baseKey)) existingByBaseName.set(baseKey, rowRef);
            }
            if (row?.progressive != null) {
              const used = usedProgressivesByCdpar.get(rowCdpar) ?? new Set<number>();
              used.add(row.progressive);
              usedProgressivesByCdpar.set(rowCdpar, used);
              // Escludi lo slot "P{cdpar}" e lo slot bare "{cdpar}" dall'indice per-progressive:
              // sono slot distinti che non devono collidere con `{cdpar}_N` (allineato a TabMedia).
              const baseFn = row.original_filename ? stripExt(row.original_filename) : "";
              const rowCdparLower = rowCdpar.toLowerCase();
              const isPName = baseFn === `p${rowCdparLower}`;
              const isBareName = baseFn === rowCdparLower;
              const progKey = `${rowCdpar}::${row.progressive}`;
              if (!isPName && !isBareName && !existingByProgressive.has(progKey)) {
                existingByProgressive.set(progKey, rowRef);
              }
            }
          });
        }
      }

      const findExisting = (cdpar: string, filename: string) => {
        const fromProg = parseImageProgressiveFromFilename(cdpar, filename);
        const byName = existingByName.get(`${cdpar}::${filename}`);
        if (byName) return byName;
        const fileBase = stripExt(filename);
        if (fileBase) {
          const byBase = existingByBaseName.get(`${cdpar}::${fileBase}`);
          if (byBase) return byBase;
        }
        if (fromProg != null) {
          const canonicalPath = buildImagePath(cdpar, fromProg, getFileExt(filename), filename);
          const byPath = existingByStoragePath.get(`${cdpar}::${canonicalPath}`);
          if (byPath) return { ...byPath, progressive: fromProg };
          const e = existingByProgressive.get(`${cdpar}::${fromProg}`);
          if (e) return { ...e, progressive: fromProg };
        }
        return null;
      };


      const newPlans = plannedBase.filter((p) => !findExisting(p.cdpar, p.bf.file.name));

      const startingProgressives = await getStartingProgressives(
        newPlans.map(({ cdpar }) => ({ cdpar, mediaType: "image" }))
      );
      const nextProgressives = { ...startingProgressives };

      const reserveNextProgressive = (cdpar: string) => {
        const progressiveKey = `${cdpar}::image`;
        const used = usedProgressivesByCdpar.get(cdpar) ?? new Set<number>();
        let progressive = nextProgressives[progressiveKey] ?? 1;
        while (used.has(progressive)) progressive++;
        used.add(progressive);
        usedProgressivesByCdpar.set(cdpar, used);
        nextProgressives[progressiveKey] = progressive + 1;
        return progressive;
      };

      const plannedUploads = plannedBase.map(({ bf, cdpar, ext }) => {
        const existing = findExisting(cdpar, bf.file.name);
        const fromProg = parseImageProgressiveFromFilename(cdpar, bf.file.name);
        if (existing) {
          const progressive = fromProg ?? existing.progressive ?? 1;
          const storagePath = fromProg != null
            ? buildImagePath(cdpar, progressive, ext, bf.file.name)
            : existing.storage_path;
          const displacedStoragePathRow = fromProg != null
            ? existingByStoragePath.get(`${cdpar}::${storagePath}`)
            : undefined;
          const displacedProgressiveRow = fromProg != null
            ? existingByProgressive.get(`${cdpar}::${fromProg}`)
            : undefined;
          const displacedProgressiveId = displacedProgressiveRow?.id !== existing.id
            ? (displacedProgressiveRow?.id as string | undefined)
            : undefined;
          const displacedProgressiveTarget = displacedProgressiveId
            ? (existing.progressive ?? reserveNextProgressive(cdpar))
            : null;
          const displacedStoragePathId = displacedStoragePathRow?.id !== existing.id
            ? (displacedStoragePathRow?.id as string | undefined)
            : undefined;
          const displacedStoragePathTarget = displacedStoragePathId ? existing.storage_path : null;
          const displacedStoragePathTemp = displacedStoragePathId
            ? `${existing.storage_path}.swap-${Date.now()}-${getBulkFileKey(bf).replace(/[^a-z0-9]/gi, "-")}`
            : null;
          return { bf, cdpar, progressive, storagePath, existingId: existing.id as string, displacedProgressiveId, displacedProgressiveTarget, displacedStoragePathId, displacedStoragePathTarget, displacedStoragePathTemp };
        }
        const progressive = fromProg ?? reserveNextProgressive(cdpar);
        if (fromProg != null) {
          const used = usedProgressivesByCdpar.get(cdpar) ?? new Set<number>();
          used.add(fromProg);
          usedProgressivesByCdpar.set(cdpar, used);
        }

        return {
          bf,
          cdpar,
          progressive,
          storagePath: buildImagePath(cdpar, progressive, ext, bf.file.name),
          existingId: null as string | null,
          displacedProgressiveId: undefined,
          displacedProgressiveTarget: null,
          displacedStoragePathId: undefined,
          displacedStoragePathTarget: null,
          displacedStoragePathTemp: null,
        };
      });

      const overwriteExistingRow = async (rowId: string, bf: BulkFile, progressive: number, storagePath: string) => {
        const { error } = await supabase.from("article_media").update({
          storage_path: storagePath,
          public_url: buildPublicMediaUrl(storagePath),
          original_filename: bf.file.name,
          file_size: bf.file.size,
          is_primary: progressive === 1,
          progressive,
          sort_order: progressive,
        } as any).eq("id", rowId);
        return error;
      };

      const findFallbackExistingRow = async (cdpar: string, filename: string, storagePath: string, progressive: number) => {
        const candidates = getMediaCdparCandidates(cdpar);
        const byFilename = await supabase
          .from("article_media")
          .select("id")
          .in("cdpar", candidates)
          .eq("media_type", "image")
          .eq("original_filename", filename)
          .limit(1);
        if (byFilename.data?.[0]) return (byFilename.data[0] as any).id as string;

        const byStorage = await supabase
          .from("article_media")
          .select("id")
          .in("cdpar", candidates)
          .eq("media_type", "image")
          .eq("storage_path", storagePath)
          .limit(1);
        if (byStorage.data?.[0]) return (byStorage.data[0] as any).id as string;

        const byProgressive = await supabase
          .from("article_media")
          .select("id")
          .in("cdpar", candidates)
          .eq("media_type", "image")
          .eq("progressive", progressive)
          .limit(1);
        return (byProgressive.data?.[0] as any)?.id as string | undefined;
      };

      await runWithConcurrency(plannedUploads, MEDIA_BULK_UPLOAD_CONCURRENCY, async ({ bf, cdpar, progressive, storagePath, existingId, displacedProgressiveId, displacedProgressiveTarget, displacedStoragePathId, displacedStoragePathTarget, displacedStoragePathTemp }) => {
        const { error: uploadError } = await supabase.storage.from("pim-media").upload(storagePath, bf.file, { upsert: true });
        if (uploadError) {
          failed++;
          lastErrorMessage = uploadError.message;
          return;
        }

        let dbError: any = null;
        if (existingId) {
          if (displacedStoragePathId && displacedStoragePathTemp) {
            const { error } = await supabase.from("article_media").update({
              storage_path: displacedStoragePathTemp,
              public_url: buildPublicMediaUrl(displacedStoragePathTemp),
            } as any).eq("id", displacedStoragePathId);
            if (error) dbError = error;
          }
          if (displacedProgressiveId && displacedProgressiveTarget != null) {
            const { error } = await supabase.from("article_media").update({
              progressive: displacedProgressiveTarget,
              sort_order: displacedProgressiveTarget,
              is_primary: displacedProgressiveTarget === 1,
            } as any).eq("id", displacedProgressiveId);
            if (error) dbError = error;
          }
          if (!dbError) dbError = await overwriteExistingRow(existingId, bf, progressive, storagePath);
          if (!dbError && displacedStoragePathId && displacedStoragePathTarget) {
            const { error } = await supabase.from("article_media").update({
              storage_path: displacedStoragePathTarget,
              public_url: buildPublicMediaUrl(displacedStoragePathTarget),
            } as any).eq("id", displacedStoragePathId);
            if (error) dbError = error;
          }
        } else {
          const { error: insertError } = await supabase.from("article_media").insert({
            cdpar,
            media_type: "image",
            storage_path: storagePath,
            public_url: buildPublicMediaUrl(storagePath),
            original_filename: bf.file.name,
            file_size: bf.file.size,
            is_primary: progressive === 1,
            progressive,
            sort_order: progressive,
          } as any);

          if (insertError && insertError.message?.includes("duplicate key value violates unique constraint")) {
            const staleRowId = await findFallbackExistingRow(cdpar, bf.file.name, storagePath, progressive);
            dbError = staleRowId
              ? await overwriteExistingRow(staleRowId, bf, progressive, storagePath)
              : insertError;
          } else {
            dbError = insertError;
          }
        }


        if (dbError) {
          failed++;
          lastErrorMessage = dbError.message;
          return;
        }

        uploaded++;
        articlesUpdated.add(cdpar);
        successfulUploads.add(getBulkFileKey(bf));
        setUploadedCount((count) => count + 1);
      });


      let syncFailed = false;

      if (uploaded > 0) {
        try {
          setUploadStage("Aggiornamento libreria...");
          for (const cdpar of articlesUpdated) {
            await normalizeArticleImageOrdering(cdpar);
          }
          await invalidateMediaQueries();
        } catch (syncError: any) {
          lastErrorMessage = syncError.message ?? lastErrorMessage;
        }
      }

      setBulkFiles((prev) => prev.filter((bf) => !successfulUploads.has(getBulkFileKey(bf))));

      toast({
        title: `Upload completato: ${uploaded} immagini caricate, ${articlesUpdated.size} articoli aggiornati`,
        description: failed > 0 ? lastErrorMessage || `${failed} file non caricati` : undefined,
        variant: failed > 0 && uploaded === 0 ? "destructive" : undefined,
      });
    } catch (e: any) {
      toast({ title: "Errore upload", description: e.message, variant: "destructive" });
    } finally {
      setUploadStage("");
      setUploading(false);
    }
  };

  // Pagination helpers
  const getVisiblePages = () => {
    const pages: (number | "ellipsis")[] = [];
    if (totalPages <= 7) {
      for (let i = 0; i < totalPages; i++) pages.push(i);
    } else {
      pages.push(0);
      if (page > 2) pages.push("ellipsis");
      for (let i = Math.max(1, page - 1); i <= Math.min(totalPages - 2, page + 1); i++) pages.push(i);
      if (page < totalPages - 3) pages.push("ellipsis");
      pages.push(totalPages - 1);
    }
    return pages;
  };

  if (loadingArticles || loadingMedia) return <div className="p-6"><Skeleton className="h-64 w-full" /></div>;

  return (
    <div className="p-6 space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Media Library</h1>
        <Button variant="outline" size="sm" onClick={handleExportCsv} disabled={exportingCsv}>
          <Download className="h-4 w-4 mr-1" /> Esporta XLSX
        </Button>
      </div>

      {/* --- Article grid with filters --- */}
      <div className="space-y-4">
        <div className="flex gap-3 flex-wrap items-center">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input className="pl-8 w-full" placeholder="Cerca articolo..." value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          {(["all", "no_image", "no_datasheet", "no_safety"] as FilterMode[]).map((f) => (
            <Button key={f} variant={filter === f ? "default" : "outline"} size="sm" onClick={() => setFilter(f)}>
              {{ all: "Tutti", no_image: "Senza immagine", no_datasheet: "Senza scheda tecnica", no_safety: "Senza scheda sicurezza" }[f]}
            </Button>
          ))}
          <div className="h-6 w-px bg-border mx-1" />
          {(["all", "online", "offline"] as B2bFilter[]).map((f) => (
            <Button key={f} variant={b2bFilter === f ? "default" : "outline"} size="sm" onClick={() => setB2bFilter(f)}>
              {{ all: "B2B: Tutti", online: "🛒 Online B2B", offline: "⊘ Offline B2B" }[f]}
            </Button>
          ))}
        </div>

        <p className="text-sm text-muted-foreground">{totalCount} articoli — Pagina {page + 1} di {totalPages || 1}</p>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {articles.map((a: any) => {
            const m = mediaMap[a.cdpar];
            return (
              <div
                key={a.cdpar}
                className="border rounded-lg overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => navigate(`/pim/articles/${a.cdpar}?tab=media`)}
              >
                <div className="h-28 bg-muted flex items-center justify-center">
                  {m?.primary ? (
                    <img src={m.primary} alt={a.cdpar} className="w-full h-full object-contain" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                  ) : (
                    <Image className="h-8 w-8 text-muted-foreground/30" />
                  )}
                </div>
                <div className="p-2">
                  <p className="text-xs font-mono font-medium truncate">{a.cdpar}</p>
                  <p className="text-xs text-muted-foreground truncate">{a.depar}</p>
                  <div className="flex gap-1 mt-1">
                    {m?.types.has("image") && <Badge variant="outline" className="text-[9px] px-1">IMG</Badge>}
                    {m?.types.has("pdf_datasheet") && <Badge variant="outline" className="text-[9px] px-1">ST</Badge>}
                    {m?.types.has("pdf_safety") && <Badge variant="outline" className="text-[9px] px-1">SS</Badge>}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious
                  onClick={() => setPage((p) => Math.max(0, p - 1))}
                  className={page === 0 ? "pointer-events-none opacity-50" : "cursor-pointer"}
                />
              </PaginationItem>
              {getVisiblePages().map((p, i) =>
                p === "ellipsis" ? (
                  <PaginationItem key={`e${i}`}><PaginationEllipsis /></PaginationItem>
                ) : (
                  <PaginationItem key={p}>
                    <PaginationLink isActive={p === page} onClick={() => setPage(p)} className="cursor-pointer">
                      {p + 1}
                    </PaginationLink>
                  </PaginationItem>
                )
              )}
              <PaginationItem>
                <PaginationNext
                  onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                  className={page >= totalPages - 1 ? "pointer-events-none opacity-50" : "cursor-pointer"}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        )}
      </div>

      {/* --- Bulk Upload Section --- */}
      <div className="border-t pt-8 space-y-4">
        <h2 className="text-xl font-bold">Caricamento Massivo Immagini</h2>

        <FileDropZone
          accept="image/jpeg,image/png,image/webp"
          onFiles={handleBulkFiles}
          label="Trascina o seleziona immagini (JPG, PNG, WebP — anche carichi massivi)"
          className="p-8"
        />

        {bulkFiles.length > 0 && (
          <div className="space-y-4">
            <div className="flex gap-4 text-sm">
              <span className="flex items-center gap-1"><CheckCircle className="h-4 w-4 text-green-500" /> {bulkStatusCounts.green} pronti</span>
              <span className="flex items-center gap-1"><AlertTriangle className="h-4 w-4 text-yellow-500" /> {bulkStatusCounts.yellow} aggiungeranno</span>
              <span className="flex items-center gap-1"><XCircle className="h-4 w-4 text-red-500" /> {bulkStatusCounts.red} non abbinati</span>
            </div>

            {bulkFiles.length > BULK_PREVIEW_LIMIT && (
              <p className="text-xs text-muted-foreground">
                Mostro i primi {BULK_PREVIEW_LIMIT} file su {bulkFiles.length.toLocaleString("it-IT")} per non rallentare la pagina.
              </p>
            )}

            <div className="max-h-96 overflow-auto border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>File</TableHead>
                    <TableHead>Codice rilevato</TableHead>
                    <TableHead>Articolo</TableHead>
                    <TableHead>Stato</TableHead>
                    <TableHead>Azione</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {previewBulkFiles.map((bf, idx) => {
                    const status = getStatus(bf);
                    const effectiveCdpar = getEffectiveCdpar(bf);
                    return (
                      <TableRow key={idx} className={
                        status === "green" ? "bg-green-50 dark:bg-green-950/20" :
                        status === "yellow" ? "bg-yellow-50 dark:bg-yellow-950/20" :
                        "bg-red-50 dark:bg-red-950/20"
                      }>
                        <TableCell className="text-xs font-mono truncate max-w-[200px]">{bf.file.name}</TableCell>
                        <TableCell className="text-xs font-mono">
                          {effectiveCdpar || "—"}
                          {bf.confidence === "partial" && <Badge variant="outline" className="ml-1 text-[9px]">parziale</Badge>}
                        </TableCell>
                        <TableCell className="text-xs truncate max-w-[200px]">{bf.depar || "—"}</TableCell>
                        <TableCell>
                          {status === "green" && <CheckCircle className="h-4 w-4 text-green-500" />}
                          {status === "yellow" && <AlertTriangle className="h-4 w-4 text-yellow-500" />}
                          {status === "red" && <XCircle className="h-4 w-4 text-red-500" />}
                        </TableCell>
                        <TableCell>
                          {status === "red" && (
                            <CdparSearchInput
                              onSelect={(cdpar) => updateManualCdpar(idx, cdpar)}
                            />

                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>

            {uploading && (
              <div className="space-y-2">
                <Progress value={(uploadedCount / uploadableFiles.length) * 100} className="h-3" />
                <p className="text-sm text-muted-foreground">
                  {uploadStage || "Caricamento in corso..."} {uploadedCount} / {uploadableFiles.length}
                </p>
              </div>
            )}

            <div className="flex gap-3">
              <Button onClick={handleBulkUpload} disabled={uploading || uploadableFiles.length === 0}>
                <Upload className="mr-2 h-4 w-4" />
                Conferma e carica tutto ({uploadableFiles.length} file)
              </Button>
              <Button variant="outline" onClick={() => setBulkFiles([])}>Annulla</Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

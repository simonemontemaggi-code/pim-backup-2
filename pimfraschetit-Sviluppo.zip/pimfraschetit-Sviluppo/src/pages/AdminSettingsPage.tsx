import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useLookupValues } from "@/hooks/useLookupValues";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { Save, Eye, EyeOff, Check } from "lucide-react";
import { BypassUsersSection } from "@/components/admin/BypassUsersSection";
import { LegalDocumentsSettings } from "@/components/admin/LegalDocumentsSettings";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

export default function AdminSettingsPage() {
  const queryClient = useQueryClient();
  const { data: assortments = [] } = useLookupValues("wfuas");

  /* ── Assortimenti visibili ────────────────────────────────── */

  const { data: setting, isLoading } = useQuery({
    queryKey: ["app_settings", "visible_assortments"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings")
        .select("*")
        .eq("setting_key", "visible_assortments")
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const savedValues: string[] = setting?.setting_value
    ? (typeof setting.setting_value === "object" && Array.isArray(setting.setting_value)
        ? setting.setting_value as string[]
        : [])
    : [];
  const savedValuesKey = JSON.stringify([...savedValues].sort());

  const [selected, setSelected] = useState<string[]>([]);

  useEffect(() => {
    if (!isLoading) {
      setSelected([...savedValues]);
    }
  }, [isLoading, savedValuesKey]);

  const toggle = (code: string) => {
    setSelected((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]
    );
  };

  const selectAll = () => setSelected(assortments.map((a) => a.code));
  const deselectAll = () => setSelected([]);

  const isDirty = JSON.stringify([...selected].sort()) !== savedValuesKey;

  const mutation = useMutation({
    mutationFn: async (values: string[]) => {
      if (setting?.id) {
        const { error } = await supabase
          .from("app_settings")
          .update({ setting_value: values as any, updated_at: new Date().toISOString() })
          .eq("id", setting.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("app_settings")
          .insert({ setting_key: "visible_assortments", setting_value: values as any });
        if (error) throw error;
      }
    },
    onSuccess: (_data, values) => {
      const now = new Date().toISOString();
      queryClient.setQueryData(["app_settings", "visible_assortments"], (current: any) => (
        current
          ? { ...current, setting_value: [...values], updated_at: now }
          : {
              id: "visible_assortments",
              setting_key: "visible_assortments",
              setting_value: [...values],
              created_at: now,
              updated_at: now,
              updated_by: null,
            }
      ));
      toast({ title: "Salvato", description: "Assortimenti visibili aggiornati." });
      queryClient.invalidateQueries({ queryKey: ["app_settings", "visible_assortments"] });
      queryClient.invalidateQueries({ queryKey: ["articles"] });
    },
    onError: (e: Error) => {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    },
  });

  const articleCount = assortments.length;
  const selectedCount = selected.length;

  /* ── Listino principale ───────────────────────────────────── */

  const { data: priceLists = [], isLoading: isLoadingPL } = useQuery({
    queryKey: ["listini_vendita_testate"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("listini_vendita_testate")
        .select("cdlst, dslst")
        .order("cdlst", { ascending: true });
      if (error) throw error;
      return (data ?? []) as { cdlst: string; dslst: string | null }[];
    },
    staleTime: 600_000,
  });

  const { data: plSetting, isLoading: isLoadingPLSetting } = useQuery({
    queryKey: ["app_settings", "primary_price_list"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings")
        .select("*")
        .eq("setting_key", "primary_price_list")
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const savedPL: string = plSetting?.setting_value
    ? (typeof plSetting.setting_value === "string" ? plSetting.setting_value : "")
    : "";

  const [selectedPL, setSelectedPL] = useState<string>("");

  useEffect(() => {
    if (!isLoadingPLSetting) {
      setSelectedPL(savedPL);
    }
  }, [isLoadingPLSetting, savedPL]);

  const plDirty = selectedPL !== savedPL;

  const plMutation = useMutation({
    mutationFn: async (value: string) => {
      if (plSetting?.id) {
        const { error } = await supabase
          .from("app_settings")
          .update({ setting_value: value as any, updated_at: new Date().toISOString() })
          .eq("id", plSetting.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("app_settings")
          .insert({ setting_key: "primary_price_list", setting_value: value as any });
        if (error) throw error;
      }
    },
    onSuccess: (_data, value) => {
      const now = new Date().toISOString();
      queryClient.setQueryData(["app_settings", "primary_price_list"], (current: any) => (
        current
          ? { ...current, setting_value: value, updated_at: now }
          : {
              id: "primary_price_list",
              setting_key: "primary_price_list",
              setting_value: value,
              created_at: now,
              updated_at: now,
              updated_by: null,
            }
      ));
      toast({ title: "Salvato", description: "Listino principale aggiornato." });
      queryClient.invalidateQueries({ queryKey: ["app_settings", "primary_price_list"] });
    },
    onError: (e: Error) => {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    },
  });

  /* ── Assortimenti online B2B ──────────────────────────────── */

  const { data: onlineSetting, isLoading: isLoadingOnline } = useQuery({
    queryKey: ["app_settings", "online_assortments"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings")
        .select("*")
        .eq("setting_key", "online_assortments")
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const savedOnline: string[] = onlineSetting?.setting_value
    ? (Array.isArray(onlineSetting.setting_value) ? (onlineSetting.setting_value as string[]) : [])
    : [];
  const savedOnlineKey = JSON.stringify([...savedOnline].sort());
  const [selectedOnline, setSelectedOnline] = useState<string[]>([]);
  useEffect(() => {
    if (!isLoadingOnline) setSelectedOnline([...savedOnline]);
  }, [isLoadingOnline, savedOnlineKey]);
  const toggleOnline = (code: string) =>
    setSelectedOnline((prev) => (prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]));
  const onlineDirty = JSON.stringify([...selectedOnline].sort()) !== savedOnlineKey;

  const onlineMutation = useMutation({
    mutationFn: async (values: string[]) => {
      if (onlineSetting?.id) {
        const { error } = await supabase
          .from("app_settings")
          .update({ setting_value: values as any, updated_at: new Date().toISOString() })
          .eq("id", onlineSetting.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("app_settings")
          .insert({ setting_key: "online_assortments", setting_value: values as any });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast({ title: "Salvato", description: "Assortimenti online B2B aggiornati." });
      queryClient.invalidateQueries({ queryKey: ["app_settings", "online_assortments"] });
      queryClient.invalidateQueries({ queryKey: ["articles"] });
    },
    onError: (e: Error) => {
      toast({ title: "Errore", description: e.message, variant: "destructive" });
    },
  });

  /* ── Stato Portale B2B ────────────────────────────────────── */

  const { data: offlineSetting, isLoading: isLoadingOffline } = useQuery({
    queryKey: ["app_settings", "b2b_offline"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings").select("*")
        .eq("setting_key", "b2b_offline").maybeSingle();
      if (error) throw error;
      return data;
    },
  });
  const savedOffline = offlineSetting?.setting_value === true || offlineSetting?.setting_value === "true";

  const offlineMutation = useMutation({
    mutationFn: async (value: boolean) => {
      if (offlineSetting?.id) {
        const { error } = await supabase.from("app_settings")
          .update({ setting_value: value as any, updated_at: new Date().toISOString() })
          .eq("id", offlineSetting.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("app_settings")
          .insert({ setting_key: "b2b_offline", setting_value: value as any });
        if (error) throw error;
      }
    },
    onSuccess: (_d, value) => {
      toast({ title: "Salvato", description: value ? "B2B messo OFFLINE" : "B2B messo ONLINE" });
      queryClient.invalidateQueries({ queryKey: ["app_settings", "b2b_offline"] });
    },
    onError: (e: Error) => toast({ title: "Errore", description: e.message, variant: "destructive" }),
  });



  return (
    <div className="p-6 space-y-6 max-w-4xl">
      {/* Stato Portale B2B */}
      <section className="rounded-lg border bg-card shadow-sm">
        <div className="bg-muted/50 px-4 py-3 border-b rounded-t-lg">
          <h2 className="text-sm font-semibold text-foreground">Stato Portale B2B</h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Quando attivo, il portale B2B mostra una schermata di manutenzione "Work in Progress" a tutti gli utenti.
          </p>
        </div>
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Switch
              checked={savedOffline}
              disabled={isLoadingOffline || offlineMutation.isPending}
              onCheckedChange={(v) => offlineMutation.mutate(v)}
            />
            <Label className="text-sm">
              {savedOffline
                ? "🔴 B2B OFFLINE — manutenzione attiva"
                : "🟢 B2B ONLINE — portale accessibile"}
            </Label>
          </div>
          <Badge variant={savedOffline ? "destructive" : "secondary"} className="text-xs">
            {savedOffline ? "Offline" : "Online"}
          </Badge>
        </div>
      </section>

      {/* Utenti autorizzati ad accedere durante la manutenzione */}
      <BypassUsersSection />



      {/* Assortimenti visibili */}
      <section className="rounded-lg border bg-card shadow-sm">
        <div className="bg-muted/50 px-4 py-3 border-b rounded-t-lg flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold text-foreground">Assortimenti Visibili</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Solo gli articoli con assortimento selezionato verranno caricati nella lista articoli.
              {selectedCount > 0 && (
                <Badge variant="secondary" className="ml-2 text-xs">
                  {selectedCount}/{articleCount} attivi
                </Badge>
              )}
              {selectedCount === 0 && (
                <Badge variant="outline" className="ml-2 text-xs text-muted-foreground">
                  Tutti visibili (nessun filtro)
                </Badge>
              )}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="h-7 text-xs" onClick={selectAll}>
              <Eye className="h-3 w-3 mr-1" /> Tutti
            </Button>
            <Button variant="outline" size="sm" className="h-7 text-xs" onClick={deselectAll}>
              <EyeOff className="h-3 w-3 mr-1" /> Nessuno
            </Button>
          </div>
        </div>
        <div className="p-4">
          {isLoading ? (
            <p className="text-sm text-muted-foreground">Caricamento...</p>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {assortments.map((a) => {
                const isOn = selected.includes(a.code);
                return (
                  <div
                    key={a.code}
                    className={`flex items-center justify-between gap-3 rounded-md border p-3 transition-colors ${
                      isOn ? "border-primary/50 bg-primary/5" : "border-border"
                    }`}
                  >
                    <div className="flex flex-col">
                      <span className="text-sm font-medium font-mono">{a.code}</span>
                      {a.label && a.label !== a.code && (
                        <span className="text-xs text-muted-foreground">{a.label}</span>
                      )}
                    </div>
                    <Switch checked={isOn} onCheckedChange={() => toggle(a.code)} />
                  </div>
                );
              })}
            </div>
          )}
        </div>
        {isDirty && (
          <div className="px-4 pb-4">
            <Button size="sm" onClick={() => mutation.mutate(selected)} disabled={mutation.isPending}>
              <Save className="h-3.5 w-3.5 mr-1.5" />
              {mutation.isPending ? "Salvataggio..." : "Salva configurazione"}
            </Button>
          </div>
        )}
      </section>

      {/* Assortimenti online B2B */}
      <section className="rounded-lg border bg-card shadow-sm">
        <div className="bg-muted/50 px-4 py-3 border-b rounded-t-lg">
          <h2 className="text-sm font-semibold text-foreground">Assortimenti Online B2B</h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Codici assortimento (wfuas) che rendono un articolo automaticamente Online sul portale B2B.
            Il flag manuale sull'articolo (Forza online / Forza offline) ha precedenza su questa regola.
            {selectedOnline.length > 0 && (
              <Badge variant="secondary" className="ml-2 text-xs">{selectedOnline.length} attivi</Badge>
            )}
          </p>
        </div>
        <div className="p-4">
          {isLoadingOnline ? (
            <p className="text-sm text-muted-foreground">Caricamento...</p>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {assortments.map((a) => {
                const isOn = selectedOnline.includes(a.code);
                return (
                  <div
                    key={a.code}
                    className={`flex items-center justify-between gap-3 rounded-md border p-3 transition-colors ${
                      isOn ? "border-green-500/50 bg-green-50 dark:bg-green-900/10" : "border-border"
                    }`}
                  >
                    <div className="flex flex-col">
                      <span className="text-sm font-medium font-mono">{a.code}</span>
                      {a.label && a.label !== a.code && (
                        <span className="text-xs text-muted-foreground">{a.label}</span>
                      )}
                    </div>
                    <Switch checked={isOn} onCheckedChange={() => toggleOnline(a.code)} />
                  </div>
                );
              })}
            </div>
          )}
        </div>
        {onlineDirty && (
          <div className="px-4 pb-4">
            <Button size="sm" onClick={() => onlineMutation.mutate(selectedOnline)} disabled={onlineMutation.isPending}>
              <Save className="h-3.5 w-3.5 mr-1.5" />
              {onlineMutation.isPending ? "Salvataggio..." : "Salva assortimenti online"}
            </Button>
          </div>
        )}
      </section>

      {/* Listino Principale */}
      <section className="rounded-lg border bg-card shadow-sm">
        <div className="bg-muted/50 px-4 py-3 border-b rounded-t-lg">
          <h2 className="text-sm font-semibold text-foreground">Listino Principale</h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Seleziona il listino di riferimento con cui lavorare. Verrà utilizzato come listino predefinito nella gestione articoli.
          </p>
        </div>
        <div className="p-4">
          {isLoadingPL || isLoadingPLSetting ? (
            <p className="text-sm text-muted-foreground">Caricamento...</p>
          ) : (
            <div className="flex items-end gap-4">
              <div className="space-y-1 flex-1 max-w-xs">
                <Label className="text-xs">Codice Listino</Label>
                <Select value={selectedPL} onValueChange={setSelectedPL}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Seleziona listino..." />
                  </SelectTrigger>
                  <SelectContent>
                    {priceLists.map((pl) => (
                      <SelectItem key={pl.cdlst} value={pl.cdlst}>
                        {pl.cdlst} — {(pl.dslst ?? "").trim()}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {savedPL && (
                <Badge variant="secondary" className="h-9 flex items-center gap-1 text-xs">
                  <Check className="h-3 w-3" /> Attuale: {savedPL}
                </Badge>
              )}
            </div>
          )}
        </div>
        {plDirty && (
          <div className="px-4 pb-4">
            <Button size="sm" onClick={() => plMutation.mutate(selectedPL)} disabled={plMutation.isPending}>
              <Save className="h-3.5 w-3.5 mr-1.5" />
              {plMutation.isPending ? "Salvataggio..." : "Salva listino"}
            </Button>
          </div>
        )}
      </section>

      {/* Documenti Legali B2B */}
      <LegalDocumentsSettings />

    </div>
  );
}

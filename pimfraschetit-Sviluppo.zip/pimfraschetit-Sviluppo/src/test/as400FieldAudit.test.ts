import { describe, it, expect } from "vitest";
import { execFileSync } from "node:child_process";

/**
 * Guardia anti-regressione: nessun campo AS400 editabile nel PIM può restare
 * fuori da src/lib/fieldDefinitions.ts (matrice permessi Admin).
 * Se questo test fallisce, aggiungi il campo mancante alla sezione giusta.
 */
describe("audit AS400 ↔ fieldDefinitions", () => {
  it("non ci sono campi editabili mancanti nella matrice permessi", () => {
    const out = execFileSync("node", ["scripts/as400-audit.mjs", "--json"], {
      encoding: "utf8",
      cwd: process.cwd(),
    });
    const report = JSON.parse(out);
    expect(report.missingInPermissions, JSON.stringify(report.missingInPermissions, null, 2)).toEqual([]);
  });
});

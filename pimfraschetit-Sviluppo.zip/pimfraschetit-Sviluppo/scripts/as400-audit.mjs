#!/usr/bin/env node
/**
 * Audit meccanico AS400 <-> PIM.
 *
 * Confronta tre fonti:
 *  1. i campi AS400 dichiarati nei parser di import (src/lib/query##Parser.ts)
 *  2. i campi realmente referenziati nei form/tab del PIM (src/components, src/pages)
 *  3. i campi registrati in src/lib/fieldDefinitions.ts (matrice permessi)
 *
 * Output: elenco dei campi editabili nel PIM che NON sono in fieldDefinitions
 * e dei campi AS400 mai toccati dal PIM. Nessuna modifica ai file.
 *
 * Uso: node scripts/as400-audit.mjs [--json]
 */
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, extname } from "node:path";

const ROOT = process.cwd();
const SRC = join(ROOT, "src");

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    const st = statSync(p);
    if (st.isDirectory()) walk(p, out);
    else if ([".ts", ".tsx"].includes(extname(p))) out.push(p);
  }
  return out;
}

const allFiles = walk(SRC);

// ---------- 1. campi AS400 dai parser ----------
const parserFiles = allFiles.filter((f) => /query\d+Parser\.ts$/.test(f));
/** @type {Map<string, Set<string>>} parserName -> fields */
const as400Fields = new Map();
for (const f of parserFiles) {
  const src = readFileSync(f, "utf8");
  const iface = src.match(/export interface Q\d+Row \{([\s\S]*?)\n\}/);
  if (!iface) continue;
  const fields = new Set();
  for (const m of iface[1].matchAll(/([a-z_][a-z0-9_]*)\s*(\??)\s*:/gi)) {
    fields.add(m[1]);
  }
  as400Fields.set(f.replace(ROOT + "/", ""), fields);
}
const as400All = new Set([...as400Fields.values()].flatMap((s) => [...s]));

// ---------- 2. campi registrati nella matrice permessi ----------
const fdSrc = readFileSync(join(SRC, "lib/fieldDefinitions.ts"), "utf8");
const registered = new Set(
  [...fdSrc.matchAll(/\{\s*key:\s*"([^"]+)"\s*,\s*label:/g)].map((m) => m[1]),
);

// ---------- 3. campi referenziati nei form del PIM ----------
const formGlobs = [
  "src/components/articles/",
  "src/components/promo/",
  "src/components/suppliers/",
  "src/pages/",
];
const uiFiles = allFiles.filter((f) =>
  formGlobs.some((g) => f.replace(ROOT + "/", "").startsWith(g)),
);

/** @type {Map<string, Set<string>>} field -> files */
const usedInForms = new Map();
for (const f of uiFiles) {
  const src = readFileSync(f, "utf8");
  const rel = f.replace(ROOT + "/", "");
  // pattern che indicano un binding editabile su un campo
  const patterns = [
    // array di definizione campi: { name: "wimba", label: "Imballo" }
    /\bname:\s*["']([a-z0-9_]+)["']\s*,\s*label:/g,
    /\bkey:\s*["']([a-z0-9_]+)["']\s*,\s*label:/g,
    /\bfield:\s*["']([a-z0-9_]+)["']/g,
    // react-hook-form / stato controllato
    /\b(?:register|setValue|watch|getValues)\(\s*["']([a-z0-9_]+)["']/g,
    /(?:setField|setForm|patch|onFieldChange)\(\s*["']([a-z0-9_]+)["']/g,
    // attributi JSX
    /\bfieldKey=\{?["']([a-z0-9_]+)["']\}?/g,
    /\bname=["']([a-z0-9_]+)["']/g,
    // accesso diretto allo stato del form
    /\b(?:form|values|draft|payload)\.([a-z][a-z0-9_]{2,})\b/g,
    /\b(?:form|values|draft|payload)\[["']([a-z0-9_]+)["']\]/g,
  ];

  for (const re of patterns) {
    for (const m of src.matchAll(re)) {
      const key = m[1];
      if (!as400All.has(key)) continue; // ci interessano solo i campi AS400
      if (!usedInForms.has(key)) usedInForms.set(key, new Set());
      usedInForms.get(key).add(rel);
    }
  }
}

// ---------- falsi positivi noti (non editabili: solo colonne di export/lettura) ----------
const IGNORED = new Set([
  "nmcat", // solo colonna selezionabile in ExportModal, non editabile
]);

// ---------- report ----------
const missingInPermissions = [...usedInForms.keys()]
  .filter((k) => !registered.has(k) && !IGNORED.has(k))
  .sort();

const registeredNotAs400 = [...registered]
  .filter((k) => !as400All.has(k) && !k.startsWith("_"))
  .sort();

const as400NeverTouched = [...as400All]
  .filter((k) => !usedInForms.has(k) && !registered.has(k))
  .sort();

const report = {
  parsers: parserFiles.length,
  as400FieldsTotal: as400All.size,
  registeredTotal: registered.size,
  usedInForms: usedInForms.size,
  missingInPermissions: missingInPermissions.map((k) => ({
    field: k,
    files: [...usedInForms.get(k)],
  })),
  registeredNotAs400,
  as400NeverTouched,
};

if (process.argv.includes("--json")) {
  console.log(JSON.stringify(report, null, 2));
  process.exit(0);
}

console.log(`Parser AS400 analizzati : ${report.parsers}`);
console.log(`Campi AS400 totali      : ${report.as400FieldsTotal}`);
console.log(`Campi in fieldDefinitions: ${report.registeredTotal}`);
console.log(`Campi AS400 usati nei form: ${report.usedInForms}`);
console.log("");
console.log(`### ⚠️  Editabili nel PIM ma NON in fieldDefinitions (${missingInPermissions.length})`);
for (const { field, files } of report.missingInPermissions) {
  console.log(`  - ${field}  →  ${files.join(", ")}`);
}
console.log("");
console.log(`### ℹ️  In fieldDefinitions ma non presenti in nessun parser AS400 (${registeredNotAs400.length})`);
console.log(registeredNotAs400.length ? "  " + registeredNotAs400.join(", ") : "  —");
console.log("");
console.log(`### Campi AS400 mai toccati dal PIM (${as400NeverTouched.length}) — read-only`);
console.log(as400NeverTouched.length ? "  " + as400NeverTouched.join(", ") : "  —");

if (missingInPermissions.length > 0) process.exitCode = 1;

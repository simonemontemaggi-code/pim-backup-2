---
name: migrations-safety
description: Regole per scrivere migration SQL Supabase nel PIM Fraschetti senza rompere schemi riservati, trigger esistenti, RLS o causare ricorsione. Usare prima di chiamare supabase--migration.
---

# Migrations Safety — Fraschetti PIM

## ❌ Vietato assolutamente

- `ALTER DATABASE postgres ...` — non permesso in Lovable
- Modifiche agli schemi: `auth`, `storage`, `realtime`, `supabase_functions`, `vault`, `extensions`
- `DROP TABLE` su tabelle con dati senza esplicito consenso utente (specie `archivio_articoli_fraschetti` da 57K righe, `customers`, `promo_strutturate_*`, `b2b_communications`)
- Foreign key verso `auth.users` (usa `user_id uuid` senza FK e referenzia via `profiles`)
- `CHECK` constraint con funzioni non immutabili (es. `now()`, `current_date`) → usa trigger di validazione
- Modificare RLS senza leggere prima le policy attive (vedi skill `rls-and-security-guard`)

## ✅ Pattern obbligatori

### Nuova tabella
```sql
CREATE TABLE public.x (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ...
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.x ENABLE ROW LEVEL SECURITY;
-- + almeno una policy esplicita
CREATE TRIGGER trg_x_updated_at BEFORE UPDATE ON public.x
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
```

### Funzioni
- SEMPRE `SET search_path = public` (security)
- SEMPRE specifica `LANGUAGE plpgsql|sql`
- `SECURITY DEFINER` solo se serve bypass RLS e dichiaralo all'utente
- Marker volatility: `STABLE` per pure read, `IMMUTABLE` se input→output deterministico

### Idempotenza
- `CREATE TABLE IF NOT EXISTS`, `CREATE INDEX IF NOT EXISTS`, `DROP POLICY IF EXISTS` prima di ricrearla
- Usa `DO $$ BEGIN ... EXCEPTION WHEN duplicate_object THEN null; END $$;` per enum add

### RPC differenziale (pattern Fraschetti per import AS400)
Vedi skill `as400-query-importer`. Restituisci sempre `{ total, updated, inserted, unchanged }`.

## Trigger di sistema da preservare

| Trigger | Tabella | Funzione |
|---|---|---|
| `fn_pad_promo_dest_articoli` | `promo_strutturate_destinatari_articoli` | pad-6 cdpar |
| `fn_customers_pim_track` | `customers` | aggiorna `pim_updated_at/by` su edit campi PIM |
| `update_*_updated_at` | molte | timestamp |

Se modifichi una tabella che ha questi trigger: **non droppare il trigger**, verifica che sopravviva.

## Checklist pre-migrazione

1. ⬜ Ho letto le RLS esistenti della tabella?
2. ⬜ Ho usato `IF NOT EXISTS` / `IF EXISTS` per idempotenza?
3. ⬜ Le nuove tabelle hanno RLS abilitata + almeno 1 policy?
4. ⬜ Le funzioni hanno `SET search_path = public`?
5. ⬜ Nessuna FK verso `auth.users`?
6. ⬜ Nessun CHECK con funzione volatile?
7. ⬜ Trigger esistenti preservati?
8. ⬜ Ho avvisato l'utente dell'impatto (chi/cosa)?
9. ⬜ Dopo la migration eseguirò `supabase--linter` per fix warning?

## Naming

- Tabelle: `snake_case` plurale, prefisso dominio se utile (`promo_strutturate_*`, `b2b_*`)
- Policy: descrittiva: `"admin_manage_x"`, `"public_read_active_x"`
- Index: `idx_<table>_<cols>`
- Trigger: `trg_<table>_<purpose>` o `fn_<purpose>` per funzione

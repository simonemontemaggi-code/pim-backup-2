---
name: as400-query-importer
description: Pattern unificato per importare estrazioni AS400 nel PIM Fraschetti (Query 01-17 e successive). Definisce parser XLSX 1-indexed strict, RPC differenziale upsert, hook React e Query##Panel UI. Da usare ogni volta che l'utente porta una nuova SELECT AS400 da mappare.
---

# AS400 Query Importer — Pattern unificato

Le query 01-17 seguono tutte lo stesso schema. Quando arriva una **nuova** estrazione AS400 (SELECT + file XLSX), replica esattamente questo pattern. Risparmia tempo, evita inconsistenze, garantisce zero rotture.

## Input atteso dall'utente

1. La query SQL AS400 (lista colonne ordinata: `a.col1, a.col2, ...`)
2. File XLSX di esempio (mappato 1:1 nell'ordine della SELECT)
3. Nome tabella Supabase target (es. `differenziale_cambio`)

## Step 1 — Verifica schema tabella

```sql
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_schema='public' AND table_name='<tabella>'
ORDER BY ordinal_position;
```
Se mancano colonne → migrazione di add column (vedi skill `migrations-safety`).

## Step 2 — Parser `src/lib/query##Parser.ts`

```ts
import * as XLSX from "xlsx";

export interface Q##Row {
  col1: string;
  col2: number;
  // … 1 campo per ogni colonna AS400, stesso ordine
}

export interface Q##ParseResult {
  headers: string[];
  rows: Q##Row[];
  warnings: string[];
}

const EXPECTED_COLS = ["col1","col2", /* … */];

export async function parseQuery##Xlsx(file: File): Promise<Q##ParseResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rowsRaw = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, defval: "" });
  if (!rowsRaw.length) return { headers: [], rows: [], warnings: ["File vuoto"] };

  const headers = rowsRaw[0].map(String);
  const warnings: string[] = [];
  if (headers.length < EXPECTED_COLS.length) {
    warnings.push(`Header count ${headers.length} < expected ${EXPECTED_COLS.length}`);
  }

  // 1-indexed mapping STRICT: posizione 0 = col1, posizione 1 = col2, …
  const seen = new Set<string>();
  const rows: Q##Row[] = [];
  for (let i = 1; i < rowsRaw.length; i++) {
    const r = rowsRaw[i];
    if (!r || r.every(v => v === "" || v == null)) continue;
    const row: Q##Row = {
      col1: String(r[0] ?? "").trim(),
      col2: parseFloat(String(r[1] ?? "0").replace(",", ".")) || 0,
      // …
    };
    // dedup su natural key (es. col1)
    const key = row.col1;
    if (!key || seen.has(key)) continue;
    seen.add(key);
    rows.push(row);
  }
  return { headers, rows, warnings };
}
```

**Regole parser**:
- `trim()` su tutte le stringhe
- `parseFloat()` su numeri, gestendo virgola decimale
- Date AS400 (YYYYMMDD numerico) → mantieni numero, conversione lato UI
- Dedup sul natural key (PK logica AS400)
- Mai inferire colonne da nome header — sempre posizione 1-indexed

## Step 3 — RPC differenziale (migrazione)

```sql
CREATE OR REPLACE FUNCTION public.import_query##_<dominio>(p_rows jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  r jsonb; total int := 0; inserted int := 0; updated int := 0; unchanged int := 0;
  existing record;
BEGIN
  FOR r IN SELECT * FROM jsonb_array_elements(p_rows) LOOP
    total := total + 1;
    SELECT * INTO existing FROM public.<tabella> WHERE <natural_key> = r->>'<key>';
    IF NOT FOUND THEN
      INSERT INTO public.<tabella>(col1, col2, …) VALUES (r->>'col1', (r->>'col2')::numeric, …);
      inserted := inserted + 1;
    ELSIF (existing.col2 IS DISTINCT FROM (r->>'col2')::numeric
           OR existing.col3 IS DISTINCT FROM r->>'col3'
           /* … tutti i non-key */) THEN
      UPDATE public.<tabella> SET col2 = (r->>'col2')::numeric, …, updated_at = now()
        WHERE <natural_key> = r->>'<key>';
      updated := updated + 1;
    ELSE
      unchanged := unchanged + 1;
    END IF;
  END LOOP;
  RETURN jsonb_build_object('total', total, 'inserted', inserted, 'updated', updated, 'unchanged', unchanged);
END $$;
```

**Regole RPC**:
- `SECURITY DEFINER` + `SET search_path = public`
- Natural key = PK logica AS400
- Confronto `IS DISTINCT FROM` su TUTTI i non-key (NULL-safe)
- Restituisce sempre `{ total, inserted, updated, unchanged }`
- Aggiorna `updated_at` se la riga cambia

## Step 4 — Hook `src/hooks/useQuery##Import.ts`

Copia struttura da `useQuery08Import.ts`:
- `CHUNK_SIZE = 1000`
- Loop chunk, chiama `supabase.rpc("import_query##_<dominio>", { p_rows: chunk })`
- Aggrega stats, aggiorna `progress` percentuale
- Ritorna `{ run, reset, isRunning, progress, stats, error }`

## Step 5 — Panel `src/components/import/temp/Query##Panel.tsx`

- Drop file XLSX
- Mostra colonne attese (`COLS` array)
- Mostra preview prime 5 righe
- Bottone "Importa" → chiama `run(rows)`
- Mostra stats finali: total/inserted/updated/unchanged
- Mostra warning del parser

## Step 6 — Registra in `TempImportPanel.tsx`

Aggiungi entry all'array `QUERIES`:
```ts
{ id: "query##", label: "Query ## — <Dominio>", table: "<tabella>", panel: Query##Panel }
```

## Step 7 — Test rapido

1. Carica XLSX di esempio
2. Verifica preview headers
3. Esegui import
4. Conferma stats coerenti (es. seconda esecuzione → tutti `unchanged`)

## ❌ Anti-pattern

- ❌ Mapping per nome header (gli header AS400 cambiano case/spazi)
- ❌ UPSERT senza diff (sporca `updated_at` inutilmente, perde traccia veri cambi)
- ❌ Importare senza dedup natural key (PK violation)
- ❌ Edge function per import bulk (usa RPC: stream più veloce, no timeout 25s)
- ❌ Saltare la registrazione in `TempImportPanel` (utente non la vede)

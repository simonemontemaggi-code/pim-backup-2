---
name: no-hardcoded-content
description: Guardrail per evitare stringhe UI, codici di business, colori, IVA, codici fornitore, magic numbers e ID hardcoded nel codice del PIM Fraschetti. Si applica a ogni edit di componenti React, hook, parser o edge function.
---

# No Hardcoded Content — Guardrail

Prima di **scrivere o modificare** componenti/hook/edge functions, esegui questo check.

## ❌ Vietato

| Tipo | Esempio sbagliato | Cosa fare invece |
|---|---|---|
| Colori inline | `text-white`, `bg-black`, `#2563eb`, `style={{color:'red'}}` | Token semantici: `text-foreground`, `bg-primary`, `border-border`. Vedi skill `design-tokens-guard`. |
| Stringhe di business | `if (role === "admin")` sparso | `usePermissions().can(...)`, `has_role()` SQL |
| Codici AS400 | `"§DC"`, `"WANFOW0F"`, codici fornitore literal | Costanti in `src/lib/config.ts` o tabella DB |
| IVA / aliquote / soglie | `price * 1.22`, `if (qty > 100)` | Lookup categories o tabella parametri |
| UUID / IDs | `department_id = "abc-123"` | Fetch da DB tramite hook esistenti |
| Email / URL produzione | `"info@fraschetti.com"`, URL hardcoded | `.env` / `import.meta.env.VITE_*` |
| Path Supabase | `https://xxx.supabase.co/...` | `supabase.functions.invoke()` o `VITE_SUPABASE_PROJECT_ID` |
| Testi UI ripetuti | "Salva", "Annulla", "Errore" copiati ovunque | OK se isolati, MA usa costanti in componenti riutilizzati |

## ✅ Permesso

- Label UI specifiche di una sola pagina (italiano fisso, no i18n nel progetto)
- Costanti di sistema documentate in `fields.ts` (es. `TESTATA_FORCED_VALUES`)
- Enum/literal type usati come tag (`"sconto_base" | "bundle"`)

## Procedura prima di un commit

1. **Cerca pattern sospetti** nei file che stai per toccare:
   ```bash
   rg -n "(text-white|bg-black|bg-white|text-black|#[0-9a-fA-F]{3,6})" <file>
   rg -n "'§|§[A-Z]{2,}'" <file>          # codici AS400 hardcoded
   rg -n "role\s*===?\s*['\"]admin['\"]" <file>  # role check manuale
   ```
2. **Se trovi**, sostituisci PRIMA di aggiungere logica nuova.
3. **Avvisa l'utente** se rilevi hardcoded preesistenti che non puoi rimuovere senza scope creep:
   > ⚠️ Trovato `<pattern>` in `<file>:<line>`. Non lo tocco perché fuori scope, ma andrebbe estratto.

## Eccezioni dichiarate

- `TESTATA_FORCED_VALUES` in `src/components/promo/fields.ts` (valori di sistema AS400).
- Codici colore semantic-only definiti UNA volta in `index.css` come HSL var.
- Codici dipartimento documentati in `mem://features/db-schema`.

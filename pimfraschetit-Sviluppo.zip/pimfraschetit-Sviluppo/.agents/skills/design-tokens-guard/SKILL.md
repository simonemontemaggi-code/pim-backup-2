---
name: design-tokens-guard
description: Garantisce che tutti i colori, font, shadow e radius del PIM Fraschetti usino i token semantici HSL definiti in src/index.css e tailwind.config.ts. Si attiva su ogni modifica UI/CSS/Tailwind classes.
---

# Design Tokens Guard — Fraschetti PIM

Il progetto ha un **design system con token HSL semantici**. Mai colori diretti.

## Token disponibili (HSL in `src/index.css`)

| Token | Uso |
|---|---|
| `--background` / `--foreground` | sfondo/testo base |
| `--card` / `--card-foreground` | superfici card |
| `--primary` / `--primary-foreground` | brand verde scuro (149 50% 22%) |
| `--secondary` / `--accent` | accenti |
| `--muted` / `--muted-foreground` | sfondi/testi neutri |
| `--destructive` | rosso errori |
| `--success` / `--warning` | feedback |
| `--border` / `--input` / `--ring` | bordi e focus |
| `--sidebar-*` | sidebar (verde scurissimo 149 50% 14%) |
| `--shadow-soft/card/elevated` | ombre |
| `--radius` | 0.75rem |
| `--font-display` / `--font-body` | Montserrat |

## Regole d'uso

### ✅ SEMPRE
```tsx
<div className="bg-card text-foreground border-border">
<Button className="bg-primary text-primary-foreground hover:bg-primary/90">
<span className="text-muted-foreground">
```

### ❌ MAI
```tsx
<div className="bg-white text-black border-gray-200">      // NO
<div style={{ background: '#2563eb' }}>                     // NO
<Button className="bg-blue-600 text-white">                 // NO
<span className="text-gray-500">                            // NO
```

### Aggiungere un nuovo colore

1. Definirlo SOLO in `src/index.css` come HSL `:root { --mio-token: 200 50% 40%; }`
2. Aggiungerlo a `tailwind.config.ts` → `theme.extend.colors.mioToken = "hsl(var(--mio-token))"`
3. Usarlo come `bg-mioToken` / `text-mioToken`

Mai colori solo nel componente.

## Check rapido prima di scrivere JSX

```bash
rg -n "(text|bg|border|fill|stroke|from|to|via)-(white|black|gray|slate|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose)-[0-9]+" <file>
rg -n "(#[0-9a-fA-F]{3,8}|rgb\(|rgba\()" <file>
```
Se trova match in file che modifichi, **rifiutali e usa token**.

## Font

- Solo `font-display` e `font-body` (entrambi Montserrat).
- Mai `font-sans` di Tailwind default, mai import Google Fonts inline nei componenti.

## Dark mode

Tutti i token hanno controparte in `.dark { ... }` in `index.css`. Quindi usare i token = dark-mode-safe automaticamente.

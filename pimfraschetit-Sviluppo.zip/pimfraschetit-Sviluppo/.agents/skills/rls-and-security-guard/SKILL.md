---
name: rls-and-security-guard
description: Checklist obbligatoria prima di modificare RLS policies, ruoli utente o accessi a tabelle sensibili (profiles, user_roles, customers, archivio_articoli_fraschetti, b2b_communications, promo_strutturate_*). Previene ricorsione, privilege escalation e bypass.
---

# RLS & Security Guard — Fraschetti PIM

## Modello ruoli (NON modificare senza grande motivo)

- Enum: `app_role` = `admin | manager | collaborator | viewer`
- Ruoli stored in tabella **`user_roles`** (mai su `profiles` o `users` → privilege escalation).
- Funzione canonica: **`public.has_role(_user_id uuid, _role app_role) returns boolean`** — `SECURITY DEFINER`, `STABLE`, `SET search_path = public`.
- Lato client: `usePermissions().can(action, sectionKey)` + `canField()`.

## ❌ Mai fare

1. **Mai** memorizzare il ruolo in `localStorage` / `sessionStorage` / cookie non firmati.
2. **Mai** check ruolo via subquery sulla stessa tabella → ricorsione RLS infinita.
3. **Mai** policy `USING (true)` su tabelle con dati sensibili.
4. **Mai** drop / alter sulle policy esistenti senza spiegare all'utente cosa rompe.
5. **Mai** toccare schemi `auth`, `storage`, `realtime`, `supabase_functions`, `vault`.
6. **Mai** esporre `service_role_key` al frontend.

## ✅ Pattern corretto policy

```sql
CREATE POLICY "admin_manage_x" ON public.x
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));
```

Per ricorsione: SEMPRE via security definer function, MAI subquery sulla tabella stessa.

## Tabelle critiche con RLS attiva (NON disabilitare!)

| Tabella | Chi può fare cosa |
|---|---|
| `profiles` | utente legge/edita il proprio; admin tutti |
| `user_roles` | admin only write; read self |
| `departments`, `user_departments` | admin only write |
| `section_permissions`, `field_permissions` | admin only |
| `customers` | read admin/manager/collaborator/viewer; write admin/manager/collaborator (anagrafica AS400 read-only, solo campi PIM-only editabili — vedi skill `customers-as400-vs-pim` quando disponibile) |
| `archivio_articoli_fraschetti` | 57K righe, write controllato via section permissions |
| `b2b_communications`, `b2b_communication_reads` | SELECT pubblico anon su attive, INSERT pubblico su reads (B2B esterno), write admin/manager/collaborator |
| `promo_strutturate_*` (8+ tabelle) | write via promo section + collaboratori |
| Bucket storage `promo-media` (pubblico), `b2b-communications` (pubblico) | upload solo authenticated |

## Procedura prima di toccare RLS

1. Leggi le policy esistenti della tabella: `SELECT * FROM pg_policies WHERE tablename = '...';`
2. **Dichiara all'utente** quali policy stai aggiungendo/modificando e l'impatto.
3. Per tabelle nuove: SEMPRE `ENABLE ROW LEVEL SECURITY` + almeno 1 policy SELECT esplicita.
4. Mai CHECK constraint per validazioni temporali (`expire > now()`): usa trigger.
5. Dopo migrazione, esegui `supabase--linter` e fixa i nuovi warning.

## Trigger di sistema da preservare

- `fn_pad_promo_dest_articoli` — pad-6 codici articoli destinatari promo
- `fn_customers_pim_track` — auto-aggiorna `pim_updated_at/by` su edit campi PIM
- `update_updated_at_column` — timestamp generici
- Trigger validation su campi PIM customers (non sovrascrive da import AS400)

Se vai a modificare la stessa tabella, **verifica che il trigger sia ancora attivo** e annunzialo.

## Warning all'utente

Se stai per fare una migration che tocca questi temi, **prima di chiamare il tool**:

> ⚠️ Sto per modificare RLS/trigger su `<tabella>`. Impatto previsto: `<chi viene affetto>`. Procedo?

---
name: edge-functions-guard
description: Contratti e regole per le 8 edge functions Supabase del PIM Fraschetti (admin-set-user-password, admin-update-user-email, ai-generate-content, attiva-prezzi-giornalieri, cleanup-broken-p-media, fetch-currency-rates, sync-as400-retry, sync-supplier-differential). Usa prima di creare o modificare qualsiasi edge function.
---

# Edge Functions Guard — Fraschetti PIM

## Edge functions esistenti (NON rinominare/eliminare senza chiedere)

| Function | Scopo | verify_jwt | Note critiche |
|---|---|---|---|
| `admin-set-user-password` | Admin imposta password utente | default (true) | Richiede `has_role(uid, 'admin')` |
| `admin-update-user-email` | Admin cambia email utente | default | idem |
| `ai-generate-content` | Genera contenuti via Lovable AI Gateway | default | Usa `LOVABLE_API_KEY`, modello `google/gemini-2.5-flash` di default |
| `attiva-prezzi-giornalieri` | Cron: attiva prezzi pianificati | default | Schedulata, non chiamarla manualmente senza motivo |
| `cleanup-broken-p-media` | Pulizia file orfani bucket promo-media | `verify_jwt = false` (in `supabase/config.toml`) | Job manutenzione |
| `fetch-currency-rates` | Importa tassi cambio | default | Usa API esterna |
| `sync-as400-retry` | Retry coda sync AS400 fallita | default | Vedi `SyncQueuePage` |
| `sync-supplier-differential` | Invia delta fornitore ad AS400 via SFTP relay | default | Usa `SFTP_RELAY_URL` + `SFTP_RELAY_API_KEY`. Operation: `delete` se `wan02='A'`, altrimenti `upsert`. |

In `supabase/config.toml`: SOLO `sync-media-storage` e `cleanup-broken-p-media` hanno `verify_jwt = false`. **Non aggiungere altre eccezioni senza motivo.**

## Regole assolute per nuove edge functions

### 1. File structure
- `supabase/functions/<name>/index.ts` — UNICO file
- Niente sottocartelle, niente import da `src/`

### 2. CORS — copia esatta
```ts
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
// Includi corsHeaders in TUTTE le response, anche errori.
```

### 3. Auth in-code (verify_jwt default è true ma valida sempre)
```ts
const authHeader = req.headers.get("Authorization");
if (!authHeader?.startsWith("Bearer ")) return new Response(JSON.stringify({error:"Unauthorized"}), {status:401, headers:{...corsHeaders,"Content-Type":"application/json"}});
const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: authHeader } } });
const { data: claims, error } = await supabase.auth.getClaims(authHeader.replace("Bearer ",""));
if (error || !claims?.claims) return new Response(JSON.stringify({error:"Unauthorized"}), {status:401, headers:...});
```

### 4. Input validation (Zod)
```ts
import { z } from "npm:zod";
const Schema = z.object({ ... });
const parsed = Schema.safeParse(await req.json());
if (!parsed.success) return new Response(JSON.stringify({error: parsed.error.flatten().fieldErrors}), {status:400, headers:...});
```

### 5. Secrets
- **Sempre** `Deno.env.get('NOME_SECRET')`.
- Prima di scrivere la function: chiedi all'utente di aggiungere i secret mancanti via il tool `secrets--add_secret`, attendi conferma.
- `SUPABASE_SERVICE_ROLE_KEY` disponibile in env, **mai esporlo via response**.

### 6. ❌ Mai
- `supabase.rpc("execute_sql", { sql: userInput })` o SQL raw da input utente.
- Chiamate via path `/api/<name>` dal frontend — usa `supabase.functions.invoke('<name>', { body })`.
- Salvare segreti/API keys in tabelle DB.
- Restituire `service_role_key` o stack trace dettagliati al client.

### 7. Chiamata dal frontend
```ts
import { supabase } from "@/integrations/supabase/client";
const { data, error } = await supabase.functions.invoke("nome-funzione", { body: {...} });
```

## Debug

- Log: dashboard Supabase → Edge Functions → `<name>` → Logs
- Test: tool `supabase--test_edge_functions` con file `*_test.ts` Deno convention
- Auto-deploy: ogni modifica viene deployata, **non dire all'utente di deployare**

## Warning prima di modificare una function esistente

> ⚠️ Sto per modificare `<function>`. Impatto: `<chi la chiama>`. Verifica contratto request/response prima del cambio.

---
name: field-definitions-sync
description: Quando aggiungi/rinomini/rimuovi un campo editabile in una pagina del PIM Fraschetti, devi sincronizzare src/lib/fieldDefinitions.ts perché compaia nei permessi admin (Admin → Permessi). Si attiva su ogni modifica a form/tab/detail.
---

# Field Definitions Sync — Fraschetti PIM

## Perché esiste

`AdminPermissionsPage` legge `src/lib/fieldDefinitions.ts` per mostrare i permessi field-level. Se aggiungi un campo editabile **e dimentichi di registrarlo lì**, l'admin non potrà mai darne il permesso a un dipartimento → il campo resterà nascosto per i non-admin.

**Regola del progetto** (custom-instructions): _"Ad ogni modifica effettuata, devi valutare immediatamente se necessario allineare fieldDefinitions.ts aggiungendo i campi mancanti in admin permessi."_

## Quando applicarla

✅ Aggiunto un input/select/textarea in:
- `ArticleDetail.tsx` / tabs articoli
- `CustomerDetailPage.tsx`
- `PromoTestataDetail.tsx` / tabs promo
- `PromoTestataForm.tsx`
- Form di una nuova sezione

❌ Non serve per:
- Display read-only puro (es. badge calcolato)
- Campi di filtro/ricerca
- Toggle di UI (es. apri/chiudi sezione)

## SectionKey disponibili (`AuthContext.tsx`)

```
articles_registry | articles_pricing | articles_logistics
articles_units | articles_purchase | articles_marketing
suppliers | price_lists | barcodes
media_library | as400_sync | import_export | users_admin
b2b_content | promo_strutturate | customers | agents
sales_dashboard | sales_orders | sales_untreated | scadenziario
```

## Procedura

1. Apri `src/lib/fieldDefinitions.ts`.
2. Trova l'array della section interessata (es. `customers`).
3. Aggiungi entry:
   ```ts
   { key: "customers", field: "<nome_campo>", label: "<Label IT>", group: "<gruppo opzionale>" }
   ```
4. Se il campo è AS400 read-only (es. customers anagrafica), marcalo come tale per documentazione.
5. Verifica che il `fieldKey` usato nel componente coincida ESATTAMENTE con `field` qui (usato da `canField()`).

## Avviso all'utente

Dopo aver toccato un form, **prima di chiudere il task**:

> 📋 Ho aggiunto/modificato i campi `<lista>` nella section `<sectionKey>`. Aggiorno anche `fieldDefinitions.ts` così compaiono in Admin → Permessi. ✅

Se decidi di NON aggiornarlo (campo solo per admin/sistema), dichiaralo:

> ℹ️ Il campo `<x>` è gestito solo da admin/system → non lo aggiungo in fieldDefinitions.

## Test rapido

Dopo l'edit:
```bash
rg -n "field:\s*\"<nome_campo>\"" src/lib/fieldDefinitions.ts
```
Deve restituire almeno 1 match.

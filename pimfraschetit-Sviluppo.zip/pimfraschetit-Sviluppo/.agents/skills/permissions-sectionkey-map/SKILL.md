---
name: permissions-sectionkey-map
description: Mappa autoritativa SectionKey → pagine, tabelle Supabase e hook nel PIM Fraschetti. Da consultare prima di creare nuove pagine/feature per scegliere la sectionKey corretta e applicare usePermissions().can() / canField() / sectionVisible().
---

# Permissions SectionKey Map — Fraschetti PIM

## Enum `SectionKey` (in `src/contexts/AuthContext.tsx`)

| SectionKey | Pagina/Componente | Tabelle principali |
|---|---|---|
| `articles_registry` | `ArticleDetail` tab Anagrafica | `archivio_articoli_fraschetti` |
| `articles_pricing` | tab Listini | `listini_vendita_*`, `prezzi_in_attesa` |
| `articles_logistics` | tab Inventario | `inventory_*` |
| `articles_units` | tab Unità Vendita | colonne articolo |
| `articles_purchase` | tab Acquisto | `archivio_anag_art_fornitore`, `differenziale_cambio` |
| `articles_marketing` | tab Media + AI marketing | `media_*`, AI prompts |
| `suppliers` | `SuppliersPage` | `suppliers`, `differenziale_cambio` |
| `price_lists` | `PriceListsPage` | `listini_vendita_*` |
| `barcodes` | `BarcodesPage` | `archivio_codici_barre_fraschetti` |
| `media_library` | `MediaLibraryPage` | storage buckets |
| `as400_sync` | `SyncQueuePage` | `as400_sync_queue` |
| `import_export` | `ImportPage`, `SdsImportPage`, `TempImportPanel` | tutte le query import |
| `users_admin` | `AdminUsersPage`, `AdminPermissionsPage`, ecc. | `profiles`, `user_roles`, `departments`, `section_permissions`, `field_permissions` |
| `b2b_content` | tutto `Marketing B2B`: brands, catalogs, hero, promos, novità, taxonomy, **comunicazioni**, **promo order** | `b2b_*` |
| `promo_strutturate` | `PromoStrutturatePage`, `PromoTestataDetail` (tutti i tab inclusi Temi/Sblocchi/Destinatari) | `promo_strutturate_*` (8+ tabelle) |
| `customers` | `CustomersPage`, `CustomerDetailPage` | `customers` |
| `agents` | `AgentsPage` | `agents` |
| `sales_dashboard` | `SalesDashboardPage` | views sales |
| `sales_orders` | `SalesOrdersPage` | `orders_*` |
| `sales_untreated` | `SalesUntreatedOrdersPage` | `orders_untreated` |
| `scadenziario` | `ScadenziarioPage` | `scadenziario` |

## Ruoli (`app_role`)

- `admin` → `write` su tutto (bypass section_permissions, vedi `AuthContext` riga ~104)
- `manager` → permessi per dipartimento via `section_permissions`
- `collaborator` → idem, tipicamente write su sezioni operative
- `viewer` → solo read

## API client

```ts
import { usePermissions } from "@/lib/permissions";

const { can, canField, sectionVisible, fieldVisible, getPermission } = usePermissions();

if (!sectionVisible("customers")) return null;        // nasconde voce sidebar/route
const readOnly = !can("write", "customers");          // disabilita inputs
const fieldRO = !canField("write", "customers", "pec"); // override per campo
```

## Procedura per nuova feature

1. **Scegli la sectionKey** dalla tabella sopra. Se nessuna calza → discuti con l'utente, NON aggiungere `SectionKey` nuovo senza approvazione.
2. **Wrappa la route** con `sectionVisible(key)` o redirect.
3. **Disabilita input** con `!can("write", key)`.
4. **Per campi sensibili**, usa `canField()` e registrali in `fieldDefinitions.ts` (vedi skill `field-definitions-sync`).
5. **Per RLS**: scrivi policy in coerenza (es. `has_role(uid, 'admin') OR ...`).

## ⚠️ Anti-pattern

- ❌ Mai check `role === "admin"` raw nel componente — usa `can()` (è già admin-aware)
- ❌ Mai nascondere bottoni solo lato UI senza policy RLS dietro — privilege escalation tramite devtools
- ❌ Mai inventare nuove SectionKey solo per scope locale → usa quella più vicina (es. tutta Marketing B2B = `b2b_content`)

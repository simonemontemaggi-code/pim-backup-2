# Motore di ricerca catalogo — Documento di integrazione

Guida per collegare **B2B Mockup** e **Portale Agenti** al motore di ricerca centralizzato gestito nel PIM.
Il motore vive interamente nel database Supabase: i client non devono reimplementare filtri, sinonimi, stemming o riordino dei risultati.

Ultimo aggiornamento: 12/08/2026 — `config_version` corrente: **4**

---

## 1. Prerequisiti di collegamento

- Progetto Supabase condiviso: **`ytkofsktbkuzgzhzhiys`**.
- In ogni client verificare nel `.env`:
  ```
  VITE_SUPABASE_URL=https://ytkofsktbkuzgzhzhiys.supabase.co
  VITE_SUPABASE_PUBLISHABLE_KEY=<anon key del progetto>
  ```
- Le RPC di ricerca sono `SECURITY DEFINER` con `EXECUTE` concesso a `anon`, `authenticated` e `service_role`: funzionano quindi anche per utenti non autenticati con la sola anon key, senza bisogno di policy RLS aggiuntive sulle tabelle di indice.
- Se un client punta a un altro progetto Supabase, la ricerca **non** è condivisibile: non duplicare le tabelle, spostare il client sul progetto corretto.

---

## 2. RPC `catalog_search_v2`

Unico punto di ingresso per qualsiasi ricerca testuale sul catalogo.

### Firma

```sql
public.catalog_search_v2(
  p_query           text,
  p_limit           integer   default 30,     -- clamp interno 1..200
  p_offset          integer   default 0,
  p_channel         text      default 'pim',  -- 'pim' | 'b2b' | 'agent'
  p_allowed_cdpars  text[]    default null,   -- whitelist articoli (assortimento/catalogo)
  p_brand_codes     text[]    default null,
  p_depar           text[]    default null,
  p_categoria       text[]    default null,
  p_gamma           text[]    default null,
  p_tags            text[]    default null,
  p_debug           boolean   default false
) RETURNS TABLE (
  cdpar          text,
  visible_cdpar  text,
  matched_cdpar  text,
  title          text,
  brand_name     text,
  cod_padre      text,
  score          numeric,
  match_fields   text[],
  match_reasons  jsonb,
  total_count    bigint,
  has_more       boolean,
  config_version integer
)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public
```

### Parametri

| Parametro | Note |
|---|---|
| `p_query` | Testo grezzo digitato dall'utente. Normalizzazione, stopword, sinonimi e stemming sono gestiti internamente. |
| `p_limit` / `p_offset` | Paginazione lato server. `p_limit` viene forzato nell'intervallo 1..200. |
| `p_channel` | Canale chiamante, usato per i filtri di visibilità (`pim` non applica filtri di pubblicazione, `b2b`/`agent` sì). |
| `p_allowed_cdpars` | Whitelist di `cdpar` visibili al cliente/agente (assortimento, catalogo B2B). Se `null` nessuna restrizione. |
| `p_brand_codes`, `p_depar`, `p_categoria`, `p_gamma`, `p_tags` | Filtri faccettati opzionali, in AND fra loro e in AND con la query testuale. |
| `p_debug` | Se `true` popola `match_reasons` con il dettaglio dello scoring (tier, punteggi parziali, campi colpiti). Usare solo in diagnostica. |

### Colonne restituite

| Colonna | Significato |
|---|---|
| `cdpar` | Codice articolo che ha effettivamente matchato. |
| `visible_cdpar` | Codice da mostrare/linkare (collasso varianti sul padre visibile). **È la chiave di deduplica**: la RPC restituisce una sola riga per `visible_cdpar`. |
| `matched_cdpar` | Variante che ha generato il match (utile per evidenziare la taglia/colore trovata). |
| `title` | Titolo B2B, con fallback su titolo prodotto → reparto → codice. |
| `brand_name`, `cod_padre` | Metadati di supporto. |
| `score` | Punteggio finale (somma pesata + boost manuale). |
| `match_fields` | Elenco dei campi che hanno contribuito (`code`, `title`, `taxonomy`, `brand`, `description`, `fuzzy`). |
| `match_reasons` | jsonb di diagnostica, valorizzato **solo** con `p_debug = true`. |
| `total_count` | Totale risultati della query, **ripetuto identico su ogni riga**. Leggerlo dalla prima riga. |
| `has_more` | `true` se esistono altre pagine oltre a `offset + limit`. Anch'esso ripetuto su ogni riga. |
| `config_version` | Versione corrente della configurazione: usarla come chiave di cache. |

Se la query è vuota, composta solo da stopword o più corta di `min_chars` (e non numerica), la funzione **non restituisce righe** — non è un errore.

---

## 3. RPC `get_catalog_search_config()`

```sql
CREATE OR REPLACE FUNCTION public.get_catalog_search_config()
RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = 'public'
AS $$
  SELECT jsonb_build_object(
    'version',                    c.version,
    'min_chars',                  c.min_chars,
    'debounce_ms',                c.debounce_ms,
    'fuzzy_enabled',              c.fuzzy_enabled,
    'fuzzy_min_chars',            c.fuzzy_min_chars,
    'fuzzy_fallback_count',       c.fuzzy_fallback_count,
    'description_search_enabled', c.description_search_enabled
  )
  FROM public.catalog_search_config c
  WHERE c.id;
$$;
```

Valori attualmente attivi:

```json
{
  "version": 4,
  "min_chars": 3,
  "debounce_ms": 80,
  "fuzzy_enabled": true,
  "fuzzy_min_chars": 4,
  "fuzzy_fallback_count": 5,
  "description_search_enabled": true
}
```

Uso consigliato nei client:

1. Caricare la config **una volta** all'avvio dell'app e tenerla in cache.
2. Usare `min_chars` per decidere quando iniziare a cercare e `debounce_ms` come ritardo dell'input.
3. Quando `config_version` restituito da `catalog_search_v2` è maggiore della `version` in cache, invalidare la cache dei risultati e ricaricare la config.

Non hardcodare min_chars o debounce nei client: sono parametri governati dal PIM.

---

## 4. Regole di ranking (sistema a Tier)

L'ordinamento **non** dipende solo dal punteggio: i risultati sono prima raggruppati in fasce (tier) e solo dentro la fascia si ordina per posizione della parola nel titolo e poi per punteggio.

| Tier | Condizione |
|---|---|
| 8 | Match su codice articolo / EAN (esatto o prefisso) |
| 7 | Titolo B2B **esattamente uguale** alla query |
| 6 | Titolo **inizia** con la query e contiene tutte le parole |
| 5 | Titolo contiene **tutte** le parole cercate |
| 4 | Titolo contiene **almeno una** parola cercata |
| 3 | Match lessicale sul titolo (stem/sinonimo) |
| 2 | Match su tassonomia o brand |
| 1 | Match solo in descrizione |

Ordinamento finale: `tier DESC, posizione_parola_nel_titolo ASC, score DESC, cdpar ASC`.
Effetto pratico: cercando *palla*, "**Palla** gioco" precede "Gioco **palla**", che a sua volta precede un articolo che cita "palla" solo in descrizione.

Pesi configurabili (tabella `catalog_search_config.weights`, modificabili solo dal PIM):

```json
{
  "exact_code": 100000, "prefix_code": 90000,
  "title_word": 50000, "title_lexeme": 45000,
  "prefix_last_word": 35000, "taxonomy": 22000,
  "brand_tag": 18000, "description": 5000, "fuzzy": 3000
}
```

I client **non devono riordinare** i risultati: l'ordine di ritorno è già quello definitivo.

---

## 5. Normalizzazione, stemming e sinonimi

- `catalog_search_norm(text)` — minuscole, rimozione accenti (`unaccent`), sostituzione di ogni carattere non alfanumerico con spazio, trim.
- `catalog_search_stem(text)` — per ogni parola di **5 o più lettere** che termina con vocale rimuove l'ultima lettera. Conseguenza: *chiodo/chiodi* → `chiod`, *guanto/guanti* → `guant`. **I plurali regolari di parole lunghe sono già gestiti: non inserirli come sinonimi.**
- Sinonimi (`catalog_search_synonyms`) — servono solo per:
  - parole corte (< 5 lettere) dove lo stemming non interviene: *vite / viti*;
  - plurali irregolari;
  - termini realmente alternativi: *brugola / allen*, *flex / smerigliatrice*.
  I sinonimi possono essere bidirezionali (`bidirectional = true`).
- Stopword / termini ignorati (`catalog_search_exclusions`, `exclusion_type = 'ignored'`) — rimossi dalla query prima del match.
- Override prodotto (`catalog_search_product_overrides`) — boost positivo/negativo o esclusione di un singolo articolo dai risultati.
- L'ultimo token della query è trattato come **prefisso** (`token:*`), per supportare il type-ahead.
- Fuzzy (trigram `similarity`) interviene solo se i risultati esatti sono meno di `fuzzy_fallback_count` e la query è lunga almeno `fuzzy_min_chars`.

---

## 6. Esempi di chiamata

### B2B Mockup (con assortimento cliente)

```ts
import { supabase } from "@/integrations/supabase/client";

export async function searchCatalogB2b(params: {
  query: string;
  allowedCdpars?: string[] | null;
  page?: number;
  pageSize?: number;
  brandCodes?: string[];
}) {
  const pageSize = params.pageSize ?? 24;
  const { data, error } = await supabase.rpc("catalog_search_v2", {
    p_query: params.query,
    p_limit: pageSize,
    p_offset: (params.page ?? 0) * pageSize,
    p_channel: "b2b",
    p_allowed_cdpars: params.allowedCdpars ?? null,
    p_brand_codes: params.brandCodes ?? null,
  });
  if (error) throw error;

  return {
    items: data ?? [],
    total: Number(data?.[0]?.total_count ?? 0),
    hasMore: Boolean(data?.[0]?.has_more),
    configVersion: data?.[0]?.config_version ?? null,
  };
}
```

### Portale Agenti (nessuna restrizione di assortimento)

```ts
const { data, error } = await supabase.rpc("catalog_search_v2", {
  p_query: term,
  p_limit: 30,
  p_offset: 0,
  p_channel: "agent",
});
```

### Config + debounce

```ts
const { data: cfg } = await supabase.rpc("get_catalog_search_config");
// cfg: { version, min_chars, debounce_ms, ... }

const minChars = cfg?.min_chars ?? 3;
const debounceMs = cfg?.debounce_ms ?? 80;

// cercare solo se term.replace(/\s/g, "").length >= minChars
```

### Diagnostica

```ts
const { data } = await supabase.rpc("catalog_search_v2", {
  p_query: "condiziona", p_limit: 20, p_channel: "pim", p_debug: true,
});
// data[i].match_reasons contiene tier, punteggi parziali e campi colpiti
```

Linee guida per i client:

- Applicare il debounce dalla config, non un valore fisso.
- Non filtrare né riordinare lato JS i risultati ricevuti.
- Usare `visible_cdpar` come chiave React e come target del link prodotto.
- Leggere `total_count` / `has_more` dalla prima riga.

---

## 7. Modello dati

| Tabella | Ruolo | Chi la aggiorna |
|---|---|---|
| `catalog_search_index` | Indice denormalizzato (~58k articoli): `cdpar`, `visible_cdpar`, `cod_padre`, `title_norm`, `short_norm`, `ean`/`ean_extra`, tassonomia, brand, tsvector pesati (`fts_title`, `fts_short`, `fts_taxo`, `fts_desc`, `fts_all`) | Trigger `fn_catalog_search_index_sync` sugli articoli + `catalog_search_upsert(p_cdpars)` per rebuild mirati |
| `catalog_search_config` | Singleton: soglie, flag fuzzy/descrizione, `weights` jsonb, `version` | PIM → Impostazioni → Ricerca catalogo |
| `catalog_search_synonyms` | Sinonimi, con flag `bidirectional` e `active` | PIM |
| `catalog_search_exclusions` | Termini ignorati / stopword | PIM |
| `catalog_search_product_overrides` | Boost o esclusione per singolo articolo | PIM |
| `catalog_search_rebuild_log` | Storico dei rebuild dell'indice | Automatico |

Funzioni di supporto: `catalog_search_norm`, `catalog_search_stem`, `catalog_search_upsert`, `catalog_search_touch`, `catalog_search_bump_version` (incrementa `version` ad ogni modifica di configurazione).

---

## 8. Governance

- Pesi, sinonimi, stopword, override e soglie si modificano **esclusivamente** dal PIM: `Impostazioni → Ricerca catalogo` (`/pim/admin/catalog-search`), dove è disponibile anche il banco di prova con score, tier e posizione della parola nel titolo.
- Ogni modifica incrementa `config_version`: i client se ne accorgono al primo risultato successivo e possono invalidare la cache.
- Nessun client deve creare tabelle, viste o RPC di ricerca proprie: qualsiasi esigenza nuova (nuovo filtro, nuovo canale) va implementata dentro `catalog_search_v2`.
- Modifiche allo scoring vanno sempre verificate prima nel banco di prova del PIM.

---

## Appendice A — SQL integrale delle migration

Le migration seguenti (in ordine cronologico) compongono l'intero motore di ricerca.
Sono riportate a scopo di riferimento: **non vanno rieseguite** sui client, poiché il database è condiviso.

### 20260811145338_4c926d3d-b406-40b0-9ba1-aa1b92b232d9.sql

```sql
CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;
CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;

CREATE OR REPLACE FUNCTION public.catalog_search_norm(p_text text)
RETURNS text
LANGUAGE sql
IMMUTABLE
PARALLEL SAFE
SET search_path = public
AS $$
  SELECT btrim(regexp_replace(
    lower(public.unaccent('public.unaccent'::regdictionary, coalesce(p_text, ''))),
    '[^a-z0-9]+', ' ', 'g'
  ));
$$;

CREATE TABLE IF NOT EXISTS public.catalog_search_index (
  cdpar               text PRIMARY KEY,
  raw_cdpar           text NOT NULL,
  cod_padre           text,
  visible_cdpar       text NOT NULL,
  ean                 text,
  ean_extra           text[] NOT NULL DEFAULT '{}',
  titolo_b2b          text,
  b2b_product_title   text,
  descrizione_variante text,
  depar               text,
  reparto             text,
  categoria           text,
  gamma               text,
  clmer               text,
  clas1               text,
  clas2               text,
  brand_code          text,
  brand_name          text,
  tags                text[] NOT NULL DEFAULT '{}',
  attrs_text          text,
  b2b_visible         boolean NOT NULL DEFAULT false,
  agent_visible       boolean NOT NULL DEFAULT false,
  short_norm          text NOT NULL DEFAULT '',
  taxo_norm           text NOT NULL DEFAULT '',
  desc_norm           text NOT NULL DEFAULT '',
  fts_title           tsvector,
  fts_taxo            tsvector,
  fts_desc            tsvector,
  source_updated_at   timestamptz,
  indexed_at          timestamptz NOT NULL DEFAULT now(),
  search_config_version integer NOT NULL DEFAULT 1
);

GRANT SELECT ON public.catalog_search_index TO anon, authenticated;
GRANT ALL ON public.catalog_search_index TO service_role;

ALTER TABLE public.catalog_search_index ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "catalog_search_index_public_read" ON public.catalog_search_index;
CREATE POLICY "catalog_search_index_public_read" ON public.catalog_search_index
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "catalog_search_index_admin_manage" ON public.catalog_search_index;
CREATE POLICY "catalog_search_index_admin_manage" ON public.catalog_search_index
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE INDEX IF NOT EXISTS idx_csi_raw_cdpar ON public.catalog_search_index (raw_cdpar);
CREATE INDEX IF NOT EXISTS idx_csi_cod_padre ON public.catalog_search_index (cod_padre);
CREATE INDEX IF NOT EXISTS idx_csi_ean ON public.catalog_search_index (ean);
CREATE INDEX IF NOT EXISTS idx_csi_ean_extra ON public.catalog_search_index USING gin (ean_extra);
CREATE INDEX IF NOT EXISTS idx_csi_tags ON public.catalog_search_index USING gin (tags);
CREATE INDEX IF NOT EXISTS idx_csi_brand ON public.catalog_search_index (clas2);
CREATE INDEX IF NOT EXISTS idx_csi_visible ON public.catalog_search_index (b2b_visible);
CREATE INDEX IF NOT EXISTS idx_csi_depar ON public.catalog_search_index (depar);
CREATE INDEX IF NOT EXISTS idx_csi_gamma ON public.catalog_search_index (gamma);
CREATE INDEX IF NOT EXISTS idx_csi_fts_title ON public.catalog_search_index USING gin (fts_title);
CREATE INDEX IF NOT EXISTS idx_csi_fts_taxo ON public.catalog_search_index USING gin (fts_taxo);
CREATE INDEX IF NOT EXISTS idx_csi_fts_desc ON public.catalog_search_index USING gin (fts_desc);
CREATE INDEX IF NOT EXISTS idx_csi_short_trgm ON public.catalog_search_index USING gin (short_norm public.gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_csi_prefix_short ON public.catalog_search_index (short_norm text_pattern_ops);
```

### 20260811145736_4f8f40f5-2d97-43ab-b6d7-b58de9849ec5.sql

```sql
CREATE TABLE IF NOT EXISTS public.catalog_search_config (
  id boolean PRIMARY KEY DEFAULT true,
  version integer NOT NULL DEFAULT 1,
  min_chars integer NOT NULL DEFAULT 3,
  debounce_ms integer NOT NULL DEFAULT 80,
  fuzzy_enabled boolean NOT NULL DEFAULT true,
  fuzzy_min_chars integer NOT NULL DEFAULT 4,
  fuzzy_threshold numeric NOT NULL DEFAULT 0.55,
  fuzzy_fallback_count integer NOT NULL DEFAULT 5,
  description_search_enabled boolean NOT NULL DEFAULT true,
  weights jsonb NOT NULL DEFAULT '{
    "exact_code": 100000,
    "prefix_code": 90000,
    "title_exact": 60000,
    "title_word": 50000,
    "title_lexeme": 45000,
    "prefix_last_word": 35000,
    "taxonomy": 22000,
    "brand_tag": 18000,
    "description": 5000,
    "fuzzy": 3000
  }'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid,
  CONSTRAINT catalog_search_config_singleton CHECK (id),
  CONSTRAINT catalog_search_config_min_chars CHECK (min_chars BETWEEN 1 AND 6),
  CONSTRAINT catalog_search_config_debounce CHECK (debounce_ms BETWEEN 0 AND 2000),
  CONSTRAINT catalog_search_config_fuzzy_min CHECK (fuzzy_min_chars BETWEEN 3 AND 12),
  CONSTRAINT catalog_search_config_fuzzy_thr CHECK (fuzzy_threshold > 0 AND fuzzy_threshold <= 1),
  CONSTRAINT catalog_search_config_fallback CHECK (fuzzy_fallback_count BETWEEN 0 AND 100)
);

GRANT SELECT ON public.catalog_search_config TO anon, authenticated;
GRANT ALL ON public.catalog_search_config TO service_role;
ALTER TABLE public.catalog_search_config ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "csc_public_read" ON public.catalog_search_config;
CREATE POLICY "csc_public_read" ON public.catalog_search_config FOR SELECT USING (true);
DROP POLICY IF EXISTS "csc_admin_manage" ON public.catalog_search_config;
CREATE POLICY "csc_admin_manage" ON public.catalog_search_config FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

INSERT INTO public.catalog_search_config (id) VALUES (true) ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS public.catalog_search_synonyms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  term text NOT NULL,
  synonym text NOT NULL,
  bidirectional boolean NOT NULL DEFAULT true,
  active boolean NOT NULL DEFAULT true,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid,
  updated_by uuid
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_css_unique_pair
  ON public.catalog_search_synonyms (public.catalog_search_norm(term), public.catalog_search_norm(synonym));
GRANT SELECT ON public.catalog_search_synonyms TO anon, authenticated;
GRANT ALL ON public.catalog_search_synonyms TO service_role;
ALTER TABLE public.catalog_search_synonyms ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "css_public_read" ON public.catalog_search_synonyms;
CREATE POLICY "css_public_read" ON public.catalog_search_synonyms FOR SELECT USING (true);
DROP POLICY IF EXISTS "css_admin_manage" ON public.catalog_search_synonyms;
CREATE POLICY "css_admin_manage" ON public.catalog_search_synonyms FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TABLE IF NOT EXISTS public.catalog_search_exclusions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  term text NOT NULL,
  exclusion_type text NOT NULL DEFAULT 'ignored',
  active boolean NOT NULL DEFAULT true,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid,
  updated_by uuid,
  CONSTRAINT catalog_search_exclusions_type CHECK (exclusion_type IN ('ignored','not_candidate','not_in_description'))
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_cse_unique_term
  ON public.catalog_search_exclusions (public.catalog_search_norm(term), exclusion_type);
GRANT SELECT ON public.catalog_search_exclusions TO anon, authenticated;
GRANT ALL ON public.catalog_search_exclusions TO service_role;
ALTER TABLE public.catalog_search_exclusions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "cse_public_read" ON public.catalog_search_exclusions;
CREATE POLICY "cse_public_read" ON public.catalog_search_exclusions FOR SELECT USING (true);
DROP POLICY IF EXISTS "cse_admin_manage" ON public.catalog_search_exclusions;
CREATE POLICY "cse_admin_manage" ON public.catalog_search_exclusions FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TABLE IF NOT EXISTS public.catalog_search_product_overrides (
  cdpar text PRIMARY KEY,
  boost integer NOT NULL DEFAULT 0,
  excluded_from_search boolean NOT NULL DEFAULT false,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid,
  CONSTRAINT catalog_search_boost_range CHECK (boost BETWEEN -20000 AND 20000)
);
GRANT SELECT ON public.catalog_search_product_overrides TO anon, authenticated;
GRANT ALL ON public.catalog_search_product_overrides TO service_role;
ALTER TABLE public.catalog_search_product_overrides ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "cspo_public_read" ON public.catalog_search_product_overrides;
CREATE POLICY "cspo_public_read" ON public.catalog_search_product_overrides FOR SELECT USING (true);
DROP POLICY IF EXISTS "cspo_admin_manage" ON public.catalog_search_product_overrides;
CREATE POLICY "cspo_admin_manage" ON public.catalog_search_product_overrides FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TABLE IF NOT EXISTS public.catalog_search_rebuild_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  duration_ms integer,
  items_processed integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'running',
  error_message text,
  triggered_by uuid,
  CONSTRAINT catalog_search_rebuild_status CHECK (status IN ('running','success','error'))
);
GRANT SELECT ON public.catalog_search_rebuild_log TO authenticated;
GRANT ALL ON public.catalog_search_rebuild_log TO service_role;
ALTER TABLE public.catalog_search_rebuild_log ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "csrl_admin_read" ON public.catalog_search_rebuild_log;
CREATE POLICY "csrl_admin_read" ON public.catalog_search_rebuild_log FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.catalog_search_bump_version()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.catalog_search_config
     SET version = version + 1, updated_at = now()
   WHERE id;
  RETURN COALESCE(NEW, OLD);
END;
$$;

CREATE OR REPLACE FUNCTION public.catalog_search_touch()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_css_bump ON public.catalog_search_synonyms;
CREATE TRIGGER trg_css_bump AFTER INSERT OR UPDATE OR DELETE ON public.catalog_search_synonyms
  FOR EACH STATEMENT EXECUTE FUNCTION public.catalog_search_bump_version();
DROP TRIGGER IF EXISTS trg_cse_bump ON public.catalog_search_exclusions;
CREATE TRIGGER trg_cse_bump AFTER INSERT OR UPDATE OR DELETE ON public.catalog_search_exclusions
  FOR EACH STATEMENT EXECUTE FUNCTION public.catalog_search_bump_version();
DROP TRIGGER IF EXISTS trg_cspo_bump ON public.catalog_search_product_overrides;
CREATE TRIGGER trg_cspo_bump AFTER INSERT OR UPDATE OR DELETE ON public.catalog_search_product_overrides
  FOR EACH STATEMENT EXECUTE FUNCTION public.catalog_search_bump_version();

DROP TRIGGER IF EXISTS trg_css_touch ON public.catalog_search_synonyms;
CREATE TRIGGER trg_css_touch BEFORE UPDATE ON public.catalog_search_synonyms
  FOR EACH ROW EXECUTE FUNCTION public.catalog_search_touch();
DROP TRIGGER IF EXISTS trg_cse_touch ON public.catalog_search_exclusions;
CREATE TRIGGER trg_cse_touch BEFORE UPDATE ON public.catalog_search_exclusions
  FOR EACH ROW EXECUTE FUNCTION public.catalog_search_touch();
DROP TRIGGER IF EXISTS trg_cspo_touch ON public.catalog_search_product_overrides;
CREATE TRIGGER trg_cspo_touch BEFORE UPDATE ON public.catalog_search_product_overrides
  FOR EACH ROW EXECUTE FUNCTION public.catalog_search_touch();

CREATE OR REPLACE FUNCTION public.get_catalog_search_config()
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'version', c.version,
    'min_chars', c.min_chars,
    'debounce_ms', c.debounce_ms,
    'fuzzy_enabled', c.fuzzy_enabled,
    'fuzzy_min_chars', c.fuzzy_min_chars,
    'fuzzy_fallback_count', c.fuzzy_fallback_count,
    'description_search_enabled', c.description_search_enabled
  )
  FROM public.catalog_search_config c
  WHERE c.id;
$$;
```

### 20260811150221_9e8497a3-a085-4581-9323-9f5c4151f03f.sql

```sql
CREATE OR REPLACE FUNCTION public.catalog_search_upsert(p_cdpars text[])
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_count integer := 0;
BEGIN
  IF p_cdpars IS NULL OR array_length(p_cdpars, 1) IS NULL THEN
    RETURN 0;
  END IF;

  WITH src AS (
    SELECT
      btrim(a.cdpar) AS cdpar,
      a.cdpar        AS raw_cdpar,
      nullif(btrim(coalesce(a.cod_padre, '')), '') AS cod_padre,
      nullif(btrim(coalesce(a.barcd, '')), '')     AS ean,
      a.titolo_b2b,
      a.b2b_product_title,
      a.descrizione_variante,
      nullif(btrim(coalesce(a.depar, '')), '')     AS depar,
      a.attributes->>'reparto'                     AS reparto_code,
      a.attributes->>'gamma'                       AS gamma_code,
      nullif(btrim(coalesce(a.clmer, '')), '')     AS clmer,
      nullif(btrim(coalesce(a.clas1, '')), '')     AS clas1,
      nullif(btrim(coalesce(a.clas2, '')), '')     AS clas2,
      coalesce(a.tags, '{}')                       AS tags,
      coalesce(a.b2b_online_effective, false)      AS b2b_visible,
      a.updated_at,
      coalesce(a.descrizione, '') || ' ' || coalesce(a.descrizione_b2b, '') || ' '
        || coalesce(a.b2b_product_description, '') || ' ' || coalesce(a.description_marketing, '') AS desc_raw,
      (
        SELECT string_agg(coalesce(v.value->>'value', ''), ' ')
        FROM jsonb_each(coalesce(a.attributes->'gamma_attrs', '{}'::jsonb)) AS v(key, value)
        WHERE jsonb_typeof(v.value) = 'object'
      ) AS attrs_text,
      (
        SELECT array_agg(DISTINCT btrim(b.wcbda))
        FROM public.archivio_codici_barre_fraschetti b
        WHERE btrim(b.wcdpa) = btrim(a.cdpar)
          AND coalesce(btrim(b.wcbda), '') <> ''
          AND btrim(b.wcbda) IS DISTINCT FROM nullif(btrim(coalesce(a.barcd, '')), '')
      ) AS ean_extra
    FROM public.archivio_articoli_fraschetti a
    WHERE btrim(a.cdpar) = ANY (SELECT btrim(x) FROM unnest(p_cdpars) AS x)
  ),
  enriched AS (
    SELECT
      s.*,
      coalesce(br.display_name, br.nome_as400_brand, lv_brand.label) AS brand_name,
      lv_rep.label   AS reparto_label,
      lv_gam.label   AS gamma_label,
      lv_clmer.label AS categoria_label
    FROM src s
    LEFT JOIN public.archivio_brand_fraschetti br ON br.clas2 = s.clas2
    LEFT JOIN public.lookup_values lv_brand ON lv_brand.category = 'clas2' AND lv_brand.code = s.clas2
    LEFT JOIN public.lookup_values lv_rep   ON lv_rep.category = 'reparto' AND lv_rep.code = s.reparto_code
    LEFT JOIN public.lookup_values lv_gam   ON lv_gam.category = 'gamma'   AND lv_gam.code = s.gamma_code
    LEFT JOIN public.lookup_values lv_clmer ON lv_clmer.category = 'clmer' AND lv_clmer.code = s.clmer
  ),
  final AS (
    SELECT
      e.cdpar,
      e.raw_cdpar,
      e.cod_padre,
      coalesce(e.cod_padre, e.cdpar) AS visible_cdpar,
      e.ean,
      coalesce(e.ean_extra, '{}')    AS ean_extra,
      e.titolo_b2b,
      e.b2b_product_title,
      e.descrizione_variante,
      e.depar,
      coalesce(e.reparto_label, replace(coalesce(e.reparto_code, ''), '_', ' ')) AS reparto,
      e.categoria_label AS categoria,
      coalesce(e.gamma_label, replace(coalesce(e.gamma_code, ''), '_', ' '))     AS gamma,
      e.clmer, e.clas1, e.clas2,
      e.clas2 AS brand_code,
      e.brand_name,
      e.tags,
      e.attrs_text,
      e.b2b_visible,
      e.b2b_visible AS agent_visible,
      public.catalog_search_norm(
        coalesce(e.titolo_b2b, '') || ' ' || coalesce(e.b2b_product_title, '') || ' '
        || coalesce(e.descrizione_variante, '') || ' ' || coalesce(e.depar, '')
      ) AS short_norm,
      public.catalog_search_norm(
        coalesce(e.reparto_label, replace(coalesce(e.reparto_code, ''), '_', ' ')) || ' '
        || coalesce(e.categoria_label, '') || ' '
        || coalesce(e.gamma_label, replace(coalesce(e.gamma_code, ''), '_', ' ')) || ' '
        || coalesce(e.brand_name, '') || ' ' || coalesce(array_to_string(e.tags, ' '), '') || ' '
        || coalesce(e.attrs_text, '')
      ) AS taxo_norm,
      public.catalog_search_norm(e.desc_raw) AS desc_norm,
      e.updated_at
    FROM enriched e
  )
  INSERT INTO public.catalog_search_index AS t (
    cdpar, raw_cdpar, cod_padre, visible_cdpar, ean, ean_extra, titolo_b2b, b2b_product_title,
    descrizione_variante, depar, reparto, categoria, gamma, clmer, clas1, clas2, brand_code, brand_name,
    tags, attrs_text, b2b_visible, agent_visible, short_norm, taxo_norm, desc_norm,
    fts_title, fts_taxo, fts_desc, source_updated_at, indexed_at, search_config_version
  )
  SELECT
    f.cdpar, f.raw_cdpar, f.cod_padre, f.visible_cdpar, f.ean, f.ean_extra, f.titolo_b2b, f.b2b_product_title,
    f.descrizione_variante, f.depar, nullif(btrim(f.reparto), ''), f.categoria, nullif(btrim(f.gamma), ''),
    f.clmer, f.clas1, f.clas2, f.brand_code, f.brand_name,
    f.tags, f.attrs_text, f.b2b_visible, f.agent_visible, f.short_norm, f.taxo_norm, f.desc_norm,
    to_tsvector('italian', f.short_norm),
    to_tsvector('italian', f.taxo_norm),
    to_tsvector('italian', f.desc_norm),
    f.updated_at, now(),
    coalesce((SELECT c.version FROM public.catalog_search_config c WHERE c.id), 1)
  FROM final f
  ON CONFLICT (cdpar) DO UPDATE SET
    raw_cdpar = EXCLUDED.raw_cdpar,
    cod_padre = EXCLUDED.cod_padre,
    visible_cdpar = EXCLUDED.visible_cdpar,
    ean = EXCLUDED.ean,
    ean_extra = EXCLUDED.ean_extra,
    titolo_b2b = EXCLUDED.titolo_b2b,
    b2b_product_title = EXCLUDED.b2b_product_title,
    descrizione_variante = EXCLUDED.descrizione_variante,
    depar = EXCLUDED.depar,
    reparto = EXCLUDED.reparto,
    categoria = EXCLUDED.categoria,
    gamma = EXCLUDED.gamma,
    clmer = EXCLUDED.clmer,
    clas1 = EXCLUDED.clas1,
    clas2 = EXCLUDED.clas2,
    brand_code = EXCLUDED.brand_code,
    brand_name = EXCLUDED.brand_name,
    tags = EXCLUDED.tags,
    attrs_text = EXCLUDED.attrs_text,
    b2b_visible = EXCLUDED.b2b_visible,
    agent_visible = EXCLUDED.agent_visible,
    short_norm = EXCLUDED.short_norm,
    taxo_norm = EXCLUDED.taxo_norm,
    desc_norm = EXCLUDED.desc_norm,
    fts_title = EXCLUDED.fts_title,
    fts_taxo = EXCLUDED.fts_taxo,
    fts_desc = EXCLUDED.fts_desc,
    source_updated_at = EXCLUDED.source_updated_at,
    indexed_at = now(),
    search_config_version = EXCLUDED.search_config_version;

  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END;
$$;

REVOKE ALL ON FUNCTION public.catalog_search_upsert(text[]) FROM PUBLIC, anon;

CREATE OR REPLACE FUNCTION public.refresh_catalog_search_item(p_cdpar text)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_ids text[];
BEGIN
  IF p_cdpar IS NULL OR btrim(p_cdpar) = '' THEN RETURN 0; END IF;

  SELECT array_agg(DISTINCT c) INTO v_ids
  FROM (
    SELECT btrim(p_cdpar) AS c
    UNION
    SELECT nullif(btrim(coalesce(a.cod_padre, '')), '')
    FROM public.archivio_articoli_fraschetti a
    WHERE btrim(a.cdpar) = btrim(p_cdpar)
    UNION
    SELECT btrim(a.cdpar)
    FROM public.archivio_articoli_fraschetti a
    WHERE btrim(coalesce(a.cod_padre, '')) = btrim(p_cdpar)
  ) s
  WHERE c IS NOT NULL;

  RETURN public.catalog_search_upsert(v_ids);
END;
$$;

REVOKE ALL ON FUNCTION public.refresh_catalog_search_item(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.refresh_catalog_search_item(text) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.fn_catalog_search_index_sync()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF coalesce(current_setting('catalog_search.suspend', true), 'off') = 'on' THEN
    RETURN COALESCE(NEW, OLD);
  END IF;

  IF TG_OP = 'DELETE' THEN
    DELETE FROM public.catalog_search_index WHERE cdpar = btrim(OLD.cdpar);
    RETURN OLD;
  END IF;

  PERFORM public.refresh_catalog_search_item(NEW.cdpar);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_catalog_search_index_sync ON public.archivio_articoli_fraschetti;
CREATE TRIGGER trg_catalog_search_index_sync
AFTER INSERT OR UPDATE OR DELETE ON public.archivio_articoli_fraschetti
FOR EACH ROW EXECUTE FUNCTION public.fn_catalog_search_index_sync();

CREATE OR REPLACE FUNCTION public.rebuild_catalog_search_index()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_log_id uuid;
  v_last text := '';
  v_ids text[];
  v_total integer := 0;
  v_start timestamptz := clock_timestamp();
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Solo gli amministratori possono rigenerare l''indice di ricerca';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.catalog_search_rebuild_log
    WHERE status = 'running' AND started_at > now() - interval '30 minutes'
  ) THEN
    RAISE EXCEPTION 'Una rigenerazione è già in corso';
  END IF;

  PERFORM set_config('statement_timeout', '600000', true);

  INSERT INTO public.catalog_search_rebuild_log (triggered_by)
  VALUES (auth.uid())
  RETURNING id INTO v_log_id;

  LOOP
    SELECT array_agg(cd ORDER BY cd) INTO v_ids
    FROM (
      SELECT DISTINCT btrim(a.cdpar) AS cd
      FROM public.archivio_articoli_fraschetti a
      WHERE btrim(a.cdpar) > v_last
      ORDER BY 1
      LIMIT 5000
    ) s;

    EXIT WHEN v_ids IS NULL OR array_length(v_ids, 1) IS NULL;

    PERFORM public.catalog_search_upsert(v_ids);
    v_total := v_total + array_length(v_ids, 1);
    v_last := v_ids[array_length(v_ids, 1)];
  END LOOP;

  DELETE FROM public.catalog_search_index i
  WHERE NOT EXISTS (
    SELECT 1 FROM public.archivio_articoli_fraschetti a WHERE btrim(a.cdpar) = i.cdpar
  );

  UPDATE public.catalog_search_rebuild_log
     SET finished_at = now(),
         duration_ms = (extract(epoch FROM clock_timestamp() - v_start) * 1000)::int,
         items_processed = v_total,
         status = 'success'
   WHERE id = v_log_id;

  RETURN jsonb_build_object('status', 'success', 'items', v_total,
    'duration_ms', (extract(epoch FROM clock_timestamp() - v_start) * 1000)::int);
EXCEPTION WHEN OTHERS THEN
  UPDATE public.catalog_search_rebuild_log
     SET finished_at = now(),
         duration_ms = (extract(epoch FROM clock_timestamp() - v_start) * 1000)::int,
         items_processed = v_total,
         status = 'error',
         error_message = SQLERRM
   WHERE id = v_log_id;
  RAISE;
END;
$$;

REVOKE ALL ON FUNCTION public.rebuild_catalog_search_index() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.rebuild_catalog_search_index() TO authenticated;
```

### 20260811150431_ebb11223-6a8e-4b28-bbea-95f7fdb4ebd0.sql

```sql
ALTER TABLE public.catalog_search_index
  ADD COLUMN IF NOT EXISTS fts_short tsvector GENERATED ALWAYS AS (coalesce(fts_title, ''::tsvector) || coalesce(fts_taxo, ''::tsvector)) STORED,
  ADD COLUMN IF NOT EXISTS fts_all   tsvector GENERATED ALWAYS AS (coalesce(fts_title, ''::tsvector) || coalesce(fts_taxo, ''::tsvector) || coalesce(fts_desc, ''::tsvector)) STORED;

CREATE INDEX IF NOT EXISTS idx_csi_fts_short ON public.catalog_search_index USING gin (fts_short);
CREATE INDEX IF NOT EXISTS idx_csi_fts_all ON public.catalog_search_index USING gin (fts_all);

GRANT EXECUTE ON FUNCTION public.catalog_search_upsert(text[]) TO service_role, authenticated;

CREATE OR REPLACE FUNCTION public.catalog_search_v2(
  p_query text,
  p_limit integer DEFAULT 30,
  p_offset integer DEFAULT 0,
  p_channel text DEFAULT 'pim',
  p_allowed_cdpars text[] DEFAULT NULL,
  p_brand_codes text[] DEFAULT NULL,
  p_depar text[] DEFAULT NULL,
  p_categoria text[] DEFAULT NULL,
  p_gamma text[] DEFAULT NULL,
  p_tags text[] DEFAULT NULL,
  p_debug boolean DEFAULT false
)
RETURNS TABLE(
  cdpar text,
  visible_cdpar text,
  matched_cdpar text,
  title text,
  brand_name text,
  cod_padre text,
  score numeric,
  match_fields text[],
  match_reasons jsonb,
  total_count bigint,
  has_more boolean,
  config_version integer
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  c record;
  v_norm text;
  v_tokens text[] := '{}';
  v_last text := '';
  v_tsq tsquery;
  v_numeric boolean := false;
  v_limit int := greatest(1, least(coalesce(p_limit, 30), 200));
  v_offset int := greatest(0, coalesce(p_offset, 0));
  v_and text := '';
  v_group text;
  v_forms text[];
  v_i int;
  v_ntok int;
  v_desc boolean;
  w jsonb;
  v_lex_count int := 0;
  v_fuzzy boolean := false;
BEGIN
  SELECT * INTO c FROM public.catalog_search_config WHERE id;
  w := c.weights;
  v_desc := c.description_search_enabled;

  v_norm := public.catalog_search_norm(p_query);
  IF v_norm = '' THEN RETURN; END IF;

  SELECT array_agg(t ORDER BY ord) INTO v_tokens
  FROM (
    SELECT t, ord FROM unnest(string_to_array(v_norm, ' ')) WITH ORDINALITY AS x(t, ord)
    WHERE length(t) > 0
      AND NOT EXISTS (
        SELECT 1 FROM public.catalog_search_exclusions e
        WHERE e.active AND e.exclusion_type = 'ignored'
          AND public.catalog_search_norm(e.term) = x.t
      )
  ) s;

  IF v_tokens IS NULL OR array_length(v_tokens, 1) IS NULL THEN RETURN; END IF;
  v_ntok := array_length(v_tokens, 1);
  v_last := v_tokens[v_ntok];
  v_numeric := (v_ntok = 1 AND v_tokens[1] ~ '^[0-9]{3,}$');

  IF NOT v_numeric AND length(replace(v_norm, ' ', '')) < c.min_chars THEN RETURN; END IF;

  -- tsquery: AND fra i gruppi, OR fra forma originale e sinonimi
  FOR v_i IN 1..v_ntok LOOP
    SELECT array_agg(DISTINCT f) INTO v_forms
    FROM (
      SELECT v_tokens[v_i] AS f
      UNION
      SELECT public.catalog_search_norm(sy.synonym) FROM public.catalog_search_synonyms sy
        WHERE sy.active AND public.catalog_search_norm(sy.term) = v_tokens[v_i]
      UNION
      SELECT public.catalog_search_norm(sy.term) FROM public.catalog_search_synonyms sy
        WHERE sy.active AND sy.bidirectional AND public.catalog_search_norm(sy.synonym) = v_tokens[v_i]
    ) f WHERE f IS NOT NULL AND length(f) > 0;

    SELECT string_agg(
             CASE WHEN v_i = v_ntok THEN '(' || replace(x, ' ', ' & ') || ' | ' || replace(x, ' ', ' & ') || ':*)'
                  ELSE '(' || replace(x, ' ', ' & ') || ')' END, ' | ')
      INTO v_group
    FROM unnest(v_forms) AS x;

    IF v_group IS NULL THEN CONTINUE; END IF;
    IF v_and <> '' THEN v_and := v_and || ' & '; END IF;
    v_and := v_and || '(' || v_group || ')';
  END LOOP;

  BEGIN
    v_tsq := to_tsquery('italian', v_and);
  EXCEPTION WHEN OTHERS THEN
    v_tsq := plainto_tsquery('italian', v_norm);
  END;

  CREATE TEMP TABLE IF NOT EXISTS _cs_tmp (x int) ON COMMIT DROP;

  RETURN QUERY
  WITH base AS (
    SELECT i.*, coalesce(o.boost, 0) AS boost
    FROM public.catalog_search_index i
    LEFT JOIN public.catalog_search_product_overrides o ON o.cdpar = i.cdpar
    WHERE coalesce(o.excluded_from_search, false) = false
      AND (p_channel = 'pim' OR (p_channel = 'b2b' AND i.b2b_visible) OR (p_channel = 'agent' AND i.agent_visible))
      AND (p_allowed_cdpars IS NULL OR i.cdpar = ANY (p_allowed_cdpars))
      AND (p_brand_codes IS NULL OR i.clas2 = ANY (p_brand_codes))
      AND (p_depar IS NULL OR i.depar = ANY (p_depar))
      AND (p_categoria IS NULL OR i.categoria = ANY (p_categoria))
      AND (p_gamma IS NULL OR i.gamma = ANY (p_gamma))
      AND (p_tags IS NULL OR i.tags && p_tags)
  ),
  code_hits AS (
    SELECT b.*,
      CASE
        WHEN b.cdpar = v_norm OR b.ean = v_norm OR v_norm = ANY (b.ean_extra) THEN (w->>'exact_code')::numeric
        WHEN v_numeric AND b.cdpar LIKE v_norm || '%' THEN (w->>'prefix_code')::numeric
        WHEN NOT v_numeric AND v_ntok = 1 AND length(v_norm) >= 3 AND b.cdpar LIKE replace(v_norm, ' ', '') || '%' THEN (w->>'prefix_code')::numeric
        ELSE 0
      END AS code_score
    FROM base b
    WHERE b.cdpar = v_norm OR b.ean = v_norm OR v_norm = ANY (b.ean_extra)
       OR (v_numeric AND b.cdpar LIKE v_norm || '%')
       OR (v_ntok = 1 AND length(v_norm) >= 3 AND b.cdpar LIKE replace(v_norm, ' ', '') || '%')
  ),
  lex_hits AS (
    SELECT b.*, 0::numeric AS code_score
    FROM base b
    WHERE NOT v_numeric
      AND (b.fts_short @@ v_tsq OR (v_desc AND b.fts_all @@ v_tsq))
  ),
  cand AS (
    SELECT * FROM code_hits
    UNION
    SELECT * FROM lex_hits
  ),
  fuzzy_hits AS (
    SELECT b.*, 0::numeric AS code_score
    FROM base b
    WHERE c.fuzzy_enabled
      AND NOT v_numeric
      AND length(v_norm) >= c.fuzzy_min_chars
      AND (SELECT count(*) FROM cand) < c.fuzzy_fallback_count
      AND similarity(b.short_norm, v_norm) >= c.fuzzy_threshold
    LIMIT 200
  ),
  allc AS (
    SELECT * FROM cand
    UNION
    SELECT * FROM fuzzy_hits
  ),
  scored AS (
    SELECT
      a.cdpar, a.visible_cdpar, a.cod_padre, a.brand_name, a.short_norm, a.boost,
      coalesce(nullif(a.titolo_b2b, ''), a.b2b_product_title, a.depar, a.cdpar) AS title,
      a.code_score,
      (SELECT count(*) FROM unnest(v_tokens) t WHERE a.short_norm ~ ('(^| )' || t || '( |$)'))::numeric AS word_hits,
      (a.fts_title @@ v_tsq) AS lex_title,
      (a.fts_taxo @@ v_tsq) AS lex_taxo,
      (a.fts_desc @@ v_tsq) AS lex_desc,
      (v_last <> '' AND a.short_norm ~ ('(^| )' || v_last)) AS prefix_hit,
      (a.brand_name IS NOT NULL AND public.catalog_search_norm(a.brand_name) ~ ('(^| )' || v_tokens[1])) AS brand_hit,
      CASE WHEN c.fuzzy_enabled THEN similarity(a.short_norm, v_norm) ELSE 0 END AS sim
    FROM allc a
  ),
  final AS (
    SELECT
      s.*,
      (
        s.code_score
        + (CASE WHEN s.short_norm = v_norm THEN (w->>'title_exact')::numeric ELSE 0 END)
        + ((w->>'title_word')::numeric * s.word_hits / v_ntok)
        + (CASE WHEN s.lex_title THEN (w->>'title_lexeme')::numeric ELSE 0 END)
        + (CASE WHEN s.prefix_hit THEN (w->>'prefix_last_word')::numeric ELSE 0 END)
        + (CASE WHEN s.lex_taxo THEN (w->>'taxonomy')::numeric ELSE 0 END)
        + (CASE WHEN s.brand_hit THEN (w->>'brand_tag')::numeric ELSE 0 END)
        + (CASE WHEN v_desc AND s.lex_desc AND NOT s.lex_title AND NOT s.lex_taxo
                THEN (w->>'description')::numeric ELSE 0 END)
        + (CASE WHEN NOT s.lex_title AND NOT s.lex_taxo AND NOT s.lex_desc AND s.code_score = 0
                THEN (w->>'fuzzy')::numeric * s.sim ELSE 0 END)
        + s.boost
      ) AS total_score
    FROM scored s
  ),
  collapsed AS (
    SELECT DISTINCT ON (f.visible_cdpar)
      f.visible_cdpar AS g_visible,
      f.cdpar AS g_matched,
      f.cod_padre AS g_padre,
      f.title AS g_title,
      f.brand_name AS g_brand,
      f.total_score AS g_score,
      f.lex_title, f.lex_taxo, f.lex_desc, f.prefix_hit, f.brand_hit, f.code_score, f.sim, f.word_hits
    FROM final f
    WHERE f.total_score > 0
    ORDER BY f.visible_cdpar, f.total_score DESC, f.cdpar ASC
  ),
  ranked AS (
    SELECT co.*, count(*) OVER () AS tot
    FROM collapsed co
    ORDER BY co.g_score DESC, co.g_visible ASC
    LIMIT v_limit OFFSET v_offset
  )
  SELECT
    r.g_visible,
    r.g_visible,
    r.g_matched,
    r.g_title,
    r.g_brand,
    r.g_padre,
    round(r.g_score, 2),
    (SELECT array_remove(ARRAY[
        CASE WHEN r.code_score > 0 THEN 'codice' END,
        CASE WHEN r.lex_title THEN 'titolo' END,
        CASE WHEN r.lex_taxo THEN 'tassonomia' END,
        CASE WHEN r.lex_desc THEN 'descrizione' END,
        CASE WHEN r.brand_hit THEN 'brand' END
      ], NULL)),
    CASE WHEN p_debug THEN jsonb_build_object(
      'code_score', r.code_score,
      'word_hits', r.word_hits,
      'tokens', to_jsonb(v_tokens),
      'lex_title', r.lex_title,
      'lex_taxo', r.lex_taxo,
      'lex_desc', r.lex_desc,
      'prefix', r.prefix_hit,
      'similarity', round(r.sim::numeric, 3),
      'tsquery', v_tsq::text,
      'kind', CASE
        WHEN r.code_score > 0 THEN 'codice'
        WHEN r.word_hits >= v_ntok THEN 'originale'
        WHEN r.lex_title OR r.lex_taxo THEN 'singolare/plurale o sinonimo'
        WHEN r.prefix_hit THEN 'prefisso'
        WHEN r.lex_desc THEN 'descrizione'
        ELSE 'fuzzy' END
    ) ELSE '{}'::jsonb END,
    r.tot,
    (v_offset + v_limit) < r.tot,
    c.version
  FROM ranked r;
END;
$$;

REVOKE ALL ON FUNCTION public.catalog_search_v2(text, integer, integer, text, text[], text[], text[], text[], text[], text[], boolean) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.catalog_search_v2(text, integer, integer, text, text[], text[], text[], text[], text[], text[], boolean) TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.get_catalog_search_config() TO anon, authenticated, service_role;
```

### 20260811151928_a17f6236-4300-4e96-afe5-3af8f11cac89.sql

```sql
CREATE OR REPLACE FUNCTION public.catalog_search_v2(
  p_query text,
  p_limit integer DEFAULT 30,
  p_offset integer DEFAULT 0,
  p_channel text DEFAULT 'pim',
  p_allowed_cdpars text[] DEFAULT NULL,
  p_brand_codes text[] DEFAULT NULL,
  p_depar text[] DEFAULT NULL,
  p_categoria text[] DEFAULT NULL,
  p_gamma text[] DEFAULT NULL,
  p_tags text[] DEFAULT NULL,
  p_debug boolean DEFAULT false
)
RETURNS TABLE(
  cdpar text,
  visible_cdpar text,
  matched_cdpar text,
  title text,
  brand_name text,
  cod_padre text,
  score numeric,
  match_fields text[],
  match_reasons jsonb,
  total_count bigint,
  has_more boolean,
  config_version integer
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  c record;
  v_norm text;
  v_tokens text[] := '{}';
  v_last text := '';
  v_tsq tsquery;
  v_numeric boolean := false;
  v_limit int := greatest(1, least(coalesce(p_limit, 30), 200));
  v_offset int := greatest(0, coalesce(p_offset, 0));
  v_and text := '';
  v_group text;
  v_forms text[];
  v_i int;
  v_ntok int;
  v_desc boolean;
  w jsonb;
BEGIN
  SELECT * INTO c FROM public.catalog_search_config WHERE id;
  w := c.weights;
  v_desc := c.description_search_enabled;

  v_norm := public.catalog_search_norm(p_query);
  IF v_norm = '' THEN RETURN; END IF;

  SELECT array_agg(t ORDER BY ord) INTO v_tokens
  FROM (
    SELECT t, ord FROM unnest(string_to_array(v_norm, ' ')) WITH ORDINALITY AS x(t, ord)
    WHERE length(t) > 0
      AND NOT EXISTS (
        SELECT 1 FROM public.catalog_search_exclusions e
        WHERE e.active AND e.exclusion_type = 'ignored'
          AND public.catalog_search_norm(e.term) = x.t
      )
  ) s;

  IF v_tokens IS NULL OR array_length(v_tokens, 1) IS NULL THEN RETURN; END IF;
  v_ntok := array_length(v_tokens, 1);
  v_last := v_tokens[v_ntok];
  v_numeric := (v_ntok = 1 AND v_tokens[1] ~ '^[0-9]{3,}$');

  IF NOT v_numeric AND length(replace(v_norm, ' ', '')) < c.min_chars THEN RETURN; END IF;

  FOR v_i IN 1..v_ntok LOOP
    SELECT array_agg(DISTINCT f) INTO v_forms
    FROM (
      SELECT v_tokens[v_i] AS f
      UNION
      SELECT public.catalog_search_norm(sy.synonym) FROM public.catalog_search_synonyms sy
        WHERE sy.active AND public.catalog_search_norm(sy.term) = v_tokens[v_i]
      UNION
      SELECT public.catalog_search_norm(sy.term) FROM public.catalog_search_synonyms sy
        WHERE sy.active AND sy.bidirectional AND public.catalog_search_norm(sy.synonym) = v_tokens[v_i]
    ) f WHERE f IS NOT NULL AND length(f) > 0;

    SELECT string_agg(
             CASE WHEN v_i = v_ntok THEN '(' || replace(x, ' ', ' & ') || ' | ' || replace(x, ' ', ' & ') || ':*)'
                  ELSE '(' || replace(x, ' ', ' & ') || ')' END, ' | ')
      INTO v_group
    FROM unnest(v_forms) AS x;

    IF v_group IS NULL THEN CONTINUE; END IF;
    IF v_and <> '' THEN v_and := v_and || ' & '; END IF;
    v_and := v_and || '(' || v_group || ')';
  END LOOP;

  BEGIN
    v_tsq := to_tsquery('italian', v_and);
  EXCEPTION WHEN OTHERS THEN
    v_tsq := plainto_tsquery('italian', v_norm);
  END;

  RETURN QUERY
  WITH base AS (
    SELECT i.*, coalesce(o.boost, 0) AS boost
    FROM public.catalog_search_index i
    LEFT JOIN public.catalog_search_product_overrides o ON o.cdpar = i.cdpar
    WHERE coalesce(o.excluded_from_search, false) = false
      AND (p_channel = 'pim' OR (p_channel = 'b2b' AND i.b2b_visible) OR (p_channel = 'agent' AND i.agent_visible))
      AND (p_allowed_cdpars IS NULL OR i.cdpar = ANY (p_allowed_cdpars))
      AND (p_brand_codes IS NULL OR i.clas2 = ANY (p_brand_codes))
      AND (p_depar IS NULL OR i.depar = ANY (p_depar))
      AND (p_categoria IS NULL OR i.categoria = ANY (p_categoria))
      AND (p_gamma IS NULL OR i.gamma = ANY (p_gamma))
      AND (p_tags IS NULL OR i.tags && p_tags)
  ),
  code_hits AS (
    SELECT b.*,
      CASE
        WHEN b.cdpar = v_norm OR b.ean = v_norm OR v_norm = ANY (b.ean_extra) THEN (w->>'exact_code')::numeric
        ELSE (w->>'prefix_code')::numeric
      END AS code_score
    FROM base b
    WHERE b.cdpar = v_norm OR b.ean = v_norm OR v_norm = ANY (b.ean_extra)
       OR (v_numeric AND b.cdpar LIKE v_norm || '%')
       OR (v_ntok = 1 AND length(v_norm) >= 3 AND b.cdpar LIKE replace(v_norm, ' ', '') || '%')
  ),
  lex_hits AS (
    SELECT b.*, 0::numeric AS code_score
    FROM base b
    WHERE NOT v_numeric
      AND (b.fts_short @@ v_tsq OR (v_desc AND b.fts_all @@ v_tsq))
  ),
  cand AS (
    SELECT * FROM code_hits
    UNION
    SELECT * FROM lex_hits
  ),
  fuzzy_hits AS (
    SELECT b.*, 0::numeric AS code_score
    FROM base b
    WHERE c.fuzzy_enabled
      AND NOT v_numeric
      AND length(v_norm) >= c.fuzzy_min_chars
      AND (SELECT count(*) FROM cand) < c.fuzzy_fallback_count
      AND similarity(b.short_norm, v_norm) >= c.fuzzy_threshold
    LIMIT 200
  ),
  allc AS (
    SELECT * FROM cand
    UNION
    SELECT * FROM fuzzy_hits
  ),
  scored AS (
    SELECT
      a.cdpar, a.visible_cdpar, a.cod_padre, a.brand_name, a.short_norm, a.boost,
      coalesce(nullif(a.titolo_b2b, ''), a.b2b_product_title, a.depar, a.cdpar) AS title,
      a.code_score,
      (SELECT count(*) FROM unnest(v_tokens) t WHERE a.short_norm ~ ('(^| )' || t || '( |$)'))::numeric AS word_hits,
      (a.fts_title @@ v_tsq) AS lex_title,
      (a.fts_taxo @@ v_tsq) AS lex_taxo,
      (a.fts_desc @@ v_tsq) AS lex_desc,
      (v_last <> '' AND a.short_norm ~ ('(^| )' || v_last)) AS prefix_hit,
      (a.brand_name IS NOT NULL AND public.catalog_search_norm(a.brand_name) ~ ('(^| )' || v_tokens[1])) AS brand_hit,
      CASE WHEN c.fuzzy_enabled THEN similarity(a.short_norm, v_norm) ELSE 0 END AS sim
    FROM allc a
  ),
  final AS (
    SELECT
      s.*,
      (
        s.code_score
        + (CASE WHEN s.short_norm = v_norm THEN (w->>'title_exact')::numeric ELSE 0 END)
        + ((w->>'title_word')::numeric * s.word_hits / v_ntok)
        + (CASE WHEN s.lex_title THEN (w->>'title_lexeme')::numeric ELSE 0 END)
        + (CASE WHEN s.prefix_hit THEN (w->>'prefix_last_word')::numeric ELSE 0 END)
        + (CASE WHEN s.lex_taxo THEN (w->>'taxonomy')::numeric ELSE 0 END)
        + (CASE WHEN s.brand_hit THEN (w->>'brand_tag')::numeric ELSE 0 END)
        + (CASE WHEN v_desc AND s.lex_desc AND NOT s.lex_title AND NOT s.lex_taxo
                THEN (w->>'description')::numeric ELSE 0 END)
        + (CASE WHEN NOT s.lex_title AND NOT s.lex_taxo AND NOT s.lex_desc AND s.code_score = 0
                THEN (w->>'fuzzy')::numeric * s.sim ELSE 0 END)
        + s.boost
      ) AS total_score
    FROM scored s
  ),
  collapsed AS (
    SELECT DISTINCT ON (f.visible_cdpar)
      f.visible_cdpar AS g_visible,
      f.cdpar AS g_matched,
      f.cod_padre AS g_padre,
      f.title AS g_title,
      f.brand_name AS g_brand,
      f.total_score AS g_score,
      f.lex_title, f.lex_taxo, f.lex_desc, f.prefix_hit, f.brand_hit, f.code_score, f.sim, f.word_hits
    FROM final f
    WHERE f.total_score > 0
    ORDER BY f.visible_cdpar, f.total_score DESC, f.cdpar ASC
  ),
  ranked AS (
    SELECT co.*, count(*) OVER () AS tot
    FROM collapsed co
    ORDER BY co.g_score DESC, co.g_visible ASC
    LIMIT v_limit OFFSET v_offset
  )
  SELECT
    r.g_visible,
    r.g_visible,
    r.g_matched,
    r.g_title,
    r.g_brand,
    r.g_padre,
    round(r.g_score, 2),
    (SELECT array_remove(ARRAY[
        CASE WHEN r.code_score > 0 THEN 'codice' END,
        CASE WHEN r.lex_title THEN 'titolo' END,
        CASE WHEN r.lex_taxo THEN 'tassonomia' END,
        CASE WHEN r.lex_desc THEN 'descrizione' END,
        CASE WHEN r.brand_hit THEN 'brand' END
      ], NULL)),
    CASE WHEN p_debug THEN jsonb_build_object(
      'code_score', r.code_score,
      'word_hits', r.word_hits,
      'tokens', to_jsonb(v_tokens),
      'lex_title', r.lex_title,
      'lex_taxo', r.lex_taxo,
      'lex_desc', r.lex_desc,
      'prefix', r.prefix_hit,
      'similarity', round(r.sim::numeric, 3),
      'tsquery', v_tsq::text,
      'kind', CASE
        WHEN r.code_score > 0 THEN 'codice'
        WHEN r.word_hits >= v_ntok THEN 'originale'
        WHEN r.lex_title OR r.lex_taxo THEN 'singolare/plurale o sinonimo'
        WHEN r.prefix_hit THEN 'prefisso'
        WHEN r.lex_desc THEN 'descrizione'
        ELSE 'fuzzy' END
    ) ELSE '{}'::jsonb END,
    r.tot,
    (v_offset + v_limit) < r.tot,
    c.version
  FROM ranked r;
END;
$$;
```

### 20260811152355_05c38096-c117-4927-babe-f2afae146acd.sql

```sql
CREATE OR REPLACE FUNCTION public.catalog_search_v2(
  p_query text,
  p_limit integer DEFAULT 30,
  p_offset integer DEFAULT 0,
  p_channel text DEFAULT 'pim',
  p_allowed_cdpars text[] DEFAULT NULL,
  p_brand_codes text[] DEFAULT NULL,
  p_depar text[] DEFAULT NULL,
  p_categoria text[] DEFAULT NULL,
  p_gamma text[] DEFAULT NULL,
  p_tags text[] DEFAULT NULL,
  p_debug boolean DEFAULT false
)
RETURNS TABLE(
  cdpar text,
  visible_cdpar text,
  matched_cdpar text,
  title text,
  brand_name text,
  cod_padre text,
  score numeric,
  match_fields text[],
  match_reasons jsonb,
  total_count bigint,
  has_more boolean,
  config_version integer
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  c record;
  v_norm text;
  v_tokens text[] := '{}';
  v_last text := '';
  v_tsq tsquery;
  v_numeric boolean := false;
  v_limit int := greatest(1, least(coalesce(p_limit, 30), 200));
  v_offset int := greatest(0, coalesce(p_offset, 0));
  v_and text := '';
  v_group text;
  v_forms text[];
  v_i int;
  v_ntok int;
  v_desc boolean;
  w jsonb;
BEGIN
  SELECT * INTO c FROM public.catalog_search_config WHERE id;
  w := c.weights;
  v_desc := c.description_search_enabled;

  v_norm := public.catalog_search_norm(p_query);
  IF v_norm = '' THEN RETURN; END IF;

  SELECT array_agg(t ORDER BY ord) INTO v_tokens
  FROM (
    SELECT t, ord FROM unnest(string_to_array(v_norm, ' ')) WITH ORDINALITY AS x(t, ord)
    WHERE length(t) > 0
      AND NOT EXISTS (
        SELECT 1 FROM public.catalog_search_exclusions e
        WHERE e.active AND e.exclusion_type = 'ignored'
          AND public.catalog_search_norm(e.term) = x.t
      )
  ) s;

  IF v_tokens IS NULL OR array_length(v_tokens, 1) IS NULL THEN RETURN; END IF;
  v_ntok := array_length(v_tokens, 1);
  v_last := v_tokens[v_ntok];
  v_numeric := (v_ntok = 1 AND v_tokens[1] ~ '^[0-9]{3,}$');

  IF NOT v_numeric AND length(replace(v_norm, ' ', '')) < c.min_chars THEN RETURN; END IF;

  FOR v_i IN 1..v_ntok LOOP
    SELECT array_agg(DISTINCT f) INTO v_forms
    FROM (
      SELECT v_tokens[v_i] AS f
      UNION
      SELECT public.catalog_search_norm(sy.synonym) FROM public.catalog_search_synonyms sy
        WHERE sy.active AND public.catalog_search_norm(sy.term) = v_tokens[v_i]
      UNION
      SELECT public.catalog_search_norm(sy.term) FROM public.catalog_search_synonyms sy
        WHERE sy.active AND sy.bidirectional AND public.catalog_search_norm(sy.synonym) = v_tokens[v_i]
    ) f WHERE f IS NOT NULL AND length(f) > 0;

    SELECT string_agg(
             CASE WHEN v_i = v_ntok THEN '(' || replace(x, ' ', ' & ') || ' | ' || replace(x, ' ', ' & ') || ':*)'
                  ELSE '(' || replace(x, ' ', ' & ') || ')' END, ' | ')
      INTO v_group
    FROM unnest(v_forms) AS x;

    IF v_group IS NULL THEN CONTINUE; END IF;
    IF v_and <> '' THEN v_and := v_and || ' & '; END IF;
    v_and := v_and || '(' || v_group || ')';
  END LOOP;

  BEGIN
    v_tsq := to_tsquery('italian', v_and);
  EXCEPTION WHEN OTHERS THEN
    v_tsq := plainto_tsquery('italian', v_norm);
  END;

  RETURN QUERY
  WITH base AS (
    SELECT i.*, coalesce(o.boost, 0) AS boost
    FROM public.catalog_search_index i
    LEFT JOIN public.catalog_search_product_overrides o ON o.cdpar = i.cdpar
    WHERE coalesce(o.excluded_from_search, false) = false
      AND (p_channel = 'pim' OR (p_channel = 'b2b' AND i.b2b_visible) OR (p_channel = 'agent' AND i.agent_visible))
      AND (p_allowed_cdpars IS NULL OR i.cdpar = ANY (p_allowed_cdpars))
      AND (p_brand_codes IS NULL OR i.clas2 = ANY (p_brand_codes))
      AND (p_depar IS NULL OR i.depar = ANY (p_depar))
      AND (p_categoria IS NULL OR i.categoria = ANY (p_categoria))
      AND (p_gamma IS NULL OR i.gamma = ANY (p_gamma))
      AND (p_tags IS NULL OR i.tags && p_tags)
  ),
  code_hits AS (
    SELECT b.*,
      CASE
        WHEN b.cdpar = v_norm OR b.ean = v_norm OR v_norm = ANY (b.ean_extra) THEN (w->>'exact_code')::numeric
        ELSE (w->>'prefix_code')::numeric
      END AS code_score
    FROM base b
    WHERE b.cdpar = v_norm OR b.ean = v_norm OR v_norm = ANY (b.ean_extra)
       OR (v_numeric AND b.cdpar LIKE v_norm || '%')
       OR (v_ntok = 1 AND length(v_norm) >= 3 AND b.cdpar LIKE replace(v_norm, ' ', '') || '%')
  ),
  lex_hits AS (
    SELECT b.*, 0::numeric AS code_score
    FROM base b
    WHERE NOT v_numeric
      AND (b.fts_short @@ v_tsq OR (v_desc AND b.fts_all @@ v_tsq))
  ),
  cand AS (
    SELECT * FROM code_hits
    UNION
    SELECT * FROM lex_hits
  ),
  fuzzy_hits AS (
    SELECT b.*, 0::numeric AS code_score
    FROM base b
    WHERE c.fuzzy_enabled
      AND NOT v_numeric
      AND length(v_norm) >= c.fuzzy_min_chars
      AND (SELECT count(*) FROM cand) < c.fuzzy_fallback_count
      AND similarity(b.short_norm, v_norm) >= c.fuzzy_threshold
    LIMIT 200
  ),
  allc AS (
    SELECT * FROM cand
    UNION
    SELECT * FROM fuzzy_hits
  ),
  scored AS (
    SELECT
      a.cdpar, a.visible_cdpar, a.cod_padre, a.brand_name, a.short_norm, a.boost,
      coalesce(nullif(a.titolo_b2b, ''), a.b2b_product_title, a.depar, a.cdpar) AS title,
      a.code_score,
      (SELECT count(*) FROM unnest(v_tokens) t WHERE a.short_norm ~ ('(^| )' || t || '( |$)'))::numeric AS word_hits,
      (a.fts_title @@ v_tsq) AS lex_title,
      (a.fts_taxo @@ v_tsq) AS lex_taxo,
      (a.fts_desc @@ v_tsq) AS lex_desc,
      (v_last <> '' AND a.short_norm ~ ('(^| )' || v_last)) AS prefix_hit,
      (a.brand_name IS NOT NULL AND public.catalog_search_norm(a.brand_name) ~ ('(^| )' || v_tokens[1])) AS brand_hit,
      CASE WHEN c.fuzzy_enabled THEN similarity(a.short_norm, v_norm)::numeric ELSE 0::numeric END AS sim
    FROM allc a
  ),
  final AS (
    SELECT
      s.*,
      (
        s.code_score
        + (CASE WHEN s.short_norm = v_norm THEN (w->>'title_exact')::numeric ELSE 0 END)
        + ((w->>'title_word')::numeric * s.word_hits / v_ntok)
        + (CASE WHEN s.lex_title THEN (w->>'title_lexeme')::numeric ELSE 0 END)
        + (CASE WHEN s.prefix_hit THEN (w->>'prefix_last_word')::numeric ELSE 0 END)
        + (CASE WHEN s.lex_taxo THEN (w->>'taxonomy')::numeric ELSE 0 END)
        + (CASE WHEN s.brand_hit THEN (w->>'brand_tag')::numeric ELSE 0 END)
        + (CASE WHEN v_desc AND s.lex_desc AND NOT s.lex_title AND NOT s.lex_taxo
                THEN (w->>'description')::numeric ELSE 0 END)
        + (CASE WHEN NOT s.lex_title AND NOT s.lex_taxo AND NOT s.lex_desc AND s.code_score = 0
                THEN (w->>'fuzzy')::numeric * s.sim ELSE 0 END)
        + s.boost
      )::numeric AS total_score
    FROM scored s
  ),
  collapsed AS (
    SELECT DISTINCT ON (f.visible_cdpar)
      f.visible_cdpar AS g_visible,
      f.cdpar AS g_matched,
      f.cod_padre AS g_padre,
      f.title AS g_title,
      f.brand_name AS g_brand,
      f.total_score AS g_score,
      f.lex_title, f.lex_taxo, f.lex_desc, f.prefix_hit, f.brand_hit, f.code_score, f.sim, f.word_hits
    FROM final f
    WHERE f.total_score > 0
    ORDER BY f.visible_cdpar, f.total_score DESC, f.cdpar ASC
  ),
  ranked AS (
    SELECT co.*, count(*) OVER () AS tot
    FROM collapsed co
    ORDER BY co.g_score DESC, co.g_visible ASC
    LIMIT v_limit OFFSET v_offset
  )
  SELECT
    r.g_visible,
    r.g_visible,
    r.g_matched,
    r.g_title,
    r.g_brand,
    r.g_padre,
    round(r.g_score::numeric, 2),
    (SELECT array_remove(ARRAY[
        CASE WHEN r.code_score > 0 THEN 'codice' END,
        CASE WHEN r.lex_title THEN 'titolo' END,
        CASE WHEN r.lex_taxo THEN 'tassonomia' END,
        CASE WHEN r.lex_desc THEN 'descrizione' END,
        CASE WHEN r.brand_hit THEN 'brand' END
      ], NULL)),
    CASE WHEN p_debug THEN jsonb_build_object(
      'code_score', r.code_score,
      'word_hits', r.word_hits,
      'tokens', to_jsonb(v_tokens),
      'lex_title', r.lex_title,
      'lex_taxo', r.lex_taxo,
      'lex_desc', r.lex_desc,
      'prefix', r.prefix_hit,
      'similarity', round(r.sim::numeric, 3),
      'tsquery', v_tsq::text,
      'kind', CASE
        WHEN r.code_score > 0 THEN 'codice'
        WHEN r.word_hits >= v_ntok THEN 'originale'
        WHEN r.lex_title OR r.lex_taxo THEN 'singolare/plurale o sinonimo'
        WHEN r.prefix_hit THEN 'prefisso'
        WHEN r.lex_desc THEN 'descrizione'
        ELSE 'fuzzy' END
    ) ELSE '{}'::jsonb END,
    r.tot,
    (v_offset + v_limit) < r.tot,
    c.version
  FROM ranked r;
END;
$$;
```

### 20260811153046_2cbf5fd6-2209-403a-96fa-52e674e1e34b.sql

```sql
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'supabase_read_only_user') THEN
    EXECUTE 'GRANT EXECUTE ON FUNCTION public.catalog_search_v2(text, integer, integer, text, text[], text[], text[], text[], text[], text[], boolean) TO supabase_read_only_user';
  END IF;
END $$;
```

### 20260812064448_33de4feb-dc26-4d11-ad0c-15a9606ecfbf.sql

```sql
CREATE OR REPLACE FUNCTION public.catalog_search_stem(p_text text)
RETURNS text
LANGUAGE sql
IMMUTABLE
SET search_path = public
AS $$
  SELECT coalesce(
    (SELECT string_agg(
       CASE WHEN length(w) >= 5 AND right(w, 1) ~ '[aeiou]' THEN left(w, length(w) - 1) ELSE w END,
       ' ' ORDER BY ord)
     FROM unnest(string_to_array(coalesce(p_text, ''), ' ')) WITH ORDINALITY AS t(w, ord)
     WHERE length(w) > 0),
  '');
$$;

CREATE OR REPLACE FUNCTION public.catalog_search_upsert(p_cdpars text[])
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_count integer := 0;
BEGIN
  IF p_cdpars IS NULL OR array_length(p_cdpars, 1) IS NULL THEN
    RETURN 0;
  END IF;

  WITH src AS (
    SELECT
      btrim(a.cdpar) AS cdpar,
      a.cdpar        AS raw_cdpar,
      nullif(btrim(coalesce(a.cod_padre, '')), '') AS cod_padre,
      nullif(btrim(coalesce(a.barcd, '')), '')     AS ean,
      a.titolo_b2b,
      a.b2b_product_title,
      a.descrizione_variante,
      nullif(btrim(coalesce(a.depar, '')), '')     AS depar,
      a.attributes->>'reparto'                     AS reparto_code,
      a.attributes->>'gamma'                       AS gamma_code,
      nullif(btrim(coalesce(a.clmer, '')), '')     AS clmer,
      nullif(btrim(coalesce(a.clas1, '')), '')     AS clas1,
      nullif(btrim(coalesce(a.clas2, '')), '')     AS clas2,
      coalesce(a.tags, '{}')                       AS tags,
      coalesce(a.b2b_online_effective, false)      AS b2b_visible,
      a.updated_at,
      coalesce(a.descrizione, '') || ' ' || coalesce(a.descrizione_b2b, '') || ' '
        || coalesce(a.b2b_product_description, '') || ' ' || coalesce(a.description_marketing, '') AS desc_raw,
      (
        SELECT string_agg(coalesce(v.value->>'value', ''), ' ')
        FROM jsonb_each(coalesce(a.attributes->'gamma_attrs', '{}'::jsonb)) AS v(key, value)
        WHERE jsonb_typeof(v.value) = 'object'
      ) AS attrs_text,
      (
        SELECT array_agg(DISTINCT btrim(b.wcbda))
        FROM public.archivio_codici_barre_fraschetti b
        WHERE btrim(b.wcdpa) = btrim(a.cdpar)
          AND coalesce(btrim(b.wcbda), '') <> ''
          AND btrim(b.wcbda) IS DISTINCT FROM nullif(btrim(coalesce(a.barcd, '')), '')
      ) AS ean_extra
    FROM public.archivio_articoli_fraschetti a
    WHERE btrim(a.cdpar) = ANY (SELECT btrim(x) FROM unnest(p_cdpars) AS x)
  ),
  enriched AS (
    SELECT
      s.*,
      coalesce(br.display_name, br.nome_as400_brand, lv_brand.label) AS brand_name,
      lv_rep.label   AS reparto_label,
      lv_gam.label   AS gamma_label,
      lv_clmer.label AS categoria_label
    FROM src s
    LEFT JOIN public.archivio_brand_fraschetti br ON br.clas2 = s.clas2
    LEFT JOIN public.lookup_values lv_brand ON lv_brand.category = 'clas2' AND lv_brand.code = s.clas2
    LEFT JOIN public.lookup_values lv_rep   ON lv_rep.category = 'reparto' AND lv_rep.code = s.reparto_code
    LEFT JOIN public.lookup_values lv_gam   ON lv_gam.category = 'gamma'   AND lv_gam.code = s.gamma_code
    LEFT JOIN public.lookup_values lv_clmer ON lv_clmer.category = 'clmer' AND lv_clmer.code = s.clmer
  ),
  final AS (
    SELECT
      e.cdpar,
      e.raw_cdpar,
      e.cod_padre,
      coalesce(e.cod_padre, e.cdpar) AS visible_cdpar,
      e.ean,
      coalesce(e.ean_extra, '{}')    AS ean_extra,
      e.titolo_b2b,
      e.b2b_product_title,
      e.descrizione_variante,
      e.depar,
      coalesce(e.reparto_label, replace(coalesce(e.reparto_code, ''), '_', ' ')) AS reparto,
      e.categoria_label AS categoria,
      coalesce(e.gamma_label, replace(coalesce(e.gamma_code, ''), '_', ' '))     AS gamma,
      e.clmer, e.clas1, e.clas2,
      e.clas2 AS brand_code,
      e.brand_name,
      e.tags,
      e.attrs_text,
      e.b2b_visible,
      e.b2b_visible AS agent_visible,
      public.catalog_search_norm(
        coalesce(e.titolo_b2b, '') || ' ' || coalesce(e.b2b_product_title, '') || ' '
        || coalesce(e.descrizione_variante, '') || ' ' || coalesce(e.depar, '')
      ) AS short_norm,
      public.catalog_search_norm(
        coalesce(e.reparto_label, replace(coalesce(e.reparto_code, ''), '_', ' ')) || ' '
        || coalesce(e.categoria_label, '') || ' '
        || coalesce(e.gamma_label, replace(coalesce(e.gamma_code, ''), '_', ' ')) || ' '
        || coalesce(e.brand_name, '') || ' ' || coalesce(array_to_string(e.tags, ' '), '') || ' '
        || coalesce(e.attrs_text, '')
      ) AS taxo_norm,
      public.catalog_search_norm(e.desc_raw) AS desc_norm,
      e.updated_at
    FROM enriched e
  )
  INSERT INTO public.catalog_search_index AS t (
    cdpar, raw_cdpar, cod_padre, visible_cdpar, ean, ean_extra, titolo_b2b, b2b_product_title,
    descrizione_variante, depar, reparto, categoria, gamma, clmer, clas1, clas2, brand_code, brand_name,
    tags, attrs_text, b2b_visible, agent_visible, short_norm, taxo_norm, desc_norm,
    fts_title, fts_taxo, fts_desc, source_updated_at, indexed_at, search_config_version
  )
  SELECT
    f.cdpar, f.raw_cdpar, f.cod_padre, f.visible_cdpar, f.ean, f.ean_extra, f.titolo_b2b, f.b2b_product_title,
    f.descrizione_variante, f.depar, nullif(btrim(f.reparto), ''), f.categoria, nullif(btrim(f.gamma), ''),
    f.clmer, f.clas1, f.clas2, f.brand_code, f.brand_name,
    f.tags, f.attrs_text, f.b2b_visible, f.agent_visible, f.short_norm, f.taxo_norm, f.desc_norm,
    to_tsvector('simple', public.catalog_search_stem(f.short_norm)),
    to_tsvector('simple', public.catalog_search_stem(f.taxo_norm)),
    to_tsvector('simple', public.catalog_search_stem(f.desc_norm)),
    f.updated_at, now(),
    coalesce((SELECT c.version FROM public.catalog_search_config c WHERE c.id), 1)
  FROM final f
  ON CONFLICT (cdpar) DO UPDATE SET
    raw_cdpar = EXCLUDED.raw_cdpar,
    cod_padre = EXCLUDED.cod_padre,
    visible_cdpar = EXCLUDED.visible_cdpar,
    ean = EXCLUDED.ean,
    ean_extra = EXCLUDED.ean_extra,
    titolo_b2b = EXCLUDED.titolo_b2b,
    b2b_product_title = EXCLUDED.b2b_product_title,
    descrizione_variante = EXCLUDED.descrizione_variante,
    depar = EXCLUDED.depar,
    reparto = EXCLUDED.reparto,
    categoria = EXCLUDED.categoria,
    gamma = EXCLUDED.gamma,
    clmer = EXCLUDED.clmer,
    clas1 = EXCLUDED.clas1,
    clas2 = EXCLUDED.clas2,
    brand_code = EXCLUDED.brand_code,
    brand_name = EXCLUDED.brand_name,
    tags = EXCLUDED.tags,
    attrs_text = EXCLUDED.attrs_text,
    b2b_visible = EXCLUDED.b2b_visible,
    agent_visible = EXCLUDED.agent_visible,
    short_norm = EXCLUDED.short_norm,
    taxo_norm = EXCLUDED.taxo_norm,
    desc_norm = EXCLUDED.desc_norm,
    fts_title = EXCLUDED.fts_title,
    fts_taxo = EXCLUDED.fts_taxo,
    fts_desc = EXCLUDED.fts_desc,
    source_updated_at = EXCLUDED.source_updated_at,
    indexed_at = now(),
    search_config_version = EXCLUDED.search_config_version;

  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END;
$function$;
```

### 20260812064614_0b28fa50-ba48-403a-be07-f07db0e6a344.sql

```sql
CREATE OR REPLACE FUNCTION public.catalog_search_v2(
  p_query text,
  p_limit integer DEFAULT 30,
  p_offset integer DEFAULT 0,
  p_channel text DEFAULT 'pim',
  p_allowed_cdpars text[] DEFAULT NULL,
  p_brand_codes text[] DEFAULT NULL,
  p_depar text[] DEFAULT NULL,
  p_categoria text[] DEFAULT NULL,
  p_gamma text[] DEFAULT NULL,
  p_tags text[] DEFAULT NULL,
  p_debug boolean DEFAULT false
)
RETURNS TABLE(
  cdpar text,
  visible_cdpar text,
  matched_cdpar text,
  title text,
  brand_name text,
  cod_padre text,
  score numeric,
  match_fields text[],
  match_reasons jsonb,
  total_count bigint,
  has_more boolean,
  config_version integer
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  c record;
  v_norm text;
  v_tokens text[] := '{}';
  v_last text := '';
  v_tsq tsquery;
  v_numeric boolean := false;
  v_limit int := greatest(1, least(coalesce(p_limit, 30), 200));
  v_offset int := greatest(0, coalesce(p_offset, 0));
  v_and text := '';
  v_group text;
  v_forms text[];
  v_i int;
  v_ntok int;
  v_desc boolean;
  w jsonb;
BEGIN
  SELECT * INTO c FROM public.catalog_search_config WHERE id;
  w := c.weights;
  v_desc := c.description_search_enabled;

  v_norm := public.catalog_search_norm(p_query);
  IF v_norm = '' THEN RETURN; END IF;

  SELECT array_agg(t ORDER BY ord) INTO v_tokens
  FROM (
    SELECT t, ord FROM unnest(string_to_array(v_norm, ' ')) WITH ORDINALITY AS x(t, ord)
    WHERE length(t) > 0
      AND NOT EXISTS (
        SELECT 1 FROM public.catalog_search_exclusions e
        WHERE e.active AND e.exclusion_type = 'ignored'
          AND public.catalog_search_norm(e.term) = x.t
      )
  ) s;

  IF v_tokens IS NULL OR array_length(v_tokens, 1) IS NULL THEN RETURN; END IF;
  v_ntok := array_length(v_tokens, 1);
  v_last := v_tokens[v_ntok];
  v_numeric := (v_ntok = 1 AND v_tokens[1] ~ '^[0-9]{3,}$');

  IF NOT v_numeric AND length(replace(v_norm, ' ', '')) < c.min_chars THEN RETURN; END IF;

  FOR v_i IN 1..v_ntok LOOP
    SELECT array_agg(DISTINCT f) INTO v_forms
    FROM (
      SELECT public.catalog_search_stem(v_tokens[v_i]) AS f
      UNION
      SELECT public.catalog_search_stem(public.catalog_search_norm(sy.synonym)) FROM public.catalog_search_synonyms sy
        WHERE sy.active AND public.catalog_search_norm(sy.term) = v_tokens[v_i]
      UNION
      SELECT public.catalog_search_stem(public.catalog_search_norm(sy.term)) FROM public.catalog_search_synonyms sy
        WHERE sy.active AND sy.bidirectional AND public.catalog_search_norm(sy.synonym) = v_tokens[v_i]
    ) f WHERE f IS NOT NULL AND length(f) > 0;

    SELECT string_agg(
             CASE WHEN v_i = v_ntok THEN '(' || replace(x, ' ', ' & ') || ' | ' || replace(x, ' ', ' & ') || ':*)'
                  ELSE '(' || replace(x, ' ', ' & ') || ')' END, ' | ')
      INTO v_group
    FROM unnest(v_forms) AS x;

    IF v_group IS NULL THEN CONTINUE; END IF;
    IF v_and <> '' THEN v_and := v_and || ' & '; END IF;
    v_and := v_and || '(' || v_group || ')';
  END LOOP;

  BEGIN
    v_tsq := to_tsquery('simple', v_and);
  EXCEPTION WHEN OTHERS THEN
    v_tsq := plainto_tsquery('simple', public.catalog_search_stem(v_norm));
  END;

  RETURN QUERY
  WITH base AS (
    SELECT i.*, coalesce(o.boost, 0) AS boost
    FROM public.catalog_search_index i
    LEFT JOIN public.catalog_search_product_overrides o ON o.cdpar = i.cdpar
    WHERE coalesce(o.excluded_from_search, false) = false
      AND (p_channel = 'pim' OR (p_channel = 'b2b' AND i.b2b_visible) OR (p_channel = 'agent' AND i.agent_visible))
      AND (p_allowed_cdpars IS NULL OR i.cdpar = ANY (p_allowed_cdpars))
      AND (p_brand_codes IS NULL OR i.clas2 = ANY (p_brand_codes))
      AND (p_depar IS NULL OR i.depar = ANY (p_depar))
      AND (p_categoria IS NULL OR i.categoria = ANY (p_categoria))
      AND (p_gamma IS NULL OR i.gamma = ANY (p_gamma))
      AND (p_tags IS NULL OR i.tags && p_tags)
  ),
  code_hits AS (
    SELECT b.*,
      CASE
        WHEN b.cdpar = v_norm OR b.ean = v_norm OR v_norm = ANY (b.ean_extra) THEN (w->>'exact_code')::numeric
        ELSE (w->>'prefix_code')::numeric
      END AS code_score
    FROM base b
    WHERE b.cdpar = v_norm OR b.ean = v_norm OR v_norm = ANY (b.ean_extra)
       OR (v_numeric AND b.cdpar LIKE v_norm || '%')
       OR (v_ntok = 1 AND length(v_norm) >= 3 AND b.cdpar LIKE replace(v_norm, ' ', '') || '%')
  ),
  lex_hits AS (
    SELECT b.*, 0::numeric AS code_score
    FROM base b
    WHERE NOT v_numeric
      AND (b.fts_short @@ v_tsq OR (v_desc AND b.fts_all @@ v_tsq))
  ),
  cand AS (
    SELECT * FROM code_hits
    UNION
    SELECT * FROM lex_hits
  ),
  fuzzy_hits AS (
    SELECT b.*, 0::numeric AS code_score
    FROM base b
    WHERE c.fuzzy_enabled
      AND NOT v_numeric
      AND length(v_norm) >= c.fuzzy_min_chars
      AND (SELECT count(*) FROM cand) < c.fuzzy_fallback_count
      AND similarity(b.short_norm, v_norm) >= c.fuzzy_threshold
    LIMIT 200
  ),
  allc AS (
    SELECT * FROM cand
    UNION
    SELECT * FROM fuzzy_hits
  ),
  scored AS (
    SELECT
      a.cdpar, a.visible_cdpar, a.cod_padre, a.brand_name, a.short_norm, a.boost,
      coalesce(nullif(a.titolo_b2b, ''), a.b2b_product_title, a.depar, a.cdpar) AS title,
      a.code_score,
      (SELECT count(*) FROM unnest(v_tokens) t WHERE a.short_norm ~ ('(^| )' || t || '( |$)'))::numeric AS word_hits,
      (a.fts_title @@ v_tsq) AS lex_title,
      (a.fts_taxo @@ v_tsq) AS lex_taxo,
      (a.fts_desc @@ v_tsq) AS lex_desc,
      (v_last <> '' AND a.short_norm ~ ('(^| )' || v_last)) AS prefix_hit,
      (a.brand_name IS NOT NULL AND public.catalog_search_norm(a.brand_name) ~ ('(^| )' || v_tokens[1])) AS brand_hit,
      CASE WHEN c.fuzzy_enabled THEN similarity(a.short_norm, v_norm)::numeric ELSE 0::numeric END AS sim
    FROM allc a
  ),
  final AS (
    SELECT
      s.*,
      (
        s.code_score
        + (CASE WHEN s.short_norm = v_norm THEN (w->>'title_exact')::numeric ELSE 0 END)
        + ((w->>'title_word')::numeric * s.word_hits / v_ntok)
        + (CASE WHEN s.lex_title THEN (w->>'title_lexeme')::numeric ELSE 0 END)
        + (CASE WHEN s.prefix_hit THEN (w->>'prefix_last_word')::numeric ELSE 0 END)
        + (CASE WHEN s.lex_taxo THEN (w->>'taxonomy')::numeric ELSE 0 END)
        + (CASE WHEN s.brand_hit THEN (w->>'brand_tag')::numeric ELSE 0 END)
        + (CASE WHEN v_desc AND s.lex_desc AND NOT s.lex_title AND NOT s.lex_taxo
                THEN (w->>'description')::numeric ELSE 0 END)
        + (CASE WHEN NOT s.lex_title AND NOT s.lex_taxo AND NOT s.lex_desc AND s.code_score = 0
                THEN (w->>'fuzzy')::numeric * s.sim ELSE 0 END)
        + s.boost
      )::numeric AS total_score
    FROM scored s
  ),
  collapsed AS (
    SELECT DISTINCT ON (f.visible_cdpar)
      f.visible_cdpar AS g_visible,
      f.cdpar AS g_matched,
      f.cod_padre AS g_padre,
      f.title AS g_title,
      f.brand_name AS g_brand,
      f.total_score AS g_score,
      f.lex_title, f.lex_taxo, f.lex_desc, f.prefix_hit, f.brand_hit, f.code_score, f.sim, f.word_hits
    FROM final f
    WHERE f.total_score > 0
    ORDER BY f.visible_cdpar, f.total_score DESC, f.cdpar ASC
  ),
  ranked AS (
    SELECT co.*, count(*) OVER () AS tot
    FROM collapsed co
    ORDER BY co.g_score DESC, co.g_visible ASC
    LIMIT v_limit OFFSET v_offset
  )
  SELECT
    r.g_visible,
    r.g_visible,
    r.g_matched,
    r.g_title,
    r.g_brand,
    r.g_padre,
    round(r.g_score::numeric, 2),
    (SELECT array_remove(ARRAY[
        CASE WHEN r.code_score > 0 THEN 'codice' END,
        CASE WHEN r.lex_title THEN 'titolo' END,
        CASE WHEN r.lex_taxo THEN 'tassonomia' END,
        CASE WHEN r.lex_desc THEN 'descrizione' END,
        CASE WHEN r.brand_hit THEN 'brand' END
      ], NULL)),
    CASE WHEN p_debug THEN jsonb_build_object(
      'code_score', r.code_score,
      'word_hits', r.word_hits,
      'tokens', to_jsonb(v_tokens),
      'lex_title', r.lex_title,
      'lex_taxo', r.lex_taxo,
      'lex_desc', r.lex_desc,
      'prefix', r.prefix_hit,
      'similarity', round(r.sim::numeric, 3),
      'tsquery', v_tsq::text,
      'kind', CASE
        WHEN r.code_score > 0 THEN 'codice'
        WHEN r.word_hits >= v_ntok THEN 'originale'
        WHEN r.lex_title OR r.lex_taxo THEN 'singolare/plurale o sinonimo'
        WHEN r.prefix_hit THEN 'prefisso'
        WHEN r.lex_desc THEN 'descrizione'
        ELSE 'fuzzy' END
    ) ELSE '{}'::jsonb END,
    r.tot,
    (v_offset + v_limit) < r.tot,
    c.version
  FROM ranked r;
END;
$$;
```

### 20260812070413_27f6d86a-9586-4021-99b6-68756b427bad.sql

```sql

ALTER TABLE public.catalog_search_index ADD COLUMN IF NOT EXISTS title_norm text;

CREATE INDEX IF NOT EXISTS catalog_search_index_title_norm_trgm
  ON public.catalog_search_index USING gin (title_norm gin_trgm_ops);

UPDATE public.catalog_search_config
   SET weights = weights
     || jsonb_build_object(
          'title_starts', coalesce((weights->>'title_starts')::numeric, 4000),
          'title_all_words', coalesce((weights->>'title_all_words')::numeric, 3000)
        )
 WHERE id;

CREATE OR REPLACE FUNCTION public.catalog_search_upsert(p_cdpars text[])
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_count integer := 0;
BEGIN
  IF p_cdpars IS NULL OR array_length(p_cdpars, 1) IS NULL THEN
    RETURN 0;
  END IF;

  WITH src AS (
    SELECT
      btrim(a.cdpar) AS cdpar,
      a.cdpar        AS raw_cdpar,
      nullif(btrim(coalesce(a.cod_padre, '')), '') AS cod_padre,
      nullif(btrim(coalesce(a.barcd, '')), '')     AS ean,
      a.titolo_b2b,
      a.b2b_product_title,
      a.descrizione_variante,
      nullif(btrim(coalesce(a.depar, '')), '')     AS depar,
      a.attributes->>'reparto'                     AS reparto_code,
      a.attributes->>'gamma'                       AS gamma_code,
      nullif(btrim(coalesce(a.clmer, '')), '')     AS clmer,
      nullif(btrim(coalesce(a.clas1, '')), '')     AS clas1,
      nullif(btrim(coalesce(a.clas2, '')), '')     AS clas2,
      coalesce(a.tags, '{}')                       AS tags,
      coalesce(a.b2b_online_effective, false)      AS b2b_visible,
      a.updated_at,
      coalesce(a.descrizione, '') || ' ' || coalesce(a.descrizione_b2b, '') || ' '
        || coalesce(a.b2b_product_description, '') || ' ' || coalesce(a.description_marketing, '') AS desc_raw,
      (
        SELECT string_agg(coalesce(v.value->>'value', ''), ' ')
        FROM jsonb_each(coalesce(a.attributes->'gamma_attrs', '{}'::jsonb)) AS v(key, value)
        WHERE jsonb_typeof(v.value) = 'object'
      ) AS attrs_text,
      (
        SELECT array_agg(DISTINCT btrim(b.wcbda))
        FROM public.archivio_codici_barre_fraschetti b
        WHERE btrim(b.wcdpa) = btrim(a.cdpar)
          AND coalesce(btrim(b.wcbda), '') <> ''
          AND btrim(b.wcbda) IS DISTINCT FROM nullif(btrim(coalesce(a.barcd, '')), '')
      ) AS ean_extra
    FROM public.archivio_articoli_fraschetti a
    WHERE btrim(a.cdpar) = ANY (SELECT btrim(x) FROM unnest(p_cdpars) AS x)
  ),
  enriched AS (
    SELECT
      s.*,
      coalesce(br.display_name, br.nome_as400_brand, lv_brand.label) AS brand_name,
      lv_rep.label   AS reparto_label,
      lv_gam.label   AS gamma_label,
      lv_clmer.label AS categoria_label
    FROM src s
    LEFT JOIN public.archivio_brand_fraschetti br ON br.clas2 = s.clas2
    LEFT JOIN public.lookup_values lv_brand ON lv_brand.category = 'clas2' AND lv_brand.code = s.clas2
    LEFT JOIN public.lookup_values lv_rep   ON lv_rep.category = 'reparto' AND lv_rep.code = s.reparto_code
    LEFT JOIN public.lookup_values lv_gam   ON lv_gam.category = 'gamma'   AND lv_gam.code = s.gamma_code
    LEFT JOIN public.lookup_values lv_clmer ON lv_clmer.category = 'clmer' AND lv_clmer.code = s.clmer
  ),
  final AS (
    SELECT
      e.cdpar,
      e.raw_cdpar,
      e.cod_padre,
      coalesce(e.cod_padre, e.cdpar) AS visible_cdpar,
      e.ean,
      coalesce(e.ean_extra, '{}')    AS ean_extra,
      e.titolo_b2b,
      e.b2b_product_title,
      e.descrizione_variante,
      e.depar,
      coalesce(e.reparto_label, replace(coalesce(e.reparto_code, ''), '_', ' ')) AS reparto,
      e.categoria_label AS categoria,
      coalesce(e.gamma_label, replace(coalesce(e.gamma_code, ''), '_', ' '))     AS gamma,
      e.clmer, e.clas1, e.clas2,
      e.clas2 AS brand_code,
      e.brand_name,
      e.tags,
      e.attrs_text,
      e.b2b_visible,
      e.b2b_visible AS agent_visible,
      public.catalog_search_norm(
        coalesce(nullif(btrim(coalesce(e.titolo_b2b, '')), ''), coalesce(e.b2b_product_title, ''))
      ) AS title_norm,
      public.catalog_search_norm(
        coalesce(e.titolo_b2b, '') || ' ' || coalesce(e.b2b_product_title, '') || ' '
        || coalesce(e.descrizione_variante, '') || ' ' || coalesce(e.depar, '')
      ) AS short_norm,
      public.catalog_search_norm(
        coalesce(e.reparto_label, replace(coalesce(e.reparto_code, ''), '_', ' ')) || ' '
        || coalesce(e.categoria_label, '') || ' '
        || coalesce(e.gamma_label, replace(coalesce(e.gamma_code, ''), '_', ' ')) || ' '
        || coalesce(e.brand_name, '') || ' ' || coalesce(array_to_string(e.tags, ' '), '') || ' '
        || coalesce(e.attrs_text, '')
      ) AS taxo_norm,
      public.catalog_search_norm(e.desc_raw) AS desc_norm,
      e.updated_at
    FROM enriched e
  )
  INSERT INTO public.catalog_search_index AS t (
    cdpar, raw_cdpar, cod_padre, visible_cdpar, ean, ean_extra, titolo_b2b, b2b_product_title,
    descrizione_variante, depar, reparto, categoria, gamma, clmer, clas1, clas2, brand_code, brand_name,
    tags, attrs_text, b2b_visible, agent_visible, title_norm, short_norm, taxo_norm, desc_norm,
    fts_title, fts_taxo, fts_desc, source_updated_at, indexed_at, search_config_version
  )
  SELECT
    f.cdpar, f.raw_cdpar, f.cod_padre, f.visible_cdpar, f.ean, f.ean_extra, f.titolo_b2b, f.b2b_product_title,
    f.descrizione_variante, f.depar, nullif(btrim(f.reparto), ''), f.categoria, nullif(btrim(f.gamma), ''),
    f.clmer, f.clas1, f.clas2, f.brand_code, f.brand_name,
    f.tags, f.attrs_text, f.b2b_visible, f.agent_visible, f.title_norm, f.short_norm, f.taxo_norm, f.desc_norm,
    to_tsvector('simple', public.catalog_search_stem(f.short_norm)),
    to_tsvector('simple', public.catalog_search_stem(f.taxo_norm)),
    to_tsvector('simple', public.catalog_search_stem(f.desc_norm)),
    f.updated_at, now(),
    coalesce((SELECT c.version FROM public.catalog_search_config c WHERE c.id), 1)
  FROM final f
  ON CONFLICT (cdpar) DO UPDATE SET
    raw_cdpar = EXCLUDED.raw_cdpar,
    cod_padre = EXCLUDED.cod_padre,
    visible_cdpar = EXCLUDED.visible_cdpar,
    ean = EXCLUDED.ean,
    ean_extra = EXCLUDED.ean_extra,
    titolo_b2b = EXCLUDED.titolo_b2b,
    b2b_product_title = EXCLUDED.b2b_product_title,
    descrizione_variante = EXCLUDED.descrizione_variante,
    depar = EXCLUDED.depar,
    reparto = EXCLUDED.reparto,
    categoria = EXCLUDED.categoria,
    gamma = EXCLUDED.gamma,
    clmer = EXCLUDED.clmer,
    clas1 = EXCLUDED.clas1,
    clas2 = EXCLUDED.clas2,
    brand_code = EXCLUDED.brand_code,
    brand_name = EXCLUDED.brand_name,
    tags = EXCLUDED.tags,
    attrs_text = EXCLUDED.attrs_text,
    b2b_visible = EXCLUDED.b2b_visible,
    agent_visible = EXCLUDED.agent_visible,
    title_norm = EXCLUDED.title_norm,
    short_norm = EXCLUDED.short_norm,
    taxo_norm = EXCLUDED.taxo_norm,
    desc_norm = EXCLUDED.desc_norm,
    fts_title = EXCLUDED.fts_title,
    fts_taxo = EXCLUDED.fts_taxo,
    fts_desc = EXCLUDED.fts_desc,
    source_updated_at = EXCLUDED.source_updated_at,
    indexed_at = now(),
    search_config_version = EXCLUDED.search_config_version;

  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END;
$function$;

UPDATE public.catalog_search_index i
   SET title_norm = public.catalog_search_norm(
         coalesce(nullif(btrim(coalesce(i.titolo_b2b, '')), ''), coalesce(i.b2b_product_title, ''))
       )
 WHERE i.title_norm IS NULL;

CREATE OR REPLACE FUNCTION public.catalog_search_v2(p_query text, p_limit integer DEFAULT 30, p_offset integer DEFAULT 0, p_channel text DEFAULT 'pim'::text, p_allowed_cdpars text[] DEFAULT NULL::text[], p_brand_codes text[] DEFAULT NULL::text[], p_depar text[] DEFAULT NULL::text[], p_categoria text[] DEFAULT NULL::text[], p_gamma text[] DEFAULT NULL::text[], p_tags text[] DEFAULT NULL::text[], p_debug boolean DEFAULT false)
 RETURNS TABLE(cdpar text, visible_cdpar text, matched_cdpar text, title text, brand_name text, cod_padre text, score numeric, match_fields text[], match_reasons jsonb, total_count bigint, has_more boolean, config_version integer)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  c record;
  v_norm text;
  v_tokens text[] := '{}';
  v_last text := '';
  v_tsq tsquery;
  v_numeric boolean := false;
  v_limit int := greatest(1, least(coalesce(p_limit, 30), 200));
  v_offset int := greatest(0, coalesce(p_offset, 0));
  v_and text := '';
  v_group text;
  v_forms text[];
  v_i int;
  v_ntok int;
  v_desc boolean;
  w jsonb;
BEGIN
  SELECT * INTO c FROM public.catalog_search_config WHERE id;
  w := c.weights;
  v_desc := c.description_search_enabled;

  v_norm := public.catalog_search_norm(p_query);
  IF v_norm = '' THEN RETURN; END IF;

  SELECT array_agg(t ORDER BY ord) INTO v_tokens
  FROM (
    SELECT t, ord FROM unnest(string_to_array(v_norm, ' ')) WITH ORDINALITY AS x(t, ord)
    WHERE length(t) > 0
      AND NOT EXISTS (
        SELECT 1 FROM public.catalog_search_exclusions e
        WHERE e.active AND e.exclusion_type = 'ignored'
          AND public.catalog_search_norm(e.term) = x.t
      )
  ) s;

  IF v_tokens IS NULL OR array_length(v_tokens, 1) IS NULL THEN RETURN; END IF;
  v_ntok := array_length(v_tokens, 1);
  v_last := v_tokens[v_ntok];
  v_numeric := (v_ntok = 1 AND v_tokens[1] ~ '^[0-9]{3,}$');

  IF NOT v_numeric AND length(replace(v_norm, ' ', '')) < c.min_chars THEN RETURN; END IF;

  FOR v_i IN 1..v_ntok LOOP
    SELECT array_agg(DISTINCT f) INTO v_forms
    FROM (
      SELECT public.catalog_search_stem(v_tokens[v_i]) AS f
      UNION
      SELECT public.catalog_search_stem(public.catalog_search_norm(sy.synonym)) FROM public.catalog_search_synonyms sy
        WHERE sy.active AND public.catalog_search_norm(sy.term) = v_tokens[v_i]
      UNION
      SELECT public.catalog_search_stem(public.catalog_search_norm(sy.term)) FROM public.catalog_search_synonyms sy
        WHERE sy.active AND sy.bidirectional AND public.catalog_search_norm(sy.synonym) = v_tokens[v_i]
    ) f WHERE f IS NOT NULL AND length(f) > 0;

    SELECT string_agg(
             CASE WHEN v_i = v_ntok THEN '(' || replace(x, ' ', ' & ') || ' | ' || replace(x, ' ', ' & ') || ':*)'
                  ELSE '(' || replace(x, ' ', ' & ') || ')' END, ' | ')
      INTO v_group
    FROM unnest(v_forms) AS x;

    IF v_group IS NULL THEN CONTINUE; END IF;
    IF v_and <> '' THEN v_and := v_and || ' & '; END IF;
    v_and := v_and || '(' || v_group || ')';
  END LOOP;

  BEGIN
    v_tsq := to_tsquery('simple', v_and);
  EXCEPTION WHEN OTHERS THEN
    v_tsq := plainto_tsquery('simple', public.catalog_search_stem(v_norm));
  END;

  RETURN QUERY
  WITH base AS (
    SELECT i.*, coalesce(o.boost, 0) AS boost
    FROM public.catalog_search_index i
    LEFT JOIN public.catalog_search_product_overrides o ON o.cdpar = i.cdpar
    WHERE coalesce(o.excluded_from_search, false) = false
      AND (p_channel = 'pim' OR (p_channel = 'b2b' AND i.b2b_visible) OR (p_channel = 'agent' AND i.agent_visible))
      AND (p_allowed_cdpars IS NULL OR i.cdpar = ANY (p_allowed_cdpars))
      AND (p_brand_codes IS NULL OR i.clas2 = ANY (p_brand_codes))
      AND (p_depar IS NULL OR i.depar = ANY (p_depar))
      AND (p_categoria IS NULL OR i.categoria = ANY (p_categoria))
      AND (p_gamma IS NULL OR i.gamma = ANY (p_gamma))
      AND (p_tags IS NULL OR i.tags && p_tags)
  ),
  code_hits AS (
    SELECT b.*,
      CASE
        WHEN b.cdpar = v_norm OR b.ean = v_norm OR v_norm = ANY (b.ean_extra) THEN (w->>'exact_code')::numeric
        ELSE (w->>'prefix_code')::numeric
      END AS code_score
    FROM base b
    WHERE b.cdpar = v_norm OR b.ean = v_norm OR v_norm = ANY (b.ean_extra)
       OR (v_numeric AND b.cdpar LIKE v_norm || '%')
       OR (v_ntok = 1 AND length(v_norm) >= 3 AND b.cdpar LIKE replace(v_norm, ' ', '') || '%')
  ),
  lex_hits AS (
    SELECT b.*, 0::numeric AS code_score
    FROM base b
    WHERE NOT v_numeric
      AND (b.fts_short @@ v_tsq OR (v_desc AND b.fts_all @@ v_tsq))
  ),
  cand AS (
    SELECT * FROM code_hits
    UNION
    SELECT * FROM lex_hits
  ),
  fuzzy_hits AS (
    SELECT b.*, 0::numeric AS code_score
    FROM base b
    WHERE c.fuzzy_enabled
      AND NOT v_numeric
      AND length(v_norm) >= c.fuzzy_min_chars
      AND (SELECT count(*) FROM cand) < c.fuzzy_fallback_count
      AND similarity(b.short_norm, v_norm) >= c.fuzzy_threshold
    LIMIT 200
  ),
  allc AS (
    SELECT * FROM cand
    UNION
    SELECT * FROM fuzzy_hits
  ),
  scored AS (
    SELECT
      a.cdpar, a.visible_cdpar, a.cod_padre, a.brand_name, a.short_norm, a.boost,
      coalesce(a.title_norm, '') AS title_norm,
      coalesce(nullif(a.titolo_b2b, ''), a.b2b_product_title, a.depar, a.cdpar) AS title,
      a.code_score,
      (SELECT count(*) FROM unnest(v_tokens) t WHERE a.short_norm ~ ('(^| )' || t || '( |$)'))::numeric AS word_hits,
      (SELECT count(*) FROM unnest(v_tokens) t
         WHERE coalesce(a.title_norm, '') ~ ('(^| )' || t || '( |$)'))::int AS title_word_hits,
      (coalesce(a.title_norm, '') = v_norm) AS title_is_exact,
      (coalesce(a.title_norm, '') LIKE v_norm || '%'
        OR coalesce(a.title_norm, '') ~ ('^' || v_tokens[1] || '( |$)')) AS title_starts,
      CASE
        WHEN position(' ' || v_tokens[1] || ' ' IN ' ' || coalesce(a.title_norm, '') || ' ') > 0
          THEN position(' ' || v_tokens[1] || ' ' IN ' ' || coalesce(a.title_norm, '') || ' ')
        ELSE 9999
      END AS title_pos,
      (a.fts_title @@ v_tsq) AS lex_title,
      (a.fts_taxo @@ v_tsq) AS lex_taxo,
      (a.fts_desc @@ v_tsq) AS lex_desc,
      (v_last <> '' AND a.short_norm ~ ('(^| )' || v_last)) AS prefix_hit,
      (a.brand_name IS NOT NULL AND public.catalog_search_norm(a.brand_name) ~ ('(^| )' || v_tokens[1])) AS brand_hit,
      CASE WHEN c.fuzzy_enabled THEN similarity(a.short_norm, v_norm)::numeric ELSE 0::numeric END AS sim
    FROM allc a
  ),
  final AS (
    SELECT
      s.*,
      CASE
        WHEN s.code_score > 0 THEN 8
        WHEN s.title_is_exact THEN 7
        WHEN s.title_starts THEN 6
        WHEN s.title_word_hits >= v_ntok THEN 5
        WHEN s.title_word_hits > 0 OR s.lex_title THEN 4
        WHEN s.lex_taxo OR s.brand_hit THEN 3
        WHEN s.lex_desc THEN 2
        ELSE 1
      END AS tier,
      (
        s.code_score
        + (CASE WHEN s.title_is_exact OR s.short_norm = v_norm THEN (w->>'title_exact')::numeric ELSE 0 END)
        + (CASE WHEN s.title_starts THEN coalesce((w->>'title_starts')::numeric, 4000) ELSE 0 END)
        + (CASE WHEN s.title_word_hits >= v_ntok THEN coalesce((w->>'title_all_words')::numeric, 3000) ELSE 0 END)
        + ((w->>'title_word')::numeric * s.word_hits / v_ntok)
        + (CASE WHEN s.lex_title THEN (w->>'title_lexeme')::numeric ELSE 0 END)
        + (CASE WHEN s.prefix_hit THEN (w->>'prefix_last_word')::numeric ELSE 0 END)
        + (CASE WHEN s.lex_taxo THEN (w->>'taxonomy')::numeric ELSE 0 END)
        + (CASE WHEN s.brand_hit THEN (w->>'brand_tag')::numeric ELSE 0 END)
        + (CASE WHEN v_desc AND s.lex_desc AND NOT s.lex_title AND NOT s.lex_taxo
                THEN (w->>'description')::numeric ELSE 0 END)
        + (CASE WHEN NOT s.lex_title AND NOT s.lex_taxo AND NOT s.lex_desc AND s.code_score = 0
                THEN (w->>'fuzzy')::numeric * s.sim ELSE 0 END)
        + s.boost
      )::numeric AS total_score
    FROM scored s
  ),
  collapsed AS (
    SELECT DISTINCT ON (f.visible_cdpar)
      f.visible_cdpar AS g_visible,
      f.cdpar AS g_matched,
      f.cod_padre AS g_padre,
      f.title AS g_title,
      f.brand_name AS g_brand,
      f.total_score AS g_score,
      f.tier AS g_tier,
      f.title_pos AS g_pos,
      f.lex_title, f.lex_taxo, f.lex_desc, f.prefix_hit, f.brand_hit, f.code_score, f.sim, f.word_hits
    FROM final f
    WHERE f.total_score > 0
    ORDER BY f.visible_cdpar, f.tier DESC, f.title_pos ASC, f.total_score DESC, f.cdpar ASC
  ),
  ranked AS (
    SELECT co.*, count(*) OVER () AS tot
    FROM collapsed co
    ORDER BY co.g_tier DESC, co.g_pos ASC, co.g_score DESC, co.g_visible ASC
    LIMIT v_limit OFFSET v_offset
  )
  SELECT
    r.g_visible,
    r.g_visible,
    r.g_matched,
    r.g_title,
    r.g_brand,
    r.g_padre,
    round(r.g_score::numeric, 2),
    (SELECT array_remove(ARRAY[
        CASE WHEN r.code_score > 0 THEN 'codice' END,
        CASE WHEN r.lex_title THEN 'titolo' END,
        CASE WHEN r.lex_taxo THEN 'tassonomia' END,
        CASE WHEN r.lex_desc THEN 'descrizione' END,
        CASE WHEN r.brand_hit THEN 'brand' END
      ], NULL)),
    CASE WHEN p_debug THEN jsonb_build_object(
      'code_score', r.code_score,
      'word_hits', r.word_hits,
      'tokens', to_jsonb(v_tokens),
      'lex_title', r.lex_title,
      'lex_taxo', r.lex_taxo,
      'lex_desc', r.lex_desc,
      'prefix', r.prefix_hit,
      'similarity', round(r.sim::numeric, 3),
      'tsquery', v_tsq::text,
      'tier', r.g_tier,
      'title_pos', CASE WHEN r.g_pos >= 9999 THEN NULL ELSE r.g_pos END,
      'kind', CASE
        WHEN r.code_score > 0 THEN 'codice'
        WHEN r.g_tier = 7 THEN 'titolo esatto'
        WHEN r.g_tier = 6 THEN 'titolo inizia con'
        WHEN r.g_tier = 5 THEN 'titolo contiene'
        WHEN r.g_tier = 4 THEN 'titolo (variante o sinonimo)'
        WHEN r.g_tier = 3 THEN 'tassonomia o brand'
        WHEN r.g_tier = 2 THEN 'descrizione'
        ELSE 'fuzzy' END
    ) ELSE '{}'::jsonb END,
    r.tot,
    (v_offset + v_limit) < r.tot,
    c.version
  FROM ranked r;
END;
$function$;

```

### 20260812070601_2304df17-94fe-46df-b827-fa014d4126b0.sql

```sql

CREATE OR REPLACE FUNCTION public.catalog_search_v2(p_query text, p_limit integer DEFAULT 30, p_offset integer DEFAULT 0, p_channel text DEFAULT 'pim'::text, p_allowed_cdpars text[] DEFAULT NULL::text[], p_brand_codes text[] DEFAULT NULL::text[], p_depar text[] DEFAULT NULL::text[], p_categoria text[] DEFAULT NULL::text[], p_gamma text[] DEFAULT NULL::text[], p_tags text[] DEFAULT NULL::text[], p_debug boolean DEFAULT false)
 RETURNS TABLE(cdpar text, visible_cdpar text, matched_cdpar text, title text, brand_name text, cod_padre text, score numeric, match_fields text[], match_reasons jsonb, total_count bigint, has_more boolean, config_version integer)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  c record;
  v_norm text;
  v_tokens text[] := '{}';
  v_last text := '';
  v_tsq tsquery;
  v_numeric boolean := false;
  v_limit int := greatest(1, least(coalesce(p_limit, 30), 200));
  v_offset int := greatest(0, coalesce(p_offset, 0));
  v_and text := '';
  v_group text;
  v_forms text[];
  v_i int;
  v_ntok int;
  v_desc boolean;
  w jsonb;
BEGIN
  SELECT * INTO c FROM public.catalog_search_config WHERE id;
  w := c.weights;
  v_desc := c.description_search_enabled;

  v_norm := public.catalog_search_norm(p_query);
  IF v_norm = '' THEN RETURN; END IF;

  SELECT array_agg(t ORDER BY ord) INTO v_tokens
  FROM (
    SELECT t, ord FROM unnest(string_to_array(v_norm, ' ')) WITH ORDINALITY AS x(t, ord)
    WHERE length(t) > 0
      AND NOT EXISTS (
        SELECT 1 FROM public.catalog_search_exclusions e
        WHERE e.active AND e.exclusion_type = 'ignored'
          AND public.catalog_search_norm(e.term) = x.t
      )
  ) s;

  IF v_tokens IS NULL OR array_length(v_tokens, 1) IS NULL THEN RETURN; END IF;
  v_ntok := array_length(v_tokens, 1);
  v_last := v_tokens[v_ntok];
  v_numeric := (v_ntok = 1 AND v_tokens[1] ~ '^[0-9]{3,}$');

  IF NOT v_numeric AND length(replace(v_norm, ' ', '')) < c.min_chars THEN RETURN; END IF;

  FOR v_i IN 1..v_ntok LOOP
    SELECT array_agg(DISTINCT f) INTO v_forms
    FROM (
      SELECT public.catalog_search_stem(v_tokens[v_i]) AS f
      UNION
      SELECT public.catalog_search_stem(public.catalog_search_norm(sy.synonym)) FROM public.catalog_search_synonyms sy
        WHERE sy.active AND public.catalog_search_norm(sy.term) = v_tokens[v_i]
      UNION
      SELECT public.catalog_search_stem(public.catalog_search_norm(sy.term)) FROM public.catalog_search_synonyms sy
        WHERE sy.active AND sy.bidirectional AND public.catalog_search_norm(sy.synonym) = v_tokens[v_i]
    ) f WHERE f IS NOT NULL AND length(f) > 0;

    SELECT string_agg(
             CASE WHEN v_i = v_ntok THEN '(' || replace(x, ' ', ' & ') || ' | ' || replace(x, ' ', ' & ') || ':*)'
                  ELSE '(' || replace(x, ' ', ' & ') || ')' END, ' | ')
      INTO v_group
    FROM unnest(v_forms) AS x;

    IF v_group IS NULL THEN CONTINUE; END IF;
    IF v_and <> '' THEN v_and := v_and || ' & '; END IF;
    v_and := v_and || '(' || v_group || ')';
  END LOOP;

  BEGIN
    v_tsq := to_tsquery('simple', v_and);
  EXCEPTION WHEN OTHERS THEN
    v_tsq := plainto_tsquery('simple', public.catalog_search_stem(v_norm));
  END;

  RETURN QUERY
  WITH base AS (
    SELECT i.*, coalesce(o.boost, 0) AS boost
    FROM public.catalog_search_index i
    LEFT JOIN public.catalog_search_product_overrides o ON o.cdpar = i.cdpar
    WHERE coalesce(o.excluded_from_search, false) = false
      AND (p_channel = 'pim' OR (p_channel = 'b2b' AND i.b2b_visible) OR (p_channel = 'agent' AND i.agent_visible))
      AND (p_allowed_cdpars IS NULL OR i.cdpar = ANY (p_allowed_cdpars))
      AND (p_brand_codes IS NULL OR i.clas2 = ANY (p_brand_codes))
      AND (p_depar IS NULL OR i.depar = ANY (p_depar))
      AND (p_categoria IS NULL OR i.categoria = ANY (p_categoria))
      AND (p_gamma IS NULL OR i.gamma = ANY (p_gamma))
      AND (p_tags IS NULL OR i.tags && p_tags)
  ),
  code_hits AS (
    SELECT b.*,
      CASE
        WHEN b.cdpar = v_norm OR b.ean = v_norm OR v_norm = ANY (b.ean_extra) THEN (w->>'exact_code')::numeric
        ELSE (w->>'prefix_code')::numeric
      END AS code_score
    FROM base b
    WHERE b.cdpar = v_norm OR b.ean = v_norm OR v_norm = ANY (b.ean_extra)
       OR (v_numeric AND b.cdpar LIKE v_norm || '%')
       OR (v_ntok = 1 AND length(v_norm) >= 3 AND b.cdpar LIKE replace(v_norm, ' ', '') || '%')
  ),
  lex_hits AS (
    SELECT b.*, 0::numeric AS code_score
    FROM base b
    WHERE NOT v_numeric
      AND (b.fts_short @@ v_tsq OR (v_desc AND b.fts_all @@ v_tsq))
  ),
  cand AS (
    SELECT * FROM code_hits
    UNION
    SELECT * FROM lex_hits
  ),
  fuzzy_hits AS (
    SELECT b.*, 0::numeric AS code_score
    FROM base b
    WHERE c.fuzzy_enabled
      AND NOT v_numeric
      AND length(v_norm) >= c.fuzzy_min_chars
      AND (SELECT count(*) FROM cand) < c.fuzzy_fallback_count
      AND similarity(b.short_norm, v_norm) >= c.fuzzy_threshold
    LIMIT 200
  ),
  allc AS (
    SELECT * FROM cand
    UNION
    SELECT * FROM fuzzy_hits
  ),
  scored AS (
    SELECT
      a.cdpar, a.visible_cdpar, a.cod_padre, a.brand_name, a.short_norm, a.boost,
      coalesce(a.title_norm, '') AS title_norm,
      coalesce(nullif(a.titolo_b2b, ''), a.b2b_product_title, a.depar, a.cdpar) AS title,
      a.code_score,
      (SELECT count(*) FROM unnest(v_tokens) t WHERE a.short_norm ~ ('(^| )' || t || '( |$)'))::numeric AS word_hits,
      (SELECT count(*) FROM unnest(v_tokens) t
         WHERE coalesce(a.title_norm, '') ~ ('(^| )' || t))::int AS title_word_hits,
      (coalesce(a.title_norm, '') = v_norm) AS title_is_exact,
      (coalesce(a.title_norm, '') ~ ('^' || v_tokens[1])) AS title_starts,
      coalesce(nullif(regexp_instr(' ' || coalesce(a.title_norm, ''), ' ' || v_tokens[1]), 0), 9999) AS title_pos,
      (a.fts_title @@ v_tsq) AS lex_title,
      (a.fts_taxo @@ v_tsq) AS lex_taxo,
      (a.fts_desc @@ v_tsq) AS lex_desc,
      (v_last <> '' AND a.short_norm ~ ('(^| )' || v_last)) AS prefix_hit,
      (a.brand_name IS NOT NULL AND public.catalog_search_norm(a.brand_name) ~ ('(^| )' || v_tokens[1])) AS brand_hit,
      CASE WHEN c.fuzzy_enabled THEN similarity(a.short_norm, v_norm)::numeric ELSE 0::numeric END AS sim
    FROM allc a
  ),
  final AS (
    SELECT
      s.*,
      CASE
        WHEN s.code_score > 0 THEN 8
        WHEN s.title_is_exact THEN 7
        WHEN s.title_starts AND s.title_word_hits >= v_ntok THEN 6
        WHEN s.title_word_hits >= v_ntok THEN 5
        WHEN s.title_word_hits > 0 THEN 4
        WHEN s.lex_title THEN 3
        WHEN s.lex_taxo OR s.brand_hit THEN 2
        WHEN s.lex_desc THEN 1
        ELSE 0
      END AS tier,
      (
        s.code_score
        + (CASE WHEN s.title_is_exact OR s.short_norm = v_norm THEN (w->>'title_exact')::numeric ELSE 0 END)
        + (CASE WHEN s.title_starts THEN coalesce((w->>'title_starts')::numeric, 4000) ELSE 0 END)
        + (CASE WHEN s.title_word_hits >= v_ntok THEN coalesce((w->>'title_all_words')::numeric, 3000) ELSE 0 END)
        + ((w->>'title_word')::numeric * s.word_hits / v_ntok)
        + (CASE WHEN s.lex_title THEN (w->>'title_lexeme')::numeric ELSE 0 END)
        + (CASE WHEN s.prefix_hit THEN (w->>'prefix_last_word')::numeric ELSE 0 END)
        + (CASE WHEN s.lex_taxo THEN (w->>'taxonomy')::numeric ELSE 0 END)
        + (CASE WHEN s.brand_hit THEN (w->>'brand_tag')::numeric ELSE 0 END)
        + (CASE WHEN v_desc AND s.lex_desc AND NOT s.lex_title AND NOT s.lex_taxo
                THEN (w->>'description')::numeric ELSE 0 END)
        + (CASE WHEN NOT s.lex_title AND NOT s.lex_taxo AND NOT s.lex_desc AND s.code_score = 0
                THEN (w->>'fuzzy')::numeric * s.sim ELSE 0 END)
        + s.boost
      )::numeric AS total_score
    FROM scored s
  ),
  collapsed AS (
    SELECT DISTINCT ON (f.visible_cdpar)
      f.visible_cdpar AS g_visible,
      f.cdpar AS g_matched,
      f.cod_padre AS g_padre,
      f.title AS g_title,
      f.brand_name AS g_brand,
      f.total_score AS g_score,
      f.tier AS g_tier,
      f.title_pos AS g_pos,
      f.lex_title, f.lex_taxo, f.lex_desc, f.prefix_hit, f.brand_hit, f.code_score, f.sim, f.word_hits
    FROM final f
    WHERE f.total_score > 0
    ORDER BY f.visible_cdpar, f.tier DESC, f.title_pos ASC, f.total_score DESC, f.cdpar ASC
  ),
  ranked AS (
    SELECT co.*, count(*) OVER () AS tot
    FROM collapsed co
    ORDER BY co.g_tier DESC, co.g_pos ASC, co.g_score DESC, co.g_visible ASC
    LIMIT v_limit OFFSET v_offset
  )
  SELECT
    r.g_visible,
    r.g_visible,
    r.g_matched,
    r.g_title,
    r.g_brand,
    r.g_padre,
    round(r.g_score::numeric, 2),
    (SELECT array_remove(ARRAY[
        CASE WHEN r.code_score > 0 THEN 'codice' END,
        CASE WHEN r.lex_title THEN 'titolo' END,
        CASE WHEN r.lex_taxo THEN 'tassonomia' END,
        CASE WHEN r.lex_desc THEN 'descrizione' END,
        CASE WHEN r.brand_hit THEN 'brand' END
      ], NULL)),
    CASE WHEN p_debug THEN jsonb_build_object(
      'code_score', r.code_score,
      'word_hits', r.word_hits,
      'tokens', to_jsonb(v_tokens),
      'lex_title', r.lex_title,
      'lex_taxo', r.lex_taxo,
      'lex_desc', r.lex_desc,
      'prefix', r.prefix_hit,
      'similarity', round(r.sim::numeric, 3),
      'tsquery', v_tsq::text,
      'tier', r.g_tier,
      'title_pos', CASE WHEN r.g_pos >= 9999 THEN NULL ELSE r.g_pos END,
      'kind', CASE
        WHEN r.code_score > 0 THEN 'codice'
        WHEN r.g_tier = 7 THEN 'titolo esatto'
        WHEN r.g_tier = 6 THEN 'titolo inizia con'
        WHEN r.g_tier IN (5, 4) THEN 'titolo contiene'
        WHEN r.g_tier = 3 THEN 'titolo (variante o sinonimo)'
        WHEN r.g_tier = 2 THEN 'tassonomia o brand'
        WHEN r.g_tier = 1 THEN 'descrizione'
        ELSE 'fuzzy' END
    ) ELSE '{}'::jsonb END,
    r.tot,
    (v_offset + v_limit) < r.tot,
    c.version
  FROM ranked r;
END;
$function$;

```

### 20260812074825_62fbefac-103a-4223-8118-5be77ff2f750.sql

```sql
DELETE FROM public.catalog_search_synonyms
WHERE (lower(term) = 'chiodo' AND lower(synonym) = 'chiodi')
   OR (lower(term) = 'guanto' AND lower(synonym) = 'guanti');
```

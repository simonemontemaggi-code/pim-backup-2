# Mappa scritture PIM → AS400

Documento di **sola identificazione** (Fase 1). Nessuna modifica al codice.
Obiettivo: elencare **tutte** le voci che il PIM può modificare e che devono essere
riscritte su AS400, con lo stato attuale dell'export JSON.

Legenda stato export:

- ✅ = ad ogni salvataggio viene già generato il JSON AS400 (`exportAs400Change`)
- ⚠️ = salvataggio su Supabase presente ma **JSON AS400 non generato** (gap da colmare in Fase 2)
- 🚫 = PIM-only, **non deve mai** finire su AS400

Formato JSON attuale (`src/lib/as400Export.ts` → `buildAs400Payload`).
`timestamp` e `record` **non** fanno più parte del JSON (il record resta solo nel nome del file):

```json
{
  "user": "mario.rossi@fraschetti.com",
  "tables": {
    "archivio_articoli_fraschetti": [
      {
        "operation": "update",
        "key": { "cdpar": "273050" },
        "fields": { "depar": "NUOVA DESCRIZIONE" }
      }
    ]
  }
}
```

---

## 1. Articoli — `archivio_articoli_fraschetti` (Query 01)

Chiave AS400: **`cdpar`** (15 char, padded a destra con spazi).
Origine dati: Query 01. Salvataggio: `useSaveArticle` → ✅ export attivo.

### 1.1 Anagrafica (`articles_registry`)

| Campo AS400 | Label PIM | Tipo | Scrivibile | Note |
|---|---|---|---|---|
| `cdpar` | Codice Parte | text(15) | chiave | read-only in UI, presente in `key` |
| `depar` | Descrizione | text(40) | ✅ | |
| `wdeag` | Estensione Descrizione | text | ✅ | |
| `clas2` | Brand | text | ✅ | lookup |
| `clmer` | Settore | text | ✅ | lookup |
| `lipro` | Linea Prodotto | text | ✅ | |
| `wcdst` | Classe Trasporto | text | ✅ | pilota le % listini 01/10/11/12 |
| `cdst1` | Cod. Statistico 1 | text | read-only | AS400 master |
| `clas1` | Classificazione 1 | text | read-only | AS400 master |
| `cdiva` | Codice IVA | text | ✅ | lookup |
| `pcfor` | Fornitore Principale | text | ✅ | |
| `wfuas` | Assortimento | text | ✅ | vedi §7 per il cambio pianificato |
| `wstag` | Stagionalità | text | ✅ | lookup |
| `cod_padre` | Cod. Padre | text(6) | 🚫 | PIM-only (varianti) |
| `nmdis` | Linea Brand | text | 🚫 | PIM-only (in `PIM_ONLY_FIELDS`) |
| `reparto` / `gamma` | Reparto / Gamma | jsonb `attributes` | 🚫 | tassonomia PIM |
| `buyer` / `demand_planner` | Buyer / Demand Planner | jsonb `attributes` | 🚫 | organizzazione interna |
| `_rasfo` | Ragione Sociale | calcolato | 🚫 | join fornitore |

### 1.2 UM & Vendita (`articles_units`) — tutti scrivibili ✅

Fonte UI: `TabUnitsSales.tsx` (+ alcuni campi anche in `ArticleDetail.tsx`).

| Campo | Label | Tipo |
|---|---|---|
| `unmis` | UM Stoccaggio | text |
| `untec` | UM Tecnica | text |
| `umfat` | Fatt. Conv. UM Tec→Stoc | number |
| `umalt` | UM Alternativa / Vendita | text |
| `umfaa` | Fatt. Conv. UM Alt→Stoc | number |
| `wimba` | **Imballo** | text (Query 01, col. 55) |
| `wdset` | Descrizione Etichette | text |
| `wdeag` | Estensione Descrizione | text |
| `wfuas` | Assortimento | text |
| `wstag` | Stagionalità | text |
| `wclve` | Classe di Vendita | text |
| `wvvii` | Vincolo Imballo / Apribilità (""/"N") | flag |
| `wfcvr` | Variabile SI/NO | flag |
| `wfcs1` | Fatt. Conv. UmSt/UmV1 | number |
| `wfc2x` | Fatt. Conv. UmV2/UmSt (imballo di vendita) | number |
| `wumrf` | UM Riferimento UmV2 | text |

Attenzione a non confondere i tre "imballo":
`wimba` = imballo articolo (Query 01), `wfc2x` = fattore imballo di vendita (Query 01),
`wimbf` = imballo fornitore (Query 02, tab Acquisto → §2).


### 1.3 Contenuti B2B (`articles_marketing`) — 🚫 tutti PIM-only

`b2b_product_title`, `b2b_product_description`, `description_ecommerce`,
`descrizione_variante`, `seo_title`, `seo_description`, `tags`,
`b2b_online_active`, `master_pack`, `catalogo_carta_titolo`,
`catalogo_carta_dettaglio`, `catalogo_carta_scheda`, media/expo.
Nessuno di questi esiste su AS400.

### 1.4 Creazione nuovo articolo — ⚠️ GAP

`ArticleList.tsx` inserisce `{cdpar, depar}` su Supabase e scrive l'audit log
ma **non genera il JSON** `operation: "insert"`.

---

## 2. Anagrafica Articolo/Fornitore — `archivio_anag_art_fornitore` (Query 02)

Chiave AS400: **`cdpar` + `cdfor`**. Salvataggio: `ArticleDetail` (UM fornitore) e `TabPurchase`.

| Campo | Label | Tipo | Stato |
|---|---|---|---|
| `cdpfo` | Cod. Articolo Fornitore | text | ⚠️ TabPurchase non esporta |
| `qtmio` | Qtà Minima Acquisto | number | ⚠️ |
| `wumqm` | UM Qtà Minima | text | ⚠️ |
| `wimbf` | Imballo Fornitore | number | ⚠️ |
| `wumim` | UM Imballo Fornitore | text | ⚠️ |
| `wviqm` | Vincolo Qtà Min. | flag | ⚠️ |
| `wviim` | Vincolo Imballo | flag | ⚠️ |
| `wqtde` | Qtà Decimali | number | ⚠️ |
| `wtaim` | Arrotondamento Imballo | text | ⚠️ |
| `cdval` | Valuta | text | ⚠️ |
| `umord` | UM Fornitore | text | ✅ (via ArticleDetail) |
| `umfaf` | Fatt. Conv. Fornitore | number | ✅ (via ArticleDetail) |

Nota: le stesse due colonne `umord`/`umfaf` sono editabili da due punti diversi
con comportamento di export diverso — da unificare.

---

## 3. Codici a Barre — `archivio_codici_barre_fraschetti` (Query 03) — ⚠️ GAP

Chiave AS400: **`wcdpa` (cdpar) + `wcpba` (barcode)**.
`TabBarcodes.tsx` fa `insert`/`update`/`delete` + audit log, **nessun JSON**.

| Campo | Label | Tipo |
|---|---|---|
| `wcdpa` | Codice articolo | chiave |
| `wcpba` | Codice a barre | chiave |
| `wcofl` | TC (tipo codice) | text |
| `wcbda` | Data attivazione | date AAAAMMGG |

Operazioni necessarie: `insert`, `update`, `delete`.

---

## 4. Listini di Acquisto / Costario — `archivio_listini_fraschetti` (Query 04) — ⚠️ GAP

Chiave AS400: **`cdpar` + `cdfor` + `cdcat` + `dtvai`**.
Scritture: `TabPriceLists.tsx` (update riga) e `PriceListsPage.tsx` (insert nuova riga). Nessun JSON.

| Campo | Label | Tipo |
|---|---|---|
| `cdfor` | Fornitore | chiave |
| `rifli` | Rif. Listino | text |
| `dtvai` | Validità da | date AAAAMMGG (chiave) |
| `dtvaf` | Validità a | date AAAAMMGG |
| `cdval` | Valuta | text |
| `wprsc` | Prezzo | number(5 dec) |
| `wscfa`…`wscfe` | Sconti A–E | number(2 dec) |
| `wmasc` | Maggiorazione | number(2 dec) |
| `prsc1` | Costo Fornitore | number(5 dec) |
| `wfcas` | Fatt. Conv. Acq→Stoc | number |
| `wcpfa` | Dazio | number |
| `wcpfb` | Trasporto | number |
| `wcpfc` | Altro | number |
| `wuord` / `wusto` | UM ordine / stoccaggio | text |

Calcolati (`_netto_acq`, `_netto_stoc`, `_diff_cambio`, `_netto_acq_eur`,
`_netto_stoc_eur`) → 🚫 mai esportati.

---

## 5. Differenziale Cambio — `differenziale_cambio` (Query 05) — ⚠️ GAP

Chiave AS400: **`wcdfo` + `wcacq`** (record filtrati con `wcacq = '§DC'`).
`SupplierDifferentialDialog.tsx` fa insert/update; invoca una edge function ma **non genera il JSON standard**.

| Campo | Label | Tipo |
|---|---|---|
| `wcdfo` | Codice fornitore | chiave |
| `wcacq` | Codice condizione (`§DC`) | chiave |
| `wan02` | Anno/riferimento | text |
| `wscfa` | Percentuale differenziale | number |
| `wdacq` | Descrizione (max 40) | text |
| `wcdva` | Valuta (default `EURO`) | text |

---

## 6. Fornitori — `archivio_fornitori_fraschetti` (Query "fornitori") — ⚠️ da normalizzare

Chiave AS400: **`cdfor`**.
**Decisione: sia la creazione sia la modifica devono generare il JSON AS400 standard.**

| Campo | Label | Tipo | Stato |
|---|---|---|---|
| `cdfor` | Codice fornitore | chiave | ⚠️ oggi JSON "grezzo" alla creazione → passare a `operation: "insert"` standard |
| `rasfo` | Ragione sociale | text(60) | ⚠️ update senza JSON → `operation: "update"` |
| `buyer` | Buyer | text | 🚫 PIM-only |
| `demand_planner` | Demand Planner | text | 🚫 PIM-only |

Nota: oggi la creazione fornitore scarica `fornitore_<cdfor>.json` con struttura
diversa da `buildAs400Payload` → in Fase 2 sostituita da `exportAs400Change`.


---

## 7. Storico Assortimenti — `storico_assortimenti` (Query 18) — ⚠️ GAP (usa la coda)

Chiave AS400: **`wchfil` (cdpar padded 256) + `wprogr`**.
`useAssortmentHistory.ts` inserisce la riga e accoda su `as400_sync_queue`
(`operation: "assortment_upsert"`), ma **non scarica il JSON**.

| Campo | Label | Tipo |
|---|---|---|
| `wchfil` | Chiave articolo (256 char) | chiave |
| `wprogr` | Progressivo | number |
| `wstato` | Nuovo stato assortimento | text |
| `wdtdec` | Data decorrenza | date AAAAMMGG |
| `wdtcre`/`worcre`/`wutcre` | Creazione (data/ora/utente) | audit AS400 |
| `wdtvar`/`worvar`/`wutvar` | Variazione (data/ora/utente) | audit AS400 |

Regola: se `wdtdec` è futura, `archivio_articoli_fraschetti.wfuas` **non** viene
aggiornato subito — AS400 attiva lo stato alla data.

---

## 8. Listini di Vendita

### 8.1 Dettagli — `listini_vendita_dettagli` (Query 10)

Chiave AS400: **`wcdpa` + `wcdls`** (+ validità).

| Campo | Label | Stato |
|---|---|---|
| `prmil` | Prezzo di listino | ✅ (PianificaPrezzoDialog, percorso "immediato") |

### 8.2 Criteri Prezzo — `listini_vendita_criteri_prezzo` (Query 09)

| Campo | Label | Stato |
|---|---|---|
| `wsm01` | Ricarico | ✅ |
| `wsm02` | Ricarico raddoppio listino | ✅ |

### 8.3 Prezzi in Attesa — `prezzi_in_attesa` (Query 12)

Chiave: **`wcdpa` + `wcdls` + `wdtin`**. `usePrezziInAttesa.ts` → ✅ export su insert/update/delete.

| Campo | Label |
|---|---|
| `wprun` | Prezzo unitario |
| `wdtin` | Validità da (AAAAMMGG) |
| `wsm01` / `wsm02` | Ricarichi associati |

### 8.4 Altre tabelle listini vendita — nessuna scrittura dal PIM (solo import)

`listini_vendita_testate` (Q11), `_campagne` (Q07), `_condizioni` (Q19),
`_def_base` (Q08). Oggi **read-only** nel PIM.

---

## 9. Promo Strutturate (Query 13–16) — ✅ export attivo

Salvataggio via `usePromoSave` + `exportAs400Change`, con filtro
`TESTATA_PIM_ONLY_FIELDS`.

### 9.1 Testate — `promo_strutturate_testate` (chiave `wpcca`)

Scrivibili su AS400: `wptpbd` (descrizione), `wptpbs` (sottotitolo), `wpcca`,
`wptpca` (tipo O/P/S), `wpstato` (calcolato), `wpindii`, `wpindif`, `wpindoi`,
`wpindof`, `wpdvali`, `wpdvalf` (unione automatica), `wpinls`.
Valori sempre forzati: `wpcadt=N`, `wpdtls=T`, `wpcain=S`, `wpliadi=S`, `wpliadd=N`.

🚫 PIM-only: `cover_image_url`, `unlock_enabled`, `unlock_mode`,
`unlock_threshold`, `show_expiry_b2b`, `visible_b2b`, `show_on_customer_view`,
`b2b_sort_order`, `b2b_banner_visibility`, `offerta_sconto_fattura`,
`excluded_listini`.

### 9.2 Elementi — `promo_strutturate_elementi`

`wpprge`, `wpdesce`, `wpccae`, `wpstate`, `wprarte` (articolo), `wprfore`,
`wprclme`, `wprasse`, `wprclie`. Forzati: `wpcaine=S`, `wpcadte=N`, `wppreoe=N`.

### 9.3 Campagne — `promo_strutturate_campagne`

`wpprga`, `wpcdcla`, `wpcdcva`, `wpcdlsa`, `wpcdpaa`, `wpdtvia`, `wpdtvfa`,
`wpnrsca`, `wpqtmsa`, `wpumqta`, `wptpbla` + campi avanzati
(`wpricoa`, `wpfldval1/2`, `wpimpcpam`, `wpdatval1/2`, `wpritaca`, `wpriatca`)
e audit AS400 read-only (`wpwutimm`, `wpwdtimm`, `wpwhhimm`, `wpwutagg`, `wpwdtagg`, `wpwhhagg`).

### 9.4 Condizioni — `promo_strutturate_condizioni`

`wpseqc`, `wpstatc`, `wptpvc` (P/I/N), `wpsegvc`, `wpval1c`, `wpval2c`.

### 9.5 Offerte / Temi — 🚫 interamente PIM-only

`promo_strutturate_temi`, `_tema_articoli`, `_tema_scaglioni`,
`_tema_omaggio_articoli`, `_tema_catalogo_esclusioni`, `_sblocchi`,
`_destinatari_clienti`, `_destinatari_articoli`. Non esistono su AS400.

---

## 10. Clienti — `customers` — ⛔ bloccato: manca la SELECT AS400

**Stato attuale**: non esiste alcuna mappatura ai nomi di campo AS400 per i clienti.
A differenza di articoli/listini/promo (che arrivano da Query 01–20 con i nomi
nativi `cdpar`, `wcdpa`, `wpcca`…), i clienti entrano nel PIM da un **XLSB
Excel** (`CustomersImportPanel.tsx`) i cui header sono etichette umane
(`RagSoc`, `Agente`, `Zona`, `PIva`, `CAP`…) mappate su nomi Supabase
(`company_name`, `original_agent_code`, `zone_code`, `vat_number`,
`postal_code`). **I nomi dei campi del file AS400 clienti non li conosciamo**,
quindi oggi non si può costruire un JSON scrivibile.

Cosa serve da te per sbloccare:

1. la **SELECT AS400** dell'anagrafica clienti (stesso formato delle query
   01–20: `a.cdcli, a.rasoc, …`) e il nome del file/tabella AS400;
2. un **XLSX di esempio** con quelle colonne.

Con quei due input: parser `queryNNParser.ts` + mappa `customers.<colonna>` ↔
`<campo AS400>` + export JSON su ogni salvataggio, esattamente come le altre
entità.

Campi PIM-only (🚫 mai su AS400, restano tali anche dopo): `pec`, `sdi_code`,
`closing_day`, `delivery_notes`, `contact_name`, `contact_mobile`, `importance`,
`visit_day`, `visit_frequency`, `competitors`, `suppliers_present`,
`sells_online`, `has_pc`, `payment_method`, `bank_name`, `bank_branch`, `iban`,
`pim_notes`.

Da decidere insieme alla mappatura: la codifica di un **nuovo cliente**
(`nuovi_clienti_richieste` → approvazione) dovrà generare `operation: "insert"`.


---

## 11. Altre tabelle scritte dal PIM ma non AS400 (🚫)

| Tabella | Contenuto |
|---|---|
| `archivio_brand_fraschetti` | Brand B2B (logo, descrizione, visibilità) |
| `article_media`, `article_expo_items` | Media e composizione expo |
| `b2b_*` (catalogs, hero, assortments, novità, communications, tickets) | Contenuti portale |
| `news`, `news_links` | News Agent Hub |
| `taxonomy_*`, `gamma_attributes` | Tassonomia PIM |
| `lookup_values` | Dizionari PIM |

---

## 12. Riepilogo gap da colmare (Fase 2)

| # | Entità | Tabella | Chiave AS400 | Operazioni |
|---|---|---|---|---|
| 1 | Nuovo articolo | `archivio_articoli_fraschetti` | `cdpar` | insert |
| 2 | Acquisto art./fornitore | `archivio_anag_art_fornitore` | `cdpar`+`cdfor` | update |
| 3 | Codici a barre | `archivio_codici_barre_fraschetti` | `wcdpa`+`wcpba` | insert/update/delete |
| 4 | Listini acquisto | `archivio_listini_fraschetti` | `cdpar`+`cdfor`+`cdcat`+`dtvai` | insert/update |
| 5 | Differenziale cambio | `differenziale_cambio` | `wcdfo`+`wcacq` | insert/update |
| 6 | Fornitori | `archivio_fornitori_fraschetti` | `cdfor` | insert (da normalizzare) / update `rasfo` |
| 7 | Storico assortimenti | `storico_assortimenti` | `wchfil`+`wprogr` | insert |
| 8 | Clienti | `customers` | da definire | ⛔ bloccato: serve la SELECT AS400 (§10) |

Già coperti: articoli (update), anag. fornitore parziale (`umord`/`umfaf`),
prezzi in attesa, `prmil`, criteri ricarico, promo strutturate.


---

## 13. Nota su `PIM_ONLY_FIELDS`

Oggi `src/lib/as400Export.ts` usa una **blacklist globale**. Con l'estensione a 7
nuove entità la blacklist diventa fragile: in Fase 2 va sostituita con una
**whitelist per entità** (`src/lib/as400Registry.ts`), derivata da questo
documento e allineata con `src/lib/fieldDefinitions.ts`.

---

## 14. Come garantire che non manchi più nessun campo (audit automatico)

Il caso `wimba` è nato da una mappatura fatta a mano. Ora la verifica è **meccanica**:

```bash
node scripts/as400-audit.mjs        # report leggibile
node scripts/as400-audit.mjs --json # output machine-readable
```

Lo script incrocia tre fonti e non si fida di nessun elenco scritto a mano:

1. **Campi AS400 reali** — estratti dalle interfacce `Q##Row` dei 20 parser di
   import (`src/lib/query01Parser.ts` … `query20Parser.ts`). Sono, per
   definizione, tutte le voci che AS400 ci manda: 347 campi.
2. **Campi editabili nel PIM** — estratti dai form (array `FIELDS`,
   `register()/setValue()`, attributi `name=`, `fieldKey=`) in
   `src/components/articles`, `src/components/promo`, `src/components/suppliers`,
   `src/pages`.
3. **Campi registrati nei permessi** — `src/lib/fieldDefinitions.ts`.

Output:

- ⚠️ **editabili nel PIM ma non nei permessi** → è il bug tipo `wimba`.
  Lo script esce con codice 1 se ce n'è anche uno solo.
- ℹ️ **nei permessi ma non in nessun parser** → campi PIM-only (atteso).
- **campi AS400 mai toccati dal PIM** → read-only, non vanno riscritti.

Falsi positivi noti (campi che compaiono solo in colonne di export, non
editabili) sono elencati in `IGNORED` dentro lo script, con motivazione.

### Guardia in CI

`src/test/as400FieldAudit.test.ts` esegue lo script e fallisce se
`missingInPermissions` non è vuoto. Quindi aggiungere un campo a un form senza
registrarlo in `fieldDefinitions.ts` rompe i test.

### Esito prima esecuzione (10/08/2026)

12 campi editabili risultavano fuori dalla matrice permessi, ora aggiunti:

| Campo | Sezione | Dove si edita |
|---|---|---|
| `rasfo` | `suppliers` | `SuppliersPage` |
| `cdfor` | `suppliers` | `SuppliersPage` |
| `wcdls` | `articles_pricing` | `TabSalesPriceCriteria` |
| `wpstate` | `promo_strutturate` | Elemento promo |
| `wpcdcva`, `wpcdpaa`, `wptpbla` | `promo_strutturate` | Campagna promo |
| `wpunmc`, `wppapc`, `wpsm1c`, `wpsm2c`, `wpsm5c` | `promo_strutturate` | Condizione promo |

`nmcat` è escluso: compare solo come colonna selezionabile in `ExportModal`.

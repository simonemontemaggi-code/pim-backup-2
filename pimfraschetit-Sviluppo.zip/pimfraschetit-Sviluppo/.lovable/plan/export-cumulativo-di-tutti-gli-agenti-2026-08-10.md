# Export cumulativo di tutti gli agenti

Oggi l'export Excel/PDF esiste solo dentro il pop-up di un singolo agente. Serve poter esportare in un colpo solo i clienti di tutti gli agenti.

## Cosa cambia

- Nella scheda "Zone & Agenti", accanto al titolo "Agenti per attivazioni", due pulsanti: **Excel** e **PDF** (export cumulativo).
- L'export contiene tutte le righe cliente di tutti gli agenti, con le stesse colonne del pop-up (Codice, Ragione sociale, Zona, Agente, Attivo B2B dal, VdC, VdC ord., Ord. cliente, Ord. agente, Ult. ord. cliente, Ult. ord. agente), ordinate per agente e poi per ragione sociale.
- Excel: due fogli — "Clienti" (dettaglio completo) e "Riepilogo agenti" (le righe della tabella agenti: codice, nome, attivati, totali, adozione %, clienti ord. da agente, clienti ord. da cliente, ord. agente non iscritti, clienti VdC).
- PDF: orizzontale, con intestazione per ogni agente e le sue righe cliente sotto, stesso stile del pop-up.
- I nomi file includono la data (es. `clienti_tutti_agenti_2026-08-10.xlsx`).

## Dettagli tecnici

- Estrarre la logica di export dal pop-up in un modulo condiviso `src/lib/adoptionExport.ts` (mappatura riga → record export + generazione PDF tabellare), usato sia da `CustomerDrilldownDialog.tsx` sia dal nuovo export cumulativo, per evitare duplicazione.
- `src/pages/PortalAdoptionPage.tsx`: nell'header della card "Agenti per attivazioni" aggiungere i due bottoni; la sorgente dati è `data.customerRows` (già contiene agente e agentName) filtrata sugli agenti mostrati in tabella.
- Excel via `xlsx` (`downloadXlsx`/`book_append_sheet`), PDF via `jsPDF` come già fatto nel dialog.

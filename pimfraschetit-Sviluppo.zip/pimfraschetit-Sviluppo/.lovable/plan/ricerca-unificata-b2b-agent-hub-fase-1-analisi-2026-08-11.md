# Ricerca unificata B2B / Agent Hub — Fase 1: analisi

Hai scelto di partire con la sola analisi. Il risultato di questa fase è un documento tecnico nel PIM (`docs/search-engine-audit.md`) che mette a confronto riga per riga i due motori di ricerca e propone la configurazione da esporre nella futura tab Impostazioni. Nessuna modifica al comportamento dei portali in questa fase.

## Cosa ho già verificato

I due portali hanno **due copie divergenti** dello stesso codice, nate da un port e poi evolute separatamente:

- `src/lib/search/smartQuery.ts` — 184 righe su Agent Hub, 181 sul B2B, con differenze sostanziali:
  - Agent Hub ha **disattivato lo stemming italiano** nell'espansione dei token (troppo rumore); il B2B lo usa ancora, anche sui sinonimi.
  - Agent Hub ha in più `alphanumSpacedVariants` (cerca "UL050" trovando anche "UL 050"); il B2B non ce l'ha.
- `src/lib/search/tagDictionary.ts` — oltre 100 righe di differenza tra i due file.
- `src/lib/supabase/products.ts` — la funzione che costruisce la query verso il DB differisce su: colonne interrogate, fallback quando non ci sono risultati, ordinamento dei risultati, cache.
- Il B2B ha una pipeline a due fetch (preview 30 risultati + smart 5000) con lunghezza minima adattiva 2/3 caratteri; l'Agent Hub ha una cache risultati e un percorso diverso.

Questo spiega perfettamente i risultati diversi a parità di parola cercata.

## Contenuto del documento di analisi

1. **Mappa dei componenti** di ricerca dei due portali (file, funzioni, chi chiama cosa).
2. **Tabella comparativa puntuale** delle divergenze: espansione token, stemming, sinonimi, dizionario tag, colonne cercate, gestione codici/barcode, fuzzy, AND/OR tra parole, fallback, ordinamento, soglie e limiti.
3. **Batteria di query campione** (parole reali problematiche) con il risultato atteso su ciascun portale e la causa tecnica della differenza.
4. **Proposta di modello dati** per la configurazione centralizzata nel PIM, che copre le quattro aree che hai chiesto:
   - sinonimi e dizionario tag,
   - colonne cercate con peso/priorità di ranking,
   - soglie e comportamento (lunghezza minima, fuzzy, AND/OR, limiti),
   - correzioni manuali per singola query (pin ed esclusioni).
5. **Proposta di architettura** per la Fase 2 con i due percorsi possibili (motore unico su funzione Postgres vs configurazione condivisa letta da entrambi i portali), con costi e rischi di ciascuno, così scegli a colpo sicuro.
6. **Specifica della tab Impostazioni PIM**, incluso il banco di prova con anteprima dei risultati che hai richiesto.

## Note tecniche

- Analisi svolta su snapshot in sola lettura dei due progetti; nessuna scrittura su Agent Hub o B2B.
- L'unico file creato in questa fase è `docs/search-engine-audit.md` nel progetto PIM.
- Le parole campione del punto 3 le estraggo dai dati reali: `search_misses` e `search_miss_resolutions` già presenti nel database, così l'analisi parte da ricerche realmente fallite dagli utenti.
- Nessuna migrazione, nessuna modifica a `fieldDefinitions.ts` o alla matrice permessi in questa fase; entrambe rientrano nella Fase 2 (SectionKey prevista: `users_admin` se la tab vive dentro Admin → Impostazioni).

# Certificazione baseline ricerca: campione corretto + analisi scarti

Il 92,6% mostrato non è un dato affidabile: il test è stato eseguito sulle 27 "ricerche a vuoto" degli ultimi 90 giorni, cioè query che per definizione non trovano nulla. Infatti 23 su 27 non danno risultati con nessuno dei due motori, e in quei casi il confronto del "primo risultato" è null vs null (conteggiato come allineato o disallineato senza significato reale). Restano solo ~4 query utili: troppo poche per certificare qualcosa.

Servono due cose: un campione rappresentativo di ricerche vere e una metrica che non venga inquinata dalle query vuote.

## Cosa cambio

### 1. Metrica corretta nel pannello di test
- L'allineamento primo risultato viene calcolato solo sulle query dove almeno uno dei due motori trova risultati (denominatore = query "utili").
- Le card diventano: query totali, query utili, allineamento 1° (su utili), sovrapposizione media top-10 (su utili), solo nuovo, solo Agent Hub, entrambe vuote.
- Le righe entrambe vuote restano visibili ma marcate come "non valutabile", così si vede subito quali query vanno gestite con sinonimi/override invece di falsare il punteggio.

### 2. Campione realistico di query
Aggiungo accanto a "Carica ricerche a vuoto" un pulsante "Carica campione catalogo (N query)" che costruisce un set rappresentativo pescando dal catalogo reale:
- parole/bigrammi frequenti dai titoli B2B degli articoli online,
- nomi brand,
- codici articolo e codici a barre,
- una quota di termini generici di reparto.

Il campione è casuale ma riproducibile (seed) e di dimensione scelta dall'utente (default 300), così i test successivi sono confrontabili tra loro.

### 3. Analisi degli scarti
Sotto la tabella aggiungo una vista "Solo disallineate" con, per ogni query, il primo risultato dei due motori affiancato (codice + titolo) e il motivo del match del nuovo motore, più un pulsante rapido per creare un sinonimo o un override da quella riga. È il ciclo di lavoro per portare l'allineamento al 98%.

### 4. Tracciamento ricerche reali (base per il futuro)
Le ricerche andate a buon fine oggi non vengono registrate da nessuna parte: si conoscono solo quelle a vuoto. Propongo di iniziare a registrare tutte le query (testo, portale, numero risultati, se c'è stato un clic) in una tabella dedicata con retention 12 mesi, così tra qualche settimana la certificazione si potrà fare sul traffico vero invece che su un campione sintetico. La scrittura avviene dai portali quando passeranno alla RPC unica; nel frattempo la tabella resta vuota e il pannello usa il campione catalogo.

## Note tecniche
- `BatchTestPanel.tsx`: nuovo calcolo metriche, filtro "solo disallineate", generatore campione, export Excel aggiornato con la colonna "valutabile".
- Nuova RPC read-only `pim_search_sample_queries(_limit, _seed)` per generare il campione dal catalogo (solo admin).
- Nuova tabella `search_queries` (query, app, results_count, user_id/customer_code, created_at) con RLS: inserimento consentito alle app, lettura solo staff; job di retention 12 mesi come per `search_misses`.
- Nessuna modifica alla RPC `pim_search_articles` in questo passo: prima si misura correttamente, poi si interviene sulla configurazione.

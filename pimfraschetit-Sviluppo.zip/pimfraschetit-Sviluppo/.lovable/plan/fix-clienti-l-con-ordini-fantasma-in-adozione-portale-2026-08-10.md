# Fix: clienti "L###" con ordini fantasma in Adozione Portale

## Cosa succede davvero

Quei clienti **non hanno nessun ordine**. Nel database `customer_orders` non esiste alcuna riga con codice `L002`, `L009`, `L117`, ecc. Gli ordini che vedi sono quelli di **altri clienti**, attribuiti per errore.

Causa: nell'Adozione Portale il codice cliente viene normalizzato buttando via tutte le lettere e gli zeri iniziali. Quindi:

```text
L002  -> "2"   ... stesso valore di  0002 (APPETITO FERRAMENTA)   -> 15 ordini
L009  -> "9"   ... stesso valore di  0009 (AGRIGARDEN SRL)        -> 4 ordini
L117  -> "117" ... stesso valore di  0117 (FERRAMENTA CIOCI)      -> 8 ordini
L902  -> "902" ... stesso valore di  0902 (DAINESE FERRAMENTA)    -> 13 ordini
```

Tutti i clienti con prefisso `L` (e anche i codici tipo `NUOVO2`) collidono con il cliente numerico corrispondente e "ereditano" i suoi ordini, sia lato cliente sia lato agente. Per questo risultano non attivi B2B ma con ordini e date di ultimo ordine.

## Cosa correggere

Il codice cliente va confrontato **esatto**: `L002`, `0002` e `00002` sono tre clienti diversi. Niente rimozione di lettere né di zeri iniziali.

1. In `src/hooks/usePortalAdoption.ts` sostituire `normalizeCode` (e il gemello `normalize`) con un semplice `trim + uppercase` del codice, senza toccare cifre o zeri.
2. Applicare il confronto esatto a tutti i match ordini↔clienti dell'hook: metriche per agente (ordini da cliente / da agente / da agente non iscritto), `ordStatsByCode`, righe di drill-down, insiemi `orderedCodesNorm` e conteggi settimanali.
3. Match Videocatalogo: `customer_videocatalogo_flags.customer_code_norm` è memorizzato senza zeri iniziali, quindi il confronto resta su quella chiave ma **solo per codici interamente numerici** — un codice come `L002` o `NUOVO2` non deve mai agganciare la riga videocatalogo `2`.
4. Bumpare la query key dell'hook (es. `v4-exact-code`) per invalidare la cache e ricalcolare KPI, tabella agenti e drill-down.

Verificato sui dati reali: in `customer_orders` i codici sono a 4 cifre (2826 righe), 5 cifre (8 righe) e alfanumerici tipo `NUOVO3` (2 righe), quindi il confronto esatto contro `customers.customer_code` è coerente e non perde ordini legittimi.

## Effetto atteso

I clienti `L###` mostreranno 0 ordini e nessuna data, i conteggi per agente caleranno di conseguenza, e i clienti numerici manterranno solo i propri ordini reali.

## Nota collegata

`src/hooks/useCustomers.ts` usa lo stesso match solo-numerico per le colonne Videocatalogo nella lista Clienti: allineo anche quello alla regola del punto 3 nello stesso intervento.


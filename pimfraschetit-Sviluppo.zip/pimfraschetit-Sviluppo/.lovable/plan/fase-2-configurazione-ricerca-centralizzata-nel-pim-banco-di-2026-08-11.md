# Fase 2 — Configurazione ricerca centralizzata nel PIM + banco di prova

Strada A a tappe: si costruisce tutto dentro il PIM (tabelle di configurazione, motore di ricerca sul database, pagina di gestione con banco di prova). I due portali **non vengono toccati** in questa fase: si agganciano solo dopo la validazione sul banco di prova.

Accesso: solo admin, dentro Admin → Impostazioni (nessuna nuova voce nella matrice permessi).

---

## Cosa si ottiene alla fine di questa fase

- Un unico posto dove decidere come cerca il catalogo: sinonimi, colonne e pesi, soglie, correzioni manuali per singola query.
- Una funzione di ricerca sul database che replica il comportamento attuale e obbedisce a quella configurazione.
- Un banco di prova che, digitando una parola, mostra affiancati i risultati del **nuovo motore**, dell'**Agent Hub** e del **B2B** di oggi, così si vede articolo per articolo dove divergono prima di cambiare i portali.

---

## 1. Tabelle di configurazione

Quattro tabelle nuove, con seed dai valori oggi hardcoded nei portali:

- **`search_synonyms`** — termine → espansioni, flag bidirezionale, attivo, nota. Seed: le 22 voci del dizionario duplicato (brugola, cacciavite, vite, chiodo, guanto, ecc.).
- **`search_fields`** — colonna cercabile, attiva, peso, modalità di match (sottostringa / parola intera / prefisso), a quali forme del token si applica, ordine. Seed: `titolo_b2b` 10000, `clas2` 3000, `descrizione_variante` 1000, gamma 500, `depar` 100, reparto 80, `cdpar` 10, `descrizione_b2b` 5, `tags`.
- **`search_settings`** — coppie chiave/valore per soglie e comportamento: lunghezza minima, stemming, varianti alfanumeriche, AND/OR fra token, fuzzy (attivo, distanza, tetto risultati), limiti anteprima, soglie numeriche codice/barcode, filtri tassonomici durante la ricerca, promozione codice esatto, score del prodotto padre recuperato.
- **`search_overrides`** — per una query: articoli da fissare in cima (ordinati), articoli da escludere, tipo di match (esatta/prefisso), nota.

Sicurezza: lettura consentita anche in anonimo (serviranno ai portali nella fase successiva), scrittura solo admin. Tutte con `updated_at`/`updated_by`.

## 2. Funzione di ricerca sul database

`pim_search_articles(query, filtri, limite, offset)` che:

- legge le quattro tabelle di configurazione;
- applica il percorso veloce numerico (codice articolo, barcode) già identico nei due portali;
- espande il token (sinonimi, stemming e varianti alfanumeriche se attivi);
- cerca sulle colonne attive con la modalità di match configurata, su `archivio_articoli_fraschetti` filtrata su `b2b_online_effective`;
- calcola lo score con i pesi configurati, applica pin/esclusioni degli override e la gestione padri/varianti;
- restituisce i risultati **con la motivazione del match** (colonna, forma del token usata, punteggio, se pinnato), necessaria al banco di prova.

Il criterio di correttezza è "riprodurre il comportamento odierno", non inventarne uno nuovo: la validazione avviene sulle query reali di `search_misses`.

## 3. Pagina di gestione — Admin → Impostazioni → Ricerca

Nuova tab nella barra di Admin, rotta `/pim/admin/search`, visibile solo agli admin. Quattro pannelli:

1. **Sinonimi** — tabella editabile con ricerca, flag bidirezionale, import/export CSV.
2. **Colonne e pesi** — elenco ordinabile con interruttore, peso, modalità di match.
3. **Soglie e comportamento** — form con spiegazione in italiano dell'effetto di ogni parametro e indicazione del valore usato oggi da ciascun portale.
4. **Correzioni manuali** — per una query: articoli da fissare in cima (riordinabili) e da escludere, con ricerca articolo per aggiungerli.

## 4. Banco di prova

In cima alla tab, un campo di ricerca. Digitando una parola mostra tre colonne affiancate:

```text
   NUOVO MOTORE (config salvata)  |  AGENT HUB (oggi)  |  B2B (oggi)
   ------------------------------ | ------------------ | ------------------
   articolo, score, perché        | articolo, score    | articolo, score
```

- Contatore risultati e tempo di risposta per colonna.
- Evidenziazione degli articoli presenti in una colonna e assenti nelle altre: è la misura visiva della divergenza.
- Interruttore "usa configurazione in modifica non salvata" per vedere l'effetto di una modifica prima di pubblicarla.

Le colonne Agent Hub e B2B sono ricostruite nel PIM replicando le due logiche attuali così come sono documentate nell'audit, in modo da avere il confronto senza dipendere dai due repository.

## 5. Collegamento con Navigation Analysis

Nella tabella delle ricerche a vuoto si aggiunge un pulsante "Correggi in Impostazioni Ricerca" che apre la tab con la query già caricata nel banco di prova: rilevo la ricerca fallita → creo il sinonimo o il pin → verifico l'effetto.

---

## Dettagli tecnici

- Migrazione: 4 tabelle in `public` con `GRANT` espliciti (SELECT ad `anon`/`authenticated`, scrittura solo admin via `has_role`), RLS abilitata, trigger `updated_at`, seed dei valori attuali.
- `pim_search_articles`: `STABLE`, `SET search_path = public`, nessun SQL costruito da input non validato.
- Frontend: `src/pages/AdminSearchSettingsPage.tsx` + componenti in `src/components/admin/search/`, rotta figlia di `AdminPage` e voce nell'array `tabs` di `src/pages/AdminPage.tsx`, hook `src/hooks/useSearchConfig.ts`.
- Motori di confronto per il banco di prova: `src/lib/search/legacyAgentHub.ts` e `src/lib/search/legacyB2b.ts`, isolati e destinati a essere cancellati a fine migrazione.
- Nessuna nuova `SectionKey`: la pagina eredita `users_admin`, coerente con le altre tab di Admin.
- Nessun campo AS400 coinvolto: `fieldDefinitions.ts` non va toccato.

## Fuori da questa fase

Modifiche ad Agent Hub e B2B Mock up, che restano invariati finché il banco di prova non conferma l'allineamento.

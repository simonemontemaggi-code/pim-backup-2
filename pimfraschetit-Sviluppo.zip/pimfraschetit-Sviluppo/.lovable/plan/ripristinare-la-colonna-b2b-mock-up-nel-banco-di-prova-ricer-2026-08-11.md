# Ripristinare la colonna "B2B Mock up" nel banco di prova ricerca

La colonna B2B era stata rimossa perché era una **simulazione inventata** (una semplice ricerca per parola intera) che restituiva quasi sempre 0 risultati: un confronto inutile e fuorviante. La soluzione corretta non è toglierla, ma rifarla con lo stesso metodo usato per Agent Hub: portare nel PIM il **codice reale del portale B2B**.

## Perché B2B e Agent Hub non danno gli stessi risultati

Dalla lettura del codice dei due portali, le pipeline sono simili ma **non identiche**. Differenze reali già verificate:

- **Espansione delle parole**: il B2B usa ancora lo *stemming* italiano (taglia le desinenze) per allargare la ricerca; Agent Hub lo ha rimosso e usa invece le varianti singolare/plurale e la separazione lettere/cifre (es. "UL050" → "UL 050"). Su molte query questo cambia i risultati.
- **Dizionario tag/categorie**: i due portali hanno versioni diverse dello stesso dizionario.
- **Risoluzione brand**: implementazioni diverse (Agent Hub interroga anche l'anagrafica brand con cache dedicata).
- **Dati letti**: il B2B non legge alcune colonne che Agent Hub usa (es. confezione master).

Entrambi filtrano solo gli articoli online sul portale, quindi la differenza è tutta nella logica linguistica e di ranking.

## Cosa faccio

1. **Porting 1:1 del motore B2B**: copio nel PIM la pipeline di ricerca reale del portale B2B (funzione lista prodotti + le sue versioni di dizionario linguistico e dizionario tag), tenendola separata da quella di Agent Hub per non contaminarle.
2. **Terza colonna nel banco di prova**: torna "B2B Mock up (oggi)" accanto a "Agent Hub (oggi)" e "Nuovo motore", con etichetta "codice reale del portale, porting 1:1", tempo di risposta, numero risultati e motivo del match.
3. **Evidenza delle differenze**: le righe presenti in una sola colonna restano evidenziate in ambra, così si vede subito dove B2B e Agent Hub divergono e dove si colloca il nuovo motore.
4. **Test di massa**: il pannello dei test batch calcola l'allineamento del nuovo motore su entrambi i portali (due percentuali distinte) invece che sul solo Agent Hub, e segnala le query dove i due portali già oggi non concordano — sono quelle che il motore unico dovrà sanare.
5. **Nessuna modifica ai portali**: il PIM resta in sola lettura sui dati; si cambia solo il banco di prova.

## Nota sulla scelta di riferimento

Con questo pannello sarà visibile query per query quale portale dà il risultato migliore. Il "nuovo motore" oggi replica Agent Hub; se in alcuni casi il comportamento B2B è preferibile, lo si potrà adottare agendo sulla configurazione (pesi colonne, sinonimi, pinned/esclusi) senza toccare il codice.

## Dettagli tecnici

- Nuovi file: `src/lib/search/b2bEngine.ts` (porting di `fetchProductsList` ramo ricerca dal progetto B2B), `src/lib/search/b2bSmartQuery.ts` e `src/lib/search/b2bTagDictionary.ts` (varianti B2B dei dizionari).
- Firma allineata a `runAgentHubSearch(query, limit)` → `{ rows, ms, total }` con `matchReason` per riga, così il test bench resta simmetrico.
- File modificati: `src/components/admin/search/SearchTestBench.tsx` (tre colonne + diff), `src/components/admin/search/BatchTestPanel.tsx` (doppia percentuale di allineamento + colonna "portali discordanti").
- Nessuna migrazione database, nessun campo nuovo da aggiungere ai permessi.

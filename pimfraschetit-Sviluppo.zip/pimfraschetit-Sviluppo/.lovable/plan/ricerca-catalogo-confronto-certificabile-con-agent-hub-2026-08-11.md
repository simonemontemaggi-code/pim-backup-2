# Ricerca catalogo — confronto certificabile con Agent Hub

## Diagnosi confermata

Il numero **66** mostrato nello screenshot di Agent Hub non appartiene alla query `condiziona`: sono gli ultimi risultati precedenti, come confermato dall’utente.

Nel codice reale Agent Hub la preview conserva intenzionalmente i dati precedenti durante il cambio query (`useProductsPreview.ts`, `placeholderData: prev`), mentre il testo e il contatore restano visibili. La pipeline definitiva usa invece la query debounced e sostituisce la preview solo quando termina (`CatalogoPage.tsx`). Questo permette temporaneamente — o in caso di richiesta bloccata/errore — di vedere il nuovo termine accanto ai vecchi risultati.

Il banco PIM mostra oggi il risultato definitivo: `condiziona` produce 12 articoli in Agent Hub. Il confronto con “66” era quindi tra due stati diversi, non tra due motori.

## Intervento

1. **Portare la pipeline definitiva Agent Hub senza reinterpretazioni**
   - Riallineare l’oracle alla funzione reale `fetchProductsList` del progetto Agent Hub: query, espansioni, filtri online, recupero padri, deduplica, ranking e paginazione.
   - Mantenere separata l’anteprima veloce: non deve mai essere usata per certificare conteggi o ordinamento.
   - Applicare la configurazione PIM solo al “Nuovo motore”; la colonna Agent Hub resta una baseline immutabile.

2. **Rendere ogni risultato verificabile**
   - Mostrare per ogni colonna: query realmente eseguita, stato `anteprima`/`definitivo`/`errore`, righe caricate e totale definitivo.
   - Azzerare subito i risultati precedenti quando parte un nuovo confronto e ignorare risposte appartenenti a query superate.
   - Non mostrare mai un totale precedente accanto a una nuova query.

3. **Confronto corretto**
   - Confrontare il Nuovo motore soltanto con il risultato definitivo Agent Hub.
   - Tenere B2B come terza baseline indipendente, usando la sua pipeline reale e senza condividere helper Agent Hub dove i due portali differiscono.
   - Nel test di massa registrare query eseguita, primo risultato, insieme dei risultati e ordine; una riga è valida solo quando entrambe le baseline sono definitive.

4. **Correggere il warning React della pagina**
   - Eliminare il passaggio improprio del `ref` a `SynonymsPanel` mantenendo il comportamento di apertura/precompilazione del tab.

5. **Verifica obbligatoria**
   - Testare `condiziona` e un campione di query note direttamente contro la pipeline Agent Hub copiata.
   - Verificare che `condiziona` mostri 12 risultati definitivi nel PIM e che i 66 precedenti non possano più essere attribuiti alla query nuova.
   - Verificare nel browser cambio rapido tra due query, errore di rete, nessun risultato e assenza del warning React.

## Dettagli tecnici

- Sorgente ufficiale: progetto Agent Hub, `src/lib/supabase/products.ts`, `useInfiniteProductsList.ts`, `useProductsPreview.ts` e `CatalogoPage.tsx`.
- La baseline non sarà più descritta come “oracle” generico: esporrà esplicitamente pipeline e fase realmente completata.
- Nessuna modifica al database e nessun nuovo campo articolo: `fieldDefinitions.ts` non richiede aggiornamenti.
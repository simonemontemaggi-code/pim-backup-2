# Pulizia sezione Ricerca catalogo

Due interventi: togliere dalla scheda Impostazioni i parametri che non incidono più sull'ordinamento, e ripulire la tabella sinonimi dalle righe che sono solo singolare/plurale già gestiti in automatico.

## 1. Campi inutili nelle Impostazioni

L'ordinamento oggi è deciso prima dalla fascia (Tier), poi dalla posizione della parola nel titolo, e solo alla fine dal punteggio. Di conseguenza tre pesi sono ridondanti perché il comportamento che descrivono è già garantito dalla fascia:

- "Titolo identico" (già Tier 7)
- "Titolo che inizia con la ricerca" (già Tier 6)
- "Tutte le parole nel titolo" (già Tier 5)

Questi tre campi vengono rimossi dalla UI. I valori restano nella configurazione salvata, quindi nessun cambiamento di comportamento.

Restano visibili e modificabili: codice/barcode esatto, codice parziale, parole del titolo, titolo (singolare/plurale e sinonimi), ultima parola digitata, tassonomia, brand, descrizione lunga, somiglianza.

## 2. Righe sinonimi da eliminare

Il motore riduce già in automatico i plurali per le parole da 5 lettere in su. Verificato che `chiodo`/`chiodi` e `guanto`/`guanti` producono la stessa radice, quindi quelle righe non servono:

- `chiodo → chiodi` — eliminare
- `guanto → guanti` — eliminare

Restano invece i sinonimi veri (brugola/allen, flex/smerigliatrice, cacciavite/giravite, metro/flessometro, ecc.) e `vite → viti`, che va tenuto perché parola corta non gestita in automatico.

## Dettagli tecnici

- `src/pages/AdminCatalogSearchPage.tsx`: togliere `title_exact`, `title_starts`, `title_all_words` da `WEIGHT_LABELS` (la card "Pesi di ordinamento" itera su quella mappa).
- `src/hooks/useCatalogSearch.ts`: rendere opzionali quelle tre chiavi nel tipo `CatalogSearchWeights`, mantenendo il salvataggio dell'intero oggetto `weights` così i valori esistenti non vengono persi.
- Migrazione: `DELETE FROM catalog_search_synonyms` per le due righe plurale (`chiodo`, `guanto`). Nessuna modifica di schema, RPC o indice.
- Nessun impatto su `catalog_search_v2`: la formula continua a leggere i pesi dal JSON di configurazione.

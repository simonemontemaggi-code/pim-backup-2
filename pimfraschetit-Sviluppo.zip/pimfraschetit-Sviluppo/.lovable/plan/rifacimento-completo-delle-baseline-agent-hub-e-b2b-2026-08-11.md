# Rifacimento completo delle baseline Agent Hub e B2B

## Risultato atteso confermato

Per la query `condiziona`, i due portali reali restituiscono entrambi **66 risultati**. Il banco PIM restituisce invece Agent Hub 12 e B2B 1: quindi **nessuna delle due baseline PIM è valida**. Il problema B2B dei confini di parola è una divergenza già individuata, ma non spiega né risolve da solo l'intero disallineamento.

## Intervento

1. **Eliminare entrambe le simulazioni attuali**
   - Non correggere incrementalmente gli oracle attuali: riscrivere le baseline Agent Hub e B2B partendo dalle rispettive sorgenti correnti.
   - Recuperare nuovamente entrambi i progetti portale e identificare l'intera catena realmente eseguita dalla UI, non soltanto una funzione isolata.
   - Includere query, preview/definitivo, filtri, paginazione, conteggio, recupero padri, deduplica e trasformazioni successive alla fetch.

2. **Porting separato e letterale dei due portali**
   - Creare una baseline Agent Hub e una baseline B2B indipendenti, senza helper condivisi salvo quelli identici nelle sorgenti.
   - Copiare tokenizzazione, espansioni, ricerca testuale, filtri online, conteggio e ordinamento senza reinterpretazioni locali.
   - Rimuovere dalla baseline B2B i confini di parola aggiunti nel PIM se non presenti nella sorgente reale.

3. **Rendere entrambe le baseline verificabili**
   - Aggiungere test deterministici delle due pipeline per `condiziona` e per un campione di query note.
   - Per `condiziona`, il test minimo obbligatorio è: Agent Hub **66**, B2B **66**.
   - Registrare query eseguita, totale, insieme ordinato dei codici e primi risultati.
   - Marcare una baseline come non certificata se totale, codici o ordine non coincidono con il rispettivo portale reale.

4. **Correggere banco singolo e test batch insieme**
   - Usare le stesse due funzioni certificate sia nel banco a tre colonne sia nel test di massa.
   - Mostrare chiaramente eventuali errori o baseline non verificata, invece di presentare un numero come definitivo.
   - Solo dopo la certificazione, riallineare il Nuovo motore ad Agent Hub.

5. **Verifica obbligatoria prima della consegna**
   - Eseguire `condiziona` nel banco e ottenere **66 / 66** nelle colonne Agent Hub e B2B.
   - Confrontare codice per codice e ordine per ordine con entrambi i portali, non solo il numero totale.
   - Verificare più query con risultati, senza risultati, codici numerici e ricerca multi-parola.
   - Controllare nel browser che cambio rapido di query, errori e risultati vuoti non mostrino dati precedenti.

## Dettagli tecnici

- File principali: `src/lib/search/portalSearchOracle.ts`, `portalB2bOracle.ts`, i rispettivi helper, `SearchTestBench.tsx` e `BatchTestPanel.tsx`.
- Nessuna modifica al database.
- Nessun nuovo campo articolo: `fieldDefinitions.ts` non richiede aggiornamenti.
- Il lavoro non sarà considerato concluso sulla sola base del conteggio: devono coincidere anche codici e ordinamento con le due pipeline sorgenti.
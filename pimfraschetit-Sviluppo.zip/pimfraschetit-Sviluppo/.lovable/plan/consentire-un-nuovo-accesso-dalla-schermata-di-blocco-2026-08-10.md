# Consentire un nuovo accesso dalla schermata di blocco

## Obiettivo
Permettere a chi entra nel PIM con un account cliente, agente o privo di profilo valido di chiudere quella sessione e autenticarsi subito con un altro account.

## Modifiche previste
- Aggiungere nelle schermate **Accesso non autorizzato** e **Accesso negato** un pulsante evidente **Esci e accedi con un altro account**.
- Al clic, richiamare il `signOut` già esistente nell'`AuthContext`, che elimina sia la sessione Supabase sia l'eventuale token SSO locale.
- Mostrare lo stato di caricamento durante l'uscita e portare l'utente alla pagina `/login`, evitando che resti bloccato o possa fare doppi clic.
- Usare il componente `Button` del design system e mantenere invariata la protezione delle route PIM.

## Verifica
- Accedere con un cliente/agente, aprire `/pim` e verificare la schermata di blocco.
- Premere il nuovo pulsante, verificare il ritorno al login e accedere con un account staff.
- Ripetere il controllo per una sessione senza profilo.

## Note tecniche
La modifica riguarda soltanto `AuthGuard`: non richiede database, nuove API, permessi o aggiornamenti a `fieldDefinitions.ts`.
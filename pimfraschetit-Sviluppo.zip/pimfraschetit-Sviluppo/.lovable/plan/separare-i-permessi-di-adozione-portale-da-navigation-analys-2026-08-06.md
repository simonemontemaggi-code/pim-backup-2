# Separare i permessi di "Adozione Portale" da "Navigation Analysis"

Oggi le due voci del gruppo Analytics condividono la stessa chiave di permesso, quindi nella Matrice Permessi compare una sola riga. Le rendiamo indipendenti: un dipartimento potrà vedere solo Adozione Portale, solo Navigation Analysis, o entrambe.

## Cosa cambia per l'utente

- Nella Matrice Permessi, gruppo **Analytics**, appariranno due sezioni:
  - `Analytics · Navigation Analysis`
  - `Analytics · Adozione Portale`
- La sidebar mostra ciascuna voce solo se il permesso corrispondente è read/write.
- Gli admin continuano ad avere accesso completo, senza configurazione.
- I permessi già assegnati oggi restano su Navigation Analysis; Adozione Portale parte nascosta per tutti i non-admin, finché non viene assegnata nella matrice.

## Dettagli tecnici

1. `src/contexts/AuthContext.tsx`: aggiungere `portal_adoption` all'union `SectionKey` e all'elenco `allSections` usato per il bypass admin.
2. `src/components/layout/PimSidebar.tsx`: la voce "Adozione Portale" usa `section: "portal_adoption"`.
3. `src/App.tsx`: la route `analytics/adozione-portale` usa `<SectionGuard section="portal_adoption">`.
4. `src/pages/AdminPermissionsPage.tsx`: gruppo Analytics → `["navigation_analysis", "portal_adoption"]`.
5. `src/lib/fieldDefinitions.ts`: aggiungere `{ key: "portal_adoption", label: "Analytics · Adozione Portale" }` e ripulire l'etichetta di `navigation_analysis`.

Nessuna migrazione DB: `section_permissions.section_key` è testuale, le righe vengono create al primo salvataggio dalla matrice. Le RPC di Navigation Analysis restano admin-only lato database.

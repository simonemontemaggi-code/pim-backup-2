# Nominativo automatico dal codice

Sì: il nome lo abbiamo già. Il codice `03` corrisponde a Federico Fraschetti e `04` a Gaetano Fiorelli (anagrafica agenti). Lo stesso vale per i clienti, dove il codice cliente è collegato alla ragione sociale.

Quindi la colonna "nominativo" nel file di import non serve più: la si può eliminare e far risolvere il nome al sistema.

## Cosa cambia

**Nell'import righe**
- Sparisce il selettore "Colonna nominativo".
- Resta solo "Colonna codice", che identifica agente o cliente.
- L'anteprima mostra, accanto al codice, il nome risolto automaticamente, così si vede subito se il codice è corretto.
- Se un codice non trova corrispondenza, la riga viene comunque importata e segnalata con un avviso "nominativo non trovato", per non bloccare l'import.

**Nella tabella del report**
- Il nome del destinatario viene mostrato come colonna calcolata subito dopo il codice, sempre aggiornata: se un agente cambia nome, il report lo riflette senza reimportare nulla.
- L'interruttore "Non mostrare il nominativo" continua a funzionare e nasconde questa colonna.

**Compatibilità**
- Se un file contiene comunque una colonna con i nomi, resta trattata come una normale colonna dati e non crea conflitti.
- I report già importati non vanno rifatti.

## Dettagli tecnici

- Il nome del destinatario non viene salvato nelle righe: viene risolto al momento della lettura in base al tipo di destinatario del report.
  - Destinatari "Agenti": lookup su `profiles.agent_code` -> `full_name`.
  - Destinatari "Clienti": lookup su `customers.customer_code` -> ragione sociale.
- Il confronto sui codici usa la stessa normalizzazione già adottata altrove (trim, zero non significativi gestiti, confronto sul codice esatto) per evitare collisioni tipo `0002` / `L002`.
- La funzione `pim_report_rows_for` viene estesa per restituire il nominativo risolto, così Portale Agenti e B2B ricevono lo stesso valore mostrato nel PIM, senza duplicare la logica lato client.
- In `AdminReportDetailPage.tsx` si rimuove lo stato del selettore nominativo e si aggiunge la colonna calcolata all'anteprima e alla tabella righe.

# Dividere "Ultimo ordine" in cliente / agente

Nel pop-up di drill-down dei clienti (Adozione Portale) la colonna "Ultimo ordine" mostra un'unica data, senza distinguere se l'ordine è stato trasmesso dal cliente su B2B o dall'agente.

## Cosa cambia

- La colonna "Ultimo ordine" viene sostituita da due colonne:
  - "Ultimo ord. cliente" — data dell'ultimo ordine con origine cliente B2B
  - "Ultimo ord. agente" — data dell'ultimo ordine trasmesso dall'agente
- Entrambe restano ordinabili come le altre intestazioni, con "—" quando non c'è nessun ordine di quel tipo.
- Gli export Excel e PDF del pop-up riportano le stesse due colonne al posto di quella unica.

## Dettagli tecnici

- `src/hooks/usePortalAdoption.ts`: in `AdoptionCustomerRow` sostituire `ultimoOrdine` con `ultimoOrdineCliente` e `ultimoOrdineAgente`; nell'accumulatore `ordStatsByCode` tenere `lastCli` e `lastAge` aggiornati separatamente in base a `isOrderByCustomer(o)` (stessa logica origine NE/CA già usata per i conteggi).
- `src/components/analytics/CustomerDrilldownDialog.tsx`: aggiornare il tipo `SortKey`, l'elenco colonne, le celle della tabella e le righe di export (Excel + PDF) con i due nuovi campi.

# Fix troncamento codice cliente negli import AS400 (FATCLI / ORDCLI)

## Diagnosi (verificata sui dati e sul codice)

Il taglio non è nel database né nelle RPC: tutte le colonne interessate sono già `text` senza limite di lunghezza, e le RPC `upsert_fatture_storico` / `sync_ordcli` ricevono e scrivono `text` così com'è.

Il taglio è nei parser fixed-width, che leggono solo 4 caratteri dove il campo nel record AS400 ne occupa 6:

- `src/lib/fatcliParser.ts` riga 68 → `slice(L, 1, 4)`
- `supabase/functions/sync-fatture-storico/index.ts` riga 93 → `slice(L, 1, 4)`
- `supabase/functions/sync-fatture/index.ts` riga 98 → `slice(L, 1, 4)`
- `supabase/functions/sync-ordcli/index.ts` riga 74 → `raw.substring(1, 5)`

Questi file **non stanno nel PIM**: stanno nel progetto **HOME** (`appfraschetti.lovable.app`), che scrive sullo stesso database Supabase. Nel PIM non esiste alcun codice che alimenta `fatture_clienti_righe` o `ordcli`.

Prova sul record reale (fattura 25990 del 2026-07-23, file `/QDLS/Portale/FATCLI.txt`):

```text
P10099 26072325990 013321VASI VETRO IMBOCC...
^      ^
|      posizione 8 = data AAMMGG
posizioni 2-7 = codice cliente (6 char, riempito a destra con spazi)
```

Il parser legge solo `1009`. Conteggio sul file corrente: 94.467 righe con codice a 4 char e 83 righe con codice a 5 char, tutte troncate.

## Cosa va corretto

### 1. Parser (progetto HOME — non modificabile da qui)

Campo codice cliente = posizioni 1-6 zero-based, larghezza 6, solo `trim()`, nessun pad, nessuno zero-fill:

- `fatcliParser.ts`, `sync-fatture-storico`, `sync-fatture`: `slice(L, 1, 6)`
- `sync-ordcli`: `raw.substring(1, 7).trim()`

Gli offset successivi restano invariati (la data resta a 7): oggi il parser scarta 2 caratteri come filler, dopo il fix quei 2 caratteri fanno parte del campo cliente.

### 2. Backfill storico `fatture_clienti_righe` — solo dal 20/07/2026

La tabella conserva `raw_line` integrale, quindi il codice pieno è recuperabile senza reimport. I codici a 5 cifre esistono dal 20 luglio 2026, quindi il backfill si limita a quella finestra: su 21.552 righe con `data_fattura >= 2026-07-20` risultano **83 righe** con codice troncato (tutte le altre coincidono già).

```sql
UPDATE public.fatture_clienti_righe
SET codice_cliente = NULLIF(trim(substring(raw_line, 2, 6)), '')
WHERE data_fattura >= '2026-07-20'
  AND raw_line IS NOT NULL
  AND codice_cliente IS DISTINCT FROM NULLIF(trim(substring(raw_line, 2, 6)), '');
```

83 righe: nessun problema di volume, si esegue in un colpo solo. Le righe antecedenti al 20/07 restano invariate.


### 3. Backfill `ordcli`

`ordcli` non conserva la riga grezza e viene ricostruita interamente a ogni import (`TRUNCATE` + insert, ultimo run 2026-08-04 01:45). Non serve backfill: basta il fix del parser e la successiva esecuzione dell'import, che rigenera tutte le 9.108 righe con il codice pieno.

### 4. `cod_cliente2` — limite del file sorgente

Nel record FATCLI il secondo campo cliente (posizione 104) occupa realmente 4 caratteri: per la fattura 25990 contiene `1009` e per la 26174 contiene `1000`, cioè è già troncato all'origine dall'export AS400. Non è recuperabile dal parser. Opzioni:

- allineare `cod_cliente2` a `codice_cliente` nel backfill quando i primi 4 caratteri coincidono (i due campi coincidono in tutti i casi campionati), oppure
- lasciarlo com'è e documentare che il campo autorevole è `codice_cliente`.

Serve una decisione: senza indicazione contraria lo lascio invariato e non lo uso per nessun match.

### 5. Altre tabelle alimentate da AS400 — esito del controllo

| Tabella | Lunghezza max codice | Esito |
|---|---|---|
| `fatture_clienti_righe.codice_cliente` | 4 | troncato |
| `fatture_clienti_righe.cod_cliente2` | 4 | troncato all'origine |
| `ordcli.codice_cliente` | 4 | troncato |
| `resi_ufficio_acquisti.codice_cliente` | 4 | da verificare: 672 righe, nessun codice lungo presente, plausibile assenza di casi |
| `richieste_ricambi.codice_cliente` | 4 | idem, 117 righe |
| `richieste_ordini_non_trattati.cliente_codice` | 4 | scritta da PIM/Agent Hub, solo 22 righe, nessuna evidenza di taglio |
| `resi` | 6 | ok |
| `adepromo` | 5 | ok |
| `scadenziario_rows`, `customer_orders`, `visite_dettaglio` | 5-6 | ok |

Per le tre tabelle "da verificare" il controllo definitivo è confrontare col file sorgente: se anche lì il parser usa larghezza 4 va allargato allo stesso modo.

### 6. Verifica finale

```sql
SELECT DISTINCT numero_fattura, codice_cliente
FROM public.fatture_clienti_righe
WHERE numero_fattura IN ('26174','25990') AND data_fattura >= '2026-07-01';
-- atteso: 26174 -> 10005, 25990 -> 10099
```

Più: `SELECT max(length(codice_cliente)) FROM ordcli;` deve tornare 5 o 6 dopo il primo import successivo al fix.

## Nota su ciò che posso fare da questo progetto

Da qui posso eseguire il backfill SQL su `fatture_clienti_righe` e le verifiche. Le correzioni ai parser vanno applicate nel progetto **HOME**, che possiede `fatcliParser.ts`, `sync-fatture`, `sync-fatture-storico` e `sync-ordcli`. Senza quelle, il prossimo import ricreerebbe righe troncate.

Nessuna normalizzazione di lunghezza verrà introdotta nel PIM: il match sul codice cliente resta uguaglianza esatta di stringa.

## Punti da confermare

1. Backfill limitato a `data_fattura >= 2026-07-20` (83 righe da correggere): confermi?
2. `cod_cliente2`: lascio invariato (consigliato) o lo allineo a `codice_cliente`?

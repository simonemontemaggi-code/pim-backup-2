# Modificare email e cellulare di accesso B2B dalla scheda cliente

## Situazione attuale (verificata)

Per il cliente 8800 (L'AGRICOLA MOGLIANESE) l'email sbagliata `infoi@agrciolamoglianese.it` è salvata in **tre posti** che devono restare allineati:

- `auth.users` — è l'email con cui il cliente fa login sul B2B
- `profiles.email` (+ `profiles.phone_number` per il cellulare)
- `customers.mail_accesso_cliente` — quella mostrata nella scheda cliente

Per questo il campo oggi è in sola lettura: cambiarlo solo nella scheda non cambierebbe il login e creerebbe disallineamento. Serve un aggiornamento server-side che tocchi tutti e tre.

## Cosa faremo

Nella sezione "Accesso portale B2B" della scheda cliente compaiono due pulsanti "Modifica" (uno per l'email, uno per il cellulare), visibili solo agli admin e solo se il cliente è attivato sul B2B.

- **Email accesso B2B**: dialog con la nuova email, validazione formato, conferma. Al salvataggio vengono aggiornati login, profilo e scheda cliente in un colpo solo. Se l'email è già usata da un altro utente compare un messaggio chiaro.
- **Cellulare B2B**: dialog con il nuovo numero (formato internazionale, es. +39...). Aggiorna `profiles.phone_number` e la data di impostazione.

Dopo il salvataggio la scheda si aggiorna subito e mostra i nuovi valori. Nessuna email automatica viene inviata al cliente: se serve avvisarlo, va fatto manualmente.

## Dettagli tecnici

1. Nuova edge function `admin-update-b2b-access`:
   - verifica il bearer token e che il chiamante abbia ruolo `admin` (stesso pattern di `admin-update-user-email`)
   - input: `customer_id`, opzionali `email`, `phone_number`
   - risolve `customers.auth_user_id`; se assente ritorna errore "cliente non attivato sul B2B"
   - email: `auth.admin.updateUserById(uid, { email, email_confirm: true })` + `profiles.email` + `customers.mail_accesso_cliente`; gestione errore duplicato
   - telefono: `profiles.phone_number` + `phone_set_at = now()`
2. Nuovo hook `useUpdateCustomerB2bAccess` in `src/hooks/useCustomers.ts` che invoca la function e invalida `["customer", id]` e `["customers-list"]`.
3. `src/pages/CustomerDetailPage.tsx`: nella `Section` "Accesso portale B2B" aggiungere i due pulsanti + dialog (shadcn `Dialog`), visibili se `role === "admin"` e `c.auth_user_id` presente.
4. Nessuna migrazione DB richiesta; `mail_accesso_cliente` resta non scrivibile dal client (solo via service role).

# Offerte promo: layout dialog + articoli in più offerte

## Problema

Nel dialog "Aggiungi articolo all'offerta" (tab Crea nuovo / Da articoli della promo) l'articolo 282110 mostra l'etichetta `In "MOTOCOMPRESSORI…"` che esce dal riquadro e il pulsante di aggiunta non è raggiungibile. Inoltre lo stesso codice non può essere assegnato a più offerte della stessa promo.

## Cosa cambia

### 1. Layout della riga (dialog e batch)
- La riga articolo non deborda più: descrizione e nome dell'offerta di provenienza vengono troncati, il pulsante di azione resta sempre visibile a destra con larghezza fissa.
- Il nome dell'altra offerta diventa un badge compatto con tooltip (testo completo al passaggio del mouse), non più un pulsante lungo.

### 2. Articoli assegnabili a più offerte
- Il blocco "già in un'altra offerta" viene rimosso: il codice può essere aggiunto anche se presente in un'altra offerta della stessa promo.
- Resta il blocco solo per "già in questa offerta" (duplicato reale nello stesso tema).
- Il badge informativo "anche in <offerta>" resta visibile come avviso, ma non disabilita più il pulsante.
- Stessa logica anche in modalità batch (incolla lista codici) e nell'import per regole: i codici presenti in altre offerte non vengono più scartati; il messaggio "N codici scartati" diventa un semplice avviso informativo "N codici presenti anche in altre offerte".

## Dettagli tecnici

File: `src/components/promo/PromoTemiTab.tsx`
- `useOccupiedByOtherTemi` resta invariato (serve ancora per l'informazione a schermo), ma i suoi risultati non vengono più usati per `disabled` né per filtrare `batchToAdd` / `allowed` in `createBatchPimAndLink` e nel pannello regole.
- `reportConflicts` diventa un toast informativo (variant default) invece di `destructive`.
- Righe `<li>`: `min-w-0` sul contenitore di testo, `truncate` sulla descrizione, `shrink-0` sul blocco azione.
- Nessuna modifica al database: `promo_strutturate_tema_articoli` ha già unique su `(tema_id, cdpar)`, quindi lo stesso cdpar in temi diversi è ammesso.
- Nessun nuovo campo editabile → `fieldDefinitions.ts` non richiede aggiornamenti.

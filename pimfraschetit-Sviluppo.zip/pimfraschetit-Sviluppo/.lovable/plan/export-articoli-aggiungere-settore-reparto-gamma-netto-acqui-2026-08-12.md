# Export Articoli: aggiungere Settore, Reparto, Gamma, Netto Acquisto

## Conferma sul calcolo del prezzo

Sì: il **Netto Acquisto €** è il punto di partenza della catena prezzi. La sequenza usata oggi nel PIM (`src/lib/priceUtils.ts`) è:

```text
Netto Acquisto = Prezzo fornitore (wprsc)
                 x (1 - ScA) x (1 - ScB) x (1 - ScC) x (1 - ScD) x (1 - ScE)
                 x (1 + Maggiorazione)
                 x (1 + Dazio + Trasporto + Altro)

Netto Stoccaggio = Netto Acquisto / Fattore conversione acquisto (wfcas)

Prezzo di Listino = Netto Stoccaggio x (1 + Ricarico listino) x (1 + Ricarico arrotondamento)
```

I dati di partenza stanno nella tabella acquisti `archivio_anag_art_fornitore` (una riga per fornitore/articolo).

## Nuove colonne nel dialog "Esporta Articoli"

Gruppo ANAGRAFICA (o nuovo gruppo TASSONOMIA):
- **Settore** — già presente oggi come `clmer`; resta invariato ma verrà rinominato per chiarezza in "Settore (clmer)".
- **Reparto** — letto dagli attributi articolo (`attributes.reparto`).
- **Gamma** — letto dagli attributi articolo (`attributes.gamma`).

Nuovo gruppo ACQUISTO:
- **Netto Acquisto €** — calcolato con `computeNetPrice` sulla riga acquisto del fornitore abituale dell'articolo (`pcfor`); se manca il fornitore abituale si usa la prima riga acquisto disponibile, altrimenti la cella resta vuota.

Tutte le nuove colonne sono opzionali (non selezionate di default), coerenti col comportamento attuale delle colonne Listino 01.

## Dettagli tecnici

File: `src/components/articles/ExportModal.tsx`

1. Aggiungere in `COLUMN_GROUPS` le voci `attr_reparto`, `attr_gamma` (gruppo Anagrafica) e `netto_acquisto` (nuovo gruppo "ACQUISTO"), tutte con `default: false`.
2. In `handleExport`, trattarle come colonne virtuali (come già fatto per `b2b_online` / `listino_01_*`):
   - se richieste `attr_reparto`/`attr_gamma`, forzare il fetch di `attributes` e derivare i valori riga per riga, quindi rimuovere `attributes` dall'output se non richiesto esplicitamente.
   - se richiesto `netto_acquisto`, forzare `cdpar` e `pcfor` nella select, poi caricare a blocchi (chunk da 500 cdpar) da `archivio_anag_art_fornitore` i campi necessari al calcolo (`cdpar, cdfor, wprsc, wscfa..wscfe, wmasc, wcpfa, wcpfb, wcpfc`), costruire una mappa cdpar -> riga preferita (match su `pcfor`, altrimenti prima riga) e valorizzare la colonna con `computeNetPrice`, arrotondata a 5 decimali.
3. Etichette export: intestazioni leggibili "Settore", "Reparto", "Gamma", "Netto Acquisto €" (con la logica di header già usata dal file per le colonne virtuali).
4. Valutare l'allineamento di `src/lib/fieldDefinitions.ts` per i campi acquisto usati, se non già mappati nei permessi admin.

Nessuna modifica al database e nessuna modifica alle logiche di prezzo esistenti.

# Allinea tutte le colonne

Nella scheda **Colonne** del report aggiungo una piccola barra sopra la tabella con l'azione "Allinea tutte a…".

## Cosa cambia
- Sopra la tabella colonne compare una riga con etichetta "Allinea tutte a:" e tre pulsanti/tendina: Sinistra, Centro, Destra.
- Scegliendo un valore, tutte le colonne del report vengono aggiornate in un colpo solo con quell'allineamento.
- Le tendine per riga restano invariate per le eccezioni.
- Il controllo è disabilitato se l'utente non ha permesso di scrittura o se non ci sono colonne.
- Toast di conferma al termine.

## Dettagli tecnici
- `src/pages/AdminReportDetailPage.tsx`: nuova mutation `bulkAlign` che esegue un unico `update` su `report_columns` filtrando per `report_id` (invece di N chiamate `saveColumn`), poi invalida la query delle colonne.
- Nessuna modifica al database né alle RPC.

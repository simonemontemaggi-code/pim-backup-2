# Ricerca: i numeri devono cercare anche nei titoli

## Cosa succede oggi

Verificato sul database: i due articoli hanno "789" nel titolo B2B
(`348031` = "piastre giunzione dritte art 789 grafite", `348670` = "... art 789 tropicalizzato"),
e nessun `cdpar` inizia per `789`.

Nella RPC `catalog_search_v2`, quando la query è un unico token di sole cifre (3+),
viene attivato il flag "numerico" e la ricerca si limita **solo** ai codici
(cdpar esatto/prefisso, EAN). Il ramo lessicale e il fuzzy sono esplicitamente
disattivati (`WHERE NOT v_numeric`). Quindi "789" cerca solo codici articolo,
non trova nulla e restituisce zero risultati.

## Cosa cambio

Una sola migrazione che aggiorna `catalog_search_v2`:

- Per le query numeriche la ricerca per codice resta, ma **in aggiunta** viene
  eseguita anche la ricerca lessicale su titoli/tassonomia (e descrizioni se
  abilitate), come per le query testuali.
- L'ordinamento resta quello a Tier: i match di codice restano in cima (Tier 8),
  subito sotto i titoli che iniziano con il numero, poi i titoli che lo contengono.
  Quindi cercando un codice reale il comportamento attuale non cambia, mentre
  "789" ora restituisce anche le piastre.
- Il fuzzy resta disattivato sui numeri (non ha senso e produrrebbe rumore).

## Note tecniche

- Modifica limitata a `public.catalog_search_v2`: il flag `v_numeric` continua a
  guidare il prefisso su `cdpar` e a bypassare `min_chars`, ma non esclude più
  `lex_hits`.
- Nessuna modifica all'indice `catalog_search_index`, alla configurazione, ai pesi
  o all'interfaccia PIM.
- Firma e colonne restituite invariate: nessun impatto su B2B e Portale Agenti,
  che vedranno solo risultati migliori.
- `docs/catalog-search-integration.md` va aggiornato nel punto in cui descrive il
  comportamento delle query numeriche.
- `fieldDefinitions.ts` non richiede modifiche (nessun campo nuovo).

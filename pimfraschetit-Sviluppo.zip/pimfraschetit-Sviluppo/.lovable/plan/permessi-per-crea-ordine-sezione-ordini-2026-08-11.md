# Permessi per "Crea ordine" (sezione Ordini)

## Stato attuale verificato

Nella matrice Admin → Permessi la sezione `sales_orders` espone oggi **una sola azione granulare: "Scarica ordini"** (`download_orders`). Non esiste alcuna azione dedicata alla creazione ordini, quindi la nuova funzione "Crea ordine" (manuale + import Excel) non è ancora codificata nelle autorizzazioni: chiunque abbia `write` su Ordini potrebbe usarla.

## Cosa aggiungere

1. **Nuova azione granulare `create` su `sales_orders`** nella matrice permessi (label "Crea ordine"), accanto a "Scarica ordini".
2. **Gate in UI**: il pulsante "Crea ordine" (e i due flussi manuale/Excel) compare solo se `canAction("sales_orders", "create")`; senza permesso resta nascosto, non solo disabilitato.
3. **Gate lato dati**: le insert degli ordini generati devono passare per policy RLS che richiedono `has_section_permission(uid, 'sales_orders', 'write')`, così il blocco non è aggirabile da devtools.
4. **Allineamento `fieldDefinitions.ts`**: verificare che gli eventuali nuovi campi editabili introdotti dal form ordine siano registrati nella sezione `sales_orders` per la gestione permessi a livello campo.

## Dettagli tecnici

- `src/pages/AdminPermissionsPage.tsx`: `SECTION_ACTIONS.sales_orders = ["create", "download_orders"]` (la action `create` esiste già in `ACTIONS`).
- `src/contexts/AuthContext.tsx`: nessuna modifica, `ActionKey` include già `create`.
- Pagina Ordini: usare `usePermissions().canAction("sales_orders", "create")` per mostrare il pulsante; nessun check su `role === "admin"` raw.
- Migration RLS sulle tabelle ordini toccate dalla creazione manuale/Excel: policy INSERT con `public.has_section_permission(auth.uid(), 'sales_orders', 'write')`. Prima di applicarla elenco le policy esistenti e l'impatto.

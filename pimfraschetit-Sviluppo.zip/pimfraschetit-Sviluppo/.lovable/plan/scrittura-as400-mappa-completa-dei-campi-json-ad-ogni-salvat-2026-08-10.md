# Scrittura AS400: mappa completa dei campi + JSON ad ogni salvataggio

## Obiettivo

1. Produrre una mappa iperdettagliata di **tutte** le voci che il PIM deve poter riscrivere su AS400, allineata 1:1 con i campi degli import AS400 (query01-20 + import XLSX/CSV), limitata ai campi realmente editabili nel PIM.
2. Fare in modo che **ogni salvataggio** su quelle entità generi automaticamente il JSON AS400 (formato attuale) e lo scarichi, come già succede oggi per articoli e promo.

## Situazione attuale (verificata)

Esiste già uno standard JSON in `src/lib/as400Export.ts`:

```text
{ timestamp, user, record, tables: { "<tabella>": [ { operation, key, fields } ] } }
```

Lo usano oggi solo: Articoli anagrafica (`useSaveArticle`), Promo strutturate testate/campagne/elementi (`usePromoSave`), Prezzi in attesa (`usePrezziInAttesa`), Pianifica prezzo (`PianificaPrezzoDialog`), Tab Sync articolo.

Non generano nulla verso AS400 oggi:
Listini vendita (testate, dettagli, condizioni, criteri prezzo, def. base, campagne), Codici a barre, Fornitori, Anagrafica articolo-fornitore, Tassi di cambio, Differenziale cambio (esiste solo una edge function isolata), Nomenclatura combinata, Promo condizioni, Storico assortimenti (usa un payload non standard).

## Cosa faremo — Fase 1 (questa): solo individuazione delle voci

Nessuna modifica al codice applicativo. Unico output: il documento di mappatura, da rivedere insieme prima di scrivere una riga di codice.

### 1. Documento di mappatura (`docs/as400-write-map.md`)


Per **ogni entità AS400** una tabella con:
- tabella Supabase ↔ file AS400 di origine ↔ query di import corrispondente
- chiave logica AS400 (colonne `key` del payload)
- elenco completo dei campi, con per ciascuno: nome AS400, etichetta IT, tipo/formato (testo, numerico, data AS400 `YYYYMMDD`, codice paddato), **scrivibile su AS400 sì/no**, punto di modifica nel PIM
- campi esclusi perché PIM-only o calcolati/read-only, con motivazione

Entità coperte (tutte):
Articoli, Listini acquisto, Listini vendita (5 tabelle + campagne), Prezzi in attesa, Codici a barre, Fornitori, Anagrafica art.-fornitore, Differenziale cambio, Tassi di cambio, Nomenclatura combinata, Promo strutturate (testate, campagne, elementi, condizioni, articoli), Storico assortimenti.

### 2. Come ricavo l'elenco delle voci

Incrocio tre fonti, campo per campo:
- le colonne effettivamente presenti nelle tabelle Supabase di destinazione;
- i parser di import AS400 (`src/lib/query01Parser.ts` … `query20Parser.ts`) che definiscono nome, posizione e formato di ogni voce lato AS400;
- i form del PIM, per capire quali di quelle voci sono davvero editabili e dove.

Ogni voce viene classificata come: **scrivibile su AS400**, **read-only AS400** (arriva ma non torna indietro) oppure **PIM-only** (non esiste su AS400).

### 3. Formato del documento

Una sezione per entità, con tabella:

```text
Campo AS400 | Etichetta IT | Tipo/Formato | Editabile nel PIM (dove) | Scrivibile AS400
```

Più, in coda ad ogni sezione, la chiave logica AS400 e l'elenco delle esclusioni con motivazione.

## Fase 2 (dopo la tua revisione, non ora)

Quando la lista è confermata: registro centralizzato dei campi scrivibili, hook unico di salvataggio che genera il JSON, collegamento a tutti i salvataggi oggi scoperti (listini, codici a barre, fornitori, nomenclatura, tassi, promo condizioni, assortimenti) e allineamento di `fieldDefinitions.ts` per i permessi. Formato JSON invariato, solo download del file ad ogni salva.


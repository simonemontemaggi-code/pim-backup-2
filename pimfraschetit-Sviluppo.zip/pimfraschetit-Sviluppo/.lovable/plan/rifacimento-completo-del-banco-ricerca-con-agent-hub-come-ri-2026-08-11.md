# Rifacimento completo del banco ricerca con Agent Hub come riferimento reale

## Obiettivo

Eliminare il porting attuale del motore e ricostruire il banco di prova partendo dal progetto **Agent Hub** indicato, senza reinterpretazioni. Il criterio di accettazione iniziale è il caso segnalato: cercando `condiziona`, il riferimento deve rappresentare esattamente i **66 articoli che l’utente vede in Agent Hub**, con gli stessi codici e nello stesso ordine; B2B dovrà essere verificato con lo stesso metodo.

## Stato verificato

- Il PIM oggi non esegue la pagina reale di Agent Hub: usa una copia separata in `agentHubEngine.ts` e una seconda copia in `b2bEngine.ts`.
- Agent Hub usa una pipeline completa composta da barra di ricerca, URL/debounce, preview, infinite query, cache, paginazione automatica e `fetchProductsList`; il banco PIM oggi esegue soltanto una funzione isolata.
- PIM e Agent Hub puntano allo stesso progetto Supabase.
- Con i dati correnti, la sola query isolata raggruppa 12 prodotti per `condiziona`; negli screenshot i portali mostrano 66 articoli e i primi articoli non contengono il termine. Questo conferma che il numero visualizzato dipende dal flusso end-to-end della pagina e non può essere certificato copiando soltanto il filtro SQL.
- Non esistono test automatici che confrontino il banco PIM con l’output visibile dei portali.

## Intervento

### 1. Rimuovere i falsi riferimenti

- Eliminare `agentHubEngine.ts`, `b2bEngine.ts` e i relativi dizionari duplicati usati soltanto dal banco.
- Rimuovere dal banco e dal test di massa ogni etichetta “porting 1:1” finché il confronto non è certificato.
- Conservare le schermate di configurazione PIM e le tabelle già create, ma scollegarle temporaneamente dal confronto durante la ricostruzione.

### 2. Creare un oracle Agent Hub fedele alla pagina

- Portare dal progetto Agent Hub la pipeline effettivamente chiamata dalla pagina catalogo, mantenendo invariati:
  - normalizzazione e propagazione della query;
  - debounce e passaggio preview → smart results;
  - filtri online, token, brand, tag e fuzzy;
  - collasso padre/figlio e ghost parent;
  - ranking, raggruppamento per brand e promozione SKU esatto;
  - paginazione da 50 risultati, caricamento delle pagine successive, deduplica e semantica del conteggio mostrato.
- Separare gli arricchimenti non necessari al banco (prezzi, immagini, stock) senza cambiare l’insieme o l’ordine degli articoli.
- Restituire sia il risultato finale visualizzato sia le fasi intermedie, per distinguere preview, smart result, cache e pagine accumulate.

### 3. Certificare prima `condiziona`

- Acquisire dal flusso Agent Hub i 66 codici effettivamente visualizzati, non solo il numero.
- Aggiungere un test di regressione che richieda per `condiziona`:
  - 66 prodotti finali;
  - stessa sequenza di codici;
  - nessun residuo di una query precedente;
  - risultato stabile dopo attesa del debounce e completamento del caricamento automatico.
- Se il 66 deriva da cache/preview/stato precedente, riprodurre e correggere esplicitamente quel comportamento nel progetto sorgente di riferimento oppure definire il risultato corretto con evidenza dei codici; il banco non mostrerà più un numero ambiguo.

### 4. Ricostruire il banco PIM

- Mostrare per ogni colonna lo stato reale: `preview`, `caricamento`, `completo` o `errore`.
- Visualizzare **caricati** e **totale certificato** come valori distinti; non chiamare “risultati” la sola lunghezza della prima pagina.
- Confrontare codici e ordine, non soltanto il primo articolo o il conteggio.
- Impedire risposte fuori ordine quando l’utente cambia query rapidamente, usando cancellazione della richiesta precedente e un identificatore della ricerca corrente.
- Solo dopo la certificazione Agent Hub, riattivare il “Nuovo motore” applicando la configurazione PIM sopra la stessa pipeline.

### 5. Verificare B2B con il suo progetto reale

- Ripetere la stessa estrazione end-to-end dal progetto B2B, senza riutilizzare o inventare logica Agent Hub.
- Certificare `condiziona = 66` anche per B2B tramite elenco codici e ordine.
- Se i due portali mostrano 66 codici diversi, il banco deve evidenziarlo invece di considerarli equivalenti per il solo conteggio.

### 6. Test di massa e controlli finali

- Rifare il batch test sopra i due oracle certificati e il nuovo motore.
- Aggiungere test per query testuali, multi-token, SKU, barcode, refusi, varianti padre/figlio, cambio rapido di query e pagine oltre la prima.
- Verificare nel browser desktop il caso `condiziona` e confrontare gli elenchi completi, non una schermata parziale.
- `fieldDefinitions.ts` non richiede modifiche: non vengono aggiunti campi articolo né nuovi campi gestiti dai permessi.

## Risultato atteso

Il banco non conterrà più simulazioni dichiarate come reali: Agent Hub sarà il riferimento certificato sull’esperienza effettivamente mostrata, `condiziona` avrà il risultato concordato di 66 articoli verificabili per codice e il nuovo motore potrà essere accettato solo quando coincide davvero.
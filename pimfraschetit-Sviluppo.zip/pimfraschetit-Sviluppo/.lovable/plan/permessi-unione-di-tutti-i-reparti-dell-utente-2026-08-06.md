# Permessi: unione di tutti i reparti dell'utente

## Problema

Il PIM calcola i permessi leggendo **solo il reparto primario** dell'utente. Danilo di Santo ha come primario **Agenti** (nessuna sezione abilitata) e come secondario **Vendite** (permessi completi per il ruolo `collaborator`): risultato, sidebar vuota.

Lato database la regola è già corretta: la funzione di sicurezza usata dalle policy considera **tutti** i reparti dell'utente. È solo l'interfaccia a essere più restrittiva del backend.

## Soluzione

L'interfaccia calcolerà i permessi come **unione di tutti i reparti** a cui l'utente appartiene, con la regola "vince il più permissivo": scrittura > lettura > nascosto.

Effetti:
- Danilo vede tutte le sezioni di Vendite pur restando nel reparto Agenti.
- Vale per qualunque utente multi-reparto (allineamento tra UI e regole del database).
- Il reparto primario resta quello mostrato nel profilo e usato per le preferenze di reparto.

## Dettagli tecnici

`src/contexts/AuthContext.tsx`:
- sostituire la query su `user_departments` filtrata con `is_primary = true` con il recupero di **tutti** i `department_id` dell'utente (fallback su `profiles.department_id` se la lista è vuota);
- mantenere una query separata per il reparto primario, usata solo per `departmentName`;
- caricare `section_permissions` con `.in("department_id", deptIds)` filtrando sul ruolo effettivo come oggi;
- costruire la mappa dei permessi con merge per `section_key` secondo la precedenza `write > read > hidden`;
- lasciare invariati il bypass admin e il resto del contesto.

Nessuna modifica al database e nessun impatto sulle policy RLS.

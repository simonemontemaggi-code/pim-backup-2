# Agenti: il salvataggio non scrive nulla (nessun errore mostrato)

## Cosa succede davvero

Verificato sul database: il profilo con codice agente `11` ha ancora `full_name = "Generico 11"`. Il salvataggio di "RM NORD OVEST" non è mai arrivato a destinazione, ma l'app ha comunque mostrato "Agente salvato".

Causa confermata: le regole di accesso alla tabella `profiles` permettono la modifica solo a:

- l'utente sul proprio profilo, oppure
- un amministratore.

Un utente `assistant_manager`, anche con permesso di scrittura sulla sezione Agenti, aggiorna 0 righe. Postgres non restituisce errore in questo caso, quindi la UI mostra il toast di successo pur non avendo salvato niente.

## Cosa fare

1. **Allineare le regole di accesso alla matrice permessi**
   Sostituire la regola di modifica su `profiles` con una che consenta l'aggiornamento anche a chi ha permesso di scrittura sulla sezione `agents` (tramite l'helper già in uso `has_section_permission`), mantenendo intatti i casi "proprio profilo" e "admin".

2. **Rendere il salvataggio onesto in UI**
   In `src/pages/AgentsPage.tsx`, nelle mutation di salvataggio e rimozione, richiedere le righe modificate (`.select("id")`) e, se il risultato è vuoto, mostrare un errore chiaro ("Permessi insufficienti: nessuna modifica salvata") invece del toast di successo. Stesso trattamento per la rimozione del codice agente.

## Dettagli tecnici

- Migration: `DROP POLICY "Users can update their own profile" ON public.profiles` e ricreazione come
  `USING (auth.uid() = user_id OR is_admin(auth.uid()) OR has_section_permission(auth.uid(),'agents','write'))`
  con lo stesso `WITH CHECK`.
- Nessun nuovo campo dati: `fieldDefinitions.ts` non richiede aggiornamenti.
- Nessuna modifica al comportamento per admin e agenti sul proprio profilo.

## Nota

Con questa regola, chi ha scrittura su "Agenti" potrà modificare i profili di altri utenti (nome, codice agente, listino, email ordini, telefono). Se preferisci limitare la modifica ai soli profili che sono già agenti, si può restringere la condizione ai record con `agent_code` valorizzato.

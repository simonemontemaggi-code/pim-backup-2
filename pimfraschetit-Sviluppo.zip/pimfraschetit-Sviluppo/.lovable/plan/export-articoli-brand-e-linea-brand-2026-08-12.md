# Export articoli: Brand e Linea Brand

## Obiettivo
Poter selezionare ed esportare anche **Brand** e **Linea Brand** dal dialog "Esporta Articoli".

## Situazione attuale
Nel gruppo ANAGRAFICA del dialog export esiste già la colonna `clas2` ma è etichettata genericamente "Classe 2" (nel PIM è il **Brand**). La **Linea Brand** (`nmdis`, campo PIM-only collegato al brand) non è presente tra le colonne esportabili.

## Modifiche
- In `src/components/articles/ExportModal.tsx`, gruppo ANAGRAFICA:
  - rinominare la colonna `clas2` da "Classe 2" a **"Brand (clas2)"**;
  - aggiungere la colonna `nmdis` con etichetta **"Linea Brand"** (non selezionata di default, come le altre colonne opzionali).
- Nessun'altra logica da toccare: entrambi i campi sono colonne dirette di `archivio_articoli_fraschetti`, quindi vengono già gestite dal fetch batch e dalla scrittura CSV/XLSX esistente.

## Note
Nessuna modifica a database, permessi o `fieldDefinitions.ts`: `clas2` e `nmdis` sono già registrati nei permessi field-level della sezione anagrafica articoli.

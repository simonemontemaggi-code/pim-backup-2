# Correzione EAN nell'indice di ricerca centralizzato

## Diagnosi (verificata sui dati reali)

Tabella `archivio_codici_barre_fraschetti` — 36.674 righe:

| Colonna | Significato reale | Valori non vuoti | Esempi |
|---|---|---|---|
| `wcdpa` | codice articolo (cdpar, pad 6) | 36.674 | `001010`, `002085` |
| `wcpba` | **barcode EAN/GTIN** | 36.663 (34.033 distinti) | `8015230010103`, `8011576000341` |
| `wcbda` | **data** (AAAAMMGG), non un barcode | 36.674 | `20240619`, `20170201` |

Lunghezze delle sole cifre di `wcpba`: 13 → 36.573, 12 → 71, 14 → 14, 8 → 3, 7 → 1, 6 → 1, vuoto → 11.

Collegamento articoli: 30.544 codici articolo distinti trovano corrispondenza in `archivio_articoli_fraschetti`, 3.817 sono orfani.

**Causa esatta**: la migration di `catalog_search_upsert` popola `ean_extra` leggendo `b.wcbda`, cioè la colonna data. Per questo l'indice contiene valori come `20170201` e quasi nessun EAN reale (`ean` valorizzato solo su 5 righe, perché deriva da `articoli.barcd` che è quasi sempre vuoto).

## Cosa faremo (una sola migration nuova)

1. **Sorgente EAN corretta** in `catalog_search_upsert`:
   - join su `btrim(wcdpa) = btrim(cdpar)`;
   - barcode letto da `wcpba`, tenute solo le cifre, scartate le stringhe vuote, deduplicate;
   - accettati GTIN-8 / 12 / 13 / 14; i codici di altra lunghezza (6-7 cifre, pochissimi casi) vengono comunque conservati ma segnalati nel report, non eliminati;
   - `wcbda` non viene più usato come EAN.
   - `ean` principale = il primo EAN-13 valido (checksum GTIN corretto), altrimenti il primo GTIN valido, altrimenti il primo codice disponibile in ordine stabile. Tutti gli altri finiscono in `ean_extra`.
2. **Indicizzazione**: ricerca EAN riscritta con operatore compatibile GIN (`ean_extra @> array[...]`) più indice B-tree su `ean`; verifica con EXPLAIN ANALYZE. Se il piano non usa l'indice, si passa a una tabella normalizzata `catalog_search_eans` (una riga per barcode, B-tree). La firma pubblica di `catalog_search_v2` resta invariata.
3. **Match EAN in `catalog_search_v2`**: un token tutto numerico di lunghezza 8/12/13/14 viene trattato come barcode esatto, con priorità pari al codice articolo esatto, senza stemming, sinonimi o fuzzy; rispetta `p_channel` e `p_allowed_cdpars` e restituisce `matched_cdpar` corretto ed `effective_visible_cdpar` (variante pubblicata se il padre non lo è).
4. **Aggiornamento dati mirato**: rilancio dell'upsert solo sui `cdpar` presenti nella tabella barcode (nessuna ricostruzione totale), log in `catalog_search_rebuild_log`, incremento di `catalog_search_config.version`. Nessuna modifica a visibilità, titoli o ranking.
5. **Test con EAN reali** (estratti dai dati, nessun codice inventato): un GTIN-8, un GTIN-12, un EAN-13, un GTIN-14, un articolo con più barcode, un barcode di variante, uno di prodotto non pubblicato, uno inesistente. Per ognuno: canale, visible_cdpar, matched_cdpar, score, tempo RPC.
6. **guanto/guanti**: eseguiremo la query sui tre canali (`pim`, `b2b`, `agent`) e riporteremo total_count, articoli pubblicati, collassamenti padre/variante e set di `visible_cdpar`. Correggeremo solo se guanto e guanti divergono dentro lo stesso canale o se b2b e agent divergono tra loro; la differenza 55 (pim) vs 44 (b2b/agent) verrà spiegata, non "riparata" pubblicando articoli.
7. **Non regressione**: `condizionatore` (13 risultati, primo 496575), pinza/pinze, vite/viti, `UL050` / `UL 050` / `UL-050`, `condizi`, `496965`, paginazione, nessun visible_cdpar non pubblicato, tempi query testuali confrontati prima/dopo.

## Consegna finale

Report con: causa, colonne reali, migration creata, strategia di indicizzazione, EAN recuperati (articoli con almeno un EAN prima/dopo, EAN distinti, articoli multi-EAN, scartati, orfani), test reali, spiegazione 44/55, nuova config_version, tempi prima/dopo e conferma che nessun portale è stato toccato.

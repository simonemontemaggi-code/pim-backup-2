# Certificare le baseline Agent Hub e B2B sui risultati reali

## Risultato verificato

Per `condiziona`, i dati reali contengono **105 righe articolo** che, dopo il raggruppamento padre/varianti usato dai portali, diventano esattamente **66 prodotti** quando la ricerca usa la radice italiana `condizion`.

Il risultato atteso del banco PIM è quindi vincolante:

```text
Agent Hub oggi: 66
B2B Mock up oggi: 66
```

## Intervento

1. **Riscrivere entrambe le baseline**
   - Eliminare le simulazioni attuali che restituiscono 12 e 1.
   - Applicare la stessa espansione italiana effettivamente necessaria per il risultato osservato: `condiziona` → `condizion`.
   - Conservare separate le pipeline Agent Hub e B2B per le differenze reali su filtri, ranking e paginazione.

2. **Replicare l'intera trasformazione mostrata dai portali**
   - Ricerca sui campi catalogo effettivi.
   - Solo articoli online.
   - Recupero del padre per i figli trovati.
   - Un solo risultato visibile per padre/standalone.
   - Deduplica, ranking e ordinamento finali.
   - Conteggio sui prodotti visibili, non sulle righe articolo grezze.

3. **Usare un'unica implementazione per banco e test batch**
   - Le colonne del banco singolo e i test di massa devono invocare le stesse due funzioni baseline.
   - Nessun conteggio separato o stimato nella UI.
   - Cambio query, errori e risultati vuoti devono azzerare immediatamente i dati precedenti.

4. **Certificazione obbligatoria**
   - Test automatico: `condiziona` deve restituire 66 per Agent Hub e 66 per B2B.
   - Confrontare anche l'insieme ordinato dei `cdpar`, non soltanto il totale.
   - Verificare query numeriche, multi-parola, senza risultati e con varianti padre/figlio.
   - Nel banco, mostrare “Certificato” solo dopo il superamento dei controlli; altrimenti mostrare l'errore senza presentare il dato come definitivo.

5. **Nuovo motore**
   - Solo dopo la certificazione delle due baseline, riallineare il Nuovo motore al comportamento scelto.

## Dettagli tecnici

- File principali: `src/lib/search/portalSearchOracle.ts`, `src/lib/search/portalB2bOracle.ts`, helper linguistici dedicati, `SearchTestBench.tsx`, `BatchTestPanel.tsx`.
- Nessuna modifica al database.
- Nessun nuovo campo articolo: `fieldDefinitions.ts` non richiede aggiornamenti.

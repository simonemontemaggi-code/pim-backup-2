# Motore di ricerca: allineamento reale ad Agent Hub

## Il problema

Le colonne "Agent Hub (oggi)" e "B2B (oggi)" del banco di prova **non sono i motori veri**: sono una riscrittura semplificata scritta nel PIM (`src/lib/search/legacyEngines.ts`, 246 righe) che imita a memoria il comportamento dei portali.

Il motore vero di Agent Hub è la pipeline in `src/lib/supabase/products.ts` del progetto Agent Hub (~700 righe di logica di ricerca) più `smartQuery.ts` e `tagDictionary.ts`, e fa cose che la copia semplificata non fa:

- token in AND (tutti i token devono matchare), non somma di punteggi
- espansione morfologica italiana + sinonimi + varianti per ogni token
- risoluzione brand (`clas2` da `archivio_brand_fraschetti`) e tag per ogni token
- fast-path numerico (cdpar prefix, barcode, EAN via `archivio_codici_barre_fraschetti`)
- fallback fuzzy con troncamenti e controllo Levenshtein quando non c'è nulla
- collasso padre/figlio (i figli vengono risolti al padre, padri mancanti recuperati)
- ranking a pesi di campo + raggruppamento per brand oltre i primi 10 risultati
- promozione del cdpar esatto in prima posizione

Per questo i confronti non hanno senso: il "riferimento" non è il riferimento. Ed è anche il motivo dello 0 risultati della colonna B2B: quella copia costruisce filtri `ilike` a parola intera (`% parola %`) combinati con lo stemming, e su molte query non matcha nulla mentre il portale vero trova risultati.

## Cosa faccio

### 1. Porto il motore vero di Agent Hub dentro il PIM
Copio dal progetto Agent Hub i file `smartQuery.ts` e `tagDictionary.ts` ed estraggo la pipeline di ricerca+ranking di `products.ts` in un modulo `src/lib/search/agentHubEngine.ts`, senza modifiche di comportamento (stessi pesi, stesse soglie, stesso ordine di fasi). Diventa lui la colonna "Agent Hub (oggi)": ciò che vedi nel banco di prova sarà esattamente ciò che vede l'agente.

### 2. Il nuovo motore riproduce Agent Hub 1:1
La RPC `pim_search_articles` viene riscritta perché, con la configurazione di default, restituisca lo stesso insieme e lo stesso ordine di Agent Hub:

- token in AND con espansione per forme (morfologia, sinonimi, brand, tag)
- fast-path numerico e fallback fuzzy identici
- collasso padre/figlio e promozione cdpar esatto
- pesi campo e raggruppamento brand identici, ma **letti dalle tabelle di configurazione** (`search_fields`, `search_settings`, `search_synonyms`) invece che hardcoded

Così il default è "Agent Hub esatto" e ogni scostamento diventa una scelta esplicita fatta dalle tue schermate di configurazione.

### 3. Elimino la colonna B2B finta
La colonna "B2B (oggi)" resta solo se posso portare anche lì il codice reale del progetto B2B Mock up con lo stesso metodo; altrimenti la tolgo, perché mostrare "0 risultati" da una simulazione sbagliata è peggio che non mostrarla.

### 4. Test di massa come prova
Il pannello di test di massa gira contro il motore vero: l'obiettivo diventa 100% di allineamento su un campione di catalogo, non 98% su query a vuoto. Le righe disallineate mostrano quale fase diverge (token, brand, fuzzy, padre/figlio, ranking).

## Note tecniche

- Nuovi file nel PIM: `src/lib/search/agentHubEngine.ts`, `src/lib/search/smartQuery.ts`, `src/lib/search/tagDictionary.ts`
- `src/lib/search/legacyEngines.ts` viene rimosso
- La RPC `pim_search_articles` viene sostituita con una nuova versione (migrazione); firma invariata (`_q`, `_limit`, `_offset`, `_config`) quindi `useSearchConfig.ts` e i pannelli non cambiano API
- Nessun impatto sui portali finché non li agganciamo: questa fase resta interna al PIM
- `fieldDefinitions.ts` non richiede nuovi campi (nessuna colonna nuova su articoli)

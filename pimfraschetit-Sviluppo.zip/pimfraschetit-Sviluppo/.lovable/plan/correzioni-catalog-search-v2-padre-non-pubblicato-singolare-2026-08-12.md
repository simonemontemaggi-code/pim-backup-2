# Correzioni catalog_search_v2 (padre non pubblicato, singolare/plurale, codici con spazi)

Una sola migration correttiva. Nessuna modifica ai portali, nessun articolo reso pubblico, firma della RPC invariata.

## Diagnosi (verificata sul database)

**1. Padre non pubblicato — confermato**
`496560` (padre) ha `b2b_visible = false` e `agent_visible = false`; le varianti `496565`, `496570` sono anch'esse non visibili, mentre `496575` è visibile su entrambi i canali. Nell'indice tutte e quattro le righe hanno `visible_cdpar = 496560`: la colonna è statica e punta sempre al padre, senza controllo di pubblicazione. Con `p_channel = 'agent'` la RPC filtra i candidati sulla visibilità (quindi entra solo `496575`), ma poi collassa su `visible_cdpar = 496560` e restituisce un codice che i portali non possono idratare. Nella ricerca `condizionatore` (13 risultati su agent e b2b) è esattamente il primo risultato. In tutto l'indice ci sono 10.583 righe con `visible_cdpar <> cdpar`, quindi il caso non è isolato.

**2. Singolare/plurale — causa individuata: sinonimi applicati alla forma digitata, non alla forma canonica**
`catalog_search_stem` produce già la stessa radice per le coppie regolari (`guanto`/`guanti` → `guant`, `pinza`/`pinze` → `pinz`, `condizionatore`/`condizionatori` → `condizionator`). La differenza nasce nel lookup dei sinonimi, che confronta `catalog_search_norm(term)` con il token digitato:

- `guanto` → sinonimo attivo `protezione mani` → tsquery `'guant' | 'guant':* | 'protezion' & 'mani' | 'protezion' & 'mani':*` → 56 risultati;
- `guanti` → nessun sinonimo → tsquery `'guant' | 'guant':*` → 42 risultati.
- I 14 codici presenti solo in `guanto` (es. `077118`, `509600`, `317037`) entrano dal ramo `protezione mani` (descrizione/tassonomia) o dal fuzzy, non dal ramo lessicale del termine.
- Identico per `pinza` (sinonimo `tronchese`, 82) vs `pinze` (80): i 2 codici in più sono `109041` e `109104`.
- `vite`/`viti`, `punta`/`punte`, `scala`/`scale`, `pennello`/`pennelli`, `condizionatore`/`condizionatori` hanno già lo stesso totale; per `vite`/`viti` la parità è dovuta al sinonimo esplicito bidirezionale già presente.

Non è un problema di indice obsoleto: i vettori dell'indice sono coerenti con la funzione di stemming attuale.

**3. Codici alfanumerici con spazi — confermato**
`catalog_search_norm` produce `ul050` per `UL050` ma `ul 050` per `UL 050` e `UL-050`. `UL050` trova 14 risultati (match sul titolo, es. `515600 .CHIAVI SWING FLUO OLC UL050 B`), mentre `UL 050`/`UL-050` ne trovano 3 completamente diversi. Manca una normalizzazione codice compatta.

## Modifiche previste (una migration)

**A. Scelta del prodotto visibile dentro la RPC**
Calcolare `effective_visible_cdpar` per riga di match:
- se esiste `cod_padre`, il padre è presente in `catalog_search_index`, è visibile nel canale richiesto (`pim`: basta esista; `b2b`: `b2b_visible`; `agent`: `agent_visible`), non è escluso da `catalog_search_product_overrides.excluded_from_search` e — quando `p_allowed_cdpars` non è null — appartiene alla whitelist → si usa il padre;
- altrimenti si usa il `cdpar` della variante che ha generato il match.

Il collasso `DISTINCT ON` e la deduplica passano da `visible_cdpar` a `effective_visible_cdpar`; `matched_cdpar` resta il codice reale del match, `cod_padre` resta la relazione originale, `score`/`tier`/`title_pos` restano quelli del miglior articolo che ha generato il match. Titolo e brand restituiti vengono presi dalla riga dell'articolo effettivamente mostrato (con fallback sulla riga di match se mancanti); in `match_reasons` si aggiungono `matched_title` e `collapsed_to` per tracciare il prodotto che ha generato il match. Ordinamento invariato e stabile, una sola riga per prodotto visibile.

**B. Sinonimi sulla forma canonica**
Il lookup dei sinonimi confronterà `catalog_search_stem(catalog_search_norm(term))` con lo stem del token digitato (e specularmente per i sinonimi bidirezionali). Così `guanto` e `guanti` generano la stessa tsquery e lo stesso insieme di candidati; la forma digitata continua a influenzare solo il punteggio (`word_hits`, `title_word_hits`, `title_is_exact`, `title_starts`, `title_pos`) e quindi solo l'ordine. Nessun sinonimo regolare verrà aggiunto a mano.

**C. Normalizzazione codice compatta**
Nuova funzione immutabile `catalog_search_code_norm(text)` che rimuove spazi, trattini e punteggiatura (`UL050`, `UL 050`, `UL-050` → `ul050`). Viene usata solo quando la query è riconosciuta come codice alfanumerico: token unico con lettere e cifre, oppure due token di cui uno alfabetico e uno numerico, eventualmente separati da spazio o trattino. In quel caso il ramo codice confronta il valore compatto con `cdpar`/EAN (uguaglianza = priorità massima, poi prefisso) e con la forma compatta dei testi brevi indicizzati, così le tre scritture restituiscono lo stesso insieme e lo stesso ordine. Le query testuali composte normali (es. `guanti nitrile`) non vengono trattate come codice.

Per rendere efficiente il confronto compatto sui testi si aggiunge alla `catalog_search_index` una colonna `compact_norm` (testo breve senza separatori) con indice trigram, popolata da `catalog_search_upsert` e dal rebuild.

**D. Versione e rebuild**
Incremento di `catalog_search_config.version` (da 5 a 6) tramite il trigger esistente. Il rebuild dell'indice viene eseguito una sola volta, necessario per popolare `compact_norm`, e resta tracciato in `catalog_search_rebuild_log`. Firma di `get_catalog_search_config` invariata; nessuna cache dei portali toccata.

## Verifiche dopo la migration

- Per ogni riga con `p_channel = 'b2b'` controllo che il `visible_cdpar` restituito abbia `b2b_visible = true`; idem `agent_visible` per `agent`; controllo di appartenenza alla whitelist quando `p_allowed_cdpars` è valorizzato (padre fuori whitelist → deve uscire la variante).
- `condizionatore`: ancora 13 risultati, con il confronto vecchio/nuovo `visible_cdpar`, `matched_cdpar`, stato di pubblicazione e ordine completo dei 13.
- Coppie singolare/plurale (`guanto/guanti`, `vite/viti`, `punta/punte`, `pinza/pinze`, `scala/scale`, `pennello/pennelli`, `condizionatore/condizionatori`): totale, differenza fra i set (attesa vuota), primi 10 risultati e spiegazione delle differenze di ordine.
- `UL050`, `UL 050`, `UL-050`: stesso insieme e stesso ordine.
- `guanti nitrile`, `viti mustad`, `condizi` (nessun peggioramento, niente concimi), `496965`, un EAN esatto.
- Paginazione senza duplicati, `total_count` stabile, ordine deterministico, nessun risultato che arrivi solo dalle descrizioni fra i primi posti.
- Tempi di esecuzione delle query principali.

## Note tecniche

- Nessuna migration storica modificata; nessun oggetto rinominato; nessun portale toccato.
- `b2b_online_effective` e la pubblicazione degli articoli non vengono modificati.
- Nessun nuovo campo AS400 o di anagrafica: `fieldDefinitions.ts` non richiede aggiornamenti.

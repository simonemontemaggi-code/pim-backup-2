# Fix codice cliente a 5 cifre nel TXT ordini

## Problema

Nel builder TXT (`src/lib/orderTxtFormat.ts`) il codice cliente viene forzato a 4 caratteri con `padCode(o.codice_cliente, 4)`, che tiene solo le **ultime 4 cifre**: `10099` diventa `0099`. Subito dopo vengono scritti sempre 2 spazi di separatore.

## Regola corretta

Il campo occupa sempre 6 caratteri (posizioni 1-6 della riga):

```text
4 cifre -> "0099  "   (codice + 2 spazi)
5 cifre -> "10099 "   (codice + 1 spazio)
6 cifre -> "100992"   (codice, nessuno spazio)
```

Zero-padding a sinistra solo fino a 4 cifre; il resto del campo si riempie con spazi a destra. La lunghezza totale della riga resta 47 caratteri, tutti gli altri offset sono invariati.

## Modifiche

1. `src/lib/orderTxtFormat.ts`
   - Nuovo helper `formatCustCode(code)`: rimuove i non-numerici, zero-pad a 4, poi pad-right con spazi fino a 6, troncando a 6 se piu lungo.
   - Usarlo in `formatItemRow` e `formatNoteRows` al posto di `padCode(...,4) + "  "` (eliminando il separatore fisso).

2. `src/lib/orderTxtParser.ts`
   - Leggere il codice cliente da `line.substring(1, 7).trim()` invece di `substring(1, 5)`.
   - Aggiornare i commenti di layout (campo cliente = 6 char, niente separatore separato).
   - Progressivo, cdpar, quantita, prezzo, origine, transmission id restano agli stessi offset.

3. Nessun cambio a `SalesPromoControlPage` / `OrderDetailDialog`: usano `custCode` come stringa gia trimmata e il match con `customers` avviene sul codice reale (ora corretto anche a 5 cifre).

## Verifica

- Generare un TXT per un ordine con cliente `10099` e controllare che la riga inizi con `A10099 ` e sia lunga 47 caratteri.
- Ricaricare lo stesso TXT in Controllo Ordini Promo: il cliente deve risultare `10099` con ragione sociale risolta.

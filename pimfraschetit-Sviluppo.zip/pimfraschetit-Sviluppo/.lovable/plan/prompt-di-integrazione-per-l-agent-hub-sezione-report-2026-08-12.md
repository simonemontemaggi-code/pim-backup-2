# Prompt di integrazione per l'Agent Hub — Sezione Report

Il PIM ha già esposto tutto il necessario (tabelle + RPC + RLS) nello stesso Supabase condiviso. Non servono modifiche al PIM. L'utente vuole solo il prompt da incollare nel progetto Agent Hub. Copia il blocco qui sotto e invialo al progetto **Agent Hub**.

---

## PROMPT DA INVIARE AD AGENT HUB

Il PIM Fraschetti ha una nuova sezione **"Report"** (configurata in Amministrazione → Report). I report sono gestiti dal PIM e salvati nello **stesso Supabase condiviso** (`ytkofsktbkuzgzhzhiys`) che usa già l'Agent Hub. L'Agent Hub deve mostrare agli agenti i report a loro destinati (`audience = 'agent'`), con i dati personalizzati per ciascun agente.

**Non creare tabelle né RPC: tutto è già esposto in lettura.** Devi solo costruire la UI che legge e visualizza i report.

### Modello dati (già esistente, Supabase condiviso)

`reports`: `id uuid, ref_id bigint, title text, description text, date_start date, date_end date, sort_order int, audience text ('agent'|'customer'), show_only_if_present bool, show_only_own bool, hidden bool, hide_recipient_name bool, created_at, updated_at`

`report_columns`: `id uuid, report_id uuid (FK reports), col_key text, label text, suffix text, group_label text, align text ('left'|'center'|'right'), visible bool, sort_order int`

`report_rows`: `id uuid, report_id uuid, recipient_code text, recipient_name text, values jsonb (chiave = col_key), sort_order int`

### Accesso (RLS già configurate — l'Agent Hub è read-only)

- SELECT pubblico (anon + authenticated) su `reports` dove `hidden = false` AND data valida (`date_start IS NULL OR date_start <= today`) AND (`date_end IS NULL OR date_end >= today`). **La policy NON filtra `audience`: devi filtrare `.eq('audience','agent')` lato client.**
- SELECT pubblico su `report_columns` e `report_rows` solo per report pubblicati.
- L'Agent Hub **non scrive mai** su queste tabelle (nessuna INSERT/UPDATE/DELETE).

### RPC personalizzata (usala per le righe)

`pim_report_rows_for(_report_id uuid, _code text)` → restituisce `TABLE(id, recipient_code, recipient_name, "values" jsonb, sort_order)`. SECURITY DEFINER, granted a anon/authenticated.

Comportamento già gestito dalla funzione (non replicarlo in TS):
- ignora report hidden o fuori date (ritorna vuoto);
- se `show_only_if_present = true`: ritorna righe solo se l'agente (`_code`) è presente tra i `recipient_code`;
- se `show_only_own = true`: ritorna solo le righe con `recipient_code = _code` (i dati dell'agente); se `false` ritorna tutte le righe del report;
- se `hide_recipient_name = true`: `recipient_name` è NULL;
- `recipient_name` è già risolto dalla funzione `pim_report_recipient_name(audience, code)` (lookup su `profiles` per agenti, `customers` per clienti).

### Codice agente

L'agente autenticato ha un `profiles.agent_code`. Recuperarlo dal profilo dell'utente loggato (es. `supabase.from('profiles').select('agent_code').eq('id', user.id).single()`) e passarlo come `_code` alla RPC.

### Cosa costruire nell'Agent Hub

1. Voce di menu **"Report"** che porta a una pagina lista.
2. **Pagina lista** — carica i report agent attivi:
   `supabase.from('reports').select('id,title,description,date_start,date_end,sort_order,show_only_if_present,show_only_own,hide_recipient_name').eq('audience','agent').order('sort_order',{ascending:false})`
   (RLS esclude già hidden/fuori date). Mostra titolo + descrizione + periodo. Ordina per `sort_order` desc.
3. **Cliccando un report** → vista tabella:
   - Colonne: `supabase.from('report_columns').select('col_key,label,suffix,group_label,align,visible,sort_order').eq('report_id',id).order('sort_order')` → usa solo `visible = true`.
   - Righe: `supabase.rpc('pim_report_rows_for', { _report_id: id, _code: agentCode })` → `{id, recipient_code, recipient_name, values, sort_order}`.
   - Se `show_only_if_present = true` e nessuna riga → stato vuoto "Nessun dato disponibile per questo report".
   - Render: per ogni riga, per ogni colonna visibile (in ordine `sort_order`), cella = `values[col_key]` + (`suffix` se presente); allineamento cella secondo `align`; raggruppa colonne per `group_label` se presente (intestazione di gruppo).
   - Colonna iniziale "Nominativo": mostra `recipient_name` se presente, altrimenti `recipient_code`; se `recipient_name` è NULL (`hide_recipient_name`) mostra il `recipient_code`.
4. Report con `show_only_own = false` (dati globali): l'agente vede tutte le righe (gestito dalla RPC).
5. Export (gradito): pulsante XLSX della tabella visibile.

### Guardrail di sicurezza

- Mostra **solo** report `audience = 'agent'`. Non elencare né aprire report `audience = 'customer'`. La RPC `pim_report_rows_for` non verifica `audience` (SECURITY DEFINER): non passare mai ID di report customer.
- L'Agent Hub è strettamente read-only su queste tabelle.

### Esempio

```ts
// lista report agent
const { data: reports } = await supabase
  .from('reports')
  .select('id,title,description,date_start,date_end,sort_order,show_only_if_present,show_only_own,hide_recipient_name')
  .eq('audience','agent')
  .order('sort_order',{ascending:false});

// colonne
const { data: cols } = await supabase
  .from('report_columns')
  .select('col_key,label,suffix,group_label,align,visible,sort_order')
  .eq('report_id', reportId)
  .order('sort_order');

// righe personalizzate dell'agente
const { data: rows } = await supabase
  .rpc('pim_report_rows_for', { _report_id: reportId, _code: agentCode });
```

Note: `values` è jsonb; i numeri possono arrivare come stringa o numero — normalizza a numero (soprattutto per colonne con `suffix` tipo valuta/percentuale). `recipient_name` è già risolto dalla RPC.
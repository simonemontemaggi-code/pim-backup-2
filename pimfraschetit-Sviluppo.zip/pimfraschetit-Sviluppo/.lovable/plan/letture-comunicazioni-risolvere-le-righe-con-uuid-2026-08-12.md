# Letture comunicazioni: risolvere le righe con UUID

Nel dialogo "Chi ha letto" alcune righe mostrano un UUID al posto del codice e non hanno nome. Sono letture in cui il portale (B2B o Agent Hub) ha registrato l'ID utente di autenticazione invece del codice cliente/codice agente.

Verifica sui dati attuali: gli UUID presenti corrispondono in maggioranza a utenti interni Fraschetti (Alessio Frasca, Goffredo Todini, Emanuele Antonelli, Eleonora Caldaroni, Fabrizio Rea, Federico Fraschetti) e in due casi a clienti reali (5991 CASULA SNC, 1304 GAMBACORTA ERNESTO).

## Cosa cambia nel dialogo

- Quando `user_identifier` ha forma di UUID, risolverlo sul profilo utente e mostrare:
  - **Codice**: il codice cliente collegato all'utente se esiste, altrimenti il codice agente, altrimenti un trattino.
  - **Nome**: ragione sociale del cliente se esiste, altrimenti nome e cognome del profilo.
- Aggiungere un'etichetta discreta accanto al nome per distinguere chi non è un cliente:
  - "Staff" per gli utenti interni Fraschetti (profili con email aziendale / ruolo non cliente).
  - Nessuna etichetta per i clienti.
- Se un UUID non corrisponde a nessun profilo, mostrare l'UUID abbreviato con etichetta "Utente sconosciuto".
- La ricerca e gli export Excel/PDF usano gli stessi valori risolti, così non compaiono più UUID nelle esportazioni.

## Note tecniche

- File interessato: `src/components/communications/CommunicationReadsDialog.tsx` (solo lettura/presentazione).
- Query aggiuntiva: `profiles` per `user_id` negli identificativi UUID, più `customers` per `auth_user_id` per ottenere `customer_code` e ragione sociale; `user_roles` per distinguere staff da cliente.
- Nessuna migration: i dati storici restano invariati, la risoluzione avviene a runtime.
- Nessun campo AS400 coinvolto: `fieldDefinitions.ts` non va aggiornato.

## Fuori scope

Modificare i portali B2B e Agent Hub perché scrivano il codice invece dell'UUID. Se lo si vuole, va fatto nei rispettivi progetti in un intervento separato.

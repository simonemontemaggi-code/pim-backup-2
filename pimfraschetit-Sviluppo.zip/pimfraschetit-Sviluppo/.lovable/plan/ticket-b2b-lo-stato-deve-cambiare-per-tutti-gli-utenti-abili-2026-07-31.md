# Ticket B2B: lo stato deve cambiare per tutti gli utenti abilitati

## Problema

Quando si invia una risposta dal dettaglio ticket, il cambio di stato (es. → Chiuso) funziona con l'utente admin ma non con altri utenti che hanno i permessi di scrittura sulla categoria.

Verificato sul database:
- La policy di UPDATE su `customer_support_tickets` consente `admin` **oppure** `has_section_permission(uid, ticket_category_section(category), 'write')`.
- L'aggiornamento di stato oggi viene fatto dal browser con `update(...).eq("id", ...)`. Se la policy non lascia passare la riga, PostgREST **non restituisce errore**: aggiorna 0 righe in silenzio. Risultato: la mail parte, il messaggio si salva, ma lo stato resta invariato e l'utente non vede nessun avviso.
- Esiste anche il ruolo `assistant_manager` (2 utenti) che non è coperto da alcune policy di lettura del ticket, quindi può fallire in modo simile.

## Cosa faccio

1. **Sposto il cambio di stato nella Edge Function `send-b2b-ticket-reply`**, che già scrive con service role: dopo aver verificato l'identità del chiamante, controlla lato server se è admin o ha il permesso `write` sulla sezione della categoria del ticket, e in tal caso scrive lo stato finale (o la promozione automatica open → in_progress). Così l'esito non dipende dalla policy vista dal browser.
2. **Il client smette di fare l'update di stato durante l'invio risposta** (`useSendTicketReply`): passa `final_status` alla funzione e usa lo stato restituito per aggiornare la UI.
3. **Errori visibili**: se la funzione risponde "permesso negato" o l'update fallisce, mostro un toast di errore invece di far sembrare che sia andato tutto bene.
4. **Cambio manuale dalla tendina "Stato"**: l'update diretto ora chiede la riga aggiornata (`.select("id")`) e, se torna vuoto, segnala "Permessi insufficienti per cambiare lo stato" invece di fallire in silenzio; in alternativa usa la stessa funzione server.
5. **Nessuna modifica ai permessi**: non allargo RLS né section_permissions. Se dopo il fix un utente vede "permessi insufficienti", il problema è la matrice permessi del suo dipartimento e te lo segnalo con il dettaglio (utente, dipartimento, sezione mancante).

## Dettagli tecnici

- File toccati: `supabase/functions/send-b2b-ticket-reply/index.ts`, `src/hooks/useTicketThread.ts`, `src/pages/B2bTicketsPage.tsx`.
- La funzione verificherà il permesso con la RPC esistente `has_section_permission` + `ticket_category_section` usando l'`auth.uid()` ricavato dal token del chiamante (mai dal body).
- Risposta della funzione estesa con `{ ok, status }` per aggiornare la UI in modo affidabile.
- Verifica finale: invio risposta con un utente non-admin abilitato (dipartimento Vendite / categoria annullamento) e controllo su DB che `status` e `updated_at` cambino.

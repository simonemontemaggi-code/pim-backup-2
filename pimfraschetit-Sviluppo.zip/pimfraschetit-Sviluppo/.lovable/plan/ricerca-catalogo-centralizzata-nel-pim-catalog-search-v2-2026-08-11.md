# Ricerca catalogo centralizzata nel PIM (catalog_search_v2)

Tutta la configurazione del motore di ricerca (sinonimi, esclusioni, pesi, priorità prodotto) vive nel PIM. Il database espone una sola funzione di ricerca versionata che in futuro useranno anche Portale B2B e Portale Agenti. In questa fase i due portali **non vengono toccati**.

## Cosa risulta dall'analisi del database

- Tabella articoli reale: `archivio_articoli_fraschetti` — 58.102 righe totali, 16.351 con `b2b_online_effective = true`.
- Campi utilizzabili per l'indice: `cdpar` (testo con padding a destra), `cod_padre`, `titolo_b2b`, `b2b_product_title`, `descrizione_variante`, `descrizione`, `descrizione_b2b`, `b2b_product_description`, `description_marketing`, `depar` (reparto), `clmer` (categoria merceologica), `clas1`, `clas2` (codice brand), `wdset`, `wstag`, `tags` (array), `attributes` (jsonb), `barcd` (EAN principale), `b2b_online_active`, `b2b_online_effective`, `updated_at`.
- Brand: `archivio_brand_fraschetti` (`clas2` → `display_name` / `nome_as400_brand`).
- EAN aggiuntivi: `archivio_codici_barre_fraschetti` (`wcdpa` = articolo, `wcbda` = barcode).
- Tassonomia editoriale: `taxonomy_content` (`node_type`, `node_code`, `display_name`); etichette da `lookup_values`.
- **Non esiste** una colonna "gamma" sull'articolo: la gamma è derivata dagli attributi (`attributes` / `gamma_attributes.gamma_code`). Verrà popolata da lì, senza inventare nuove fonti.
- Esistono già `fts` e `fts_simple` sulla tabella articoli e la RPC `search_agent_catalog_products` usata oggi dai portali: **restano invariate**.
- Estensione `pg_trgm` già presente; `unaccent` **da abilitare**.

## Migration (idempotenti, nessuna perdita di dati)

1. `unaccent` + funzione immutabile `catalog_search_norm(text)` (lower, unaccent, punteggiatura e spazi normalizzati) per poterla usare negli indici.
2. `catalog_search_index` — chiave `cdpar` normalizzata, `cod_padre`, `visible_cdpar`, `ean`, `ean_extra[]`, titoli, variante, `depar`, `reparto`, `categoria`, `gamma`, `clmer`, `clas1`, `clas2`, brand code/nome, `tags`, attributi di ricerca, visibilità B2B/agenti, testi normalizzati (breve, tassonomico, descrizioni) e tre vettori `tsvector` italiani (titoli, tassonomia+brand+tag, descrizioni), `source_updated_at`, `indexed_at`, `search_config_version`.
   Indici: B-tree su `cdpar`, `ean`, `cod_padre`, brand e visibilità; GIN sui tre tsvector e su `ean_extra`/`tags`; GIN trigram sul testo breve normalizzato.
3. `catalog_search_config` (riga singola), `catalog_search_synonyms`, `catalog_search_exclusions` (vuota), `catalog_search_product_overrides`, `catalog_search_rebuild_log`. GRANT espliciti, RLS attiva, `updated_at`/`updated_by`, trigger che incrementa `version` a ogni modifica di config/sinonimi/esclusioni/override.
4. Funzioni di manutenzione: `refresh_catalog_search_item(text)` (aggiorna la riga e il padre coinvolto), `rebuild_catalog_search_index()` (ricostruzione a batch, tracciata nel log, senza stati parziali) e trigger su `archivio_articoli_fraschetti` che accoda solo l'articolo modificato. Import massivi: nessun refresh per riga, si lancia un solo rebuild finale.
5. `catalog_search_v2(p_query, p_limit, p_offset, p_channel, p_allowed_cdpars, filtri, p_debug)` e `get_catalog_search_config()`.

## Comportamento della ricerca

- Normalizzazione query, distinzione numerico/testuale, SKU ed EAN esatti con priorità massima, poi prefisso codice.
- Token in gruppi: AND fra i termini digitati, OR fra forma originale, singolare/plurale (dizionario italiano full-text) e sinonimi.
- Prefisso applicato **solo** all'ultima parola in digitazione e solo su titoli, variante, brand e tassonomia breve — mai sulle descrizioni.
- Descrizioni con peso basso, solo di supporto; fuzzy attivato solo se i risultati lessicali sono meno di `fuzzy_fallback_count`, su token lunghi, mai sulle descrizioni, con punteggio che non può superare un match lessicale corretto.
- Override, esclusioni, filtri di visibilità e `p_allowed_cdpars` applicati centralmente; varianti collassate sul padre conservando `matched_cdpar`.
- Ordinamento stabile (punteggio desc, `cdpar` asc), `LIMIT/OFFSET` reali nel database, nessun tetto fisso a 240 candidati, nessun prezzo o giacenza nell'output.

## Pagina PIM

Nuova voce **Impostazioni → Ricerca catalogo**, rotta `/pim/admin/catalog-search`, tab nella barra di `AdminPage`, accesso solo admin. Schede: Generale (config + pesi con testi di aiuto e validazione), Sinonimi, Esclusioni, Priorità prodotti (selezione articolo reale dal database), Test ricerca (usa realmente `catalog_search_v2`, con canale, filtri, tempo di risposta, motivazione del punteggio per riga e modalità confronto fra due query), Diagnostica (conteggi, ultimo rebuild, articoli mancanti, pulsante "Rigenera indice" con conferma e stato). Salvataggio esplicito, toast, skeleton, stati vuoti, testi in italiano, layout desktop/tablet coerente con il PIM esistente.

## Sicurezza

Scrittura su config/sinonimi/esclusioni/override e rebuild riservata agli admin (`has_role(auth.uid(),'admin')`); lettura di config e ricerca consentita anche in anonimo, filtrata sulla visibilità. `SECURITY DEFINER` sempre con `SET search_path = public`. Nessun dato commerciale esposto.

## Test e prestazioni

Test SQL + applicativi su tutte le coppie singolare/plurale indicate, `viti mustad`, `guanti nitrile`, `condizi` (verifica che non emergano concimi o match solo da descrizione), `496965`, `UL050` / `UL 050`, EAN esatto, sinonimo bidirezionale, match via variante rappresentato dal padre, esclusione, boost, paginazione senza duplicati. `EXPLAIN ANALYZE` sulle query principali con correzione degli indici in caso di scansioni sequenziali; obiettivo primi 30 risultati entro 150 ms.

## Note tecniche

- Nuovi oggetti tutti con prefisso `catalog_search_*`: nessuna RPC o indice esistente viene rinominato o modificato.
- Frontend: `src/pages/AdminCatalogSearchPage.tsx` + componenti in `src/components/admin/catalog-search/`, hook `src/hooks/useCatalogSearchConfig.ts`, rotta figlia di `AdminPage` in `src/App.tsx`.
- Nessuna nuova `SectionKey`: la pagina eredita `users_admin` come le altre tab di Admin; nessun campo AS400 coinvolto, `fieldDefinitions.ts` non va toccato.

## Fuori da questa fase

Modifiche al Portale B2B e al Portale Agenti: al termine verrà indicato esattamente cosa dovranno cambiare per passare a `catalog_search_v2`.

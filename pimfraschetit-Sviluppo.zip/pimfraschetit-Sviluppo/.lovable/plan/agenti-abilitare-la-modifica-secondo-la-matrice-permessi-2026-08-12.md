# Agenti: abilitare la modifica secondo la matrice permessi

## Perché ora non può modificare

La pagina Agenti non usa la matrice permessi: controlla il ruolo grezzo.

```
canEdit  = role === "admin" || "manager" || "collaborator"
canRemove = role === "admin"
```

L'utente collegato è `assistant_manager`, ruolo non incluso in quella lista: i pulsanti "Assegna codice agente", modifica e rimozione restano nascosti, indipendentemente dal permesso `agents` assegnato al suo dipartimento in Admin → Permessi.

## Cosa cambiare

In `src/pages/AgentsPage.tsx` sostituire il check di ruolo con `usePermissions()`:

- `canEdit = can("write", "agents")` — così vale la matrice per dipartimento/ruolo (admin resta sempre write).
- `canRemove = can("write", "agents")` oppure, se si vuole tenere la rimozione più restrittiva, `can("delete", "agents")` tramite azione granulare.
- Nascondere l'intera pagina se `!sectionVisible("agents")`.

Nessuna modifica al database: la RLS su `profiles` resta invariata.

## Da decidere

La rimozione del codice agente deve restare riservata agli admin, o basta il permesso di scrittura sulla sezione Agenti?

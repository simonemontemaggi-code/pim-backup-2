# Sezione Report (Amministrazione)

Replica nel PIM la logica del programma attuale: un report è una **tabella libera** con testata, regole di visibilità, colonne configurabili e righe importate da Excel/TXT/incolla, destinate ad agenti o clienti.

## Dove
Nuovo tab **Report** in `Amministrazione` (`/pim/admin/reports`), con pagina di dettaglio `/pim/admin/reports/:id`. Nuova SectionKey `admin_reports` (visibilità/scrittura gestibili in Admin → Permessi).

## Testata del report
- ID progressivo leggibile, Titolo, Descrizione
- Data inizio / Data fine (finestra di pubblicazione)
- Ordine di visualizzazione (decrescente insieme all'ID)
- Destinatari: **Agenti** oppure **Clienti** (determina se la colonna chiave delle righe è codice agente o codice cliente)
- Flag di visibilità, identici al programma attuale:
  - Mostra dati solo se il destinatario è presente nella lista
  - Mostra solo i dati del singolo utente
  - Non mostrare (report sospeso)
  - Non mostrare il nominativo

## Colonne
Le colonne non sono fisse: nascono dall'intestazione del file caricato. Per ognuna si configura:
- etichetta, suffisso (es. €, %), gruppo
- allineamento (sinistra/centro/destra)
- "in lista" (visibile sì/no)
- ordine di visualizzazione (drag or su/giù)

## Caricamento righe
Tre modalità nello stesso dialog:
1. **XLSX** (prima riga = intestazioni)
2. **TXT delimitato da tabulazione**
3. **Incolla da Excel** (textarea, parsing tab/newline)

Flusso: anteprima delle prime righe + mappatura della colonna chiave (codice agente/cliente) e della colonna nominativo, poi scelta tra **Sostituisci** le righe esistenti o **Aggiungi**. Le colonne nuove trovate nel file vengono create automaticamente con impostazioni di default.

## Anteprima
Nel dettaglio report, un selettore "Vedi come" (agente o cliente) mostra esattamente ciò che quell'utente vedrebbe, applicando finestra date e i quattro flag.

## Dettagli tecnici
- Tre tabelle nuove: `reports` (testata + flag), `report_columns` (chiave colonna, label, suffisso, gruppo, allineamento, visibile, ordine), `report_rows` (report_id, codice destinatario, nominativo, `values` jsonb, ordine). Grant + RLS: gestione per chi ha permesso di scrittura su `admin_reports`; lettura pubblica limitata alle righe dei report attivi e in finestra, per il consumo futuro da Agent Hub/B2B.
- Funzione SQL `pim_report_rows_for(report_id, codice)` che applica flag + finestra date, usata sia dall'anteprima PIM sia in seguito dai portali.
- Parser condiviso `src/lib/reportRowsParser.ts` per XLSX (via `xlsx`), TXT tabulato e incolla, con normalizzazione numeri in formato italiano.
- Pagine `AdminReportsPage.tsx` (lista con ricerca, stato attivo/scaduto, ordine) e `AdminReportDetailPage.tsx` (testata, colonne, righe, import, anteprima), registrate in `App.tsx` e nei tab di `AdminPage.tsx`.
- Registrazione dei campi della testata in `src/lib/fieldDefinitions.ts` sotto la nuova section.

## Fuori scope in questa fase
Rendering dei report dentro Portale Agenti e B2B: qui produciamo solo dati e funzione di lettura già pronti.

# Rimozione completa della sezione Ricerca

## Risultato

Eliminare integralmente la sezione amministrativa **Ricerca** appena introdotta e ripristinare il PIM senza banco di prova, configurazione centralizzata o simulazioni Agent Hub/B2B. Le ricerche operative già esistenti nel catalogo PIM, in Agent Hub e nel B2B non saranno modificate.

## Intervento

1. **Rimuovere la sezione dall'interfaccia**
   - Eliminare la voce “Ricerca” dalle tab di amministrazione.
   - Eliminare la route `/pim/admin/search` e il relativo import.
   - Rimuovere la pagina, il banco a tre colonne, il test di massa e i pannelli Sinonimi/Campi/Impostazioni/Correzioni.

2. **Eliminare il codice del motore sperimentale**
   - Rimuovere `useSearchConfig` e tutti gli oracle/helper aggiunti per simulare Agent Hub e B2B.
   - Eliminare i riferimenti residui e verificare che nessun'altra pagina importi questi moduli.

3. **Pulire i collegamenti secondari**
   - Nella tabella delle ricerche senza risultato, rimuovere solo il pulsante che portava alle nuove Impostazioni Ricerca.
   - Conservare la ricerca nel catalogo e le azioni “gestita/riapri”, che appartengono alla Navigation Analysis esistente.

4. **Rimuovere le risorse database sperimentali**
   - Applicare una migration di rollback che elimini le funzioni `pim_search_articles`, `pim_search_match_expr` e `pim_search_sample_queries` se presenti.
   - Eliminare le tabelle `search_synonyms`, `search_fields`, `search_settings`, `search_overrides` e `search_queries`, insieme al relativo job di retention se presente.
   - Rigenerare i tipi Supabase tramite il normale flusso della migration.

5. **Pulizia e verifica**
   - Rimuovere la documentazione specifica del motore sperimentale.
   - Verificare che l'area Admin si apra senza la tab Ricerca, che la vecchia URL dia pagina non trovata e che Navigation Analysis continui a funzionare.
   - Eseguire i controlli automatici disponibili e una verifica browser dei flussi interessati.

## Confini

- Nessuna modifica alla ricerca reale degli articoli già usata nel PIM.
- Nessuna modifica ai progetti Agent Hub e B2B Mockup.
- Nessun nuovo campo articolo: `fieldDefinitions.ts` non richiede aggiornamenti.

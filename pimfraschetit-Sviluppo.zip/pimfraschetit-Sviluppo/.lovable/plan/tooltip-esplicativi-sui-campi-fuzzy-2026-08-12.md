# Tooltip esplicativi sui campi fuzzy

Aggiungere un'icona "?" accanto alle due voci nella card "Comportamento" della pagina Ricerca catalogo, con tooltip al passaggio del mouse.

## Testi dei tooltip

- **Tolleranza errori di battitura**: "Se attiva, la ricerca trova risultati anche quando la parola è scritta con piccoli errori (es. 'martelo' → 'martello'). Viene usata solo come rete di sicurezza quando la ricerca esatta restituisce pochi risultati."
- **Soglia somiglianza (0-1)**: "Quanto una parola deve assomigliare al termine cercato per essere accettata. Valori alti (0,7-0,9) = pochi risultati ma molto pertinenti; valori bassi (0,3-0,4) = più risultati ma con rischio di errori. Consigliato: 0,55."

## Dettagli tecnici

- File: `src/pages/AdminCatalogSearchPage.tsx`
- Usare `Tooltip`/`TooltipTrigger`/`TooltipContent` da `@/components/ui/tooltip` con icona `HelpCircle` (lucide, `h-3.5 w-3.5 text-muted-foreground`) accanto alla `Label`.
- Nessuna modifica a logica, dati o RPC.

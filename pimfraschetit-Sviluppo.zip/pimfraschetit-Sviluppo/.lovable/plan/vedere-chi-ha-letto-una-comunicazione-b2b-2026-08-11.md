# Vedere chi ha letto una comunicazione B2B

Oggi la scheda "Letture" mostra solo il numero (es. 13). I dati per sapere *chi* ci sono già: ogni lettura salva l'app di provenienza (`agent_hub` o `b2b`), l'identificativo utente e la data/ora.

## Cosa aggiungere

Nella pagina di dettaglio della comunicazione, nel riquadro "Letture":

- Pulsante **Vedi dettaglio** accanto ad "Azzera letture".
- Popup con la lista delle letture ordinata dalla più recente:
  - Origine (badge Agent Hub / B2B)
  - Codice (agente o cliente)
  - Nome: per Agent Hub il nome dell'agente, per B2B la ragione sociale del cliente
  - Data e ora della lettura
- Campo di ricerca per codice/nome e conteggio totale in alto.
- Export XLSX/PDF della lista, coerente con gli altri popup del PIM.

## Note tecniche

- Fonte dati: `b2b_communication_reads` filtrata per `communication_id` (SELECT già consentita).
- Risoluzione nomi: `profiles.agent_code -> full_name` per `app = 'agent_hub'`; `customers.customer_code -> ragione sociale` per `app = 'b2b'`; se non trovato si mostra solo il codice.
- Nuovo componente `CommunicationReadsDialog.tsx` usato da `B2bCommunicationEditorPage.tsx`; nessuna modifica al database.

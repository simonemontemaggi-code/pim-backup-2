# Ordinamento risultati: priorità al titolo B2B e alla posizione della parola

Oggi il punteggio mescola titolo, tassonomia, brand e descrizione, quindi un articolo che ha la parola cercata solo in tassonomia può finire sopra a uno che ce l'ha nel titolo B2B (es. "Etichette adesive segnaletiche A" prima dei climatizzatori per la query `condiziona`).

## Nuovo comportamento

I risultati vengono ordinati per fasce, dalla più forte alla più debole:

1. Codice articolo o EAN esatto
2. Titolo B2B identico alla ricerca
3. Titolo B2B che **inizia** con la parola/frase cercata (es. "Palla gioco")
4. Titolo B2B che contiene la parola cercata in posizione successiva (es. "Gioco palla")
5. Titolo B2B che contiene la parola solo in forma singolare/plurale o come sinonimo
6. Tassonomia / brand / tag
7. Solo descrizione
8. Fuzzy

Dentro la fascia 4 conta la posizione: più la parola è vicina all'inizio del titolo, più alto è il risultato. A parità, si usa il punteggio attuale (pesi, boost manuali) e poi il codice articolo, così l'ordine resta stabile e la paginazione non duplica righe.

L'insieme dei risultati (il totale, oggi 66 per `condiziona`) **non cambia**: cambia solo l'ordine.

## Dettagli tecnici

- Aggiungere a `catalog_search_index` la colonna `title_norm` (solo titolo B2B normalizzato con `catalog_search_norm`, senza variante/brand/tassonomia) più indice trigram, e popolarla in `catalog_search_upsert` / `rebuild_catalog_search_index` con rebuild completo dell'indice.
- In `catalog_search_v2`, nel blocco `scored`, calcolare da `title_norm`:
  - `title_exact` (uguaglianza con la query normalizzata)
  - `title_starts` (`title_norm` inizia con la frase o con il primo token)
  - `title_word_pos` = posizione in caratteri della prima occorrenza della parola cercata (0 se assente)
  - `title_all_words` = tutti i token presenti come parola intera nel titolo
- Aggiungere i pesi in `catalog_search_config.weights`: `title_starts`, `title_position_decay`, `title_all_words`, esposti e modificabili nella scheda **Parametri** di `/pim/admin/catalog-search` con testo di aiuto.
- Ordinamento finale: `rank_tier DESC, total_score DESC, title_word_pos ASC, visible_cdpar ASC` (il `DISTINCT ON` del collasso varianti usa lo stesso criterio).
- Aggiungere in debug (`match_reasons`) `tier`, `title_pos` e mostrare nel banco di prova una colonna/badge con la fascia, per verificare l'ordine.
- Verifica: query `condiziona` (climatizzatori/condizionatori prima delle etichette), una query a due parole, un codice numerico, e un test di paginazione senza duplicati.
- Nessun campo AS400 coinvolto: `fieldDefinitions.ts` non va aggiornato.

# Fase 3 — Agent Hub come baseline, poi motore unico per tutti

La configurazione attualmente caricata nel PIM replica già il comportamento Agent Hub (stesse colonne, stessi pesi, match "substring", sinonimi storici). Dato che Agent Hub è il motore migliore, lo trattiamo come riferimento ufficiale: prima lo certifichiamo con un test di massa, poi facciamo passare anche B2B Mockup e Agent Hub sul motore unico controllato dal PIM.

## Passo 1 — Certificare la baseline (nessun rischio, solo lettura)

Aggiungere al banco di prova una modalità "Batch": si incolla (o si importa dalle ricerche a vuoto reali) una lista di query e il PIM le esegue tutte, confrontando nuovo motore vs Agent Hub.

Output: una tabella con, per ogni query, numero risultati nuovo/Agent Hub, primo risultato uguale o diverso, e una percentuale complessiva di allineamento. Export Excel.

Obiettivo dichiarato: >= 98% di query con stesso primo risultato. Se qualcosa diverge, si corregge la configurazione (pesi/sinonimi/override) finché non torna, senza toccare le app esterne.

## Passo 2 — Migliorie sopra la baseline

Solo dopo che il Passo 1 è verde, si attivano una alla volta (ognuna con un confronto prima/dopo nel banco di prova):

- Sinonimi centralizzati validi per entrambe le app (oggi Agent Hub e B2B hanno liste diverse).
- Correzioni manuali (pin/escludi) per le query a vuoto ricorrenti già tracciate in Navigation Analysis.
- Tolleranza refusi (fuzzy) attivabile solo quando la ricerca non produce risultati, così non sporca i casi buoni.

## Passo 3 — Collegare le app esterne

Le due app puntano alla funzione di ricerca del PIM invece della propria logica interna, una alla volta:

1. Agent Hub (rischio minimo: stessa configurazione già certificata).
2. B2B Mockup (guadagno maggiore: eredita il comportamento migliore).

Ogni app tiene un interruttore di rientro immediato al vecchio motore in caso di problemi. Da quel momento, ogni modifica fatta in PIM → Admin → Ricerca ha effetto su entrambe senza rilasci di codice.

## Passo 4 — Monitoraggio

Le ricerche a vuoto continuano ad arrivare in Navigation Analysis, con la sorgente (Agent Hub / B2B). Dalla riga si apre già il banco di prova con la query precompilata per correggerla.

## Dettagli tecnici

- La configurazione vive in `search_fields`, `search_synonyms`, `search_settings`, `search_overrides`; la funzione è `public.pim_search_articles(_q, _limit, _offset, _config)`.
- Passo 1: nuovo componente `BatchTestPanel.tsx` che cicla le query sul motore nuovo e sul replay Agent Hub già presente in `src/lib/search/legacyEngines.ts`, con export via `xlsx`.
- Passo 2 fuzzy: `pg_trgm` con soglia da `search_settings`, applicato solo come fallback a zero risultati.
- Passo 3: le app chiamano la RPC via `supabase.rpc("pim_search_articles", ...)`; serve `GRANT EXECUTE` ad `anon` e `authenticated` (oggi la funzione è già eseguibile, verrà confermato al momento del collegamento). Il rientro è un flag in `search_settings` letto dalle app.
- Le modifiche alle app esterne vanno fatte nei rispettivi progetti: questo piano copre il PIM e la RPC condivisa; per Agent Hub e B2B Mockup fornirò lo snippet esatto da incollare.

## Cosa NON tocchiamo

Nessuna modifica alla ricerca articoli interna del PIM, né ai dati degli articoli.

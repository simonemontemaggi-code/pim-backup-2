# Ordinamento drag & drop ed eliminazione report

## Obiettivo
Gestire l'ordine dei report direttamente dalla lista (trascinamento righe) e poter eliminare un report da lì. Il campo numerico "Ordine (decrescente)" sparisce dalla scheda del singolo report.

## Lista Report (`/pim/admin/reports`)
- Ogni riga ottiene una maniglia di trascinamento a sinistra (icona grip): si trascina per riordinare, la posizione in alto = report mostrato per primo ai destinatari.
- Al rilascio, il nuovo ordine viene salvato subito su tutte le righe interessate; in caso di errore si torna all'ordine precedente con un messaggio.
- La colonna numerica "Ordine" viene rimossa (l'ordine è ora implicito nella posizione).
- Nuova colonna azioni a destra con pulsante elimina (icona cestino) e conferma prima della cancellazione (avviso che vengono eliminate anche colonne e righe dati del report).
- Trascinamento ed eliminazione visibili solo con permesso di scrittura su `admin_reports`. Il drag è disabilitato quando è attiva una ricerca, per evitare riordini parziali.
- Il click sulla riga continua ad aprire il report (il drag non deve innescare la navigazione).

## Scheda report (`/pim/admin/reports/:id`)
- Rimosso il campo "Ordine (decrescente)" dalla testata e dal salvataggio: l'ordine si gestisce solo dalla lista.

## Note tecniche
- `AdminReportsPage.tsx`: `DndContext` + `SortableContext` (`@dnd-kit`, già usato altrove nel progetto) con `verticalListSortingStrategy` su righe di tabella; stato locale ordinato + mutation di persistenza.
- Persistenza: la lista è ordinata per `sort_order` decrescente; alla fine del drag si riassegnano valori `sort_order` decrescenti (N-1 … 0) e si aggiornano le righe modificate su `reports`, poi invalidazione di `admin_reports`.
- Eliminazione: `delete` su `reports` per id (le tabelle `report_columns`/`report_rows` sono legate al report tramite `report_id` con cancellazione a cascata) usando `useConfirm`.
- `AdminReportDetailPage.tsx`: rimozione dell'input `sort_order` e della relativa chiave nell'update di `saveHead`.
- Nessuna modifica al database o alle policy; nessun nuovo campo per `fieldDefinitions.ts`.

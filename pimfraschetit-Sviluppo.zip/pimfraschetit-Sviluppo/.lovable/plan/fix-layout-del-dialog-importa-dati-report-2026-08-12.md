# Fix layout del dialog "Importa dati report"

La finestra di import sborda: l'anteprima con decine di colonne (settimana 01…52) allarga il dialog oltre lo schermo, la tendina "Colonna codice agente" diventa larghissima e i contenuti finiscono fuori dal riquadro.

## Cosa cambia

- Il dialog resta di larghezza fissa e leggibile (max ~1100px, mai oltre il 95% dello schermo) e scorre verticalmente se il contenuto è lungo.
- L'anteprima delle righe vive dentro un contenitore con scorrimento orizzontale proprio: le colonne extra si scorrono, non allargano la finestra.
- La colonna "Nominativo" resta fissa a sinistra durante lo scorrimento orizzontale, così si vede sempre a chi appartiene la riga.
- La tendina "Colonna codice agente" torna a larghezza normale (max ~320px).
- La textarea "Incolla da Excel" non si allarga con il testo: va a capo/scorre internamente, altezza fissa.
- Anteprima limitata alle prime 5 righe e alle prime colonne visibili, con nota "…e altre N colonne" per evitare tabelle chilometriche.
- Il footer con i pulsanti (Sostituisci / Aggiungi, Importa) resta sempre visibile in fondo al dialog.

## Dettagli tecnici

Interventi solo in `src/pages/AdminReportDetailPage.tsx`, componente `ImportDialog`:
- `DialogContent` con `max-w-[1100px] w-[95vw] max-h-[85vh] overflow-hidden flex flex-col`; corpo scrollabile `flex-1 overflow-y-auto`, footer fuori dall'area scrollabile.
- Wrapper dell'anteprima: `w-full overflow-x-auto` con tabella `min-w-max`; prima colonna `sticky left-0 bg-background z-10`.
- `SelectTrigger` della colonna codice: `max-w-xs`.
- `Textarea`: `w-full h-40 resize-none font-mono text-xs whitespace-pre overflow-auto`.
- Aggiunta `aria-describedby`/`DialogDescription` per togliere anche il warning console su `DialogContent`.

Nessuna modifica a parser, RPC o dati.

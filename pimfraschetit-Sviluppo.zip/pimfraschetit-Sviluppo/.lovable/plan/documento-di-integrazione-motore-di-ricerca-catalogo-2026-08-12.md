# Documento di integrazione motore di ricerca catalogo

Creare un unico documento markdown nel repo PIM da consegnare ai progetti B2B Mockup e Portale Agenti, così che possano collegarsi al motore di ricerca centralizzato senza reimplementare logica.

## Cosa contiene il documento

`docs/catalog-search-integration.md`, con queste sezioni:

1. **Prerequisiti di collegamento** — stesso progetto Supabase (`ytkofsktbkuzgzhzhiys`), verifica di `VITE_SUPABASE_URL` nei due client, nota che la anon key basta perché le RPC sono SECURITY DEFINER con EXECUTE per `anon`.
2. **RPC `catalog_search_v2`** — firma completa, significato di ogni parametro (canale, whitelist assortimento, filtri, debug), colonne restituite e note d'uso (total_count/has_more ripetuti su ogni riga, match_reasons solo con debug).
3. **RPC `get_catalog_search_config()`** — output jsonb e come usarlo per min_chars, debounce e invalidazione cache su `version`.
4. **Regole di ranking** — sistema a Tier (titolo esatto, inizio titolo, inclusione, poi lessicale/tassonomia) e ruolo dei pesi configurabili.
5. **Normalizzazione e sinonimi** — comportamento di `catalog_search_norm` e `catalog_search_stem` (plurali automatici ≥5 lettere), quando serve un sinonimo esplicito, dove si gestiscono stopword e override prodotto.
6. **Esempi di chiamata** — snippet TypeScript con il client Supabase per B2B (con `p_allowed_cdpars` dell'assortimento) e per Agent Hub, più gestione di paginazione e debounce.
7. **Modello dati** — elenco tabelle di supporto e chi le aggiorna (trigger di sync, `catalog_search_upsert`, log di rebuild).
8. **Governance** — tutte le modifiche a pesi, sinonimi, stopword e override si fanno solo dal PIM in Impostazioni → Ricerca catalogo; i client non devono duplicare filtri o riordini lato codice.
9. **Appendice A — SQL integrale** — contenuto completo delle 12 migration relative alla ricerca, in ordine cronologico, ciascuna con nome file e separatore.

## Dettagli tecnici

- Nessuna modifica a database, RPC o UI: il lavoro è solo di documentazione.
- Le migration incluse in appendice: `20260811145338`, `20260811145736`, `20260811150221`, `20260811150431`, `20260811151928`, `20260811152355`, `20260811153046`, `20260812064448`, `20260812064614`, `20260812070413`, `20260812070601`, `20260812074825`.
- Le definizioni di funzione riportate nel documento saranno quelle attualmente attive sul database, non solo quelle delle migration originali.
- Nessun aggiornamento a `fieldDefinitions.ts` necessario: non vengono introdotti nuovi campi o sezioni.
